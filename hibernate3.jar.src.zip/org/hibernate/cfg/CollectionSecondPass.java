/*    */ package org.hibernate.cfg;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.MappingException;
/*    */ import org.hibernate.mapping.Collection;
/*    */ import org.hibernate.mapping.IndexedCollection;
/*    */ import org.hibernate.mapping.OneToMany;
/*    */ import org.hibernate.mapping.Selectable;
/*    */ import org.hibernate.mapping.Value;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CollectionSecondPass
/*    */   implements SecondPass
/*    */ {
/* 21 */   private static Log log = LogFactory.getLog(CollectionSecondPass.class);
/*    */   Mappings mappings;
/*    */   Collection collection;
/*    */   
/*    */   public CollectionSecondPass(Mappings mappings, Collection collection) {
/* 26 */     this.collection = collection;
/* 27 */     this.mappings = mappings;
/*    */   }
/*    */   
/*    */   public void doSecondPass(Map persistentClasses, Map inheritedMetas) throws MappingException
/*    */   {
/* 32 */     if (log.isDebugEnabled()) {
/* 33 */       log.debug("Second pass for collection: " + this.collection.getRole());
/*    */     }
/* 35 */     secondPass(persistentClasses, inheritedMetas);
/* 36 */     this.collection.createAllKeys();
/*    */     
/* 38 */     if (log.isDebugEnabled()) {
/* 39 */       String msg = "Mapped collection key: " + columns(this.collection.getKey());
/* 40 */       if (this.collection.isIndexed())
/* 41 */         msg = msg + ", index: " + columns(((IndexedCollection)this.collection).getIndex());
/* 42 */       if (this.collection.isOneToMany()) {
/* 43 */         msg = msg + ", one-to-many: " + ((OneToMany)this.collection.getElement()).getReferencedEntityName();
/*    */       }
/*    */       else
/*    */       {
/* 47 */         msg = msg + ", element: " + columns(this.collection.getElement());
/*    */       }
/* 49 */       log.debug(msg);
/*    */     }
/*    */   }
/*    */   
/*    */   public abstract void secondPass(Map paramMap1, Map paramMap2) throws MappingException;
/*    */   
/*    */   private static String columns(Value val)
/*    */   {
/* 57 */     StringBuffer columns = new StringBuffer();
/* 58 */     Iterator iter = val.getColumnIterator();
/* 59 */     while (iter.hasNext()) {
/* 60 */       columns.append(((Selectable)iter.next()).getText());
/* 61 */       if (iter.hasNext()) columns.append(", ");
/*    */     }
/* 63 */     return columns.toString();
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cfg\CollectionSecondPass.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */