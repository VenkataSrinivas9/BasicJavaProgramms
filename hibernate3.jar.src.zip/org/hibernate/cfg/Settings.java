/*     */ package org.hibernate.cfg;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.hibernate.ConnectionReleaseMode;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.cache.CacheProvider;
/*     */ import org.hibernate.cache.QueryCacheFactory;
/*     */ import org.hibernate.connection.ConnectionProvider;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.exception.SQLExceptionConverter;
/*     */ import org.hibernate.hql.QueryTranslatorFactory;
/*     */ import org.hibernate.jdbc.BatcherFactory;
/*     */ import org.hibernate.transaction.TransactionFactory;
/*     */ import org.hibernate.transaction.TransactionManagerLookup;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Settings
/*     */ {
/*     */   private boolean showSql;
/*     */   private boolean formatSql;
/*     */   private Integer maximumFetchDepth;
/*     */   private Map querySubstitutions;
/*     */   private Dialect dialect;
/*     */   private int jdbcBatchSize;
/*     */   private int defaultBatchFetchSize;
/*     */   private boolean scrollableResultSetsEnabled;
/*     */   private boolean getGeneratedKeysEnabled;
/*     */   private String defaultSchemaName;
/*     */   private String defaultCatalogName;
/*     */   private Integer jdbcFetchSize;
/*     */   private String sessionFactoryName;
/*     */   private boolean autoCreateSchema;
/*     */   private boolean autoDropSchema;
/*     */   private boolean autoUpdateSchema;
/*     */   private boolean autoValidateSchema;
/*     */   private boolean queryCacheEnabled;
/*     */   private boolean structuredCacheEntriesEnabled;
/*     */   private boolean secondLevelCacheEnabled;
/*     */   private String cacheRegionPrefix;
/*     */   private boolean minimalPutsEnabled;
/*     */   private boolean commentsEnabled;
/*     */   private boolean statisticsEnabled;
/*     */   private boolean jdbcBatchVersionedData;
/*     */   private boolean identifierRollbackEnabled;
/*     */   private boolean flushBeforeCompletionEnabled;
/*     */   private boolean autoCloseSessionEnabled;
/*     */   private ConnectionReleaseMode connectionReleaseMode;
/*     */   private CacheProvider cacheProvider;
/*     */   private QueryCacheFactory queryCacheFactory;
/*     */   private ConnectionProvider connectionProvider;
/*     */   private TransactionFactory transactionFactory;
/*     */   private TransactionManagerLookup transactionManagerLookup;
/*     */   private BatcherFactory batcherFactory;
/*     */   private QueryTranslatorFactory queryTranslatorFactory;
/*     */   private SQLExceptionConverter sqlExceptionConverter;
/*     */   private boolean wrapResultSetsEnabled;
/*     */   private boolean orderUpdatesEnabled;
/*     */   private EntityMode defaultEntityMode;
/*     */   
/*     */   public String getDefaultSchemaName()
/*     */   {
/*  69 */     return this.defaultSchemaName;
/*     */   }
/*     */   
/*     */   public String getDefaultCatalogName() {
/*  73 */     return this.defaultCatalogName;
/*     */   }
/*     */   
/*     */   public Dialect getDialect() {
/*  77 */     return this.dialect;
/*     */   }
/*     */   
/*     */   public int getJdbcBatchSize() {
/*  81 */     return this.jdbcBatchSize;
/*     */   }
/*     */   
/*     */   public int getDefaultBatchFetchSize() {
/*  85 */     return this.defaultBatchFetchSize;
/*     */   }
/*     */   
/*     */   public Map getQuerySubstitutions() {
/*  89 */     return this.querySubstitutions;
/*     */   }
/*     */   
/*     */   public boolean isShowSqlEnabled() {
/*  93 */     return this.showSql;
/*     */   }
/*     */   
/*     */   public boolean isFormatSqlEnabled() {
/*  97 */     return this.formatSql;
/*     */   }
/*     */   
/*     */   public boolean isIdentifierRollbackEnabled() {
/* 101 */     return this.identifierRollbackEnabled;
/*     */   }
/*     */   
/*     */   public boolean isScrollableResultSetsEnabled() {
/* 105 */     return this.scrollableResultSetsEnabled;
/*     */   }
/*     */   
/*     */   public boolean isGetGeneratedKeysEnabled() {
/* 109 */     return this.getGeneratedKeysEnabled;
/*     */   }
/*     */   
/*     */   public boolean isMinimalPutsEnabled() {
/* 113 */     return this.minimalPutsEnabled;
/*     */   }
/*     */   
/*     */   void setDefaultSchemaName(String string) {
/* 117 */     this.defaultSchemaName = string;
/*     */   }
/*     */   
/*     */   void setDefaultCatalogName(String string) {
/* 121 */     this.defaultCatalogName = string;
/*     */   }
/*     */   
/*     */   void setDialect(Dialect dialect) {
/* 125 */     this.dialect = dialect;
/*     */   }
/*     */   
/*     */   void setJdbcBatchSize(int i) {
/* 129 */     this.jdbcBatchSize = i;
/*     */   }
/*     */   
/*     */   void setDefaultBatchFetchSize(int i) {
/* 133 */     this.defaultBatchFetchSize = i;
/*     */   }
/*     */   
/*     */   void setQuerySubstitutions(Map map) {
/* 137 */     this.querySubstitutions = map;
/*     */   }
/*     */   
/*     */   void setShowSqlEnabled(boolean b) {
/* 141 */     this.showSql = b;
/*     */   }
/*     */   
/*     */   void setFormatSqlEnabled(boolean b) {
/* 145 */     this.formatSql = b;
/*     */   }
/*     */   
/*     */   void setIdentifierRollbackEnabled(boolean b) {
/* 149 */     this.identifierRollbackEnabled = b;
/*     */   }
/*     */   
/*     */   void setMinimalPutsEnabled(boolean b) {
/* 153 */     this.minimalPutsEnabled = b;
/*     */   }
/*     */   
/*     */   void setScrollableResultSetsEnabled(boolean b) {
/* 157 */     this.scrollableResultSetsEnabled = b;
/*     */   }
/*     */   
/*     */   void setGetGeneratedKeysEnabled(boolean b) {
/* 161 */     this.getGeneratedKeysEnabled = b;
/*     */   }
/*     */   
/*     */   public Integer getJdbcFetchSize() {
/* 165 */     return this.jdbcFetchSize;
/*     */   }
/*     */   
/* 168 */   void setJdbcFetchSize(Integer integer) { this.jdbcFetchSize = integer; }
/*     */   
/*     */   public ConnectionProvider getConnectionProvider()
/*     */   {
/* 172 */     return this.connectionProvider;
/*     */   }
/*     */   
/* 175 */   void setConnectionProvider(ConnectionProvider provider) { this.connectionProvider = provider; }
/*     */   
/*     */   public TransactionFactory getTransactionFactory()
/*     */   {
/* 179 */     return this.transactionFactory;
/*     */   }
/*     */   
/* 182 */   void setTransactionFactory(TransactionFactory factory) { this.transactionFactory = factory; }
/*     */   
/*     */   public String getSessionFactoryName()
/*     */   {
/* 186 */     return this.sessionFactoryName;
/*     */   }
/*     */   
/* 189 */   void setSessionFactoryName(String string) { this.sessionFactoryName = string; }
/*     */   
/*     */   public boolean isAutoCreateSchema()
/*     */   {
/* 193 */     return this.autoCreateSchema;
/*     */   }
/*     */   
/* 196 */   public boolean isAutoDropSchema() { return this.autoDropSchema; }
/*     */   
/*     */   public boolean isAutoUpdateSchema()
/*     */   {
/* 200 */     return this.autoUpdateSchema;
/*     */   }
/*     */   
/* 203 */   void setAutoCreateSchema(boolean b) { this.autoCreateSchema = b; }
/*     */   
/*     */   void setAutoDropSchema(boolean b)
/*     */   {
/* 207 */     this.autoDropSchema = b;
/*     */   }
/*     */   
/* 210 */   void setAutoUpdateSchema(boolean b) { this.autoUpdateSchema = b; }
/*     */   
/*     */   public Integer getMaximumFetchDepth()
/*     */   {
/* 214 */     return this.maximumFetchDepth;
/*     */   }
/*     */   
/* 217 */   void setMaximumFetchDepth(Integer i) { this.maximumFetchDepth = i; }
/*     */   
/*     */   public CacheProvider getCacheProvider()
/*     */   {
/* 221 */     return this.cacheProvider;
/*     */   }
/*     */   
/* 224 */   void setCacheProvider(CacheProvider cacheProvider) { this.cacheProvider = cacheProvider; }
/*     */   
/*     */   public TransactionManagerLookup getTransactionManagerLookup()
/*     */   {
/* 228 */     return this.transactionManagerLookup;
/*     */   }
/*     */   
/* 231 */   void setTransactionManagerLookup(TransactionManagerLookup lookup) { this.transactionManagerLookup = lookup; }
/*     */   
/*     */   public boolean isQueryCacheEnabled()
/*     */   {
/* 235 */     return this.queryCacheEnabled;
/*     */   }
/*     */   
/* 238 */   void setQueryCacheEnabled(boolean b) { this.queryCacheEnabled = b; }
/*     */   
/*     */   public boolean isCommentsEnabled()
/*     */   {
/* 242 */     return this.commentsEnabled;
/*     */   }
/*     */   
/* 245 */   void setCommentsEnabled(boolean commentsEnabled) { this.commentsEnabled = commentsEnabled; }
/*     */   
/*     */   public boolean isSecondLevelCacheEnabled()
/*     */   {
/* 249 */     return this.secondLevelCacheEnabled;
/*     */   }
/*     */   
/* 252 */   void setSecondLevelCacheEnabled(boolean secondLevelCacheEnabled) { this.secondLevelCacheEnabled = secondLevelCacheEnabled; }
/*     */   
/*     */   public String getCacheRegionPrefix()
/*     */   {
/* 256 */     return this.cacheRegionPrefix;
/*     */   }
/*     */   
/* 259 */   void setCacheRegionPrefix(String cacheRegionPrefix) { this.cacheRegionPrefix = cacheRegionPrefix; }
/*     */   
/*     */   public QueryCacheFactory getQueryCacheFactory()
/*     */   {
/* 263 */     return this.queryCacheFactory;
/*     */   }
/*     */   
/* 266 */   public void setQueryCacheFactory(QueryCacheFactory queryCacheFactory) { this.queryCacheFactory = queryCacheFactory; }
/*     */   
/*     */   public boolean isStatisticsEnabled()
/*     */   {
/* 270 */     return this.statisticsEnabled;
/*     */   }
/*     */   
/* 273 */   void setStatisticsEnabled(boolean statisticsEnabled) { this.statisticsEnabled = statisticsEnabled; }
/*     */   
/*     */   public boolean isJdbcBatchVersionedData()
/*     */   {
/* 277 */     return this.jdbcBatchVersionedData;
/*     */   }
/*     */   
/* 280 */   void setJdbcBatchVersionedData(boolean jdbcBatchVersionedData) { this.jdbcBatchVersionedData = jdbcBatchVersionedData; }
/*     */   
/*     */   public boolean isFlushBeforeCompletionEnabled()
/*     */   {
/* 284 */     return this.flushBeforeCompletionEnabled;
/*     */   }
/*     */   
/* 287 */   void setFlushBeforeCompletionEnabled(boolean flushBeforeCompletionEnabled) { this.flushBeforeCompletionEnabled = flushBeforeCompletionEnabled; }
/*     */   
/*     */   public BatcherFactory getBatcherFactory()
/*     */   {
/* 291 */     return this.batcherFactory;
/*     */   }
/*     */   
/* 294 */   void setBatcherFactory(BatcherFactory batcher) { this.batcherFactory = batcher; }
/*     */   
/*     */   public boolean isAutoCloseSessionEnabled()
/*     */   {
/* 298 */     return this.autoCloseSessionEnabled;
/*     */   }
/*     */   
/* 301 */   void setAutoCloseSessionEnabled(boolean autoCloseSessionEnabled) { this.autoCloseSessionEnabled = autoCloseSessionEnabled; }
/*     */   
/*     */   public ConnectionReleaseMode getConnectionReleaseMode()
/*     */   {
/* 305 */     return this.connectionReleaseMode;
/*     */   }
/*     */   
/*     */   public void setConnectionReleaseMode(ConnectionReleaseMode connectionReleaseMode) {
/* 309 */     this.connectionReleaseMode = connectionReleaseMode;
/*     */   }
/*     */   
/*     */   public QueryTranslatorFactory getQueryTranslatorFactory() {
/* 313 */     return this.queryTranslatorFactory;
/*     */   }
/*     */   
/*     */   void setQueryTranslatorFactory(QueryTranslatorFactory queryTranslatorFactory) {
/* 317 */     this.queryTranslatorFactory = queryTranslatorFactory;
/*     */   }
/*     */   
/*     */   public SQLExceptionConverter getSQLExceptionConverter() {
/* 321 */     return this.sqlExceptionConverter;
/*     */   }
/*     */   
/*     */   void setSQLExceptionConverter(SQLExceptionConverter sqlExceptionConverter) {
/* 325 */     this.sqlExceptionConverter = sqlExceptionConverter;
/*     */   }
/*     */   
/*     */   public boolean isWrapResultSetsEnabled() {
/* 329 */     return this.wrapResultSetsEnabled;
/*     */   }
/*     */   
/*     */   void setWrapResultSetsEnabled(boolean wrapResultSetsEnabled) {
/* 333 */     this.wrapResultSetsEnabled = wrapResultSetsEnabled;
/*     */   }
/*     */   
/*     */   public boolean isOrderUpdatesEnabled() {
/* 337 */     return this.orderUpdatesEnabled;
/*     */   }
/*     */   
/* 340 */   void setOrderUpdatesEnabled(boolean orderUpdatesEnabled) { this.orderUpdatesEnabled = orderUpdatesEnabled; }
/*     */   
/*     */   public boolean isStructuredCacheEntriesEnabled()
/*     */   {
/* 344 */     return this.structuredCacheEntriesEnabled;
/*     */   }
/*     */   
/* 347 */   void setStructuredCacheEntriesEnabled(boolean structuredCacheEntriesEnabled) { this.structuredCacheEntriesEnabled = structuredCacheEntriesEnabled; }
/*     */   
/*     */   public EntityMode getDefaultEntityMode()
/*     */   {
/* 351 */     return this.defaultEntityMode;
/*     */   }
/*     */   
/*     */   public void setDefaultEntityMode(EntityMode defaultEntityMode) {
/* 355 */     this.defaultEntityMode = defaultEntityMode;
/*     */   }
/*     */   
/*     */   public boolean isAutoValidateSchema() {
/* 359 */     return this.autoValidateSchema;
/*     */   }
/*     */   
/*     */   void setAutoValidateSchema(boolean autoValidateSchema) {
/* 363 */     this.autoValidateSchema = autoValidateSchema;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cfg\Settings.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */