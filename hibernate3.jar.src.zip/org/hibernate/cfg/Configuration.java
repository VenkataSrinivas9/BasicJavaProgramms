/*      */ package org.hibernate.cfg;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.Serializable;
/*      */ import java.io.StringReader;
/*      */ import java.lang.reflect.Array;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.ListIterator;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ import java.util.jar.JarFile;
/*      */ import java.util.zip.ZipEntry;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.dom4j.Attribute;
/*      */ import org.dom4j.DocumentException;
/*      */ import org.dom4j.Element;
/*      */ import org.dom4j.io.DOMReader;
/*      */ import org.dom4j.io.SAXReader;
/*      */ import org.hibernate.EmptyInterceptor;
/*      */ import org.hibernate.HibernateException;
/*      */ import org.hibernate.Interceptor;
/*      */ import org.hibernate.MappingException;
/*      */ import org.hibernate.SessionFactory;
/*      */ import org.hibernate.dialect.Dialect;
/*      */ import org.hibernate.dialect.MySQLDialect;
/*      */ import org.hibernate.engine.FilterDefinition;
/*      */ import org.hibernate.engine.Mapping;
/*      */ import org.hibernate.event.AutoFlushEventListener;
/*      */ import org.hibernate.event.DeleteEventListener;
/*      */ import org.hibernate.event.DirtyCheckEventListener;
/*      */ import org.hibernate.event.EventListeners;
/*      */ import org.hibernate.event.EvictEventListener;
/*      */ import org.hibernate.event.FlushEntityEventListener;
/*      */ import org.hibernate.event.FlushEventListener;
/*      */ import org.hibernate.event.InitializeCollectionEventListener;
/*      */ import org.hibernate.event.LoadEventListener;
/*      */ import org.hibernate.event.LockEventListener;
/*      */ import org.hibernate.event.MergeEventListener;
/*      */ import org.hibernate.event.PersistEventListener;
/*      */ import org.hibernate.event.PostDeleteEventListener;
/*      */ import org.hibernate.event.PostInsertEventListener;
/*      */ import org.hibernate.event.PostLoadEventListener;
/*      */ import org.hibernate.event.PostUpdateEventListener;
/*      */ import org.hibernate.event.PreDeleteEventListener;
/*      */ import org.hibernate.event.PreInsertEventListener;
/*      */ import org.hibernate.event.PreLoadEventListener;
/*      */ import org.hibernate.event.PreUpdateEventListener;
/*      */ import org.hibernate.event.RefreshEventListener;
/*      */ import org.hibernate.event.ReplicateEventListener;
/*      */ import org.hibernate.event.SaveOrUpdateEventListener;
/*      */ import org.hibernate.id.IdentifierGenerator;
/*      */ import org.hibernate.id.PersistentIdentifierGenerator;
/*      */ import org.hibernate.impl.SessionFactoryImpl;
/*      */ import org.hibernate.mapping.AuxiliaryDatabaseObject;
/*      */ import org.hibernate.mapping.ForeignKey;
/*      */ import org.hibernate.mapping.IdentifierCollection;
/*      */ import org.hibernate.mapping.Index;
/*      */ import org.hibernate.mapping.KeyValue;
/*      */ import org.hibernate.mapping.PersistentClass;
/*      */ import org.hibernate.mapping.Property;
/*      */ import org.hibernate.mapping.RootClass;
/*      */ import org.hibernate.mapping.SimpleValue;
/*      */ import org.hibernate.mapping.Table;
/*      */ import org.hibernate.mapping.UniqueKey;
/*      */ import org.hibernate.secure.JACCConfiguration;
/*      */ import org.hibernate.tool.hbm2ddl.DatabaseMetadata;
/*      */ import org.hibernate.tool.hbm2ddl.TableMetadata;
/*      */ import org.hibernate.type.SerializationException;
/*      */ import org.hibernate.type.Type;
/*      */ import org.hibernate.util.ArrayHelper;
/*      */ import org.hibernate.util.CollectionHelper;
/*      */ import org.hibernate.util.ConfigHelper;
/*      */ import org.hibernate.util.PropertiesHelper;
/*      */ import org.hibernate.util.ReflectHelper;
/*      */ import org.hibernate.util.SerializationHelper;
/*      */ import org.hibernate.util.StringHelper;
/*      */ import org.hibernate.util.XMLHelper;
/*      */ import org.xml.sax.EntityResolver;
/*      */ import org.xml.sax.InputSource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Configuration
/*      */   implements Serializable
/*      */ {
/*  116 */   private static Log log = LogFactory.getLog(Configuration.class);
/*      */   
/*      */   protected Map classes;
/*      */   
/*      */   protected Map imports;
/*      */   
/*      */   protected Map collections;
/*      */   
/*      */   protected Map tables;
/*      */   
/*      */   protected List auxiliaryDatabaseObjects;
/*      */   
/*      */   protected Map namedQueries;
/*      */   
/*      */   protected Map namedSqlQueries;
/*      */   
/*      */   protected Map sqlResultSetMappings;
/*      */   protected Map filterDefinitions;
/*      */   protected List secondPasses;
/*      */   protected List propertyReferences;
/*      */   protected Map extendsQueue;
/*      */   protected Map tableNameBinding;
/*      */   protected Map columnNameBindingPerTable;
/*      */   private Interceptor interceptor;
/*      */   private Properties properties;
/*      */   private EntityResolver entityResolver;
/*      */   private transient XMLHelper xmlHelper;
/*      */   protected transient Map typeDefs;
/*      */   protected NamingStrategy namingStrategy;
/*      */   private EventListeners eventListeners;
/*      */   protected final SettingsFactory settingsFactory;
/*      */   
/*      */   protected void reset()
/*      */   {
/*  150 */     this.classes = new HashMap();
/*  151 */     this.imports = new HashMap();
/*  152 */     this.collections = new HashMap();
/*  153 */     this.tables = new TreeMap();
/*  154 */     this.namedQueries = new HashMap();
/*  155 */     this.namedSqlQueries = new HashMap();
/*  156 */     this.sqlResultSetMappings = new HashMap();
/*  157 */     this.xmlHelper = new XMLHelper();
/*  158 */     this.typeDefs = new HashMap();
/*  159 */     this.propertyReferences = new ArrayList();
/*  160 */     this.secondPasses = new ArrayList();
/*  161 */     this.interceptor = EmptyInterceptor.INSTANCE;
/*  162 */     this.properties = Environment.getProperties();
/*  163 */     this.entityResolver = XMLHelper.DEFAULT_DTD_RESOLVER;
/*  164 */     this.eventListeners = new EventListeners();
/*  165 */     this.filterDefinitions = new HashMap();
/*      */     
/*  167 */     this.extendsQueue = new HashMap();
/*  168 */     this.auxiliaryDatabaseObjects = new ArrayList();
/*  169 */     this.tableNameBinding = new HashMap();
/*  170 */     this.columnNameBindingPerTable = new HashMap();
/*  171 */     this.namingStrategy = DefaultNamingStrategy.INSTANCE;
/*      */   }
/*      */   
/*  174 */   private transient Mapping mapping = buildMapping();
/*      */   
/*      */   protected Configuration(SettingsFactory settingsFactory) {
/*  177 */     this.settingsFactory = settingsFactory;
/*  178 */     reset();
/*      */   }
/*      */   
/*      */   public Configuration() {
/*  182 */     this(new SettingsFactory());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Iterator getClassMappings()
/*      */   {
/*  189 */     return this.classes.values().iterator();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Iterator getCollectionMappings()
/*      */   {
/*  196 */     return this.collections.values().iterator();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Iterator getTableMappings()
/*      */   {
/*  203 */     return this.tables.values().iterator();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public PersistentClass getClassMapping(String persistentClass)
/*      */   {
/*  210 */     return (PersistentClass)this.classes.get(persistentClass);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public org.hibernate.mapping.Collection getCollectionMapping(String role)
/*      */   {
/*  220 */     return (org.hibernate.mapping.Collection)this.collections.get(role);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEntityResolver(EntityResolver entityResolver)
/*      */   {
/*  231 */     this.entityResolver = entityResolver;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration addFile(String xmlFile)
/*      */     throws MappingException
/*      */   {
/*  240 */     log.info("Reading mappings from file: " + xmlFile);
/*      */     try {
/*  242 */       List errors = new ArrayList();
/*  243 */       org.dom4j.Document doc = this.xmlHelper.createSAXReader(xmlFile, errors, this.entityResolver).read(new File(xmlFile));
/*      */       
/*  245 */       if (errors.size() != 0) {
/*  246 */         throw new MappingException("invalid mapping", (Throwable)errors.get(0));
/*      */       }
/*  248 */       add(doc);
/*  249 */       return this;
/*      */     }
/*      */     catch (Exception e) {
/*  252 */       throw new MappingException("Could not read mapping document from file: " + xmlFile, e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration addFile(File xmlFile)
/*      */     throws MappingException
/*      */   {
/*  265 */     log.info("Reading mappings from file: " + xmlFile.getPath());
/*      */     try {
/*  267 */       addInputStream(new FileInputStream(xmlFile));
/*      */     }
/*      */     catch (Exception e) {
/*  270 */       throw new MappingException("Could not read mapping document from file: " + xmlFile.getPath(), e);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  275 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Configuration addCacheableFile(File xmlFile)
/*      */     throws MappingException
/*      */   {
/*      */     try
/*      */     {
/*  285 */       File lazyfile = new File(xmlFile.getAbsolutePath() + ".bin");
/*  286 */       org.dom4j.Document doc = null;
/*  287 */       List errors = new ArrayList();
/*      */       
/*  289 */       boolean useCachedFile = (xmlFile.exists()) && (lazyfile.exists()) && (xmlFile.lastModified() < lazyfile.lastModified());
/*      */       
/*      */ 
/*      */ 
/*  293 */       if (useCachedFile) {
/*      */         try {
/*  295 */           log.info("Reading mappings from cache file: " + lazyfile);
/*  296 */           doc = (org.dom4j.Document)SerializationHelper.deserialize(new FileInputStream(lazyfile));
/*      */         }
/*      */         catch (SerializationException e) {
/*  299 */           log.warn("Could not deserialize cache file: " + lazyfile.getPath(), e);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  304 */       if (doc == null) {
/*  305 */         log.info("Reading mappings from file: " + xmlFile);
/*  306 */         doc = this.xmlHelper.createSAXReader(xmlFile.getAbsolutePath(), errors, this.entityResolver).read(xmlFile);
/*      */         try
/*      */         {
/*  309 */           log.debug("Writing cache file for: " + xmlFile + " to: " + lazyfile);
/*  310 */           SerializationHelper.serialize((Serializable)doc, new FileOutputStream(lazyfile));
/*      */         }
/*      */         catch (SerializationException e) {
/*  313 */           log.warn("Could not write cached file: " + lazyfile, e);
/*      */         }
/*      */       }
/*      */       
/*  317 */       if (errors.size() != 0) {
/*  318 */         throw new MappingException("invalid mapping", (Throwable)errors.get(0));
/*      */       }
/*  320 */       add(doc);
/*  321 */       return this;
/*      */     }
/*      */     catch (Exception e) {
/*  324 */       throw new MappingException("Could not read mapping document from file: " + xmlFile, e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Configuration addCacheableFile(String xmlFile)
/*      */     throws MappingException
/*      */   {
/*  332 */     return addCacheableFile(new File(xmlFile));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration addXML(String xml)
/*      */     throws MappingException
/*      */   {
/*  342 */     if (log.isDebugEnabled()) log.debug("Mapping XML:\n" + xml);
/*      */     try {
/*  344 */       List errors = new ArrayList();
/*  345 */       org.dom4j.Document doc = this.xmlHelper.createSAXReader("XML String", errors, this.entityResolver).read(new StringReader(xml));
/*      */       
/*  347 */       if (errors.size() != 0) {
/*  348 */         throw new MappingException("invalid mapping", (Throwable)errors.get(0));
/*      */       }
/*  350 */       add(doc);
/*      */     }
/*      */     catch (DocumentException e) {
/*  353 */       throw new MappingException("Could not parse mapping document in XML string", e);
/*      */     }
/*  355 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration addURL(URL url)
/*      */     throws MappingException
/*      */   {
/*  364 */     if (log.isDebugEnabled()) log.debug("Reading mapping document from URL:" + url);
/*      */     try {
/*  366 */       addInputStream(url.openStream());
/*      */     }
/*      */     catch (Exception e) {
/*  369 */       throw new MappingException("Could not read mapping document from URL: " + url, e);
/*      */     }
/*  371 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration addDocument(org.w3c.dom.Document doc)
/*      */     throws MappingException
/*      */   {
/*  380 */     if (log.isDebugEnabled()) log.debug("Mapping document:\n" + doc);
/*  381 */     add(this.xmlHelper.createDOMReader().read(doc));
/*  382 */     return this;
/*      */   }
/*      */   
/*      */   protected void add(org.dom4j.Document doc) throws MappingException {
/*  386 */     HbmBinder.bindRoot(doc, createMappings(), CollectionHelper.EMPTY_MAP);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Mappings createMappings()
/*      */   {
/*  394 */     return new Mappings(this.classes, this.collections, this.tables, this.namedQueries, this.namedSqlQueries, this.sqlResultSetMappings, this.imports, this.secondPasses, this.propertyReferences, this.namingStrategy, this.typeDefs, this.filterDefinitions, this.extendsQueue, this.auxiliaryDatabaseObjects, this.tableNameBinding, this.columnNameBindingPerTable);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration addInputStream(InputStream xmlInputStream)
/*      */     throws MappingException
/*      */   {
/*      */     try
/*      */     {
/*  421 */       List errors = new ArrayList();
/*  422 */       org.dom4j.Document doc = this.xmlHelper.createSAXReader("XML InputStream", errors, this.entityResolver).read(new InputSource(xmlInputStream));
/*      */       
/*  424 */       if (errors.size() != 0) {
/*  425 */         throw new MappingException("invalid mapping", (Throwable)errors.get(0));
/*      */       }
/*  427 */       add(doc);
/*  428 */       return this;
/*      */     }
/*      */     catch (DocumentException e) {
/*  431 */       throw new MappingException("Could not parse mapping document in input stream", e);
/*      */     }
/*      */     finally {
/*      */       try {
/*  435 */         xmlInputStream.close();
/*      */       }
/*      */       catch (IOException ioe) {
/*  438 */         log.warn("Could not close input stream", ioe);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration addResource(String path, ClassLoader classLoader)
/*      */     throws MappingException
/*      */   {
/*  450 */     log.info("Reading mappings from resource: " + path);
/*  451 */     InputStream rsrc = classLoader.getResourceAsStream(path);
/*  452 */     if (rsrc == null) {
/*  453 */       throw new MappingException("Resource: " + path + " not found");
/*      */     }
/*      */     try {
/*  456 */       return addInputStream(rsrc);
/*      */     }
/*      */     catch (MappingException me) {
/*  459 */       throw new MappingException("Could not read mappings from resource: " + path, me);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration addResource(String path)
/*      */     throws MappingException
/*      */   {
/*  469 */     log.info("Reading mappings from resource: " + path);
/*  470 */     ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
/*  471 */     InputStream rsrc = null;
/*  472 */     if (contextClassLoader != null) {
/*  473 */       rsrc = contextClassLoader.getResourceAsStream(path);
/*      */     }
/*  475 */     if (rsrc == null) {
/*  476 */       rsrc = Environment.class.getClassLoader().getResourceAsStream(path);
/*      */     }
/*  478 */     if (rsrc == null) {
/*  479 */       throw new MappingException("Resource: " + path + " not found");
/*      */     }
/*      */     try {
/*  482 */       return addInputStream(rsrc);
/*      */     }
/*      */     catch (MappingException me) {
/*  485 */       throw new MappingException("Could not read mappings from resource: " + path, me);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration addClass(Class persistentClass)
/*      */     throws MappingException
/*      */   {
/*  496 */     String fileName = persistentClass.getName().replace('.', '/') + ".hbm.xml";
/*  497 */     log.info("Reading mappings from resource: " + fileName);
/*  498 */     InputStream rsrc = persistentClass.getClassLoader().getResourceAsStream(fileName);
/*  499 */     if (rsrc == null) {
/*  500 */       throw new MappingException("Resource: " + fileName + " not found");
/*      */     }
/*      */     try {
/*  503 */       return addInputStream(rsrc);
/*      */     }
/*      */     catch (MappingException me) {
/*  506 */       throw new MappingException("Could not read mappings from resource: " + fileName, me);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration addJar(File jar)
/*      */     throws MappingException
/*      */   {
/*  520 */     log.info("Searching for mapping documents in jar: " + jar.getName());
/*      */     
/*  522 */     JarFile jarFile = null;
/*      */     try
/*      */     {
/*      */       try {
/*  526 */         jarFile = new JarFile(jar);
/*      */       }
/*      */       catch (IOException ioe) {
/*  529 */         throw new MappingException("Could not read mapping documents from jar: " + jar.getName(), ioe);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  535 */       Enumeration jarEntries = jarFile.entries();
/*  536 */       while (jarEntries.hasMoreElements())
/*      */       {
/*  538 */         ZipEntry ze = (ZipEntry)jarEntries.nextElement();
/*      */         
/*  540 */         if (ze.getName().endsWith(".hbm.xml")) {
/*  541 */           log.info("Found mapping document in jar: " + ze.getName());
/*      */           try {
/*  543 */             addInputStream(jarFile.getInputStream(ze));
/*      */           }
/*      */           catch (Exception e) {
/*  546 */             throw new MappingException("Could not read mapping documents from jar: " + jar.getName(), e);
/*      */           }
/*      */           
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/*  558 */         if (jarFile != null) jarFile.close();
/*      */       }
/*      */       catch (IOException ioe) {
/*  561 */         log.error("could not close jar", ioe);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  566 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration addDirectory(File dir)
/*      */     throws MappingException
/*      */   {
/*  577 */     File[] files = dir.listFiles();
/*  578 */     for (int i = 0; i < files.length; i++) {
/*  579 */       if (files[i].isDirectory()) {
/*  580 */         addDirectory(files[i]);
/*      */       }
/*  582 */       else if (files[i].getName().endsWith(".hbm.xml")) {
/*  583 */         addFile(files[i]);
/*      */       }
/*      */     }
/*  586 */     return this;
/*      */   }
/*      */   
/*      */   private Iterator iterateGenerators(Dialect dialect) throws MappingException
/*      */   {
/*  591 */     TreeMap generators = new TreeMap();
/*  592 */     String defaultCatalog = this.properties.getProperty("hibernate.default_catalog");
/*  593 */     String defaultSchema = this.properties.getProperty("hibernate.default_schema");
/*      */     
/*  595 */     Iterator iter = this.classes.values().iterator();
/*  596 */     while (iter.hasNext()) {
/*  597 */       PersistentClass pc = (PersistentClass)iter.next();
/*      */       
/*  599 */       if (!pc.isInherited())
/*      */       {
/*  601 */         IdentifierGenerator ig = pc.getIdentifier().createIdentifierGenerator(dialect, defaultCatalog, defaultSchema, (RootClass)pc);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  609 */         if ((ig instanceof PersistentIdentifierGenerator)) {
/*  610 */           generators.put(((PersistentIdentifierGenerator)ig).generatorKey(), ig);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  616 */     iter = this.collections.values().iterator();
/*  617 */     while (iter.hasNext()) {
/*  618 */       org.hibernate.mapping.Collection collection = (org.hibernate.mapping.Collection)iter.next();
/*      */       
/*  620 */       if (collection.isIdentified())
/*      */       {
/*  622 */         IdentifierGenerator ig = ((IdentifierCollection)collection).getIdentifier().createIdentifierGenerator(dialect, defaultCatalog, defaultSchema, null);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  630 */         if ((ig instanceof PersistentIdentifierGenerator)) {
/*  631 */           generators.put(((PersistentIdentifierGenerator)ig).generatorKey(), ig);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  637 */     return generators.values().iterator();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] generateDropSchemaScript(Dialect dialect)
/*      */     throws HibernateException
/*      */   {
/*  647 */     secondPassCompile();
/*      */     
/*  649 */     String defaultCatalog = this.properties.getProperty("hibernate.default_catalog");
/*  650 */     String defaultSchema = this.properties.getProperty("hibernate.default_schema");
/*      */     
/*  652 */     ArrayList script = new ArrayList(50);
/*      */     
/*      */ 
/*  655 */     ListIterator itr = this.auxiliaryDatabaseObjects.listIterator(this.auxiliaryDatabaseObjects.size());
/*  656 */     while (itr.hasPrevious()) {
/*  657 */       AuxiliaryDatabaseObject object = (AuxiliaryDatabaseObject)itr.previous();
/*  658 */       if (object.appliesToDialect(dialect)) {
/*  659 */         script.add(object.sqlDropString(dialect, defaultCatalog, defaultSchema));
/*      */       }
/*      */     }
/*      */     
/*  663 */     if (dialect.dropConstraints()) {
/*  664 */       Iterator iter = getTableMappings();
/*  665 */       while (iter.hasNext()) {
/*  666 */         Table table = (Table)iter.next();
/*  667 */         if (table.isPhysicalTable()) {
/*  668 */           Iterator subIter = table.getForeignKeyIterator();
/*  669 */           while (subIter.hasNext()) {
/*  670 */             ForeignKey fk = (ForeignKey)subIter.next();
/*  671 */             if (fk.isPhysicalConstraint()) {
/*  672 */               script.add(fk.sqlDropString(dialect, defaultCatalog, defaultSchema));
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  686 */     Iterator iter = getTableMappings();
/*  687 */     while (iter.hasNext())
/*      */     {
/*  689 */       Table table = (Table)iter.next();
/*  690 */       if (table.isPhysicalTable())
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  700 */         script.add(table.sqlDropString(dialect, defaultCatalog, defaultSchema));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  712 */     iter = iterateGenerators(dialect);
/*  713 */     while (iter.hasNext()) {
/*  714 */       String[] lines = ((PersistentIdentifierGenerator)iter.next()).sqlDropStrings(dialect);
/*  715 */       for (int i = 0; i < lines.length; i++) {
/*  716 */         script.add(lines[i]);
/*      */       }
/*      */     }
/*      */     
/*  720 */     return ArrayHelper.toStringArray(script);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] generateSchemaCreationScript(Dialect dialect)
/*      */     throws HibernateException
/*      */   {
/*  729 */     secondPassCompile();
/*      */     
/*  731 */     ArrayList script = new ArrayList(50);
/*  732 */     String defaultCatalog = this.properties.getProperty("hibernate.default_catalog");
/*  733 */     String defaultSchema = this.properties.getProperty("hibernate.default_schema");
/*      */     
/*  735 */     Iterator iter = getTableMappings();
/*  736 */     while (iter.hasNext()) {
/*  737 */       Table table = (Table)iter.next();
/*  738 */       if (table.isPhysicalTable()) {
/*  739 */         script.add(table.sqlCreateString(dialect, this.mapping, defaultCatalog, defaultSchema));
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  747 */         Iterator comments = table.sqlCommentStrings(dialect, defaultCatalog, defaultSchema);
/*  748 */         while (comments.hasNext()) {
/*  749 */           script.add(comments.next());
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  754 */     iter = getTableMappings();
/*  755 */     while (iter.hasNext()) {
/*  756 */       Table table = (Table)iter.next();
/*  757 */       if (table.isPhysicalTable())
/*      */       {
/*  759 */         if (!dialect.supportsUniqueConstraintInCreateAlterTable()) {
/*  760 */           Iterator subIter = table.getUniqueKeyIterator();
/*  761 */           while (subIter.hasNext()) {
/*  762 */             UniqueKey uk = (UniqueKey)subIter.next();
/*  763 */             script.add(uk.sqlCreateString(dialect, this.mapping, defaultCatalog, defaultSchema));
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*  768 */         Iterator subIter = table.getIndexIterator();
/*  769 */         while (subIter.hasNext()) {
/*  770 */           Index index = (Index)subIter.next();
/*  771 */           script.add(index.sqlCreateString(dialect, this.mapping, defaultCatalog, defaultSchema));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  781 */         if (dialect.hasAlterTable()) {
/*  782 */           subIter = table.getForeignKeyIterator();
/*  783 */           while (subIter.hasNext()) {
/*  784 */             ForeignKey fk = (ForeignKey)subIter.next();
/*  785 */             if (fk.isPhysicalConstraint()) {
/*  786 */               script.add(fk.sqlCreateString(dialect, this.mapping, defaultCatalog, defaultSchema));
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  800 */     iter = iterateGenerators(dialect);
/*  801 */     while (iter.hasNext()) {
/*  802 */       String[] lines = ((PersistentIdentifierGenerator)iter.next()).sqlCreateStrings(dialect);
/*  803 */       for (int i = 0; i < lines.length; i++) {
/*  804 */         script.add(lines[i]);
/*      */       }
/*      */     }
/*      */     
/*  808 */     Iterator itr = this.auxiliaryDatabaseObjects.iterator();
/*  809 */     while (itr.hasNext()) {
/*  810 */       AuxiliaryDatabaseObject object = (AuxiliaryDatabaseObject)itr.next();
/*  811 */       if (object.appliesToDialect(dialect)) {
/*  812 */         script.add(object.sqlCreateString(dialect, this.mapping, defaultCatalog, defaultSchema));
/*      */       }
/*      */     }
/*      */     
/*  816 */     return ArrayHelper.toStringArray(script);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] generateSchemaUpdateScript(Dialect dialect, DatabaseMetadata databaseMetadata)
/*      */     throws HibernateException
/*      */   {
/*  826 */     secondPassCompile();
/*      */     
/*  828 */     String defaultCatalog = this.properties.getProperty("hibernate.default_catalog");
/*  829 */     String defaultSchema = this.properties.getProperty("hibernate.default_schema");
/*      */     
/*  831 */     ArrayList script = new ArrayList(50);
/*      */     
/*  833 */     Iterator iter = getTableMappings();
/*  834 */     while (iter.hasNext()) {
/*  835 */       Table table = (Table)iter.next();
/*  836 */       if (table.isPhysicalTable())
/*      */       {
/*  838 */         TableMetadata tableInfo = databaseMetadata.getTableMetadata(table.getName(), table.getSchema(), table.getCatalog());
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  843 */         if (tableInfo == null) {
/*  844 */           script.add(table.sqlCreateString(dialect, this.mapping, defaultCatalog, defaultSchema));
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  854 */           Iterator subiter = table.sqlAlterStrings(dialect, this.mapping, tableInfo, defaultCatalog, defaultSchema);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  861 */           while (subiter.hasNext()) { script.add(subiter.next());
/*      */           }
/*      */         }
/*  864 */         Iterator comments = table.sqlCommentStrings(dialect, defaultCatalog, defaultSchema);
/*  865 */         while (comments.hasNext()) {
/*  866 */           script.add(comments.next());
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  872 */     iter = getTableMappings();
/*  873 */     while (iter.hasNext()) {
/*  874 */       Table table = (Table)iter.next();
/*  875 */       if (table.isPhysicalTable())
/*      */       {
/*  877 */         TableMetadata tableInfo = databaseMetadata.getTableMetadata(table.getName(), table.getSchema(), table.getCatalog());
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  883 */         if (dialect.hasAlterTable()) {
/*  884 */           Iterator subIter = table.getForeignKeyIterator();
/*  885 */           while (subIter.hasNext()) {
/*  886 */             ForeignKey fk = (ForeignKey)subIter.next();
/*  887 */             if (fk.isPhysicalConstraint()) {
/*  888 */               boolean create = (tableInfo == null) || ((tableInfo.getForeignKeyMetadata(fk.getName()) == null) && ((!(dialect instanceof MySQLDialect)) || (tableInfo.getIndexMetadata(fk.getName()) == null)));
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  895 */               if (create) {
/*  896 */                 script.add(fk.sqlCreateString(dialect, this.mapping, defaultCatalog, defaultSchema));
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  931 */     iter = iterateGenerators(dialect);
/*  932 */     while (iter.hasNext()) {
/*  933 */       PersistentIdentifierGenerator generator = (PersistentIdentifierGenerator)iter.next();
/*  934 */       Object key = generator.generatorKey();
/*  935 */       if ((!databaseMetadata.isSequence(key)) && (!databaseMetadata.isTable(key))) {
/*  936 */         String[] lines = generator.sqlCreateStrings(dialect);
/*  937 */         for (int i = 0; i < lines.length; i++) {
/*  938 */           script.add(lines[i]);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  943 */     return ArrayHelper.toStringArray(script);
/*      */   }
/*      */   
/*      */   public void validateSchema(Dialect dialect, DatabaseMetadata databaseMetadata) throws HibernateException
/*      */   {
/*  948 */     secondPassCompile();
/*      */     
/*  950 */     Iterator iter = getTableMappings();
/*  951 */     while (iter.hasNext()) {
/*  952 */       Table table = (Table)iter.next();
/*  953 */       if (table.isPhysicalTable())
/*      */       {
/*  955 */         TableMetadata tableInfo = databaseMetadata.getTableMetadata(table.getName(), table.getSchema(), table.getCatalog());
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  961 */         if (tableInfo == null) {
/*  962 */           throw new HibernateException("Missing table: " + table.getName());
/*      */         }
/*      */         
/*  965 */         table.validateColumns(dialect, this.mapping, tableInfo);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  971 */     iter = iterateGenerators(dialect);
/*  972 */     while (iter.hasNext()) {
/*  973 */       PersistentIdentifierGenerator generator = (PersistentIdentifierGenerator)iter.next();
/*  974 */       Object key = generator.generatorKey();
/*  975 */       if ((!databaseMetadata.isSequence(key)) && (!databaseMetadata.isTable(key))) {
/*  976 */         throw new HibernateException("Missing sequence or table: " + key);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void validate() throws MappingException {
/*  982 */     Iterator iter = this.classes.values().iterator();
/*  983 */     while (iter.hasNext()) {
/*  984 */       ((PersistentClass)iter.next()).validate(this.mapping);
/*      */     }
/*  986 */     iter = this.collections.values().iterator();
/*  987 */     while (iter.hasNext()) {
/*  988 */       ((org.hibernate.mapping.Collection)iter.next()).validate(this.mapping);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void buildMappings()
/*      */   {
/*  997 */     secondPassCompile();
/*      */   }
/*      */   
/*      */   protected void secondPassCompile() throws MappingException
/*      */   {
/* 1002 */     log.debug("processing extends queue");
/*      */     
/* 1004 */     processExtendsQueue();
/*      */     
/* 1006 */     log.debug("processing collection mappings");
/*      */     
/* 1008 */     Iterator iter = this.secondPasses.iterator();
/* 1009 */     while (iter.hasNext()) {
/* 1010 */       SecondPass sp = (SecondPass)iter.next();
/* 1011 */       if (!(sp instanceof QuerySecondPass)) {
/* 1012 */         sp.doSecondPass(this.classes, CollectionHelper.EMPTY_MAP);
/* 1013 */         iter.remove();
/*      */       }
/*      */     }
/*      */     
/* 1017 */     log.debug("processing native query and ResultSetMapping mappings");
/* 1018 */     iter = this.secondPasses.iterator();
/* 1019 */     while (iter.hasNext()) {
/* 1020 */       SecondPass sp = (SecondPass)iter.next();
/* 1021 */       sp.doSecondPass(this.classes, CollectionHelper.EMPTY_MAP);
/* 1022 */       iter.remove();
/*      */     }
/*      */     
/* 1025 */     log.debug("processing association property references");
/*      */     
/* 1027 */     iter = this.propertyReferences.iterator();
/* 1028 */     while (iter.hasNext()) {
/* 1029 */       Mappings.PropertyReference upr = (Mappings.PropertyReference)iter.next();
/*      */       
/* 1031 */       PersistentClass clazz = getClassMapping(upr.referencedClass);
/* 1032 */       if (clazz == null) {
/* 1033 */         throw new MappingException("property-ref to unmapped class: " + upr.referencedClass);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1039 */       Property prop = clazz.getReferencedProperty(upr.propertyName);
/* 1040 */       if (upr.unique) {
/* 1041 */         ((SimpleValue)prop.getValue()).setAlternateUniqueKey(true);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1047 */     log.debug("processing foreign key constraints");
/*      */     
/* 1049 */     iter = getTableMappings();
/* 1050 */     Set done = new HashSet();
/* 1051 */     while (iter.hasNext()) {
/* 1052 */       secondPassCompileForeignKeys((Table)iter.next(), done);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void processExtendsQueue()
/*      */   {
/* 1065 */     org.dom4j.Document document = findPossibleExtends();
/* 1066 */     while (document != null) {
/* 1067 */       add(document);
/* 1068 */       document = findPossibleExtends();
/*      */     }
/*      */     
/* 1071 */     if (this.extendsQueue.size() > 0)
/*      */     {
/* 1073 */       Iterator iterator = this.extendsQueue.keySet().iterator();
/* 1074 */       StringBuffer buf = new StringBuffer("Following superclasses referenced in extends not found: ");
/* 1075 */       while (iterator.hasNext()) {
/* 1076 */         ExtendsQueueEntry entry = (ExtendsQueueEntry)iterator.next();
/* 1077 */         buf.append(entry.getExplicitName());
/* 1078 */         if (entry.getMappingPackage() != null) {
/* 1079 */           buf.append("[").append(entry.getMappingPackage()).append("]");
/*      */         }
/* 1081 */         if (iterator.hasNext()) {
/* 1082 */           buf.append(",");
/*      */         }
/*      */       }
/* 1085 */       throw new MappingException(buf.toString());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected org.dom4j.Document findPossibleExtends()
/*      */   {
/* 1094 */     Iterator iter = this.extendsQueue.keySet().iterator();
/* 1095 */     while (iter.hasNext()) {
/* 1096 */       ExtendsQueueEntry entry = (ExtendsQueueEntry)iter.next();
/* 1097 */       if (getClassMapping(entry.getExplicitName()) != null)
/*      */       {
/* 1099 */         iter.remove();
/* 1100 */         return entry.getDocument();
/*      */       }
/* 1102 */       if (getClassMapping(HbmBinder.getClassName(entry.getExplicitName(), entry.getMappingPackage())) != null)
/*      */       {
/* 1104 */         iter.remove();
/* 1105 */         return entry.getDocument();
/*      */       }
/*      */     }
/* 1108 */     return null;
/*      */   }
/*      */   
/*      */   protected void secondPassCompileForeignKeys(Table table, Set done) throws MappingException
/*      */   {
/* 1113 */     table.createForeignKeys();
/*      */     
/* 1115 */     Iterator iter = table.getForeignKeyIterator();
/* 1116 */     while (iter.hasNext())
/*      */     {
/* 1118 */       ForeignKey fk = (ForeignKey)iter.next();
/* 1119 */       if (!done.contains(fk)) {
/* 1120 */         done.add(fk);
/* 1121 */         String referencedEntityName = fk.getReferencedEntityName();
/* 1122 */         if (referencedEntityName == null) {
/* 1123 */           throw new MappingException("An association from the table " + fk.getTable().getName() + " does not specify the referenced entity");
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1129 */         if (log.isDebugEnabled()) {
/* 1130 */           log.debug("resolving reference to class: " + referencedEntityName);
/*      */         }
/* 1132 */         PersistentClass referencedClass = (PersistentClass)this.classes.get(referencedEntityName);
/* 1133 */         if (referencedClass == null) {
/* 1134 */           throw new MappingException("An association from the table " + fk.getTable().getName() + " refers to an unmapped class: " + referencedEntityName);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1141 */         if (referencedClass.isJoinedSubclass()) {
/* 1142 */           secondPassCompileForeignKeys(referencedClass.getSuperclass().getTable(), done);
/*      */         }
/* 1144 */         fk.setReferencedTable(referencedClass.getTable());
/* 1145 */         fk.alignColumns();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Map getNamedQueries()
/*      */   {
/* 1154 */     return this.namedQueries;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SessionFactory buildSessionFactory()
/*      */     throws HibernateException
/*      */   {
/* 1167 */     log.debug("Preparing to build session factory with filters : " + this.filterDefinitions);
/* 1168 */     secondPassCompile();
/* 1169 */     validate();
/* 1170 */     Environment.verifyProperties(this.properties);
/* 1171 */     Properties copy = new Properties();
/* 1172 */     copy.putAll(this.properties);
/* 1173 */     PropertiesHelper.resolvePlaceHolders(copy);
/* 1174 */     Settings settings = buildSettings(copy);
/*      */     
/* 1176 */     return new SessionFactoryImpl(this, this.mapping, settings, getInitializedEventListeners());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private EventListeners getInitializedEventListeners()
/*      */   {
/* 1185 */     EventListeners result = (EventListeners)this.eventListeners.shallowCopy();
/* 1186 */     result.initializeListeners(this);
/* 1187 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Interceptor getInterceptor()
/*      */   {
/* 1194 */     return this.interceptor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Properties getProperties()
/*      */   {
/* 1201 */     return this.properties;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Configuration setInterceptor(Interceptor interceptor)
/*      */   {
/* 1208 */     this.interceptor = interceptor;
/* 1209 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Configuration setProperties(Properties properties)
/*      */   {
/* 1216 */     this.properties = properties;
/* 1217 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Configuration addProperties(Properties extraProperties)
/*      */   {
/* 1224 */     this.properties.putAll(extraProperties);
/* 1225 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration mergeProperties(Properties properties)
/*      */   {
/* 1237 */     Iterator itr = properties.entrySet().iterator();
/* 1238 */     while (itr.hasNext()) {
/* 1239 */       Map.Entry entry = (Map.Entry)itr.next();
/* 1240 */       if (!this.properties.containsKey(entry.getKey()))
/*      */       {
/*      */ 
/* 1243 */         this.properties.setProperty((String)entry.getKey(), (String)entry.getValue()); }
/*      */     }
/* 1245 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Configuration setProperty(String propertyName, String value)
/*      */   {
/* 1252 */     this.properties.setProperty(propertyName, value);
/* 1253 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getProperty(String propertyName)
/*      */   {
/* 1260 */     return this.properties.getProperty(propertyName);
/*      */   }
/*      */   
/*      */   private void addProperties(Element parent) {
/* 1264 */     Iterator iter = parent.elementIterator("property");
/* 1265 */     while (iter.hasNext()) {
/* 1266 */       Element node = (Element)iter.next();
/* 1267 */       String name = node.attributeValue("name");
/* 1268 */       String value = node.getText().trim();
/* 1269 */       log.debug(name + "=" + value);
/* 1270 */       this.properties.setProperty(name, value);
/* 1271 */       if (!name.startsWith("hibernate")) {
/* 1272 */         this.properties.setProperty("hibernate." + name, value);
/*      */       }
/*      */     }
/* 1275 */     Environment.verifyProperties(this.properties);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputStream getConfigurationInputStream(String resource)
/*      */     throws HibernateException
/*      */   {
/* 1285 */     log.info("Configuration resource: " + resource);
/*      */     
/* 1287 */     return ConfigHelper.getResourceAsStream(resource);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration configure()
/*      */     throws HibernateException
/*      */   {
/* 1296 */     configure("/hibernate.cfg.xml");
/* 1297 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration configure(String resource)
/*      */     throws HibernateException
/*      */   {
/* 1308 */     log.info("configuring from resource: " + resource);
/* 1309 */     InputStream stream = getConfigurationInputStream(resource);
/* 1310 */     return doConfigure(stream, resource);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration configure(URL url)
/*      */     throws HibernateException
/*      */   {
/* 1323 */     log.info("configuring from url: " + url.toString());
/*      */     try {
/* 1325 */       return doConfigure(url.openStream(), url.toString());
/*      */     }
/*      */     catch (IOException ioe) {
/* 1328 */       throw new HibernateException("could not configure from URL: " + url, ioe);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration configure(File configFile)
/*      */     throws HibernateException
/*      */   {
/* 1342 */     log.info("configuring from file: " + configFile.getName());
/*      */     try {
/* 1344 */       return doConfigure(new FileInputStream(configFile), configFile.toString());
/*      */     }
/*      */     catch (FileNotFoundException fnfe) {
/* 1347 */       throw new HibernateException("could not find file: " + configFile, fnfe);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Configuration doConfigure(InputStream stream, String resourceName)
/*      */     throws HibernateException
/*      */   {
/*      */     try
/*      */     {
/* 1365 */       List errors = new ArrayList();
/* 1366 */       org.dom4j.Document doc = this.xmlHelper.createSAXReader(resourceName, errors, this.entityResolver).read(new InputSource(stream));
/*      */       
/* 1368 */       if (errors.size() != 0) {
/* 1369 */         throw new MappingException("invalid configuration", (Throwable)errors.get(0));
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     catch (DocumentException e)
/*      */     {
/* 1376 */       throw new HibernateException("Could not parse configuration: " + resourceName, e);
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/* 1383 */         stream.close();
/*      */       }
/*      */       catch (IOException ioe) {
/* 1386 */         log.warn("could not close input stream for: " + resourceName, ioe);
/*      */       }
/*      */     }
/*      */     org.dom4j.Document doc;
/* 1390 */     return doConfigure(doc);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration configure(org.w3c.dom.Document document)
/*      */     throws HibernateException
/*      */   {
/* 1404 */     log.info("configuring from XML document");
/* 1405 */     return doConfigure(this.xmlHelper.createDOMReader().read(document));
/*      */   }
/*      */   
/*      */   protected Configuration doConfigure(org.dom4j.Document doc) throws HibernateException
/*      */   {
/* 1410 */     Element sfNode = doc.getRootElement().element("session-factory");
/* 1411 */     String name = sfNode.attributeValue("name");
/* 1412 */     if (name != null) this.properties.setProperty("hibernate.session_factory_name", name);
/* 1413 */     addProperties(sfNode);
/* 1414 */     parseSessionFactory(sfNode, name);
/*      */     
/* 1416 */     Element secNode = doc.getRootElement().element("security");
/* 1417 */     if (secNode != null) { parseSecurity(secNode);
/*      */     }
/* 1419 */     log.info("Configured SessionFactory: " + name);
/* 1420 */     log.debug("properties: " + this.properties);
/*      */     
/* 1422 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */   private void parseSessionFactory(Element sfNode, String name)
/*      */   {
/* 1428 */     Iterator elements = sfNode.elementIterator();
/* 1429 */     while (elements.hasNext()) {
/* 1430 */       Element subelement = (Element)elements.next();
/* 1431 */       String subelementName = subelement.getName();
/* 1432 */       if ("mapping".equals(subelementName)) {
/* 1433 */         parseMappingElement(subelement, name);
/*      */       }
/* 1435 */       else if ("class-cache".equals(subelementName)) {
/* 1436 */         String className = subelement.attributeValue("class");
/* 1437 */         Attribute regionNode = subelement.attribute("region");
/* 1438 */         String region = regionNode == null ? className : regionNode.getValue();
/* 1439 */         boolean includeLazy = !"non-lazy".equals(subelement.attributeValue("include"));
/* 1440 */         setCacheConcurrencyStrategy(className, subelement.attributeValue("usage"), region, includeLazy);
/*      */       }
/* 1442 */       else if ("collection-cache".equals(subelementName)) {
/* 1443 */         String role = subelement.attributeValue("collection");
/* 1444 */         Attribute regionNode = subelement.attribute("region");
/* 1445 */         String region = regionNode == null ? role : regionNode.getValue();
/* 1446 */         setCollectionCacheConcurrencyStrategy(role, subelement.attributeValue("usage"), region);
/*      */       }
/* 1448 */       else if ("listener".equals(subelementName)) {
/* 1449 */         parseListener(subelement);
/*      */       }
/* 1451 */       else if ("event".equals(subelementName)) {
/* 1452 */         parseEvent(subelement);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected void parseMappingElement(Element subelement, String name) {
/* 1458 */     Attribute rsrc = subelement.attribute("resource");
/* 1459 */     Attribute file = subelement.attribute("file");
/* 1460 */     Attribute jar = subelement.attribute("jar");
/* 1461 */     Attribute pkg = subelement.attribute("package");
/* 1462 */     Attribute clazz = subelement.attribute("class");
/* 1463 */     if (rsrc != null) {
/* 1464 */       log.debug(name + "<-" + rsrc);
/* 1465 */       addResource(rsrc.getValue());
/*      */     }
/* 1467 */     else if (jar != null) {
/* 1468 */       log.debug(name + "<-" + jar);
/* 1469 */       addJar(new File(jar.getValue()));
/*      */     } else {
/* 1471 */       if (pkg != null) {
/* 1472 */         throw new MappingException("An AnnotationConfiguration instance is required to use <mapping package=\"" + pkg.getValue() + "\"/>");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1477 */       if (clazz != null) {
/* 1478 */         throw new MappingException("An AnnotationConfiguration instance is required to use <mapping class=\"" + clazz.getValue() + "\"/>");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1484 */       if (file == null) {
/* 1485 */         throw new MappingException("<mapping> element in configuration specifies no attributes");
/*      */       }
/*      */       
/*      */ 
/* 1489 */       log.debug(name + "<-" + file);
/* 1490 */       addFile(file.getValue());
/*      */     }
/*      */   }
/*      */   
/*      */   private void parseSecurity(Element secNode) {
/* 1495 */     String contextId = secNode.attributeValue("context");
/* 1496 */     setProperty("hibernate.jacc_context_id", contextId);
/* 1497 */     log.info("JACC contextID: " + contextId);
/* 1498 */     JACCConfiguration jcfg = new JACCConfiguration(contextId);
/* 1499 */     Iterator grantElements = secNode.elementIterator();
/* 1500 */     while (grantElements.hasNext()) {
/* 1501 */       Element grantElement = (Element)grantElements.next();
/* 1502 */       String elementName = grantElement.getName();
/* 1503 */       if ("grant".equals(elementName)) {
/* 1504 */         jcfg.addPermission(grantElement.attributeValue("role"), grantElement.attributeValue("entity-name"), grantElement.attributeValue("actions"));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parseEvent(Element element)
/*      */   {
/* 1514 */     String type = element.attributeValue("type");
/* 1515 */     List listeners = element.elements();
/* 1516 */     String[] listenerClasses = new String[listeners.size()];
/* 1517 */     for (int i = 0; i < listeners.size(); i++) {
/* 1518 */       listenerClasses[i] = ((Element)listeners.get(i)).attributeValue("class");
/*      */     }
/* 1520 */     log.debug("Event listeners: " + type + "=" + StringHelper.toString(listenerClasses));
/* 1521 */     setListeners(type, listenerClasses);
/*      */   }
/*      */   
/*      */   private void parseListener(Element element) {
/* 1525 */     String type = element.attributeValue("type");
/* 1526 */     if (type == null) throw new MappingException("No type specified for listener");
/* 1527 */     String impl = element.attributeValue("class");
/* 1528 */     log.debug("Event listener: " + type + "=" + impl);
/* 1529 */     setListeners(type, new String[] { impl });
/*      */   }
/*      */   
/*      */   public void setListeners(String type, String[] listenerClasses) {
/* 1533 */     Object[] listeners = (Object[])Array.newInstance(this.eventListeners.getListenerClassFor(type), listenerClasses.length);
/* 1534 */     for (int i = 0; i < listeners.length; i++) {
/*      */       try {
/* 1536 */         listeners[i] = ReflectHelper.classForName(listenerClasses[i]).newInstance();
/*      */       }
/*      */       catch (Exception e) {
/* 1539 */         throw new MappingException("Unable to instantiate specified event (" + type + ") listener class: " + listenerClasses[i], e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1545 */     setListeners(type, listeners);
/*      */   }
/*      */   
/*      */   public void setListener(String type, Object listener) {
/* 1549 */     if (listener == null) {
/* 1550 */       setListener(type, null);
/*      */     }
/*      */     else {
/* 1553 */       Object[] listeners = (Object[])Array.newInstance(this.eventListeners.getListenerClassFor(type), 1);
/* 1554 */       listeners[0] = listener;
/* 1555 */       setListeners(type, listeners);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setListeners(String type, Object[] listeners) {
/* 1560 */     if ("auto-flush".equals(type)) {
/* 1561 */       if (listeners == null) {
/* 1562 */         this.eventListeners.setAutoFlushEventListeners(new AutoFlushEventListener[0]);
/*      */       }
/*      */       else {
/* 1565 */         this.eventListeners.setAutoFlushEventListeners((AutoFlushEventListener[])listeners);
/*      */       }
/*      */     }
/* 1568 */     else if ("merge".equals(type)) {
/* 1569 */       if (listeners == null) {
/* 1570 */         this.eventListeners.setMergeEventListeners(new MergeEventListener[0]);
/*      */       }
/*      */       else {
/* 1573 */         this.eventListeners.setMergeEventListeners((MergeEventListener[])listeners);
/*      */       }
/*      */     }
/* 1576 */     else if ("create".equals(type)) {
/* 1577 */       if (listeners == null) {
/* 1578 */         this.eventListeners.setPersistEventListeners(new PersistEventListener[0]);
/*      */       }
/*      */       else {
/* 1581 */         this.eventListeners.setPersistEventListeners((PersistEventListener[])listeners);
/*      */       }
/*      */     }
/* 1584 */     else if ("create-onflush".equals(type)) {
/* 1585 */       if (listeners == null) {
/* 1586 */         this.eventListeners.setPersistOnFlushEventListeners(new PersistEventListener[0]);
/*      */       }
/*      */       else {
/* 1589 */         this.eventListeners.setPersistOnFlushEventListeners((PersistEventListener[])listeners);
/*      */       }
/*      */     }
/* 1592 */     else if ("delete".equals(type)) {
/* 1593 */       if (listeners == null) {
/* 1594 */         this.eventListeners.setDeleteEventListeners(new DeleteEventListener[0]);
/*      */       }
/*      */       else {
/* 1597 */         this.eventListeners.setDeleteEventListeners((DeleteEventListener[])listeners);
/*      */       }
/*      */     }
/* 1600 */     else if ("dirty-check".equals(type)) {
/* 1601 */       if (listeners == null) {
/* 1602 */         this.eventListeners.setDirtyCheckEventListeners(new DirtyCheckEventListener[0]);
/*      */       }
/*      */       else {
/* 1605 */         this.eventListeners.setDirtyCheckEventListeners((DirtyCheckEventListener[])listeners);
/*      */       }
/*      */     }
/* 1608 */     else if ("evict".equals(type)) {
/* 1609 */       if (listeners == null) {
/* 1610 */         this.eventListeners.setEvictEventListeners(new EvictEventListener[0]);
/*      */       }
/*      */       else {
/* 1613 */         this.eventListeners.setEvictEventListeners((EvictEventListener[])listeners);
/*      */       }
/*      */     }
/* 1616 */     else if ("flush".equals(type)) {
/* 1617 */       if (listeners == null) {
/* 1618 */         this.eventListeners.setFlushEventListeners(new FlushEventListener[0]);
/*      */       }
/*      */       else {
/* 1621 */         this.eventListeners.setFlushEventListeners((FlushEventListener[])listeners);
/*      */       }
/*      */     }
/* 1624 */     else if ("flush-entity".equals(type)) {
/* 1625 */       if (listeners == null) {
/* 1626 */         this.eventListeners.setFlushEntityEventListeners(new FlushEntityEventListener[0]);
/*      */       }
/*      */       else {
/* 1629 */         this.eventListeners.setFlushEntityEventListeners((FlushEntityEventListener[])listeners);
/*      */       }
/*      */     }
/* 1632 */     else if ("load".equals(type)) {
/* 1633 */       if (listeners == null) {
/* 1634 */         this.eventListeners.setLoadEventListeners(new LoadEventListener[0]);
/*      */       }
/*      */       else {
/* 1637 */         this.eventListeners.setLoadEventListeners((LoadEventListener[])listeners);
/*      */       }
/*      */     }
/* 1640 */     else if ("load-collection".equals(type)) {
/* 1641 */       if (listeners == null) {
/* 1642 */         this.eventListeners.setInitializeCollectionEventListeners(new InitializeCollectionEventListener[0]);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1647 */         this.eventListeners.setInitializeCollectionEventListeners((InitializeCollectionEventListener[])listeners);
/*      */       }
/*      */       
/*      */ 
/*      */     }
/* 1652 */     else if ("lock".equals(type)) {
/* 1653 */       if (listeners == null) {
/* 1654 */         this.eventListeners.setLockEventListeners(new LockEventListener[0]);
/*      */       }
/*      */       else {
/* 1657 */         this.eventListeners.setLockEventListeners((LockEventListener[])listeners);
/*      */       }
/*      */     }
/* 1660 */     else if ("refresh".equals(type)) {
/* 1661 */       if (listeners == null) {
/* 1662 */         this.eventListeners.setRefreshEventListeners(new RefreshEventListener[0]);
/*      */       }
/*      */       else {
/* 1665 */         this.eventListeners.setRefreshEventListeners((RefreshEventListener[])listeners);
/*      */       }
/*      */     }
/* 1668 */     else if ("replicate".equals(type)) {
/* 1669 */       if (listeners == null) {
/* 1670 */         this.eventListeners.setReplicateEventListeners(new ReplicateEventListener[0]);
/*      */       }
/*      */       else {
/* 1673 */         this.eventListeners.setReplicateEventListeners((ReplicateEventListener[])listeners);
/*      */       }
/*      */     }
/* 1676 */     else if ("save-update".equals(type)) {
/* 1677 */       if (listeners == null) {
/* 1678 */         this.eventListeners.setSaveOrUpdateEventListeners(new SaveOrUpdateEventListener[0]);
/*      */       }
/*      */       else {
/* 1681 */         this.eventListeners.setSaveOrUpdateEventListeners((SaveOrUpdateEventListener[])listeners);
/*      */       }
/*      */     }
/* 1684 */     else if ("save".equals(type)) {
/* 1685 */       if (listeners == null) {
/* 1686 */         this.eventListeners.setSaveEventListeners(new SaveOrUpdateEventListener[0]);
/*      */       }
/*      */       else {
/* 1689 */         this.eventListeners.setSaveEventListeners((SaveOrUpdateEventListener[])listeners);
/*      */       }
/*      */     }
/* 1692 */     else if ("update".equals(type)) {
/* 1693 */       if (listeners == null) {
/* 1694 */         this.eventListeners.setUpdateEventListeners(new SaveOrUpdateEventListener[0]);
/*      */       }
/*      */       else {
/* 1697 */         this.eventListeners.setUpdateEventListeners((SaveOrUpdateEventListener[])listeners);
/*      */       }
/*      */     }
/* 1700 */     else if ("pre-load".equals(type)) {
/* 1701 */       if (listeners == null) {
/* 1702 */         this.eventListeners.setPreLoadEventListeners(new PreLoadEventListener[0]);
/*      */       }
/*      */       else {
/* 1705 */         this.eventListeners.setPreLoadEventListeners((PreLoadEventListener[])listeners);
/*      */       }
/*      */     }
/* 1708 */     else if ("pre-update".equals(type)) {
/* 1709 */       if (listeners == null) {
/* 1710 */         this.eventListeners.setPreUpdateEventListeners(new PreUpdateEventListener[0]);
/*      */       }
/*      */       else {
/* 1713 */         this.eventListeners.setPreUpdateEventListeners((PreUpdateEventListener[])listeners);
/*      */       }
/*      */     }
/* 1716 */     else if ("pre-delete".equals(type)) {
/* 1717 */       if (listeners == null) {
/* 1718 */         this.eventListeners.setPreDeleteEventListeners(new PreDeleteEventListener[0]);
/*      */       }
/*      */       else {
/* 1721 */         this.eventListeners.setPreDeleteEventListeners((PreDeleteEventListener[])listeners);
/*      */       }
/*      */     }
/* 1724 */     else if ("pre-insert".equals(type)) {
/* 1725 */       if (listeners == null) {
/* 1726 */         this.eventListeners.setPreInsertEventListeners(new PreInsertEventListener[0]);
/*      */       }
/*      */       else {
/* 1729 */         this.eventListeners.setPreInsertEventListeners((PreInsertEventListener[])listeners);
/*      */       }
/*      */     }
/* 1732 */     else if ("post-load".equals(type)) {
/* 1733 */       if (listeners == null) {
/* 1734 */         this.eventListeners.setPostLoadEventListeners(new PostLoadEventListener[0]);
/*      */       }
/*      */       else {
/* 1737 */         this.eventListeners.setPostLoadEventListeners((PostLoadEventListener[])listeners);
/*      */       }
/*      */     }
/* 1740 */     else if ("post-update".equals(type)) {
/* 1741 */       if (listeners == null) {
/* 1742 */         this.eventListeners.setPostUpdateEventListeners(new PostUpdateEventListener[0]);
/*      */       }
/*      */       else {
/* 1745 */         this.eventListeners.setPostUpdateEventListeners((PostUpdateEventListener[])listeners);
/*      */       }
/*      */     }
/* 1748 */     else if ("post-delete".equals(type)) {
/* 1749 */       if (listeners == null) {
/* 1750 */         this.eventListeners.setPostDeleteEventListeners(new PostDeleteEventListener[0]);
/*      */       }
/*      */       else {
/* 1753 */         this.eventListeners.setPostDeleteEventListeners((PostDeleteEventListener[])listeners);
/*      */       }
/*      */     }
/* 1756 */     else if ("post-insert".equals(type)) {
/* 1757 */       if (listeners == null) {
/* 1758 */         this.eventListeners.setPostInsertEventListeners(new PostInsertEventListener[0]);
/*      */       }
/*      */       else {
/* 1761 */         this.eventListeners.setPostInsertEventListeners((PostInsertEventListener[])listeners);
/*      */       }
/*      */     }
/* 1764 */     else if ("post-commit-update".equals(type)) {
/* 1765 */       if (listeners == null) {
/* 1766 */         this.eventListeners.setPostCommitUpdateEventListeners(new PostUpdateEventListener[0]);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1771 */         this.eventListeners.setPostCommitUpdateEventListeners((PostUpdateEventListener[])listeners);
/*      */       }
/*      */     }
/* 1774 */     else if ("post-commit-delete".equals(type)) {
/* 1775 */       if (listeners == null) {
/* 1776 */         this.eventListeners.setPostCommitDeleteEventListeners(new PostDeleteEventListener[0]);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1781 */         this.eventListeners.setPostCommitDeleteEventListeners((PostDeleteEventListener[])listeners);
/*      */       }
/*      */     }
/* 1784 */     else if ("post-commit-insert".equals(type)) {
/* 1785 */       if (listeners == null) {
/* 1786 */         this.eventListeners.setPostCommitInsertEventListeners(new PostInsertEventListener[0]);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1791 */         this.eventListeners.setPostCommitInsertEventListeners((PostInsertEventListener[])listeners);
/*      */       }
/*      */     }
/*      */     else {
/* 1795 */       log.warn("Unrecognized listener type [" + type + "]");
/*      */     }
/*      */   }
/*      */   
/*      */   public EventListeners getEventListeners() {
/* 1800 */     return this.eventListeners;
/*      */   }
/*      */   
/*      */   RootClass getRootClassMapping(String clazz) throws MappingException {
/*      */     try {
/* 1805 */       return (RootClass)getClassMapping(clazz);
/*      */     }
/*      */     catch (ClassCastException cce) {
/* 1808 */       throw new MappingException("You may only specify a cache for root <class> mappings");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration setCacheConcurrencyStrategy(String clazz, String concurrencyStrategy)
/*      */     throws MappingException
/*      */   {
/* 1822 */     setCacheConcurrencyStrategy(clazz, concurrencyStrategy, clazz);
/* 1823 */     return this;
/*      */   }
/*      */   
/*      */   public void setCacheConcurrencyStrategy(String clazz, String concurrencyStrategy, String region) throws MappingException
/*      */   {
/* 1828 */     setCacheConcurrencyStrategy(clazz, concurrencyStrategy, region, true);
/*      */   }
/*      */   
/*      */   void setCacheConcurrencyStrategy(String clazz, String concurrencyStrategy, String region, boolean includeLazy) throws MappingException
/*      */   {
/* 1833 */     RootClass rootClass = getRootClassMapping(clazz);
/* 1834 */     if (rootClass == null) throw new MappingException("Cannot cache an unknown entity: " + clazz);
/* 1835 */     rootClass.setCacheConcurrencyStrategy(concurrencyStrategy);
/* 1836 */     rootClass.setCacheRegionName(region);
/* 1837 */     rootClass.setLazyPropertiesCacheable(includeLazy);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration setCollectionCacheConcurrencyStrategy(String collectionRole, String concurrencyStrategy)
/*      */     throws MappingException
/*      */   {
/* 1850 */     setCollectionCacheConcurrencyStrategy(collectionRole, concurrencyStrategy, collectionRole);
/* 1851 */     return this;
/*      */   }
/*      */   
/*      */   public void setCollectionCacheConcurrencyStrategy(String collectionRole, String concurrencyStrategy, String region) throws MappingException
/*      */   {
/* 1856 */     org.hibernate.mapping.Collection collection = getCollectionMapping(collectionRole);
/* 1857 */     if (collection == null) throw new MappingException("Cannot cache an unknown collection: " + collectionRole);
/* 1858 */     collection.setCacheConcurrencyStrategy(concurrencyStrategy);
/* 1859 */     collection.setCacheRegionName(region);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Map getImports()
/*      */   {
/* 1868 */     return this.imports;
/*      */   }
/*      */   
/*      */ 
/*      */   public Settings buildSettings()
/*      */     throws HibernateException
/*      */   {
/* 1875 */     Properties clone = (Properties)this.properties.clone();
/* 1876 */     PropertiesHelper.resolvePlaceHolders(clone);
/* 1877 */     return this.settingsFactory.buildSettings(clone);
/*      */   }
/*      */   
/*      */   public Settings buildSettings(Properties props) throws HibernateException {
/* 1881 */     return this.settingsFactory.buildSettings(props);
/*      */   }
/*      */   
/*      */   public Map getNamedSQLQueries() {
/* 1885 */     return this.namedSqlQueries;
/*      */   }
/*      */   
/*      */   public Map getSqlResultSetMappings() {
/* 1889 */     return this.sqlResultSetMappings;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public NamingStrategy getNamingStrategy()
/*      */   {
/* 1896 */     return this.namingStrategy;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration setNamingStrategy(NamingStrategy namingStrategy)
/*      */   {
/* 1905 */     this.namingStrategy = namingStrategy;
/* 1906 */     return this;
/*      */   }
/*      */   
/*      */   private Mapping buildMapping() {
/* 1910 */     new Mapping()
/*      */     {
/*      */       public Type getIdentifierType(String persistentClass)
/*      */         throws MappingException
/*      */       {
/* 1915 */         PersistentClass pc = (PersistentClass)Configuration.this.classes.get(persistentClass);
/* 1916 */         if (pc == null) {
/* 1917 */           throw new MappingException("persistent class not known: " + persistentClass);
/*      */         }
/* 1919 */         return pc.getIdentifier().getType();
/*      */       }
/*      */       
/*      */       public String getIdentifierPropertyName(String persistentClass) throws MappingException {
/* 1923 */         PersistentClass pc = (PersistentClass)Configuration.this.classes.get(persistentClass);
/* 1924 */         if (pc == null) {
/* 1925 */           throw new MappingException("persistent class not known: " + persistentClass);
/*      */         }
/* 1927 */         if (!pc.hasIdentifierProperty()) return null;
/* 1928 */         return pc.getIdentifierProperty().getName();
/*      */       }
/*      */       
/*      */       public Type getReferencedPropertyType(String persistentClass, String propertyName) throws MappingException {
/* 1932 */         PersistentClass pc = (PersistentClass)Configuration.this.classes.get(persistentClass);
/* 1933 */         if (pc == null) {
/* 1934 */           throw new MappingException("persistent class not known: " + persistentClass);
/*      */         }
/* 1936 */         Property prop = pc.getReferencedProperty(propertyName);
/* 1937 */         if (prop == null) {
/* 1938 */           throw new MappingException("property not known: " + persistentClass + '.' + propertyName);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1943 */         return prop.getType();
/*      */       }
/*      */     };
/*      */   }
/*      */   
/*      */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 1949 */     ois.defaultReadObject();
/* 1950 */     this.mapping = buildMapping();
/* 1951 */     this.xmlHelper = new XMLHelper();
/*      */   }
/*      */   
/*      */   public Map getFilterDefinitions() {
/* 1955 */     return this.filterDefinitions;
/*      */   }
/*      */   
/*      */   public void addFilterDefinition(FilterDefinition definition) {
/* 1959 */     this.filterDefinitions.put(definition.getFilterName(), definition);
/*      */   }
/*      */   
/*      */   public void addAuxiliaryDatabaseObject(AuxiliaryDatabaseObject object) {
/* 1963 */     this.auxiliaryDatabaseObjects.add(object);
/*      */   }
/*      */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cfg\Configuration.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */