package org.hibernate.cfg;

public abstract interface NamingStrategy
{
  public abstract String classToTableName(String paramString);
  
  public abstract String propertyToColumnName(String paramString);
  
  public abstract String tableName(String paramString);
  
  public abstract String columnName(String paramString);
  
  public abstract String collectionTableName(String paramString1, String paramString2, String paramString3);
  
  public abstract String joinKeyColumnName(String paramString1, String paramString2);
  
  public abstract String foreignKeyColumnName(String paramString1, String paramString2, String paramString3);
  
  public abstract String logicalColumnName(String paramString1, String paramString2);
  
  public abstract String logicalCollectionTableName(String paramString1, String paramString2, String paramString3, String paramString4);
  
  public abstract String logicalCollectionColumnName(String paramString1, String paramString2, String paramString3);
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cfg\NamingStrategy.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */