/*     */ package org.hibernate.cfg;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.sql.Statement;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.util.ConfigHelper;
/*     */ import org.hibernate.util.PropertiesHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Environment
/*     */ {
/*     */   public static final String VERSION = "3.1.2";
/*     */   public static final String CONNECTION_PROVIDER = "hibernate.connection.provider_class";
/*     */   public static final String DRIVER = "hibernate.connection.driver_class";
/*     */   public static final String ISOLATION = "hibernate.connection.isolation";
/*     */   public static final String URL = "hibernate.connection.url";
/*     */   public static final String USER = "hibernate.connection.username";
/*     */   public static final String PASS = "hibernate.connection.password";
/*     */   public static final String AUTOCOMMIT = "hibernate.connection.autocommit";
/*     */   public static final String POOL_SIZE = "hibernate.connection.pool_size";
/*     */   public static final String DATASOURCE = "hibernate.connection.datasource";
/*     */   public static final String CONNECTION_PREFIX = "hibernate.connection";
/*     */   public static final String JNDI_CLASS = "hibernate.jndi.class";
/*     */   public static final String JNDI_URL = "hibernate.jndi.url";
/*     */   public static final String JNDI_PREFIX = "hibernate.jndi";
/*     */   public static final String SESSION_FACTORY_NAME = "hibernate.session_factory_name";
/*     */   public static final String DIALECT = "hibernate.dialect";
/*     */   public static final String DEFAULT_SCHEMA = "hibernate.default_schema";
/*     */   public static final String DEFAULT_CATALOG = "hibernate.default_catalog";
/*     */   public static final String SHOW_SQL = "hibernate.show_sql";
/*     */   public static final String FORMAT_SQL = "hibernate.format_sql";
/*     */   public static final String USE_SQL_COMMENTS = "hibernate.use_sql_comments";
/*     */   public static final String MAX_FETCH_DEPTH = "hibernate.max_fetch_depth";
/*     */   public static final String DEFAULT_BATCH_FETCH_SIZE = "hibernate.default_batch_fetch_size";
/*     */   public static final String USE_STREAMS_FOR_BINARY = "hibernate.jdbc.use_streams_for_binary";
/*     */   public static final String USE_SCROLLABLE_RESULTSET = "hibernate.jdbc.use_scrollable_resultset";
/*     */   public static final String USE_GET_GENERATED_KEYS = "hibernate.jdbc.use_get_generated_keys";
/*     */   public static final String STATEMENT_FETCH_SIZE = "hibernate.jdbc.fetch_size";
/*     */   public static final String STATEMENT_BATCH_SIZE = "hibernate.jdbc.batch_size";
/*     */   public static final String BATCH_STRATEGY = "hibernate.jdbc.factory_class";
/*     */   public static final String BATCH_VERSIONED_DATA = "hibernate.jdbc.batch_versioned_data";
/*     */   public static final String OUTPUT_STYLESHEET = "hibernate.xml.output_stylesheet";
/*     */   public static final String C3P0_MAX_SIZE = "hibernate.c3p0.max_size";
/*     */   public static final String C3P0_MIN_SIZE = "hibernate.c3p0.min_size";
/*     */   public static final String C3P0_TIMEOUT = "hibernate.c3p0.timeout";
/*     */   public static final String C3P0_MAX_STATEMENTS = "hibernate.c3p0.max_statements";
/*     */   public static final String C3P0_ACQUIRE_INCREMENT = "hibernate.c3p0.acquire_increment";
/*     */   public static final String C3P0_IDLE_TEST_PERIOD = "hibernate.c3p0.idle_test_period";
/*     */   public static final String PROXOOL_PREFIX = "hibernate.proxool";
/*     */   public static final String PROXOOL_XML = "hibernate.proxool.xml";
/*     */   public static final String PROXOOL_PROPERTIES = "hibernate.proxool.properties";
/*     */   public static final String PROXOOL_EXISTING_POOL = "hibernate.proxool.existing_pool";
/*     */   public static final String PROXOOL_POOL_ALIAS = "hibernate.proxool.pool_alias";
/*     */   public static final String AUTO_CLOSE_SESSION = "hibernate.transaction.auto_close_session";
/*     */   public static final String FLUSH_BEFORE_COMPLETION = "hibernate.transaction.flush_before_completion";
/*     */   public static final String RELEASE_CONNECTIONS = "hibernate.connection.release_mode";
/*     */   public static final String CURRENT_SESSION_CONTEXT_CLASS = "hibernate.current_session_context_class";
/*     */   public static final String TRANSACTION_STRATEGY = "hibernate.transaction.factory_class";
/*     */   public static final String TRANSACTION_MANAGER_STRATEGY = "hibernate.transaction.manager_lookup_class";
/*     */   public static final String USER_TRANSACTION = "jta.UserTransaction";
/*     */   public static final String CACHE_PROVIDER = "hibernate.cache.provider_class";
/*     */   public static final String CACHE_NAMESPACE = "hibernate.cache.jndi";
/*     */   public static final String USE_QUERY_CACHE = "hibernate.cache.use_query_cache";
/*     */   public static final String QUERY_CACHE_FACTORY = "hibernate.cache.query_cache_factory";
/*     */   public static final String USE_SECOND_LEVEL_CACHE = "hibernate.cache.use_second_level_cache";
/*     */   public static final String USE_MINIMAL_PUTS = "hibernate.cache.use_minimal_puts";
/*     */   public static final String CACHE_REGION_PREFIX = "hibernate.cache.region_prefix";
/*     */   public static final String USE_STRUCTURED_CACHE = "hibernate.cache.use_structured_entries";
/*     */   public static final String GENERATE_STATISTICS = "hibernate.generate_statistics";
/*     */   public static final String USE_IDENTIFIER_ROLLBACK = "hibernate.use_identifier_rollback";
/*     */   public static final String USE_REFLECTION_OPTIMIZER = "hibernate.cglib.use_reflection_optimizer";
/*     */   public static final String QUERY_TRANSLATOR = "hibernate.query.factory_class";
/*     */   public static final String QUERY_SUBSTITUTIONS = "hibernate.query.substitutions";
/*     */   public static final String HBM2DDL_AUTO = "hibernate.hbm2ddl.auto";
/*     */   public static final String SQL_EXCEPTION_CONVERTER = "hibernate.jdbc.sql_exception_converter";
/*     */   public static final String WRAP_RESULT_SETS = "hibernate.jdbc.wrap_result_sets";
/*     */   public static final String ORDER_UPDATES = "hibernate.order_updates";
/*     */   public static final String DEFAULT_ENTITY_MODE = "hibernate.default_entity_mode";
/*     */   public static final String JACC_CONTEXTID = "hibernate.jacc_context_id";
/*     */   private static final boolean ENABLE_BINARY_STREAMS;
/*     */   private static final boolean ENABLE_REFLECTION_OPTIMIZER;
/*     */   private static final boolean JVM_SUPPORTS_LINKED_HASH_COLLECTIONS;
/*     */   private static final boolean JVM_HAS_TIMESTAMP_BUG;
/*     */   private static final boolean JVM_HAS_JDK14_TIMESTAMP;
/*     */   private static final boolean JVM_SUPPORTS_GET_GENERATED_KEYS;
/*     */   private static final Properties GLOBAL_PROPERTIES;
/* 460 */   private static final HashMap ISOLATION_LEVELS = new HashMap();
/* 461 */   private static final Map OBSOLETE_PROPERTIES = new HashMap();
/*     */   
/* 463 */   private static final Log log = LogFactory.getLog(Environment.class);
/*     */   
/*     */ 
/*     */ 
/*     */   public static void verifyProperties(Properties props)
/*     */   {
/* 469 */     Iterator iter = props.keySet().iterator();
/* 470 */     while (iter.hasNext()) {
/* 471 */       Object oldProp = iter.next();
/* 472 */       Object newProp = OBSOLETE_PROPERTIES.get(oldProp);
/* 473 */       if (newProp != null) log.warn("Usage of obsolete property: " + oldProp + " no longer supported, use: " + newProp);
/*     */     }
/*     */   }
/*     */   
/*     */   static
/*     */   {
/* 479 */     log.info("Hibernate 3.1.2");
/*     */     
/* 481 */     ISOLATION_LEVELS.put(new Integer(0), "NONE");
/* 482 */     ISOLATION_LEVELS.put(new Integer(1), "READ_UNCOMMITTED");
/* 483 */     ISOLATION_LEVELS.put(new Integer(2), "READ_COMMITTED");
/* 484 */     ISOLATION_LEVELS.put(new Integer(4), "REPEATABLE_READ");
/* 485 */     ISOLATION_LEVELS.put(new Integer(8), "SERIALIZABLE");
/*     */     
/* 487 */     GLOBAL_PROPERTIES = new Properties();
/* 488 */     GLOBAL_PROPERTIES.setProperty("hibernate.cglib.use_reflection_optimizer", Boolean.TRUE.toString());
/*     */     try
/*     */     {
/* 491 */       InputStream stream = ConfigHelper.getResourceAsStream("/hibernate.properties");
/*     */       try {
/* 493 */         GLOBAL_PROPERTIES.load(stream);
/* 494 */         log.info("loaded properties from resource hibernate.properties: " + PropertiesHelper.maskOut(GLOBAL_PROPERTIES, "hibernate.connection.password"));
/*     */       }
/*     */       catch (Exception e) {
/* 497 */         log.error("problem loading properties from hibernate.properties");
/*     */       }
/*     */       finally {
/*     */         try {
/* 501 */           stream.close();
/*     */         }
/*     */         catch (IOException ioe) {
/* 504 */           log.error("could not close stream on hibernate.properties", ioe);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (HibernateException he) {
/* 509 */       log.info("hibernate.properties not found");
/*     */     }
/*     */     try
/*     */     {
/* 513 */       GLOBAL_PROPERTIES.putAll(System.getProperties());
/*     */     }
/*     */     catch (SecurityException se) {
/* 516 */       log.warn("could not copy system properties, system properties will be ignored");
/*     */     }
/*     */     
/* 519 */     verifyProperties(GLOBAL_PROPERTIES);
/*     */     
/* 521 */     ENABLE_BINARY_STREAMS = PropertiesHelper.getBoolean("hibernate.jdbc.use_streams_for_binary", GLOBAL_PROPERTIES);
/* 522 */     ENABLE_REFLECTION_OPTIMIZER = PropertiesHelper.getBoolean("hibernate.cglib.use_reflection_optimizer", GLOBAL_PROPERTIES);
/*     */     
/* 524 */     if (ENABLE_BINARY_STREAMS) log.info("using java.io streams to persist binary types");
/* 525 */     if (ENABLE_REFLECTION_OPTIMIZER) log.info("using CGLIB reflection optimizer");
/*     */     boolean getGeneratedKeysSupport;
/*     */     try
/*     */     {
/* 529 */       Statement.class.getMethod("getGeneratedKeys", null);
/* 530 */       getGeneratedKeysSupport = true;
/*     */     } catch (NoSuchMethodException nsme) {
/*     */       boolean getGeneratedKeysSupport;
/* 533 */       getGeneratedKeysSupport = false;
/*     */     }
/* 535 */     JVM_SUPPORTS_GET_GENERATED_KEYS = getGeneratedKeysSupport;
/* 536 */     if (!JVM_SUPPORTS_GET_GENERATED_KEYS) log.info("JVM does not support Statement.getGeneratedKeys()");
/*     */     boolean linkedHashSupport;
/*     */     try
/*     */     {
/* 540 */       Class.forName("java.util.LinkedHashSet");
/* 541 */       linkedHashSupport = true;
/*     */     } catch (ClassNotFoundException cnfe) {
/*     */       boolean linkedHashSupport;
/* 544 */       linkedHashSupport = false;
/*     */     }
/* 546 */     JVM_SUPPORTS_LINKED_HASH_COLLECTIONS = linkedHashSupport;
/* 547 */     if (!JVM_SUPPORTS_LINKED_HASH_COLLECTIONS) { log.info("JVM does not support LinkedHasMap, LinkedHashSet - ordered maps and sets disabled");
/*     */     }
/* 549 */     JVM_HAS_TIMESTAMP_BUG = new Timestamp(123456789L).getTime() != 123456789L;
/* 550 */     if (JVM_HAS_TIMESTAMP_BUG) log.info("using workaround for JVM bug in java.sql.Timestamp");
/* 551 */     Timestamp t = new Timestamp(0L);
/* 552 */     t.setNanos(5000000);
/* 553 */     JVM_HAS_JDK14_TIMESTAMP = t.getTime() == 5L;
/* 554 */     if (JVM_HAS_JDK14_TIMESTAMP) {
/* 555 */       log.info("using JDK 1.4 java.sql.Timestamp handling");
/*     */     }
/*     */     else {
/* 558 */       log.info("using pre JDK 1.4 java.sql.Timestamp handling");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean jvmHasTimestampBug()
/*     */   {
/* 566 */     return JVM_HAS_TIMESTAMP_BUG;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean jvmHasJDK14Timestamp()
/*     */   {
/* 573 */     return JVM_HAS_JDK14_TIMESTAMP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean jvmSupportsLinkedHashCollections()
/*     */   {
/* 582 */     return JVM_SUPPORTS_LINKED_HASH_COLLECTIONS;
/*     */   }
/*     */   
/*     */   public static boolean jvmSupportsGetGeneratedKeys() {
/* 586 */     return JVM_SUPPORTS_GET_GENERATED_KEYS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean useStreamsForBinary()
/*     */   {
/* 595 */     return ENABLE_BINARY_STREAMS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean useReflectionOptimizer()
/*     */   {
/* 604 */     return ENABLE_REFLECTION_OPTIMIZER;
/*     */   }
/*     */   
/* 607 */   private Environment() { throw new UnsupportedOperationException(); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Properties getProperties()
/*     */   {
/* 615 */     Properties copy = new Properties();
/* 616 */     copy.putAll(GLOBAL_PROPERTIES);
/* 617 */     return copy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String isolationLevelToString(int isolation)
/*     */   {
/* 628 */     return (String)ISOLATION_LEVELS.get(new Integer(isolation));
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cfg\Environment.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */