/*    */ package org.hibernate.cfg;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.dom4j.Attribute;
/*    */ import org.dom4j.Element;
/*    */ import org.hibernate.MappingException;
/*    */ import org.hibernate.engine.NamedSQLQueryDefinition;
/*    */ import org.hibernate.engine.ResultSetMappingDefinition;
/*    */ import org.hibernate.util.StringHelper;
/*    */ 
/*    */ 
/*    */ public class NamedSQLQuerySecondPass
/*    */   extends ResultSetMappingBinder
/*    */   implements QuerySecondPass
/*    */ {
/* 21 */   private static Log log = LogFactory.getLog(NamedSQLQuerySecondPass.class);
/*    */   private Element queryElem;
/*    */   private String path;
/*    */   private Mappings mappings;
/*    */   
/*    */   public NamedSQLQuerySecondPass(Element queryElem, String path, Mappings mappings) {
/* 27 */     this.queryElem = queryElem;
/* 28 */     this.path = path;
/* 29 */     this.mappings = mappings;
/*    */   }
/*    */   
/*    */   public void doSecondPass(Map persistentClasses, Map inheritedMetas) throws MappingException {
/* 33 */     String queryName = this.queryElem.attribute("name").getValue();
/* 34 */     if (this.path != null) { queryName = this.path + '.' + queryName;
/*    */     }
/* 36 */     boolean cacheable = "true".equals(this.queryElem.attributeValue("cacheable"));
/* 37 */     String region = this.queryElem.attributeValue("cache-region");
/* 38 */     Attribute tAtt = this.queryElem.attribute("timeout");
/* 39 */     Integer timeout = tAtt == null ? null : new Integer(tAtt.getValue());
/* 40 */     Attribute fsAtt = this.queryElem.attribute("fetch-size");
/* 41 */     Integer fetchSize = fsAtt == null ? null : new Integer(fsAtt.getValue());
/* 42 */     Attribute roAttr = this.queryElem.attribute("read-only");
/* 43 */     boolean readOnly = (roAttr != null) && ("true".equals(roAttr.getValue()));
/* 44 */     Attribute cacheModeAtt = this.queryElem.attribute("cache-mode");
/* 45 */     String cacheMode = cacheModeAtt == null ? null : cacheModeAtt.getValue();
/* 46 */     Attribute cmAtt = this.queryElem.attribute("comment");
/* 47 */     String comment = cmAtt == null ? null : cmAtt.getValue();
/*    */     
/* 49 */     List synchronizedTables = new ArrayList();
/* 50 */     Iterator tables = this.queryElem.elementIterator("synchronize");
/* 51 */     while (tables.hasNext()) {
/* 52 */       synchronizedTables.add(((Element)tables.next()).attributeValue("table"));
/*    */     }
/* 54 */     boolean callable = "true".equals(this.queryElem.attributeValue("callable"));
/*    */     
/*    */ 
/* 57 */     Attribute ref = this.queryElem.attribute("resultset-ref");
/* 58 */     String resultSetRef = ref == null ? null : ref.getValue();
/* 59 */     NamedSQLQueryDefinition namedQuery; NamedSQLQueryDefinition namedQuery; if (StringHelper.isNotEmpty(resultSetRef)) {
/* 60 */       namedQuery = new NamedSQLQueryDefinition(this.queryElem.getText(), resultSetRef, synchronizedTables, cacheable, region, timeout, fetchSize, HbmBinder.getFlushMode(this.queryElem.attributeValue("flush-mode")), HbmBinder.getCacheMode(cacheMode), readOnly, comment, HbmBinder.getParameterTypes(this.queryElem), callable);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     }
/*    */     else
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 78 */       ResultSetMappingDefinition definition = buildResultSetMappingDefinition(this.queryElem, this.path, this.mappings);
/* 79 */       namedQuery = new NamedSQLQueryDefinition(this.queryElem.getText(), definition.getEntityQueryReturns(), definition.getScalarQueryReturns(), synchronizedTables, cacheable, region, timeout, fetchSize, HbmBinder.getFlushMode(this.queryElem.attributeValue("flush-mode")), HbmBinder.getCacheMode(cacheMode), readOnly, comment, HbmBinder.getParameterTypes(this.queryElem), callable);
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 97 */     log.debug("Named SQL query: " + queryName + " -> " + namedQuery.getQueryString());
/* 98 */     this.mappings.addSQLQuery(queryName, namedQuery);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cfg\NamedSQLQuerySecondPass.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */