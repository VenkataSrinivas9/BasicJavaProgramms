/*     */ package org.hibernate.cfg;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.DuplicateMappingException;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.engine.FilterDefinition;
/*     */ import org.hibernate.engine.NamedQueryDefinition;
/*     */ import org.hibernate.engine.NamedSQLQueryDefinition;
/*     */ import org.hibernate.engine.ResultSetMappingDefinition;
/*     */ import org.hibernate.mapping.AuxiliaryDatabaseObject;
/*     */ import org.hibernate.mapping.Column;
/*     */ import org.hibernate.mapping.DenormalizedTable;
/*     */ import org.hibernate.mapping.PersistentClass;
/*     */ import org.hibernate.mapping.Table;
/*     */ import org.hibernate.mapping.TypeDef;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Mappings
/*     */   implements Serializable
/*     */ {
/*  36 */   private static final Log log = LogFactory.getLog(Mappings.class);
/*     */   
/*     */ 
/*     */   private final Map classes;
/*     */   
/*     */ 
/*     */   private final Map collections;
/*     */   
/*     */ 
/*     */   private final Map tables;
/*     */   
/*     */ 
/*     */   private final Map queries;
/*     */   
/*     */ 
/*     */   private final Map sqlqueries;
/*     */   
/*     */ 
/*     */   private final Map resultSetMappings;
/*     */   
/*     */ 
/*     */   private final Map typeDefs;
/*     */   
/*     */ 
/*     */   private final List secondPasses;
/*     */   
/*     */ 
/*     */   private final Map imports;
/*     */   
/*     */ 
/*     */   private String schemaName;
/*     */   
/*     */   private String catalogName;
/*     */   
/*     */   private String defaultCascade;
/*     */   
/*     */   private String defaultPackage;
/*     */   
/*     */   private String defaultAccess;
/*     */   
/*     */   private boolean autoImport;
/*     */   
/*     */   private boolean defaultLazy;
/*     */   
/*     */   private final List propertyReferences;
/*     */   
/*     */   private final NamingStrategy namingStrategy;
/*     */   
/*     */   private final Map filterDefinitions;
/*     */   
/*     */   private final List auxiliaryDatabaseObjects;
/*     */   
/*     */   private final Map extendsQueue;
/*     */   
/*     */   protected final Map columnNameBindingPerTable;
/*     */   
/*     */   protected final Map tableNameBinding;
/*     */   
/*     */ 
/*     */   Mappings(Map classes, Map collections, Map tables, Map queries, Map sqlqueries, Map sqlResultSetMappings, Map imports, List secondPasses, List propertyReferences, NamingStrategy namingStrategy, Map typeDefs, Map filterDefinitions, Map extendsQueue, List auxiliaryDatabaseObjects, Map tableNamebinding, Map columnNameBindingPerTable)
/*     */   {
/*  97 */     this.classes = classes;
/*  98 */     this.collections = collections;
/*  99 */     this.queries = queries;
/* 100 */     this.sqlqueries = sqlqueries;
/* 101 */     this.resultSetMappings = sqlResultSetMappings;
/* 102 */     this.tables = tables;
/* 103 */     this.imports = imports;
/* 104 */     this.secondPasses = secondPasses;
/* 105 */     this.propertyReferences = propertyReferences;
/* 106 */     this.namingStrategy = namingStrategy;
/* 107 */     this.typeDefs = typeDefs;
/* 108 */     this.filterDefinitions = filterDefinitions;
/* 109 */     this.extendsQueue = extendsQueue;
/* 110 */     this.auxiliaryDatabaseObjects = auxiliaryDatabaseObjects;
/* 111 */     this.tableNameBinding = tableNamebinding;
/* 112 */     this.columnNameBindingPerTable = columnNameBindingPerTable;
/*     */   }
/*     */   
/*     */   public void addClass(PersistentClass persistentClass) throws MappingException {
/* 116 */     Object old = this.classes.put(persistentClass.getEntityName(), persistentClass);
/* 117 */     if (old != null)
/* 118 */       throw new DuplicateMappingException("class/entity", persistentClass.getEntityName());
/*     */   }
/*     */   
/*     */   public void addCollection(org.hibernate.mapping.Collection collection) throws MappingException {
/* 122 */     Object old = this.collections.put(collection.getRole(), collection);
/* 123 */     if (old != null)
/* 124 */       throw new DuplicateMappingException("collection role", collection.getRole());
/*     */   }
/*     */   
/*     */   public PersistentClass getClass(String className) {
/* 128 */     return (PersistentClass)this.classes.get(className);
/*     */   }
/*     */   
/* 131 */   public org.hibernate.mapping.Collection getCollection(String role) { return (org.hibernate.mapping.Collection)this.collections.get(role); }
/*     */   
/*     */   public void addImport(String className, String rename) throws MappingException
/*     */   {
/* 135 */     String existing = (String)this.imports.put(rename, className);
/* 136 */     if (existing != null) {
/* 137 */       if (existing.equals(className)) {
/* 138 */         log.info("duplicate import: " + className + "->" + rename);
/*     */       }
/*     */       else {
/* 141 */         throw new DuplicateMappingException("duplicate import: " + rename + " refers to both " + className + " and " + existing + " (try using auto-import=\"false\")", "import", rename);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static final class PropertyReference
/*     */     implements Serializable
/*     */   {
/*     */     String referencedClass;
/*     */     
/*     */     String propertyName;
/*     */     
/*     */     boolean unique;
/*     */   }
/*     */   
/*     */   public Table addTable(String schema, String catalog, String name, String subselect, boolean isAbstract)
/*     */   {
/* 159 */     String key = subselect == null ? Table.qualify(catalog, schema, name) : subselect;
/*     */     
/*     */ 
/* 162 */     Table table = (Table)this.tables.get(key);
/*     */     
/* 164 */     if (table == null) {
/* 165 */       table = new Table();
/* 166 */       table.setAbstract(isAbstract);
/* 167 */       table.setName(name);
/* 168 */       table.setSchema(schema);
/* 169 */       table.setCatalog(catalog);
/* 170 */       table.setSubselect(subselect);
/* 171 */       this.tables.put(key, table);
/*     */ 
/*     */     }
/* 174 */     else if (!isAbstract) { table.setAbstract(false);
/*     */     }
/*     */     
/* 177 */     return table;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Table addDenormalizedTable(String schema, String catalog, String name, boolean isAbstract, String subselect, Table includedTable)
/*     */     throws MappingException
/*     */   {
/* 188 */     String key = subselect == null ? Table.qualify(catalog, schema, name) : subselect;
/*     */     
/*     */ 
/* 191 */     if (this.tables.containsKey(key)) {
/* 192 */       throw new DuplicateMappingException("table", name);
/*     */     }
/*     */     
/* 195 */     Table table = new DenormalizedTable(includedTable);
/* 196 */     table.setAbstract(isAbstract);
/* 197 */     table.setName(name);
/* 198 */     table.setSchema(schema);
/* 199 */     table.setCatalog(catalog);
/* 200 */     table.setSubselect(subselect);
/* 201 */     this.tables.put(key, table);
/* 202 */     return table;
/*     */   }
/*     */   
/*     */   public Table getTable(String schema, String catalog, String name) {
/* 206 */     String key = Table.qualify(catalog, schema, name);
/* 207 */     return (Table)this.tables.get(key);
/*     */   }
/*     */   
/*     */   public String getSchemaName() {
/* 211 */     return this.schemaName;
/*     */   }
/*     */   
/*     */   public String getCatalogName() {
/* 215 */     return this.catalogName;
/*     */   }
/*     */   
/*     */   public String getDefaultCascade() {
/* 219 */     return this.defaultCascade;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSchemaName(String schemaName)
/*     */   {
/* 227 */     this.schemaName = schemaName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCatalogName(String catalogName)
/*     */   {
/* 235 */     this.catalogName = catalogName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultCascade(String defaultCascade)
/*     */   {
/* 243 */     this.defaultCascade = defaultCascade;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultAccess(String defaultAccess)
/*     */   {
/* 251 */     this.defaultAccess = defaultAccess;
/*     */   }
/*     */   
/*     */   public String getDefaultAccess() {
/* 255 */     return this.defaultAccess;
/*     */   }
/*     */   
/*     */   public void addQuery(String name, NamedQueryDefinition query) throws MappingException {
/* 259 */     checkQueryExist(name);
/* 260 */     this.queries.put(name.intern(), query);
/*     */   }
/*     */   
/*     */   public void addSQLQuery(String name, NamedSQLQueryDefinition query) throws MappingException {
/* 264 */     checkQueryExist(name);
/* 265 */     this.sqlqueries.put(name.intern(), query);
/*     */   }
/*     */   
/*     */   private void checkQueryExist(String name) throws MappingException {
/* 269 */     if ((this.sqlqueries.containsKey(name)) || (this.queries.containsKey(name))) {
/* 270 */       throw new DuplicateMappingException("query", name);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addResultSetMapping(ResultSetMappingDefinition sqlResultSetMapping) {
/* 275 */     String name = sqlResultSetMapping.getName();
/* 276 */     if (this.resultSetMappings.containsKey(name)) {
/* 277 */       throw new DuplicateMappingException("resultSet", name);
/*     */     }
/* 279 */     this.resultSetMappings.put(name, sqlResultSetMapping);
/*     */   }
/*     */   
/*     */   public ResultSetMappingDefinition getResultSetMapping(String name) {
/* 283 */     return (ResultSetMappingDefinition)this.resultSetMappings.get(name);
/*     */   }
/*     */   
/*     */   public NamedQueryDefinition getQuery(String name)
/*     */   {
/* 288 */     return (NamedQueryDefinition)this.queries.get(name);
/*     */   }
/*     */   
/*     */   public void addSecondPass(SecondPass sp) {
/* 292 */     addSecondPass(sp, false);
/*     */   }
/*     */   
/*     */   public void addSecondPass(SecondPass sp, boolean onTopOfTheQueue) {
/* 296 */     if (onTopOfTheQueue) {
/* 297 */       this.secondPasses.add(0, sp);
/*     */     }
/*     */     else {
/* 300 */       this.secondPasses.add(sp);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutoImport()
/*     */   {
/* 309 */     return this.autoImport;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutoImport(boolean autoImport)
/*     */   {
/* 317 */     this.autoImport = autoImport;
/*     */   }
/*     */   
/*     */   void addUniquePropertyReference(String referencedClass, String propertyName) {
/* 321 */     PropertyReference upr = new PropertyReference();
/* 322 */     upr.referencedClass = referencedClass;
/* 323 */     upr.propertyName = propertyName;
/* 324 */     upr.unique = true;
/* 325 */     this.propertyReferences.add(upr);
/*     */   }
/*     */   
/*     */   void addPropertyReference(String referencedClass, String propertyName) {
/* 329 */     PropertyReference upr = new PropertyReference();
/* 330 */     upr.referencedClass = referencedClass;
/* 331 */     upr.propertyName = propertyName;
/* 332 */     this.propertyReferences.add(upr);
/*     */   }
/*     */   
/*     */   private String buildTableNameKey(String schema, String catalog, String finalName) {
/* 336 */     StringBuffer keyBuilder = new StringBuffer();
/* 337 */     if (schema != null) keyBuilder.append(schema);
/* 338 */     keyBuilder.append(".");
/* 339 */     if (catalog != null) keyBuilder.append(catalog);
/* 340 */     keyBuilder.append(".");
/* 341 */     keyBuilder.append(finalName);
/* 342 */     return keyBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDefaultPackage()
/*     */   {
/* 355 */     return this.defaultPackage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDefaultPackage(String defaultPackage)
/*     */   {
/* 362 */     this.defaultPackage = defaultPackage;
/*     */   }
/*     */   
/*     */   public NamingStrategy getNamingStrategy() {
/* 366 */     return this.namingStrategy;
/*     */   }
/*     */   
/*     */   public void addTypeDef(String typeName, String typeClass, Properties paramMap) {
/* 370 */     TypeDef def = new TypeDef(typeClass, paramMap);
/* 371 */     this.typeDefs.put(typeName, def);
/* 372 */     log.debug("Added " + typeName + " with class " + typeClass);
/*     */   }
/*     */   
/*     */   public TypeDef getTypeDef(String typeName) {
/* 376 */     return (TypeDef)this.typeDefs.get(typeName);
/*     */   }
/*     */   
/*     */   public Iterator iterateCollections() {
/* 380 */     return this.collections.values().iterator();
/*     */   }
/*     */   
/*     */   public Iterator iterateTables() {
/* 384 */     return this.tables.values().iterator();
/*     */   }
/*     */   
/*     */   public Map getFilterDefinitions() {
/* 388 */     return this.filterDefinitions;
/*     */   }
/*     */   
/*     */   public void addFilterDefinition(FilterDefinition definition) {
/* 392 */     this.filterDefinitions.put(definition.getFilterName(), definition);
/*     */   }
/*     */   
/*     */   public FilterDefinition getFilterDefinition(String name) {
/* 396 */     return (FilterDefinition)this.filterDefinitions.get(name);
/*     */   }
/*     */   
/*     */   public boolean isDefaultLazy() {
/* 400 */     return this.defaultLazy;
/*     */   }
/*     */   
/* 403 */   public void setDefaultLazy(boolean defaultLazy) { this.defaultLazy = defaultLazy; }
/*     */   
/*     */   public void addToExtendsQueue(ExtendsQueueEntry entry)
/*     */   {
/* 407 */     this.extendsQueue.put(entry, null);
/*     */   }
/*     */   
/*     */   public PersistentClass locatePersistentClassByEntityName(String entityName) {
/* 411 */     PersistentClass persistentClass = (PersistentClass)this.classes.get(entityName);
/* 412 */     if (persistentClass == null) {
/* 413 */       String actualEntityName = (String)this.imports.get(entityName);
/* 414 */       if (StringHelper.isNotEmpty(actualEntityName)) {
/* 415 */         persistentClass = (PersistentClass)this.classes.get(actualEntityName);
/*     */       }
/*     */     }
/* 418 */     return persistentClass;
/*     */   }
/*     */   
/*     */   public void addAuxiliaryDatabaseObject(AuxiliaryDatabaseObject auxiliaryDatabaseObject) {
/* 422 */     this.auxiliaryDatabaseObjects.add(auxiliaryDatabaseObject);
/*     */   }
/*     */   
/*     */ 
/*     */   public void addTableBinding(String schema, String catalog, String logicalName, String physicalName, Table denormalizedSuperTable)
/*     */   {
/* 428 */     String key = buildTableNameKey(schema, catalog, physicalName);
/* 429 */     TableDescription tableDescription = new TableDescription(logicalName, denormalizedSuperTable);
/*     */     
/*     */ 
/* 432 */     TableDescription oldDescriptor = (TableDescription)this.tableNameBinding.put(key, tableDescription);
/* 433 */     if ((oldDescriptor != null) && (!oldDescriptor.logicalName.equals(logicalName)))
/*     */     {
/* 435 */       throw new MappingException("Same physical table name reference several logical table names: " + physicalName + " => " + "'" + oldDescriptor.logicalName + "' and '" + logicalName + "'");
/*     */     }
/*     */   }
/*     */   
/*     */   public void addColumnBinding(String logicalName, Column finalColumn, Table table)
/*     */   {
/* 441 */     ColumnNames binding = (ColumnNames)this.columnNameBindingPerTable.get(table);
/* 442 */     if (binding == null) {
/* 443 */       binding = new ColumnNames();
/* 444 */       this.columnNameBindingPerTable.put(table, binding);
/*     */     }
/* 446 */     String oldFinalName = (String)binding.logicalToPhysical.put(logicalName.toLowerCase(), finalColumn.getQuotedName());
/*     */     
/*     */ 
/*     */ 
/* 450 */     if ((oldFinalName != null) && (finalColumn.isQuoted() ? !oldFinalName.equals(finalColumn.getQuotedName()) : !oldFinalName.equalsIgnoreCase(finalColumn.getQuotedName())))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 455 */       throw new MappingException("Same logical column name referenced by different physical ones: " + table.getName() + "." + logicalName + " => '" + oldFinalName + "' and '" + finalColumn.getQuotedName() + "'");
/*     */     }
/*     */     
/* 458 */     String oldLogicalName = (String)binding.physicalToLogical.put(finalColumn.getQuotedName(), logicalName);
/*     */     
/*     */ 
/*     */ 
/* 462 */     if ((oldLogicalName != null) && (!oldLogicalName.equals(logicalName)))
/*     */     {
/* 464 */       throw new MappingException("Same physical column represented by different logical column names: " + table.getName() + "." + finalColumn.getQuotedName() + " => '" + oldLogicalName + "' and '" + logicalName + "'");
/*     */     }
/*     */   }
/*     */   
/*     */   private String getLogicalTableName(String schema, String catalog, String physicalName)
/*     */   {
/* 470 */     String key = buildTableNameKey(schema, catalog, physicalName);
/* 471 */     TableDescription descriptor = (TableDescription)this.tableNameBinding.get(key);
/* 472 */     if (descriptor == null) {
/* 473 */       throw new MappingException("Unable to find physical table: " + physicalName);
/*     */     }
/* 475 */     return descriptor.logicalName;
/*     */   }
/*     */   
/*     */   public String getPhysicalColumnName(String logicalName, Table table) {
/* 479 */     logicalName = logicalName.toLowerCase();
/* 480 */     String finalName = null;
/* 481 */     Table currentTable = table;
/*     */     do {
/* 483 */       ColumnNames binding = (ColumnNames)this.columnNameBindingPerTable.get(currentTable);
/* 484 */       if (binding != null) {
/* 485 */         finalName = (String)binding.logicalToPhysical.get(logicalName);
/*     */       }
/* 487 */       String key = buildTableNameKey(currentTable.getSchema(), currentTable.getCatalog(), currentTable.getName());
/* 488 */       TableDescription description = (TableDescription)this.tableNameBinding.get(key);
/* 489 */       if (description != null) { currentTable = description.denormalizedSupertable;
/*     */       }
/* 491 */     } while ((finalName == null) && (currentTable != null));
/* 492 */     if (finalName == null) {
/* 493 */       throw new MappingException("Unable to find column with logical name: " + table.getName() + "." + logicalName);
/*     */     }
/* 495 */     return finalName;
/*     */   }
/*     */   
/*     */   public String getLogicalColumnName(String physicalName, Table table) {
/* 499 */     String logical = null;
/* 500 */     Table currentTable = table;
/* 501 */     TableDescription description = null;
/*     */     do {
/* 503 */       ColumnNames binding = (ColumnNames)this.columnNameBindingPerTable.get(currentTable);
/* 504 */       if (binding != null) {
/* 505 */         logical = (String)binding.physicalToLogical.get(physicalName);
/*     */       }
/* 507 */       String key = buildTableNameKey(currentTable.getSchema(), currentTable.getCatalog(), currentTable.getName());
/* 508 */       description = (TableDescription)this.tableNameBinding.get(key);
/* 509 */       if (description != null) { currentTable = description.denormalizedSupertable;
/*     */       }
/* 511 */     } while ((logical == null) && (currentTable != null) && (description != null));
/* 512 */     if (logical == null) {
/* 513 */       throw new MappingException("Unable to find logical column name from physical name: " + table.getName() + "." + physicalName);
/*     */     }
/*     */     
/* 516 */     return logical;
/*     */   }
/*     */   
/*     */   public String getLogicalTableName(Table table) {
/* 520 */     return getLogicalTableName(table.getSchema(), table.getCatalog(), table.getName());
/*     */   }
/*     */   
/*     */   public static class ColumnNames implements Serializable
/*     */   {
/* 525 */     public Map logicalToPhysical = new HashMap();
/*     */     
/* 527 */     public Map physicalToLogical = new HashMap();
/*     */   }
/*     */   
/*     */   public static class TableDescription implements Serializable {
/*     */     public String logicalName;
/*     */     public Table denormalizedSupertable;
/*     */     
/* 534 */     public TableDescription(String logicalName, Table denormalizedSupertable) { this.logicalName = logicalName;
/* 535 */       this.denormalizedSupertable = denormalizedSupertable;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cfg\Mappings.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */