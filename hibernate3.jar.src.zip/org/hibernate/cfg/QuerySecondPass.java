package org.hibernate.cfg;

public abstract interface QuerySecondPass
  extends SecondPass
{}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cfg\QuerySecondPass.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */