/*    */ package org.hibernate.cfg;
/*    */ 
/*    */ import org.dom4j.Document;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExtendsQueueEntry
/*    */ {
/*    */   private final String explicitName;
/*    */   private final String mappingPackage;
/*    */   private final Document document;
/*    */   
/*    */   public ExtendsQueueEntry(String explicitName, String mappingPackage, Document document)
/*    */   {
/* 17 */     this.explicitName = explicitName;
/* 18 */     this.mappingPackage = mappingPackage;
/* 19 */     this.document = document;
/*    */   }
/*    */   
/*    */   public String getExplicitName() {
/* 23 */     return this.explicitName;
/*    */   }
/*    */   
/*    */   public String getMappingPackage() {
/* 27 */     return this.mappingPackage;
/*    */   }
/*    */   
/*    */   public Document getDocument() {
/* 31 */     return this.document;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cfg\ExtendsQueueEntry.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */