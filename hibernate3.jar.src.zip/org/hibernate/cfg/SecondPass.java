package org.hibernate.cfg;

import java.io.Serializable;
import java.util.Map;
import org.hibernate.MappingException;

public abstract interface SecondPass
  extends Serializable
{
  public abstract void doSecondPass(Map paramMap1, Map paramMap2)
    throws MappingException;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cfg\SecondPass.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */