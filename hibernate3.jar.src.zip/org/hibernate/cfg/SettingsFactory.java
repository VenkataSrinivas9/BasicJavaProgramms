/*     */ package org.hibernate.cfg;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.ConnectionReleaseMode;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.cache.CacheProvider;
/*     */ import org.hibernate.cache.NoCacheProvider;
/*     */ import org.hibernate.cache.QueryCacheFactory;
/*     */ import org.hibernate.connection.ConnectionProvider;
/*     */ import org.hibernate.connection.ConnectionProviderFactory;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.dialect.DialectFactory;
/*     */ import org.hibernate.exception.SQLExceptionConverter;
/*     */ import org.hibernate.exception.SQLExceptionConverterFactory;
/*     */ import org.hibernate.hql.QueryTranslatorFactory;
/*     */ import org.hibernate.jdbc.BatcherFactory;
/*     */ import org.hibernate.jdbc.BatchingBatcherFactory;
/*     */ import org.hibernate.jdbc.NonBatchingBatcherFactory;
/*     */ import org.hibernate.transaction.TransactionFactory;
/*     */ import org.hibernate.transaction.TransactionFactoryFactory;
/*     */ import org.hibernate.transaction.TransactionManagerLookup;
/*     */ import org.hibernate.transaction.TransactionManagerLookupFactory;
/*     */ import org.hibernate.util.PropertiesHelper;
/*     */ import org.hibernate.util.ReflectHelper;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SettingsFactory
/*     */   implements Serializable
/*     */ {
/*  46 */   private static final Log log = LogFactory.getLog(SettingsFactory.class);
/*     */   
/*     */   protected SettingsFactory() throws HibernateException
/*     */   {}
/*     */   
/*  51 */   public Settings buildSettings(Properties props) { Settings settings = new Settings();
/*     */     
/*     */ 
/*     */ 
/*  55 */     String sessionFactoryName = props.getProperty("hibernate.session_factory_name");
/*  56 */     settings.setSessionFactoryName(sessionFactoryName);
/*     */     
/*     */ 
/*     */ 
/*  60 */     ConnectionProvider connections = createConnectionProvider(props);
/*  61 */     settings.setConnectionProvider(connections);
/*     */     
/*     */ 
/*     */ 
/*  65 */     boolean metaSupportsScrollable = false;
/*  66 */     boolean metaSupportsGetGeneratedKeys = false;
/*  67 */     boolean metaSupportsBatchUpdates = false;
/*  68 */     String databaseName = null;
/*  69 */     int databaseMajorVersion = 0;
/*     */     try
/*     */     {
/*  72 */       Connection conn = connections.getConnection();
/*     */       try {
/*  74 */         DatabaseMetaData meta = conn.getMetaData();
/*  75 */         databaseName = meta.getDatabaseProductName();
/*  76 */         databaseMajorVersion = getDatabaseMajorVersion(meta);
/*  77 */         log.info("RDBMS: " + databaseName + ", version: " + meta.getDatabaseProductVersion());
/*  78 */         log.info("JDBC driver: " + meta.getDriverName() + ", version: " + meta.getDriverVersion());
/*     */         
/*  80 */         metaSupportsScrollable = meta.supportsResultSetType(1004);
/*  81 */         metaSupportsBatchUpdates = meta.supportsBatchUpdates();
/*     */         
/*  83 */         if (Environment.jvmSupportsGetGeneratedKeys()) {
/*     */           try {
/*  85 */             Boolean result = (Boolean)DatabaseMetaData.class.getMethod("supportsGetGeneratedKeys", null).invoke(meta, null);
/*     */             
/*  87 */             metaSupportsGetGeneratedKeys = result.booleanValue();
/*     */           }
/*     */           catch (AbstractMethodError ame) {
/*  90 */             metaSupportsGetGeneratedKeys = false;
/*     */           }
/*     */           catch (Exception e) {
/*  93 */             metaSupportsGetGeneratedKeys = false;
/*     */           }
/*     */         }
/*     */       }
/*     */       finally
/*     */       {
/*  99 */         connections.closeConnection(conn);
/*     */       }
/*     */     }
/*     */     catch (SQLException sqle) {
/* 103 */       log.warn("Could not obtain connection metadata", sqle);
/*     */     }
/*     */     catch (UnsupportedOperationException uoe) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 110 */     Dialect dialect = determineDialect(props, databaseName, databaseMajorVersion);
/* 111 */     settings.setDialect(dialect);
/*     */     
/*     */ 
/* 114 */     Properties properties = new Properties();
/* 115 */     properties.putAll(dialect.getDefaultProperties());
/* 116 */     properties.putAll(props);
/*     */     
/*     */ 
/*     */ 
/* 120 */     TransactionFactory transactionFactory = createTransactionFactory(properties);
/* 121 */     settings.setTransactionFactory(transactionFactory);
/* 122 */     settings.setTransactionManagerLookup(createTransactionManagerLookup(properties));
/*     */     
/* 124 */     boolean flushBeforeCompletion = PropertiesHelper.getBoolean("hibernate.transaction.flush_before_completion", properties);
/* 125 */     log.info("Automatic flush during beforeCompletion(): " + enabledDisabled(flushBeforeCompletion));
/* 126 */     settings.setFlushBeforeCompletionEnabled(flushBeforeCompletion);
/*     */     
/* 128 */     boolean autoCloseSession = PropertiesHelper.getBoolean("hibernate.transaction.auto_close_session", properties);
/* 129 */     log.info("Automatic session close at end of transaction: " + enabledDisabled(autoCloseSession));
/* 130 */     settings.setAutoCloseSessionEnabled(autoCloseSession);
/*     */     
/*     */ 
/*     */ 
/* 134 */     int batchSize = PropertiesHelper.getInt("hibernate.jdbc.batch_size", properties, 0);
/* 135 */     if (!metaSupportsBatchUpdates) batchSize = 0;
/* 136 */     if (batchSize > 0) log.info("JDBC batch size: " + batchSize);
/* 137 */     settings.setJdbcBatchSize(batchSize);
/* 138 */     boolean jdbcBatchVersionedData = PropertiesHelper.getBoolean("hibernate.jdbc.batch_versioned_data", properties, false);
/* 139 */     if (batchSize > 0) log.info("JDBC batch updates for versioned data: " + enabledDisabled(jdbcBatchVersionedData));
/* 140 */     settings.setJdbcBatchVersionedData(jdbcBatchVersionedData);
/* 141 */     settings.setBatcherFactory(createBatcherFactory(properties, batchSize));
/*     */     
/* 143 */     boolean useScrollableResultSets = PropertiesHelper.getBoolean("hibernate.jdbc.use_scrollable_resultset", properties, metaSupportsScrollable);
/* 144 */     log.info("Scrollable result sets: " + enabledDisabled(useScrollableResultSets));
/* 145 */     settings.setScrollableResultSetsEnabled(useScrollableResultSets);
/*     */     
/* 147 */     boolean wrapResultSets = PropertiesHelper.getBoolean("hibernate.jdbc.wrap_result_sets", properties, false);
/* 148 */     log.debug("Wrap result sets: " + enabledDisabled(wrapResultSets));
/* 149 */     settings.setWrapResultSetsEnabled(wrapResultSets);
/*     */     
/* 151 */     boolean useGetGeneratedKeys = PropertiesHelper.getBoolean("hibernate.jdbc.use_get_generated_keys", properties, metaSupportsGetGeneratedKeys);
/* 152 */     log.info("JDBC3 getGeneratedKeys(): " + enabledDisabled(useGetGeneratedKeys));
/* 153 */     settings.setGetGeneratedKeysEnabled(useGetGeneratedKeys);
/*     */     
/* 155 */     Integer statementFetchSize = PropertiesHelper.getInteger("hibernate.jdbc.fetch_size", properties);
/* 156 */     if (statementFetchSize != null) log.info("JDBC result set fetch size: " + statementFetchSize);
/* 157 */     settings.setJdbcFetchSize(statementFetchSize);
/*     */     
/* 159 */     String releaseModeName = PropertiesHelper.getString("hibernate.connection.release_mode", properties, "auto");
/* 160 */     log.info("Connection release mode: " + releaseModeName);
/*     */     ConnectionReleaseMode releaseMode;
/* 162 */     ConnectionReleaseMode releaseMode; if ("auto".equals(releaseModeName)) {
/* 163 */       releaseMode = transactionFactory.getDefaultReleaseMode();
/*     */     }
/*     */     else {
/* 166 */       releaseMode = ConnectionReleaseMode.parse(releaseModeName);
/* 167 */       if ((releaseMode == ConnectionReleaseMode.AFTER_STATEMENT) && (!connections.supportsAggressiveRelease())) {
/* 168 */         log.warn("Overriding release mode as connection provider does not support 'after_statement'");
/* 169 */         releaseMode = ConnectionReleaseMode.AFTER_TRANSACTION;
/*     */       }
/*     */     }
/* 172 */     settings.setConnectionReleaseMode(releaseMode);
/*     */     
/*     */ 
/*     */ 
/* 176 */     String defaultSchema = properties.getProperty("hibernate.default_schema");
/* 177 */     String defaultCatalog = properties.getProperty("hibernate.default_catalog");
/* 178 */     if (defaultSchema != null) log.info("Default schema: " + defaultSchema);
/* 179 */     if (defaultCatalog != null) log.info("Default catalog: " + defaultCatalog);
/* 180 */     settings.setDefaultSchemaName(defaultSchema);
/* 181 */     settings.setDefaultCatalogName(defaultCatalog);
/*     */     
/* 183 */     Integer maxFetchDepth = PropertiesHelper.getInteger("hibernate.max_fetch_depth", properties);
/* 184 */     if (maxFetchDepth != null) log.info("Maximum outer join fetch depth: " + maxFetchDepth);
/* 185 */     settings.setMaximumFetchDepth(maxFetchDepth);
/* 186 */     int batchFetchSize = PropertiesHelper.getInt("hibernate.default_batch_fetch_size", properties, 1);
/* 187 */     log.info("Default batch fetch size: " + batchFetchSize);
/* 188 */     settings.setDefaultBatchFetchSize(batchFetchSize);
/*     */     
/* 190 */     boolean comments = PropertiesHelper.getBoolean("hibernate.use_sql_comments", properties);
/* 191 */     log.info("Generate SQL with comments: " + enabledDisabled(comments));
/* 192 */     settings.setCommentsEnabled(comments);
/*     */     
/* 194 */     boolean orderUpdates = PropertiesHelper.getBoolean("hibernate.order_updates", properties);
/* 195 */     log.info("Order SQL updates by primary key: " + enabledDisabled(orderUpdates));
/* 196 */     settings.setOrderUpdatesEnabled(orderUpdates);
/*     */     
/*     */ 
/*     */ 
/* 200 */     settings.setQueryTranslatorFactory(createQueryTranslatorFactory(properties));
/*     */     
/* 202 */     Map querySubstitutions = PropertiesHelper.toMap("hibernate.query.substitutions", " ,=;:\n\t\r\f", properties);
/* 203 */     log.info("Query language substitutions: " + querySubstitutions);
/* 204 */     settings.setQuerySubstitutions(querySubstitutions);
/*     */     
/*     */ 
/*     */ 
/* 208 */     boolean useSecondLevelCache = PropertiesHelper.getBoolean("hibernate.cache.use_second_level_cache", properties, true);
/* 209 */     log.info("Second-level cache: " + enabledDisabled(useSecondLevelCache));
/* 210 */     settings.setSecondLevelCacheEnabled(useSecondLevelCache);
/*     */     
/* 212 */     boolean useQueryCache = PropertiesHelper.getBoolean("hibernate.cache.use_query_cache", properties);
/* 213 */     log.info("Query cache: " + enabledDisabled(useQueryCache));
/* 214 */     settings.setQueryCacheEnabled(useQueryCache);
/*     */     
/* 216 */     if ((useSecondLevelCache) || (useQueryCache))
/*     */     {
/*     */ 
/* 219 */       settings.setCacheProvider(createCacheProvider(properties));
/*     */     }
/*     */     else {
/* 222 */       settings.setCacheProvider(new NoCacheProvider());
/*     */     }
/*     */     
/* 225 */     boolean useMinimalPuts = PropertiesHelper.getBoolean("hibernate.cache.use_minimal_puts", properties, settings.getCacheProvider().isMinimalPutsEnabledByDefault());
/*     */     
/*     */ 
/* 228 */     log.info("Optimize cache for minimal puts: " + enabledDisabled(useMinimalPuts));
/* 229 */     settings.setMinimalPutsEnabled(useMinimalPuts);
/*     */     
/* 231 */     String prefix = properties.getProperty("hibernate.cache.region_prefix");
/* 232 */     if (StringHelper.isEmpty(prefix)) prefix = null;
/* 233 */     if (prefix != null) log.info("Cache region prefix: " + prefix);
/* 234 */     settings.setCacheRegionPrefix(prefix);
/*     */     
/* 236 */     boolean useStructuredCacheEntries = PropertiesHelper.getBoolean("hibernate.cache.use_structured_entries", properties, false);
/* 237 */     log.info("Structured second-level cache entries: " + enabledDisabled(useStructuredCacheEntries));
/* 238 */     settings.setStructuredCacheEntriesEnabled(useStructuredCacheEntries);
/*     */     
/* 240 */     if (useQueryCache) { settings.setQueryCacheFactory(createQueryCacheFactory(properties));
/*     */     }
/*     */     
/*     */     SQLExceptionConverter sqlExceptionConverter;
/*     */     try
/*     */     {
/* 246 */       sqlExceptionConverter = SQLExceptionConverterFactory.buildSQLExceptionConverter(dialect, properties);
/*     */     } catch (HibernateException e) {
/*     */       SQLExceptionConverter sqlExceptionConverter;
/* 249 */       log.warn("Error building SQLExceptionConverter; using minimal converter");
/* 250 */       sqlExceptionConverter = SQLExceptionConverterFactory.buildMinimalSQLExceptionConverter();
/*     */     }
/* 252 */     settings.setSQLExceptionConverter(sqlExceptionConverter);
/*     */     
/*     */ 
/*     */ 
/* 256 */     boolean showSql = PropertiesHelper.getBoolean("hibernate.show_sql", properties);
/* 257 */     if (showSql) log.info("Echoing all SQL to stdout");
/* 258 */     settings.setShowSqlEnabled(showSql);
/*     */     
/* 260 */     boolean formatSql = PropertiesHelper.getBoolean("hibernate.format_sql", properties);
/* 261 */     settings.setFormatSqlEnabled(formatSql);
/*     */     
/* 263 */     boolean useStatistics = PropertiesHelper.getBoolean("hibernate.generate_statistics", properties);
/* 264 */     log.info("Statistics: " + enabledDisabled(useStatistics));
/* 265 */     settings.setStatisticsEnabled(useStatistics);
/*     */     
/* 267 */     boolean useIdentifierRollback = PropertiesHelper.getBoolean("hibernate.use_identifier_rollback", properties);
/* 268 */     log.info("Deleted entity synthetic identifier rollback: " + enabledDisabled(useIdentifierRollback));
/* 269 */     settings.setIdentifierRollbackEnabled(useIdentifierRollback);
/*     */     
/*     */ 
/*     */ 
/* 273 */     String autoSchemaExport = properties.getProperty("hibernate.hbm2ddl.auto");
/* 274 */     if ("validate".equals(autoSchemaExport)) settings.setAutoValidateSchema(true);
/* 275 */     if ("update".equals(autoSchemaExport)) settings.setAutoUpdateSchema(true);
/* 276 */     if ("create".equals(autoSchemaExport)) settings.setAutoCreateSchema(true);
/* 277 */     if ("create-drop".equals(autoSchemaExport)) {
/* 278 */       settings.setAutoCreateSchema(true);
/* 279 */       settings.setAutoDropSchema(true);
/*     */     }
/*     */     
/* 282 */     EntityMode defaultEntityMode = EntityMode.parse(properties.getProperty("hibernate.default_entity_mode"));
/* 283 */     log.info("Default entity-mode: " + defaultEntityMode);
/* 284 */     settings.setDefaultEntityMode(defaultEntityMode);
/*     */     
/* 286 */     return settings;
/*     */   }
/*     */   
/*     */   private int getDatabaseMajorVersion(DatabaseMetaData meta)
/*     */   {
/*     */     try {
/* 292 */       Method gdbmvMethod = DatabaseMetaData.class.getMethod("getDatabaseMajorVersion", null);
/* 293 */       return ((Integer)gdbmvMethod.invoke(meta, null)).intValue();
/*     */     }
/*     */     catch (NoSuchMethodException nsme) {
/* 296 */       return 0;
/*     */     }
/*     */     catch (Throwable t) {
/* 299 */       log.debug("could not get database version from JDBC metadata"); }
/* 300 */     return 0;
/*     */   }
/*     */   
/*     */   private static final String enabledDisabled(boolean value)
/*     */   {
/* 305 */     return value ? "enabled" : "disabled";
/*     */   }
/*     */   
/*     */   protected QueryCacheFactory createQueryCacheFactory(Properties properties) {
/* 309 */     String queryCacheFactoryClassName = PropertiesHelper.getString("hibernate.cache.query_cache_factory", properties, "org.hibernate.cache.StandardQueryCacheFactory");
/*     */     
/*     */ 
/* 312 */     log.info("Query cache factory: " + queryCacheFactoryClassName);
/*     */     try {
/* 314 */       return (QueryCacheFactory)ReflectHelper.classForName(queryCacheFactoryClassName).newInstance();
/*     */     }
/*     */     catch (Exception cnfe) {
/* 317 */       throw new HibernateException("could not instantiate QueryCacheFactory: " + queryCacheFactoryClassName, cnfe);
/*     */     }
/*     */   }
/*     */   
/*     */   protected CacheProvider createCacheProvider(Properties properties) {
/* 322 */     String cacheClassName = PropertiesHelper.getString("hibernate.cache.provider_class", properties, "org.hibernate.cache.EhCacheProvider");
/*     */     
/*     */ 
/* 325 */     log.info("Cache provider: " + cacheClassName);
/*     */     try {
/* 327 */       return (CacheProvider)ReflectHelper.classForName(cacheClassName).newInstance();
/*     */     }
/*     */     catch (Exception cnfe) {
/* 330 */       throw new HibernateException("could not instantiate CacheProvider: " + cacheClassName, cnfe);
/*     */     }
/*     */   }
/*     */   
/*     */   protected QueryTranslatorFactory createQueryTranslatorFactory(Properties properties) {
/* 335 */     String className = PropertiesHelper.getString("hibernate.query.factory_class", properties, "org.hibernate.hql.ast.ASTQueryTranslatorFactory");
/*     */     
/*     */ 
/* 338 */     log.info("Query translator: " + className);
/*     */     try {
/* 340 */       return (QueryTranslatorFactory)ReflectHelper.classForName(className).newInstance();
/*     */     }
/*     */     catch (Exception cnfe) {
/* 343 */       throw new HibernateException("could not instantiate QueryTranslatorFactory: " + className, cnfe);
/*     */     }
/*     */   }
/*     */   
/*     */   protected BatcherFactory createBatcherFactory(Properties properties, int batchSize) {
/* 348 */     String batcherClass = properties.getProperty("hibernate.jdbc.factory_class");
/* 349 */     if (batcherClass == null) {
/* 350 */       return batchSize == 0 ? new NonBatchingBatcherFactory() : new BatchingBatcherFactory();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 355 */     log.info("Batcher factory: " + batcherClass);
/*     */     try {
/* 357 */       return (BatcherFactory)ReflectHelper.classForName(batcherClass).newInstance();
/*     */     }
/*     */     catch (Exception cnfe) {
/* 360 */       throw new HibernateException("could not instantiate BatcherFactory: " + batcherClass, cnfe);
/*     */     }
/*     */   }
/*     */   
/*     */   protected ConnectionProvider createConnectionProvider(Properties properties)
/*     */   {
/* 366 */     return ConnectionProviderFactory.newConnectionProvider(properties);
/*     */   }
/*     */   
/*     */   protected TransactionFactory createTransactionFactory(Properties properties) {
/* 370 */     return TransactionFactoryFactory.buildTransactionFactory(properties);
/*     */   }
/*     */   
/*     */   protected TransactionManagerLookup createTransactionManagerLookup(Properties properties) {
/* 374 */     return TransactionManagerLookupFactory.getTransactionManagerLookup(properties);
/*     */   }
/*     */   
/*     */   private Dialect determineDialect(Properties props, String databaseName, int databaseMajorVersion) {
/* 378 */     return DialectFactory.buildDialect(props, databaseName, databaseMajorVersion);
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cfg\SettingsFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */