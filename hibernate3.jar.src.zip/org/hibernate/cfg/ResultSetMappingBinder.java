/*     */ package org.hibernate.cfg;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.dom4j.Attribute;
/*     */ import org.dom4j.Element;
/*     */ import org.hibernate.LockMode;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.engine.ResultSetMappingDefinition;
/*     */ import org.hibernate.loader.custom.SQLQueryCollectionReturn;
/*     */ import org.hibernate.loader.custom.SQLQueryJoinReturn;
/*     */ import org.hibernate.loader.custom.SQLQueryRootReturn;
/*     */ import org.hibernate.loader.custom.SQLQueryScalarReturn;
/*     */ import org.hibernate.mapping.Component;
/*     */ import org.hibernate.mapping.PersistentClass;
/*     */ import org.hibernate.mapping.Property;
/*     */ import org.hibernate.mapping.ToOne;
/*     */ import org.hibernate.mapping.Value;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.type.TypeFactory;
/*     */ import org.hibernate.util.ArrayHelper;
/*     */ import org.hibernate.util.CollectionHelper;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ public abstract class ResultSetMappingBinder
/*     */ {
/*     */   protected static ResultSetMappingDefinition buildResultSetMappingDefinition(Element resultSetElem, String path, Mappings mappings)
/*     */   {
/*  36 */     String resultSetName = resultSetElem.attribute("name").getValue();
/*  37 */     if (path != null) resultSetName = path + '.' + resultSetName;
/*  38 */     ResultSetMappingDefinition definition = new ResultSetMappingDefinition(resultSetName);
/*  39 */     Iterator returns = resultSetElem.elementIterator("return-scalar");
/*  40 */     while (returns.hasNext()) {
/*  41 */       Element returnElem = (Element)returns.next();
/*  42 */       String column = returnElem.attributeValue("column");
/*  43 */       String typeFromXML = HbmBinder.getTypeFromXML(returnElem);
/*  44 */       Type type = null;
/*  45 */       if (typeFromXML != null) {
/*  46 */         type = TypeFactory.heuristicType(typeFromXML);
/*  47 */         if (type == null) {
/*  48 */           throw new MappingException("could not determine type " + type);
/*     */         }
/*     */       }
/*  51 */       definition.addScalarQueryReturn(new SQLQueryScalarReturn(column, type));
/*     */     }
/*  53 */     returns = resultSetElem.elementIterator();
/*  54 */     int cnt = 0;
/*  55 */     while (returns.hasNext()) {
/*  56 */       cnt++;
/*  57 */       Element returnElem = (Element)returns.next();
/*  58 */       String name = returnElem.getName();
/*  59 */       if ("return".equals(name)) {
/*  60 */         definition.addEntityQueryReturn(bindReturn(returnElem, mappings, cnt));
/*     */       }
/*  62 */       else if ("return-join".equals(name)) {
/*  63 */         definition.addEntityQueryReturn(bindReturnJoin(returnElem, mappings));
/*     */       }
/*  65 */       else if ("load-collection".equals(name)) {
/*  66 */         definition.addEntityQueryReturn(bindLoadCollection(returnElem, mappings));
/*     */       }
/*     */     }
/*  69 */     return definition;
/*     */   }
/*     */   
/*     */   private static SQLQueryRootReturn bindReturn(Element returnElem, Mappings mappings, int elementCount) {
/*  73 */     String alias = returnElem.attributeValue("alias");
/*  74 */     if (StringHelper.isEmpty(alias)) {
/*  75 */       alias = "alias_" + elementCount;
/*     */     }
/*     */     
/*  78 */     String entityName = HbmBinder.getEntityName(returnElem, mappings);
/*  79 */     if (entityName == null) {
/*  80 */       throw new MappingException("<return alias='" + alias + "'> must specify either a class or entity-name");
/*     */     }
/*  82 */     LockMode lockMode = getLockMode(returnElem.attributeValue("lock-mode"));
/*     */     
/*  84 */     PersistentClass pc = mappings.getClass(entityName);
/*  85 */     Map propertyResults = bindPropertyResults(alias, returnElem, pc, mappings);
/*     */     
/*  87 */     return new SQLQueryRootReturn(alias, entityName, propertyResults, lockMode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static SQLQueryJoinReturn bindReturnJoin(Element returnElem, Mappings mappings)
/*     */   {
/*  96 */     String alias = returnElem.attributeValue("alias");
/*  97 */     String roleAttribute = returnElem.attributeValue("property");
/*  98 */     LockMode lockMode = getLockMode(returnElem.attributeValue("lock-mode"));
/*  99 */     int dot = roleAttribute.lastIndexOf('.');
/* 100 */     if (dot == -1) {
/* 101 */       throw new MappingException("Role attribute for sql query return [alias=" + alias + "] not formatted correctly {owningAlias.propertyName}");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 106 */     String roleOwnerAlias = roleAttribute.substring(0, dot);
/* 107 */     String roleProperty = roleAttribute.substring(dot + 1);
/*     */     
/*     */ 
/* 110 */     Map propertyResults = bindPropertyResults(alias, returnElem, null, mappings);
/*     */     
/* 112 */     return new SQLQueryJoinReturn(alias, roleOwnerAlias, roleProperty, propertyResults, lockMode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static SQLQueryCollectionReturn bindLoadCollection(Element returnElem, Mappings mappings)
/*     */   {
/* 122 */     String alias = returnElem.attributeValue("alias");
/* 123 */     String collectionAttribute = returnElem.attributeValue("role");
/* 124 */     LockMode lockMode = getLockMode(returnElem.attributeValue("lock-mode"));
/* 125 */     int dot = collectionAttribute.lastIndexOf('.');
/* 126 */     if (dot == -1) {
/* 127 */       throw new MappingException("Collection attribute for sql query return [alias=" + alias + "] not formatted correctly {OwnerClassName.propertyName}");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 132 */     String ownerClassName = HbmBinder.getClassName(collectionAttribute.substring(0, dot), mappings);
/* 133 */     String ownerPropertyName = collectionAttribute.substring(dot + 1);
/*     */     
/*     */ 
/* 136 */     Map propertyResults = bindPropertyResults(alias, returnElem, null, mappings);
/*     */     
/* 138 */     return new SQLQueryCollectionReturn(alias, ownerClassName, ownerPropertyName, propertyResults, lockMode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Map bindPropertyResults(String alias, Element returnElement, PersistentClass pc, Mappings mappings)
/*     */   {
/* 151 */     HashMap propertyresults = new HashMap();
/*     */     
/* 153 */     Element discriminatorResult = returnElement.element("return-discriminator");
/* 154 */     if (discriminatorResult != null) {
/* 155 */       ArrayList resultColumns = getResultColumns(discriminatorResult);
/* 156 */       propertyresults.put("class", ArrayHelper.toStringArray(resultColumns));
/*     */     }
/* 158 */     Iterator iterator = returnElement.elementIterator("return-property");
/* 159 */     List properties = new ArrayList();
/* 160 */     List propertyNames = new ArrayList();
/* 161 */     while (iterator.hasNext()) {
/* 162 */       Element propertyresult = (Element)iterator.next();
/* 163 */       String name = propertyresult.attributeValue("name");
/* 164 */       if ((pc == null) || (name.indexOf('.') == -1))
/*     */       {
/* 166 */         properties.add(propertyresult);
/* 167 */         propertyNames.add(name);
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/* 176 */         if (pc == null)
/* 177 */           throw new MappingException("dotted notation in <return-join> or <load_collection> not yet supported");
/* 178 */         int dotIndex = name.lastIndexOf('.');
/* 179 */         String reducedName = name.substring(0, dotIndex);
/* 180 */         Value value = pc.getRecursiveProperty(reducedName).getValue();
/*     */         Iterator parentPropIter;
/* 182 */         Iterator parentPropIter; if ((value instanceof Component)) {
/* 183 */           Component comp = (Component)value;
/* 184 */           parentPropIter = comp.getPropertyIterator();
/*     */         }
/* 186 */         else if ((value instanceof ToOne)) {
/* 187 */           ToOne toOne = (ToOne)value;
/* 188 */           PersistentClass referencedPc = mappings.getClass(toOne.getReferencedEntityName());
/* 189 */           if (toOne.getReferencedPropertyName() != null) {
/*     */             try {
/* 191 */               parentPropIter = ((Component)referencedPc.getRecursiveProperty(toOne.getReferencedPropertyName()).getValue()).getPropertyIterator();
/*     */             } catch (ClassCastException e) { Iterator parentPropIter;
/* 193 */               throw new MappingException("dotted notation reference neither a component nor a many/one to one", e);
/*     */             }
/*     */           } else {
/*     */             try {
/*     */               Iterator parentPropIter;
/* 198 */               if (referencedPc.getIdentifierMapper() == null) {
/* 199 */                 parentPropIter = ((Component)referencedPc.getIdentifierProperty().getValue()).getPropertyIterator();
/*     */               }
/*     */               else {
/* 202 */                 parentPropIter = referencedPc.getIdentifierMapper().getPropertyIterator();
/*     */               }
/*     */             }
/*     */             catch (ClassCastException e) {
/* 206 */               throw new MappingException("dotted notation reference neither a component nor a many/one to one", e);
/*     */             }
/*     */           }
/*     */         }
/*     */         else {
/* 211 */           throw new MappingException("dotted notation reference neither a component nor a many/one to one");
/*     */         }
/* 213 */         boolean hasFollowers = false;
/* 214 */         List followers = new ArrayList();
/* 215 */         while (parentPropIter.hasNext()) {
/* 216 */           String currentPropertyName = ((Property)parentPropIter.next()).getName();
/* 217 */           String currentName = reducedName + '.' + currentPropertyName;
/* 218 */           if (hasFollowers) {
/* 219 */             followers.add(currentName);
/*     */           }
/* 221 */           if (name.equals(currentName)) { hasFollowers = true;
/*     */           }
/*     */         }
/* 224 */         int index = propertyNames.size();
/* 225 */         int followersSize = followers.size();
/* 226 */         for (int loop = 0; loop < followersSize; loop++) {
/* 227 */           String follower = (String)followers.get(loop);
/* 228 */           int currentIndex = getIndexOfFirstMatchingProperty(propertyNames, follower);
/* 229 */           index = (currentIndex != -1) && (currentIndex < index) ? currentIndex : index;
/*     */         }
/* 231 */         propertyNames.add(index, name);
/* 232 */         properties.add(index, propertyresult);
/*     */       }
/*     */     }
/*     */     
/* 236 */     Set uniqueReturnProperty = new HashSet();
/* 237 */     iterator = properties.iterator();
/* 238 */     while (iterator.hasNext()) {
/* 239 */       Element propertyresult = (Element)iterator.next();
/* 240 */       String name = propertyresult.attributeValue("name");
/* 241 */       if ("class".equals(name)) {
/* 242 */         throw new MappingException("class is not a valid property name to use in a <return-property>, use <return-discriminator> instead");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 247 */       ArrayList allResultColumns = getResultColumns(propertyresult);
/*     */       
/* 249 */       if (allResultColumns.isEmpty()) {
/* 250 */         throw new MappingException("return-property for alias " + alias + " must specify at least one column or return-column name");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 255 */       if (uniqueReturnProperty.contains(name)) {
/* 256 */         throw new MappingException("duplicate return-property for property " + name + " on alias " + alias);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 261 */       uniqueReturnProperty.add(name);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 284 */       String key = name;
/* 285 */       ArrayList intermediateResults = (ArrayList)propertyresults.get(key);
/* 286 */       if (intermediateResults == null) {
/* 287 */         propertyresults.put(key, allResultColumns);
/*     */       }
/*     */       else {
/* 290 */         intermediateResults.addAll(allResultColumns);
/*     */       }
/*     */     }
/*     */     
/* 294 */     Iterator entries = propertyresults.entrySet().iterator();
/* 295 */     while (entries.hasNext()) {
/* 296 */       Map.Entry entry = (Map.Entry)entries.next();
/* 297 */       if ((entry.getValue() instanceof ArrayList)) {
/* 298 */         ArrayList list = (ArrayList)entry.getValue();
/* 299 */         entry.setValue(list.toArray(new String[list.size()]));
/*     */       }
/*     */     }
/* 302 */     return propertyresults.isEmpty() ? CollectionHelper.EMPTY_MAP : propertyresults;
/*     */   }
/*     */   
/*     */   private static int getIndexOfFirstMatchingProperty(List propertyNames, String follower) {
/* 306 */     int propertySize = propertyNames.size();
/* 307 */     for (int propIndex = 0; propIndex < propertySize; propIndex++) {
/* 308 */       if (((String)propertyNames.get(propIndex)).startsWith(follower)) {
/* 309 */         return propIndex;
/*     */       }
/*     */     }
/* 312 */     return -1;
/*     */   }
/*     */   
/*     */   private static ArrayList getResultColumns(Element propertyresult) {
/* 316 */     String column = unquote(propertyresult.attributeValue("column"));
/* 317 */     ArrayList allResultColumns = new ArrayList();
/* 318 */     if (column != null) allResultColumns.add(column);
/* 319 */     Iterator resultColumns = propertyresult.elementIterator("return-column");
/* 320 */     while (resultColumns.hasNext()) {
/* 321 */       Element element = (Element)resultColumns.next();
/* 322 */       allResultColumns.add(unquote(element.attributeValue("name")));
/*     */     }
/* 324 */     return allResultColumns;
/*     */   }
/*     */   
/*     */   private static String unquote(String name) {
/* 328 */     if ((name != null) && (name.charAt(0) == '`')) {
/* 329 */       name = name.substring(1, name.length() - 1);
/*     */     }
/* 331 */     return name;
/*     */   }
/*     */   
/*     */   private static final LockMode getLockMode(String lockMode) {
/* 335 */     if ((lockMode == null) || ("read".equals(lockMode))) {
/* 336 */       return LockMode.READ;
/*     */     }
/* 338 */     if ("none".equals(lockMode)) {
/* 339 */       return LockMode.NONE;
/*     */     }
/* 341 */     if ("upgrade".equals(lockMode)) {
/* 342 */       return LockMode.UPGRADE;
/*     */     }
/* 344 */     if ("upgrade-nowait".equals(lockMode)) {
/* 345 */       return LockMode.UPGRADE_NOWAIT;
/*     */     }
/* 347 */     if ("upgrade-nowait".equals(lockMode)) {
/* 348 */       return LockMode.UPGRADE_NOWAIT;
/*     */     }
/* 350 */     if ("write".equals(lockMode)) {
/* 351 */       return LockMode.WRITE;
/*     */     }
/*     */     
/* 354 */     throw new MappingException("unknown lockmode");
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cfg\ResultSetMappingBinder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */