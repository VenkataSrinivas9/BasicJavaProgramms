/*     */ package org.hibernate.cfg;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultNamingStrategy
/*     */   implements NamingStrategy, Serializable
/*     */ {
/*  19 */   public static final NamingStrategy INSTANCE = new DefaultNamingStrategy();
/*     */   
/*     */ 
/*     */ 
/*     */   public String classToTableName(String className)
/*     */   {
/*  25 */     return StringHelper.unqualify(className);
/*     */   }
/*     */   
/*     */ 
/*     */   public String propertyToColumnName(String propertyName)
/*     */   {
/*  31 */     return StringHelper.unqualify(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */   public String tableName(String tableName)
/*     */   {
/*  37 */     return tableName;
/*     */   }
/*     */   
/*     */ 
/*     */   public String columnName(String columnName)
/*     */   {
/*  43 */     return columnName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String collectionTableName(String ownerEntityTable, String associatedEntityTable, String propertyName)
/*     */   {
/*  51 */     return StringHelper.unqualify(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String joinKeyColumnName(String joinedColumn, String joinedTable)
/*     */   {
/*  58 */     return columnName(joinedColumn);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String foreignKeyColumnName(String propertyName, String propertyTableName, String referencedColumnName)
/*     */   {
/*  65 */     String header = propertyName != null ? StringHelper.unqualify(propertyName) : propertyTableName;
/*  66 */     if (header == null) throw new AssertionFailure("NammingStrategy not properly filled");
/*  67 */     return columnName(header);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String logicalColumnName(String columnName, String propertyName)
/*     */   {
/*  74 */     return StringHelper.isNotEmpty(columnName) ? columnName : StringHelper.unqualify(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String logicalCollectionTableName(String tableName, String ownerEntityTable, String associatedEntityTable, String propertyName)
/*     */   {
/*  85 */     if (tableName != null) {
/*  86 */       return tableName;
/*     */     }
/*     */     
/*     */ 
/*  90 */     return ownerEntityTable + "_" + (associatedEntityTable != null ? associatedEntityTable : StringHelper.unqualify(propertyName));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String logicalCollectionColumnName(String columnName, String propertyName, String referencedColumn)
/*     */   {
/* 103 */     return propertyName + "_" + referencedColumn;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cfg\DefaultNamingStrategy.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */