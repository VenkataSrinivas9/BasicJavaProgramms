/*      */ package org.hibernate.cfg;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.StringTokenizer;
/*      */ import org.apache.commons.collections.SequencedHashMap;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.dom4j.Attribute;
/*      */ import org.dom4j.Document;
/*      */ import org.dom4j.Element;
/*      */ import org.hibernate.CacheMode;
/*      */ import org.hibernate.EntityMode;
/*      */ import org.hibernate.FetchMode;
/*      */ import org.hibernate.FlushMode;
/*      */ import org.hibernate.MappingException;
/*      */ import org.hibernate.engine.FilterDefinition;
/*      */ import org.hibernate.engine.NamedQueryDefinition;
/*      */ import org.hibernate.mapping.Any;
/*      */ import org.hibernate.mapping.Array;
/*      */ import org.hibernate.mapping.AuxiliaryDatabaseObject;
/*      */ import org.hibernate.mapping.Backref;
/*      */ import org.hibernate.mapping.Bag;
/*      */ import org.hibernate.mapping.Collection;
/*      */ import org.hibernate.mapping.Column;
/*      */ import org.hibernate.mapping.Component;
/*      */ import org.hibernate.mapping.DependantValue;
/*      */ import org.hibernate.mapping.Fetchable;
/*      */ import org.hibernate.mapping.Filterable;
/*      */ import org.hibernate.mapping.Formula;
/*      */ import org.hibernate.mapping.IdentifierCollection;
/*      */ import org.hibernate.mapping.Index;
/*      */ import org.hibernate.mapping.IndexBackref;
/*      */ import org.hibernate.mapping.Join;
/*      */ import org.hibernate.mapping.JoinedSubclass;
/*      */ import org.hibernate.mapping.KeyValue;
/*      */ import org.hibernate.mapping.ManyToOne;
/*      */ import org.hibernate.mapping.MetaAttribute;
/*      */ import org.hibernate.mapping.OneToMany;
/*      */ import org.hibernate.mapping.OneToOne;
/*      */ import org.hibernate.mapping.PersistentClass;
/*      */ import org.hibernate.mapping.Property;
/*      */ import org.hibernate.mapping.PropertyGeneration;
/*      */ import org.hibernate.mapping.RootClass;
/*      */ import org.hibernate.mapping.Selectable;
/*      */ import org.hibernate.mapping.SimpleAuxiliaryDatabaseObject;
/*      */ import org.hibernate.mapping.SimpleValue;
/*      */ import org.hibernate.mapping.SingleTableSubclass;
/*      */ import org.hibernate.mapping.Subclass;
/*      */ import org.hibernate.mapping.Table;
/*      */ import org.hibernate.mapping.ToOne;
/*      */ import org.hibernate.mapping.TypeDef;
/*      */ import org.hibernate.mapping.UnionSubclass;
/*      */ import org.hibernate.mapping.UniqueKey;
/*      */ import org.hibernate.mapping.Value;
/*      */ import org.hibernate.persister.entity.JoinedSubclassEntityPersister;
/*      */ import org.hibernate.persister.entity.SingleTableEntityPersister;
/*      */ import org.hibernate.persister.entity.UnionSubclassEntityPersister;
/*      */ import org.hibernate.type.DiscriminatorType;
/*      */ import org.hibernate.type.ForeignKeyDirection;
/*      */ import org.hibernate.type.Type;
/*      */ import org.hibernate.type.TypeFactory;
/*      */ import org.hibernate.util.JoinedIterator;
/*      */ import org.hibernate.util.ReflectHelper;
/*      */ import org.hibernate.util.StringHelper;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class HbmBinder
/*      */ {
/*   87 */   private static final Log log = LogFactory.getLog(HbmBinder.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void bindRoot(Document doc, Mappings mappings, java.util.Map inheritedMetas)
/*      */     throws MappingException
/*      */   {
/*  107 */     java.util.List names = getExtendsNeeded(doc, mappings);
/*  108 */     if (!names.isEmpty())
/*      */     {
/*  110 */       Element hmNode = doc.getRootElement();
/*  111 */       Attribute packNode = hmNode.attribute("package");
/*  112 */       String packageName = null;
/*  113 */       if (packNode != null) {
/*  114 */         packageName = packNode.getValue();
/*      */       }
/*  116 */       Iterator itr = names.iterator();
/*  117 */       while (itr.hasNext()) {
/*  118 */         String extendsName = (String)itr.next();
/*  119 */         mappings.addToExtendsQueue(new ExtendsQueueEntry(extendsName, packageName, doc));
/*      */       }
/*  121 */       return;
/*      */     }
/*      */     
/*  124 */     Element hmNode = doc.getRootElement();
/*  125 */     inheritedMetas = getMetas(hmNode, inheritedMetas, true);
/*      */     
/*  127 */     extractRootAttributes(hmNode, mappings);
/*      */     
/*  129 */     Iterator filterDefs = hmNode.elementIterator("filter-def");
/*  130 */     while (filterDefs.hasNext()) {
/*  131 */       parseFilterDef((Element)filterDefs.next(), mappings);
/*      */     }
/*      */     
/*  134 */     Iterator typeDefs = hmNode.elementIterator("typedef");
/*  135 */     while (typeDefs.hasNext()) {
/*  136 */       Element typeDef = (Element)typeDefs.next();
/*  137 */       String typeClass = typeDef.attributeValue("class");
/*  138 */       String typeName = typeDef.attributeValue("name");
/*  139 */       Iterator paramIter = typeDef.elementIterator("param");
/*  140 */       Properties parameters = new Properties();
/*  141 */       while (paramIter.hasNext()) {
/*  142 */         Element param = (Element)paramIter.next();
/*  143 */         parameters.setProperty(param.attributeValue("name"), param.getTextTrim());
/*      */       }
/*      */       
/*  146 */       mappings.addTypeDef(typeName, typeClass, parameters);
/*      */     }
/*      */     
/*  149 */     Iterator nodes = hmNode.elementIterator("class");
/*  150 */     while (nodes.hasNext()) {
/*  151 */       Element n = (Element)nodes.next();
/*  152 */       RootClass rootclass = new RootClass();
/*  153 */       bindRootClass(n, rootclass, mappings, inheritedMetas);
/*  154 */       mappings.addClass(rootclass);
/*      */     }
/*      */     
/*  157 */     Iterator subclassnodes = hmNode.elementIterator("subclass");
/*  158 */     while (subclassnodes.hasNext()) {
/*  159 */       Element subnode = (Element)subclassnodes.next();
/*  160 */       PersistentClass superModel = getSuperclass(mappings, subnode);
/*  161 */       handleSubclass(superModel, mappings, subnode, inheritedMetas);
/*      */     }
/*      */     
/*  164 */     Iterator joinedsubclassnodes = hmNode.elementIterator("joined-subclass");
/*  165 */     while (joinedsubclassnodes.hasNext()) {
/*  166 */       Element subnode = (Element)joinedsubclassnodes.next();
/*  167 */       PersistentClass superModel = getSuperclass(mappings, subnode);
/*  168 */       handleJoinedSubclass(superModel, mappings, subnode, inheritedMetas);
/*      */     }
/*      */     
/*  171 */     Iterator unionsubclassnodes = hmNode.elementIterator("union-subclass");
/*  172 */     while (unionsubclassnodes.hasNext()) {
/*  173 */       Element subnode = (Element)unionsubclassnodes.next();
/*  174 */       PersistentClass superModel = getSuperclass(mappings, subnode);
/*  175 */       handleUnionSubclass(superModel, mappings, subnode, inheritedMetas);
/*      */     }
/*      */     
/*  178 */     nodes = hmNode.elementIterator("query");
/*  179 */     while (nodes.hasNext()) {
/*  180 */       bindNamedQuery((Element)nodes.next(), null, mappings);
/*      */     }
/*      */     
/*  183 */     nodes = hmNode.elementIterator("sql-query");
/*  184 */     while (nodes.hasNext()) {
/*  185 */       bindNamedSQLQuery((Element)nodes.next(), null, mappings);
/*      */     }
/*      */     
/*  188 */     nodes = hmNode.elementIterator("resultset");
/*  189 */     while (nodes.hasNext()) {
/*  190 */       bindResultSetMappingDefinition((Element)nodes.next(), null, mappings);
/*      */     }
/*      */     
/*  193 */     nodes = hmNode.elementIterator("import");
/*  194 */     while (nodes.hasNext()) {
/*  195 */       Element n = (Element)nodes.next();
/*  196 */       String className = getClassName(n.attribute("class"), mappings);
/*  197 */       Attribute renameNode = n.attribute("rename");
/*  198 */       String rename = renameNode == null ? StringHelper.unqualify(className) : renameNode.getValue();
/*      */       
/*      */ 
/*  201 */       log.debug("Import: " + rename + " -> " + className);
/*  202 */       mappings.addImport(className, rename);
/*      */     }
/*      */     
/*  205 */     nodes = hmNode.elementIterator("database-object");
/*  206 */     while (nodes.hasNext()) {
/*  207 */       Element auxDbObjectNode = (Element)nodes.next();
/*  208 */       AuxiliaryDatabaseObject auxDbObject = null;
/*  209 */       Element definitionNode = auxDbObjectNode.element("definition");
/*  210 */       if (definitionNode != null) {
/*      */         try {
/*  212 */           auxDbObject = (AuxiliaryDatabaseObject)ReflectHelper.classForName(definitionNode.attributeValue("class")).newInstance();
/*      */ 
/*      */         }
/*      */         catch (ClassNotFoundException e)
/*      */         {
/*  217 */           throw new MappingException("could not locate custom database object class [" + definitionNode.attributeValue("class") + "]");
/*      */ 
/*      */         }
/*      */         catch (Throwable t)
/*      */         {
/*      */ 
/*  223 */           throw new MappingException("could not instantiate custom database object class [" + definitionNode.attributeValue("class") + "]");
/*      */ 
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/*  230 */         auxDbObject = new SimpleAuxiliaryDatabaseObject(auxDbObjectNode.elementTextTrim("create"), auxDbObjectNode.elementTextTrim("drop"));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  236 */       Iterator dialectScopings = auxDbObjectNode.elementIterator("dialect-scope");
/*  237 */       while (dialectScopings.hasNext()) {
/*  238 */         Element dialectScoping = (Element)dialectScopings.next();
/*  239 */         auxDbObject.addDialectScope(dialectScoping.attributeValue("name"));
/*      */       }
/*      */       
/*  242 */       mappings.addAuxiliaryDatabaseObject(auxDbObject);
/*      */     }
/*      */   }
/*      */   
/*      */   private static void extractRootAttributes(Element hmNode, Mappings mappings) {
/*  247 */     Attribute schemaNode = hmNode.attribute("schema");
/*  248 */     mappings.setSchemaName(schemaNode == null ? null : schemaNode.getValue());
/*      */     
/*  250 */     Attribute catalogNode = hmNode.attribute("catalog");
/*  251 */     mappings.setCatalogName(catalogNode == null ? null : catalogNode.getValue());
/*      */     
/*  253 */     Attribute dcNode = hmNode.attribute("default-cascade");
/*  254 */     mappings.setDefaultCascade(dcNode == null ? "none" : dcNode.getValue());
/*      */     
/*  256 */     Attribute daNode = hmNode.attribute("default-access");
/*  257 */     mappings.setDefaultAccess(daNode == null ? "property" : daNode.getValue());
/*      */     
/*  259 */     Attribute dlNode = hmNode.attribute("default-lazy");
/*  260 */     mappings.setDefaultLazy((dlNode == null) || (dlNode.getValue().equals("true")));
/*      */     
/*  262 */     Attribute aiNode = hmNode.attribute("auto-import");
/*  263 */     mappings.setAutoImport(aiNode == null ? true : "true".equals(aiNode.getValue()));
/*      */     
/*  265 */     Attribute packNode = hmNode.attribute("package");
/*  266 */     if (packNode != null) { mappings.setDefaultPackage(packNode.getValue());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void bindRootClass(Element node, RootClass rootClass, Mappings mappings, java.util.Map inheritedMetas)
/*      */     throws MappingException
/*      */   {
/*  280 */     bindClass(node, rootClass, mappings, inheritedMetas);
/*  281 */     inheritedMetas = getMetas(node, inheritedMetas, true);
/*  282 */     bindRootPersistentClassCommonValues(node, inheritedMetas, mappings, rootClass);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void bindRootPersistentClassCommonValues(Element node, java.util.Map inheritedMetas, Mappings mappings, RootClass entity)
/*      */     throws MappingException
/*      */   {
/*  291 */     Attribute schemaNode = node.attribute("schema");
/*  292 */     String schema = schemaNode == null ? mappings.getSchemaName() : schemaNode.getValue();
/*      */     
/*      */ 
/*  295 */     Attribute catalogNode = node.attribute("catalog");
/*  296 */     String catalog = catalogNode == null ? mappings.getCatalogName() : catalogNode.getValue();
/*      */     
/*      */ 
/*  299 */     Table table = mappings.addTable(schema, catalog, getClassTableName(entity, node, schema, catalog, null, mappings), getSubselect(node), entity.isAbstract() == null ? false : entity.isAbstract().booleanValue());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  306 */     entity.setTable(table);
/*  307 */     bindComment(table, node);
/*      */     
/*  309 */     log.info("Mapping class: " + entity.getEntityName() + " -> " + entity.getTable().getName());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  315 */     Attribute mutableNode = node.attribute("mutable");
/*  316 */     entity.setMutable((mutableNode == null) || (mutableNode.getValue().equals("true")));
/*      */     
/*      */ 
/*  319 */     Attribute whereNode = node.attribute("where");
/*  320 */     if (whereNode != null) { entity.setWhere(whereNode.getValue());
/*      */     }
/*      */     
/*  323 */     Attribute chNode = node.attribute("check");
/*  324 */     if (chNode != null) { table.addCheckConstraint(chNode.getValue());
/*      */     }
/*      */     
/*  327 */     Attribute polyNode = node.attribute("polymorphism");
/*  328 */     entity.setExplicitPolymorphism((polyNode != null) && (polyNode.getValue().equals("explicit")));
/*      */     
/*      */ 
/*      */ 
/*  332 */     Attribute rowidNode = node.attribute("rowid");
/*  333 */     if (rowidNode != null) { table.setRowId(rowidNode.getValue());
/*      */     }
/*  335 */     Iterator subnodes = node.elementIterator();
/*  336 */     while (subnodes.hasNext())
/*      */     {
/*  338 */       Element subnode = (Element)subnodes.next();
/*  339 */       String name = subnode.getName();
/*      */       
/*  341 */       if ("id".equals(name))
/*      */       {
/*  343 */         bindSimpleId(subnode, entity, mappings, inheritedMetas);
/*      */       }
/*  345 */       else if ("composite-id".equals(name))
/*      */       {
/*  347 */         bindCompositeId(subnode, entity, mappings, inheritedMetas);
/*      */       }
/*  349 */       else if (("version".equals(name)) || ("timestamp".equals(name)))
/*      */       {
/*  351 */         bindVersioningProperty(table, subnode, mappings, name, entity, inheritedMetas);
/*      */       }
/*  353 */       else if ("discriminator".equals(name))
/*      */       {
/*  355 */         bindDiscriminatorProperty(table, entity, subnode, mappings);
/*      */       }
/*  357 */       else if ("cache".equals(name)) {
/*  358 */         entity.setCacheConcurrencyStrategy(subnode.attributeValue("usage"));
/*  359 */         entity.setCacheRegionName(subnode.attributeValue("region"));
/*  360 */         entity.setLazyPropertiesCacheable(!"non-lazy".equals(subnode.attributeValue("include")));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  366 */     entity.createPrimaryKey();
/*      */     
/*  368 */     createClassProperties(node, entity, mappings, inheritedMetas);
/*      */   }
/*      */   
/*      */   private static void bindSimpleId(Element idNode, RootClass entity, Mappings mappings, java.util.Map inheritedMetas) throws MappingException
/*      */   {
/*  373 */     String propertyName = idNode.attributeValue("name");
/*      */     
/*  375 */     SimpleValue id = new SimpleValue(entity.getTable());
/*  376 */     entity.setIdentifier(id);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  396 */     if (propertyName == null) {
/*  397 */       bindSimpleValue(idNode, id, false, "id", mappings);
/*      */     }
/*      */     else {
/*  400 */       bindSimpleValue(idNode, id, false, propertyName, mappings);
/*      */     }
/*      */     
/*  403 */     if ((propertyName == null) || (!entity.hasPojoRepresentation())) {
/*  404 */       if (!id.isTypeSpecified()) {
/*  405 */         throw new MappingException("must specify an identifier type: " + entity.getEntityName());
/*      */       }
/*      */       
/*      */     }
/*      */     else {
/*  410 */       id.setTypeUsingReflection(entity.getClassName(), propertyName);
/*      */     }
/*      */     
/*  413 */     if (propertyName != null) {
/*  414 */       Property prop = new Property();
/*  415 */       prop.setValue(id);
/*  416 */       bindProperty(idNode, prop, mappings, inheritedMetas);
/*  417 */       entity.setIdentifierProperty(prop);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  425 */     makeIdentifier(idNode, id, mappings);
/*      */   }
/*      */   
/*      */   private static void bindCompositeId(Element idNode, RootClass entity, Mappings mappings, java.util.Map inheritedMetas) throws MappingException
/*      */   {
/*  430 */     String propertyName = idNode.attributeValue("name");
/*  431 */     Component id = new Component(entity);
/*  432 */     entity.setIdentifier(id);
/*  433 */     bindCompositeId(idNode, id, entity, propertyName, mappings, inheritedMetas);
/*  434 */     if (propertyName == null) {
/*  435 */       entity.setEmbeddedIdentifier(id.isEmbedded());
/*  436 */       if (id.isEmbedded())
/*      */       {
/*  438 */         id.setDynamic(!entity.hasPojoRepresentation());
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  447 */       Property prop = new Property();
/*  448 */       prop.setValue(id);
/*  449 */       bindProperty(idNode, prop, mappings, inheritedMetas);
/*  450 */       entity.setIdentifierProperty(prop);
/*      */     }
/*      */     
/*  453 */     makeIdentifier(idNode, id, mappings);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static void bindVersioningProperty(Table table, Element subnode, Mappings mappings, String name, RootClass entity, java.util.Map inheritedMetas)
/*      */   {
/*  460 */     String propertyName = subnode.attributeValue("name");
/*  461 */     SimpleValue val = new SimpleValue(table);
/*  462 */     bindSimpleValue(subnode, val, false, propertyName, mappings);
/*  463 */     if (!val.isTypeSpecified())
/*      */     {
/*      */ 
/*  466 */       if ("version".equals(name)) {
/*  467 */         val.setTypeName("integer");
/*      */ 
/*      */       }
/*  470 */       else if ("db".equals(subnode.attributeValue("source"))) {
/*  471 */         val.setTypeName("dbtimestamp");
/*      */       }
/*      */       else {
/*  474 */         val.setTypeName("timestamp");
/*      */       }
/*      */     }
/*      */     
/*  478 */     Property prop = new Property();
/*  479 */     prop.setValue(val);
/*  480 */     bindProperty(subnode, prop, mappings, inheritedMetas);
/*      */     
/*      */ 
/*      */ 
/*  484 */     if (prop.getGeneration() == PropertyGeneration.INSERT) {
/*  485 */       throw new MappingException("'generated' attribute cannot be 'insert' for versioning property");
/*      */     }
/*  487 */     makeVersion(subnode, val);
/*  488 */     entity.setVersion(prop);
/*  489 */     entity.addProperty(prop);
/*      */   }
/*      */   
/*      */   private static void bindDiscriminatorProperty(Table table, RootClass entity, Element subnode, Mappings mappings)
/*      */   {
/*  494 */     SimpleValue discrim = new SimpleValue(table);
/*  495 */     entity.setDiscriminator(discrim);
/*  496 */     bindSimpleValue(subnode, discrim, false, "class", mappings);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  503 */     if (!discrim.isTypeSpecified()) {
/*  504 */       discrim.setTypeName("string");
/*      */     }
/*      */     
/*  507 */     entity.setPolymorphic(true);
/*  508 */     if ("true".equals(subnode.attributeValue("force")))
/*  509 */       entity.setForceDiscriminator(true);
/*  510 */     if ("false".equals(subnode.attributeValue("insert"))) {
/*  511 */       entity.setDiscriminatorInsertable(false);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void bindClass(Element node, PersistentClass persistentClass, Mappings mappings, java.util.Map inheritedMetas)
/*      */     throws MappingException
/*      */   {
/*  518 */     Attribute lazyNode = node.attribute("lazy");
/*  519 */     boolean lazy = lazyNode == null ? mappings.isDefaultLazy() : "true".equals(lazyNode.getValue());
/*      */     
/*      */ 
/*      */ 
/*  523 */     persistentClass.setLazy(lazy);
/*      */     
/*  525 */     String entityName = node.attributeValue("entity-name");
/*  526 */     if (entityName == null) entityName = getClassName(node.attribute("name"), mappings);
/*  527 */     if (entityName == null) {
/*  528 */       throw new MappingException("Unable to determine entity name");
/*      */     }
/*  530 */     persistentClass.setEntityName(entityName);
/*      */     
/*  532 */     bindPojoRepresentation(node, persistentClass, mappings, inheritedMetas);
/*  533 */     bindDom4jRepresentation(node, persistentClass, mappings, inheritedMetas);
/*  534 */     bindMapRepresentation(node, persistentClass, mappings, inheritedMetas);
/*      */     
/*  536 */     bindPersistentClassCommonValues(node, persistentClass, mappings, inheritedMetas);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static void bindPojoRepresentation(Element node, PersistentClass entity, Mappings mappings, java.util.Map metaTags)
/*      */   {
/*  543 */     String className = getClassName(node.attribute("name"), mappings);
/*  544 */     String proxyName = getClassName(node.attribute("proxy"), mappings);
/*      */     
/*  546 */     entity.setClassName(className);
/*      */     
/*  548 */     if (proxyName != null) {
/*  549 */       entity.setProxyInterfaceName(proxyName);
/*  550 */       entity.setLazy(true);
/*      */     }
/*  552 */     else if (entity.isLazy()) {
/*  553 */       entity.setProxyInterfaceName(className);
/*      */     }
/*      */     
/*  556 */     Element tuplizer = locateTuplizerDefinition(node, EntityMode.POJO);
/*  557 */     if (tuplizer != null) {
/*  558 */       entity.addTuplizer(EntityMode.POJO, tuplizer.attributeValue("class"));
/*      */     }
/*      */   }
/*      */   
/*      */   private static void bindDom4jRepresentation(Element node, PersistentClass entity, Mappings mappings, java.util.Map inheritedMetas)
/*      */   {
/*  564 */     String nodeName = node.attributeValue("node");
/*  565 */     if (nodeName == null) nodeName = StringHelper.unqualify(entity.getEntityName());
/*  566 */     entity.setNodeName(nodeName);
/*      */     
/*  568 */     Element tuplizer = locateTuplizerDefinition(node, EntityMode.DOM4J);
/*  569 */     if (tuplizer != null) {
/*  570 */       entity.addTuplizer(EntityMode.DOM4J, tuplizer.attributeValue("class"));
/*      */     }
/*      */   }
/*      */   
/*      */   private static void bindMapRepresentation(Element node, PersistentClass entity, Mappings mappings, java.util.Map inheritedMetas)
/*      */   {
/*  576 */     Element tuplizer = locateTuplizerDefinition(node, EntityMode.MAP);
/*  577 */     if (tuplizer != null) {
/*  578 */       entity.addTuplizer(EntityMode.MAP, tuplizer.attributeValue("class"));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Element locateTuplizerDefinition(Element container, EntityMode entityMode)
/*      */   {
/*  590 */     Iterator itr = container.elements("tuplizer").iterator();
/*  591 */     while (itr.hasNext()) {
/*  592 */       Element tuplizerElem = (Element)itr.next();
/*  593 */       if (entityMode.toString().equals(tuplizerElem.attributeValue("entity-mode"))) {
/*  594 */         return tuplizerElem;
/*      */       }
/*      */     }
/*  597 */     return null;
/*      */   }
/*      */   
/*      */   private static void bindPersistentClassCommonValues(Element node, PersistentClass entity, Mappings mappings, java.util.Map inheritedMetas)
/*      */     throws MappingException
/*      */   {
/*  603 */     Attribute discriminatorNode = node.attribute("discriminator-value");
/*  604 */     entity.setDiscriminatorValue(discriminatorNode == null ? entity.getEntityName() : discriminatorNode.getValue());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  609 */     Attribute dynamicNode = node.attribute("dynamic-update");
/*  610 */     entity.setDynamicUpdate(dynamicNode == null ? false : "true".equals(dynamicNode.getValue()));
/*      */     
/*      */ 
/*      */ 
/*  614 */     Attribute insertNode = node.attribute("dynamic-insert");
/*  615 */     entity.setDynamicInsert(insertNode == null ? false : "true".equals(insertNode.getValue()));
/*      */     
/*      */ 
/*      */ 
/*  619 */     mappings.addImport(entity.getEntityName(), entity.getEntityName());
/*  620 */     if ((mappings.isAutoImport()) && (entity.getEntityName().indexOf('.') > 0)) {
/*  621 */       mappings.addImport(entity.getEntityName(), StringHelper.unqualify(entity.getEntityName()));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  628 */     Attribute batchNode = node.attribute("batch-size");
/*  629 */     if (batchNode != null) { entity.setBatchSize(Integer.parseInt(batchNode.getValue()));
/*      */     }
/*      */     
/*  632 */     Attribute sbuNode = node.attribute("select-before-update");
/*  633 */     if (sbuNode != null) { entity.setSelectBeforeUpdate("true".equals(sbuNode.getValue()));
/*      */     }
/*      */     
/*  636 */     Attribute olNode = node.attribute("optimistic-lock");
/*  637 */     entity.setOptimisticLockMode(getOptimisticLockMode(olNode));
/*      */     
/*  639 */     entity.setMetaAttributes(getMetas(node, inheritedMetas));
/*      */     
/*      */ 
/*  642 */     Attribute persisterNode = node.attribute("persister");
/*  643 */     if (persisterNode != null)
/*      */     {
/*      */       try
/*      */       {
/*      */ 
/*  648 */         entity.setEntityPersisterClass(ReflectHelper.classForName(persisterNode.getValue()));
/*      */       }
/*      */       catch (ClassNotFoundException cnfe)
/*      */       {
/*  652 */         throw new MappingException("Could not find persister class: " + persisterNode.getValue());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  658 */     handleCustomSQL(node, entity);
/*      */     
/*  660 */     Iterator tables = node.elementIterator("synchronize");
/*  661 */     while (tables.hasNext()) {
/*  662 */       entity.addSynchronizedTable(((Element)tables.next()).attributeValue("table"));
/*      */     }
/*      */     
/*  665 */     Attribute abstractNode = node.attribute("abstract");
/*  666 */     Boolean isAbstract = "false".equals(abstractNode.getValue()) ? Boolean.FALSE : "true".equals(abstractNode.getValue()) ? Boolean.TRUE : abstractNode == null ? null : null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  673 */     entity.setAbstract(isAbstract);
/*      */   }
/*      */   
/*      */   private static void handleCustomSQL(Element node, PersistentClass model) throws MappingException
/*      */   {
/*  678 */     Element element = node.element("sql-insert");
/*  679 */     if (element != null) {
/*  680 */       boolean callable = false;
/*  681 */       callable = isCallable(element);
/*  682 */       model.setCustomSQLInsert(element.getTextTrim(), callable);
/*      */     }
/*      */     
/*  685 */     element = node.element("sql-delete");
/*  686 */     if (element != null) {
/*  687 */       boolean callable = false;
/*  688 */       callable = isCallable(element);
/*  689 */       model.setCustomSQLDelete(element.getTextTrim(), callable);
/*      */     }
/*      */     
/*  692 */     element = node.element("sql-update");
/*  693 */     if (element != null) {
/*  694 */       boolean callable = false;
/*  695 */       callable = isCallable(element);
/*  696 */       model.setCustomSQLUpdate(element.getTextTrim(), callable);
/*      */     }
/*      */     
/*  699 */     element = node.element("loader");
/*  700 */     if (element != null) {
/*  701 */       model.setLoaderName(element.attributeValue("query-ref"));
/*      */     }
/*      */   }
/*      */   
/*      */   private static void handleCustomSQL(Element node, Join model) throws MappingException {
/*  706 */     Element element = node.element("sql-insert");
/*  707 */     if (element != null) {
/*  708 */       boolean callable = false;
/*  709 */       callable = isCallable(element);
/*  710 */       model.setCustomSQLInsert(element.getTextTrim(), callable);
/*      */     }
/*      */     
/*  713 */     element = node.element("sql-delete");
/*  714 */     if (element != null) {
/*  715 */       boolean callable = false;
/*  716 */       callable = isCallable(element);
/*  717 */       model.setCustomSQLDelete(element.getTextTrim(), callable);
/*      */     }
/*      */     
/*  720 */     element = node.element("sql-update");
/*  721 */     if (element != null) {
/*  722 */       boolean callable = false;
/*  723 */       callable = isCallable(element);
/*  724 */       model.setCustomSQLUpdate(element.getTextTrim(), callable);
/*      */     }
/*      */   }
/*      */   
/*      */   private static void handleCustomSQL(Element node, Collection model) throws MappingException {
/*  729 */     Element element = node.element("sql-insert");
/*  730 */     if (element != null) {
/*  731 */       boolean callable = false;
/*  732 */       callable = isCallable(element, true);
/*  733 */       model.setCustomSQLInsert(element.getTextTrim(), callable);
/*      */     }
/*      */     
/*  736 */     element = node.element("sql-delete");
/*  737 */     if (element != null) {
/*  738 */       boolean callable = false;
/*  739 */       callable = isCallable(element, true);
/*  740 */       model.setCustomSQLDelete(element.getTextTrim(), callable);
/*      */     }
/*      */     
/*  743 */     element = node.element("sql-update");
/*  744 */     if (element != null) {
/*  745 */       boolean callable = false;
/*  746 */       callable = isCallable(element, true);
/*  747 */       model.setCustomSQLUpdate(element.getTextTrim(), callable);
/*      */     }
/*      */     
/*  750 */     element = node.element("sql-delete-all");
/*  751 */     if (element != null) {
/*  752 */       boolean callable = false;
/*  753 */       callable = isCallable(element, true);
/*  754 */       model.setCustomSQLDeleteAll(element.getTextTrim(), callable);
/*      */     }
/*      */   }
/*      */   
/*      */   private static boolean isCallable(Element e) throws MappingException {
/*  759 */     return isCallable(e, true);
/*      */   }
/*      */   
/*      */   private static boolean isCallable(Element element, boolean supportsCallable) throws MappingException
/*      */   {
/*  764 */     Attribute attrib = element.attribute("callable");
/*  765 */     if ((attrib != null) && ("true".equals(attrib.getValue()))) {
/*  766 */       if (!supportsCallable) {
/*  767 */         throw new MappingException("callable attribute not supported yet!");
/*      */       }
/*  769 */       return true;
/*      */     }
/*  771 */     return false;
/*      */   }
/*      */   
/*      */   public static void bindUnionSubclass(Element node, UnionSubclass unionSubclass, Mappings mappings, java.util.Map inheritedMetas)
/*      */     throws MappingException
/*      */   {
/*  777 */     bindClass(node, unionSubclass, mappings, inheritedMetas);
/*  778 */     inheritedMetas = getMetas(node, inheritedMetas, true);
/*      */     
/*  780 */     if (unionSubclass.getEntityPersisterClass() == null) {
/*  781 */       unionSubclass.getRootClass().setEntityPersisterClass(UnionSubclassEntityPersister.class);
/*      */     }
/*      */     
/*      */ 
/*  785 */     Attribute schemaNode = node.attribute("schema");
/*  786 */     String schema = schemaNode == null ? mappings.getSchemaName() : schemaNode.getValue();
/*      */     
/*      */ 
/*  789 */     Attribute catalogNode = node.attribute("catalog");
/*  790 */     String catalog = catalogNode == null ? mappings.getCatalogName() : catalogNode.getValue();
/*      */     
/*      */ 
/*  793 */     Table denormalizedSuperTable = unionSubclass.getSuperclass().getTable();
/*  794 */     Table mytable = mappings.addDenormalizedTable(schema, catalog, getClassTableName(unionSubclass, node, schema, catalog, denormalizedSuperTable, mappings), unionSubclass.isAbstract() == null ? false : unionSubclass.isAbstract().booleanValue(), getSubselect(node), denormalizedSuperTable);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  802 */     unionSubclass.setTable(mytable);
/*      */     
/*  804 */     log.info("Mapping union-subclass: " + unionSubclass.getEntityName() + " -> " + unionSubclass.getTable().getName());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  809 */     createClassProperties(node, unionSubclass, mappings, inheritedMetas);
/*      */   }
/*      */   
/*      */ 
/*      */   public static void bindSubclass(Element node, Subclass subclass, Mappings mappings, java.util.Map inheritedMetas)
/*      */     throws MappingException
/*      */   {
/*  816 */     bindClass(node, subclass, mappings, inheritedMetas);
/*  817 */     inheritedMetas = getMetas(node, inheritedMetas, true);
/*      */     
/*  819 */     if (subclass.getEntityPersisterClass() == null) {
/*  820 */       subclass.getRootClass().setEntityPersisterClass(SingleTableEntityPersister.class);
/*      */     }
/*      */     
/*      */ 
/*  824 */     log.info("Mapping subclass: " + subclass.getEntityName() + " -> " + subclass.getTable().getName());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  830 */     createClassProperties(node, subclass, mappings, inheritedMetas);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static String getClassTableName(PersistentClass model, Element node, String schema, String catalog, Table denormalizedSuperTable, Mappings mappings)
/*      */   {
/*  837 */     Attribute tableNameNode = node.attribute("table");
/*      */     String physicalTableName;
/*      */     String logicalTableName;
/*  840 */     String physicalTableName; if (tableNameNode == null) {
/*  841 */       String logicalTableName = StringHelper.unqualify(model.getEntityName());
/*  842 */       physicalTableName = mappings.getNamingStrategy().classToTableName(model.getEntityName());
/*      */     }
/*      */     else {
/*  845 */       logicalTableName = tableNameNode.getValue();
/*  846 */       physicalTableName = mappings.getNamingStrategy().tableName(logicalTableName);
/*      */     }
/*  848 */     mappings.addTableBinding(schema, catalog, logicalTableName, physicalTableName, denormalizedSuperTable);
/*  849 */     return physicalTableName;
/*      */   }
/*      */   
/*      */   public static void bindJoinedSubclass(Element node, JoinedSubclass joinedSubclass, Mappings mappings, java.util.Map inheritedMetas)
/*      */     throws MappingException
/*      */   {
/*  855 */     bindClass(node, joinedSubclass, mappings, inheritedMetas);
/*  856 */     inheritedMetas = getMetas(node, inheritedMetas, true);
/*      */     
/*      */ 
/*      */ 
/*  860 */     if (joinedSubclass.getEntityPersisterClass() == null) {
/*  861 */       joinedSubclass.getRootClass().setEntityPersisterClass(JoinedSubclassEntityPersister.class);
/*      */     }
/*      */     
/*      */ 
/*  865 */     Attribute schemaNode = node.attribute("schema");
/*  866 */     String schema = schemaNode == null ? mappings.getSchemaName() : schemaNode.getValue();
/*      */     
/*      */ 
/*  869 */     Attribute catalogNode = node.attribute("catalog");
/*  870 */     String catalog = catalogNode == null ? mappings.getCatalogName() : catalogNode.getValue();
/*      */     
/*      */ 
/*  873 */     Table mytable = mappings.addTable(schema, catalog, getClassTableName(joinedSubclass, node, schema, catalog, null, mappings), getSubselect(node), false);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  880 */     joinedSubclass.setTable(mytable);
/*  881 */     bindComment(mytable, node);
/*      */     
/*  883 */     log.info("Mapping joined-subclass: " + joinedSubclass.getEntityName() + " -> " + joinedSubclass.getTable().getName());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  889 */     Element keyNode = node.element("key");
/*  890 */     SimpleValue key = new DependantValue(mytable, joinedSubclass.getIdentifier());
/*  891 */     joinedSubclass.setKey(key);
/*  892 */     key.setCascadeDeleteEnabled("cascade".equals(keyNode.attributeValue("on-delete")));
/*  893 */     bindSimpleValue(keyNode, key, false, joinedSubclass.getEntityName(), mappings);
/*      */     
/*      */ 
/*  896 */     joinedSubclass.createPrimaryKey();
/*  897 */     joinedSubclass.createForeignKey();
/*      */     
/*      */ 
/*  900 */     Attribute chNode = node.attribute("check");
/*  901 */     if (chNode != null) { mytable.addCheckConstraint(chNode.getValue());
/*      */     }
/*      */     
/*  904 */     createClassProperties(node, joinedSubclass, mappings, inheritedMetas);
/*      */   }
/*      */   
/*      */ 
/*      */   private static void bindJoin(Element node, Join join, Mappings mappings, java.util.Map inheritedMetas)
/*      */     throws MappingException
/*      */   {
/*  911 */     PersistentClass persistentClass = join.getPersistentClass();
/*  912 */     String path = persistentClass.getEntityName();
/*      */     
/*      */ 
/*      */ 
/*  916 */     Attribute schemaNode = node.attribute("schema");
/*  917 */     String schema = schemaNode == null ? mappings.getSchemaName() : schemaNode.getValue();
/*      */     
/*  919 */     Attribute catalogNode = node.attribute("catalog");
/*  920 */     String catalog = catalogNode == null ? mappings.getCatalogName() : catalogNode.getValue();
/*      */     
/*  922 */     Table primaryTable = persistentClass.getTable();
/*  923 */     Table table = mappings.addTable(schema, catalog, getClassTableName(persistentClass, node, schema, catalog, primaryTable, mappings), getSubselect(node), false);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  930 */     join.setTable(table);
/*  931 */     bindComment(table, node);
/*      */     
/*  933 */     Attribute fetchNode = node.attribute("fetch");
/*  934 */     if (fetchNode != null) {
/*  935 */       join.setSequentialSelect("select".equals(fetchNode.getValue()));
/*      */     }
/*      */     
/*  938 */     Attribute invNode = node.attribute("inverse");
/*  939 */     if (invNode != null) {
/*  940 */       join.setInverse("true".equals(invNode.getValue()));
/*      */     }
/*      */     
/*  943 */     Attribute nullNode = node.attribute("optional");
/*  944 */     if (nullNode != null) {
/*  945 */       join.setOptional("true".equals(nullNode.getValue()));
/*      */     }
/*      */     
/*  948 */     log.info("Mapping class join: " + persistentClass.getEntityName() + " -> " + join.getTable().getName());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  954 */     Element keyNode = node.element("key");
/*  955 */     SimpleValue key = new DependantValue(table, persistentClass.getIdentifier());
/*  956 */     join.setKey(key);
/*  957 */     key.setCascadeDeleteEnabled("cascade".equals(keyNode.attributeValue("on-delete")));
/*  958 */     bindSimpleValue(keyNode, key, false, persistentClass.getEntityName(), mappings);
/*      */     
/*      */ 
/*  961 */     join.createPrimaryKey();
/*  962 */     join.createForeignKey();
/*      */     
/*      */ 
/*  965 */     Iterator iter = node.elementIterator();
/*  966 */     while (iter.hasNext()) {
/*  967 */       Element subnode = (Element)iter.next();
/*  968 */       String name = subnode.getName();
/*  969 */       String propertyName = subnode.attributeValue("name");
/*      */       
/*  971 */       Value value = null;
/*  972 */       if ("many-to-one".equals(name)) {
/*  973 */         value = new ManyToOne(table);
/*  974 */         bindManyToOne(subnode, (ManyToOne)value, propertyName, true, mappings);
/*      */       }
/*  976 */       else if ("any".equals(name)) {
/*  977 */         value = new Any(table);
/*  978 */         bindAny(subnode, (Any)value, true, mappings);
/*      */       }
/*  980 */       else if ("property".equals(name)) {
/*  981 */         value = new SimpleValue(table);
/*  982 */         bindSimpleValue(subnode, (SimpleValue)value, true, propertyName, mappings);
/*      */       }
/*  984 */       else if (("component".equals(name)) || ("dynamic-component".equals(name))) {
/*  985 */         String subpath = StringHelper.qualify(path, propertyName);
/*  986 */         value = new Component(join);
/*  987 */         bindComponent(subnode, (Component)value, join.getPersistentClass().getClassName(), propertyName, subpath, true, false, mappings, inheritedMetas, false);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1001 */       if (value != null) {
/* 1002 */         Property prop = createProperty(value, propertyName, persistentClass.getEntityName(), subnode, mappings, inheritedMetas);
/*      */         
/* 1004 */         prop.setOptional(join.isOptional());
/* 1005 */         join.addProperty(prop);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1011 */     handleCustomSQL(node, join);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static void bindColumns(Element node, SimpleValue simpleValue, boolean isNullable, boolean autoColumn, String propertyPath, Mappings mappings)
/*      */     throws MappingException
/*      */   {
/* 1019 */     Table table = simpleValue.getTable();
/*      */     
/*      */ 
/* 1022 */     Attribute columnAttribute = node.attribute("column");
/* 1023 */     if (columnAttribute == null) {
/* 1024 */       Iterator iter = node.elementIterator();
/* 1025 */       int count = 0;
/* 1026 */       while (iter.hasNext()) {
/* 1027 */         Element columnElement = (Element)iter.next();
/* 1028 */         if (columnElement.getName().equals("column")) {
/* 1029 */           Column column = new Column();
/* 1030 */           column.setValue(simpleValue);
/* 1031 */           column.setTypeIndex(count++);
/* 1032 */           bindColumn(columnElement, column, isNullable);
/* 1033 */           String logicalColumnName = mappings.getNamingStrategy().logicalColumnName(columnElement.attributeValue("name"), propertyPath);
/*      */           
/*      */ 
/* 1036 */           column.setName(mappings.getNamingStrategy().columnName(logicalColumnName));
/*      */           
/* 1038 */           if (table != null) {
/* 1039 */             table.addColumn(column);
/*      */             
/*      */ 
/* 1042 */             mappings.addColumnBinding(logicalColumnName, column, table);
/*      */           }
/*      */           
/*      */ 
/* 1046 */           simpleValue.addColumn(column);
/*      */           
/* 1048 */           bindIndex(columnElement.attribute("index"), table, column, mappings);
/* 1049 */           bindIndex(node.attribute("index"), table, column, mappings);
/*      */           
/* 1051 */           bindUniqueKey(columnElement.attribute("unique-key"), table, column, mappings);
/* 1052 */           bindUniqueKey(node.attribute("unique-key"), table, column, mappings);
/*      */         }
/* 1054 */         else if (columnElement.getName().equals("formula")) {
/* 1055 */           Formula formula = new Formula();
/* 1056 */           formula.setFormula(columnElement.getText());
/* 1057 */           simpleValue.addFormula(formula);
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/* 1062 */       if (node.elementIterator("column").hasNext()) {
/* 1063 */         throw new MappingException("column attribute may not be used together with <column> subelement");
/*      */       }
/*      */       
/* 1066 */       if (node.elementIterator("formula").hasNext()) {
/* 1067 */         throw new MappingException("column attribute may not be used together with <formula> subelement");
/*      */       }
/*      */       
/*      */ 
/* 1071 */       Column column = new Column();
/* 1072 */       column.setValue(simpleValue);
/* 1073 */       bindColumn(node, column, isNullable);
/* 1074 */       String logicalColumnName = mappings.getNamingStrategy().logicalColumnName(columnAttribute.getValue(), propertyPath);
/*      */       
/*      */ 
/* 1077 */       column.setName(mappings.getNamingStrategy().columnName(logicalColumnName));
/* 1078 */       if (table != null) {
/* 1079 */         table.addColumn(column);
/*      */         
/*      */ 
/* 1082 */         mappings.addColumnBinding(logicalColumnName, column, table);
/*      */       }
/* 1084 */       simpleValue.addColumn(column);
/* 1085 */       bindIndex(node.attribute("index"), table, column, mappings);
/* 1086 */       bindUniqueKey(node.attribute("unique-key"), table, column, mappings);
/*      */     }
/*      */     
/* 1089 */     if ((autoColumn) && (simpleValue.getColumnSpan() == 0)) {
/* 1090 */       Column column = new Column();
/* 1091 */       column.setValue(simpleValue);
/* 1092 */       bindColumn(node, column, isNullable);
/* 1093 */       column.setName(mappings.getNamingStrategy().propertyToColumnName(propertyPath));
/* 1094 */       String logicalName = mappings.getNamingStrategy().logicalColumnName(null, propertyPath);
/* 1095 */       mappings.addColumnBinding(logicalName, column, table);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1100 */       simpleValue.getTable().addColumn(column);
/* 1101 */       simpleValue.addColumn(column);
/* 1102 */       bindIndex(node.attribute("index"), table, column, mappings);
/* 1103 */       bindUniqueKey(node.attribute("unique-key"), table, column, mappings);
/*      */     }
/*      */   }
/*      */   
/*      */   private static void bindIndex(Attribute indexAttribute, Table table, Column column, Mappings mappings)
/*      */   {
/* 1109 */     if ((indexAttribute != null) && (table != null)) {
/* 1110 */       StringTokenizer tokens = new StringTokenizer(indexAttribute.getValue(), ", ");
/* 1111 */       while (tokens.hasMoreTokens()) {
/* 1112 */         table.getOrCreateIndex(tokens.nextToken()).addColumn(column);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private static void bindUniqueKey(Attribute uniqueKeyAttribute, Table table, Column column, Mappings mappings) {
/* 1118 */     if ((uniqueKeyAttribute != null) && (table != null)) {
/* 1119 */       StringTokenizer tokens = new StringTokenizer(uniqueKeyAttribute.getValue(), ", ");
/* 1120 */       while (tokens.hasMoreTokens()) {
/* 1121 */         table.getOrCreateUniqueKey(tokens.nextToken()).addColumn(column);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static void bindSimpleValue(Element node, SimpleValue simpleValue, boolean isNullable, String path, Mappings mappings)
/*      */     throws MappingException
/*      */   {
/* 1129 */     bindSimpleValueType(node, simpleValue, mappings);
/*      */     
/* 1131 */     bindColumnsOrFormula(node, simpleValue, path, isNullable, mappings);
/*      */     
/* 1133 */     Attribute fkNode = node.attribute("foreign-key");
/* 1134 */     if (fkNode != null) simpleValue.setForeignKeyName(fkNode.getValue());
/*      */   }
/*      */   
/*      */   private static void bindSimpleValueType(Element node, SimpleValue simpleValue, Mappings mappings) throws MappingException
/*      */   {
/* 1139 */     String typeName = null;
/*      */     
/* 1141 */     Properties parameters = new Properties();
/*      */     
/* 1143 */     Attribute typeNode = node.attribute("type");
/* 1144 */     if (typeNode == null) typeNode = node.attribute("id-type");
/* 1145 */     if (typeNode != null) { typeName = typeNode.getValue();
/*      */     }
/* 1147 */     Element typeChild = node.element("type");
/* 1148 */     if ((typeName == null) && (typeChild != null)) {
/* 1149 */       typeName = typeChild.attribute("name").getValue();
/* 1150 */       Iterator typeParameters = typeChild.elementIterator("param");
/*      */       
/* 1152 */       while (typeParameters.hasNext()) {
/* 1153 */         Element paramElement = (Element)typeParameters.next();
/* 1154 */         parameters.setProperty(paramElement.attributeValue("name"), paramElement.getTextTrim());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1161 */     TypeDef typeDef = mappings.getTypeDef(typeName);
/* 1162 */     if (typeDef != null) {
/* 1163 */       typeName = typeDef.getTypeClass();
/*      */       
/*      */ 
/* 1166 */       Properties allParameters = new Properties();
/* 1167 */       allParameters.putAll(typeDef.getParameters());
/* 1168 */       allParameters.putAll(parameters);
/* 1169 */       parameters = allParameters;
/*      */     }
/*      */     
/* 1172 */     if (!parameters.isEmpty()) { simpleValue.setTypeParameters(parameters);
/*      */     }
/* 1174 */     if (typeName != null) { simpleValue.setTypeName(typeName);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static void bindProperty(Element node, Property property, Mappings mappings, java.util.Map inheritedMetas)
/*      */     throws MappingException
/*      */   {
/* 1183 */     String propName = node.attributeValue("name");
/* 1184 */     property.setName(propName);
/* 1185 */     String nodeName = node.attributeValue("node");
/* 1186 */     if (nodeName == null) nodeName = propName;
/* 1187 */     property.setNodeName(nodeName);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1194 */     Attribute accessNode = node.attribute("access");
/* 1195 */     if (accessNode != null) {
/* 1196 */       property.setPropertyAccessorName(accessNode.getValue());
/*      */     }
/* 1198 */     else if (node.getName().equals("properties")) {
/* 1199 */       property.setPropertyAccessorName("embedded");
/*      */     }
/*      */     else {
/* 1202 */       property.setPropertyAccessorName(mappings.getDefaultAccess());
/*      */     }
/*      */     
/* 1205 */     Attribute cascadeNode = node.attribute("cascade");
/* 1206 */     property.setCascade(cascadeNode == null ? mappings.getDefaultCascade() : cascadeNode.getValue());
/*      */     
/*      */ 
/* 1209 */     Attribute updateNode = node.attribute("update");
/* 1210 */     property.setUpdateable((updateNode == null) || ("true".equals(updateNode.getValue())));
/*      */     
/* 1212 */     Attribute insertNode = node.attribute("insert");
/* 1213 */     property.setInsertable((insertNode == null) || ("true".equals(insertNode.getValue())));
/*      */     
/* 1215 */     Attribute lockNode = node.attribute("optimistic-lock");
/* 1216 */     property.setOptimisticLocked((lockNode == null) || ("true".equals(lockNode.getValue())));
/*      */     
/* 1218 */     Attribute generatedNode = node.attribute("generated");
/* 1219 */     String generationName = generatedNode == null ? null : generatedNode.getValue();
/* 1220 */     PropertyGeneration generation = PropertyGeneration.parse(generationName);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1225 */     if ((generation == PropertyGeneration.ALWAYS) || (generation == PropertyGeneration.INSERT)) {
/* 1226 */       if ((insertNode != null) && (property.isInsertable())) {
/* 1227 */         throw new MappingException("cannot specify both insert=\"true\" and generated=\"" + generation.getName() + "\" for property: " + propName);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1233 */       if ((updateNode != null) && (property.isUpdateable())) {
/* 1234 */         throw new MappingException("cannot specify both update=\"true\" and generated=\"" + generation.getName() + "\" for property: " + propName);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1240 */       property.setInsertable(false);
/* 1241 */       property.setUpdateable(false);
/* 1242 */       property.setGeneration(generation);
/*      */     }
/*      */     
/* 1245 */     boolean isLazyable = ("property".equals(node.getName())) || ("component".equals(node.getName())) || ("many-to-one".equals(node.getName())) || ("one-to-one".equals(node.getName())) || ("any".equals(node.getName()));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1250 */     if (isLazyable) {
/* 1251 */       Attribute lazyNode = node.attribute("lazy");
/* 1252 */       property.setLazy((lazyNode != null) && ("true".equals(lazyNode.getValue())));
/*      */     }
/*      */     
/* 1255 */     if (log.isDebugEnabled()) {
/* 1256 */       String msg = "Mapped property: " + property.getName();
/* 1257 */       String columns = columns(property.getValue());
/* 1258 */       if (columns.length() > 0) { msg = msg + " -> " + columns;
/*      */       }
/*      */       
/* 1261 */       log.debug(msg);
/*      */     }
/*      */     
/* 1264 */     property.setMetaAttributes(getMetas(node, inheritedMetas));
/*      */   }
/*      */   
/*      */   private static String columns(Value val)
/*      */   {
/* 1269 */     StringBuffer columns = new StringBuffer();
/* 1270 */     Iterator iter = val.getColumnIterator();
/* 1271 */     while (iter.hasNext()) {
/* 1272 */       columns.append(((Selectable)iter.next()).getText());
/* 1273 */       if (iter.hasNext()) columns.append(", ");
/*      */     }
/* 1275 */     return columns.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void bindCollection(Element node, Collection collection, String className, String path, Mappings mappings)
/*      */     throws MappingException
/*      */   {
/* 1285 */     collection.setRole(path);
/*      */     
/* 1287 */     Attribute inverseNode = node.attribute("inverse");
/* 1288 */     if (inverseNode != null) {
/* 1289 */       collection.setInverse("true".equals(inverseNode.getValue()));
/*      */     }
/*      */     
/* 1292 */     Attribute mutableNode = node.attribute("mutable");
/* 1293 */     if (mutableNode != null) {
/* 1294 */       collection.setMutable(!"false".equals(mutableNode.getValue()));
/*      */     }
/*      */     
/* 1297 */     Attribute olNode = node.attribute("optimistic-lock");
/* 1298 */     collection.setOptimisticLocked((olNode == null) || ("true".equals(olNode.getValue())));
/*      */     
/* 1300 */     Attribute orderNode = node.attribute("order-by");
/* 1301 */     if (orderNode != null) {
/* 1302 */       if ((Environment.jvmSupportsLinkedHashCollections()) || ((collection instanceof Bag))) {
/* 1303 */         collection.setOrderBy(orderNode.getValue());
/*      */       }
/*      */       else {
/* 1306 */         log.warn("Attribute \"order-by\" ignored in JDK1.3 or less");
/*      */       }
/*      */     }
/* 1309 */     Attribute whereNode = node.attribute("where");
/* 1310 */     if (whereNode != null) {
/* 1311 */       collection.setWhere(whereNode.getValue());
/*      */     }
/* 1313 */     Attribute batchNode = node.attribute("batch-size");
/* 1314 */     if (batchNode != null) {
/* 1315 */       collection.setBatchSize(Integer.parseInt(batchNode.getValue()));
/*      */     }
/*      */     
/* 1318 */     String nodeName = node.attributeValue("node");
/* 1319 */     if (nodeName == null) nodeName = node.attributeValue("name");
/* 1320 */     collection.setNodeName(nodeName);
/* 1321 */     String embed = node.attributeValue("embed-xml");
/* 1322 */     collection.setEmbedded((embed == null) || ("true".equals(embed)));
/*      */     
/*      */ 
/*      */ 
/* 1326 */     Attribute persisterNode = node.attribute("persister");
/* 1327 */     if (persisterNode != null) {
/*      */       try {
/* 1329 */         collection.setCollectionPersisterClass(ReflectHelper.classForName(persisterNode.getValue()));
/*      */       }
/*      */       catch (ClassNotFoundException cnfe)
/*      */       {
/* 1333 */         throw new MappingException("Could not find collection persister class: " + persisterNode.getValue());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1338 */     Attribute typeNode = node.attribute("collection-type");
/* 1339 */     if (typeNode != null) { collection.setTypeName(typeNode.getValue());
/*      */     }
/*      */     
/*      */ 
/* 1343 */     initOuterJoinFetchSetting(node, collection);
/*      */     
/* 1345 */     if ("subselect".equals(node.attributeValue("fetch"))) {
/* 1346 */       collection.setSubselectLoadable(true);
/* 1347 */       collection.getOwner().setSubselectLoadableCollections(true);
/*      */     }
/*      */     
/* 1350 */     initLaziness(node, collection, mappings, "true", mappings.isDefaultLazy());
/*      */     
/* 1352 */     if ("extra".equals(node.attributeValue("lazy"))) {
/* 1353 */       collection.setLazy(true);
/* 1354 */       collection.setExtraLazy(true);
/*      */     }
/*      */     
/* 1357 */     Element oneToManyNode = node.element("one-to-many");
/* 1358 */     if (oneToManyNode != null) {
/* 1359 */       OneToMany oneToMany = new OneToMany(collection.getOwner());
/* 1360 */       collection.setElement(oneToMany);
/* 1361 */       bindOneToMany(oneToManyNode, oneToMany, mappings);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 1366 */       Attribute tableNode = node.attribute("table");
/*      */       String tableName;
/* 1368 */       String tableName; if (tableNode != null) {
/* 1369 */         tableName = mappings.getNamingStrategy().tableName(tableNode.getValue());
/*      */       }
/*      */       else
/*      */       {
/* 1373 */         Table ownerTable = collection.getOwner().getTable();
/*      */         
/* 1375 */         String logicalOwnerTableName = ownerTable.getName();
/*      */         
/* 1377 */         tableName = mappings.getNamingStrategy().collectionTableName(logicalOwnerTableName, null, path);
/*      */       }
/* 1379 */       Attribute schemaNode = node.attribute("schema");
/* 1380 */       String schema = schemaNode == null ? mappings.getSchemaName() : schemaNode.getValue();
/*      */       
/*      */ 
/* 1383 */       Attribute catalogNode = node.attribute("catalog");
/* 1384 */       String catalog = catalogNode == null ? mappings.getCatalogName() : catalogNode.getValue();
/*      */       
/*      */ 
/* 1387 */       Table table = mappings.addTable(schema, catalog, tableName, getSubselect(node), false);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1394 */       collection.setCollectionTable(table);
/* 1395 */       bindComment(table, node);
/*      */       
/* 1397 */       log.info("Mapping collection: " + collection.getRole() + " -> " + collection.getCollectionTable().getName());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1404 */     Attribute sortedAtt = node.attribute("sort");
/*      */     
/* 1406 */     if ((sortedAtt == null) || (sortedAtt.getValue().equals("unsorted"))) {
/* 1407 */       collection.setSorted(false);
/*      */     }
/*      */     else {
/* 1410 */       collection.setSorted(true);
/* 1411 */       String comparatorClassName = sortedAtt.getValue();
/* 1412 */       if (!comparatorClassName.equals("natural")) {
/* 1413 */         collection.setComparatorClassName(comparatorClassName);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1418 */     Attribute cascadeAtt = node.attribute("cascade");
/* 1419 */     if ((cascadeAtt != null) && (cascadeAtt.getValue().indexOf("delete-orphan") >= 0)) {
/* 1420 */       collection.setOrphanDelete(true);
/*      */     }
/*      */     
/*      */ 
/* 1424 */     handleCustomSQL(node, collection);
/*      */     
/* 1426 */     if ((collection instanceof org.hibernate.mapping.List)) {
/* 1427 */       mappings.addSecondPass(new ListSecondPass(node, mappings, (org.hibernate.mapping.List)collection));
/*      */     }
/* 1429 */     else if ((collection instanceof org.hibernate.mapping.Map)) {
/* 1430 */       mappings.addSecondPass(new MapSecondPass(node, mappings, (org.hibernate.mapping.Map)collection));
/*      */     }
/* 1432 */     else if ((collection instanceof IdentifierCollection)) {
/* 1433 */       mappings.addSecondPass(new IdentifierCollectionSecondPass(node, mappings, collection));
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/* 1440 */       mappings.addSecondPass(new CollectionSecondPass(node, mappings, collection));
/*      */     }
/*      */     
/* 1443 */     Iterator iter = node.elementIterator("filter");
/* 1444 */     while (iter.hasNext()) {
/* 1445 */       Element filter = (Element)iter.next();
/* 1446 */       parseFilter(filter, collection, mappings);
/*      */     }
/*      */     
/* 1449 */     Iterator tables = node.elementIterator("synchronize");
/* 1450 */     while (tables.hasNext()) {
/* 1451 */       collection.getSynchronizedTables().add(((Element)tables.next()).attributeValue("table"));
/*      */     }
/*      */     
/*      */ 
/* 1455 */     Element element = node.element("loader");
/* 1456 */     if (element != null) {
/* 1457 */       collection.setLoaderName(element.attributeValue("query-ref"));
/*      */     }
/*      */     
/* 1460 */     collection.setReferencedPropertyName(node.element("key").attributeValue("property-ref"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void initLaziness(Element node, Fetchable fetchable, Mappings mappings, String proxyVal, boolean defaultLazy)
/*      */   {
/* 1470 */     Attribute lazyNode = node.attribute("lazy");
/* 1471 */     boolean isLazyTrue = lazyNode == null ? false : (defaultLazy) && (fetchable.isLazy()) ? true : lazyNode.getValue().equals(proxyVal);
/*      */     
/*      */ 
/* 1474 */     fetchable.setLazy(isLazyTrue);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void initLaziness(Element node, ToOne fetchable, Mappings mappings, boolean defaultLazy)
/*      */   {
/* 1483 */     if ("no-proxy".equals(node.attributeValue("lazy"))) {
/* 1484 */       fetchable.setUnwrapProxy(true);
/* 1485 */       fetchable.setLazy(true);
/*      */     }
/*      */     else
/*      */     {
/* 1489 */       initLaziness(node, fetchable, mappings, "proxy", defaultLazy);
/*      */     }
/*      */   }
/*      */   
/*      */   private static void bindColumnsOrFormula(Element node, SimpleValue simpleValue, String path, boolean isNullable, Mappings mappings)
/*      */   {
/* 1495 */     Attribute formulaNode = node.attribute("formula");
/* 1496 */     if (formulaNode != null) {
/* 1497 */       Formula f = new Formula();
/* 1498 */       f.setFormula(formulaNode.getText());
/* 1499 */       simpleValue.addFormula(f);
/*      */     }
/*      */     else {
/* 1502 */       bindColumns(node, simpleValue, isNullable, true, path, mappings);
/*      */     }
/*      */   }
/*      */   
/*      */   private static void bindComment(Table table, Element node) {
/* 1507 */     Element comment = node.element("comment");
/* 1508 */     if (comment != null) table.setComment(comment.getTextTrim());
/*      */   }
/*      */   
/*      */   public static void bindManyToOne(Element node, ManyToOne manyToOne, String path, boolean isNullable, Mappings mappings)
/*      */     throws MappingException
/*      */   {
/* 1514 */     bindColumnsOrFormula(node, manyToOne, path, isNullable, mappings);
/* 1515 */     initOuterJoinFetchSetting(node, manyToOne);
/* 1516 */     initLaziness(node, manyToOne, mappings, true);
/*      */     
/* 1518 */     Attribute ukName = node.attribute("property-ref");
/* 1519 */     if (ukName != null) {
/* 1520 */       manyToOne.setReferencedPropertyName(ukName.getValue());
/*      */     }
/*      */     
/* 1523 */     manyToOne.setReferencedEntityName(getEntityName(node, mappings));
/*      */     
/* 1525 */     String embed = node.attributeValue("embed-xml");
/* 1526 */     manyToOne.setEmbedded((embed == null) || ("true".equals(embed)));
/*      */     
/* 1528 */     String notFound = node.attributeValue("not-found");
/* 1529 */     manyToOne.setIgnoreNotFound("ignore".equals(notFound));
/*      */     
/* 1531 */     if ((ukName != null) && (!manyToOne.isIgnoreNotFound()) && 
/* 1532 */       (!node.getName().equals("many-to-many"))) {
/* 1533 */       mappings.addSecondPass(new ManyToOneSecondPass(manyToOne));
/*      */     }
/*      */     
/*      */ 
/* 1537 */     Attribute fkNode = node.attribute("foreign-key");
/* 1538 */     if (fkNode != null) { manyToOne.setForeignKeyName(fkNode.getValue());
/*      */     }
/* 1540 */     validateCascade(node, path);
/*      */   }
/*      */   
/*      */   private static void validateCascade(Element node, String path) {
/* 1544 */     String cascade = node.attributeValue("cascade");
/* 1545 */     if ((cascade != null) && (cascade.indexOf("delete-orphan") > 0)) {
/* 1546 */       throw new MappingException("single-valued associations do not support orphan delete: " + path);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void bindAny(Element node, Any any, boolean isNullable, Mappings mappings) throws MappingException
/*      */   {
/* 1552 */     any.setIdentifierType(getTypeFromXML(node));
/* 1553 */     Attribute metaAttribute = node.attribute("meta-type");
/* 1554 */     if (metaAttribute != null) {
/* 1555 */       any.setMetaType(metaAttribute.getValue());
/*      */       
/* 1557 */       Iterator iter = node.elementIterator("meta-value");
/* 1558 */       if (iter.hasNext()) {
/* 1559 */         HashMap values = new HashMap();
/* 1560 */         Type metaType = TypeFactory.heuristicType(any.getMetaType());
/* 1561 */         while (iter.hasNext()) {
/* 1562 */           Element metaValue = (Element)iter.next();
/*      */           try {
/* 1564 */             Object value = ((DiscriminatorType)metaType).stringToObject(metaValue.attributeValue("value"));
/*      */             
/* 1566 */             String entityName = getClassName(metaValue.attribute("class"), mappings);
/* 1567 */             values.put(value, entityName);
/*      */           }
/*      */           catch (ClassCastException cce) {
/* 1570 */             throw new MappingException("meta-type was not a DiscriminatorType: " + metaType.getName());
/*      */           }
/*      */           catch (Exception e)
/*      */           {
/* 1574 */             throw new MappingException("could not interpret meta-value", e);
/*      */           }
/*      */         }
/* 1577 */         any.setMetaValues(values);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1582 */     bindColumns(node, any, isNullable, false, null, mappings);
/*      */   }
/*      */   
/*      */   public static void bindOneToOne(Element node, OneToOne oneToOne, String path, boolean isNullable, Mappings mappings)
/*      */     throws MappingException
/*      */   {
/* 1588 */     bindColumns(node, oneToOne, isNullable, false, null, mappings);
/*      */     
/* 1590 */     Attribute constrNode = node.attribute("constrained");
/* 1591 */     boolean constrained = (constrNode != null) && (constrNode.getValue().equals("true"));
/* 1592 */     oneToOne.setConstrained(constrained);
/*      */     
/* 1594 */     oneToOne.setForeignKeyType(constrained ? ForeignKeyDirection.FOREIGN_KEY_FROM_PARENT : ForeignKeyDirection.FOREIGN_KEY_TO_PARENT);
/*      */     
/*      */ 
/*      */ 
/* 1598 */     initOuterJoinFetchSetting(node, oneToOne);
/* 1599 */     initLaziness(node, oneToOne, mappings, true);
/*      */     
/* 1601 */     oneToOne.setEmbedded("true".equals(node.attributeValue("embed-xml")));
/*      */     
/* 1603 */     Attribute fkNode = node.attribute("foreign-key");
/* 1604 */     if (fkNode != null) { oneToOne.setForeignKeyName(fkNode.getValue());
/*      */     }
/* 1606 */     Attribute ukName = node.attribute("property-ref");
/* 1607 */     if (ukName != null) { oneToOne.setReferencedPropertyName(ukName.getValue());
/*      */     }
/* 1609 */     oneToOne.setPropertyName(node.attributeValue("name"));
/*      */     
/* 1611 */     oneToOne.setReferencedEntityName(getEntityName(node, mappings));
/*      */     
/* 1613 */     validateCascade(node, path);
/*      */   }
/*      */   
/*      */   public static void bindOneToMany(Element node, OneToMany oneToMany, Mappings mappings)
/*      */     throws MappingException
/*      */   {
/* 1619 */     oneToMany.setReferencedEntityName(getEntityName(node, mappings));
/*      */     
/* 1621 */     String embed = node.attributeValue("embed-xml");
/* 1622 */     oneToMany.setEmbedded((embed == null) || ("true".equals(embed)));
/*      */     
/* 1624 */     String notFound = node.attributeValue("not-found");
/* 1625 */     oneToMany.setIgnoreNotFound("ignore".equals(notFound));
/*      */   }
/*      */   
/*      */   public static void bindColumn(Element node, Column column, boolean isNullable)
/*      */   {
/* 1630 */     Attribute lengthNode = node.attribute("length");
/* 1631 */     if (lengthNode != null) column.setLength(Integer.parseInt(lengthNode.getValue()));
/* 1632 */     Attribute scalNode = node.attribute("scale");
/* 1633 */     if (scalNode != null) column.setScale(Integer.parseInt(scalNode.getValue()));
/* 1634 */     Attribute precNode = node.attribute("precision");
/* 1635 */     if (precNode != null) { column.setPrecision(Integer.parseInt(precNode.getValue()));
/*      */     }
/* 1637 */     Attribute nullNode = node.attribute("not-null");
/* 1638 */     column.setNullable(nullNode == null ? isNullable : nullNode.getValue().equals("false"));
/*      */     
/* 1640 */     Attribute unqNode = node.attribute("unique");
/* 1641 */     if (unqNode != null) { column.setUnique(unqNode.getValue().equals("true"));
/*      */     }
/* 1643 */     column.setCheckConstraint(node.attributeValue("check"));
/* 1644 */     column.setDefaultValue(node.attributeValue("default"));
/*      */     
/* 1646 */     Attribute typeNode = node.attribute("sql-type");
/* 1647 */     if (typeNode != null) { column.setSqlType(typeNode.getValue());
/*      */     }
/* 1649 */     Element comment = node.element("comment");
/* 1650 */     if (comment != null) { column.setComment(comment.getTextTrim());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void bindArray(Element node, Array array, String prefix, String path, Mappings mappings)
/*      */     throws MappingException
/*      */   {
/* 1660 */     bindCollection(node, array, prefix, path, mappings);
/*      */     
/* 1662 */     Attribute att = node.attribute("element-class");
/* 1663 */     if (att != null) array.setElementClassName(getClassName(att, mappings));
/*      */   }
/*      */   
/*      */   private static Class reflectedPropertyClass(String className, String propertyName)
/*      */     throws MappingException
/*      */   {
/* 1669 */     if (className == null) return null;
/* 1670 */     return ReflectHelper.reflectedPropertyClass(className, propertyName);
/*      */   }
/*      */   
/*      */   public static void bindComposite(Element node, Component component, String path, boolean isNullable, Mappings mappings, java.util.Map inheritedMetas)
/*      */     throws MappingException
/*      */   {
/* 1676 */     bindComponent(node, component, null, null, path, isNullable, false, mappings, inheritedMetas, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void bindCompositeId(Element node, Component component, PersistentClass persistentClass, String propertyName, Mappings mappings, java.util.Map inheritedMetas)
/*      */     throws MappingException
/*      */   {
/* 1694 */     component.setKey(true);
/*      */     
/* 1696 */     String path = StringHelper.qualify(persistentClass.getEntityName(), propertyName == null ? "id" : propertyName);
/*      */     
/*      */ 
/*      */ 
/* 1700 */     bindComponent(node, component, persistentClass.getClassName(), propertyName, path, false, (node.attribute("class") == null) && (propertyName == null), mappings, inheritedMetas, false);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1714 */     if ("true".equals(node.attributeValue("mapped"))) {
/* 1715 */       if (propertyName != null) {
/* 1716 */         throw new MappingException("cannot combine mapped=\"true\" with specified name");
/*      */       }
/* 1718 */       Component mapper = new Component(persistentClass);
/* 1719 */       bindComponent(node, mapper, persistentClass.getClassName(), null, path, false, true, mappings, inheritedMetas, true);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1731 */       persistentClass.setIdentifierMapper(mapper);
/* 1732 */       Property property = new Property();
/* 1733 */       property.setName("_identifierMapper");
/* 1734 */       property.setNodeName("id");
/* 1735 */       property.setUpdateable(false);
/* 1736 */       property.setInsertable(false);
/* 1737 */       property.setValue(mapper);
/* 1738 */       property.setPropertyAccessorName("embedded");
/* 1739 */       persistentClass.addProperty(property);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static void bindComponent(Element node, Component component, String ownerClassName, String parentProperty, String path, boolean isNullable, boolean isEmbedded, Mappings mappings, java.util.Map inheritedMetas, boolean isIdentifierMapper)
/*      */     throws MappingException
/*      */   {
/* 1748 */     component.setEmbedded(isEmbedded);
/*      */     
/* 1750 */     component.setMetaAttributes(getMetas(node, inheritedMetas));
/*      */     
/* 1752 */     Attribute classNode = isIdentifierMapper ? null : node.attribute("class");
/* 1753 */     if (classNode != null) {
/* 1754 */       component.setComponentClassName(getClassName(classNode, mappings));
/*      */     }
/* 1756 */     else if ("dynamic-component".equals(node.getName())) {
/* 1757 */       component.setDynamic(true);
/*      */     }
/* 1759 */     else if (isEmbedded)
/*      */     {
/*      */ 
/* 1762 */       if (component.getOwner().hasPojoRepresentation()) {
/* 1763 */         component.setComponentClassName(component.getOwner().getClassName());
/*      */       }
/*      */       else {
/* 1766 */         component.setDynamic(true);
/*      */       }
/*      */       
/*      */ 
/*      */     }
/* 1771 */     else if (component.getOwner().hasPojoRepresentation()) {
/* 1772 */       Class reflectedClass = reflectedPropertyClass(ownerClassName, parentProperty);
/* 1773 */       if (reflectedClass != null) {
/* 1774 */         component.setComponentClassName(reflectedClass.getName());
/*      */       }
/*      */     }
/*      */     else {
/* 1778 */       component.setDynamic(true);
/*      */     }
/*      */     
/*      */ 
/* 1782 */     String nodeName = node.attributeValue("node");
/* 1783 */     if (nodeName == null) nodeName = node.attributeValue("name");
/* 1784 */     if (nodeName == null) nodeName = component.getOwner().getNodeName();
/* 1785 */     component.setNodeName(nodeName);
/*      */     
/* 1787 */     Iterator iter = node.elementIterator();
/* 1788 */     while (iter.hasNext())
/*      */     {
/* 1790 */       Element subnode = (Element)iter.next();
/* 1791 */       String name = subnode.getName();
/* 1792 */       String propertyName = getPropertyName(subnode);
/* 1793 */       String subpath = propertyName == null ? null : StringHelper.qualify(path, propertyName);
/*      */       
/*      */ 
/* 1796 */       CollectionType collectType = CollectionType.collectionTypeFromString(name);
/* 1797 */       Value value = null;
/* 1798 */       if (collectType != null) {
/* 1799 */         Collection collection = collectType.create(subnode, subpath, component.getOwner(), mappings);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1805 */         mappings.addCollection(collection);
/* 1806 */         value = collection;
/*      */       }
/* 1808 */       else if (("many-to-one".equals(name)) || ("key-many-to-one".equals(name))) {
/* 1809 */         value = new ManyToOne(component.getTable());
/*      */         String relativePath;
/* 1811 */         String relativePath; if (isEmbedded) {
/* 1812 */           relativePath = propertyName;
/*      */         }
/*      */         else {
/* 1815 */           relativePath = subpath.substring(component.getOwner().getEntityName().length() + 1);
/*      */         }
/* 1817 */         bindManyToOne(subnode, (ManyToOne)value, relativePath, isNullable, mappings);
/*      */       }
/* 1819 */       else if ("one-to-one".equals(name)) {
/* 1820 */         value = new OneToOne(component.getTable(), component.getOwner());
/*      */         String relativePath;
/* 1822 */         String relativePath; if (isEmbedded) {
/* 1823 */           relativePath = propertyName;
/*      */         }
/*      */         else {
/* 1826 */           relativePath = subpath.substring(component.getOwner().getEntityName().length() + 1);
/*      */         }
/* 1828 */         bindOneToOne(subnode, (OneToOne)value, relativePath, isNullable, mappings);
/*      */       }
/* 1830 */       else if ("any".equals(name)) {
/* 1831 */         value = new Any(component.getTable());
/* 1832 */         bindAny(subnode, (Any)value, isNullable, mappings);
/*      */       }
/* 1834 */       else if (("property".equals(name)) || ("key-property".equals(name))) {
/* 1835 */         value = new SimpleValue(component.getTable());
/*      */         String relativePath;
/* 1837 */         String relativePath; if (isEmbedded) {
/* 1838 */           relativePath = propertyName;
/*      */         }
/*      */         else {
/* 1841 */           relativePath = subpath.substring(component.getOwner().getEntityName().length() + 1);
/*      */         }
/* 1843 */         bindSimpleValue(subnode, (SimpleValue)value, isNullable, relativePath, mappings);
/*      */       }
/* 1845 */       else if (("component".equals(name)) || ("dynamic-component".equals(name)) || ("nested-composite-element".equals(name)))
/*      */       {
/*      */ 
/* 1848 */         value = new Component(component);
/* 1849 */         bindComponent(subnode, (Component)value, component.getComponentClassName(), propertyName, subpath, isNullable, isEmbedded, mappings, inheritedMetas, isIdentifierMapper);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/* 1862 */       else if ("parent".equals(name)) {
/* 1863 */         component.setParentProperty(propertyName);
/*      */       }
/*      */       
/* 1866 */       if (value != null) {
/* 1867 */         Property property = createProperty(value, propertyName, component.getComponentClassName(), subnode, mappings, inheritedMetas);
/*      */         
/* 1869 */         if (isIdentifierMapper) {
/* 1870 */           property.setInsertable(false);
/* 1871 */           property.setUpdateable(false);
/*      */         }
/* 1873 */         component.addProperty(property);
/*      */       }
/*      */     }
/*      */     
/* 1877 */     if ("true".equals(node.attributeValue("unique"))) {
/* 1878 */       iter = component.getColumnIterator();
/* 1879 */       ArrayList cols = new ArrayList();
/* 1880 */       while (iter.hasNext()) {
/* 1881 */         cols.add(iter.next());
/*      */       }
/* 1883 */       component.getOwner().getTable().createUniqueKey(cols);
/*      */     }
/*      */     
/* 1886 */     iter = node.elementIterator("tuplizer");
/* 1887 */     while (iter.hasNext()) {
/* 1888 */       Element tuplizerElem = (Element)iter.next();
/* 1889 */       EntityMode mode = EntityMode.parse(tuplizerElem.attributeValue("entity-mode"));
/* 1890 */       component.addTuplizer(mode, tuplizerElem.attributeValue("class"));
/*      */     }
/*      */   }
/*      */   
/*      */   public static String getTypeFromXML(Element node) throws MappingException
/*      */   {
/* 1896 */     Attribute typeNode = node.attribute("type");
/* 1897 */     if (typeNode == null) typeNode = node.attribute("id-type");
/* 1898 */     if (typeNode == null) return null;
/* 1899 */     return typeNode.getValue();
/*      */   }
/*      */   
/*      */   private static void initOuterJoinFetchSetting(Element node, Fetchable model) {
/* 1903 */     Attribute fetchNode = node.attribute("fetch");
/*      */     
/* 1905 */     boolean lazy = true;
/* 1906 */     FetchMode fetchStyle; FetchMode fetchStyle; if (fetchNode == null) {
/* 1907 */       Attribute jfNode = node.attribute("outer-join");
/* 1908 */       FetchMode fetchStyle; if (jfNode == null) { FetchMode fetchStyle;
/* 1909 */         if ("many-to-many".equals(node.getName()))
/*      */         {
/*      */ 
/*      */ 
/* 1913 */           lazy = false;
/* 1914 */           fetchStyle = FetchMode.JOIN;
/*      */         } else { FetchMode fetchStyle;
/* 1916 */           if ("one-to-one".equals(node.getName()))
/*      */           {
/*      */ 
/*      */ 
/* 1920 */             lazy = ((OneToOne)model).isConstrained();
/* 1921 */             fetchStyle = lazy ? FetchMode.DEFAULT : FetchMode.JOIN;
/*      */           }
/*      */           else {
/* 1924 */             fetchStyle = FetchMode.DEFAULT;
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/* 1929 */         String eoj = jfNode.getValue();
/* 1930 */         FetchMode fetchStyle; if ("auto".equals(eoj)) {
/* 1931 */           fetchStyle = FetchMode.DEFAULT;
/*      */         }
/*      */         else {
/* 1934 */           boolean join = "true".equals(eoj);
/* 1935 */           fetchStyle = join ? FetchMode.JOIN : FetchMode.SELECT;
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/* 1940 */       boolean join = "join".equals(fetchNode.getValue());
/*      */       
/* 1942 */       fetchStyle = join ? FetchMode.JOIN : FetchMode.SELECT;
/*      */     }
/* 1944 */     model.setFetchMode(fetchStyle);
/* 1945 */     model.setLazy(lazy);
/*      */   }
/*      */   
/*      */ 
/*      */   private static void makeIdentifier(Element node, SimpleValue model, Mappings mappings)
/*      */   {
/* 1951 */     Element subnode = node.element("generator");
/* 1952 */     if (subnode != null) {
/* 1953 */       model.setIdentifierGeneratorStrategy(subnode.attributeValue("class"));
/*      */       
/* 1955 */       Properties params = new Properties();
/*      */       
/* 1957 */       if (mappings.getSchemaName() != null) {
/* 1958 */         params.setProperty("schema", mappings.getSchemaName());
/*      */       }
/* 1960 */       if (mappings.getCatalogName() != null) {
/* 1961 */         params.setProperty("catalog", mappings.getCatalogName());
/*      */       }
/*      */       
/* 1964 */       Iterator iter = subnode.elementIterator("param");
/* 1965 */       while (iter.hasNext()) {
/* 1966 */         Element childNode = (Element)iter.next();
/* 1967 */         params.setProperty(childNode.attributeValue("name"), childNode.getText());
/*      */       }
/*      */       
/* 1970 */       model.setIdentifierGeneratorProperties(params);
/*      */     }
/*      */     
/* 1973 */     model.getTable().setIdentifierValue(model);
/*      */     
/*      */ 
/* 1976 */     Attribute nullValueNode = node.attribute("unsaved-value");
/* 1977 */     if (nullValueNode != null) {
/* 1978 */       model.setNullValue(nullValueNode.getValue());
/*      */ 
/*      */     }
/* 1981 */     else if ("assigned".equals(model.getIdentifierGeneratorStrategy())) {
/* 1982 */       model.setNullValue("undefined");
/*      */     }
/*      */     else {
/* 1985 */       model.setNullValue(null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static final void makeVersion(Element node, SimpleValue model)
/*      */   {
/* 1993 */     Attribute nullValueNode = node.attribute("unsaved-value");
/* 1994 */     if (nullValueNode != null) {
/* 1995 */       model.setNullValue(nullValueNode.getValue());
/*      */     }
/*      */     else {
/* 1998 */       model.setNullValue("undefined");
/*      */     }
/*      */   }
/*      */   
/*      */   protected static void createClassProperties(Element node, PersistentClass persistentClass, Mappings mappings, java.util.Map inheritedMetas)
/*      */     throws MappingException
/*      */   {
/* 2005 */     createClassProperties(node, persistentClass, mappings, inheritedMetas, null, true, true, false);
/*      */   }
/*      */   
/*      */ 
/*      */   protected static void createClassProperties(Element node, PersistentClass persistentClass, Mappings mappings, java.util.Map inheritedMetas, UniqueKey uniqueKey, boolean mutable, boolean nullable, boolean naturalId)
/*      */     throws MappingException
/*      */   {
/* 2012 */     String entityName = persistentClass.getEntityName();
/* 2013 */     Table table = persistentClass.getTable();
/*      */     
/* 2015 */     Iterator iter = node.elementIterator();
/* 2016 */     while (iter.hasNext()) {
/* 2017 */       Element subnode = (Element)iter.next();
/* 2018 */       String name = subnode.getName();
/* 2019 */       String propertyName = subnode.attributeValue("name");
/*      */       
/* 2021 */       CollectionType collectType = CollectionType.collectionTypeFromString(name);
/* 2022 */       Value value = null;
/* 2023 */       if (collectType != null) {
/* 2024 */         Collection collection = collectType.create(subnode, StringHelper.qualify(entityName, propertyName), persistentClass, mappings);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2030 */         mappings.addCollection(collection);
/* 2031 */         value = collection;
/*      */       }
/* 2033 */       else if ("many-to-one".equals(name)) {
/* 2034 */         value = new ManyToOne(table);
/* 2035 */         bindManyToOne(subnode, (ManyToOne)value, propertyName, nullable, mappings);
/*      */       }
/* 2037 */       else if ("any".equals(name)) {
/* 2038 */         value = new Any(table);
/* 2039 */         bindAny(subnode, (Any)value, nullable, mappings);
/*      */       }
/* 2041 */       else if ("one-to-one".equals(name)) {
/* 2042 */         value = new OneToOne(table, persistentClass);
/* 2043 */         bindOneToOne(subnode, (OneToOne)value, propertyName, true, mappings);
/*      */       }
/* 2045 */       else if ("property".equals(name)) {
/* 2046 */         value = new SimpleValue(table);
/* 2047 */         bindSimpleValue(subnode, (SimpleValue)value, nullable, propertyName, mappings);
/*      */       }
/* 2049 */       else if (("component".equals(name)) || ("dynamic-component".equals(name)) || ("properties".equals(name)))
/*      */       {
/*      */ 
/* 2052 */         String subpath = StringHelper.qualify(entityName, propertyName);
/* 2053 */         value = new Component(persistentClass);
/*      */         
/* 2055 */         bindComponent(subnode, (Component)value, persistentClass.getClassName(), propertyName, subpath, true, "properties".equals(name), mappings, inheritedMetas, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/* 2068 */       else if ("join".equals(name)) {
/* 2069 */         Join join = new Join();
/* 2070 */         join.setPersistentClass(persistentClass);
/* 2071 */         bindJoin(subnode, join, mappings, inheritedMetas);
/* 2072 */         persistentClass.addJoin(join);
/*      */       }
/* 2074 */       else if ("subclass".equals(name)) {
/* 2075 */         handleSubclass(persistentClass, mappings, subnode, inheritedMetas);
/*      */       }
/* 2077 */       else if ("joined-subclass".equals(name)) {
/* 2078 */         handleJoinedSubclass(persistentClass, mappings, subnode, inheritedMetas);
/*      */       }
/* 2080 */       else if ("union-subclass".equals(name)) {
/* 2081 */         handleUnionSubclass(persistentClass, mappings, subnode, inheritedMetas);
/*      */       }
/* 2083 */       else if ("filter".equals(name)) {
/* 2084 */         parseFilter(subnode, persistentClass, mappings);
/*      */       }
/* 2086 */       else if ("natural-id".equals(name)) {
/* 2087 */         UniqueKey uk = new UniqueKey();
/* 2088 */         uk.setName("_UniqueKey");
/* 2089 */         uk.setTable(table);
/*      */         
/* 2091 */         boolean mutableId = "true".equals(subnode.attributeValue("mutable"));
/* 2092 */         createClassProperties(subnode, persistentClass, mappings, inheritedMetas, uk, mutableId, false, true);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2102 */         table.addUniqueKey(uk);
/*      */       }
/* 2104 */       else if ("query".equals(name)) {
/* 2105 */         bindNamedQuery(subnode, persistentClass.getEntityName(), mappings);
/*      */       }
/* 2107 */       else if ("sql-query".equals(name)) {
/* 2108 */         bindNamedSQLQuery(subnode, persistentClass.getEntityName(), mappings);
/*      */       }
/* 2110 */       else if ("resultset".equals(name)) {
/* 2111 */         bindResultSetMappingDefinition(subnode, persistentClass.getEntityName(), mappings);
/*      */       }
/*      */       
/* 2114 */       if (value != null) {
/* 2115 */         Property property = createProperty(value, propertyName, persistentClass.getClassName(), subnode, mappings, inheritedMetas);
/*      */         
/* 2117 */         if (!mutable) property.setUpdateable(false);
/* 2118 */         if (naturalId) property.setNaturalIdentifier(true);
/* 2119 */         persistentClass.addProperty(property);
/* 2120 */         if (uniqueKey != null) { uniqueKey.addColumns(property.getColumnIterator());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Property createProperty(Value value, String propertyName, String className, Element subnode, Mappings mappings, java.util.Map inheritedMetas)
/*      */     throws MappingException
/*      */   {
/* 2134 */     if (StringHelper.isEmpty(propertyName)) {
/* 2135 */       throw new MappingException(subnode.getName() + " mapping must defined a name attribute [" + className + "]");
/*      */     }
/*      */     
/* 2138 */     value.setTypeUsingReflection(className, propertyName);
/*      */     
/*      */ 
/*      */ 
/* 2142 */     if ((value instanceof ToOne)) {
/* 2143 */       ToOne toOne = (ToOne)value;
/* 2144 */       String propertyRef = toOne.getReferencedPropertyName();
/* 2145 */       if (propertyRef != null) {
/* 2146 */         mappings.addUniquePropertyReference(toOne.getReferencedEntityName(), propertyRef);
/*      */       }
/*      */     }
/* 2149 */     else if ((value instanceof Collection)) {
/* 2150 */       Collection coll = (Collection)value;
/* 2151 */       String propertyRef = coll.getReferencedPropertyName();
/*      */       
/* 2153 */       if (propertyRef != null) {
/* 2154 */         mappings.addPropertyReference(coll.getOwnerEntityName(), propertyRef);
/*      */       }
/*      */     }
/*      */     
/* 2158 */     value.createForeignKey();
/* 2159 */     Property prop = new Property();
/* 2160 */     prop.setValue(value);
/* 2161 */     bindProperty(subnode, prop, mappings, inheritedMetas);
/* 2162 */     return prop;
/*      */   }
/*      */   
/*      */   private static void handleUnionSubclass(PersistentClass model, Mappings mappings, Element subnode, java.util.Map inheritedMetas) throws MappingException
/*      */   {
/* 2167 */     UnionSubclass subclass = new UnionSubclass(model);
/* 2168 */     bindUnionSubclass(subnode, subclass, mappings, inheritedMetas);
/* 2169 */     model.addSubclass(subclass);
/* 2170 */     mappings.addClass(subclass);
/*      */   }
/*      */   
/*      */   private static void handleJoinedSubclass(PersistentClass model, Mappings mappings, Element subnode, java.util.Map inheritedMetas) throws MappingException
/*      */   {
/* 2175 */     JoinedSubclass subclass = new JoinedSubclass(model);
/* 2176 */     bindJoinedSubclass(subnode, subclass, mappings, inheritedMetas);
/* 2177 */     model.addSubclass(subclass);
/* 2178 */     mappings.addClass(subclass);
/*      */   }
/*      */   
/*      */   private static void handleSubclass(PersistentClass model, Mappings mappings, Element subnode, java.util.Map inheritedMetas) throws MappingException
/*      */   {
/* 2183 */     Subclass subclass = new SingleTableSubclass(model);
/* 2184 */     bindSubclass(subnode, subclass, mappings, inheritedMetas);
/* 2185 */     model.addSubclass(subclass);
/* 2186 */     mappings.addClass(subclass);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void bindListSecondPass(Element node, org.hibernate.mapping.List list, java.util.Map classes, Mappings mappings, java.util.Map inheritedMetas)
/*      */     throws MappingException
/*      */   {
/* 2195 */     bindCollectionSecondPass(node, list, classes, mappings, inheritedMetas);
/*      */     
/* 2197 */     Element subnode = node.element("list-index");
/* 2198 */     if (subnode == null) subnode = node.element("index");
/* 2199 */     SimpleValue iv = new SimpleValue(list.getCollectionTable());
/* 2200 */     bindSimpleValue(subnode, iv, list.isOneToMany(), "idx", mappings);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2207 */     iv.setTypeName("integer");
/* 2208 */     list.setIndex(iv);
/* 2209 */     String baseIndex = subnode.attributeValue("base");
/* 2210 */     if (baseIndex != null) list.setBaseIndex(Integer.parseInt(baseIndex));
/* 2211 */     list.setIndexNodeName(subnode.attributeValue("node"));
/*      */     
/* 2213 */     if ((list.isOneToMany()) && (!list.getKey().isNullable()) && (!list.isInverse())) {
/* 2214 */       String entityName = ((OneToMany)list.getElement()).getReferencedEntityName();
/* 2215 */       PersistentClass referenced = mappings.getClass(entityName);
/* 2216 */       IndexBackref ib = new IndexBackref();
/* 2217 */       ib.setName('_' + node.attributeValue("name") + "IndexBackref");
/* 2218 */       ib.setUpdateable(false);
/* 2219 */       ib.setSelectable(false);
/* 2220 */       ib.setCollectionRole(list.getRole());
/* 2221 */       ib.setEntityName(list.getOwner().getEntityName());
/* 2222 */       ib.setValue(list.getIndex());
/*      */       
/*      */ 
/* 2225 */       referenced.addProperty(ib);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static void bindIdentifierCollectionSecondPass(Element node, IdentifierCollection collection, java.util.Map persistentClasses, Mappings mappings, java.util.Map inheritedMetas)
/*      */     throws MappingException
/*      */   {
/* 2233 */     bindCollectionSecondPass(node, collection, persistentClasses, mappings, inheritedMetas);
/*      */     
/* 2235 */     Element subnode = node.element("collection-id");
/* 2236 */     SimpleValue id = new SimpleValue(collection.getCollectionTable());
/* 2237 */     bindSimpleValue(subnode, id, false, "id", mappings);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2244 */     collection.setIdentifier(id);
/* 2245 */     makeIdentifier(subnode, id, mappings);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void bindMapSecondPass(Element node, org.hibernate.mapping.Map map, java.util.Map classes, Mappings mappings, java.util.Map inheritedMetas)
/*      */     throws MappingException
/*      */   {
/* 2255 */     bindCollectionSecondPass(node, map, classes, mappings, inheritedMetas);
/*      */     
/* 2257 */     Iterator iter = node.elementIterator();
/* 2258 */     while (iter.hasNext()) {
/* 2259 */       Element subnode = (Element)iter.next();
/* 2260 */       String name = subnode.getName();
/*      */       
/* 2262 */       if (("index".equals(name)) || ("map-key".equals(name))) {
/* 2263 */         SimpleValue value = new SimpleValue(map.getCollectionTable());
/* 2264 */         bindSimpleValue(subnode, value, map.isOneToMany(), "idx", mappings);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2271 */         if (!value.isTypeSpecified()) {
/* 2272 */           throw new MappingException("map index element must specify a type: " + map.getRole());
/*      */         }
/*      */         
/* 2275 */         map.setIndex(value);
/* 2276 */         map.setIndexNodeName(subnode.attributeValue("node"));
/*      */       }
/* 2278 */       else if (("index-many-to-many".equals(name)) || ("map-key-many-to-many".equals(name))) {
/* 2279 */         ManyToOne mto = new ManyToOne(map.getCollectionTable());
/* 2280 */         bindManyToOne(subnode, mto, "idx", map.isOneToMany(), mappings);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2287 */         map.setIndex(mto);
/*      */ 
/*      */       }
/* 2290 */       else if (("composite-index".equals(name)) || ("composite-map-key".equals(name))) {
/* 2291 */         Component component = new Component(map);
/* 2292 */         bindComposite(subnode, component, map.getRole() + ".index", map.isOneToMany(), mappings, inheritedMetas);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2300 */         map.setIndex(component);
/*      */       }
/* 2302 */       else if ("index-many-to-any".equals(name)) {
/* 2303 */         Any any = new Any(map.getCollectionTable());
/* 2304 */         bindAny(subnode, any, map.isOneToMany(), mappings);
/* 2305 */         map.setIndex(any);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2310 */     boolean indexIsFormula = false;
/* 2311 */     Iterator colIter = map.getIndex().getColumnIterator();
/* 2312 */     while (colIter.hasNext()) {
/* 2313 */       if (((Selectable)colIter.next()).isFormula()) { indexIsFormula = true;
/*      */       }
/*      */     }
/* 2316 */     if ((map.isOneToMany()) && (!map.getKey().isNullable()) && (!map.isInverse()) && (!indexIsFormula)) {
/* 2317 */       String entityName = ((OneToMany)map.getElement()).getReferencedEntityName();
/* 2318 */       PersistentClass referenced = mappings.getClass(entityName);
/* 2319 */       IndexBackref ib = new IndexBackref();
/* 2320 */       ib.setName('_' + node.attributeValue("name") + "IndexBackref");
/* 2321 */       ib.setUpdateable(false);
/* 2322 */       ib.setSelectable(false);
/* 2323 */       ib.setCollectionRole(map.getRole());
/* 2324 */       ib.setEntityName(map.getOwner().getEntityName());
/* 2325 */       ib.setValue(map.getIndex());
/*      */       
/*      */ 
/* 2328 */       referenced.addProperty(ib);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void bindCollectionSecondPass(Element node, Collection collection, java.util.Map persistentClasses, Mappings mappings, java.util.Map inheritedMetas)
/*      */     throws MappingException
/*      */   {
/* 2339 */     if (collection.isOneToMany()) {
/* 2340 */       OneToMany oneToMany = (OneToMany)collection.getElement();
/* 2341 */       String assocClass = oneToMany.getReferencedEntityName();
/* 2342 */       PersistentClass persistentClass = (PersistentClass)persistentClasses.get(assocClass);
/* 2343 */       if (persistentClass == null) {
/* 2344 */         throw new MappingException("Association references unmapped class: " + assocClass);
/*      */       }
/* 2346 */       oneToMany.setAssociatedClass(persistentClass);
/* 2347 */       collection.setCollectionTable(persistentClass.getTable());
/*      */       
/* 2349 */       log.info("Mapping collection: " + collection.getRole() + " -> " + collection.getCollectionTable().getName());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2356 */     Attribute chNode = node.attribute("check");
/* 2357 */     if (chNode != null) {
/* 2358 */       collection.getCollectionTable().addCheckConstraint(chNode.getValue());
/*      */     }
/*      */     
/*      */ 
/* 2362 */     Iterator iter = node.elementIterator();
/* 2363 */     while (iter.hasNext()) {
/* 2364 */       Element subnode = (Element)iter.next();
/* 2365 */       String name = subnode.getName();
/*      */       
/* 2367 */       if ("key".equals(name))
/*      */       {
/* 2369 */         String propRef = collection.getReferencedPropertyName();
/* 2370 */         KeyValue keyVal; KeyValue keyVal; if (propRef == null) {
/* 2371 */           keyVal = collection.getOwner().getIdentifier();
/*      */         }
/*      */         else {
/* 2374 */           keyVal = (KeyValue)collection.getOwner().getProperty(propRef).getValue();
/*      */         }
/* 2376 */         SimpleValue key = new DependantValue(collection.getCollectionTable(), keyVal);
/* 2377 */         key.setCascadeDeleteEnabled("cascade".equals(subnode.attributeValue("on-delete")));
/*      */         
/* 2379 */         bindSimpleValue(subnode, key, collection.isOneToMany(), "id", mappings);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2386 */         collection.setKey(key);
/*      */         
/* 2388 */         Attribute notNull = subnode.attribute("not-null");
/* 2389 */         ((DependantValue)key).setNullable((notNull == null) || (notNull.getValue().equals("false")));
/*      */         
/* 2391 */         Attribute updateable = subnode.attribute("update");
/* 2392 */         ((DependantValue)key).setUpdateable((updateable == null) || (updateable.getValue().equals("true")));
/*      */ 
/*      */ 
/*      */       }
/* 2396 */       else if ("element".equals(name)) {
/* 2397 */         SimpleValue elt = new SimpleValue(collection.getCollectionTable());
/* 2398 */         collection.setElement(elt);
/* 2399 */         bindSimpleValue(subnode, elt, true, "elt", mappings);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/* 2407 */       else if ("many-to-many".equals(name)) {
/* 2408 */         ManyToOne element = new ManyToOne(collection.getCollectionTable());
/* 2409 */         collection.setElement(element);
/* 2410 */         bindManyToOne(subnode, element, "elt", false, mappings);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2417 */         bindManyToManyFilters(collection, subnode, mappings);
/*      */       }
/* 2419 */       else if ("composite-element".equals(name)) {
/* 2420 */         Component element = new Component(collection);
/* 2421 */         collection.setElement(element);
/* 2422 */         bindComposite(subnode, element, collection.getRole() + ".element", true, mappings, inheritedMetas);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/* 2431 */       else if ("many-to-any".equals(name)) {
/* 2432 */         Any element = new Any(collection.getCollectionTable());
/* 2433 */         collection.setElement(element);
/* 2434 */         bindAny(subnode, element, true, mappings);
/*      */       }
/* 2436 */       else if ("cache".equals(name)) {
/* 2437 */         collection.setCacheConcurrencyStrategy(subnode.attributeValue("usage"));
/* 2438 */         collection.setCacheRegionName(subnode.attributeValue("region"));
/*      */       }
/*      */       
/* 2441 */       String nodeName = subnode.attributeValue("node");
/* 2442 */       if (nodeName != null) { collection.setElementNodeName(nodeName);
/*      */       }
/*      */     }
/*      */     
/* 2446 */     if ((collection.isOneToMany()) && (!collection.isInverse()) && (!collection.getKey().isNullable()))
/*      */     {
/*      */ 
/*      */ 
/* 2450 */       String entityName = ((OneToMany)collection.getElement()).getReferencedEntityName();
/* 2451 */       PersistentClass referenced = mappings.getClass(entityName);
/* 2452 */       Backref prop = new Backref();
/* 2453 */       prop.setName('_' + node.attributeValue("name") + "Backref");
/* 2454 */       prop.setUpdateable(false);
/* 2455 */       prop.setSelectable(false);
/* 2456 */       prop.setCollectionRole(collection.getRole());
/* 2457 */       prop.setEntityName(collection.getOwner().getEntityName());
/* 2458 */       prop.setValue(collection.getKey());
/* 2459 */       referenced.addProperty(prop);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static void bindManyToManyFilters(Collection collection, Element manyToManyNode, Mappings model)
/*      */     throws MappingException
/*      */   {
/* 2468 */     Attribute where = manyToManyNode.attribute("where");
/* 2469 */     String whereCondition = where == null ? null : where.getValue();
/* 2470 */     collection.setManyToManyWhere(whereCondition);
/*      */     
/*      */ 
/* 2473 */     Iterator filters = manyToManyNode.elementIterator("filter");
/* 2474 */     if (((filters.hasNext()) || (whereCondition != null)) && (collection.getFetchMode() == FetchMode.JOIN) && (collection.getElement().getFetchMode() != FetchMode.JOIN))
/*      */     {
/*      */ 
/* 2477 */       throw new MappingException("many-to-many defining filter or where without join fetching not valid within collection using join fetching [" + collection.getRole() + "]");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2482 */     while (filters.hasNext()) {
/* 2483 */       Element filterElement = (Element)filters.next();
/* 2484 */       String name = filterElement.attributeValue("name");
/* 2485 */       String condition = filterElement.getTextTrim();
/* 2486 */       if (StringHelper.isEmpty(condition)) condition = filterElement.attributeValue("condition");
/* 2487 */       if (StringHelper.isEmpty(condition)) {
/* 2488 */         condition = model.getFilterDefinition(name).getDefaultFilterCondition();
/*      */       }
/* 2490 */       if (condition == null) {
/* 2491 */         throw new MappingException("no filter condition found for filter: " + name);
/*      */       }
/* 2493 */       log.debug("Applying many-to-many filter [" + name + "] as [" + condition + "] to role [" + collection.getRole() + "]");
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2498 */       collection.addManyToManyFilter(name, condition);
/*      */     }
/*      */   }
/*      */   
/*      */   public static final FlushMode getFlushMode(String flushMode) {
/* 2503 */     if (flushMode == null) {
/* 2504 */       return null;
/*      */     }
/* 2506 */     if ("auto".equals(flushMode)) {
/* 2507 */       return FlushMode.AUTO;
/*      */     }
/* 2509 */     if ("commit".equals(flushMode)) {
/* 2510 */       return FlushMode.COMMIT;
/*      */     }
/* 2512 */     if ("never".equals(flushMode)) {
/* 2513 */       return FlushMode.NEVER;
/*      */     }
/* 2515 */     if ("always".equals(flushMode)) {
/* 2516 */       return FlushMode.ALWAYS;
/*      */     }
/*      */     
/* 2519 */     throw new MappingException("unknown flushmode");
/*      */   }
/*      */   
/*      */   private static void bindNamedQuery(Element queryElem, String path, Mappings mappings)
/*      */   {
/* 2524 */     String queryName = queryElem.attributeValue("name");
/* 2525 */     if (path != null) queryName = path + '.' + queryName;
/* 2526 */     String query = queryElem.getText();
/* 2527 */     log.debug("Named query: " + queryName + " -> " + query);
/*      */     
/* 2529 */     boolean cacheable = "true".equals(queryElem.attributeValue("cacheable"));
/* 2530 */     String region = queryElem.attributeValue("cache-region");
/* 2531 */     Attribute tAtt = queryElem.attribute("timeout");
/* 2532 */     Integer timeout = tAtt == null ? null : new Integer(tAtt.getValue());
/* 2533 */     Attribute fsAtt = queryElem.attribute("fetch-size");
/* 2534 */     Integer fetchSize = fsAtt == null ? null : new Integer(fsAtt.getValue());
/* 2535 */     Attribute roAttr = queryElem.attribute("read-only");
/* 2536 */     boolean readOnly = (roAttr != null) && ("true".equals(roAttr.getValue()));
/* 2537 */     Attribute cacheModeAtt = queryElem.attribute("cache-mode");
/* 2538 */     String cacheMode = cacheModeAtt == null ? null : cacheModeAtt.getValue();
/* 2539 */     Attribute cmAtt = queryElem.attribute("comment");
/* 2540 */     String comment = cmAtt == null ? null : cmAtt.getValue();
/*      */     
/* 2542 */     NamedQueryDefinition namedQuery = new NamedQueryDefinition(query, cacheable, region, timeout, fetchSize, getFlushMode(queryElem.attributeValue("flush-mode")), getCacheMode(cacheMode), readOnly, comment, getParameterTypes(queryElem));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2555 */     mappings.addQuery(queryName, namedQuery);
/*      */   }
/*      */   
/*      */   public static CacheMode getCacheMode(String cacheMode) {
/* 2559 */     if (cacheMode == null) return null;
/* 2560 */     if ("get".equals(cacheMode)) return CacheMode.GET;
/* 2561 */     if ("ignore".equals(cacheMode)) return CacheMode.IGNORE;
/* 2562 */     if ("normal".equals(cacheMode)) return CacheMode.NORMAL;
/* 2563 */     if ("put".equals(cacheMode)) return CacheMode.PUT;
/* 2564 */     if ("refresh".equals(cacheMode)) return CacheMode.REFRESH;
/* 2565 */     throw new MappingException("Unknown Cache Mode: " + cacheMode);
/*      */   }
/*      */   
/*      */   public static java.util.Map getParameterTypes(Element queryElem) {
/* 2569 */     java.util.Map result = new SequencedHashMap();
/* 2570 */     Iterator iter = queryElem.elementIterator("query-param");
/* 2571 */     while (iter.hasNext()) {
/* 2572 */       Element element = (Element)iter.next();
/* 2573 */       result.put(element.attributeValue("name"), element.attributeValue("type"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2578 */     return result;
/*      */   }
/*      */   
/*      */   private static void bindResultSetMappingDefinition(Element resultSetElem, String path, Mappings mappings) {
/* 2582 */     mappings.addSecondPass(new ResultSetMappingSecondPass(resultSetElem, path, mappings));
/*      */   }
/*      */   
/*      */   private static void bindNamedSQLQuery(Element queryElem, String path, Mappings mappings) {
/* 2586 */     mappings.addSecondPass(new NamedSQLQuerySecondPass(queryElem, path, mappings));
/*      */   }
/*      */   
/*      */   private static String getPropertyName(Element node) {
/* 2590 */     return node.attributeValue("name");
/*      */   }
/*      */   
/*      */   private static PersistentClass getSuperclass(Mappings mappings, Element subnode) throws MappingException
/*      */   {
/* 2595 */     String extendsName = subnode.attributeValue("extends");
/* 2596 */     PersistentClass superModel = mappings.getClass(extendsName);
/* 2597 */     if (superModel == null) {
/* 2598 */       String qualifiedExtendsName = getClassName(extendsName, mappings);
/* 2599 */       superModel = mappings.getClass(qualifiedExtendsName);
/*      */     }
/*      */     
/* 2602 */     if (superModel == null) {
/* 2603 */       throw new MappingException("Cannot extend unmapped class " + extendsName);
/*      */     }
/* 2605 */     return superModel;
/*      */   }
/*      */   
/*      */   static class CollectionSecondPass extends CollectionSecondPass {
/*      */     Element node;
/*      */     
/*      */     CollectionSecondPass(Element node, Mappings mappings, Collection collection) {
/* 2612 */       super(collection);
/* 2613 */       this.node = node;
/*      */     }
/*      */     
/*      */     public void secondPass(java.util.Map persistentClasses, java.util.Map inheritedMetas) throws MappingException
/*      */     {
/* 2618 */       HbmBinder.bindCollectionSecondPass(this.node, this.collection, persistentClasses, this.mappings, inheritedMetas);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static class IdentifierCollectionSecondPass
/*      */     extends HbmBinder.CollectionSecondPass
/*      */   {
/*      */     IdentifierCollectionSecondPass(Element node, Mappings mappings, Collection collection)
/*      */     {
/* 2630 */       super(mappings, collection);
/*      */     }
/*      */     
/*      */     public void secondPass(java.util.Map persistentClasses, java.util.Map inheritedMetas) throws MappingException
/*      */     {
/* 2635 */       HbmBinder.bindIdentifierCollectionSecondPass(this.node, (IdentifierCollection)this.collection, persistentClasses, this.mappings, inheritedMetas);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static class MapSecondPass
/*      */     extends HbmBinder.CollectionSecondPass
/*      */   {
/*      */     MapSecondPass(Element node, Mappings mappings, org.hibernate.mapping.Map collection)
/*      */     {
/* 2648 */       super(mappings, collection);
/*      */     }
/*      */     
/*      */     public void secondPass(java.util.Map persistentClasses, java.util.Map inheritedMetas) throws MappingException
/*      */     {
/* 2653 */       HbmBinder.bindMapSecondPass(this.node, (org.hibernate.mapping.Map)this.collection, persistentClasses, this.mappings, inheritedMetas);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static class ManyToOneSecondPass
/*      */     implements SecondPass
/*      */   {
/*      */     private final ManyToOne manyToOne;
/*      */     
/*      */ 
/*      */ 
/*      */     ManyToOneSecondPass(ManyToOne manyToOne)
/*      */     {
/* 2669 */       this.manyToOne = manyToOne;
/*      */     }
/*      */     
/*      */     public void doSecondPass(java.util.Map persistentClasses, java.util.Map inheritedMetas) throws MappingException {
/* 2673 */       this.manyToOne.createPropertyRefConstraints(persistentClasses);
/*      */     }
/*      */   }
/*      */   
/*      */   static class ListSecondPass extends HbmBinder.CollectionSecondPass
/*      */   {
/*      */     ListSecondPass(Element node, Mappings mappings, org.hibernate.mapping.List collection) {
/* 2680 */       super(mappings, collection);
/*      */     }
/*      */     
/*      */     public void secondPass(java.util.Map persistentClasses, java.util.Map inheritedMetas) throws MappingException
/*      */     {
/* 2685 */       HbmBinder.bindListSecondPass(this.node, (org.hibernate.mapping.List)this.collection, persistentClasses, this.mappings, inheritedMetas);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static abstract class CollectionType
/*      */   {
/*      */     private String xmlTag;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     CollectionType(String xmlTag)
/*      */     {
/* 2704 */       this.xmlTag = xmlTag;
/*      */     }
/*      */     
/*      */     public String toString() {
/* 2708 */       return this.xmlTag;
/*      */     }
/*      */     
/* 2711 */     private static final CollectionType MAP = new HbmBinder.1("map");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2719 */     private static final CollectionType SET = new HbmBinder.2("set");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2727 */     private static final CollectionType LIST = new HbmBinder.3("list");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2735 */     private static final CollectionType BAG = new HbmBinder.4("bag");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2743 */     private static final CollectionType IDBAG = new HbmBinder.5("idbag");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2751 */     private static final CollectionType ARRAY = new HbmBinder.6("array");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2759 */     private static final CollectionType PRIMITIVE_ARRAY = new HbmBinder.7("primitive-array");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2767 */     private static final HashMap INSTANCES = new HashMap();
/*      */     
/*      */     static {
/* 2770 */       INSTANCES.put(MAP.toString(), MAP);
/* 2771 */       INSTANCES.put(BAG.toString(), BAG);
/* 2772 */       INSTANCES.put(IDBAG.toString(), IDBAG);
/* 2773 */       INSTANCES.put(SET.toString(), SET);
/* 2774 */       INSTANCES.put(LIST.toString(), LIST);
/* 2775 */       INSTANCES.put(ARRAY.toString(), ARRAY);
/* 2776 */       INSTANCES.put(PRIMITIVE_ARRAY.toString(), PRIMITIVE_ARRAY);
/*      */     }
/*      */     
/*      */ 
/* 2780 */     public static CollectionType collectionTypeFromString(String xmlTagName) { return (CollectionType)INSTANCES.get(xmlTagName); }
/*      */     
/*      */     public abstract Collection create(Element paramElement, String paramString, PersistentClass paramPersistentClass, Mappings paramMappings) throws MappingException;
/*      */   }
/*      */   
/*      */   private static int getOptimisticLockMode(Attribute olAtt) throws MappingException {
/* 2786 */     if (olAtt == null) return 0;
/* 2787 */     String olMode = olAtt.getValue();
/* 2788 */     if ((olMode == null) || ("version".equals(olMode))) {
/* 2789 */       return 0;
/*      */     }
/* 2791 */     if ("dirty".equals(olMode)) {
/* 2792 */       return 1;
/*      */     }
/* 2794 */     if ("all".equals(olMode)) {
/* 2795 */       return 2;
/*      */     }
/* 2797 */     if ("none".equals(olMode)) {
/* 2798 */       return -1;
/*      */     }
/*      */     
/* 2801 */     throw new MappingException("Unsupported optimistic-lock style: " + olMode);
/*      */   }
/*      */   
/*      */   private static final java.util.Map getMetas(Element node, java.util.Map inheritedMeta)
/*      */   {
/* 2806 */     return getMetas(node, inheritedMeta, false);
/*      */   }
/*      */   
/*      */   public static final java.util.Map getMetas(Element node, java.util.Map inheritedMeta, boolean onlyInheritable)
/*      */   {
/* 2811 */     java.util.Map map = new HashMap();
/* 2812 */     map.putAll(inheritedMeta);
/*      */     
/* 2814 */     Iterator iter = node.elementIterator("meta");
/* 2815 */     while (iter.hasNext()) {
/* 2816 */       Element metaNode = (Element)iter.next();
/* 2817 */       boolean inheritable = Boolean.valueOf(metaNode.attributeValue("inherit")).booleanValue();
/*      */       
/*      */ 
/* 2820 */       if (!(onlyInheritable & !inheritable))
/*      */       {
/*      */ 
/* 2823 */         String name = metaNode.attributeValue("attribute");
/*      */         
/* 2825 */         MetaAttribute meta = (MetaAttribute)map.get(name);
/* 2826 */         if (meta == null) {
/* 2827 */           meta = new MetaAttribute(name);
/* 2828 */           map.put(name, meta);
/*      */         }
/* 2830 */         meta.addValue(metaNode.getText());
/*      */       } }
/* 2832 */     return map;
/*      */   }
/*      */   
/*      */   public static String getEntityName(Element elem, Mappings model) {
/* 2836 */     String entityName = elem.attributeValue("entity-name");
/* 2837 */     return entityName == null ? getClassName(elem.attribute("class"), model) : entityName;
/*      */   }
/*      */   
/*      */   private static String getClassName(Attribute att, Mappings model) {
/* 2841 */     if (att == null) return null;
/* 2842 */     return getClassName(att.getValue(), model);
/*      */   }
/*      */   
/*      */   public static String getClassName(String unqualifiedName, Mappings model) {
/* 2846 */     return getClassName(unqualifiedName, model.getDefaultPackage());
/*      */   }
/*      */   
/*      */   public static String getClassName(String unqualifiedName, String defaultPackage) {
/* 2850 */     if (unqualifiedName == null) return null;
/* 2851 */     if ((unqualifiedName.indexOf('.') < 0) && (defaultPackage != null)) {
/* 2852 */       return defaultPackage + '.' + unqualifiedName;
/*      */     }
/* 2854 */     return unqualifiedName;
/*      */   }
/*      */   
/*      */   private static void parseFilterDef(Element element, Mappings mappings) {
/* 2858 */     String name = element.attributeValue("name");
/* 2859 */     log.debug("Parsing filter-def [" + name + "]");
/* 2860 */     String defaultCondition = element.getTextTrim();
/* 2861 */     if (StringHelper.isEmpty(defaultCondition)) {
/* 2862 */       defaultCondition = element.attributeValue("condition");
/*      */     }
/* 2864 */     HashMap paramMappings = new HashMap();
/* 2865 */     Iterator params = element.elementIterator("filter-param");
/* 2866 */     while (params.hasNext()) {
/* 2867 */       Element param = (Element)params.next();
/* 2868 */       String paramName = param.attributeValue("name");
/* 2869 */       String paramType = param.attributeValue("type");
/* 2870 */       log.debug("adding filter parameter : " + paramName + " -> " + paramType);
/* 2871 */       Type heuristicType = TypeFactory.heuristicType(paramType);
/* 2872 */       log.debug("parameter heuristic type : " + heuristicType);
/* 2873 */       paramMappings.put(paramName, heuristicType);
/*      */     }
/* 2875 */     log.debug("Parsed filter-def [" + name + "]");
/* 2876 */     FilterDefinition def = new FilterDefinition(name, defaultCondition, paramMappings);
/* 2877 */     mappings.addFilterDefinition(def);
/*      */   }
/*      */   
/*      */   private static void parseFilter(Element filterElement, Filterable filterable, Mappings model) {
/* 2881 */     String name = filterElement.attributeValue("name");
/* 2882 */     String condition = filterElement.getTextTrim();
/* 2883 */     if (StringHelper.isEmpty(condition)) {
/* 2884 */       condition = filterElement.attributeValue("condition");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2892 */     if (StringHelper.isEmpty(condition)) {
/* 2893 */       condition = model.getFilterDefinition(name).getDefaultFilterCondition();
/*      */     }
/* 2895 */     if (condition == null) {
/* 2896 */       throw new MappingException("no filter condition found for filter: " + name);
/*      */     }
/* 2898 */     log.debug("Applying filter [" + name + "] as [" + condition + "]");
/* 2899 */     filterable.addFilter(name, condition);
/*      */   }
/*      */   
/*      */   private static String getSubselect(Element element) {
/* 2903 */     String subselect = element.attributeValue("subselect");
/* 2904 */     if (subselect != null) {
/* 2905 */       return subselect;
/*      */     }
/*      */     
/* 2908 */     Element subselectElement = element.element("subselect");
/* 2909 */     return subselectElement == null ? null : subselectElement.getText();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static java.util.List getExtendsNeeded(Document doc, Mappings mappings)
/*      */   {
/* 2922 */     java.util.List extendz = new ArrayList();
/* 2923 */     Iterator[] subclasses = new Iterator[3];
/* 2924 */     Element hmNode = doc.getRootElement();
/*      */     
/* 2926 */     Attribute packNode = hmNode.attribute("package");
/* 2927 */     final String packageName = packNode == null ? null : packNode.getValue();
/* 2928 */     if (packageName != null) {
/* 2929 */       mappings.setDefaultPackage(packageName);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2935 */     subclasses[0] = hmNode.elementIterator("subclass");
/* 2936 */     subclasses[1] = hmNode.elementIterator("joined-subclass");
/* 2937 */     subclasses[2] = hmNode.elementIterator("union-subclass");
/*      */     
/* 2939 */     Iterator iterator = new JoinedIterator(subclasses);
/* 2940 */     while (iterator.hasNext()) {
/* 2941 */       Element element = (Element)iterator.next();
/* 2942 */       String extendsName = element.attributeValue("extends");
/*      */       
/*      */ 
/* 2945 */       if ((mappings.getClass(extendsName) == null) && (mappings.getClass(getClassName(extendsName, mappings)) == null)) {
/* 2946 */         extendz.add(extendsName);
/*      */       }
/*      */     }
/*      */     
/* 2950 */     if (!extendz.isEmpty())
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2958 */       Set set = new HashSet(extendz);
/* 2959 */       EntityElementHandler handler = new EntityElementHandler() { private final Set val$set;
/*      */         
/* 2961 */         public void handleEntity(String entityName, String className, Mappings mappings) { if (entityName != null) {
/* 2962 */             this.val$set.remove(entityName);
/*      */           }
/*      */           else {
/* 2965 */             String fqn = HbmBinder.getClassName(className, packageName);
/* 2966 */             this.val$set.remove(fqn);
/* 2967 */             if (packageName != null) {
/* 2968 */               this.val$set.remove(StringHelper.unqualify(fqn));
/*      */             }
/*      */           }
/*      */         }
/* 2972 */       };
/* 2973 */       recognizeEntities(mappings, hmNode, handler);
/* 2974 */       extendz.clear();
/* 2975 */       extendz.addAll(set);
/*      */     }
/*      */     
/* 2978 */     return extendz;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void recognizeEntities(Mappings mappings, Element startNode, EntityElementHandler handler)
/*      */   {
/* 2994 */     Iterator[] classes = new Iterator[4];
/* 2995 */     classes[0] = startNode.elementIterator("class");
/* 2996 */     classes[1] = startNode.elementIterator("subclass");
/* 2997 */     classes[2] = startNode.elementIterator("joined-subclass");
/* 2998 */     classes[3] = startNode.elementIterator("union-subclass");
/*      */     
/* 3000 */     Iterator classIterator = new JoinedIterator(classes);
/* 3001 */     while (classIterator.hasNext()) {
/* 3002 */       Element element = (Element)classIterator.next();
/* 3003 */       handler.handleEntity(element.attributeValue("entity-name"), element.attributeValue("name"), mappings);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 3008 */       recognizeEntities(mappings, element, handler);
/*      */     }
/*      */   }
/*      */   
/*      */   private static abstract interface EntityElementHandler
/*      */   {
/*      */     public abstract void handleEntity(String paramString1, String paramString2, Mappings paramMappings);
/*      */   }
/*      */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cfg\HbmBinder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */