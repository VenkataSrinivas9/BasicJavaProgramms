/*    */ package org.hibernate.cfg;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.dom4j.Element;
/*    */ import org.hibernate.MappingException;
/*    */ import org.hibernate.engine.ResultSetMappingDefinition;
/*    */ 
/*    */ 
/*    */ public class ResultSetMappingSecondPass
/*    */   extends ResultSetMappingBinder
/*    */   implements QuerySecondPass
/*    */ {
/*    */   private Element element;
/*    */   private String path;
/*    */   private Mappings mappings;
/*    */   
/*    */   public ResultSetMappingSecondPass(Element element, String path, Mappings mappings)
/*    */   {
/* 19 */     this.element = element;
/* 20 */     this.path = path;
/* 21 */     this.mappings = mappings;
/*    */   }
/*    */   
/*    */   public void doSecondPass(Map persistentClasses, Map inheritedMetas) throws MappingException {
/* 25 */     ResultSetMappingDefinition definition = buildResultSetMappingDefinition(this.element, this.path, this.mappings);
/* 26 */     this.mappings.addResultSetMapping(definition);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cfg\ResultSetMappingSecondPass.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */