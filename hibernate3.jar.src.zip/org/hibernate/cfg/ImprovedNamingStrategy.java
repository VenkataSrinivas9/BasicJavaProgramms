/*     */ package org.hibernate.cfg;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImprovedNamingStrategy
/*     */   implements NamingStrategy, Serializable
/*     */ {
/*  20 */   public static final NamingStrategy INSTANCE = new ImprovedNamingStrategy();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String classToTableName(String className)
/*     */   {
/*  27 */     return addUnderscores(StringHelper.unqualify(className));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String propertyToColumnName(String propertyName)
/*     */   {
/*  34 */     return addUnderscores(StringHelper.unqualify(propertyName));
/*     */   }
/*     */   
/*     */ 
/*     */   public String tableName(String tableName)
/*     */   {
/*  40 */     return addUnderscores(tableName);
/*     */   }
/*     */   
/*     */ 
/*     */   public String columnName(String columnName)
/*     */   {
/*  46 */     return addUnderscores(columnName);
/*     */   }
/*     */   
/*     */   protected static String addUnderscores(String name) {
/*  50 */     StringBuffer buf = new StringBuffer(name.replace('.', '_'));
/*  51 */     for (int i = 1; i < buf.length() - 1; i++) {
/*  52 */       if ((Character.isLowerCase(buf.charAt(i - 1))) && (Character.isUpperCase(buf.charAt(i))) && (Character.isLowerCase(buf.charAt(i + 1))))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*  57 */         buf.insert(i++, '_');
/*     */       }
/*     */     }
/*  60 */     return buf.toString().toLowerCase();
/*     */   }
/*     */   
/*     */   public String collectionTableName(String ownerEntityTable, String associatedEntityTable, String propertyName) {
/*  64 */     return tableName(ownerEntityTable + '_' + propertyToColumnName(propertyName));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String joinKeyColumnName(String joinedColumn, String joinedTable)
/*     */   {
/*  71 */     return columnName(joinedColumn);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String foreignKeyColumnName(String propertyName, String propertyTableName, String referencedColumnName)
/*     */   {
/*  78 */     String header = propertyName != null ? StringHelper.unqualify(propertyName) : propertyTableName;
/*  79 */     if (header == null) throw new AssertionFailure("NammingStrategy not properly filled");
/*  80 */     return columnName(header);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String logicalColumnName(String columnName, String propertyName)
/*     */   {
/*  87 */     return StringHelper.isNotEmpty(columnName) ? columnName : StringHelper.unqualify(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String logicalCollectionTableName(String tableName, String ownerEntityTable, String associatedEntityTable, String propertyName)
/*     */   {
/*  98 */     if (tableName != null) {
/*  99 */       return tableName;
/*     */     }
/*     */     
/*     */ 
/* 103 */     return ownerEntityTable + "_" + (associatedEntityTable != null ? associatedEntityTable : StringHelper.unqualify(propertyName));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String logicalCollectionColumnName(String columnName, String propertyName, String referencedColumn)
/*     */   {
/* 115 */     return StringHelper.unqualify(propertyName) + "_" + referencedColumn;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cfg\ImprovedNamingStrategy.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */