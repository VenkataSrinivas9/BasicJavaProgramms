/*     */ package org.hibernate.intercept;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Set;
/*     */ import net.sf.cglib.transform.impl.InterceptFieldCallback;
/*     */ import net.sf.cglib.transform.impl.InterceptFieldEnabled;
/*     */ import org.hibernate.LazyInitializationException;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.proxy.HibernateProxy;
/*     */ import org.hibernate.proxy.LazyInitializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FieldInterceptor
/*     */   implements InterceptFieldCallback, Serializable
/*     */ {
/*     */   private transient SessionImplementor session;
/*     */   private Set uninitializedFields;
/*     */   private final String entityName;
/*     */   private transient boolean initializing;
/*     */   private boolean dirty;
/*     */   
/*     */   private FieldInterceptor(SessionImplementor session, String entityName, Set uninitializedFields)
/*     */   {
/*  33 */     this.session = session;
/*  34 */     this.entityName = entityName;
/*  35 */     this.uninitializedFields = uninitializedFields;
/*     */   }
/*     */   
/*     */   public void setSession(SessionImplementor session) {
/*  39 */     this.session = session;
/*     */   }
/*     */   
/*     */   public boolean isInitialized() {
/*  43 */     return (this.uninitializedFields == null) || (this.uninitializedFields.size() == 0);
/*     */   }
/*     */   
/*     */   public boolean isInitialized(String field) {
/*  47 */     return (this.uninitializedFields == null) || (!this.uninitializedFields.contains(field));
/*     */   }
/*     */   
/*     */   public void dirty() {
/*  51 */     this.dirty = true;
/*     */   }
/*     */   
/*     */   public boolean isDirty() {
/*  55 */     return this.dirty;
/*     */   }
/*     */   
/*     */   public void clearDirty() {
/*  59 */     this.dirty = false;
/*     */   }
/*     */   
/*     */   private Object intercept(Object target, String fieldName, Object value) {
/*  63 */     if (this.initializing) { return value;
/*     */     }
/*  65 */     if ((this.uninitializedFields != null) && (this.uninitializedFields.contains(fieldName))) {
/*  66 */       if (this.session == null) {
/*  67 */         throw new LazyInitializationException("entity with lazy properties is not associated with a session");
/*     */       }
/*  69 */       if ((!this.session.isOpen()) || (!this.session.isConnected())) {
/*  70 */         throw new LazyInitializationException("session is not connected");
/*     */       }
/*     */       
/*     */ 
/*  74 */       this.initializing = true;
/*     */       try {
/*  76 */         result = ((LazyPropertyInitializer)this.session.getFactory().getEntityPersister(this.entityName)).initializeLazyProperty(fieldName, target, this.session);
/*     */       }
/*     */       finally
/*     */       {
/*     */         Object result;
/*  81 */         this.initializing = false; }
/*     */       Object result;
/*  83 */       this.uninitializedFields = null;
/*  84 */       return result;
/*     */     }
/*     */     
/*  87 */     return value;
/*     */   }
/*     */   
/*     */   public boolean readBoolean(Object target, String name, boolean oldValue)
/*     */   {
/*  92 */     return ((Boolean)intercept(target, name, oldValue ? Boolean.TRUE : Boolean.FALSE)).booleanValue();
/*     */   }
/*     */   
/*     */   public byte readByte(Object target, String name, byte oldValue)
/*     */   {
/*  97 */     return ((Byte)intercept(target, name, new Byte(oldValue))).byteValue();
/*     */   }
/*     */   
/*     */   public char readChar(Object target, String name, char oldValue) {
/* 101 */     return ((Character)intercept(target, name, new Character(oldValue))).charValue();
/*     */   }
/*     */   
/*     */   public double readDouble(Object target, String name, double oldValue)
/*     */   {
/* 106 */     return ((Double)intercept(target, name, new Double(oldValue))).doubleValue();
/*     */   }
/*     */   
/*     */   public float readFloat(Object target, String name, float oldValue)
/*     */   {
/* 111 */     return ((Float)intercept(target, name, new Float(oldValue))).floatValue();
/*     */   }
/*     */   
/*     */   public int readInt(Object target, String name, int oldValue)
/*     */   {
/* 116 */     return ((Integer)intercept(target, name, new Integer(oldValue))).intValue();
/*     */   }
/*     */   
/*     */   public long readLong(Object target, String name, long oldValue)
/*     */   {
/* 121 */     return ((Long)intercept(target, name, new Long(oldValue))).longValue();
/*     */   }
/*     */   
/*     */   public short readShort(Object target, String name, short oldValue) {
/* 125 */     return ((Short)intercept(target, name, new Short(oldValue))).shortValue();
/*     */   }
/*     */   
/*     */   public Object readObject(Object target, String name, Object oldValue)
/*     */   {
/* 130 */     Object value = intercept(target, name, oldValue);
/* 131 */     if ((value instanceof HibernateProxy)) {
/* 132 */       LazyInitializer li = ((HibernateProxy)value).getHibernateLazyInitializer();
/* 133 */       if (li.isUnwrap()) {
/* 134 */         value = li.getImplementation();
/*     */       }
/*     */     }
/* 137 */     return value;
/*     */   }
/*     */   
/*     */   public boolean writeBoolean(Object target, String name, boolean oldValue, boolean newValue) {
/* 141 */     dirty();
/* 142 */     intercept(target, name, oldValue ? Boolean.TRUE : Boolean.FALSE);
/* 143 */     return newValue;
/*     */   }
/*     */   
/*     */   public byte writeByte(Object target, String name, byte oldValue, byte newValue) {
/* 147 */     dirty();
/* 148 */     intercept(target, name, new Byte(oldValue));
/* 149 */     return newValue;
/*     */   }
/*     */   
/*     */   public char writeChar(Object target, String name, char oldValue, char newValue) {
/* 153 */     dirty();
/* 154 */     intercept(target, name, new Character(oldValue));
/* 155 */     return newValue;
/*     */   }
/*     */   
/*     */   public double writeDouble(Object target, String name, double oldValue, double newValue) {
/* 159 */     dirty();
/* 160 */     intercept(target, name, new Double(oldValue));
/* 161 */     return newValue;
/*     */   }
/*     */   
/*     */   public float writeFloat(Object target, String name, float oldValue, float newValue) {
/* 165 */     dirty();
/* 166 */     intercept(target, name, new Float(oldValue));
/* 167 */     return newValue;
/*     */   }
/*     */   
/*     */   public int writeInt(Object target, String name, int oldValue, int newValue) {
/* 171 */     dirty();
/* 172 */     intercept(target, name, new Integer(oldValue));
/* 173 */     return newValue;
/*     */   }
/*     */   
/*     */   public long writeLong(Object target, String name, long oldValue, long newValue) {
/* 177 */     dirty();
/* 178 */     intercept(target, name, new Long(oldValue));
/* 179 */     return newValue;
/*     */   }
/*     */   
/*     */   public short writeShort(Object target, String name, short oldValue, short newValue) {
/* 183 */     dirty();
/* 184 */     intercept(target, name, new Short(oldValue));
/* 185 */     return newValue;
/*     */   }
/*     */   
/*     */   public Object writeObject(Object target, String name, Object oldValue, Object newValue) {
/* 189 */     dirty();
/* 190 */     intercept(target, name, oldValue);
/* 191 */     return newValue;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 195 */     return "FieldInterceptor(entityName=" + this.entityName + ",dirty=" + this.dirty + ",uninitializedFields=" + this.uninitializedFields + ')';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void clearDirty(Object entity)
/*     */   {
/* 203 */     if (hasInterceptor(entity)) {
/* 204 */       getFieldInterceptor(entity).clearDirty();
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean hasInterceptor(Object entity) {
/* 209 */     return ((entity instanceof InterceptFieldEnabled)) && (((InterceptFieldEnabled)entity).getInterceptFieldCallback() != null);
/*     */   }
/*     */   
/*     */   public static FieldInterceptor getFieldInterceptor(Object entity)
/*     */   {
/* 214 */     return (FieldInterceptor)((InterceptFieldEnabled)entity).getInterceptFieldCallback();
/*     */   }
/*     */   
/*     */   public static FieldInterceptor initFieldInterceptor(Object entity, String entityName, SessionImplementor session, Set lazyProps) {
/* 218 */     FieldInterceptor fieldInterceptor = new FieldInterceptor(session, entityName, lazyProps);
/* 219 */     ((InterceptFieldEnabled)entity).setInterceptFieldCallback(fieldInterceptor);
/* 220 */     return fieldInterceptor;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\intercept\FieldInterceptor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */