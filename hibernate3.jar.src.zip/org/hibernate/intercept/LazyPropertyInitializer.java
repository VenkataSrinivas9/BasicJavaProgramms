/*    */ package org.hibernate.intercept;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface LazyPropertyInitializer
/*    */ {
/* 33 */   public static final Serializable UNFETCHED_PROPERTY = new Serializable() {
/*    */     public String toString() {
/* 35 */       return "<lazy>";
/*    */     }
/*    */     
/*    */     public Object readResolve() {
/* 39 */       return LazyPropertyInitializer.UNFETCHED_PROPERTY;
/*    */     }
/*    */   };
/*    */   
/*    */   public abstract Object initializeLazyProperty(String paramString, Object paramObject, SessionImplementor paramSessionImplementor)
/*    */     throws HibernateException;
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\intercept\LazyPropertyInitializer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */