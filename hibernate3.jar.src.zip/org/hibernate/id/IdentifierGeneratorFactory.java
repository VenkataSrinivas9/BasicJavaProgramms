/*     */ package org.hibernate.id;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.ReflectHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class IdentifierGeneratorFactory
/*     */ {
/*  25 */   private static final Log log = LogFactory.getLog(IdentifierGeneratorFactory.class);
/*     */   
/*     */ 
/*     */ 
/*     */   public static Serializable getGeneratedIdentity(ResultSet rs, Type type)
/*     */     throws SQLException, HibernateException, IdentifierGenerationException
/*     */   {
/*  32 */     if (!rs.next()) {
/*  33 */       throw new HibernateException("The database returned no natively generated identity value");
/*     */     }
/*  35 */     Serializable id = get(rs, type);
/*     */     
/*  37 */     if (log.isDebugEnabled()) log.debug("Natively generated identity: " + id);
/*  38 */     return id;
/*     */   }
/*     */   
/*     */ 
/*     */   public static Serializable get(ResultSet rs, Type type)
/*     */     throws SQLException, IdentifierGenerationException
/*     */   {
/*  45 */     Class clazz = type.getReturnedClass();
/*  46 */     if (clazz == Long.class) {
/*  47 */       return new Long(rs.getLong(1));
/*     */     }
/*  49 */     if (clazz == Integer.class) {
/*  50 */       return new Integer(rs.getInt(1));
/*     */     }
/*  52 */     if (clazz == Short.class) {
/*  53 */       return new Short(rs.getShort(1));
/*     */     }
/*  55 */     if (clazz == String.class) {
/*  56 */       return rs.getString(1);
/*     */     }
/*     */     
/*  59 */     throw new IdentifierGenerationException("this id generator generates long, integer, short or string");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*  64 */   private static final HashMap GENERATORS = new HashMap();
/*     */   
/*  66 */   public static final Serializable SHORT_CIRCUIT_INDICATOR = new Serializable() {
/*  67 */     public String toString() { return "SHORT_CIRCUIT_INDICATOR"; }
/*     */   };
/*     */   
/*  70 */   public static final Serializable POST_INSERT_INDICATOR = new Serializable() {
/*  71 */     public String toString() { return "POST_INSERT_INDICATOR"; }
/*     */   };
/*     */   
/*     */   static {
/*  75 */     GENERATORS.put("uuid", UUIDHexGenerator.class);
/*  76 */     GENERATORS.put("hilo", TableHiLoGenerator.class);
/*  77 */     GENERATORS.put("assigned", Assigned.class);
/*  78 */     GENERATORS.put("identity", IdentityGenerator.class);
/*  79 */     GENERATORS.put("select", SelectGenerator.class);
/*  80 */     GENERATORS.put("sequence", SequenceGenerator.class);
/*  81 */     GENERATORS.put("seqhilo", SequenceHiLoGenerator.class);
/*  82 */     GENERATORS.put("increment", IncrementGenerator.class);
/*  83 */     GENERATORS.put("foreign", ForeignGenerator.class);
/*  84 */     GENERATORS.put("guid", GUIDGenerator.class);
/*  85 */     GENERATORS.put("uuid.hex", UUIDHexGenerator.class);
/*     */   }
/*     */   
/*     */   public static IdentifierGenerator create(String strategy, Type type, Properties params, Dialect dialect) throws MappingException
/*     */   {
/*     */     try {
/*  91 */       Class clazz = getIdentifierGeneratorClass(strategy, dialect);
/*  92 */       IdentifierGenerator idgen = (IdentifierGenerator)clazz.newInstance();
/*  93 */       if ((idgen instanceof Configurable)) ((Configurable)idgen).configure(type, params, dialect);
/*  94 */       return idgen;
/*     */     }
/*     */     catch (Exception e) {
/*  97 */       throw new MappingException("could not instantiate id generator", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Class getIdentifierGeneratorClass(String strategy, Dialect dialect) {
/* 102 */     Class clazz = (Class)GENERATORS.get(strategy);
/* 103 */     if ("native".equals(strategy)) clazz = dialect.getNativeIdentifierGeneratorClass();
/*     */     try {
/* 105 */       if (clazz == null) clazz = ReflectHelper.classForName(strategy);
/*     */     }
/*     */     catch (ClassNotFoundException e) {
/* 108 */       throw new MappingException("could not interpret id generator strategy: " + strategy);
/*     */     }
/* 110 */     return clazz;
/*     */   }
/*     */   
/*     */   public static Number createNumber(long value, Class clazz) throws IdentifierGenerationException {
/* 114 */     if (clazz == Long.class) {
/* 115 */       return new Long(value);
/*     */     }
/* 117 */     if (clazz == Integer.class) {
/* 118 */       return new Integer((int)value);
/*     */     }
/* 120 */     if (clazz == Short.class) {
/* 121 */       return new Short((short)(int)value);
/*     */     }
/*     */     
/* 124 */     throw new IdentifierGenerationException("this id generator generates long, integer, short");
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\id\IdentifierGeneratorFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */