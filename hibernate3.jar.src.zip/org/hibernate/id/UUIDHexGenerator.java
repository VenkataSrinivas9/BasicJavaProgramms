/*    */ package org.hibernate.id;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.io.Serializable;
/*    */ import java.util.Properties;
/*    */ import org.hibernate.Hibernate;
/*    */ import org.hibernate.dialect.Dialect;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.type.Type;
/*    */ import org.hibernate.util.PropertiesHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UUIDHexGenerator
/*    */   extends AbstractUUIDGenerator
/*    */   implements Configurable
/*    */ {
/* 28 */   private String sep = "";
/*    */   
/*    */   protected String format(int intval) {
/* 31 */     String formatted = Integer.toHexString(intval);
/* 32 */     StringBuffer buf = new StringBuffer("00000000");
/* 33 */     buf.replace(8 - formatted.length(), 8, formatted);
/* 34 */     return buf.toString();
/*    */   }
/*    */   
/*    */   protected String format(short shortval) {
/* 38 */     String formatted = Integer.toHexString(shortval);
/* 39 */     StringBuffer buf = new StringBuffer("0000");
/* 40 */     buf.replace(4 - formatted.length(), 4, formatted);
/* 41 */     return buf.toString();
/*    */   }
/*    */   
/*    */   public Serializable generate(SessionImplementor session, Object obj) {
/* 45 */     return 36 + format(getIP()) + this.sep + format(getJVM()) + this.sep + format(getHiTime()) + this.sep + format(getLoTime()) + this.sep + format(getCount());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void configure(Type type, Properties params, Dialect d)
/*    */   {
/* 55 */     this.sep = PropertiesHelper.getString("separator", params, "");
/*    */   }
/*    */   
/*    */   public static void main(String[] args) throws Exception {
/* 59 */     Properties props = new Properties();
/* 60 */     props.setProperty("separator", "/");
/* 61 */     IdentifierGenerator gen = new UUIDHexGenerator();
/* 62 */     ((Configurable)gen).configure(Hibernate.STRING, props, null);
/* 63 */     IdentifierGenerator gen2 = new UUIDHexGenerator();
/* 64 */     ((Configurable)gen2).configure(Hibernate.STRING, props, null);
/*    */     
/* 66 */     for (int i = 0; i < 10; i++) {
/* 67 */       String id = (String)gen.generate(null, null);
/* 68 */       System.out.println(id);
/* 69 */       String id2 = (String)gen2.generate(null, null);
/* 70 */       System.out.println(id2);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\id\UUIDHexGenerator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */