/*    */ package org.hibernate.id;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IdentityGenerator
/*    */   extends AbstractPostInsertGenerator
/*    */ {
/*    */   protected String getSQL(PostInsertIdentityPersister persister)
/*    */   {
/* 22 */     return persister.getIdentitySelectString();
/*    */   }
/*    */   
/*    */   protected Serializable getResult(SessionImplementor session, ResultSet rs, Object object, PostInsertIdentityPersister persister) throws SQLException
/*    */   {
/* 27 */     return IdentifierGeneratorFactory.getGeneratedIdentity(rs, persister.getIdentifierType());
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\id\IdentityGenerator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */