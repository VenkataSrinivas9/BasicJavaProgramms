package org.hibernate.id;

import java.util.Properties;
import org.hibernate.MappingException;
import org.hibernate.dialect.Dialect;
import org.hibernate.type.Type;

public abstract interface Configurable
{
  public abstract void configure(Type paramType, Properties paramProperties, Dialect paramDialect)
    throws MappingException;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\id\Configurable.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */