/*     */ package org.hibernate.id;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.exception.JDBCExceptionHelper;
/*     */ import org.hibernate.jdbc.Batcher;
/*     */ import org.hibernate.mapping.Table;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IncrementGenerator
/*     */   implements IdentifierGenerator, Configurable
/*     */ {
/*  34 */   private static final Log log = LogFactory.getLog(IncrementGenerator.class);
/*     */   
/*     */   private long next;
/*     */   private String sql;
/*     */   private Class returnClass;
/*     */   
/*     */   public synchronized Serializable generate(SessionImplementor session, Object object)
/*     */     throws HibernateException
/*     */   {
/*  43 */     if (this.sql != null) {
/*  44 */       getNext(session);
/*     */     }
/*  46 */     return IdentifierGeneratorFactory.createNumber(this.next++, this.returnClass);
/*     */   }
/*     */   
/*     */   public void configure(Type type, Properties params, Dialect dialect)
/*     */     throws MappingException
/*     */   {
/*  52 */     String tableList = params.getProperty("tables");
/*  53 */     if (tableList == null) tableList = params.getProperty("identity_tables");
/*  54 */     String[] tables = StringHelper.split(", ", tableList);
/*  55 */     String column = params.getProperty("column");
/*  56 */     if (column == null) column = params.getProperty("target_column");
/*  57 */     String schema = params.getProperty("schema");
/*  58 */     String catalog = params.getProperty("catalog");
/*  59 */     this.returnClass = type.getReturnedClass();
/*     */     
/*     */ 
/*  62 */     StringBuffer buf = new StringBuffer();
/*  63 */     for (int i = 0; i < tables.length; i++) {
/*  64 */       if (tables.length > 1) {
/*  65 */         buf.append("select ").append(column).append(" from ");
/*     */       }
/*  67 */       buf.append(Table.qualify(catalog, schema, tables[i]));
/*  68 */       if (i < tables.length - 1) buf.append(" union ");
/*     */     }
/*  70 */     if (tables.length > 1) {
/*  71 */       buf.insert(0, "( ").append(" ) ids_");
/*  72 */       column = "ids_." + column;
/*     */     }
/*     */     
/*  75 */     this.sql = ("select max(" + column + ") from " + buf.toString());
/*     */   }
/*     */   
/*     */   private void getNext(SessionImplementor session)
/*     */   {
/*  80 */     log.debug("fetching initial value: " + this.sql);
/*     */     try
/*     */     {
/*  83 */       PreparedStatement st = session.getBatcher().prepareSelectStatement(this.sql);
/*     */       try {
/*  85 */         ResultSet rs = st.executeQuery();
/*     */         try {
/*  87 */           if (rs.next()) {
/*  88 */             this.next = (rs.getLong(1) + 1L);
/*  89 */             if (rs.wasNull()) this.next = 1L;
/*     */           }
/*     */           else {
/*  92 */             this.next = 1L;
/*     */           }
/*  94 */           this.sql = null;
/*  95 */           log.debug("first free id: " + this.next);
/*     */         }
/*     */         finally {
/*  98 */           rs.close();
/*     */         }
/*     */       }
/*     */       finally {
/* 102 */         session.getBatcher().closeStatement(st);
/*     */       }
/*     */     }
/*     */     catch (SQLException sqle)
/*     */     {
/* 107 */       throw JDBCExceptionHelper.convert(session.getFactory().getSQLExceptionConverter(), sqle, "could not fetch initial value for increment generator", this.sql);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\id\IncrementGenerator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */