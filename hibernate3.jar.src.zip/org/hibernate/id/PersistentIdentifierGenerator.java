/*    */ package org.hibernate.id;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.dialect.Dialect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface PersistentIdentifierGenerator
/*    */   extends IdentifierGenerator
/*    */ {
/*    */   public static final String SCHEMA = "schema";
/*    */   public static final String TABLE = "target_table";
/*    */   public static final String TABLES = "identity_tables";
/*    */   public static final String PK = "target_column";
/*    */   public static final String CATALOG = "catalog";
/* 72 */   public static final Log SQL = LogFactory.getLog("org.hibernate.SQL");
/*    */   
/*    */   public abstract String[] sqlCreateStrings(Dialect paramDialect)
/*    */     throws HibernateException;
/*    */   
/*    */   public abstract String[] sqlDropStrings(Dialect paramDialect)
/*    */     throws HibernateException;
/*    */   
/*    */   public abstract Object generatorKey();
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\id\PersistentIdentifierGenerator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */