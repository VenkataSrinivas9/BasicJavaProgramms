/*    */ package org.hibernate.id;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.util.Properties;
/*    */ import org.hibernate.MappingException;
/*    */ import org.hibernate.dialect.Dialect;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.metadata.ClassMetadata;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SelectGenerator
/*    */   extends AbstractPostInsertGenerator
/*    */   implements Configurable
/*    */ {
/*    */   private String uniqueKeyPropertyName;
/*    */   private Type idType;
/*    */   private String entityName;
/*    */   
/*    */   public void configure(Type type, Properties params, Dialect d)
/*    */     throws MappingException
/*    */   {
/* 31 */     this.uniqueKeyPropertyName = params.getProperty("key");
/* 32 */     this.entityName = params.getProperty("entity_name");
/* 33 */     this.idType = type;
/*    */   }
/*    */   
/*    */   protected String getSQL(PostInsertIdentityPersister persister) {
/* 37 */     return persister.getSelectByUniqueKeyString(this.uniqueKeyPropertyName);
/*    */   }
/*    */   
/*    */   protected void bindParameters(SessionImplementor session, PreparedStatement ps, Object object, PostInsertIdentityPersister persister) throws SQLException
/*    */   {
/* 42 */     Type uniqueKeyPropertyType = session.getFactory().getClassMetadata(this.entityName).getPropertyType(this.uniqueKeyPropertyName);
/*    */     
/*    */ 
/* 45 */     Object uniqueKeyValue = persister.getPropertyValue(object, this.uniqueKeyPropertyName, session.getEntityMode());
/* 46 */     uniqueKeyPropertyType.nullSafeSet(ps, uniqueKeyValue, 1, session);
/*    */   }
/*    */   
/*    */   protected Serializable getResult(SessionImplementor session, ResultSet rs, Object object, PostInsertIdentityPersister persister) throws SQLException
/*    */   {
/* 51 */     if (!rs.next()) {
/* 52 */       throw new IdentifierGenerationException("the inserted row could not be located by the unique key: " + this.uniqueKeyPropertyName);
/*    */     }
/* 54 */     return (Serializable)this.idType.nullSafeGet(rs, persister.getRootTableKeyColumnNames(), session, object);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\id\SelectGenerator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */