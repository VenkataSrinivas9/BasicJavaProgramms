/*    */ package org.hibernate.id;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractPostInsertGenerator
/*    */   implements PostInsertIdentifierGenerator
/*    */ {
/*    */   public Serializable generate(SessionImplementor s, Object obj)
/*    */   {
/* 20 */     return IdentifierGeneratorFactory.POST_INSERT_INDICATOR;
/*    */   }
/*    */   
/*    */   protected abstract String getSQL(PostInsertIdentityPersister paramPostInsertIdentityPersister);
/*    */   
/*    */   protected void bindParameters(SessionImplementor session, PreparedStatement ps, Object object, PostInsertIdentityPersister persister)
/*    */     throws SQLException
/*    */   {}
/*    */   
/*    */   protected abstract Serializable getResult(SessionImplementor paramSessionImplementor, ResultSet paramResultSet, Object paramObject, PostInsertIdentityPersister paramPostInsertIdentityPersister)
/*    */     throws SQLException;
/*    */   
/*    */   /* Error */
/*    */   public Serializable getGenerated(SessionImplementor session, Object object, PostInsertIdentityPersister persister)
/*    */     throws org.hibernate.HibernateException
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_3
/*    */     //   2: invokevirtual 3	org/hibernate/id/AbstractPostInsertGenerator:getSQL	(Lorg/hibernate/id/PostInsertIdentityPersister;)Ljava/lang/String;
/*    */     //   5: astore 4
/*    */     //   7: aload_1
/*    */     //   8: invokeinterface 4 1 0
/*    */     //   13: aload 4
/*    */     //   15: invokeinterface 5 2 0
/*    */     //   20: astore 5
/*    */     //   22: aload_0
/*    */     //   23: aload_1
/*    */     //   24: aload 5
/*    */     //   26: aload_2
/*    */     //   27: aload_3
/*    */     //   28: invokevirtual 6	org/hibernate/id/AbstractPostInsertGenerator:bindParameters	(Lorg/hibernate/engine/SessionImplementor;Ljava/sql/PreparedStatement;Ljava/lang/Object;Lorg/hibernate/id/PostInsertIdentityPersister;)V
/*    */     //   31: aload 5
/*    */     //   33: invokeinterface 7 1 0
/*    */     //   38: astore 6
/*    */     //   40: aload_0
/*    */     //   41: aload_1
/*    */     //   42: aload 6
/*    */     //   44: aload_2
/*    */     //   45: aload_3
/*    */     //   46: invokevirtual 8	org/hibernate/id/AbstractPostInsertGenerator:getResult	(Lorg/hibernate/engine/SessionImplementor;Ljava/sql/ResultSet;Ljava/lang/Object;Lorg/hibernate/id/PostInsertIdentityPersister;)Ljava/io/Serializable;
/*    */     //   49: astore 7
/*    */     //   51: aload 6
/*    */     //   53: invokeinterface 9 1 0
/*    */     //   58: aload_1
/*    */     //   59: invokeinterface 4 1 0
/*    */     //   64: aload 5
/*    */     //   66: invokeinterface 10 2 0
/*    */     //   71: aload 7
/*    */     //   73: areturn
/*    */     //   74: astore 8
/*    */     //   76: aload 6
/*    */     //   78: invokeinterface 9 1 0
/*    */     //   83: aload 8
/*    */     //   85: athrow
/*    */     //   86: astore 9
/*    */     //   88: aload_1
/*    */     //   89: invokeinterface 4 1 0
/*    */     //   94: aload 5
/*    */     //   96: invokeinterface 10 2 0
/*    */     //   101: aload 9
/*    */     //   103: athrow
/*    */     //   104: astore 5
/*    */     //   106: aload_1
/*    */     //   107: invokeinterface 12 1 0
/*    */     //   112: invokeinterface 13 1 0
/*    */     //   117: aload 5
/*    */     //   119: new 14	java/lang/StringBuffer
/*    */     //   122: dup
/*    */     //   123: invokespecial 15	java/lang/StringBuffer:<init>	()V
/*    */     //   126: ldc 16
/*    */     //   128: invokevirtual 17	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   131: aload_3
/*    */     //   132: invokestatic 18	org/hibernate/pretty/MessageHelper:infoString	(Lorg/hibernate/persister/entity/EntityPersister;)Ljava/lang/String;
/*    */     //   135: invokevirtual 17	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   138: invokevirtual 19	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*    */     //   141: aload 4
/*    */     //   143: invokestatic 20	org/hibernate/exception/JDBCExceptionHelper:convert	(Lorg/hibernate/exception/SQLExceptionConverter;Ljava/sql/SQLException;Ljava/lang/String;Ljava/lang/String;)Lorg/hibernate/JDBCException;
/*    */     //   146: athrow
/*    */     // Line number table:
/*    */     //   Java source line #34	-> byte code offset #0
/*    */     //   Java source line #39	-> byte code offset #7
/*    */     //   Java source line #41	-> byte code offset #22
/*    */     //   Java source line #42	-> byte code offset #31
/*    */     //   Java source line #44	-> byte code offset #40
/*    */     //   Java source line #47	-> byte code offset #51
/*    */     //   Java source line #51	-> byte code offset #58
/*    */     //   Java source line #47	-> byte code offset #74
/*    */     //   Java source line #51	-> byte code offset #86
/*    */     //   Java source line #55	-> byte code offset #104
/*    */     //   Java source line #56	-> byte code offset #106
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	147	0	this	AbstractPostInsertGenerator
/*    */     //   0	147	1	session	SessionImplementor
/*    */     //   0	147	2	object	Object
/*    */     //   0	147	3	persister	PostInsertIdentityPersister
/*    */     //   5	137	4	sql	String
/*    */     //   20	75	5	idSelect	PreparedStatement
/*    */     //   104	14	5	sqle	SQLException
/*    */     //   38	39	6	rs	ResultSet
/*    */     //   49	23	7	localSerializable	Serializable
/*    */     //   74	10	8	localObject1	Object
/*    */     //   86	16	9	localObject2	Object
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   40	51	74	finally
/*    */     //   74	76	74	finally
/*    */     //   22	58	86	finally
/*    */     //   74	88	86	finally
/*    */     //   7	71	104	java/sql/SQLException
/*    */     //   74	104	104	java/sql/SQLException
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\id\AbstractPostInsertGenerator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */