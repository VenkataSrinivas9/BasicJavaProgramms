/*     */ package org.hibernate.id;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.LockMode;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.engine.TransactionHelper;
/*     */ import org.hibernate.mapping.Table;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.PropertiesHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableGenerator
/*     */   extends TransactionHelper
/*     */   implements PersistentIdentifierGenerator, Configurable
/*     */ {
/*     */   public static final String COLUMN = "column";
/*     */   public static final String DEFAULT_COLUMN_NAME = "next_hi";
/*     */   public static final String TABLE = "table";
/*     */   public static final String DEFAULT_TABLE_NAME = "hibernate_unique_key";
/*  59 */   private static final Log log = LogFactory.getLog(TableGenerator.class);
/*     */   
/*     */   private String tableName;
/*     */   private String columnName;
/*     */   private String query;
/*     */   private String update;
/*     */   
/*     */   public void configure(Type type, Properties params, Dialect dialect)
/*     */   {
/*  68 */     this.tableName = PropertiesHelper.getString("table", params, "hibernate_unique_key");
/*  69 */     this.columnName = PropertiesHelper.getString("column", params, "next_hi");
/*  70 */     String schemaName = params.getProperty("schema");
/*  71 */     String catalogName = params.getProperty("catalog");
/*     */     
/*  73 */     if (this.tableName.indexOf('.') < 0) {
/*  74 */       this.tableName = Table.qualify(catalogName, schemaName, this.tableName);
/*     */     }
/*     */     
/*  77 */     this.query = ("select " + this.columnName + " from " + dialect.appendLockHint(LockMode.UPGRADE, this.tableName) + dialect.getForUpdateString());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */     this.update = ("update " + this.tableName + " set " + this.columnName + " = ? where " + this.columnName + " = ?");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Serializable generate(SessionImplementor session, Object object)
/*     */     throws HibernateException
/*     */   {
/*  94 */     int result = ((Integer)doWorkInNewTransaction(session)).intValue();
/*  95 */     return new Integer(result);
/*     */   }
/*     */   
/*     */   public String[] sqlCreateStrings(Dialect dialect) throws HibernateException
/*     */   {
/* 100 */     return new String[] { "create table " + this.tableName + " ( " + this.columnName + " " + dialect.getTypeName(4) + " )", "insert into " + this.tableName + " values ( 0 )" };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] sqlDropStrings(Dialect dialect)
/*     */   {
/* 108 */     StringBuffer sqlDropString = new StringBuffer().append("drop table ");
/*     */     
/* 110 */     if (dialect.supportsIfExistsBeforeTableName()) sqlDropString.append("if exists ");
/* 111 */     sqlDropString.append(this.tableName).append(dialect.getCascadeConstraintsString());
/*     */     
/* 113 */     if (dialect.supportsIfExistsAfterTableName()) sqlDropString.append(" if exists");
/* 114 */     return new String[] { sqlDropString.toString() };
/*     */   }
/*     */   
/*     */   public Object generatorKey() {
/* 118 */     return this.tableName;
/*     */   }
/*     */   
/*     */ 
/*     */   public Serializable doWorkInCurrentTransaction(Connection conn, String sql)
/*     */     throws SQLException
/*     */   {
/*     */     int result;
/*     */     int rows;
/*     */     do
/*     */     {
/* 129 */       sql = this.query;
/* 130 */       SQL.debug(this.query);
/* 131 */       PreparedStatement qps = conn.prepareStatement(this.query);
/*     */       try {
/* 133 */         ResultSet rs = qps.executeQuery();
/* 134 */         if (!rs.next()) {
/* 135 */           String err = "could not read a hi value - you need to populate the table: " + this.tableName;
/* 136 */           log.error(err);
/* 137 */           throw new IdentifierGenerationException(err);
/*     */         }
/* 139 */         int result = rs.getInt(1);
/* 140 */         rs.close();
/*     */       }
/*     */       catch (SQLException sqle) {
/* 143 */         log.error("could not read a hi value", sqle);
/* 144 */         throw sqle;
/*     */       }
/*     */       finally {
/* 147 */         qps.close();
/*     */       }
/*     */       
/* 150 */       sql = this.update;
/* 151 */       SQL.debug(this.update);
/* 152 */       PreparedStatement ups = conn.prepareStatement(this.update);
/*     */       try {
/* 154 */         ups.setInt(1, result + 1);
/* 155 */         ups.setInt(2, result);
/* 156 */         rows = ups.executeUpdate();
/*     */       } catch (SQLException sqle) {
/*     */         int rows;
/* 159 */         log.error("could not update hi value in: " + this.tableName, sqle);
/* 160 */         throw sqle;
/*     */       }
/*     */       finally {
/* 163 */         ups.close();
/*     */       }
/*     */       
/* 166 */     } while (rows == 0);
/* 167 */     return new Integer(result);
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\id\TableGenerator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */