/*     */ package org.hibernate.id;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.mapping.Table;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.PropertiesHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SequenceGenerator
/*     */   implements PersistentIdentifierGenerator, Configurable
/*     */ {
/*     */   public static final String SEQUENCE = "sequence";
/*     */   public static final String PARAMETERS = "parameters";
/*     */   private String sequenceName;
/*     */   private String parameters;
/*     */   private Type identifierType;
/*     */   private String sql;
/*  52 */   private static final Log log = LogFactory.getLog(SequenceGenerator.class);
/*     */   
/*     */   public void configure(Type type, Properties params, Dialect dialect) throws MappingException {
/*  55 */     this.sequenceName = PropertiesHelper.getString("sequence", params, "hibernate_sequence");
/*  56 */     this.parameters = params.getProperty("parameters");
/*  57 */     String schemaName = params.getProperty("schema");
/*  58 */     String catalogName = params.getProperty("catalog");
/*     */     
/*  60 */     if (this.sequenceName.indexOf('.') < 0) {
/*  61 */       this.sequenceName = Table.qualify(catalogName, schemaName, this.sequenceName);
/*     */     }
/*     */     
/*  64 */     this.identifierType = type;
/*  65 */     this.sql = dialect.getSequenceNextValString(this.sequenceName);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public java.io.Serializable generate(org.hibernate.engine.SessionImplementor session, Object obj)
/*     */     throws HibernateException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: invokeinterface 21 1 0
/*     */     //   6: aload_0
/*     */     //   7: getfield 20	org/hibernate/id/SequenceGenerator:sql	Ljava/lang/String;
/*     */     //   10: invokeinterface 22 2 0
/*     */     //   15: astore_3
/*     */     //   16: aload_3
/*     */     //   17: invokeinterface 23 1 0
/*     */     //   22: astore 4
/*     */     //   24: aload 4
/*     */     //   26: invokeinterface 24 1 0
/*     */     //   31: pop
/*     */     //   32: aload 4
/*     */     //   34: aload_0
/*     */     //   35: getfield 18	org/hibernate/id/SequenceGenerator:identifierType	Lorg/hibernate/type/Type;
/*     */     //   38: invokestatic 25	org/hibernate/id/IdentifierGeneratorFactory:get	(Ljava/sql/ResultSet;Lorg/hibernate/type/Type;)Ljava/io/Serializable;
/*     */     //   41: astore 5
/*     */     //   43: getstatic 26	org/hibernate/id/SequenceGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   46: invokeinterface 27 1 0
/*     */     //   51: ifeq +31 -> 82
/*     */     //   54: getstatic 26	org/hibernate/id/SequenceGenerator:log	Lorg/apache/commons/logging/Log;
/*     */     //   57: new 28	java/lang/StringBuffer
/*     */     //   60: dup
/*     */     //   61: invokespecial 29	java/lang/StringBuffer:<init>	()V
/*     */     //   64: ldc 30
/*     */     //   66: invokevirtual 31	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   69: aload 5
/*     */     //   71: invokevirtual 32	java/lang/StringBuffer:append	(Ljava/lang/Object;)Ljava/lang/StringBuffer;
/*     */     //   74: invokevirtual 33	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*     */     //   77: invokeinterface 34 2 0
/*     */     //   82: aload 5
/*     */     //   84: astore 6
/*     */     //   86: aload 4
/*     */     //   88: invokeinterface 35 1 0
/*     */     //   93: aload_1
/*     */     //   94: invokeinterface 21 1 0
/*     */     //   99: aload_3
/*     */     //   100: invokeinterface 36 2 0
/*     */     //   105: aload 6
/*     */     //   107: areturn
/*     */     //   108: astore 7
/*     */     //   110: aload 4
/*     */     //   112: invokeinterface 35 1 0
/*     */     //   117: aload 7
/*     */     //   119: athrow
/*     */     //   120: astore 8
/*     */     //   122: aload_1
/*     */     //   123: invokeinterface 21 1 0
/*     */     //   128: aload_3
/*     */     //   129: invokeinterface 36 2 0
/*     */     //   134: aload 8
/*     */     //   136: athrow
/*     */     //   137: astore_3
/*     */     //   138: aload_1
/*     */     //   139: invokeinterface 38 1 0
/*     */     //   144: invokeinterface 39 1 0
/*     */     //   149: aload_3
/*     */     //   150: ldc 40
/*     */     //   152: aload_0
/*     */     //   153: getfield 20	org/hibernate/id/SequenceGenerator:sql	Ljava/lang/String;
/*     */     //   156: invokestatic 41	org/hibernate/exception/JDBCExceptionHelper:convert	(Lorg/hibernate/exception/SQLExceptionConverter;Ljava/sql/SQLException;Ljava/lang/String;Ljava/lang/String;)Lorg/hibernate/JDBCException;
/*     */     //   159: athrow
/*     */     // Line number table:
/*     */     //   Java source line #73	-> byte code offset #0
/*     */     //   Java source line #75	-> byte code offset #16
/*     */     //   Java source line #77	-> byte code offset #24
/*     */     //   Java source line #78	-> byte code offset #32
/*     */     //   Java source line #81	-> byte code offset #43
/*     */     //   Java source line #82	-> byte code offset #54
/*     */     //   Java source line #84	-> byte code offset #82
/*     */     //   Java source line #87	-> byte code offset #86
/*     */     //   Java source line #91	-> byte code offset #93
/*     */     //   Java source line #87	-> byte code offset #108
/*     */     //   Java source line #91	-> byte code offset #120
/*     */     //   Java source line #95	-> byte code offset #137
/*     */     //   Java source line #96	-> byte code offset #138
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	160	0	this	SequenceGenerator
/*     */     //   0	160	1	session	org.hibernate.engine.SessionImplementor
/*     */     //   0	160	2	obj	Object
/*     */     //   15	114	3	st	java.sql.PreparedStatement
/*     */     //   137	13	3	sqle	java.sql.SQLException
/*     */     //   22	89	4	rs	java.sql.ResultSet
/*     */     //   41	42	5	result	java.io.Serializable
/*     */     //   84	22	6	localSerializable1	java.io.Serializable
/*     */     //   108	10	7	localObject1	Object
/*     */     //   120	15	8	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   24	86	108	finally
/*     */     //   108	110	108	finally
/*     */     //   16	93	120	finally
/*     */     //   108	122	120	finally
/*     */     //   0	105	137	java/sql/SQLException
/*     */     //   108	137	137	java/sql/SQLException
/*     */   }
/*     */   
/*     */   public String[] sqlCreateStrings(Dialect dialect)
/*     */     throws HibernateException
/*     */   {
/* 107 */     String[] ddl = dialect.getCreateSequenceStrings(this.sequenceName);
/* 108 */     if (this.parameters != null) { int tmp28_27 = (ddl.length - 1); String[] tmp28_23 = ddl;tmp28_23[tmp28_27] = (tmp28_23[tmp28_27] + ' ' + this.parameters); }
/* 109 */     return ddl;
/*     */   }
/*     */   
/*     */   public String[] sqlDropStrings(Dialect dialect) throws HibernateException {
/* 113 */     return dialect.getDropSequenceStrings(this.sequenceName);
/*     */   }
/*     */   
/*     */   public Object generatorKey() {
/* 117 */     return this.sequenceName;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\id\SequenceGenerator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */