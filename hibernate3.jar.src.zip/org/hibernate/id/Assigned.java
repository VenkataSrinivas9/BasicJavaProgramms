/*    */ package org.hibernate.id;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Properties;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.MappingException;
/*    */ import org.hibernate.dialect.Dialect;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Assigned
/*    */   implements IdentifierGenerator, Configurable
/*    */ {
/*    */   private String entityName;
/*    */   
/*    */   public Serializable generate(SessionImplementor session, Object obj)
/*    */     throws HibernateException
/*    */   {
/* 28 */     Serializable id = session.getEntityPersister(this.entityName, obj).getIdentifier(obj, session.getEntityMode());
/*    */     
/*    */ 
/*    */ 
/* 32 */     if (id == null) {
/* 33 */       throw new IdentifierGenerationException("ids for this class must be manually assigned before calling save(): " + this.entityName);
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 39 */     return id;
/*    */   }
/*    */   
/*    */   public void configure(Type type, Properties params, Dialect d) throws MappingException
/*    */   {
/* 44 */     this.entityName = params.getProperty("entity_name");
/* 45 */     if (this.entityName == null) {
/* 46 */       throw new MappingException("no entity name");
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\id\Assigned.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */