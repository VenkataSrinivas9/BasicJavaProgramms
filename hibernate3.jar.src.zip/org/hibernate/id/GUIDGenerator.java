/*    */ package org.hibernate.id;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GUIDGenerator
/*    */   implements IdentifierGenerator
/*    */ {
/* 22 */   private static final Log log = LogFactory.getLog(GUIDGenerator.class);
/*    */   
/*    */   /* Error */
/*    */   public java.io.Serializable generate(org.hibernate.engine.SessionImplementor session, Object obj)
/*    */     throws org.hibernate.HibernateException
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_1
/*    */     //   1: invokeinterface 7 1 0
/*    */     //   6: invokeinterface 8 1 0
/*    */     //   11: invokevirtual 9	org/hibernate/dialect/Dialect:getSelectGUIDString	()Ljava/lang/String;
/*    */     //   14: astore_3
/*    */     //   15: aload_1
/*    */     //   16: invokeinterface 10 1 0
/*    */     //   21: aload_3
/*    */     //   22: invokeinterface 11 2 0
/*    */     //   27: astore 4
/*    */     //   29: aload 4
/*    */     //   31: invokeinterface 12 1 0
/*    */     //   36: astore 5
/*    */     //   38: aload 5
/*    */     //   40: invokeinterface 13 1 0
/*    */     //   45: pop
/*    */     //   46: aload 5
/*    */     //   48: iconst_1
/*    */     //   49: invokeinterface 14 2 0
/*    */     //   54: astore 6
/*    */     //   56: aload 5
/*    */     //   58: invokeinterface 15 1 0
/*    */     //   63: goto +15 -> 78
/*    */     //   66: astore 7
/*    */     //   68: aload 5
/*    */     //   70: invokeinterface 15 1 0
/*    */     //   75: aload 7
/*    */     //   77: athrow
/*    */     //   78: getstatic 16	org/hibernate/id/GUIDGenerator:log	Lorg/apache/commons/logging/Log;
/*    */     //   81: new 17	java/lang/StringBuffer
/*    */     //   84: dup
/*    */     //   85: invokespecial 18	java/lang/StringBuffer:<init>	()V
/*    */     //   88: ldc 19
/*    */     //   90: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   93: aload 6
/*    */     //   95: invokevirtual 20	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   98: invokevirtual 21	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*    */     //   101: invokeinterface 22 2 0
/*    */     //   106: aload 6
/*    */     //   108: astore 7
/*    */     //   110: aload_1
/*    */     //   111: invokeinterface 10 1 0
/*    */     //   116: aload 4
/*    */     //   118: invokeinterface 23 2 0
/*    */     //   123: aload 7
/*    */     //   125: areturn
/*    */     //   126: astore 8
/*    */     //   128: aload_1
/*    */     //   129: invokeinterface 10 1 0
/*    */     //   134: aload 4
/*    */     //   136: invokeinterface 23 2 0
/*    */     //   141: aload 8
/*    */     //   143: athrow
/*    */     //   144: astore 4
/*    */     //   146: aload_1
/*    */     //   147: invokeinterface 7 1 0
/*    */     //   152: invokeinterface 25 1 0
/*    */     //   157: aload 4
/*    */     //   159: ldc 26
/*    */     //   161: aload_3
/*    */     //   162: invokestatic 27	org/hibernate/exception/JDBCExceptionHelper:convert	(Lorg/hibernate/exception/SQLExceptionConverter;Ljava/sql/SQLException;Ljava/lang/String;Ljava/lang/String;)Lorg/hibernate/JDBCException;
/*    */     //   165: athrow
/*    */     // Line number table:
/*    */     //   Java source line #27	-> byte code offset #0
/*    */     //   Java source line #29	-> byte code offset #15
/*    */     //   Java source line #31	-> byte code offset #29
/*    */     //   Java source line #34	-> byte code offset #38
/*    */     //   Java source line #35	-> byte code offset #46
/*    */     //   Java source line #38	-> byte code offset #56
/*    */     //   Java source line #39	-> byte code offset #63
/*    */     //   Java source line #38	-> byte code offset #66
/*    */     //   Java source line #40	-> byte code offset #78
/*    */     //   Java source line #41	-> byte code offset #106
/*    */     //   Java source line #44	-> byte code offset #110
/*    */     //   Java source line #47	-> byte code offset #144
/*    */     //   Java source line #48	-> byte code offset #146
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	166	0	this	GUIDGenerator
/*    */     //   0	166	1	session	org.hibernate.engine.SessionImplementor
/*    */     //   0	166	2	obj	Object
/*    */     //   14	148	3	sql	String
/*    */     //   27	108	4	st	java.sql.PreparedStatement
/*    */     //   144	14	4	sqle	java.sql.SQLException
/*    */     //   36	33	5	rs	java.sql.ResultSet
/*    */     //   54	3	6	result	String
/*    */     //   78	29	6	result	String
/*    */     //   66	10	7	localObject1	Object
/*    */     //   126	16	8	localObject2	Object
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   38	56	66	finally
/*    */     //   66	68	66	finally
/*    */     //   29	110	126	finally
/*    */     //   126	128	126	finally
/*    */     //   15	123	144	java/sql/SQLException
/*    */     //   126	144	144	java/sql/SQLException
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\id\GUIDGenerator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */