/*     */ package org.hibernate.id;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.LockMode;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.engine.TransactionHelper;
/*     */ import org.hibernate.mapping.Table;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.PropertiesHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultipleHiLoPerTableGenerator
/*     */   extends TransactionHelper
/*     */   implements PersistentIdentifierGenerator, Configurable
/*     */ {
/*  59 */   private static final Log log = LogFactory.getLog(MultipleHiLoPerTableGenerator.class);
/*     */   
/*     */   public static final String ID_TABLE = "table";
/*     */   
/*     */   public static final String PK_COLUMN_NAME = "primary_key_column";
/*     */   
/*     */   public static final String PK_VALUE_NAME = "primary_key_value";
/*     */   
/*     */   public static final String VALUE_COLUMN_NAME = "value_column";
/*     */   
/*     */   public static final String PK_LENGTH_NAME = "primary_key_length";
/*     */   private static final int DEFAULT_PK_LENGTH = 255;
/*     */   public static final String DEFAULT_TABLE = "hibernate_sequences";
/*     */   private static final String DEFAULT_PK_COLUMN = "sequence_name";
/*     */   private static final String DEFAULT_VALUE_COLUMN = "sequence_next_hi_value";
/*     */   private String tableName;
/*     */   private String pkColumnName;
/*     */   private String valueColumnName;
/*     */   private String query;
/*     */   private String insert;
/*     */   private String update;
/*     */   public static final String MAX_LO = "max_lo";
/*     */   private long hi;
/*     */   private int lo;
/*     */   private int maxLo;
/*     */   private Class returnClass;
/*     */   private int keySize;
/*     */   
/*     */   public String[] sqlCreateStrings(Dialect dialect)
/*     */     throws HibernateException
/*     */   {
/*  90 */     return new String[] { "create table " + this.tableName + " ( " + this.pkColumnName + " " + dialect.getTypeName(12, this.keySize, 0, 0) + ",  " + this.valueColumnName + " " + dialect.getTypeName(4) + " ) " };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] sqlDropStrings(Dialect dialect)
/*     */     throws HibernateException
/*     */   {
/* 108 */     StringBuffer sqlDropString = new StringBuffer().append("drop table ");
/*     */     
/* 110 */     if (dialect.supportsIfExistsBeforeTableName()) sqlDropString.append("if exists ");
/* 111 */     sqlDropString.append(this.tableName).append(dialect.getCascadeConstraintsString());
/*     */     
/* 113 */     if (dialect.supportsIfExistsAfterTableName()) sqlDropString.append(" if exists");
/* 114 */     return new String[] { sqlDropString.toString() };
/*     */   }
/*     */   
/*     */   public Object generatorKey() {
/* 118 */     return this.tableName;
/*     */   }
/*     */   
/*     */ 
/*     */   public Serializable doWorkInCurrentTransaction(Connection conn, String sql)
/*     */     throws SQLException
/*     */   {
/*     */     int result;
/*     */     
/*     */     int rows;
/*     */     do
/*     */     {
/* 130 */       SQL.debug(this.query);
/* 131 */       PreparedStatement qps = conn.prepareStatement(this.query);
/* 132 */       PreparedStatement ips = null;
/*     */       try
/*     */       {
/* 135 */         ResultSet rs = qps.executeQuery();
/* 136 */         boolean isInitialized = rs.next();
/* 137 */         int result; if (!isInitialized) {
/* 138 */           int result = 0;
/* 139 */           ips = conn.prepareStatement(this.insert);
/*     */           
/* 141 */           ips.setInt(1, result);
/* 142 */           ips.execute();
/*     */         }
/*     */         else {
/* 145 */           result = rs.getInt(1);
/*     */         }
/* 147 */         rs.close();
/*     */       }
/*     */       catch (SQLException sqle) {
/* 150 */         log.error("could not read or init a hi value", sqle);
/* 151 */         throw sqle;
/*     */       }
/*     */       finally {
/* 154 */         if (ips != null) {
/* 155 */           ips.close();
/*     */         }
/* 157 */         qps.close();
/*     */       }
/*     */       
/*     */ 
/* 161 */       PreparedStatement ups = conn.prepareStatement(this.update);
/*     */       try {
/* 163 */         ups.setInt(1, result + 1);
/* 164 */         ups.setInt(2, result);
/*     */         
/* 166 */         rows = ups.executeUpdate();
/*     */       } catch (SQLException sqle) {
/*     */         int rows;
/* 169 */         log.error("could not update hi value in: " + this.tableName, sqle);
/* 170 */         throw sqle;
/*     */       }
/*     */       finally {
/* 173 */         ups.close();
/*     */       }
/*     */       
/* 176 */     } while (rows == 0);
/* 177 */     return new Integer(result);
/*     */   }
/*     */   
/*     */   public synchronized Serializable generate(SessionImplementor session, Object obj) throws HibernateException
/*     */   {
/* 182 */     if (this.lo > this.maxLo) {
/* 183 */       int hival = ((Integer)doWorkInNewTransaction(session)).intValue();
/* 184 */       this.lo = (hival == 0 ? 1 : 0);
/* 185 */       this.hi = (hival * (this.maxLo + 1));
/* 186 */       log.debug("new hi value: " + hival);
/*     */     }
/*     */     
/* 189 */     return IdentifierGeneratorFactory.createNumber(this.hi + this.lo++, this.returnClass);
/*     */   }
/*     */   
/*     */   public void configure(Type type, Properties params, Dialect dialect) throws MappingException {
/* 193 */     this.tableName = PropertiesHelper.getString("table", params, "hibernate_sequences");
/* 194 */     this.pkColumnName = PropertiesHelper.getString("primary_key_column", params, "sequence_name");
/* 195 */     this.valueColumnName = PropertiesHelper.getString("value_column", params, "sequence_next_hi_value");
/* 196 */     String schemaName = params.getProperty("schema");
/* 197 */     String catalogName = params.getProperty("catalog");
/* 198 */     this.keySize = PropertiesHelper.getInt("primary_key_length", params, 255);
/* 199 */     String keyValue = PropertiesHelper.getString("primary_key_value", params, params.getProperty("target_table"));
/*     */     
/* 201 */     if (this.tableName.indexOf('.') < 0) {
/* 202 */       this.tableName = Table.qualify(catalogName, schemaName, this.tableName);
/*     */     }
/*     */     
/* 205 */     this.query = ("select " + this.valueColumnName + " from " + dialect.appendLockHint(LockMode.UPGRADE, this.tableName) + " where " + this.pkColumnName + " = '" + keyValue + "'" + dialect.getForUpdateString());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 212 */     this.update = ("update " + this.tableName + " set " + this.valueColumnName + " = ? where " + this.valueColumnName + " = ? and " + this.pkColumnName + " = '" + keyValue + "'");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 224 */     this.insert = ("insert into " + this.tableName + "(" + this.pkColumnName + ", " + this.valueColumnName + ") " + "values('" + keyValue + "', ?)");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 230 */     this.maxLo = PropertiesHelper.getInt("max_lo", params, 32767);
/* 231 */     this.lo = (this.maxLo + 1);
/* 232 */     this.returnClass = type.getReturnedClass();
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\id\MultipleHiLoPerTableGenerator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */