/*    */ package org.hibernate.id;
/*    */ 
/*    */ import java.net.InetAddress;
/*    */ import org.hibernate.util.BytesHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractUUIDGenerator
/*    */   implements IdentifierGenerator
/*    */ {
/*    */   private static final int IP;
/*    */   
/*    */   static
/*    */   {
/*    */     int ipadd;
/*    */     try
/*    */     {
/* 22 */       ipadd = BytesHelper.toInt(InetAddress.getLocalHost().getAddress());
/*    */     } catch (Exception e) {
/*    */       int ipadd;
/* 25 */       ipadd = 0;
/*    */     }
/* 27 */     IP = ipadd; }
/*    */   
/* 29 */   private static short counter = 0;
/* 30 */   private static final int JVM = (int)(System.currentTimeMillis() >>> 8);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected int getJVM()
/*    */   {
/* 40 */     return JVM;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected short getCount()
/*    */   {
/* 48 */     synchronized (AbstractUUIDGenerator.class) {
/* 49 */       if (counter < 0) counter = 0;
/* 50 */       return counter++;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected int getIP()
/*    */   {
/* 58 */     return IP;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected short getHiTime()
/*    */   {
/* 65 */     return (short)(int)(System.currentTimeMillis() >>> 32);
/*    */   }
/*    */   
/* 68 */   protected int getLoTime() { return (int)System.currentTimeMillis(); }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\id\AbstractUUIDGenerator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */