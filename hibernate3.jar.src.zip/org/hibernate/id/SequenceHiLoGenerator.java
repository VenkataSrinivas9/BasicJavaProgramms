/*    */ package org.hibernate.id;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Properties;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.MappingException;
/*    */ import org.hibernate.dialect.Dialect;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.type.Type;
/*    */ import org.hibernate.util.PropertiesHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SequenceHiLoGenerator
/*    */   extends SequenceGenerator
/*    */ {
/*    */   public static final String MAX_LO = "max_lo";
/* 35 */   private static final Log log = LogFactory.getLog(SequenceHiLoGenerator.class);
/*    */   private int maxLo;
/*    */   private int lo;
/*    */   private long hi;
/*    */   private Class returnClass;
/*    */   
/*    */   public void configure(Type type, Properties params, Dialect d) throws MappingException
/*    */   {
/* 43 */     super.configure(type, params, d);
/* 44 */     this.maxLo = PropertiesHelper.getInt("max_lo", params, 9);
/* 45 */     this.lo = (this.maxLo + 1);
/* 46 */     this.returnClass = type.getReturnedClass();
/*    */   }
/*    */   
/*    */   public synchronized Serializable generate(SessionImplementor session, Object obj)
/*    */     throws HibernateException
/*    */   {
/* 52 */     if (this.lo > this.maxLo) {
/* 53 */       long hival = ((Number)super.generate(session, obj)).longValue();
/* 54 */       this.lo = (hival == 0L ? 1 : 0);
/* 55 */       this.hi = (hival * (this.maxLo + 1));
/* 56 */       if (log.isDebugEnabled()) {
/* 57 */         log.debug("new hi value: " + hival);
/*    */       }
/*    */     }
/* 60 */     return IdentifierGeneratorFactory.createNumber(this.hi + this.lo++, this.returnClass);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\id\SequenceHiLoGenerator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */