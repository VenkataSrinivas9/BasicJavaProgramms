package org.hibernate.id;

import org.hibernate.persister.entity.EntityPersister;

public abstract interface PostInsertIdentityPersister
  extends EntityPersister
{
  public abstract String getSelectByUniqueKeyString(String paramString);
  
  public abstract String getIdentitySelectString();
  
  public abstract String[] getRootTableKeyColumnNames();
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\id\PostInsertIdentityPersister.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */