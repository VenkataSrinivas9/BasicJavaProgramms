/*    */ package org.hibernate.id;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Properties;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.dialect.Dialect;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.type.Type;
/*    */ import org.hibernate.util.PropertiesHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TableHiLoGenerator
/*    */   extends TableGenerator
/*    */ {
/*    */   public static final String MAX_LO = "max_lo";
/*    */   private long hi;
/*    */   private int lo;
/*    */   private int maxLo;
/*    */   private Class returnClass;
/* 44 */   private static final Log log = LogFactory.getLog(TableHiLoGenerator.class);
/*    */   
/*    */   public void configure(Type type, Properties params, Dialect d) {
/* 47 */     super.configure(type, params, d);
/* 48 */     this.maxLo = PropertiesHelper.getInt("max_lo", params, 32767);
/* 49 */     this.lo = (this.maxLo + 1);
/* 50 */     this.returnClass = type.getReturnedClass();
/*    */   }
/*    */   
/*    */   public synchronized Serializable generate(SessionImplementor session, Object obj) throws HibernateException
/*    */   {
/* 55 */     if (this.maxLo < 2)
/*    */     {
/* 57 */       int val = ((Integer)super.generate(session, obj)).intValue();
/* 58 */       return IdentifierGeneratorFactory.createNumber(val, this.returnClass);
/*    */     }
/* 60 */     if (this.lo > this.maxLo) {
/* 61 */       int hival = ((Integer)super.generate(session, obj)).intValue();
/* 62 */       this.lo = (hival == 0 ? 1 : 0);
/* 63 */       this.hi = (hival * (this.maxLo + 1));
/* 64 */       log.debug("new hi value: " + hival);
/*    */     }
/*    */     
/* 67 */     return IdentifierGeneratorFactory.createNumber(this.hi + this.lo++, this.returnClass);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\id\TableHiLoGenerator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */