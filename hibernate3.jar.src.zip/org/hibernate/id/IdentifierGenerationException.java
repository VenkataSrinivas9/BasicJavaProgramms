/*    */ package org.hibernate.id;
/*    */ 
/*    */ import org.hibernate.HibernateException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IdentifierGenerationException
/*    */   extends HibernateException
/*    */ {
/*    */   public IdentifierGenerationException(String msg)
/*    */   {
/* 17 */     super(msg);
/*    */   }
/*    */   
/*    */   public IdentifierGenerationException(String msg, Throwable t) {
/* 21 */     super(msg, t);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\id\IdentifierGenerationException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */