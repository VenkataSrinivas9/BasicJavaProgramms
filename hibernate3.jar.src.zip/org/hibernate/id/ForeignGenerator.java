/*    */ package org.hibernate.id;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Properties;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.MappingException;
/*    */ import org.hibernate.Session;
/*    */ import org.hibernate.TransientObjectException;
/*    */ import org.hibernate.dialect.Dialect;
/*    */ import org.hibernate.engine.ForeignKeys;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.metadata.ClassMetadata;
/*    */ import org.hibernate.type.EntityType;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ForeignGenerator
/*    */   implements IdentifierGenerator, Configurable
/*    */ {
/*    */   private String propertyName;
/*    */   private String entityName;
/*    */   
/*    */   public Serializable generate(SessionImplementor sessionImplementor, Object object)
/*    */     throws HibernateException
/*    */   {
/* 37 */     Session session = (Session)sessionImplementor;
/*    */     
/* 39 */     Object associatedObject = sessionImplementor.getFactory().getClassMetadata(this.entityName).getPropertyValue(object, this.propertyName, session.getEntityMode());
/*    */     
/*    */ 
/*    */ 
/* 43 */     if (associatedObject == null) {
/* 44 */       throw new IdentifierGenerationException("attempted to assign id from null one-to-one property: " + this.propertyName);
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 50 */     EntityType type = (EntityType)sessionImplementor.getFactory().getClassMetadata(this.entityName).getPropertyType(this.propertyName);
/*    */     
/*    */     Serializable id;
/*    */     
/*    */     try
/*    */     {
/* 56 */       id = ForeignKeys.getEntityIdentifierIfNotUnsaved(type.getAssociatedEntityName(), associatedObject, sessionImplementor);
/*    */     }
/*    */     catch (TransientObjectException toe)
/*    */     {
/*    */       Serializable id;
/*    */       
/*    */ 
/* 63 */       id = session.save(type.getAssociatedEntityName(), associatedObject);
/*    */     }
/*    */     
/* 66 */     if (session.contains(object))
/*    */     {
/* 68 */       return IdentifierGeneratorFactory.SHORT_CIRCUIT_INDICATOR;
/*    */     }
/*    */     
/* 71 */     return id;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void configure(Type type, Properties params, Dialect d)
/*    */     throws MappingException
/*    */   {
/* 80 */     this.propertyName = params.getProperty("property");
/* 81 */     this.entityName = params.getProperty("entity_name");
/* 82 */     if (this.propertyName == null) throw new MappingException("param named \"property\" is required for foreign id generation strategy");
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\id\ForeignGenerator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */