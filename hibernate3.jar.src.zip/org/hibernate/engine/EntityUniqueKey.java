/*    */ package org.hibernate.engine;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.EntityMode;
/*    */ import org.hibernate.pretty.MessageHelper;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityUniqueKey
/*    */   implements Serializable
/*    */ {
/*    */   private final String uniqueKeyName;
/*    */   private final String entityName;
/*    */   private final Object key;
/*    */   private final Type keyType;
/*    */   private final EntityMode entityMode;
/*    */   private final int hashCode;
/*    */   
/*    */   public EntityUniqueKey(String entityName, String uniqueKeyName, Object semiResolvedKey, Type keyType, EntityMode entityMode, SessionFactoryImplementor factory)
/*    */   {
/* 38 */     this.uniqueKeyName = uniqueKeyName;
/* 39 */     this.entityName = entityName;
/* 40 */     this.key = semiResolvedKey;
/* 41 */     this.keyType = keyType.getSemiResolvedType(factory);
/* 42 */     this.entityMode = entityMode;
/* 43 */     this.hashCode = getHashCode(factory);
/*    */   }
/*    */   
/*    */   public String getEntityName() {
/* 47 */     return this.entityName;
/*    */   }
/*    */   
/*    */   public Object getKey() {
/* 51 */     return this.key;
/*    */   }
/*    */   
/*    */   public String getUniqueKeyName() {
/* 55 */     return this.uniqueKeyName;
/*    */   }
/*    */   
/*    */   public int getHashCode(SessionFactoryImplementor factory) {
/* 59 */     int result = 17;
/* 60 */     result = 37 * result + this.entityName.hashCode();
/* 61 */     result = 37 * result + this.uniqueKeyName.hashCode();
/* 62 */     result = 37 * result + this.keyType.getHashCode(this.key, this.entityMode, factory);
/* 63 */     return result;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 67 */     return this.hashCode;
/*    */   }
/*    */   
/*    */   public boolean equals(Object other) {
/* 71 */     EntityUniqueKey that = (EntityUniqueKey)other;
/* 72 */     return (that.entityName.equals(this.entityName)) && (that.uniqueKeyName.equals(this.uniqueKeyName)) && (this.keyType.isEqual(that.key, this.key, this.entityMode));
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 78 */     return "EntityUniqueKey" + MessageHelper.infoString(this.entityName, this.uniqueKeyName, this.key);
/*    */   }
/*    */   
/*    */ 
/*    */   private void writeObject(ObjectOutputStream oos)
/*    */     throws IOException
/*    */   {
/* 85 */     if ((this.key != null) && (!Serializable.class.isAssignableFrom(this.key.getClass()))) {
/* 86 */       throw new IllegalStateException("Cannot serialize an EntityUniqueKey which represents a non serializable property value [" + this.entityName + "." + this.uniqueKeyName + "]");
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 91 */     oos.defaultWriteObject();
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\EntityUniqueKey.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */