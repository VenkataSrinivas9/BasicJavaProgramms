/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ import org.hibernate.CacheMode;
/*     */ import org.hibernate.FlushMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamedQueryDefinition
/*     */   implements Serializable
/*     */ {
/*     */   private final String query;
/*     */   private final boolean cacheable;
/*     */   private final String cacheRegion;
/*     */   private final Integer timeout;
/*     */   private final Integer fetchSize;
/*     */   private final FlushMode flushMode;
/*     */   private final Map parameterTypes;
/*     */   private CacheMode cacheMode;
/*     */   private boolean readOnly;
/*     */   private String comment;
/*     */   
/*     */   public NamedQueryDefinition(String query, boolean cacheable, String cacheRegion, Integer timeout, Integer fetchSize, FlushMode flushMode, Map parameterTypes)
/*     */   {
/*  38 */     this(query, cacheable, cacheRegion, timeout, fetchSize, flushMode, null, false, null, parameterTypes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NamedQueryDefinition(String query, boolean cacheable, String cacheRegion, Integer timeout, Integer fetchSize, FlushMode flushMode, CacheMode cacheMode, boolean readOnly, String comment, Map parameterTypes)
/*     */   {
/*  64 */     this.query = query;
/*  65 */     this.cacheable = cacheable;
/*  66 */     this.cacheRegion = cacheRegion;
/*  67 */     this.timeout = timeout;
/*  68 */     this.fetchSize = fetchSize;
/*  69 */     this.flushMode = flushMode;
/*  70 */     this.parameterTypes = parameterTypes;
/*  71 */     this.cacheMode = cacheMode;
/*  72 */     this.readOnly = readOnly;
/*  73 */     this.comment = comment;
/*     */   }
/*     */   
/*     */   public String getQueryString() {
/*  77 */     return this.query;
/*     */   }
/*     */   
/*     */   public boolean isCacheable() {
/*  81 */     return this.cacheable;
/*     */   }
/*     */   
/*     */   public String getCacheRegion() {
/*  85 */     return this.cacheRegion;
/*     */   }
/*     */   
/*     */   public Integer getFetchSize() {
/*  89 */     return this.fetchSize;
/*     */   }
/*     */   
/*     */   public Integer getTimeout() {
/*  93 */     return this.timeout;
/*     */   }
/*     */   
/*     */   public FlushMode getFlushMode() {
/*  97 */     return this.flushMode;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 101 */     return getClass().getName() + '(' + this.query + ')';
/*     */   }
/*     */   
/*     */   public Map getParameterTypes() {
/* 105 */     return this.parameterTypes;
/*     */   }
/*     */   
/*     */   public String getQuery() {
/* 109 */     return this.query;
/*     */   }
/*     */   
/*     */   public CacheMode getCacheMode() {
/* 113 */     return this.cacheMode;
/*     */   }
/*     */   
/*     */   public boolean isReadOnly() {
/* 117 */     return this.readOnly;
/*     */   }
/*     */   
/*     */   public String getComment() {
/* 121 */     return this.comment;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\NamedQueryDefinition.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */