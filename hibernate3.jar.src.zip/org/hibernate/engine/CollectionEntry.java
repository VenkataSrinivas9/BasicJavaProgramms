/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.collection.PersistentCollection;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.pretty.MessageHelper;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CollectionEntry
/*     */   implements Serializable
/*     */ {
/*  24 */   private static final Log log = LogFactory.getLog(CollectionEntry.class);
/*     */   
/*     */ 
/*     */   private Serializable snapshot;
/*     */   
/*     */ 
/*     */   private String role;
/*     */   
/*     */ 
/*     */   private transient CollectionPersister loadedPersister;
/*     */   
/*     */ 
/*     */   private Serializable loadedKey;
/*     */   
/*     */ 
/*     */   private transient boolean reached;
/*     */   
/*     */ 
/*     */   private transient boolean processed;
/*     */   
/*     */ 
/*     */   private transient boolean doupdate;
/*     */   
/*     */ 
/*     */   private transient boolean doremove;
/*     */   
/*     */   private transient boolean dorecreate;
/*     */   
/*     */   private transient boolean ignore;
/*     */   
/*     */   private transient CollectionPersister currentPersister;
/*     */   
/*     */   private transient Serializable currentKey;
/*     */   
/*     */ 
/*     */   public CollectionEntry(CollectionPersister persister, PersistentCollection collection)
/*     */   {
/*  61 */     this.ignore = false;
/*     */     
/*  63 */     collection.clearDirty();
/*     */     
/*  65 */     this.snapshot = (persister.isMutable() ? collection.getSnapshot(persister) : null);
/*     */     
/*     */ 
/*  68 */     collection.setSnapshot(this.loadedKey, this.role, this.snapshot);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CollectionEntry(PersistentCollection collection, CollectionPersister loadedPersister, Serializable loadedKey, boolean ignore)
/*     */   {
/*  80 */     this.ignore = ignore;
/*     */     
/*     */ 
/*     */ 
/*  84 */     this.loadedKey = loadedKey;
/*  85 */     setLoadedPersister(loadedPersister);
/*     */     
/*  87 */     collection.setSnapshot(loadedKey, this.role, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CollectionEntry(CollectionPersister loadedPersister, Serializable loadedKey)
/*     */   {
/*  98 */     this.ignore = false;
/*     */     
/*     */ 
/*     */ 
/* 102 */     this.loadedKey = loadedKey;
/* 103 */     setLoadedPersister(loadedPersister);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   CollectionEntry(PersistentCollection collection, SessionFactoryImplementor factory)
/*     */     throws MappingException
/*     */   {
/* 113 */     this.ignore = false;
/*     */     
/* 115 */     this.loadedKey = collection.getKey();
/* 116 */     setLoadedPersister(factory.getCollectionPersister(collection.getRole()));
/*     */     
/* 118 */     this.snapshot = collection.getStoredSnapshot();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void dirty(PersistentCollection collection)
/*     */     throws HibernateException
/*     */   {
/* 127 */     boolean forceDirty = (collection.wasInitialized()) && (!collection.isDirty()) && (getLoadedPersister() != null) && (getLoadedPersister().isMutable()) && ((collection.isDirectlyAccessible()) || (getLoadedPersister().getElementType().isMutable())) && (!collection.equalsSnapshot(getLoadedPersister()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 134 */     if (forceDirty) {
/* 135 */       collection.dirty();
/*     */     }
/*     */   }
/*     */   
/*     */   public void preFlush(PersistentCollection collection)
/*     */     throws HibernateException
/*     */   {
/* 142 */     boolean nonMutableChange = (collection.isDirty()) && (getLoadedPersister() != null) && (!getLoadedPersister().isMutable());
/*     */     
/*     */ 
/* 145 */     if (nonMutableChange) {
/* 146 */       throw new HibernateException("changed an immutable collection instance: " + MessageHelper.collectionInfoString(getLoadedPersister().getRole(), getLoadedKey()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 152 */     dirty(collection);
/*     */     
/* 154 */     if ((log.isDebugEnabled()) && (collection.isDirty()) && (getLoadedPersister() != null)) {
/* 155 */       log.debug("Collection dirty: " + MessageHelper.collectionInfoString(getLoadedPersister().getRole(), getLoadedKey()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 161 */     setDoupdate(false);
/* 162 */     setDoremove(false);
/* 163 */     setDorecreate(false);
/* 164 */     setReached(false);
/* 165 */     setProcessed(false);
/*     */   }
/*     */   
/*     */   public void postInitialize(PersistentCollection collection) throws HibernateException {
/* 169 */     this.snapshot = (getLoadedPersister().isMutable() ? collection.getSnapshot(getLoadedPersister()) : null);
/*     */     
/*     */ 
/* 172 */     collection.setSnapshot(this.loadedKey, this.role, this.snapshot);
/*     */   }
/*     */   
/*     */ 
/*     */   public void postFlush(PersistentCollection collection)
/*     */     throws HibernateException
/*     */   {
/* 179 */     if (isIgnore()) {
/* 180 */       this.ignore = false;
/*     */     }
/* 182 */     else if (!isProcessed()) {
/* 183 */       throw new AssertionFailure("collection was not processed by flush()");
/*     */     }
/* 185 */     collection.setSnapshot(this.loadedKey, this.role, this.snapshot);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void afterAction(PersistentCollection collection)
/*     */   {
/* 192 */     this.loadedKey = getCurrentKey();
/* 193 */     setLoadedPersister(getCurrentPersister());
/*     */     
/* 195 */     boolean resnapshot = (collection.wasInitialized()) && ((isDoremove()) || (isDorecreate()) || (isDoupdate()));
/*     */     
/* 197 */     if (resnapshot) {
/* 198 */       this.snapshot = ((this.loadedPersister == null) || (!this.loadedPersister.isMutable()) ? null : collection.getSnapshot(this.loadedPersister));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 203 */     collection.postAction();
/*     */   }
/*     */   
/*     */   public Serializable getKey() {
/* 207 */     return getLoadedKey();
/*     */   }
/*     */   
/*     */   public String getRole() {
/* 211 */     return this.role;
/*     */   }
/*     */   
/*     */   public Serializable getSnapshot() {
/* 215 */     return this.snapshot;
/*     */   }
/*     */   
/*     */   private void setLoadedPersister(CollectionPersister persister) {
/* 219 */     this.loadedPersister = persister;
/* 220 */     setRole(persister == null ? null : persister.getRole());
/*     */   }
/*     */   
/*     */   void afterDeserialize(SessionFactoryImplementor factory) {
/* 224 */     this.loadedPersister = factory.getCollectionPersister(this.role);
/*     */   }
/*     */   
/*     */   public boolean wasDereferenced() {
/* 228 */     return getLoadedKey() == null;
/*     */   }
/*     */   
/*     */   public boolean isReached() {
/* 232 */     return this.reached;
/*     */   }
/*     */   
/*     */   public void setReached(boolean reached) {
/* 236 */     this.reached = reached;
/*     */   }
/*     */   
/*     */   public boolean isProcessed() {
/* 240 */     return this.processed;
/*     */   }
/*     */   
/*     */   public void setProcessed(boolean processed) {
/* 244 */     this.processed = processed;
/*     */   }
/*     */   
/*     */   public boolean isDoupdate() {
/* 248 */     return this.doupdate;
/*     */   }
/*     */   
/*     */   public void setDoupdate(boolean doupdate) {
/* 252 */     this.doupdate = doupdate;
/*     */   }
/*     */   
/*     */   public boolean isDoremove() {
/* 256 */     return this.doremove;
/*     */   }
/*     */   
/*     */   public void setDoremove(boolean doremove) {
/* 260 */     this.doremove = doremove;
/*     */   }
/*     */   
/*     */   public boolean isDorecreate() {
/* 264 */     return this.dorecreate;
/*     */   }
/*     */   
/*     */   public void setDorecreate(boolean dorecreate) {
/* 268 */     this.dorecreate = dorecreate;
/*     */   }
/*     */   
/*     */   public boolean isIgnore() {
/* 272 */     return this.ignore;
/*     */   }
/*     */   
/*     */   public CollectionPersister getCurrentPersister() {
/* 276 */     return this.currentPersister;
/*     */   }
/*     */   
/*     */   public void setCurrentPersister(CollectionPersister currentPersister) {
/* 280 */     this.currentPersister = currentPersister;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Serializable getCurrentKey()
/*     */   {
/* 288 */     return this.currentKey;
/*     */   }
/*     */   
/*     */   public void setCurrentKey(Serializable currentKey) {
/* 292 */     this.currentKey = currentKey;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CollectionPersister getLoadedPersister()
/*     */   {
/* 299 */     return this.loadedPersister;
/*     */   }
/*     */   
/*     */   public Serializable getLoadedKey() {
/* 303 */     return this.loadedKey;
/*     */   }
/*     */   
/*     */   public void setRole(String role) {
/* 307 */     this.role = role;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 311 */     String result = "CollectionEntry" + MessageHelper.collectionInfoString(this.loadedPersister.getRole(), this.loadedKey);
/*     */     
/* 313 */     if (this.currentPersister != null) {
/* 314 */       result = result + "->" + MessageHelper.collectionInfoString(this.currentPersister.getRole(), this.currentKey);
/*     */     }
/*     */     
/* 317 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Collection getOrphans(String entityName, PersistentCollection collection)
/*     */     throws HibernateException
/*     */   {
/* 325 */     if (this.snapshot == null) {
/* 326 */       throw new AssertionFailure("no collection snapshot for orphan delete");
/*     */     }
/* 328 */     return collection.getOrphans(this.snapshot, entityName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isSnapshotEmpty(PersistentCollection collection)
/*     */   {
/* 335 */     return (collection.wasInitialized()) && ((getLoadedPersister() == null) || (getLoadedPersister().isMutable())) && (collection.isSnapshotEmpty(getSnapshot()));
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\CollectionEntry.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */