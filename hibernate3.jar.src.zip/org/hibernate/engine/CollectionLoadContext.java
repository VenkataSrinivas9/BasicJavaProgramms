/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.CacheMode;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.cache.CacheConcurrencyStrategy;
/*     */ import org.hibernate.cache.CacheKey;
/*     */ import org.hibernate.cache.entry.CacheEntryStructure;
/*     */ import org.hibernate.cache.entry.CollectionCacheEntry;
/*     */ import org.hibernate.cfg.Settings;
/*     */ import org.hibernate.collection.PersistentCollection;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.pretty.MessageHelper;
/*     */ import org.hibernate.stat.Statistics;
/*     */ import org.hibernate.stat.StatisticsImplementor;
/*     */ import org.hibernate.type.CollectionType;
/*     */ 
/*     */ public class CollectionLoadContext
/*     */ {
/*  31 */   private static final Log log = LogFactory.getLog(CollectionLoadContext.class);
/*     */   
/*     */ 
/*  34 */   private final Map loadingCollections = new HashMap(8);
/*     */   private final PersistenceContext context;
/*     */   
/*     */   public CollectionLoadContext(PersistenceContext context) {
/*  38 */     this.context = context;
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class LoadingCollectionEntry
/*     */   {
/*     */     final PersistentCollection collection;
/*     */     
/*     */     final Serializable key;
/*     */     
/*     */     final Object resultSetId;
/*     */     
/*     */     final CollectionPersister persister;
/*     */     
/*     */     LoadingCollectionEntry(PersistentCollection collection, Serializable key, CollectionPersister persister, Object resultSetId)
/*     */     {
/*  54 */       this.collection = collection;
/*  55 */       this.key = key;
/*  56 */       this.persister = persister;
/*  57 */       this.resultSetId = resultSetId;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PersistentCollection getLoadingCollection(CollectionPersister persister, Serializable key, Object resultSetId, EntityMode em)
/*     */     throws HibernateException
/*     */   {
/*  72 */     CollectionKey ckey = new CollectionKey(persister, key, em);
/*  73 */     LoadingCollectionEntry lce = getLoadingCollectionEntry(ckey);
/*  74 */     if (lce == null)
/*     */     {
/*  76 */       PersistentCollection collection = this.context.getCollection(ckey);
/*  77 */       if (collection != null) {
/*  78 */         if (collection.wasInitialized()) {
/*  79 */           log.trace("collection already initialized: ignoring");
/*  80 */           return null;
/*     */         }
/*     */         
/*     */ 
/*  84 */         log.trace("uninitialized collection: initializing");
/*     */       }
/*     */       else
/*     */       {
/*  88 */         Object entity = this.context.getCollectionOwner(key, persister);
/*  89 */         boolean newlySavedEntity = (entity != null) && (this.context.getEntry(entity).getStatus() != Status.LOADING) && (em != EntityMode.DOM4J);
/*     */         
/*     */ 
/*  92 */         if (newlySavedEntity)
/*     */         {
/*     */ 
/*  95 */           log.trace("owning entity already loaded: ignoring");
/*  96 */           return null;
/*     */         }
/*     */         
/*     */ 
/* 100 */         log.trace("new collection: instantiating");
/* 101 */         collection = persister.getCollectionType().instantiate(this.context.getSession(), persister, key);
/*     */       }
/*     */       
/*     */ 
/* 105 */       collection.beforeInitialize(persister);
/* 106 */       collection.beginRead();
/* 107 */       addLoadingCollectionEntry(ckey, collection, persister, resultSetId);
/* 108 */       return collection;
/*     */     }
/*     */     
/* 111 */     if (lce.resultSetId == resultSetId) {
/* 112 */       log.trace("reading row");
/* 113 */       return lce.collection;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 118 */     log.trace("collection is already being initialized: ignoring row");
/* 119 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PersistentCollection getLoadingCollection(CollectionPersister persister, Serializable id, EntityMode em)
/*     */   {
/* 129 */     LoadingCollectionEntry lce = getLoadingCollectionEntry(new CollectionKey(persister, id, em));
/* 130 */     if (lce != null) {
/* 131 */       if (log.isTraceEnabled()) {
/* 132 */         log.trace("returning loading collection:" + MessageHelper.collectionInfoString(persister, id, this.context.getSession().getFactory()));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 137 */       return lce.collection;
/*     */     }
/*     */     
/* 140 */     if (log.isTraceEnabled()) {
/* 141 */       log.trace("creating collection wrapper:" + MessageHelper.collectionInfoString(persister, id, this.context.getSession().getFactory()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 146 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addLoadingCollectionEntry(CollectionKey collectionKey, PersistentCollection collection, CollectionPersister persister, Object resultSetId)
/*     */   {
/* 159 */     this.loadingCollections.put(collectionKey, new LoadingCollectionEntry(collection, collectionKey.getKey(), persister, resultSetId));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private LoadingCollectionEntry getLoadingCollectionEntry(CollectionKey collectionKey)
/*     */   {
/* 174 */     return (LoadingCollectionEntry)this.loadingCollections.get(collectionKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void endLoadingCollection(LoadingCollectionEntry lce, CollectionPersister persister, EntityMode em)
/*     */   {
/* 183 */     boolean hasNoQueuedAdds = lce.collection.endRead();
/*     */     
/* 185 */     if (persister.getCollectionType().hasHolder(em)) {
/* 186 */       this.context.addCollectionHolder(lce.collection);
/*     */     }
/*     */     
/* 189 */     CollectionEntry ce = this.context.getCollectionEntry(lce.collection);
/* 190 */     if (ce == null) {
/* 191 */       ce = this.context.addInitializedCollection(persister, lce.collection, lce.key);
/*     */     }
/*     */     else {
/* 194 */       ce.postInitialize(lce.collection);
/*     */     }
/*     */     
/* 197 */     SessionImplementor session = this.context.getSession();
/*     */     
/* 199 */     boolean addToCache = (hasNoQueuedAdds) && (persister.hasCache()) && (session.getCacheMode().isPutEnabled()) && (!ce.isDoremove());
/*     */     
/*     */ 
/*     */ 
/* 203 */     if (addToCache) { addCollectionToCache(lce, persister);
/*     */     }
/* 205 */     if (log.isDebugEnabled()) {
/* 206 */       log.debug("collection fully initialized: " + MessageHelper.collectionInfoString(persister, lce.key, this.context.getSession().getFactory()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 212 */     if (session.getFactory().getStatistics().isStatisticsEnabled()) {
/* 213 */       session.getFactory().getStatisticsImplementor().loadCollection(persister.getRole());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void endLoadingCollections(CollectionPersister persister, Object resultSetId, SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/* 229 */     List resultSetCollections = null;
/* 230 */     Iterator iter = this.loadingCollections.values().iterator();
/* 231 */     while (iter.hasNext()) {
/* 232 */       LoadingCollectionEntry lce = (LoadingCollectionEntry)iter.next();
/* 233 */       if ((lce.resultSetId == resultSetId) && (lce.persister == persister)) {
/* 234 */         if (resultSetCollections == null) {
/* 235 */           resultSetCollections = new ArrayList();
/*     */         }
/* 237 */         resultSetCollections.add(lce);
/* 238 */         if (lce.collection.getOwner() == null) {
/* 239 */           session.getPersistenceContext().addUnownedCollection(new CollectionKey(persister, lce.key, session.getEntityMode()), lce.collection);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 245 */         iter.remove();
/*     */       }
/*     */     }
/*     */     
/* 249 */     endLoadingCollections(persister, resultSetCollections, session.getEntityMode());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void endLoadingCollections(CollectionPersister persister, List resultSetCollections, EntityMode em)
/*     */     throws HibernateException
/*     */   {
/* 259 */     int count = resultSetCollections == null ? 0 : resultSetCollections.size();
/*     */     
/* 261 */     if (log.isDebugEnabled()) {
/* 262 */       log.debug(count + " collections were found in result set for role: " + persister.getRole());
/*     */     }
/*     */     
/*     */ 
/* 266 */     for (int i = 0; i < count; i++) {
/* 267 */       LoadingCollectionEntry lce = (LoadingCollectionEntry)resultSetCollections.get(i);
/* 268 */       endLoadingCollection(lce, persister, em);
/*     */     }
/*     */     
/* 271 */     if (log.isDebugEnabled()) {
/* 272 */       log.debug(count + " collections initialized for role: " + persister.getRole());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addCollectionToCache(LoadingCollectionEntry lce, CollectionPersister persister)
/*     */   {
/* 281 */     if (log.isDebugEnabled()) {
/* 282 */       log.debug("Caching collection: " + MessageHelper.collectionInfoString(persister, lce.key, this.context.getSession().getFactory()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 288 */     SessionImplementor session = this.context.getSession();
/* 289 */     SessionFactoryImplementor factory = session.getFactory();
/*     */     
/* 291 */     if ((!session.getEnabledFilters().isEmpty()) && (persister.isAffectedByEnabledFilters(session)))
/*     */     {
/* 293 */       log.debug("Refusing to add to cache due to enabled filters"); return;
/*     */     }
/*     */     
/*     */ 
/*     */     Object version;
/*     */     
/*     */ 
/*     */     Object version;
/*     */     
/*     */     Comparator versionComparator;
/*     */     
/* 304 */     if (persister.isVersioned()) {
/* 305 */       Comparator versionComparator = persister.getOwnerEntityPersister().getVersionType().getComparator();
/* 306 */       version = this.context.getEntry(this.context.getCollectionOwner(lce.key, persister)).getVersion();
/*     */     }
/*     */     else {
/* 309 */       version = null;
/* 310 */       versionComparator = null;
/*     */     }
/*     */     
/* 313 */     CollectionCacheEntry entry = new CollectionCacheEntry(lce.collection, persister);
/*     */     
/* 315 */     CacheKey cacheKey = new CacheKey(lce.key, persister.getKeyType(), persister.getRole(), session.getEntityMode(), session.getFactory());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 322 */     boolean put = persister.getCache().put(cacheKey, persister.getCacheEntryStructure().structure(entry), session.getTimestamp(), version, versionComparator, (factory.getSettings().isMinimalPutsEnabled()) && (session.getCacheMode() != CacheMode.REFRESH));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 332 */     if ((put) && (factory.getStatistics().isStatisticsEnabled())) {
/* 333 */       factory.getStatisticsImplementor().secondLevelCachePut(persister.getCache().getRegionName());
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\CollectionLoadContext.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */