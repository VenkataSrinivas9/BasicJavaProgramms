/*    */ package org.hibernate.engine;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ import org.hibernate.type.VersionType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Versioning
/*    */ {
/* 19 */   private static final Log log = LogFactory.getLog(Versioning.class);
/*    */   public static final int OPTIMISTIC_LOCK_NONE = -1;
/*    */   public static final int OPTIMISTIC_LOCK_ALL = 2;
/*    */   public static final int OPTIMISTIC_LOCK_DIRTY = 1;
/*    */   public static final int OPTIMISTIC_LOCK_VERSION = 0;
/*    */   
/* 25 */   public static Object increment(Object version, VersionType versionType, SessionImplementor session) { Object next = versionType.next(version, session);
/* 26 */     if (log.isTraceEnabled()) log.trace("Incrementing: " + version + " to " + next);
/* 27 */     return next;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   private static Object seed(VersionType versionType, SessionImplementor session)
/*    */   {
/* 34 */     Object seed = versionType.seed(session);
/* 35 */     if (log.isTraceEnabled()) log.trace("Seeding: " + seed);
/* 36 */     return seed;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static boolean seedVersion(Object[] fields, int versionProperty, VersionType versionType, SessionImplementor session)
/*    */   {
/* 47 */     Object initialVersion = fields[versionProperty];
/* 48 */     if ((initialVersion == null) || (((initialVersion instanceof Number)) && (((Number)initialVersion).longValue() < 0L)))
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 56 */       fields[versionProperty] = seed(versionType, session);
/* 57 */       return true;
/*    */     }
/*    */     
/* 60 */     if (log.isTraceEnabled()) log.trace("using initial version: " + initialVersion);
/* 61 */     return false;
/*    */   }
/*    */   
/*    */   private static Object getVersion(Object[] fields, int versionProperty)
/*    */   {
/* 66 */     return fields[versionProperty];
/*    */   }
/*    */   
/*    */   private static void setVersion(Object[] fields, Object version, int versionProperty) {
/* 70 */     fields[versionProperty] = version;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static void setVersion(Object[] fields, Object version, EntityPersister persister)
/*    */   {
/* 77 */     setVersion(fields, version, persister.getVersionProperty());
/*    */   }
/*    */   
/*    */ 
/*    */   public static Object getVersion(Object[] fields, EntityPersister persister)
/*    */     throws HibernateException
/*    */   {
/* 84 */     return persister.isVersioned() ? getVersion(fields, persister.getVersionProperty()) : null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static boolean isVersionIncrementRequired(int[] dirtyProperties, boolean hasDirtyCollections, boolean[] propertyVersionability)
/*    */   {
/* 95 */     if (hasDirtyCollections) return true;
/* 96 */     for (int i = 0; i < dirtyProperties.length; i++) {
/* 97 */       if (propertyVersionability[dirtyProperties[i]] != 0) return true;
/*    */     }
/* 99 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\Versioning.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */