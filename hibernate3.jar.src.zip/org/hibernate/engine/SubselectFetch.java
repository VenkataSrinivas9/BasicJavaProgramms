/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.hibernate.persister.entity.Loadable;
/*     */ import org.hibernate.persister.entity.PropertyMapping;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubselectFetch
/*     */ {
/*     */   private final Set resultingEntityKeys;
/*     */   private final String queryString;
/*     */   private final String alias;
/*     */   private final Loadable loadable;
/*     */   private final QueryParameters queryParameters;
/*     */   private final Map namedParameterLocMap;
/*     */   
/*     */   public SubselectFetch(String alias, Loadable loadable, QueryParameters queryParameters, Set resultingEntityKeys, Map namedParameterLocMap)
/*     */   {
/*  59 */     this.resultingEntityKeys = resultingEntityKeys;
/*     */     
/*  61 */     this.queryParameters = queryParameters;
/*     */     
/*  63 */     this.namedParameterLocMap = namedParameterLocMap;
/*     */     
/*  65 */     this.loadable = loadable;
/*     */     
/*  67 */     this.alias = alias;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  73 */     String queryString = queryParameters.getFilteredSQL();
/*     */     
/*  75 */     int fromIndex = queryString.indexOf(" from ");
/*     */     
/*  77 */     int orderByIndex = queryString.lastIndexOf("order by");
/*     */     
/*  79 */     this.queryString = (orderByIndex > 0 ? queryString.substring(fromIndex, orderByIndex) : queryString.substring(fromIndex));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public QueryParameters getQueryParameters()
/*     */   {
/*  93 */     return this.queryParameters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set getResult()
/*     */   {
/* 107 */     return this.resultingEntityKeys;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toSubselectString(String ukname)
/*     */   {
/* 117 */     String[] joinColumns = ukname == null ? StringHelper.qualify(this.alias, this.loadable.getIdentifierColumnNames()) : ((PropertyMapping)this.loadable).toColumns(this.alias, ukname);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */     return "select " + StringHelper.join(", ", joinColumns) + this.queryString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 141 */     return "SubselectFetch(" + this.queryString + ')';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map getNamedParameterLocMap()
/*     */   {
/* 149 */     return this.namedParameterLocMap;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\SubselectFetch.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */