/*    */ package org.hibernate.engine;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class AssociationKey
/*    */   implements Serializable
/*    */ {
/*    */   private EntityKey ownerKey;
/*    */   private String propertyName;
/*    */   
/*    */   public AssociationKey(EntityKey ownerKey, String propertyName)
/*    */   {
/* 35 */     this.ownerKey = ownerKey;
/*    */     
/* 37 */     this.propertyName = propertyName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean equals(Object that)
/*    */   {
/* 45 */     AssociationKey key = (AssociationKey)that;
/*    */     
/* 47 */     return (key.propertyName.equals(this.propertyName)) && (key.ownerKey.equals(this.ownerKey));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 57 */     return this.ownerKey.hashCode() + this.propertyName.hashCode();
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\AssociationKey.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */