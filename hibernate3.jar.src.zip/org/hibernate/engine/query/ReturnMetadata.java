/*    */ package org.hibernate.engine.query;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ public class ReturnMetadata
/*    */   implements Serializable
/*    */ {
/*    */   private final String[] returnAliases;
/*    */   private final Type[] returnTypes;
/*    */   
/*    */   public ReturnMetadata(String[] returnAliases, Type[] returnTypes)
/*    */   {
/* 15 */     this.returnAliases = returnAliases;
/* 16 */     this.returnTypes = returnTypes;
/*    */   }
/*    */   
/*    */   public String[] getReturnAliases() {
/* 20 */     return this.returnAliases;
/*    */   }
/*    */   
/*    */   public Type[] getReturnTypes() {
/* 24 */     return this.returnTypes;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\query\ReturnMetadata.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */