/*     */ package org.hibernate.engine.query;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.util.ArrayHelper;
/*     */ import org.hibernate.util.SimpleMRUCache;
/*     */ import org.hibernate.util.SoftLimitMRUCache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueryPlanCache
/*     */   implements Serializable
/*     */ {
/*  28 */   private static final Log log = LogFactory.getLog(QueryPlanCache.class);
/*     */   private SessionFactoryImplementor factory;
/*     */   
/*     */   public QueryPlanCache(SessionFactoryImplementor factory)
/*     */   {
/*  33 */     this.factory = factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  42 */   private final SimpleMRUCache sqlParamMetadataCache = new SimpleMRUCache();
/*     */   
/*     */ 
/*  45 */   private final SoftLimitMRUCache planCache = new SoftLimitMRUCache(128);
/*     */   
/*     */   public ParameterMetadata getSQLParameterMetadata(String query)
/*     */   {
/*  49 */     ParameterMetadata metadata = (ParameterMetadata)this.sqlParamMetadataCache.get(query);
/*  50 */     if (metadata == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  56 */       metadata = buildNativeSQLParameterMetadata(query);
/*  57 */       this.sqlParamMetadataCache.put(query, metadata);
/*     */     }
/*  59 */     return metadata;
/*     */   }
/*     */   
/*     */   public HQLQueryPlan getHQLQueryPlan(String queryString, boolean shallow, Map enabledFilters) throws QueryException, MappingException
/*     */   {
/*  64 */     HQLQueryPlanKey key = new HQLQueryPlanKey(queryString, shallow, enabledFilters);
/*  65 */     HQLQueryPlan plan = (HQLQueryPlan)this.planCache.get(key);
/*     */     
/*  67 */     if (plan == null) {
/*  68 */       if (log.isTraceEnabled()) {
/*  69 */         log.trace("unable to locate HQL query plan in cache; generating (" + queryString + ")");
/*     */       }
/*  71 */       plan = new HQLQueryPlan(queryString, shallow, enabledFilters, this.factory);
/*     */ 
/*     */     }
/*  74 */     else if (log.isTraceEnabled()) {
/*  75 */       log.trace("located HQL query plan in cache (" + queryString + ")");
/*     */     }
/*     */     
/*     */ 
/*  79 */     this.planCache.put(key, plan);
/*     */     
/*  81 */     return plan;
/*     */   }
/*     */   
/*     */   public FilterQueryPlan getFilterQueryPlan(String filterString, String collectionRole, boolean shallow, Map enabledFilters) throws QueryException, MappingException
/*     */   {
/*  86 */     FilterQueryPlanKey key = new FilterQueryPlanKey(filterString, collectionRole, shallow, enabledFilters);
/*  87 */     FilterQueryPlan plan = (FilterQueryPlan)this.planCache.get(key);
/*     */     
/*  89 */     if (plan == null) {
/*  90 */       if (log.isTraceEnabled()) {
/*  91 */         log.trace("unable to locate collection-filter query plan in cache; generating (" + collectionRole + " : " + filterString + ")");
/*     */       }
/*  93 */       plan = new FilterQueryPlan(filterString, collectionRole, shallow, enabledFilters, this.factory);
/*     */ 
/*     */     }
/*  96 */     else if (log.isTraceEnabled()) {
/*  97 */       log.trace("located collection-filter query plan in cache (" + collectionRole + " : " + filterString + ")");
/*     */     }
/*     */     
/*     */ 
/* 101 */     this.planCache.put(key, plan);
/*     */     
/* 103 */     return plan;
/*     */   }
/*     */   
/*     */   public NativeSQLQueryPlan getNativeSQLQueryPlan(NativeSQLQuerySpecification spec) {
/* 107 */     NativeSQLQueryPlan plan = (NativeSQLQueryPlan)this.planCache.get(spec);
/*     */     
/* 109 */     if (plan == null) {
/* 110 */       if (log.isTraceEnabled()) {
/* 111 */         log.trace("unable to locate native-sql query plan in cache; generating (" + spec.getQueryString() + ")");
/*     */       }
/* 113 */       plan = new NativeSQLQueryPlan(spec, this.factory);
/*     */ 
/*     */     }
/* 116 */     else if (log.isTraceEnabled()) {
/* 117 */       log.trace("located native-sql query plan in cache (" + spec.getQueryString() + ")");
/*     */     }
/*     */     
/*     */ 
/* 121 */     this.planCache.put(spec, plan);
/* 122 */     return plan;
/*     */   }
/*     */   
/*     */   private ParameterMetadata buildNativeSQLParameterMetadata(String sqlString) {
/* 126 */     ParamLocationRecognizer recognizer = ParamLocationRecognizer.parseLocations(sqlString);
/*     */     
/* 128 */     OrdinalParameterDescriptor[] ordinalDescriptors = new OrdinalParameterDescriptor[recognizer.getOrdinalParameterLocationList().size()];
/*     */     
/* 130 */     for (int i = 0; i < recognizer.getOrdinalParameterLocationList().size(); i++) {
/* 131 */       Integer position = (Integer)recognizer.getOrdinalParameterLocationList().get(i);
/* 132 */       ordinalDescriptors[i] = new OrdinalParameterDescriptor(i, null, position.intValue());
/*     */     }
/*     */     
/* 135 */     Iterator itr = recognizer.getNamedParameterLocationMap().entrySet().iterator();
/* 136 */     Map namedParamDescriptorMap = new HashMap();
/* 137 */     while (itr.hasNext()) {
/* 138 */       Map.Entry entry = (Map.Entry)itr.next();
/* 139 */       String name = (String)entry.getKey();
/* 140 */       List locationList = (List)entry.getValue();
/* 141 */       namedParamDescriptorMap.put(name, new NamedParameterDescriptor(name, null, ArrayHelper.toIntArray(locationList)));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 147 */     return new ParameterMetadata(ordinalDescriptors, namedParamDescriptorMap);
/*     */   }
/*     */   
/*     */   private static class HQLQueryPlanKey implements Serializable {
/*     */     private final String query;
/*     */     private final boolean shallow;
/*     */     private final Set filterNames;
/*     */     private final int hashCode;
/*     */     
/*     */     public HQLQueryPlanKey(String query, boolean shallow, Map enabledFilters) {
/* 157 */       this.query = query;
/* 158 */       this.shallow = shallow;
/*     */       
/* 160 */       if ((enabledFilters == null) || (enabledFilters.isEmpty())) {
/* 161 */         this.filterNames = Collections.EMPTY_SET;
/*     */       }
/*     */       else {
/* 164 */         Set tmp = new HashSet();
/* 165 */         tmp.addAll(enabledFilters.keySet());
/* 166 */         this.filterNames = Collections.unmodifiableSet(tmp);
/*     */       }
/*     */       
/* 169 */       int hash = query.hashCode();
/* 170 */       hash = 29 * hash + (shallow ? 1 : 0);
/* 171 */       hash = 29 * hash + this.filterNames.hashCode();
/* 172 */       this.hashCode = hash;
/*     */     }
/*     */     
/*     */     public boolean equals(Object o) {
/* 176 */       if (this == o) {
/* 177 */         return true;
/*     */       }
/* 179 */       if ((o == null) || (getClass() != o.getClass())) {
/* 180 */         return false;
/*     */       }
/*     */       
/* 183 */       HQLQueryPlanKey that = (HQLQueryPlanKey)o;
/*     */       
/* 185 */       if (this.shallow != that.shallow) {
/* 186 */         return false;
/*     */       }
/* 188 */       if (!this.filterNames.equals(that.filterNames)) {
/* 189 */         return false;
/*     */       }
/* 191 */       if (!this.query.equals(that.query)) {
/* 192 */         return false;
/*     */       }
/*     */       
/* 195 */       return true;
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 199 */       return this.hashCode;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class FilterQueryPlanKey implements Serializable {
/*     */     private final String query;
/*     */     private final String collectionRole;
/*     */     private final boolean shallow;
/*     */     private final Set filterNames;
/*     */     private final int hashCode;
/*     */     
/*     */     public FilterQueryPlanKey(String query, String collectionRole, boolean shallow, Map enabledFilters) {
/* 211 */       this.query = query;
/* 212 */       this.collectionRole = collectionRole;
/* 213 */       this.shallow = shallow;
/*     */       
/* 215 */       if ((enabledFilters == null) || (enabledFilters.isEmpty())) {
/* 216 */         this.filterNames = Collections.EMPTY_SET;
/*     */       }
/*     */       else {
/* 219 */         Set tmp = new HashSet();
/* 220 */         tmp.addAll(enabledFilters.keySet());
/* 221 */         this.filterNames = Collections.unmodifiableSet(tmp);
/*     */       }
/*     */       
/* 224 */       int hash = query.hashCode();
/* 225 */       hash = 29 * hash + collectionRole.hashCode();
/* 226 */       hash = 29 * hash + (shallow ? 1 : 0);
/* 227 */       hash = 29 * hash + this.filterNames.hashCode();
/* 228 */       this.hashCode = hash;
/*     */     }
/*     */     
/*     */     public boolean equals(Object o) {
/* 232 */       if (this == o) {
/* 233 */         return true;
/*     */       }
/* 235 */       if ((o == null) || (getClass() != o.getClass())) {
/* 236 */         return false;
/*     */       }
/*     */       
/* 239 */       FilterQueryPlanKey that = (FilterQueryPlanKey)o;
/*     */       
/* 241 */       if (this.shallow != that.shallow) {
/* 242 */         return false;
/*     */       }
/* 244 */       if (!this.filterNames.equals(that.filterNames)) {
/* 245 */         return false;
/*     */       }
/* 247 */       if (!this.query.equals(that.query)) {
/* 248 */         return false;
/*     */       }
/* 250 */       if (!this.collectionRole.equals(that.collectionRole)) {
/* 251 */         return false;
/*     */       }
/*     */       
/* 254 */       return true;
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 258 */       return this.hashCode;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\query\QueryPlanCache.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */