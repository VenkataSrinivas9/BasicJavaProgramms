/*    */ package org.hibernate.engine.query;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParameterMetadata
/*    */   implements Serializable
/*    */ {
/* 18 */   private static final OrdinalParameterDescriptor[] EMPTY_ORDINALS = new OrdinalParameterDescriptor[0];
/*    */   
/*    */ 
/*    */   private final OrdinalParameterDescriptor[] ordinalDescriptors;
/*    */   
/*    */ 
/*    */   private final Map namedDescriptorMap;
/*    */   
/*    */ 
/*    */ 
/*    */   public ParameterMetadata(OrdinalParameterDescriptor[] ordinalDescriptors, Map namedDescriptorMap)
/*    */   {
/* 30 */     if (ordinalDescriptors == null) {
/* 31 */       this.ordinalDescriptors = EMPTY_ORDINALS;
/*    */     }
/*    */     else {
/* 34 */       OrdinalParameterDescriptor[] copy = new OrdinalParameterDescriptor[ordinalDescriptors.length];
/* 35 */       System.arraycopy(ordinalDescriptors, 0, copy, 0, ordinalDescriptors.length);
/* 36 */       this.ordinalDescriptors = copy;
/*    */     }
/* 38 */     if (namedDescriptorMap == null) {
/* 39 */       this.namedDescriptorMap = Collections.EMPTY_MAP;
/*    */     }
/*    */     else {
/* 42 */       int size = (int)(namedDescriptorMap.size() / 0.75D + 1.0D);
/* 43 */       Map copy = new HashMap(size);
/* 44 */       copy.putAll(namedDescriptorMap);
/* 45 */       this.namedDescriptorMap = Collections.unmodifiableMap(copy);
/*    */     }
/*    */   }
/*    */   
/*    */   public int getOrdinalParameterCount() {
/* 50 */     return this.ordinalDescriptors.length;
/*    */   }
/*    */   
/*    */   public OrdinalParameterDescriptor getOrdinalParameterDescriptor(int position) {
/* 54 */     if ((position < 1) || (position > this.ordinalDescriptors.length)) {
/* 55 */       throw new IndexOutOfBoundsException("Remember that ordinal parameters are 1-based!");
/*    */     }
/* 57 */     return this.ordinalDescriptors[(position - 1)];
/*    */   }
/*    */   
/*    */   public Type getOrdinalParameterExpectedType(int position) {
/* 61 */     return getOrdinalParameterDescriptor(position).getExpectedType();
/*    */   }
/*    */   
/*    */   public int getOrdinalParameterSourceLocation(int position) {
/* 65 */     return getOrdinalParameterDescriptor(position).getSourceLocation();
/*    */   }
/*    */   
/*    */   public Set getNamedParameterNames() {
/* 69 */     return this.namedDescriptorMap.keySet();
/*    */   }
/*    */   
/*    */   public NamedParameterDescriptor getNamedParameterDescriptor(String name) {
/* 73 */     NamedParameterDescriptor meta = (NamedParameterDescriptor)this.namedDescriptorMap.get(name);
/* 74 */     if (meta == null) {
/* 75 */       throw new HibernateException("could not locate named parameter [" + name + "]");
/*    */     }
/* 77 */     return meta;
/*    */   }
/*    */   
/*    */   public Type getNamedParameterExpectedType(String name) {
/* 81 */     return getNamedParameterDescriptor(name).getExpectedType();
/*    */   }
/*    */   
/*    */   public int[] getNamedParameterSourceLocations(String name) {
/* 85 */     return getNamedParameterDescriptor(name).getSourceLocations();
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\query\ParameterMetadata.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */