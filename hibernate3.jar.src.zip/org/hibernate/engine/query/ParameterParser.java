/*    */ package org.hibernate.engine.query;
/*    */ 
/*    */ import org.hibernate.QueryException;
/*    */ import org.hibernate.util.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParameterParser
/*    */ {
/*    */   public static void parse(String sqlString, Recognizer recognizer)
/*    */     throws QueryException
/*    */   {
/* 42 */     boolean hasMainOutputParameter = (sqlString.indexOf("call") > 0) && (sqlString.indexOf("?") < sqlString.indexOf("call")) && (sqlString.indexOf("=") < sqlString.indexOf("call"));
/*    */     
/*    */ 
/* 45 */     boolean foundMainOutputParam = false;
/*    */     
/* 47 */     int stringLength = sqlString.length();
/* 48 */     boolean inQuote = false;
/* 49 */     for (int indx = 0; indx < stringLength; indx++) {
/* 50 */       char c = sqlString.charAt(indx);
/* 51 */       if (inQuote) {
/* 52 */         if ('\'' == c) {
/* 53 */           inQuote = false;
/*    */         }
/* 55 */         recognizer.other(c);
/*    */       }
/* 57 */       else if ('\'' == c) {
/* 58 */         inQuote = true;
/* 59 */         recognizer.other(c);
/*    */ 
/*    */       }
/* 62 */       else if (c == ':')
/*    */       {
/* 64 */         int right = StringHelper.firstIndexOfChar(sqlString, " \n\r\f\t,()=<>&|+-=/*'^![]#~\\", indx + 1);
/* 65 */         int chopLocation = right < 0 ? sqlString.length() : right;
/* 66 */         String param = sqlString.substring(indx + 1, chopLocation);
/* 67 */         recognizer.namedParameter(param, indx);
/* 68 */         indx = chopLocation - 1;
/*    */       }
/* 70 */       else if (c == '?')
/*    */       {
/* 72 */         if ((indx < stringLength - 1) && (Character.isDigit(sqlString.charAt(indx + 1))))
/*    */         {
/* 74 */           int right = StringHelper.firstIndexOfChar(sqlString, " \n\r\f\t,()=<>&|+-=/*'^![]#~\\", indx + 1);
/* 75 */           int chopLocation = right < 0 ? sqlString.length() : right;
/* 76 */           String param = sqlString.substring(indx + 1, chopLocation);
/*    */           try
/*    */           {
/* 79 */             new Integer(param);
/*    */           }
/*    */           catch (NumberFormatException e) {
/* 82 */             throw new QueryException("ejb3-style positional param was not an integral ordinal");
/*    */           }
/* 84 */           recognizer.ejb3PositionalParameter(param, indx);
/* 85 */           indx = chopLocation - 1;
/*    */ 
/*    */         }
/* 88 */         else if ((hasMainOutputParameter) && (!foundMainOutputParam)) {
/* 89 */           foundMainOutputParam = true;
/* 90 */           recognizer.outParameter(indx);
/*    */         }
/*    */         else {
/* 93 */           recognizer.ordinalParameter(indx);
/*    */         }
/*    */       }
/*    */       else
/*    */       {
/* 98 */         recognizer.other(c);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public static abstract interface Recognizer
/*    */   {
/*    */     public abstract void outParameter(int paramInt);
/*    */     
/*    */     public abstract void ordinalParameter(int paramInt);
/*    */     
/*    */     public abstract void namedParameter(String paramString, int paramInt);
/*    */     
/*    */     public abstract void ejb3PositionalParameter(String paramString, int paramInt);
/*    */     
/*    */     public abstract void other(char paramChar);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\query\ParameterParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */