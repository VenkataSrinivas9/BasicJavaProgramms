/*     */ package org.hibernate.engine.query;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.ScrollableResults;
/*     */ import org.hibernate.cfg.Settings;
/*     */ import org.hibernate.engine.QueryParameters;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.event.EventSource;
/*     */ import org.hibernate.hql.FilterTranslator;
/*     */ import org.hibernate.hql.ParameterTranslations;
/*     */ import org.hibernate.hql.QuerySplitter;
/*     */ import org.hibernate.hql.QueryTranslator;
/*     */ import org.hibernate.hql.QueryTranslatorFactory;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.ArrayHelper;
/*     */ import org.hibernate.util.EmptyIterator;
/*     */ import org.hibernate.util.JoinedIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HQLQueryPlan
/*     */   implements Serializable
/*     */ {
/*  39 */   private static final Log log = LogFactory.getLog(HQLQueryPlan.class);
/*     */   
/*     */   private final String sourceQuery;
/*     */   
/*     */   private final QueryTranslator[] translators;
/*     */   
/*     */   private final String[] sqlStrings;
/*     */   private final ParameterMetadata parameterMetadata;
/*     */   private final ReturnMetadata returnMetadata;
/*     */   private final Set querySpaces;
/*     */   private final Set enabledFilterNames;
/*     */   private final boolean shallow;
/*     */   
/*     */   public HQLQueryPlan(String hql, boolean shallow, Map enabledFilters, SessionFactoryImplementor factory)
/*     */   {
/*  54 */     this(hql, null, shallow, enabledFilters, factory);
/*     */   }
/*     */   
/*     */   protected HQLQueryPlan(String hql, String collectionRole, boolean shallow, Map enabledFilters, SessionFactoryImplementor factory) {
/*  58 */     this.sourceQuery = hql;
/*  59 */     this.shallow = shallow;
/*     */     
/*  61 */     Set copy = new HashSet();
/*  62 */     copy.addAll(enabledFilters.keySet());
/*  63 */     this.enabledFilterNames = Collections.unmodifiableSet(copy);
/*     */     
/*  65 */     Set combinedQuerySpaces = new HashSet();
/*  66 */     String[] concreteQueryStrings = QuerySplitter.concreteQueries(hql, factory);
/*  67 */     int length = concreteQueryStrings.length;
/*  68 */     this.translators = new QueryTranslator[length];
/*  69 */     List sqlStringList = new ArrayList();
/*  70 */     for (int i = 0; i < length; i++) {
/*  71 */       if (collectionRole == null) {
/*  72 */         this.translators[i] = factory.getSettings().getQueryTranslatorFactory().createQueryTranslator(hql, concreteQueryStrings[i], enabledFilters, factory);
/*     */         
/*     */ 
/*  75 */         this.translators[i].compile(factory.getSettings().getQuerySubstitutions(), shallow);
/*     */       }
/*     */       else {
/*  78 */         this.translators[i] = factory.getSettings().getQueryTranslatorFactory().createFilterTranslator(hql, concreteQueryStrings[i], enabledFilters, factory);
/*     */         
/*     */ 
/*  81 */         ((FilterTranslator)this.translators[i]).compile(collectionRole, factory.getSettings().getQuerySubstitutions(), shallow);
/*     */       }
/*  83 */       combinedQuerySpaces.addAll(this.translators[i].getQuerySpaces());
/*  84 */       sqlStringList.addAll(this.translators[i].collectSqlStrings());
/*     */     }
/*     */     
/*  87 */     this.sqlStrings = ArrayHelper.toStringArray(sqlStringList);
/*  88 */     this.querySpaces = combinedQuerySpaces;
/*     */     
/*  90 */     if (length == 0) {
/*  91 */       this.parameterMetadata = new ParameterMetadata(null, null);
/*  92 */       this.returnMetadata = null;
/*     */     }
/*     */     else {
/*  95 */       this.parameterMetadata = buildParameterMetadata(this.translators[0].getParameterTranslations(), hql);
/*  96 */       if (this.translators[0].isManipulationStatement()) {
/*  97 */         this.returnMetadata = null;
/*     */ 
/*     */       }
/* 100 */       else if (length > 1) {
/* 101 */         int returns = this.translators[0].getReturnTypes().length;
/* 102 */         this.returnMetadata = new ReturnMetadata(this.translators[0].getReturnAliases(), new Type[returns]);
/*     */       }
/*     */       else {
/* 105 */         this.returnMetadata = new ReturnMetadata(this.translators[0].getReturnAliases(), this.translators[0].getReturnTypes());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String getSourceQuery()
/*     */   {
/* 112 */     return this.sourceQuery;
/*     */   }
/*     */   
/*     */   public Set getQuerySpaces() {
/* 116 */     return this.querySpaces;
/*     */   }
/*     */   
/*     */   public ParameterMetadata getParameterMetadata() {
/* 120 */     return this.parameterMetadata;
/*     */   }
/*     */   
/*     */   public ReturnMetadata getReturnMetadata() {
/* 124 */     return this.returnMetadata;
/*     */   }
/*     */   
/*     */   public Set getEnabledFilterNames() {
/* 128 */     return this.enabledFilterNames;
/*     */   }
/*     */   
/*     */   public String[] getSqlStrings() {
/* 132 */     return this.sqlStrings;
/*     */   }
/*     */   
/*     */   public Set getUtilizedFilterNames()
/*     */   {
/* 137 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isShallow() {
/* 141 */     return this.shallow;
/*     */   }
/*     */   
/*     */   public List performList(QueryParameters queryParameters, SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/* 147 */     if (log.isTraceEnabled()) {
/* 148 */       log.trace("find: " + getSourceQuery());
/* 149 */       queryParameters.traceParameters(session.getFactory());
/*     */     }
/* 151 */     List combinedResults = new ArrayList();
/* 152 */     for (int i = 0; i < this.translators.length; i++) {
/* 153 */       combinedResults.addAll(this.translators[i].list(session, queryParameters));
/*     */     }
/* 155 */     return combinedResults;
/*     */   }
/*     */   
/*     */   public Iterator performIterate(QueryParameters queryParameters, EventSource session)
/*     */     throws HibernateException
/*     */   {
/* 161 */     if (log.isTraceEnabled()) {
/* 162 */       log.trace("iterate: " + getSourceQuery());
/* 163 */       queryParameters.traceParameters(session.getFactory());
/*     */     }
/* 165 */     if (this.translators.length == 0) {
/* 166 */       return EmptyIterator.INSTANCE;
/*     */     }
/*     */     
/* 169 */     Iterator[] results = null;
/* 170 */     boolean many = this.translators.length > 1;
/* 171 */     if (many) {
/* 172 */       results = new Iterator[this.translators.length];
/*     */     }
/*     */     
/* 175 */     Iterator result = null;
/* 176 */     for (int i = 0; i < this.translators.length; i++) {
/* 177 */       result = this.translators[i].iterate(queryParameters, session);
/* 178 */       if (many) { results[i] = result;
/*     */       }
/*     */     }
/* 181 */     return many ? new JoinedIterator(results) : result;
/*     */   }
/*     */   
/*     */   public ScrollableResults performScroll(QueryParameters queryParameters, SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/* 187 */     if (log.isTraceEnabled()) {
/* 188 */       log.trace("iterate: " + getSourceQuery());
/* 189 */       queryParameters.traceParameters(session.getFactory());
/*     */     }
/* 191 */     if (this.translators.length != 1) {
/* 192 */       throw new QueryException("implicit polymorphism not supported for scroll() queries");
/*     */     }
/*     */     
/* 195 */     return this.translators[0].scroll(queryParameters, session);
/*     */   }
/*     */   
/*     */   public int performExecuteUpdate(QueryParameters queryParameters, SessionImplementor session) throws HibernateException
/*     */   {
/* 200 */     if (log.isTraceEnabled()) {
/* 201 */       log.trace("executeUpdate: " + getSourceQuery());
/* 202 */       queryParameters.traceParameters(session.getFactory());
/*     */     }
/* 204 */     if (this.translators.length != 1) {
/* 205 */       log.warn("manipulation query [" + getSourceQuery() + "] resulted in [" + this.translators.length + "] split queries");
/*     */     }
/* 207 */     int result = 0;
/* 208 */     for (int i = 0; i < this.translators.length; i++) {
/* 209 */       result += this.translators[i].executeUpdate(queryParameters, session);
/*     */     }
/* 211 */     return result;
/*     */   }
/*     */   
/*     */   private ParameterMetadata buildParameterMetadata(ParameterTranslations parameterTranslations, String hql) {
/* 215 */     long start = System.currentTimeMillis();
/* 216 */     ParamLocationRecognizer recognizer = ParamLocationRecognizer.parseLocations(hql);
/* 217 */     long end = System.currentTimeMillis();
/* 218 */     if (log.isTraceEnabled()) {
/* 219 */       log.trace("HQL param location recognition took " + (end - start) + " mills (" + hql + ")");
/*     */     }
/*     */     
/* 222 */     int ordinalParamCount = parameterTranslations.getOrdinalParameterCount();
/* 223 */     int[] locations = ArrayHelper.toIntArray(recognizer.getOrdinalParameterLocationList());
/* 224 */     if ((parameterTranslations.supportsOrdinalParameterMetadata()) && (locations.length != ordinalParamCount)) {
/* 225 */       throw new HibernateException("ordinal parameter mismatch");
/*     */     }
/* 227 */     ordinalParamCount = locations.length;
/* 228 */     OrdinalParameterDescriptor[] ordinalParamDescriptors = new OrdinalParameterDescriptor[ordinalParamCount];
/* 229 */     for (int i = 1; i <= ordinalParamCount; i++) {
/* 230 */       ordinalParamDescriptors[(i - 1)] = new OrdinalParameterDescriptor(i, parameterTranslations.supportsOrdinalParameterMetadata() ? parameterTranslations.getOrdinalParameterExpectedType(i) : null, locations[(i - 1)]);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 239 */     Iterator itr = recognizer.getNamedParameterLocationMap().entrySet().iterator();
/* 240 */     Map namedParamDescriptorMap = new HashMap();
/* 241 */     while (itr.hasNext()) {
/* 242 */       Map.Entry entry = (Map.Entry)itr.next();
/* 243 */       String name = (String)entry.getKey();
/* 244 */       int[] locArray = ArrayHelper.toIntArray((List)entry.getValue());
/* 245 */       namedParamDescriptorMap.put(name, new NamedParameterDescriptor(name, parameterTranslations.getNamedParameterExpectedType(name), locArray));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 255 */     return new ParameterMetadata(ordinalParamDescriptors, namedParamDescriptorMap);
/*     */   }
/*     */   
/*     */   public QueryTranslator[] getTranslators() {
/* 259 */     QueryTranslator[] copy = new QueryTranslator[this.translators.length];
/* 260 */     System.arraycopy(this.translators, 0, copy, 0, copy.length);
/* 261 */     return copy;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\query\HQLQueryPlan.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */