/*    */ package org.hibernate.engine.query;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Map;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FilterQueryPlan
/*    */   extends HQLQueryPlan
/*    */   implements Serializable
/*    */ {
/*    */   private final String collectionRole;
/*    */   
/*    */   public FilterQueryPlan(String hql, String collectionRole, boolean shallow, Map enabledFilters, SessionFactoryImplementor factory)
/*    */   {
/* 24 */     super(hql, collectionRole, shallow, enabledFilters, factory);
/* 25 */     this.collectionRole = collectionRole;
/*    */   }
/*    */   
/*    */   public String getCollectionRole() {
/* 29 */     return this.collectionRole;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\query\FilterQueryPlan.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */