/*    */ package org.hibernate.engine.query;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ public class OrdinalParameterDescriptor
/*    */   implements Serializable
/*    */ {
/*    */   private final int ordinalPosition;
/*    */   private final Type expectedType;
/*    */   private final int sourceLocation;
/*    */   
/*    */   public OrdinalParameterDescriptor(int ordinalPosition, Type expectedType, int sourceLocation)
/*    */   {
/* 16 */     this.ordinalPosition = ordinalPosition;
/* 17 */     this.expectedType = expectedType;
/* 18 */     this.sourceLocation = sourceLocation;
/*    */   }
/*    */   
/*    */   public int getOrdinalPosition() {
/* 22 */     return this.ordinalPosition;
/*    */   }
/*    */   
/*    */   public Type getExpectedType() {
/* 26 */     return this.expectedType;
/*    */   }
/*    */   
/*    */   public int getSourceLocation() {
/* 30 */     return this.sourceLocation;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\query\OrdinalParameterDescriptor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */