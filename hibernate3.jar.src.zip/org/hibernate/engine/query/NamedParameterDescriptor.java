/*    */ package org.hibernate.engine.query;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ public class NamedParameterDescriptor
/*    */   implements Serializable
/*    */ {
/*    */   private final String name;
/*    */   private final Type expectedType;
/*    */   private final int[] sourceLocations;
/*    */   
/*    */   public NamedParameterDescriptor(String name, Type expectedType, int[] sourceLocations)
/*    */   {
/* 16 */     this.name = name;
/* 17 */     this.expectedType = expectedType;
/* 18 */     this.sourceLocations = sourceLocations;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 22 */     return this.name;
/*    */   }
/*    */   
/*    */   public Type getExpectedType() {
/* 26 */     return this.expectedType;
/*    */   }
/*    */   
/*    */   public int[] getSourceLocations() {
/* 30 */     return this.sourceLocations;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\query\NamedParameterDescriptor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */