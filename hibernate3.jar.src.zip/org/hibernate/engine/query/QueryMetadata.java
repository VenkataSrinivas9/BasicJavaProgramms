/*    */ package org.hibernate.engine.query;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Set;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QueryMetadata
/*    */   implements Serializable
/*    */ {
/*    */   private final String sourceQuery;
/*    */   private final ParameterMetadata parameterMetadata;
/*    */   private final String[] returnAliases;
/*    */   private final Type[] returnTypes;
/*    */   private final Set querySpaces;
/*    */   
/*    */   public QueryMetadata(String sourceQuery, ParameterMetadata parameterMetadata, String[] returnAliases, Type[] returnTypes, Set querySpaces)
/*    */   {
/* 26 */     this.sourceQuery = sourceQuery;
/* 27 */     this.parameterMetadata = parameterMetadata;
/* 28 */     this.returnAliases = returnAliases;
/* 29 */     this.returnTypes = returnTypes;
/* 30 */     this.querySpaces = querySpaces;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getSourceQuery()
/*    */   {
/* 39 */     return this.sourceQuery;
/*    */   }
/*    */   
/*    */   public ParameterMetadata getParameterMetadata() {
/* 43 */     return this.parameterMetadata;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String[] getReturnAliases()
/*    */   {
/* 52 */     return this.returnAliases;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Type[] getReturnTypes()
/*    */   {
/* 61 */     return this.returnTypes;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Set getQuerySpaces()
/*    */   {
/* 70 */     return this.querySpaces;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\query\QueryMetadata.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */