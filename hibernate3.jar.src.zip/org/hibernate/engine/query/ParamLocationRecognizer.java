/*    */ package org.hibernate.engine.query;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParamLocationRecognizer
/*    */   implements ParameterParser.Recognizer
/*    */ {
/* 15 */   private Map namedParameterLocationMap = new HashMap();
/* 16 */   private List ordinalParameterLocationList = new ArrayList();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static ParamLocationRecognizer parseLocations(String query)
/*    */   {
/* 26 */     ParamLocationRecognizer recognizer = new ParamLocationRecognizer();
/* 27 */     ParameterParser.parse(query, recognizer);
/* 28 */     return recognizer;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Map getNamedParameterLocationMap()
/*    */   {
/* 38 */     return this.namedParameterLocationMap;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public List getOrdinalParameterLocationList()
/*    */   {
/* 50 */     return this.ordinalParameterLocationList;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void ordinalParameter(int position)
/*    */   {
/* 57 */     this.ordinalParameterLocationList.add(new Integer(position));
/*    */   }
/*    */   
/*    */   public void namedParameter(String name, int position) {
/* 61 */     List locations = (List)this.namedParameterLocationMap.get(name);
/* 62 */     if (locations == null) {
/* 63 */       locations = new ArrayList();
/* 64 */       this.namedParameterLocationMap.put(name, locations);
/*    */     }
/* 66 */     locations.add(new Integer(position));
/*    */   }
/*    */   
/*    */   public void ejb3PositionalParameter(String name, int position) {
/* 70 */     namedParameter(name, position);
/*    */   }
/*    */   
/*    */   public void other(char character) {}
/*    */   
/*    */   public void outParameter(int position) {}
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\query\ParamLocationRecognizer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */