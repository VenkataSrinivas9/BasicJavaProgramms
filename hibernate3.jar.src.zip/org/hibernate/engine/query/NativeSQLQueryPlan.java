/*    */ package org.hibernate.engine.query;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.loader.custom.SQLCustomQuery;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NativeSQLQueryPlan
/*    */   implements Serializable
/*    */ {
/*    */   private final String sourceQuery;
/*    */   private final SQLCustomQuery customQuery;
/*    */   
/*    */   public NativeSQLQueryPlan(NativeSQLQuerySpecification specification, SessionFactoryImplementor factory)
/*    */   {
/* 19 */     this.sourceQuery = specification.getQueryString();
/*    */     
/* 21 */     this.customQuery = new SQLCustomQuery(specification.getSqlQueryReturns(), specification.getSqlQueryScalarReturns(), specification.getQueryString(), specification.getQuerySpaces(), factory);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getSourceQuery()
/*    */   {
/* 31 */     return this.sourceQuery;
/*    */   }
/*    */   
/*    */   public SQLCustomQuery getCustomQuery() {
/* 35 */     return this.customQuery;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\query\NativeSQLQueryPlan.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */