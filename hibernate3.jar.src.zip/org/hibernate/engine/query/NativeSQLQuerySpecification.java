/*    */ package org.hibernate.engine.query;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.hibernate.loader.custom.SQLQueryReturn;
/*    */ import org.hibernate.loader.custom.SQLQueryScalarReturn;
/*    */ import org.hibernate.util.ArrayHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NativeSQLQuerySpecification
/*    */ {
/*    */   private final String queryString;
/*    */   private final SQLQueryReturn[] sqlQueryReturns;
/*    */   private final SQLQueryScalarReturn[] sqlQueryScalarReturns;
/*    */   private final Set querySpaces;
/*    */   private final int hashCode;
/*    */   
/*    */   public NativeSQLQuerySpecification(String queryString, SQLQueryReturn[] sqlQueryReturns, SQLQueryScalarReturn[] sqlQueryScalarReturns, Collection querySpaces)
/*    */   {
/* 33 */     this.queryString = queryString;
/* 34 */     this.sqlQueryReturns = sqlQueryReturns;
/* 35 */     this.sqlQueryScalarReturns = sqlQueryScalarReturns;
/* 36 */     if (querySpaces == null) {
/* 37 */       this.querySpaces = Collections.EMPTY_SET;
/*    */     }
/*    */     else {
/* 40 */       Set tmp = new HashSet();
/* 41 */       tmp.addAll(querySpaces);
/* 42 */       this.querySpaces = Collections.unmodifiableSet(tmp);
/*    */     }
/*    */     
/*    */ 
/* 46 */     int hashCode = queryString.hashCode();
/* 47 */     hashCode = 29 * hashCode + this.querySpaces.hashCode();
/* 48 */     if (this.sqlQueryReturns != null) {
/* 49 */       hashCode = 29 * hashCode + ArrayHelper.toList(this.sqlQueryReturns).hashCode();
/*    */     }
/* 51 */     if (this.sqlQueryScalarReturns != null) {
/* 52 */       hashCode = 29 * hashCode + ArrayHelper.toList(this.sqlQueryScalarReturns).hashCode();
/*    */     }
/* 54 */     this.hashCode = hashCode;
/*    */   }
/*    */   
/*    */   public String getQueryString() {
/* 58 */     return this.queryString;
/*    */   }
/*    */   
/*    */   public SQLQueryReturn[] getSqlQueryReturns() {
/* 62 */     return this.sqlQueryReturns;
/*    */   }
/*    */   
/*    */   public SQLQueryScalarReturn[] getSqlQueryScalarReturns() {
/* 66 */     return this.sqlQueryScalarReturns;
/*    */   }
/*    */   
/*    */   public Set getQuerySpaces() {
/* 70 */     return this.querySpaces;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o) {
/* 74 */     if (this == o) {
/* 75 */       return true;
/*    */     }
/* 77 */     if ((o == null) || (getClass() != o.getClass())) {
/* 78 */       return false;
/*    */     }
/*    */     
/* 81 */     NativeSQLQuerySpecification that = (NativeSQLQuerySpecification)o;
/*    */     
/* 83 */     return (this.querySpaces.equals(that.querySpaces)) && (this.queryString.equals(that.queryString)) && (Arrays.equals(this.sqlQueryReturns, that.sqlQueryReturns)) && (Arrays.equals(this.sqlQueryScalarReturns, that.sqlQueryScalarReturns));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 91 */     return this.hashCode;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\query\NativeSQLQuerySpecification.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */