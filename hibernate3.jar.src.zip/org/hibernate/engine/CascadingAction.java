/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.LockMode;
/*     */ import org.hibernate.ReplicationMode;
/*     */ import org.hibernate.collection.PersistentCollection;
/*     */ import org.hibernate.event.EventSource;
/*     */ import org.hibernate.type.CollectionType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CascadingAction
/*     */ {
/*  23 */   private static final Log log = LogFactory.getLog(CascadingAction.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  42 */   public static final CascadingAction DELETE = new CascadingAction()
/*     */   {
/*     */     public void cascade(EventSource session, Object child, String entityName, Object anything, boolean isCascadeDeleteEnabled) throws HibernateException {
/*  45 */       if (CascadingAction.log.isTraceEnabled()) CascadingAction.log.trace("cascading to delete: " + entityName);
/*  46 */       if (ForeignKeys.isNotTransient(entityName, child, null, session)) {
/*  47 */         session.delete(entityName, child, isCascadeDeleteEnabled);
/*     */       }
/*     */     }
/*     */     
/*     */     public Iterator getCascadableChildrenIterator(EventSource session, CollectionType collectionType, Object collection) {
/*  52 */       return CascadingAction.getAllElementsIterator(session, collectionType, collection);
/*     */     }
/*     */     
/*     */     public boolean deleteOrphans() {
/*  56 */       return true;
/*     */     }
/*     */     
/*  59 */     public String toString() { return "ACTION_DELETE"; }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */   public static final CascadingAction LOCK = new CascadingAction()
/*     */   {
/*     */     public void cascade(EventSource session, Object child, String entityName, Object anything, boolean isCascadeDeleteEnabled) throws HibernateException {
/*  69 */       if (CascadingAction.log.isTraceEnabled()) CascadingAction.log.trace("cascading to lock: " + entityName);
/*  70 */       session.lock(entityName, child, LockMode.NONE);
/*     */     }
/*     */     
/*     */     public Iterator getCascadableChildrenIterator(EventSource session, CollectionType collectionType, Object collection) {
/*  74 */       return getLoadedElementsIterator(session, collectionType, collection);
/*     */     }
/*     */     
/*     */     public boolean deleteOrphans() {
/*  78 */       return false;
/*     */     }
/*     */     
/*  81 */     public String toString() { return "ACTION_LOCK"; }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  88 */   public static final CascadingAction REFRESH = new CascadingAction()
/*     */   {
/*     */     public void cascade(EventSource session, Object child, String entityName, Object anything, boolean isCascadeDeleteEnabled) throws HibernateException {
/*  91 */       if (CascadingAction.log.isTraceEnabled()) CascadingAction.log.trace("cascading to refresh: " + entityName);
/*  92 */       session.refresh(child, (Map)anything);
/*     */     }
/*     */     
/*     */     public Iterator getCascadableChildrenIterator(EventSource session, CollectionType collectionType, Object collection) {
/*  96 */       return getLoadedElementsIterator(session, collectionType, collection);
/*     */     }
/*     */     
/*  99 */     public boolean deleteOrphans() { return false; }
/*     */     
/*     */     public String toString() {
/* 102 */       return "ACTION_REFRESH";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 109 */   public static final CascadingAction EVICT = new CascadingAction()
/*     */   {
/*     */     public void cascade(EventSource session, Object child, String entityName, Object anything, boolean isCascadeDeleteEnabled) throws HibernateException {
/* 112 */       if (CascadingAction.log.isTraceEnabled()) CascadingAction.log.trace("cascading to evict: " + entityName);
/* 113 */       session.evict(child);
/*     */     }
/*     */     
/*     */     public Iterator getCascadableChildrenIterator(EventSource session, CollectionType collectionType, Object collection) {
/* 117 */       return getLoadedElementsIterator(session, collectionType, collection);
/*     */     }
/*     */     
/* 120 */     public boolean deleteOrphans() { return false; }
/*     */     
/*     */     public String toString() {
/* 123 */       return "ACTION_EVICT";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 130 */   public static final CascadingAction SAVE_UPDATE = new CascadingAction()
/*     */   {
/*     */     public void cascade(EventSource session, Object child, String entityName, Object anything, boolean isCascadeDeleteEnabled) throws HibernateException {
/* 133 */       if (CascadingAction.log.isTraceEnabled()) CascadingAction.log.trace("cascading to saveOrUpdate: " + entityName);
/* 134 */       session.saveOrUpdate(entityName, child);
/*     */     }
/*     */     
/*     */     public Iterator getCascadableChildrenIterator(EventSource session, CollectionType collectionType, Object collection) {
/* 138 */       return getLoadedElementsIterator(session, collectionType, collection);
/*     */     }
/*     */     
/*     */     public boolean deleteOrphans() {
/* 142 */       return true;
/*     */     }
/*     */     
/* 145 */     public String toString() { return "ACTION_SAVE_UPDATE"; }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 152 */   public static final CascadingAction MERGE = new CascadingAction()
/*     */   {
/*     */     public void cascade(EventSource session, Object child, String entityName, Object anything, boolean isCascadeDeleteEnabled) throws HibernateException {
/* 155 */       if (CascadingAction.log.isTraceEnabled()) CascadingAction.log.trace("cascading to merge: " + entityName);
/* 156 */       session.merge(entityName, child, (Map)anything);
/*     */     }
/*     */     
/*     */     public Iterator getCascadableChildrenIterator(EventSource session, CollectionType collectionType, Object collection)
/*     */     {
/* 161 */       return getLoadedElementsIterator(session, collectionType, collection);
/*     */     }
/*     */     
/*     */     public boolean deleteOrphans() {
/* 165 */       return false;
/*     */     }
/*     */     
/* 168 */     public String toString() { return "ACTION_MERGE"; }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 175 */   public static final CascadingAction SAVE_UPDATE_COPY = new CascadingAction()
/*     */   {
/*     */     public void cascade(EventSource session, Object child, String entityName, Object anything, boolean isCascadeDeleteEnabled) throws HibernateException
/*     */     {
/* 179 */       if (CascadingAction.log.isTraceEnabled()) CascadingAction.log.trace("cascading to saveOrUpdateCopy: " + entityName);
/* 180 */       session.saveOrUpdateCopy(entityName, child, (Map)anything);
/*     */     }
/*     */     
/*     */     public Iterator getCascadableChildrenIterator(EventSource session, CollectionType collectionType, Object collection) {
/* 184 */       return getLoadedElementsIterator(session, collectionType, collection);
/*     */     }
/*     */     
/*     */     public boolean deleteOrphans() {
/* 188 */       return false;
/*     */     }
/*     */     
/* 191 */     public String toString() { return "ACTION_SAVE_UPDATE_COPY"; }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 198 */   public static final CascadingAction PERSIST = new CascadingAction()
/*     */   {
/*     */     public void cascade(EventSource session, Object child, String entityName, Object anything, boolean isCascadeDeleteEnabled) throws HibernateException {
/* 201 */       if (CascadingAction.log.isTraceEnabled()) CascadingAction.log.trace("cascading to persist: " + entityName);
/* 202 */       session.persist(entityName, child, (Map)anything);
/*     */     }
/*     */     
/*     */     public Iterator getCascadableChildrenIterator(EventSource session, CollectionType collectionType, Object collection) {
/* 206 */       return CascadingAction.getAllElementsIterator(session, collectionType, collection);
/*     */     }
/*     */     
/* 209 */     public boolean deleteOrphans() { return false; }
/*     */     
/*     */     public String toString() {
/* 212 */       return "ACTION_PERSIST";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 221 */   public static final CascadingAction PERSIST_ON_FLUSH = new CascadingAction()
/*     */   {
/*     */     public void cascade(EventSource session, Object child, String entityName, Object anything, boolean isCascadeDeleteEnabled) throws HibernateException {
/* 224 */       if (CascadingAction.log.isTraceEnabled()) CascadingAction.log.trace("cascading to persistOnFlush: " + entityName);
/* 225 */       session.persistOnFlush(entityName, child, (Map)anything);
/*     */     }
/*     */     
/*     */     public Iterator getCascadableChildrenIterator(EventSource session, CollectionType collectionType, Object collection) {
/* 229 */       return CascadingAction.getLoadedElementsIterator(session, collectionType, collection);
/*     */     }
/*     */     
/* 232 */     public boolean deleteOrphans() { return true; }
/*     */     
/*     */     public String toString() {
/* 235 */       return "ACTION_PERSIST_ON_FLUSH";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 242 */   public static final CascadingAction REPLICATE = new CascadingAction()
/*     */   {
/*     */     public void cascade(EventSource session, Object child, String entityName, Object anything, boolean isCascadeDeleteEnabled) throws HibernateException {
/* 245 */       if (CascadingAction.log.isTraceEnabled()) CascadingAction.log.trace("cascading to replicate: " + entityName);
/* 246 */       session.replicate(entityName, child, (ReplicationMode)anything);
/*     */     }
/*     */     
/*     */     public Iterator getCascadableChildrenIterator(EventSource session, CollectionType collectionType, Object collection) {
/* 250 */       return getLoadedElementsIterator(session, collectionType, collection);
/*     */     }
/*     */     
/* 253 */     public boolean deleteOrphans() { return false; }
/*     */     
/*     */     public String toString() {
/* 256 */       return "ACTION_REPLICATE";
/*     */     }
/*     */   };
/*     */   
/*     */   public abstract void cascade(EventSource paramEventSource, Object paramObject1, String paramString, Object paramObject2, boolean paramBoolean) throws HibernateException;
/*     */   
/*     */   public abstract Iterator getCascadableChildrenIterator(EventSource paramEventSource, CollectionType paramCollectionType, Object paramObject);
/*     */   
/*     */   public abstract boolean deleteOrphans();
/*     */   
/* 266 */   private static Iterator getAllElementsIterator(EventSource session, CollectionType collectionType, Object collection) { return collectionType.getElementsIterator(collection, session); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Iterator getLoadedElementsIterator(SessionImplementor session, CollectionType collectionType, Object collection)
/*     */   {
/* 273 */     if (collectionIsInitialized(collection))
/*     */     {
/* 275 */       return collectionType.getElementsIterator(collection, session);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 280 */     return ((PersistentCollection)collection).queuedAdditionIterator();
/*     */   }
/*     */   
/*     */   private static boolean collectionIsInitialized(Object collection)
/*     */   {
/* 285 */     return (!(collection instanceof PersistentCollection)) || (((PersistentCollection)collection).wasInitialized());
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\CascadingAction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */