/*    */ package org.hibernate.engine;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FilterDefinition
/*    */ {
/*    */   private final String filterName;
/*    */   private final String defaultFilterCondition;
/* 19 */   private final Map parameterTypes = new HashMap();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public FilterDefinition(String name, String defaultCondition, Map parameterTypes)
/*    */   {
/* 27 */     this.filterName = name;
/* 28 */     this.defaultFilterCondition = defaultCondition;
/* 29 */     this.parameterTypes.putAll(parameterTypes);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getFilterName()
/*    */   {
/* 38 */     return this.filterName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Set getParameterNames()
/*    */   {
/* 47 */     return this.parameterTypes.keySet();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Type getParameterType(String parameterName)
/*    */   {
/* 57 */     return (Type)this.parameterTypes.get(parameterName);
/*    */   }
/*    */   
/*    */   public String getDefaultFilterCondition() {
/* 61 */     return this.defaultFilterCondition;
/*    */   }
/*    */   
/*    */   public Map getParameterTypes() {
/* 65 */     return this.parameterTypes;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\FilterDefinition.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */