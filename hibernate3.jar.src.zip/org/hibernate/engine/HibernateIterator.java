package org.hibernate.engine;

import java.util.Iterator;
import org.hibernate.JDBCException;

public abstract interface HibernateIterator
  extends Iterator
{
  public abstract void close()
    throws JDBCException;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\HibernateIterator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */