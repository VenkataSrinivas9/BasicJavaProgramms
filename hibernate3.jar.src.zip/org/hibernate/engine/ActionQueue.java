/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.action.BulkOperationCleanupAction;
/*     */ import org.hibernate.action.CollectionRecreateAction;
/*     */ import org.hibernate.action.CollectionRemoveAction;
/*     */ import org.hibernate.action.CollectionUpdateAction;
/*     */ import org.hibernate.action.EntityDeleteAction;
/*     */ import org.hibernate.action.EntityIdentityInsertAction;
/*     */ import org.hibernate.action.EntityInsertAction;
/*     */ import org.hibernate.action.EntityUpdateAction;
/*     */ import org.hibernate.action.Executable;
/*     */ import org.hibernate.cache.CacheException;
/*     */ import org.hibernate.cache.UpdateTimestampsCache;
/*     */ import org.hibernate.cfg.Settings;
/*     */ import org.hibernate.jdbc.Batcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActionQueue
/*     */   implements Serializable
/*     */ {
/*  37 */   private static final Log log = LogFactory.getLog(ActionQueue.class);
/*     */   
/*     */ 
/*     */   private static final int INIT_QUEUE_LIST_SIZE = 5;
/*     */   
/*     */ 
/*     */   private SessionImplementor session;
/*     */   
/*     */ 
/*     */   private ArrayList insertions;
/*     */   
/*     */ 
/*     */   private ArrayList deletions;
/*     */   
/*     */   private ArrayList updates;
/*     */   
/*     */   private ArrayList collectionCreations;
/*     */   
/*     */   private ArrayList collectionUpdates;
/*     */   
/*     */   private ArrayList collectionRemovals;
/*     */   
/*     */   private transient ArrayList executions;
/*     */   
/*     */ 
/*     */   public ActionQueue(SessionImplementor session)
/*     */   {
/*  64 */     this.session = session;
/*     */     
/*  66 */     this.insertions = new ArrayList(5);
/*  67 */     this.deletions = new ArrayList(5);
/*  68 */     this.updates = new ArrayList(5);
/*     */     
/*  70 */     this.collectionCreations = new ArrayList(5);
/*  71 */     this.collectionRemovals = new ArrayList(5);
/*  72 */     this.collectionUpdates = new ArrayList(5);
/*     */     
/*  74 */     this.executions = new ArrayList(15);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/*  78 */     ois.defaultReadObject();
/*  79 */     this.executions = new ArrayList(15);
/*     */   }
/*     */   
/*     */   public void clear() {
/*  83 */     this.updates.clear();
/*  84 */     this.insertions.clear();
/*  85 */     this.deletions.clear();
/*     */     
/*  87 */     this.collectionCreations.clear();
/*  88 */     this.collectionRemovals.clear();
/*  89 */     this.collectionUpdates.clear();
/*     */   }
/*     */   
/*     */   public void addAction(EntityInsertAction action) {
/*  93 */     this.insertions.add(action);
/*     */   }
/*     */   
/*     */   public void addAction(EntityDeleteAction action) {
/*  97 */     this.deletions.add(action);
/*     */   }
/*     */   
/*     */   public void addAction(EntityUpdateAction action) {
/* 101 */     this.updates.add(action);
/*     */   }
/*     */   
/*     */   public void addAction(CollectionRecreateAction action) {
/* 105 */     this.collectionCreations.add(action);
/*     */   }
/*     */   
/*     */   public void addAction(CollectionRemoveAction action) {
/* 109 */     this.collectionRemovals.add(action);
/*     */   }
/*     */   
/*     */   public void addAction(CollectionUpdateAction action) {
/* 113 */     this.collectionUpdates.add(action);
/*     */   }
/*     */   
/*     */   public void addAction(EntityIdentityInsertAction insert) {
/* 117 */     this.insertions.add(insert);
/*     */   }
/*     */   
/*     */   public void addAction(BulkOperationCleanupAction cleanupAction)
/*     */   {
/* 122 */     this.executions.add(cleanupAction);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeInserts()
/*     */     throws HibernateException
/*     */   {
/* 131 */     executeActions(this.insertions);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeActions()
/*     */     throws HibernateException
/*     */   {
/* 140 */     executeActions(this.insertions);
/* 141 */     executeActions(this.updates);
/* 142 */     executeActions(this.collectionRemovals);
/* 143 */     executeActions(this.collectionUpdates);
/* 144 */     executeActions(this.collectionCreations);
/* 145 */     executeActions(this.deletions);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prepareActions()
/*     */     throws HibernateException
/*     */   {
/* 154 */     prepareActions(this.collectionRemovals);
/* 155 */     prepareActions(this.collectionUpdates);
/* 156 */     prepareActions(this.collectionCreations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterTransactionCompletion(boolean success)
/*     */   {
/* 165 */     int size = this.executions.size();
/* 166 */     boolean invalidateQueryCache = this.session.getFactory().getSettings().isQueryCacheEnabled();
/* 167 */     for (int i = 0; i < size; i++) {
/*     */       try {
/* 169 */         Executable exec = (Executable)this.executions.get(i);
/*     */         try {
/* 171 */           exec.afterTransactionCompletion(success);
/*     */         }
/*     */         finally {
/* 174 */           if (invalidateQueryCache) {
/* 175 */             this.session.getFactory().getUpdateTimestampsCache().invalidate(exec.getPropertySpaces());
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (CacheException ce) {
/* 180 */         log.error("could not release a cache lock", ce);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 184 */         throw new AssertionFailure("Exception releasing cache locks", e);
/*     */       }
/*     */     }
/* 187 */     this.executions.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean areTablesToBeUpdated(Set tables)
/*     */   {
/* 198 */     return (areTablesToUpdated(this.updates, tables)) || (areTablesToUpdated(this.insertions, tables)) || (areTablesToUpdated(this.deletions, tables)) || (areTablesToUpdated(this.collectionUpdates, tables)) || (areTablesToUpdated(this.collectionCreations, tables)) || (areTablesToUpdated(this.collectionRemovals, tables));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean areInsertionsOrDeletionsQueued()
/*     */   {
/* 207 */     return (this.insertions.size() > 0) || (this.deletions.size() > 0);
/*     */   }
/*     */   
/*     */   private static boolean areTablesToUpdated(List executables, Set set) {
/* 211 */     int size = executables.size();
/* 212 */     for (int j = 0; j < size; j++) {
/* 213 */       Serializable[] spaces = ((Executable)executables.get(j)).getPropertySpaces();
/* 214 */       for (int i = 0; i < spaces.length; i++) {
/* 215 */         if (set.contains(spaces[i])) {
/* 216 */           if (log.isDebugEnabled()) log.debug("changes must be flushed to space: " + spaces[i]);
/* 217 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 221 */     return false;
/*     */   }
/*     */   
/*     */   private void executeActions(List list) throws HibernateException {
/* 225 */     int size = list.size();
/* 226 */     for (int i = 0; i < size; i++) {
/* 227 */       execute((Executable)list.get(i));
/*     */     }
/* 229 */     list.clear();
/* 230 */     this.session.getBatcher().executeBatch();
/*     */   }
/*     */   
/*     */   public void execute(Executable executable) {
/* 234 */     boolean lockQueryCache = this.session.getFactory().getSettings().isQueryCacheEnabled();
/* 235 */     if ((executable.hasAfterTransactionCompletion()) || (lockQueryCache)) {
/* 236 */       this.executions.add(executable);
/*     */     }
/* 238 */     if (lockQueryCache) {
/* 239 */       this.session.getFactory().getUpdateTimestampsCache().preinvalidate(executable.getPropertySpaces());
/*     */     }
/*     */     
/*     */ 
/* 243 */     executable.execute();
/*     */   }
/*     */   
/*     */   private void prepareActions(List queue) throws HibernateException {
/* 247 */     int size = queue.size();
/* 248 */     for (int i = 0; i < size; i++) {
/* 249 */       Executable executable = (Executable)queue.get(i);
/* 250 */       executable.beforeExecutions();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 260 */     return "ActionQueue[insertions=" + this.insertions + " updates=" + this.updates + " deletions=" + this.deletions + " collectionCreations=" + this.collectionCreations + " collectionRemovals=" + this.collectionRemovals + " collectionUpdates=" + this.collectionUpdates + "]";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int numberOfCollectionRemovals()
/*     */   {
/* 272 */     return this.collectionRemovals.size();
/*     */   }
/*     */   
/*     */   public int numberOfCollectionUpdates() {
/* 276 */     return this.collectionUpdates.size();
/*     */   }
/*     */   
/*     */   public int numberOfCollectionCreations() {
/* 280 */     return this.collectionCreations.size();
/*     */   }
/*     */   
/*     */   public int numberOfDeletions() {
/* 284 */     return this.deletions.size();
/*     */   }
/*     */   
/*     */   public int numberOfUpdates() {
/* 288 */     return this.updates.size();
/*     */   }
/*     */   
/*     */   public int numberOfInsertions() {
/* 292 */     return this.insertions.size();
/*     */   }
/*     */   
/*     */   public void sortCollectionActions() {
/* 296 */     if (this.session.getFactory().getSettings().isOrderUpdatesEnabled())
/*     */     {
/* 298 */       Collections.sort(this.collectionCreations);
/* 299 */       Collections.sort(this.collectionUpdates);
/* 300 */       Collections.sort(this.collectionRemovals);
/*     */     }
/*     */   }
/*     */   
/*     */   public void sortUpdateActions() {
/* 305 */     if (this.session.getFactory().getSettings().isOrderUpdatesEnabled())
/*     */     {
/* 307 */       Collections.sort(this.updates);
/*     */     }
/*     */   }
/*     */   
/*     */   public ArrayList cloneDeletions() {
/* 312 */     return (ArrayList)this.deletions.clone();
/*     */   }
/*     */   
/*     */   public void clearFromFlushNeededCheck(int previousCollectionRemovalSize) {
/* 316 */     this.collectionCreations.clear();
/* 317 */     this.collectionUpdates.clear();
/* 318 */     this.updates.clear();
/*     */     
/*     */ 
/* 321 */     for (int i = this.collectionRemovals.size() - 1; i >= previousCollectionRemovalSize; i--) {
/* 322 */       this.collectionRemovals.remove(i);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean hasAnyQueuedActions() {
/* 327 */     return (this.updates.size() > 0) || (this.insertions.size() > 0) || (this.deletions.size() > 0) || (this.collectionUpdates.size() > 0) || (this.collectionRemovals.size() > 0) || (this.collectionCreations.size() > 0);
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\ActionQueue.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */