/*    */ package org.hibernate.engine;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.EntityMode;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TypedValue
/*    */   implements Serializable
/*    */ {
/*    */   private final Type type;
/*    */   private final Object value;
/*    */   private final EntityMode entityMode;
/*    */   
/*    */   public TypedValue(Type type, Object value, EntityMode entityMode)
/*    */   {
/* 21 */     this.type = type;
/* 22 */     this.value = value;
/* 23 */     this.entityMode = entityMode;
/*    */   }
/*    */   
/*    */   public Object getValue() {
/* 27 */     return this.value;
/*    */   }
/*    */   
/*    */   public Type getType() {
/* 31 */     return this.type;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 35 */     return this.value == null ? "null" : this.value.toString();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 43 */     return this.value == null ? 0 : this.type.getHashCode(this.value, this.entityMode);
/*    */   }
/*    */   
/*    */   public boolean equals(Object other) {
/* 47 */     if (!(other instanceof TypedValue)) return false;
/* 48 */     TypedValue that = (TypedValue)other;
/*    */     
/*    */ 
/* 51 */     return (this.type.getReturnedClass() == that.type.getReturnedClass()) && (this.type.isEqual(that.value, this.value, this.entityMode));
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\TypedValue.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */