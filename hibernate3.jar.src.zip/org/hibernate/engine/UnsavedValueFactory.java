/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Constructor;
/*     */ import org.hibernate.InstantiationException;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.property.Getter;
/*     */ import org.hibernate.type.IdentifierType;
/*     */ import org.hibernate.type.PrimitiveType;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.type.VersionType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnsavedValueFactory
/*     */ {
/*     */   private static Object instantiate(Constructor constructor)
/*     */   {
/*     */     try
/*     */     {
/*  22 */       return constructor.newInstance(null);
/*     */     }
/*     */     catch (Exception e) {
/*  25 */       throw new InstantiationException("could not instantiate test object", constructor.getDeclaringClass(), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IdentifierValue getUnsavedIdentifierValue(String unsavedValue, Getter identifierGetter, Type identifierType, Constructor constructor)
/*     */   {
/*  41 */     if (unsavedValue == null) {
/*  42 */       if ((identifierGetter != null) && (constructor != null))
/*     */       {
/*  44 */         Serializable defaultValue = (Serializable)identifierGetter.get(instantiate(constructor));
/*  45 */         return new IdentifierValue(defaultValue);
/*     */       }
/*  47 */       if ((identifierGetter != null) && ((identifierType instanceof PrimitiveType))) {
/*  48 */         Serializable defaultValue = ((PrimitiveType)identifierType).getDefaultValue();
/*  49 */         return new IdentifierValue(defaultValue);
/*     */       }
/*     */       
/*  52 */       return IdentifierValue.NULL;
/*     */     }
/*     */     
/*  55 */     if ("null".equals(unsavedValue)) {
/*  56 */       return IdentifierValue.NULL;
/*     */     }
/*  58 */     if ("undefined".equals(unsavedValue)) {
/*  59 */       return IdentifierValue.UNDEFINED;
/*     */     }
/*  61 */     if ("none".equals(unsavedValue)) {
/*  62 */       return IdentifierValue.NONE;
/*     */     }
/*  64 */     if ("any".equals(unsavedValue)) {
/*  65 */       return IdentifierValue.ANY;
/*     */     }
/*     */     try
/*     */     {
/*  69 */       return new IdentifierValue((Serializable)((IdentifierType)identifierType).stringToObject(unsavedValue));
/*     */     }
/*     */     catch (ClassCastException cce) {
/*  72 */       throw new MappingException("Bad identifier type: " + identifierType.getName());
/*     */     }
/*     */     catch (Exception e) {
/*  75 */       throw new MappingException("Could not parse identifier unsaved-value: " + unsavedValue);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static VersionValue getUnsavedVersionValue(String versionUnsavedValue, Getter versionGetter, VersionType versionType, Constructor constructor)
/*     */   {
/*  86 */     if (versionUnsavedValue == null) {
/*  87 */       if (constructor != null) {
/*  88 */         Object defaultValue = versionGetter.get(instantiate(constructor));
/*     */         
/*     */ 
/*  91 */         return versionType.isEqual(versionType.seed(null), defaultValue) ? VersionValue.UNDEFINED : new VersionValue(defaultValue);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*  96 */       return VersionValue.UNDEFINED;
/*     */     }
/*     */     
/*  99 */     if ("undefined".equals(versionUnsavedValue)) {
/* 100 */       return VersionValue.UNDEFINED;
/*     */     }
/* 102 */     if ("null".equals(versionUnsavedValue)) {
/* 103 */       return VersionValue.NULL;
/*     */     }
/* 105 */     if ("negative".equals(versionUnsavedValue)) {
/* 106 */       return VersionValue.NEGATIVE;
/*     */     }
/*     */     
/*     */ 
/* 110 */     throw new MappingException("Could not parse version unsaved-value: " + versionUnsavedValue);
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\UnsavedValueFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */