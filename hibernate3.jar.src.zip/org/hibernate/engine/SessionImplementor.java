package org.hibernate.engine;

import java.io.Serializable;
import java.sql.Connection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.hibernate.CacheMode;
import org.hibernate.EntityMode;
import org.hibernate.FlushMode;
import org.hibernate.HibernateException;
import org.hibernate.Interceptor;
import org.hibernate.Query;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Transaction;
import org.hibernate.collection.PersistentCollection;
import org.hibernate.engine.query.NativeSQLQuerySpecification;
import org.hibernate.event.EventListeners;
import org.hibernate.impl.CriteriaImpl;
import org.hibernate.jdbc.Batcher;
import org.hibernate.jdbc.JDBCContext;
import org.hibernate.loader.custom.CustomQuery;
import org.hibernate.persister.entity.EntityPersister;
import org.hibernate.type.Type;

public abstract interface SessionImplementor
  extends Serializable
{
  public abstract Interceptor getInterceptor();
  
  public abstract void setAutoClear(boolean paramBoolean);
  
  public abstract boolean isTransactionInProgress();
  
  public abstract void initializeCollection(PersistentCollection paramPersistentCollection, boolean paramBoolean)
    throws HibernateException;
  
  public abstract Object internalLoad(String paramString, Serializable paramSerializable, boolean paramBoolean1, boolean paramBoolean2)
    throws HibernateException;
  
  public abstract Object immediateLoad(String paramString, Serializable paramSerializable)
    throws HibernateException;
  
  public abstract long getTimestamp();
  
  public abstract SessionFactoryImplementor getFactory();
  
  public abstract Batcher getBatcher();
  
  public abstract List list(String paramString, QueryParameters paramQueryParameters)
    throws HibernateException;
  
  public abstract Iterator iterate(String paramString, QueryParameters paramQueryParameters)
    throws HibernateException;
  
  public abstract ScrollableResults scroll(String paramString, QueryParameters paramQueryParameters)
    throws HibernateException;
  
  public abstract ScrollableResults scroll(CriteriaImpl paramCriteriaImpl, ScrollMode paramScrollMode);
  
  public abstract List list(CriteriaImpl paramCriteriaImpl);
  
  public abstract List listFilter(Object paramObject, String paramString, QueryParameters paramQueryParameters)
    throws HibernateException;
  
  public abstract Iterator iterateFilter(Object paramObject, String paramString, QueryParameters paramQueryParameters)
    throws HibernateException;
  
  public abstract EntityPersister getEntityPersister(String paramString, Object paramObject)
    throws HibernateException;
  
  public abstract Object getEntityUsingInterceptor(EntityKey paramEntityKey)
    throws HibernateException;
  
  public abstract void afterTransactionCompletion(boolean paramBoolean, Transaction paramTransaction);
  
  public abstract void beforeTransactionCompletion(Transaction paramTransaction);
  
  public abstract Serializable getContextEntityIdentifier(Object paramObject);
  
  public abstract String bestGuessEntityName(Object paramObject);
  
  public abstract String guessEntityName(Object paramObject)
    throws HibernateException;
  
  public abstract Object instantiate(String paramString, Serializable paramSerializable)
    throws HibernateException;
  
  public abstract List listCustomQuery(CustomQuery paramCustomQuery, QueryParameters paramQueryParameters)
    throws HibernateException;
  
  public abstract ScrollableResults scrollCustomQuery(CustomQuery paramCustomQuery, QueryParameters paramQueryParameters)
    throws HibernateException;
  
  public abstract List list(NativeSQLQuerySpecification paramNativeSQLQuerySpecification, QueryParameters paramQueryParameters)
    throws HibernateException;
  
  public abstract ScrollableResults scroll(NativeSQLQuerySpecification paramNativeSQLQuerySpecification, QueryParameters paramQueryParameters)
    throws HibernateException;
  
  public abstract Object getFilterParameterValue(String paramString);
  
  public abstract Type getFilterParameterType(String paramString);
  
  public abstract Map getEnabledFilters();
  
  public abstract int getDontFlushFromFind();
  
  public abstract EventListeners getListeners();
  
  public abstract PersistenceContext getPersistenceContext();
  
  public abstract int executeUpdate(String paramString, QueryParameters paramQueryParameters)
    throws HibernateException;
  
  public abstract EntityMode getEntityMode();
  
  public abstract CacheMode getCacheMode();
  
  public abstract void setCacheMode(CacheMode paramCacheMode);
  
  public abstract boolean isOpen();
  
  public abstract boolean isConnected();
  
  public abstract FlushMode getFlushMode();
  
  public abstract void setFlushMode(FlushMode paramFlushMode);
  
  public abstract Connection connection();
  
  public abstract void flush();
  
  public abstract Query getNamedQuery(String paramString);
  
  public abstract Query getNamedSQLQuery(String paramString);
  
  public abstract boolean isEventSource();
  
  public abstract void afterScrollOperation();
  
  public abstract void setFetchProfile(String paramString);
  
  public abstract String getFetchProfile();
  
  public abstract JDBCContext getJDBCContext();
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\SessionImplementor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */