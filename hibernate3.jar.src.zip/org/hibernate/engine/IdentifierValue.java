/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IdentifierValue
/*     */ {
/*  37 */   private static final Log log = LogFactory.getLog(IdentifierValue.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Serializable value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  51 */   public static final IdentifierValue ANY = new IdentifierValue()
/*     */   {
/*     */     public final Boolean isUnsaved(Serializable id)
/*     */     {
/*  55 */       IdentifierValue.log.trace("id unsaved-value strategy ANY");
/*     */       
/*  57 */       return Boolean.TRUE;
/*     */     }
/*     */     
/*     */ 
/*     */     public Serializable getDefaultValue(Serializable currentValue)
/*     */     {
/*  63 */       return currentValue;
/*     */     }
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/*  69 */       return "SAVE_ANY";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */   public static final IdentifierValue NONE = new IdentifierValue()
/*     */   {
/*     */     public final Boolean isUnsaved(Serializable id)
/*     */     {
/*  87 */       IdentifierValue.log.trace("id unsaved-value strategy NONE");
/*     */       
/*  89 */       return Boolean.FALSE;
/*     */     }
/*     */     
/*     */ 
/*     */     public Serializable getDefaultValue(Serializable currentValue)
/*     */     {
/*  95 */       return currentValue;
/*     */     }
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/* 101 */       return "SAVE_NONE";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 117 */   public static final IdentifierValue NULL = new IdentifierValue()
/*     */   {
/*     */     public final Boolean isUnsaved(Serializable id)
/*     */     {
/* 121 */       IdentifierValue.log.trace("id unsaved-value strategy NULL");
/*     */       
/* 123 */       return id == null ? Boolean.TRUE : Boolean.FALSE;
/*     */     }
/*     */     
/*     */ 
/*     */     public Serializable getDefaultValue(Serializable currentValue)
/*     */     {
/* 129 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/* 135 */       return "SAVE_NULL";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 149 */   public static final IdentifierValue UNDEFINED = new IdentifierValue()
/*     */   {
/*     */     public final Boolean isUnsaved(Serializable id)
/*     */     {
/* 153 */       IdentifierValue.log.trace("id unsaved-value strategy UNDEFINED");
/*     */       
/* 155 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */     public Serializable getDefaultValue(Serializable currentValue)
/*     */     {
/* 161 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/* 167 */       return "UNDEFINED";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected IdentifierValue()
/*     */   {
/* 177 */     this.value = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IdentifierValue(Serializable value)
/*     */   {
/* 193 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean isUnsaved(Serializable id)
/*     */   {
/* 207 */     if (log.isTraceEnabled()) { log.trace("id unsaved-value: " + this.value);
/*     */     }
/* 209 */     return (id == null) || (id.equals(this.value)) ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Serializable getDefaultValue(Serializable currentValue)
/*     */   {
/* 217 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 225 */     return "identifier unsaved-value: " + this.value;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\IdentifierValue.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */