/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.CacheMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.LockMode;
/*     */ import org.hibernate.cache.CacheConcurrencyStrategy;
/*     */ import org.hibernate.cache.CacheKey;
/*     */ import org.hibernate.cache.entry.CacheEntry;
/*     */ import org.hibernate.cache.entry.CacheEntryStructure;
/*     */ import org.hibernate.cfg.Settings;
/*     */ import org.hibernate.event.EventListeners;
/*     */ import org.hibernate.event.PostLoadEvent;
/*     */ import org.hibernate.event.PostLoadEventListener;
/*     */ import org.hibernate.event.PreLoadEvent;
/*     */ import org.hibernate.event.PreLoadEventListener;
/*     */ import org.hibernate.intercept.LazyPropertyInitializer;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.pretty.MessageHelper;
/*     */ import org.hibernate.property.BackrefPropertyAccessor;
/*     */ import org.hibernate.stat.Statistics;
/*     */ import org.hibernate.stat.StatisticsImplementor;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.type.TypeFactory;
/*     */ import org.hibernate.type.VersionType;
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TwoPhaseLoad
/*     */ {
/*  34 */   private static final Log log = LogFactory.getLog(TwoPhaseLoad.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void postHydrate(EntityPersister persister, Serializable id, Object[] values, Object rowId, Object object, LockMode lockMode, boolean lazyPropertiesAreUnfetched, SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/*  56 */     Object version = Versioning.getVersion(values, persister);
/*  57 */     session.getPersistenceContext().addEntry(object, Status.LOADING, values, rowId, id, version, lockMode, true, persister, false, lazyPropertiesAreUnfetched);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  71 */     if ((log.isTraceEnabled()) && (version != null)) {
/*  72 */       log.trace("Version: " + version);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void initializeEntity(Object entity, boolean readOnly, SessionImplementor session, PreLoadEvent preLoadEvent, PostLoadEvent postLoadEvent)
/*     */     throws HibernateException
/*     */   {
/*  94 */     PersistenceContext persistenceContext = session.getPersistenceContext();
/*  95 */     EntityEntry entityEntry = persistenceContext.getEntry(entity);
/*  96 */     if (entityEntry == null) {
/*  97 */       throw new AssertionFailure("possible non-threadsafe access to the session");
/*     */     }
/*  99 */     EntityPersister persister = entityEntry.getPersister();
/* 100 */     Serializable id = entityEntry.getId();
/* 101 */     Object[] hydratedState = entityEntry.getLoadedState();
/*     */     
/* 103 */     if (log.isDebugEnabled()) {
/* 104 */       log.debug("resolving associations for " + MessageHelper.infoString(persister, id, session.getFactory()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 109 */     Type[] types = persister.getPropertyTypes();
/* 110 */     for (int i = 0; i < hydratedState.length; i++) {
/* 111 */       Object value = hydratedState[i];
/* 112 */       if ((value != LazyPropertyInitializer.UNFETCHED_PROPERTY) && (value != BackrefPropertyAccessor.UNKNOWN)) {
/* 113 */         hydratedState[i] = types[i].resolve(value, session, entity);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 118 */     if (session.isEventSource()) {
/* 119 */       preLoadEvent.setEntity(entity).setState(hydratedState).setId(id).setPersister(persister);
/* 120 */       PreLoadEventListener[] listeners = session.getListeners().getPreLoadEventListeners();
/* 121 */       for (int i = 0; i < listeners.length; i++) {
/* 122 */         listeners[i].onPreLoad(preLoadEvent);
/*     */       }
/*     */     }
/*     */     
/* 126 */     persister.setPropertyValues(entity, hydratedState, session.getEntityMode());
/*     */     
/* 128 */     SessionFactoryImplementor factory = session.getFactory();
/* 129 */     if ((persister.hasCache()) && (session.getCacheMode().isPutEnabled()))
/*     */     {
/* 131 */       if (log.isDebugEnabled()) {
/* 132 */         log.debug("adding entity to second-level cache: " + MessageHelper.infoString(persister, id, session.getFactory()));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 137 */       Object version = Versioning.getVersion(hydratedState, persister);
/* 138 */       CacheEntry entry = new CacheEntry(hydratedState, persister, entityEntry.isLoadedWithLazyPropertiesUnfetched(), version, session, entity);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 146 */       CacheKey cacheKey = new CacheKey(id, persister.getIdentifierType(), persister.getRootEntityName(), session.getEntityMode(), session.getFactory());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 153 */       boolean put = persister.getCache().put(cacheKey, persister.getCacheEntryStructure().structure(entry), session.getTimestamp(), version, persister.isVersioned() ? persister.getVersionType().getComparator() : null, useMinimalPuts(session, entityEntry));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 164 */       if ((put) && (factory.getStatistics().isStatisticsEnabled())) {
/* 165 */         factory.getStatisticsImplementor().secondLevelCachePut(persister.getCache().getRegionName());
/*     */       }
/*     */     }
/*     */     
/* 169 */     if ((readOnly) || (!persister.isMutable()))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 174 */       persistenceContext.setEntryStatus(entityEntry, Status.READ_ONLY);
/*     */     }
/*     */     else
/*     */     {
/* 178 */       TypeFactory.deepCopy(hydratedState, persister.getPropertyTypes(), persister.getPropertyUpdateability(), hydratedState, session);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 185 */       persistenceContext.setEntryStatus(entityEntry, Status.MANAGED);
/*     */     }
/*     */     
/* 188 */     persister.afterInitialize(entity, entityEntry.isLoadedWithLazyPropertiesUnfetched(), session);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 194 */     if (session.isEventSource()) {
/* 195 */       postLoadEvent.setEntity(entity).setId(id).setPersister(persister);
/* 196 */       PostLoadEventListener[] listeners = session.getListeners().getPostLoadEventListeners();
/* 197 */       for (int i = 0; i < listeners.length; i++) {
/* 198 */         listeners[i].onPostLoad(postLoadEvent);
/*     */       }
/*     */     }
/*     */     
/* 202 */     if (log.isDebugEnabled()) {
/* 203 */       log.debug("done materializing entity " + MessageHelper.infoString(persister, id, session.getFactory()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 208 */     if (factory.getStatistics().isStatisticsEnabled()) {
/* 209 */       factory.getStatisticsImplementor().loadEntity(persister.getEntityName());
/*     */     }
/*     */   }
/*     */   
/*     */   private static boolean useMinimalPuts(SessionImplementor session, EntityEntry entityEntry)
/*     */   {
/* 215 */     return ((session.getFactory().getSettings().isMinimalPutsEnabled()) && (session.getCacheMode() != CacheMode.REFRESH)) || ((entityEntry.getPersister().hasLazyProperties()) && (entityEntry.isLoadedWithLazyPropertiesUnfetched()) && (entityEntry.getPersister().isLazyPropertiesCacheable()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void addUninitializedEntity(EntityKey key, Object object, EntityPersister persister, LockMode lockMode, boolean lazyPropertiesAreUnfetched, SessionImplementor session)
/*     */   {
/* 237 */     session.getPersistenceContext().addEntity(object, Status.LOADING, null, key, null, lockMode, true, persister, false, lazyPropertiesAreUnfetched);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void addUninitializedCachedEntity(EntityKey key, Object object, EntityPersister persister, LockMode lockMode, boolean lazyPropertiesAreUnfetched, Object version, SessionImplementor session)
/*     */   {
/* 260 */     session.getPersistenceContext().addEntity(object, Status.LOADING, null, key, version, lockMode, true, persister, false, lazyPropertiesAreUnfetched);
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\TwoPhaseLoad.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */