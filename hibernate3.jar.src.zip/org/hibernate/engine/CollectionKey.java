/*    */ package org.hibernate.engine;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.EntityMode;
/*    */ import org.hibernate.persister.collection.CollectionPersister;
/*    */ import org.hibernate.pretty.MessageHelper;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CollectionKey
/*    */   implements Serializable
/*    */ {
/*    */   private final String role;
/*    */   private final Serializable key;
/*    */   private final Type keyType;
/*    */   private final SessionFactoryImplementor factory;
/*    */   private final int hashCode;
/*    */   private EntityMode entityMode;
/*    */   
/*    */   public CollectionKey(CollectionPersister persister, Serializable key, EntityMode em)
/*    */   {
/* 28 */     this.entityMode = em;
/* 29 */     this.role = persister.getRole();
/* 30 */     this.key = key;
/* 31 */     this.keyType = persister.getKeyType();
/* 32 */     this.factory = persister.getFactory();
/* 33 */     this.hashCode = getHashCode();
/*    */   }
/*    */   
/*    */   public boolean equals(Object other) {
/* 37 */     CollectionKey that = (CollectionKey)other;
/* 38 */     return (that.role.equals(this.role)) && (this.keyType.isEqual(that.key, this.key, this.entityMode, this.factory));
/*    */   }
/*    */   
/*    */   public int getHashCode()
/*    */   {
/* 43 */     int result = 17;
/* 44 */     result = 37 * result + this.role.hashCode();
/* 45 */     result = 37 * result + this.keyType.getHashCode(this.key, this.entityMode, this.factory);
/* 46 */     return result;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 50 */     return this.hashCode;
/*    */   }
/*    */   
/*    */   public String getRole() {
/* 54 */     return this.role;
/*    */   }
/*    */   
/*    */   public Serializable getKey() {
/* 58 */     return this.key;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 62 */     return "CollectionKey" + MessageHelper.collectionInfoString(this.factory.getCollectionPersister(this.role), this.key, this.factory);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\CollectionKey.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */