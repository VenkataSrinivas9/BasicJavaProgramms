/*    */ package org.hibernate.engine;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.hibernate.loader.custom.SQLQueryReturn;
/*    */ import org.hibernate.loader.custom.SQLQueryScalarReturn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResultSetMappingDefinition
/*    */   implements Serializable
/*    */ {
/* 18 */   private List entityQueryReturns = new ArrayList();
/*    */   
/* 20 */   private List scalarQueryReturns = new ArrayList();
/*    */   private String name;
/*    */   
/*    */   public String getName() {
/* 24 */     return this.name;
/*    */   }
/*    */   
/*    */   public ResultSetMappingDefinition(String name) {
/* 28 */     this.name = name;
/*    */   }
/*    */   
/*    */   public void addEntityQueryReturn(SQLQueryReturn entityQueryReturn) {
/* 32 */     this.entityQueryReturns.add(entityQueryReturn);
/*    */   }
/*    */   
/*    */   public void addScalarQueryReturn(SQLQueryScalarReturn scalarQueryReturn) {
/* 36 */     this.scalarQueryReturns.add(scalarQueryReturn);
/*    */   }
/*    */   
/*    */   public SQLQueryReturn[] getEntityQueryReturns() {
/* 40 */     return (SQLQueryReturn[])this.entityQueryReturns.toArray(new SQLQueryReturn[0]);
/*    */   }
/*    */   
/*    */   public SQLQueryScalarReturn[] getScalarQueryReturns() {
/* 44 */     return (SQLQueryScalarReturn[])this.scalarQueryReturns.toArray(new SQLQueryScalarReturn[0]);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\ResultSetMappingDefinition.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */