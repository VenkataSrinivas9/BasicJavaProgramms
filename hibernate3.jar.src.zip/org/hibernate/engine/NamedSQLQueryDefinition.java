/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.hibernate.CacheMode;
/*     */ import org.hibernate.FlushMode;
/*     */ import org.hibernate.loader.custom.SQLQueryReturn;
/*     */ import org.hibernate.loader.custom.SQLQueryScalarReturn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamedSQLQueryDefinition
/*     */   extends NamedQueryDefinition
/*     */ {
/*     */   private SQLQueryReturn[] queryReturns;
/*     */   private SQLQueryScalarReturn[] scalarReturns;
/*     */   private final List querySpaces;
/*     */   private final boolean callable;
/*     */   private String resultSetRef;
/*     */   
/*     */   public NamedSQLQueryDefinition(String query, SQLQueryReturn[] queryReturns, SQLQueryScalarReturn[] scalarReturns, List querySpaces, boolean cacheable, String cacheRegion, Integer timeout, Integer fetchSize, FlushMode flushMode, Map parameterTypes, boolean callable)
/*     */   {
/*  41 */     this(query, queryReturns, scalarReturns, querySpaces, cacheable, cacheRegion, timeout, fetchSize, flushMode, null, false, null, parameterTypes, callable);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NamedSQLQueryDefinition(String query, SQLQueryReturn[] queryReturns, SQLQueryScalarReturn[] scalarReturns, List querySpaces, boolean cacheable, String cacheRegion, Integer timeout, Integer fetchSize, FlushMode flushMode, CacheMode cacheMode, boolean readOnly, String comment, Map parameterTypes, boolean callable)
/*     */   {
/*  75 */     super(query.trim(), cacheable, cacheRegion, timeout, fetchSize, flushMode, cacheMode, readOnly, comment, parameterTypes);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  87 */     this.queryReturns = queryReturns;
/*  88 */     this.scalarReturns = scalarReturns;
/*  89 */     this.querySpaces = querySpaces;
/*  90 */     this.callable = callable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NamedSQLQueryDefinition(String query, String resultSetRef, List querySpaces, boolean cacheable, String cacheRegion, Integer timeout, Integer fetchSize, FlushMode flushMode, Map parameterTypes, boolean callable)
/*     */   {
/* 105 */     this(query, resultSetRef, querySpaces, cacheable, cacheRegion, timeout, fetchSize, flushMode, null, false, null, parameterTypes, callable);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NamedSQLQueryDefinition(String query, String resultSetRef, List querySpaces, boolean cacheable, String cacheRegion, Integer timeout, Integer fetchSize, FlushMode flushMode, CacheMode cacheMode, boolean readOnly, String comment, Map parameterTypes, boolean callable)
/*     */   {
/* 137 */     super(query.trim(), cacheable, cacheRegion, timeout, fetchSize, flushMode, cacheMode, readOnly, comment, parameterTypes);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 149 */     this.resultSetRef = resultSetRef;
/* 150 */     this.querySpaces = querySpaces;
/* 151 */     this.callable = callable;
/*     */   }
/*     */   
/*     */   public SQLQueryReturn[] getQueryReturns() {
/* 155 */     return this.queryReturns;
/*     */   }
/*     */   
/*     */   public SQLQueryScalarReturn[] getScalarQueryReturns() {
/* 159 */     return this.scalarReturns;
/*     */   }
/*     */   
/*     */   public List getQuerySpaces() {
/* 163 */     return this.querySpaces;
/*     */   }
/*     */   
/*     */   public boolean isCallable() {
/* 167 */     return this.callable;
/*     */   }
/*     */   
/*     */   public String getResultSetRef() {
/* 171 */     return this.resultSetRef;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\NamedSQLQueryDefinition.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */