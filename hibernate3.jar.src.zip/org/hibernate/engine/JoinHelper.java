/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import org.hibernate.persister.entity.Joinable;
/*     */ import org.hibernate.persister.entity.OuterJoinLoadable;
/*     */ import org.hibernate.persister.entity.PropertyMapping;
/*     */ import org.hibernate.type.AssociationType;
/*     */ import org.hibernate.util.ArrayHelper;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JoinHelper
/*     */ {
/*     */   public static String[] getAliasedLHSColumnNames(AssociationType type, String alias, int property, OuterJoinLoadable lhsPersister, Mapping mapping)
/*     */   {
/*  29 */     return getAliasedLHSColumnNames(type, alias, property, 0, lhsPersister, mapping);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] getLHSColumnNames(AssociationType type, int property, OuterJoinLoadable lhsPersister, Mapping mapping)
/*     */   {
/*  42 */     return getLHSColumnNames(type, property, 0, lhsPersister, mapping);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] getAliasedLHSColumnNames(AssociationType type, String alias, int property, int begin, OuterJoinLoadable lhsPersister, Mapping mapping)
/*     */   {
/*  57 */     if (type.useLHSPrimaryKey()) {
/*  58 */       return StringHelper.qualify(alias, lhsPersister.getIdentifierColumnNames());
/*     */     }
/*     */     
/*  61 */     String propertyName = type.getLHSPropertyName();
/*  62 */     if (propertyName == null) {
/*  63 */       return ArrayHelper.slice(lhsPersister.toColumns(alias, property), begin, type.getColumnSpan(mapping));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  70 */     return ((PropertyMapping)lhsPersister).toColumns(alias, propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] getLHSColumnNames(AssociationType type, int property, int begin, OuterJoinLoadable lhsPersister, Mapping mapping)
/*     */   {
/*  86 */     if (type.useLHSPrimaryKey())
/*     */     {
/*  88 */       return lhsPersister.getIdentifierColumnNames();
/*     */     }
/*     */     
/*  91 */     String propertyName = type.getLHSPropertyName();
/*  92 */     if (propertyName == null)
/*     */     {
/*     */ 
/*  95 */       return ArrayHelper.slice(lhsPersister.getSubclassPropertyColumnNames(property), begin, type.getColumnSpan(mapping));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 104 */     return lhsPersister.getPropertyColumnNames(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getLHSTableName(AssociationType type, int property, OuterJoinLoadable lhsPersister)
/*     */   {
/* 114 */     if (type.useLHSPrimaryKey()) {
/* 115 */       return lhsPersister.getTableName();
/*     */     }
/*     */     
/* 118 */     String propertyName = type.getLHSPropertyName();
/* 119 */     if (propertyName == null)
/*     */     {
/*     */ 
/*     */ 
/* 123 */       return lhsPersister.getSubclassPropertyTableName(property);
/*     */     }
/*     */     
/*     */ 
/* 127 */     String propertyRefTable = lhsPersister.getPropertyTableName(propertyName);
/* 128 */     if (propertyRefTable == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 136 */       propertyRefTable = lhsPersister.getSubclassPropertyTableName(property);
/*     */     }
/* 138 */     return propertyRefTable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] getRHSColumnNames(AssociationType type, SessionFactoryImplementor factory)
/*     */   {
/* 148 */     String uniqueKeyPropertyName = type.getRHSUniqueKeyPropertyName();
/* 149 */     Joinable joinable = type.getAssociatedJoinable(factory);
/* 150 */     if (uniqueKeyPropertyName == null) {
/* 151 */       return joinable.getKeyColumnNames();
/*     */     }
/*     */     
/* 154 */     return ((OuterJoinLoadable)joinable).getPropertyColumnNames(uniqueKeyPropertyName);
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\JoinHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */