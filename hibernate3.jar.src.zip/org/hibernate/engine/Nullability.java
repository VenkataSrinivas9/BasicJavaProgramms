/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.PropertyValueException;
/*     */ import org.hibernate.intercept.LazyPropertyInitializer;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.type.AbstractComponentType;
/*     */ import org.hibernate.type.CollectionType;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Nullability
/*     */ {
/*     */   private final SessionImplementor session;
/*     */   
/*     */   public Nullability(SessionImplementor session)
/*     */   {
/*  24 */     this.session = session;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void checkNullability(Object[] values, EntityPersister persister, boolean isUpdate)
/*     */     throws PropertyValueException, HibernateException
/*     */   {
/*  59 */     boolean[] nullability = persister.getPropertyNullability();
/*  60 */     boolean[] checkability = isUpdate ? persister.getPropertyUpdateability() : persister.getPropertyInsertability();
/*     */     
/*     */ 
/*  63 */     Type[] propertyTypes = persister.getPropertyTypes();
/*     */     
/*  65 */     for (int i = 0; i < values.length; i++)
/*     */     {
/*  67 */       if ((checkability[i] != 0) && (values[i] != LazyPropertyInitializer.UNFETCHED_PROPERTY)) {
/*  68 */         Object value = values[i];
/*  69 */         if ((nullability[i] == 0) && (value == null))
/*     */         {
/*     */ 
/*  72 */           throw new PropertyValueException("not-null property references a null or transient value", persister.getEntityName(), persister.getPropertyNames()[i]);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */         if (value != null)
/*     */         {
/*     */ 
/*  82 */           String breakProperties = checkSubElementsNullability(propertyTypes[i], value);
/*  83 */           if (breakProperties != null) {
/*  84 */             throw new PropertyValueException("not-null property references a null or transient value", persister.getEntityName(), buildPropertyPath(persister.getPropertyNames()[i], breakProperties));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String checkSubElementsNullability(Type propertyType, Object value)
/*     */     throws HibernateException
/*     */   {
/* 110 */     if (propertyType.isComponentType()) {
/* 111 */       return checkComponentNullability(value, (AbstractComponentType)propertyType);
/*     */     }
/* 113 */     if (propertyType.isCollectionType())
/*     */     {
/*     */ 
/* 116 */       CollectionType collectionType = (CollectionType)propertyType;
/* 117 */       Type collectionElementType = collectionType.getElementType(this.session.getFactory());
/* 118 */       if (collectionElementType.isComponentType())
/*     */       {
/*     */ 
/* 121 */         AbstractComponentType componentType = (AbstractComponentType)collectionElementType;
/* 122 */         Iterator iter = CascadingAction.getLoadedElementsIterator(this.session, collectionType, value);
/* 123 */         while (iter.hasNext()) {
/* 124 */           Object compValue = iter.next();
/* 125 */           if (compValue != null) {
/* 126 */             return checkComponentNullability(compValue, componentType);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 131 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String checkComponentNullability(Object value, AbstractComponentType compType)
/*     */     throws HibernateException
/*     */   {
/* 149 */     boolean[] nullability = compType.getPropertyNullability();
/* 150 */     if (nullability != null)
/*     */     {
/* 152 */       Object[] values = compType.getPropertyValues(value, this.session.getEntityMode());
/* 153 */       Type[] propertyTypes = compType.getSubtypes();
/* 154 */       for (int i = 0; i < values.length; i++) {
/* 155 */         Object subvalue = values[i];
/* 156 */         if ((nullability[i] == 0) && (subvalue == null)) {
/* 157 */           return compType.getPropertyNames()[i];
/*     */         }
/* 159 */         if (subvalue != null) {
/* 160 */           String breakProperties = checkSubElementsNullability(propertyTypes[i], subvalue);
/* 161 */           if (breakProperties != null) {
/* 162 */             return buildPropertyPath(compType.getPropertyNames()[i], breakProperties);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 167 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String buildPropertyPath(String parent, String child)
/*     */   {
/* 179 */     return parent.length() + child.length() + 1 + parent + '.' + child;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\Nullability.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */