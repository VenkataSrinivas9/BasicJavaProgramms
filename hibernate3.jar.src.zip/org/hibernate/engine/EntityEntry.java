/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.HashSet;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.LockMode;
/*     */ import org.hibernate.intercept.FieldInterceptor;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.persister.entity.UniqueKeyLoadable;
/*     */ import org.hibernate.pretty.MessageHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EntityEntry
/*     */   implements Serializable
/*     */ {
/*     */   private LockMode lockMode;
/*     */   private Status status;
/*     */   private final Serializable id;
/*     */   private Object[] loadedState;
/*     */   private Object[] deletedState;
/*     */   private boolean existsInDatabase;
/*     */   private Object version;
/*     */   private transient EntityPersister persister;
/*     */   private final EntityMode entityMode;
/*     */   private final String entityName;
/*     */   private boolean isBeingReplicated;
/*     */   private boolean loadedWithLazyPropertiesUnfetched;
/*     */   private final transient Object rowId;
/*     */   
/*     */   EntityEntry(Status status, Object[] loadedState, Object rowId, Serializable id, Object version, LockMode lockMode, boolean existsInDatabase, EntityPersister persister, EntityMode entityMode, boolean disableVersionIncrement, boolean lazyPropertiesAreUnfetched)
/*     */   {
/*  49 */     this.status = status;
/*  50 */     this.loadedState = loadedState;
/*  51 */     this.id = id;
/*  52 */     this.rowId = rowId;
/*  53 */     this.existsInDatabase = existsInDatabase;
/*  54 */     this.version = version;
/*  55 */     this.lockMode = lockMode;
/*  56 */     this.isBeingReplicated = disableVersionIncrement;
/*  57 */     this.loadedWithLazyPropertiesUnfetched = lazyPropertiesAreUnfetched;
/*  58 */     this.persister = persister;
/*  59 */     this.entityMode = entityMode;
/*  60 */     this.entityName = (persister == null ? null : persister.getEntityName());
/*     */   }
/*     */   
/*     */   public LockMode getLockMode()
/*     */   {
/*  65 */     return this.lockMode;
/*     */   }
/*     */   
/*     */   public void setLockMode(LockMode lockMode) {
/*  69 */     this.lockMode = lockMode;
/*     */   }
/*     */   
/*     */   public Status getStatus() {
/*  73 */     return this.status;
/*     */   }
/*     */   
/*     */   public void setStatus(Status status) {
/*  77 */     if (status == Status.READ_ONLY) {
/*  78 */       this.loadedState = null;
/*     */     }
/*  80 */     this.status = status;
/*     */   }
/*     */   
/*     */   public Serializable getId() {
/*  84 */     return this.id;
/*     */   }
/*     */   
/*     */   public Object[] getLoadedState() {
/*  88 */     return this.loadedState;
/*     */   }
/*     */   
/*     */   public Object[] getDeletedState() {
/*  92 */     return this.deletedState;
/*     */   }
/*     */   
/*     */   public void setDeletedState(Object[] deletedState) {
/*  96 */     this.deletedState = deletedState;
/*     */   }
/*     */   
/*     */   public boolean isExistsInDatabase() {
/* 100 */     return this.existsInDatabase;
/*     */   }
/*     */   
/*     */   public Object getVersion() {
/* 104 */     return this.version;
/*     */   }
/*     */   
/*     */   public EntityPersister getPersister() {
/* 108 */     return this.persister;
/*     */   }
/*     */   
/*     */   void afterDeserialize(SessionFactoryImplementor factory) {
/* 112 */     this.persister = factory.getEntityPersister(this.entityName);
/*     */   }
/*     */   
/*     */   public String getEntityName() {
/* 116 */     return this.entityName;
/*     */   }
/*     */   
/*     */   public boolean isBeingReplicated() {
/* 120 */     return this.isBeingReplicated;
/*     */   }
/*     */   
/*     */   public Object getRowId() {
/* 124 */     return this.rowId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void postUpdate(Object entity, Object[] updatedState, Object nextVersion)
/*     */   {
/* 132 */     this.loadedState = updatedState;
/*     */     
/* 134 */     setLockMode(LockMode.WRITE);
/*     */     
/* 136 */     if (getPersister().isVersioned()) {
/* 137 */       this.version = nextVersion;
/* 138 */       getPersister().setPropertyValue(entity, getPersister().getVersionProperty(), nextVersion, this.entityMode);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 146 */     FieldInterceptor.clearDirty(entity);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void postDelete()
/*     */   {
/* 154 */     this.status = Status.GONE;
/* 155 */     this.existsInDatabase = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void postInsert()
/*     */   {
/* 163 */     this.existsInDatabase = true;
/*     */   }
/*     */   
/*     */   public boolean isNullifiable(boolean earlyInsert, SessionImplementor session) {
/* 167 */     return (getStatus() == Status.SAVING) || (earlyInsert ? !isExistsInDatabase() : session.getPersistenceContext().getNullifiableEntityKeys().contains(new EntityKey(getId(), getPersister(), this.entityMode)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getLoadedValue(String propertyName)
/*     */   {
/* 176 */     int propertyIndex = ((UniqueKeyLoadable)this.persister).getPropertyIndex(propertyName);
/* 177 */     return this.loadedState[propertyIndex];
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean requiresDirtyCheck(Object entity)
/*     */   {
/* 183 */     boolean isMutableInstance = (this.status != Status.READ_ONLY) && (this.persister.isMutable());
/*     */     
/*     */ 
/*     */ 
/* 187 */     return (isMutableInstance) && ((getPersister().hasMutableProperties()) || (!FieldInterceptor.hasInterceptor(entity)) || (FieldInterceptor.getFieldInterceptor(entity).isDirty()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReadOnly(boolean readOnly, Object entity)
/*     */   {
/* 196 */     if ((this.status != Status.MANAGED) && (this.status != Status.READ_ONLY)) {
/* 197 */       throw new HibernateException("instance was not in a valid state");
/*     */     }
/* 199 */     if (readOnly) {
/* 200 */       setStatus(Status.READ_ONLY);
/* 201 */       this.loadedState = null;
/*     */     }
/*     */     else {
/* 204 */       setStatus(Status.MANAGED);
/* 205 */       this.loadedState = getPersister().getPropertyValues(entity, this.entityMode);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() {
/* 210 */     return "EntityEntry" + MessageHelper.infoString(this.entityName, this.id) + '(' + this.status + ')';
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isLoadedWithLazyPropertiesUnfetched()
/*     */   {
/* 216 */     return this.loadedWithLazyPropertiesUnfetched;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\EntityEntry.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */