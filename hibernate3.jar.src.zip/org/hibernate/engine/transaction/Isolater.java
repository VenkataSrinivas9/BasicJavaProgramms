/*     */ package org.hibernate.engine.transaction;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import javax.transaction.Transaction;
/*     */ import javax.transaction.TransactionManager;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.exception.JDBCExceptionHelper;
/*     */ import org.hibernate.jdbc.Batcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Isolater
/*     */ {
/*  22 */   private static final Log log = LogFactory.getLog(Isolater.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void doIsolatedWork(IsolatedWork work, SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/*  33 */     boolean isJta = session.getFactory().getTransactionManager() != null;
/*  34 */     if (isJta) {
/*  35 */       new JtaDelegate(session).delegateWork(work);
/*     */     }
/*     */     else {
/*  38 */       new JdbcDelegate(session).delegateWork(work);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static abstract interface Delegate
/*     */   {
/*     */     public abstract void delegateWork(IsolatedWork paramIsolatedWork)
/*     */       throws HibernateException;
/*     */   }
/*     */   
/*     */ 
/*     */   public static class JtaDelegate
/*     */     implements Isolater.Delegate
/*     */   {
/*     */     private final SessionImplementor session;
/*     */     
/*     */ 
/*     */     public JtaDelegate(SessionImplementor session)
/*     */     {
/*  59 */       this.session = session;
/*     */     }
/*     */     
/*     */     public void delegateWork(IsolatedWork work) throws HibernateException {
/*  63 */       TransactionManager transactionManager = this.session.getFactory().getTransactionManager();
/*  64 */       Transaction surroundingTransaction = null;
/*  65 */       Connection connection = null;
/*  66 */       boolean caughtException = false;
/*     */       
/*     */ 
/*     */       try
/*     */       {
/*  71 */         surroundingTransaction = transactionManager.suspend();
/*  72 */         if (Isolater.log.isDebugEnabled()) {
/*  73 */           Isolater.log.debug("surrounding JTA transaction suspended [" + surroundingTransaction + "]");
/*     */         }
/*  75 */         transactionManager.begin();
/*  76 */         connection = this.session.getBatcher().openConnection();
/*     */         
/*     */ 
/*  79 */         work.doWork(connection);
/*     */         
/*     */ 
/*     */ 
/*  83 */         this.session.getBatcher().closeConnection(connection);
/*  84 */         transactionManager.commit();
/*     */ 
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/*     */ 
/*  90 */         caughtException = true;
/*     */         try {
/*  92 */           if ((connection != null) && (!connection.isClosed())) {
/*  93 */             this.session.getBatcher().closeConnection(connection);
/*     */           }
/*     */         }
/*     */         catch (Throwable ignore) {
/*  97 */           Isolater.log.trace("unable to release connection on exception [" + ignore + "]");
/*     */         }
/*     */         try {
/* 100 */           transactionManager.rollback();
/*     */         }
/*     */         catch (Throwable ignore) {
/* 103 */           Isolater.log.trace("unable to rollback new transaction on exception [" + ignore + "]");
/*     */         }
/*     */         
/*     */ 
/* 107 */         if ((t instanceof HibernateException)) {
/* 108 */           throw ((HibernateException)t);
/*     */         }
/*     */         
/* 111 */         throw new HibernateException("error performing isolated work", t);
/*     */       }
/*     */       finally
/*     */       {
/* 115 */         if (surroundingTransaction != null) {
/*     */           try {
/* 117 */             transactionManager.resume(surroundingTransaction);
/* 118 */             if (Isolater.log.isDebugEnabled()) {
/* 119 */               Isolater.log.debug("surrounding JTA transaction resumed [" + surroundingTransaction + "]");
/*     */             }
/*     */           }
/*     */           catch (Throwable t) {
/* 123 */             if (!caughtException) {
/* 124 */               new HibernateException("unable to resume previously suspended transaction", t);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class JdbcDelegate
/*     */     implements Isolater.Delegate
/*     */   {
/*     */     private final SessionImplementor session;
/*     */     
/*     */     public JdbcDelegate(SessionImplementor session)
/*     */     {
/* 140 */       this.session = session;
/*     */     }
/*     */     
/*     */     public void delegateWork(IsolatedWork work) throws HibernateException {
/* 144 */       Connection connection = null;
/* 145 */       boolean wasAutoCommit = false;
/*     */       try {
/* 147 */         connection = this.session.getBatcher().openConnection();
/* 148 */         if (connection.getAutoCommit()) {
/* 149 */           wasAutoCommit = true;
/* 150 */           connection.setAutoCommit(false);
/*     */         }
/*     */         
/* 153 */         work.doWork(connection);
/*     */         
/* 155 */         connection.commit();
/*     */       }
/*     */       catch (Throwable t) {
/*     */         try {
/* 159 */           if ((connection != null) && (!connection.isClosed())) {
/* 160 */             connection.rollback();
/*     */           }
/*     */         }
/*     */         catch (Throwable ignore) {
/* 164 */           Isolater.log.trace("unable to release connection on exception [" + ignore + "]");
/*     */         }
/*     */         
/* 167 */         if ((t instanceof HibernateException)) {
/* 168 */           throw ((HibernateException)t);
/*     */         }
/* 170 */         if ((t instanceof SQLException)) {
/* 171 */           throw JDBCExceptionHelper.convert(this.session.getFactory().getSQLExceptionConverter(), (SQLException)t, "error performing isolated work");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 178 */         throw new HibernateException("error performing isolated work", t);
/*     */       }
/*     */       finally
/*     */       {
/* 182 */         if (wasAutoCommit) {
/*     */           try {
/* 184 */             connection.setAutoCommit(true);
/*     */           }
/*     */           catch (Throwable ignore) {
/* 187 */             Isolater.log.trace("was unable to reset connection back to auto-commit");
/*     */           }
/* 189 */           this.session.getBatcher().closeConnection(connection);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\transaction\Isolater.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */