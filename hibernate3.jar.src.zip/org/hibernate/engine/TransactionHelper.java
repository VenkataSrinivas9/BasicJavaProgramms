/*    */ package org.hibernate.engine;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.engine.transaction.IsolatedWork;
/*    */ import org.hibernate.engine.transaction.Isolater;
/*    */ import org.hibernate.exception.JDBCExceptionHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TransactionHelper
/*    */ {
/*    */   protected abstract Serializable doWorkInCurrentTransaction(Connection paramConnection, String paramString)
/*    */     throws SQLException;
/*    */   
/*    */   public Serializable doWorkInNewTransaction(final SessionImplementor session)
/*    */     throws HibernateException
/*    */   {
/* 50 */     IsolatedWork work = new IsolatedWork()
/*    */     {
/*    */       Serializable generatedValue;
/*    */       
/*    */       public void doWork(Connection connection)
/*    */         throws HibernateException
/*    */       {
/* 36 */         String sql = null;
/*    */         try {
/* 38 */           this.generatedValue = TransactionHelper.this.doWorkInCurrentTransaction(connection, sql);
/*    */         }
/*    */         catch (SQLException sqle) {
/* 41 */           throw JDBCExceptionHelper.convert(session.getFactory().getSQLExceptionConverter(), sqle, "could not get or update next value", sql);
/*    */ 
/*    */         }
/*    */         
/*    */ 
/*    */       }
/*    */       
/*    */ 
/*    */ 
/* 50 */     };
/* 51 */     Isolater.doIsolatedWork(work, session);
/* 52 */     return work.generatedValue;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\TransactionHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */