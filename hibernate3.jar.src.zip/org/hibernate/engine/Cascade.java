/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.collection.PersistentCollection;
/*     */ import org.hibernate.event.EventSource;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.type.AbstractComponentType;
/*     */ import org.hibernate.type.AssociationType;
/*     */ import org.hibernate.type.CollectionType;
/*     */ import org.hibernate.type.EntityType;
/*     */ import org.hibernate.type.ForeignKeyDirection;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.CollectionHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Cascade
/*     */ {
/*     */   private int cascadeTo;
/*     */   private EventSource eventSource;
/*     */   private CascadingAction action;
/*     */   
/*     */   public Cascade(CascadingAction action, int cascadeTo, EventSource eventSource)
/*     */   {
/*  39 */     this.cascadeTo = cascadeTo;
/*  40 */     this.eventSource = eventSource;
/*  41 */     this.action = action;
/*     */   }
/*     */   
/*  44 */   private static final Log log = LogFactory.getLog(Cascade.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int AFTER_INSERT_BEFORE_DELETE = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int BEFORE_INSERT_AFTER_DELETE = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int AFTER_INSERT_BEFORE_DELETE_VIA_COLLECTION = 3;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int AFTER_UPDATE = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int BEFORE_FLUSH = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int AFTER_EVICT = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int BEFORE_REFRESH = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int AFTER_LOCK = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int BEFORE_MERGE = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void cascadeProperty(Object child, Type type, CascadeStyle style, Object anything, boolean isCascadeDeleteEnabled)
/*     */     throws HibernateException
/*     */   {
/* 104 */     if (child != null) {
/* 105 */       if (type.isAssociationType()) {
/* 106 */         AssociationType associationType = (AssociationType)type;
/* 107 */         if (cascadeAssociationNow(associationType)) {
/* 108 */           cascadeAssociation(child, type, style, anything, isCascadeDeleteEnabled);
/*     */ 
/*     */ 
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/* 117 */       else if (type.isComponentType()) {
/* 118 */         cascadeComponent(child, (AbstractComponentType)type, anything);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean cascadeAssociationNow(AssociationType associationType) {
/* 124 */     return (associationType.getForeignKeyDirection().cascadeNow(this.cascadeTo)) && ((this.eventSource.getEntityMode() != EntityMode.DOM4J) || (associationType.isEmbeddedInXML()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void cascadeComponent(Object child, AbstractComponentType componentType, Object anything)
/*     */   {
/* 133 */     Object[] children = componentType.getPropertyValues(child, this.eventSource);
/* 134 */     Type[] types = componentType.getSubtypes();
/* 135 */     for (int i = 0; i < types.length; i++) {
/* 136 */       CascadeStyle componentPropertyStyle = componentType.getCascadeStyle(i);
/* 137 */       if (componentPropertyStyle.doCascade(this.action)) {
/* 138 */         cascadeProperty(children[i], types[i], componentPropertyStyle, anything, false);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void cascadeAssociation(Object child, Type type, CascadeStyle style, Object anything, boolean isCascadeDeleteEnabled)
/*     */   {
/* 156 */     if ((type.isEntityType()) || (type.isAnyType())) {
/* 157 */       cascadeToOne(child, type, style, anything, isCascadeDeleteEnabled);
/*     */     }
/* 159 */     else if (type.isCollectionType()) {
/* 160 */       cascadeCollection(child, style, anything, (CollectionType)type);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void cascadeCollection(Object child, CascadeStyle style, Object anything, CollectionType type)
/*     */   {
/* 174 */     CollectionPersister persister = this.eventSource.getFactory().getCollectionPersister(type.getRole());
/*     */     
/* 176 */     Type elemType = persister.getElementType();
/*     */     
/* 178 */     int oldCascadeTo = this.cascadeTo;
/* 179 */     if (this.cascadeTo == 1) {
/* 180 */       this.cascadeTo = 3;
/*     */     }
/*     */     
/*     */ 
/* 184 */     if ((elemType.isEntityType()) || (elemType.isAnyType()) || (elemType.isComponentType())) {
/* 185 */       cascadeCollectionElements(child, type, style, elemType, anything, persister.isCascadeDeleteEnabled());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 195 */     this.cascadeTo = oldCascadeTo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void cascadeToOne(Object child, Type type, CascadeStyle style, Object anything, boolean isCascadeDeleteEnabled)
/*     */   {
/* 209 */     String entityName = type.isEntityType() ? ((EntityType)type).getAssociatedEntityName() : null;
/*     */     
/*     */ 
/* 212 */     if (style.reallyDoCascade(this.action)) {
/* 213 */       this.action.cascade(this.eventSource, child, entityName, anything, isCascadeDeleteEnabled);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void cascade(EntityPersister persister, Object parent)
/*     */     throws HibernateException
/*     */   {
/* 223 */     cascade(persister, parent, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void cascade(EntityPersister persister, Object parent, Object anything)
/*     */     throws HibernateException
/*     */   {
/* 235 */     if (persister.hasCascades()) {
/* 236 */       if (log.isTraceEnabled()) {
/* 237 */         log.trace("processing cascade " + this.action + " for: " + persister.getEntityName());
/*     */       }
/*     */       
/* 240 */       Type[] types = persister.getPropertyTypes();
/* 241 */       CascadeStyle[] cascadeStyles = persister.getPropertyCascadeStyles();
/* 242 */       for (int i = 0; i < types.length; i++) {
/* 243 */         CascadeStyle style = cascadeStyles[i];
/* 244 */         if (style.doCascade(this.action))
/*     */         {
/*     */ 
/*     */ 
/* 248 */           cascadeProperty(persister.getPropertyValue(parent, i, this.eventSource.getEntityMode()), types[i], style, anything, false);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 258 */       if (log.isTraceEnabled()) {
/* 259 */         log.trace("done processing cascade " + this.action + " for: " + persister.getEntityName());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void cascadeCollectionElements(Object child, CollectionType collectionType, CascadeStyle style, Type elemType, Object anything, boolean isCascadeDeleteEnabled)
/*     */     throws HibernateException
/*     */   {
/* 277 */     boolean embeddedElements = (this.eventSource.getEntityMode() != EntityMode.DOM4J) || (((EntityType)collectionType.getElementType(this.eventSource.getFactory())).isEmbeddedInXML());
/*     */     
/*     */ 
/* 280 */     boolean reallyDoCascade = (style.reallyDoCascade(this.action)) && (embeddedElements) && (child != CollectionType.UNFETCHED_COLLECTION);
/*     */     
/*     */ 
/* 283 */     if (reallyDoCascade) {
/* 284 */       if (log.isTraceEnabled()) {
/* 285 */         log.trace("cascade " + this.action + " for collection: " + collectionType.getRole());
/*     */       }
/*     */       
/* 288 */       Iterator iter = this.action.getCascadableChildrenIterator(this.eventSource, collectionType, child);
/* 289 */       while (iter.hasNext()) {
/* 290 */         cascadeProperty(iter.next(), elemType, style, anything, isCascadeDeleteEnabled);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 299 */       if (log.isTraceEnabled()) {
/* 300 */         log.trace("done cascade " + this.action + " for collection: " + collectionType.getRole());
/*     */       }
/*     */     }
/*     */     
/* 304 */     boolean deleteOrphans = (style.hasOrphanDelete()) && (this.action.deleteOrphans()) && (elemType.isEntityType()) && ((child instanceof PersistentCollection));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 309 */     if (deleteOrphans) {
/* 310 */       if (log.isTraceEnabled()) {
/* 311 */         log.trace("deleting orphans for collection: " + collectionType.getRole());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 317 */       String entityName = collectionType.getAssociatedEntityName(this.eventSource.getFactory());
/* 318 */       deleteOrphans(entityName, (PersistentCollection)child);
/*     */       
/* 320 */       if (log.isTraceEnabled()) {
/* 321 */         log.trace("done deleting orphans for collection: " + collectionType.getRole());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void deleteOrphans(String entityName, PersistentCollection pc)
/*     */     throws HibernateException
/*     */   {
/*     */     Collection orphans;
/*     */     
/*     */     Collection orphans;
/*     */     
/* 334 */     if (pc.wasInitialized()) {
/* 335 */       CollectionEntry ce = this.eventSource.getPersistenceContext().getCollectionEntry(pc);
/* 336 */       orphans = ce == null ? CollectionHelper.EMPTY_COLLECTION : ce.getOrphans(entityName, pc);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 341 */       orphans = pc.getQueuedOrphans(entityName);
/*     */     }
/*     */     
/* 344 */     Iterator orphanIter = orphans.iterator();
/* 345 */     while (orphanIter.hasNext()) {
/* 346 */       Object orphan = orphanIter.next();
/* 347 */       if (orphan != null) {
/* 348 */         if (log.isTraceEnabled()) {
/* 349 */           log.trace("deleting orphaned entity instance: " + entityName);
/*     */         }
/* 351 */         this.eventSource.delete(entityName, orphan, false);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\Cascade.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */