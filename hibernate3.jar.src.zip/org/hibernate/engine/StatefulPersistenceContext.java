/*      */ package org.hibernate.engine;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InvalidObjectException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.collections.ReferenceMap;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.hibernate.AssertionFailure;
/*      */ import org.hibernate.Hibernate;
/*      */ import org.hibernate.HibernateException;
/*      */ import org.hibernate.LockMode;
/*      */ import org.hibernate.MappingException;
/*      */ import org.hibernate.NonUniqueObjectException;
/*      */ import org.hibernate.PersistentObjectException;
/*      */ import org.hibernate.TransientObjectException;
/*      */ import org.hibernate.collection.PersistentCollection;
/*      */ import org.hibernate.persister.collection.CollectionPersister;
/*      */ import org.hibernate.persister.entity.EntityPersister;
/*      */ import org.hibernate.proxy.HibernateProxy;
/*      */ import org.hibernate.proxy.LazyInitializer;
/*      */ import org.hibernate.tuple.ElementWrapper;
/*      */ import org.hibernate.type.CollectionType;
/*      */ import org.hibernate.util.IdentityMap;
/*      */ import org.hibernate.util.MarkerObject;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StatefulPersistenceContext
/*      */   implements Serializable, PersistenceContext
/*      */ {
/*   53 */   private static final Log log = LogFactory.getLog(StatefulPersistenceContext.class);
/*   54 */   private static final Log PROXY_WARN_LOG = LogFactory.getLog(StatefulPersistenceContext.class.getName() + ".ProxyWarnLog");
/*      */   
/*   56 */   public static final Object NO_ROW = new MarkerObject("NO_ROW");
/*      */   
/*      */ 
/*      */   private SessionImplementor session;
/*      */   
/*      */ 
/*      */   private final Map entitiesByKey;
/*      */   
/*      */ 
/*      */   private final Map entitiesByUniqueKey;
/*      */   
/*      */ 
/*      */   private transient Map entityEntries;
/*      */   
/*      */ 
/*      */   private transient Map proxiesByKey;
/*      */   
/*      */ 
/*      */   private final Map entitySnapshotsByKey;
/*      */   
/*      */ 
/*      */   private transient Map arrayHolders;
/*      */   
/*      */ 
/*      */   private transient Map collectionEntries;
/*      */   
/*      */ 
/*      */   private final Map collectionsByKey;
/*      */   
/*      */ 
/*   86 */   private HashSet nullifiableEntityKeys = new HashSet();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private transient HashSet nullAssociations;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private transient List nonlazyCollections;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private transient Map unownedCollections;
/*      */   
/*      */ 
/*      */ 
/*  105 */   private transient int cascading = 0;
/*  106 */   private transient int loadCounter = 0;
/*  107 */   private transient boolean flushing = false;
/*      */   
/*  109 */   private boolean hasNonReadOnlyEntities = false;
/*      */   private transient CollectionLoadContext collectionLoadContext;
/*      */   private transient BatchFetchQueue batchFetchQueue;
/*      */   private static final int INIT_MAP_SIZE = 8;
/*      */   
/*      */   public boolean isStateless() {
/*  115 */     return false;
/*      */   }
/*      */   
/*      */   public SessionImplementor getSession() {
/*  119 */     return this.session;
/*      */   }
/*      */   
/*      */   public CollectionLoadContext getCollectionLoadContext() {
/*  123 */     if (this.collectionLoadContext == null) {
/*  124 */       this.collectionLoadContext = new CollectionLoadContext(this);
/*      */     }
/*  126 */     return this.collectionLoadContext;
/*      */   }
/*      */   
/*      */   public void addUnownedCollection(CollectionKey key, PersistentCollection collection) {
/*  130 */     if (this.unownedCollections == null) {
/*  131 */       this.unownedCollections = new HashMap(8);
/*      */     }
/*  133 */     this.unownedCollections.put(key, collection);
/*      */   }
/*      */   
/*      */   public PersistentCollection useUnownedCollection(CollectionKey key) {
/*  137 */     if (this.unownedCollections == null) {
/*  138 */       return null;
/*      */     }
/*      */     
/*  141 */     return (PersistentCollection)this.unownedCollections.remove(key);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BatchFetchQueue getBatchFetchQueue()
/*      */   {
/*  150 */     if (this.batchFetchQueue == null) {
/*  151 */       this.batchFetchQueue = new BatchFetchQueue(this);
/*      */     }
/*  153 */     return this.batchFetchQueue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StatefulPersistenceContext(SessionImplementor session)
/*      */   {
/*  164 */     this.session = session;
/*      */     
/*  166 */     this.entitiesByKey = new HashMap(8);
/*  167 */     this.entitiesByUniqueKey = new HashMap(8);
/*  168 */     this.proxiesByKey = new ReferenceMap(0, 2);
/*  169 */     this.entitySnapshotsByKey = new HashMap(8);
/*      */     
/*      */ 
/*  172 */     this.entityEntries = IdentityMap.instantiateSequenced(8);
/*  173 */     this.collectionEntries = IdentityMap.instantiateSequenced(8);
/*  174 */     this.collectionsByKey = new HashMap(8);
/*  175 */     this.arrayHolders = IdentityMap.instantiate(8);
/*      */     
/*  177 */     initTransientState();
/*      */   }
/*      */   
/*      */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/*  181 */     log.trace("deserializing persistent-context");
/*  182 */     ois.defaultReadObject();
/*      */     
/*  184 */     this.entityEntries = IdentityMap.deserialize(ois.readObject());
/*  185 */     this.collectionEntries = IdentityMap.deserialize(ois.readObject());
/*  186 */     this.arrayHolders = IdentityMap.deserialize(ois.readObject());
/*      */     
/*  188 */     initTransientState();
/*      */     
/*  190 */     this.proxiesByKey = new ReferenceMap(0, 2);
/*  191 */     Map map = (Map)ois.readObject();
/*  192 */     this.proxiesByKey.putAll(map);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  200 */       Iterator iter = this.collectionEntries.entrySet().iterator();
/*  201 */       while (iter.hasNext()) {
/*  202 */         Map.Entry e = (Map.Entry)iter.next();
/*  203 */         ((PersistentCollection)e.getKey()).setCurrentSession(this.session);
/*  204 */         CollectionEntry ce = (CollectionEntry)e.getValue();
/*  205 */         if (ce.getRole() != null) {
/*  206 */           ce.afterDeserialize(this.session.getFactory());
/*      */         }
/*      */       }
/*      */       
/*  210 */       iter = this.proxiesByKey.values().iterator();
/*  211 */       while (iter.hasNext()) {
/*  212 */         Object proxy = iter.next();
/*  213 */         if ((proxy instanceof HibernateProxy)) {
/*  214 */           ((HibernateProxy)proxy).getHibernateLazyInitializer().setSession(this.session);
/*      */         }
/*      */         else {
/*  217 */           iter.remove();
/*      */         }
/*      */       }
/*      */       
/*  221 */       iter = this.entityEntries.entrySet().iterator();
/*  222 */       while (iter.hasNext()) {
/*  223 */         EntityEntry e = (EntityEntry)((Map.Entry)iter.next()).getValue();
/*  224 */         e.afterDeserialize(this.session.getFactory());
/*      */       }
/*      */     }
/*      */     catch (HibernateException he)
/*      */     {
/*  229 */       throw new InvalidObjectException(he.getMessage());
/*      */     }
/*      */   }
/*      */   
/*      */   private void writeObject(ObjectOutputStream oos) throws IOException
/*      */   {
/*  235 */     log.trace("serializing persistent-context");
/*      */     
/*  237 */     oos.defaultWriteObject();
/*      */     
/*  239 */     oos.writeObject(IdentityMap.serialize(this.entityEntries));
/*  240 */     oos.writeObject(IdentityMap.serialize(this.collectionEntries));
/*  241 */     oos.writeObject(IdentityMap.serialize(this.arrayHolders));
/*      */     
/*  243 */     HashMap map = new HashMap(8);
/*  244 */     map.putAll(this.proxiesByKey);
/*  245 */     oos.writeObject(map);
/*      */   }
/*      */   
/*      */   private void initTransientState() {
/*  249 */     this.nullAssociations = new HashSet(8);
/*  250 */     this.nonlazyCollections = new ArrayList(8);
/*      */   }
/*      */   
/*      */   public void clear() {
/*  254 */     this.arrayHolders.clear();
/*  255 */     this.entitiesByKey.clear();
/*  256 */     this.entitiesByUniqueKey.clear();
/*  257 */     this.entityEntries.clear();
/*  258 */     this.entitySnapshotsByKey.clear();
/*  259 */     this.collectionsByKey.clear();
/*  260 */     this.collectionEntries.clear();
/*  261 */     if (this.unownedCollections != null) this.unownedCollections.clear();
/*  262 */     this.proxiesByKey.clear();
/*      */     
/*  264 */     this.nullifiableEntityKeys.clear();
/*      */     
/*  266 */     if (this.batchFetchQueue != null) this.batchFetchQueue.clear();
/*  267 */     this.hasNonReadOnlyEntities = false;
/*      */   }
/*      */   
/*      */   public boolean hasNonReadOnlyEntities() {
/*  271 */     return this.hasNonReadOnlyEntities;
/*      */   }
/*      */   
/*      */   public void setEntryStatus(EntityEntry entry, Status status) {
/*  275 */     entry.setStatus(status);
/*  276 */     setHasNonReadOnlyEnties(status);
/*      */   }
/*      */   
/*      */   private void setHasNonReadOnlyEnties(Status status) {
/*  280 */     if ((status == Status.DELETED) || (status == Status.MANAGED) || (status == Status.SAVING)) {
/*  281 */       this.hasNonReadOnlyEntities = true;
/*      */     }
/*      */   }
/*      */   
/*      */   public void afterTransactionCompletion()
/*      */   {
/*  287 */     Iterator iter = this.entityEntries.values().iterator();
/*  288 */     while (iter.hasNext()) {
/*  289 */       ((EntityEntry)iter.next()).setLockMode(LockMode.NONE);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object[] getDatabaseSnapshot(Serializable id, EntityPersister persister)
/*      */     throws HibernateException
/*      */   {
/*  299 */     EntityKey key = new EntityKey(id, persister, this.session.getEntityMode());
/*  300 */     Object cached = this.entitySnapshotsByKey.get(key);
/*  301 */     if (cached != null) {
/*  302 */       return cached == NO_ROW ? null : (Object[])cached;
/*      */     }
/*      */     
/*  305 */     Object[] snapshot = persister.getDatabaseSnapshot(id, this.session);
/*  306 */     this.entitySnapshotsByKey.put(key, snapshot == null ? NO_ROW : snapshot);
/*  307 */     return snapshot;
/*      */   }
/*      */   
/*      */   public Object[] getNaturalIdSnapshot(Serializable id, EntityPersister persister)
/*      */     throws HibernateException
/*      */   {
/*  313 */     if (!persister.hasNaturalIdentifier()) {
/*  314 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  319 */     int[] props = persister.getNaturalIdentifierProperties();
/*  320 */     boolean[] updateable = persister.getPropertyUpdateability();
/*  321 */     boolean allNatualIdPropsAreUpdateable = true;
/*  322 */     for (int i = 0; i < props.length; i++) {
/*  323 */       if (updateable[props[i]] == 0) {
/*  324 */         allNatualIdPropsAreUpdateable = false;
/*  325 */         break;
/*      */       }
/*      */     }
/*      */     
/*  329 */     if (allNatualIdPropsAreUpdateable)
/*      */     {
/*      */ 
/*      */ 
/*  333 */       Object[] entitySnapshot = getDatabaseSnapshot(id, persister);
/*  334 */       if (entitySnapshot == NO_ROW) {
/*  335 */         return null;
/*      */       }
/*  337 */       Object[] naturalIdSnapshot = new Object[props.length];
/*  338 */       for (int i = 0; i < props.length; i++) {
/*  339 */         naturalIdSnapshot[i] = entitySnapshot[props[i]];
/*      */       }
/*  341 */       return naturalIdSnapshot;
/*      */     }
/*      */     
/*  344 */     return persister.getNaturalIdentifierSnapshot(id, this.session);
/*      */   }
/*      */   
/*      */ 
/*      */   public Object[] getCachedDatabaseSnapshot(EntityKey key)
/*      */   {
/*  350 */     return (Object[])this.entitySnapshotsByKey.get(key);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addEntity(EntityKey key, Object entity)
/*      */   {
/*  358 */     this.entitiesByKey.put(key, entity);
/*  359 */     getBatchFetchQueue().removeBatchLoadableEntityKey(key);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getEntity(EntityKey key)
/*      */   {
/*  367 */     return this.entitiesByKey.get(key);
/*      */   }
/*      */   
/*      */   public boolean containsEntity(EntityKey key) {
/*  371 */     return this.entitiesByKey.containsKey(key);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object removeEntity(EntityKey key)
/*      */   {
/*  380 */     Object entity = this.entitiesByKey.remove(key);
/*  381 */     Iterator iter = this.entitiesByUniqueKey.values().iterator();
/*  382 */     while (iter.hasNext()) {
/*  383 */       if (iter.next() == entity) iter.remove();
/*      */     }
/*  385 */     this.entitySnapshotsByKey.remove(key);
/*  386 */     this.nullifiableEntityKeys.remove(key);
/*  387 */     getBatchFetchQueue().removeBatchLoadableEntityKey(key);
/*  388 */     getBatchFetchQueue().removeSubselect(key);
/*  389 */     return entity;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Object getEntity(EntityUniqueKey euk)
/*      */   {
/*  396 */     return this.entitiesByUniqueKey.get(euk);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void addEntity(EntityUniqueKey euk, Object entity)
/*      */   {
/*  403 */     this.entitiesByUniqueKey.put(euk, entity);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EntityEntry getEntry(Object entity)
/*      */   {
/*  413 */     return (EntityEntry)this.entityEntries.get(entity);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public EntityEntry removeEntry(Object entity)
/*      */   {
/*  420 */     return (EntityEntry)this.entityEntries.remove(entity);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isEntryFor(Object entity)
/*      */   {
/*  427 */     return this.entityEntries.containsKey(entity);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public CollectionEntry getCollectionEntry(PersistentCollection coll)
/*      */   {
/*  434 */     return (CollectionEntry)this.collectionEntries.get(coll);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EntityEntry addEntity(Object entity, Status status, Object[] loadedState, EntityKey entityKey, Object version, LockMode lockMode, boolean existsInDatabase, EntityPersister persister, boolean disableVersionIncrement, boolean lazyPropertiesAreUnfetched)
/*      */   {
/*  453 */     addEntity(entityKey, entity);
/*      */     
/*  455 */     return addEntry(entity, status, loadedState, null, entityKey.getIdentifier(), version, lockMode, existsInDatabase, persister, disableVersionIncrement, lazyPropertiesAreUnfetched);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public EntityEntry addEntry(Object entity, Status status, Object[] loadedState, Object rowId, Serializable id, Object version, LockMode lockMode, boolean existsInDatabase, EntityPersister persister, boolean disableVersionIncrement, boolean lazyPropertiesAreUnfetched)
/*      */   {
/*  488 */     EntityEntry e = new EntityEntry(status, loadedState, rowId, id, version, lockMode, existsInDatabase, persister, this.session.getEntityMode(), disableVersionIncrement, lazyPropertiesAreUnfetched);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  501 */     this.entityEntries.put(entity, e);
/*      */     
/*  503 */     setHasNonReadOnlyEnties(status);
/*  504 */     return e;
/*      */   }
/*      */   
/*      */   public boolean containsCollection(PersistentCollection collection) {
/*  508 */     return this.collectionEntries.containsKey(collection);
/*      */   }
/*      */   
/*      */   public boolean containsProxy(Object entity) {
/*  512 */     return this.proxiesByKey.containsValue(entity);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean reassociateIfUninitializedProxy(Object value)
/*      */     throws MappingException
/*      */   {
/*  523 */     if ((value instanceof ElementWrapper)) {
/*  524 */       value = ((ElementWrapper)value).getElement();
/*      */     }
/*      */     
/*  527 */     if (!Hibernate.isInitialized(value)) {
/*  528 */       HibernateProxy proxy = (HibernateProxy)value;
/*  529 */       LazyInitializer li = proxy.getHibernateLazyInitializer();
/*  530 */       reassociateProxy(li, proxy);
/*  531 */       return true;
/*      */     }
/*      */     
/*  534 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void reassociateProxy(Object value, Serializable id)
/*      */     throws MappingException
/*      */   {
/*  543 */     if ((value instanceof ElementWrapper)) {
/*  544 */       value = ((ElementWrapper)value).getElement();
/*      */     }
/*      */     
/*  547 */     if ((value instanceof HibernateProxy)) {
/*  548 */       if (log.isDebugEnabled()) log.debug("setting proxy identifier: " + id);
/*  549 */       HibernateProxy proxy = (HibernateProxy)value;
/*  550 */       LazyInitializer li = proxy.getHibernateLazyInitializer();
/*  551 */       li.setIdentifier(id);
/*  552 */       reassociateProxy(li, proxy);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void reassociateProxy(LazyInitializer li, HibernateProxy proxy)
/*      */     throws HibernateException
/*      */   {
/*  560 */     if (li.getSession() != this) {
/*  561 */       EntityPersister persister = this.session.getFactory().getEntityPersister(li.getEntityName());
/*  562 */       EntityKey key = new EntityKey(li.getIdentifier(), persister, this.session.getEntityMode());
/*  563 */       if (!this.proxiesByKey.containsKey(key)) this.proxiesByKey.put(key, proxy);
/*  564 */       proxy.getHibernateLazyInitializer().setSession(this.session);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object unproxy(Object maybeProxy)
/*      */     throws HibernateException
/*      */   {
/*  574 */     if ((maybeProxy instanceof ElementWrapper)) {
/*  575 */       maybeProxy = ((ElementWrapper)maybeProxy).getElement();
/*      */     }
/*      */     
/*  578 */     if ((maybeProxy instanceof HibernateProxy)) {
/*  579 */       HibernateProxy proxy = (HibernateProxy)maybeProxy;
/*  580 */       LazyInitializer li = proxy.getHibernateLazyInitializer();
/*  581 */       if (li.isUninitialized()) {
/*  582 */         throw new PersistentObjectException("object was an uninitialized proxy for " + li.getEntityName());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  587 */       return li.getImplementation();
/*      */     }
/*      */     
/*  590 */     return maybeProxy;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object unproxyAndReassociate(Object maybeProxy)
/*      */     throws HibernateException
/*      */   {
/*  602 */     if ((maybeProxy instanceof ElementWrapper)) {
/*  603 */       maybeProxy = ((ElementWrapper)maybeProxy).getElement();
/*      */     }
/*      */     
/*  606 */     if ((maybeProxy instanceof HibernateProxy)) {
/*  607 */       HibernateProxy proxy = (HibernateProxy)maybeProxy;
/*  608 */       LazyInitializer li = proxy.getHibernateLazyInitializer();
/*  609 */       reassociateProxy(li, proxy);
/*  610 */       return li.getImplementation();
/*      */     }
/*      */     
/*  613 */     return maybeProxy;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void checkUniqueness(EntityKey key, Object object)
/*      */     throws HibernateException
/*      */   {
/*  624 */     Object entity = getEntity(key);
/*  625 */     if (entity == object) {
/*  626 */       throw new AssertionFailure("object already associated, but no entry was found");
/*      */     }
/*  628 */     if (entity != null) {
/*  629 */       throw new NonUniqueObjectException(key.getIdentifier(), key.getEntityName());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object narrowProxy(Object proxy, EntityPersister persister, EntityKey key, Object object)
/*      */     throws HibernateException
/*      */   {
/*  649 */     boolean alreadyNarrow = persister.getConcreteProxyClass(this.session.getEntityMode()).isAssignableFrom(proxy.getClass());
/*      */     
/*      */ 
/*  652 */     if (!alreadyNarrow) {
/*  653 */       if (PROXY_WARN_LOG.isWarnEnabled()) {
/*  654 */         PROXY_WARN_LOG.warn("Narrowing proxy to " + persister.getConcreteProxyClass(this.session.getEntityMode()) + " - this operation breaks ==");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  661 */       if (object != null) {
/*  662 */         this.proxiesByKey.remove(key);
/*  663 */         return object;
/*      */       }
/*      */       
/*  666 */       proxy = persister.createProxy(key.getIdentifier(), this.session);
/*  667 */       this.proxiesByKey.put(key, proxy);
/*  668 */       return proxy;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  674 */     if (object != null) {
/*  675 */       LazyInitializer li = ((HibernateProxy)proxy).getHibernateLazyInitializer();
/*  676 */       li.setImplementation(object);
/*      */     }
/*      */     
/*  679 */     return proxy;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object proxyFor(EntityPersister persister, EntityKey key, Object impl)
/*      */     throws HibernateException
/*      */   {
/*  692 */     if (!persister.hasProxy()) return impl;
/*  693 */     Object proxy = this.proxiesByKey.get(key);
/*  694 */     if (proxy != null) {
/*  695 */       return narrowProxy(proxy, persister, key, impl);
/*      */     }
/*      */     
/*  698 */     return impl;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object proxyFor(Object impl)
/*      */     throws HibernateException
/*      */   {
/*  708 */     EntityEntry e = getEntry(impl);
/*  709 */     EntityPersister p = e.getPersister();
/*  710 */     return proxyFor(p, new EntityKey(e.getId(), p, this.session.getEntityMode()), impl);
/*      */   }
/*      */   
/*      */ 
/*      */   public Object getCollectionOwner(Serializable key, CollectionPersister collectionPersister)
/*      */     throws MappingException
/*      */   {
/*  717 */     return getEntity(new EntityKey(key, collectionPersister.getOwnerEntityPersister(), this.session.getEntityMode()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void addUninitializedCollection(CollectionPersister persister, PersistentCollection collection, Serializable id)
/*      */   {
/*  724 */     CollectionEntry ce = new CollectionEntry(collection, persister, id, this.flushing);
/*  725 */     addCollection(collection, ce, id);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void addUninitializedDetachedCollection(CollectionPersister persister, PersistentCollection collection)
/*      */   {
/*  732 */     CollectionEntry ce = new CollectionEntry(persister, collection.getKey());
/*  733 */     addCollection(collection, ce, collection.getKey());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addNewCollection(CollectionPersister persister, PersistentCollection collection)
/*      */     throws HibernateException
/*      */   {
/*  743 */     addCollection(collection, persister);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void addCollection(PersistentCollection coll, CollectionEntry entry, Serializable key)
/*      */   {
/*  750 */     this.collectionEntries.put(coll, entry);
/*  751 */     CollectionKey collectionKey = new CollectionKey(entry.getLoadedPersister(), key, this.session.getEntityMode());
/*  752 */     PersistentCollection old = (PersistentCollection)this.collectionsByKey.put(collectionKey, coll);
/*  753 */     if (old != null) {
/*  754 */       if (old == coll) { throw new AssertionFailure("bug adding collection twice");
/*      */       }
/*  756 */       old.unsetSession(this.session);
/*  757 */       this.collectionEntries.remove(old);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addCollection(PersistentCollection collection, CollectionPersister persister)
/*      */     throws HibernateException
/*      */   {
/*  768 */     CollectionEntry ce = new CollectionEntry(persister, collection);
/*  769 */     this.collectionEntries.put(collection, ce);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addInitializedDetachedCollection(CollectionPersister collectionPersister, PersistentCollection collection)
/*      */     throws HibernateException
/*      */   {
/*  778 */     if (collection.isUnreferenced())
/*      */     {
/*  780 */       addCollection(collection, collectionPersister);
/*      */     }
/*      */     else {
/*  783 */       CollectionEntry ce = new CollectionEntry(collection, this.session.getFactory());
/*  784 */       addCollection(collection, ce, collection.getKey());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public CollectionEntry addInitializedCollection(CollectionPersister persister, PersistentCollection collection, Serializable id)
/*      */     throws HibernateException
/*      */   {
/*  793 */     CollectionEntry ce = new CollectionEntry(collection, persister, id, this.flushing);
/*  794 */     ce.postInitialize(collection);
/*  795 */     addCollection(collection, ce, id);
/*  796 */     return ce;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public PersistentCollection getCollection(CollectionKey collectionKey)
/*      */   {
/*  803 */     return (PersistentCollection)this.collectionsByKey.get(collectionKey);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addNonLazyCollection(PersistentCollection collection)
/*      */   {
/*  811 */     this.nonlazyCollections.add(collection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void initializeNonLazyCollections()
/*      */     throws HibernateException
/*      */   {
/*  820 */     if (this.loadCounter == 0) {
/*  821 */       log.debug("initializing non-lazy collections");
/*      */       
/*  823 */       this.loadCounter += 1;
/*      */       try {
/*      */         int size;
/*  826 */         while ((size = this.nonlazyCollections.size()) > 0)
/*      */         {
/*  828 */           ((PersistentCollection)this.nonlazyCollections.remove(size - 1)).forceInitialization();
/*      */         }
/*      */       }
/*      */       finally {
/*  832 */         this.loadCounter -= 1;
/*  833 */         clearNullProperties();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PersistentCollection getCollectionHolder(Object array)
/*      */   {
/*  843 */     return (PersistentCollection)this.arrayHolders.get(array);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addCollectionHolder(PersistentCollection holder)
/*      */   {
/*  853 */     this.arrayHolders.put(holder.getValue(), holder);
/*      */   }
/*      */   
/*      */   public PersistentCollection removeCollectionHolder(Object array) {
/*  857 */     return (PersistentCollection)this.arrayHolders.remove(array);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Serializable getSnapshot(PersistentCollection coll)
/*      */   {
/*  864 */     return getCollectionEntry(coll).getSnapshot();
/*      */   }
/*      */   
/*      */ 
/*      */   public CollectionEntry getCollectionEntryOrNull(Object collection)
/*      */   {
/*      */     PersistentCollection coll;
/*      */     
/*      */     PersistentCollection coll;
/*      */     
/*  874 */     if ((collection instanceof PersistentCollection)) {
/*  875 */       coll = (PersistentCollection)collection;
/*      */     }
/*      */     else
/*      */     {
/*  879 */       coll = getCollectionHolder(collection);
/*  880 */       if (coll == null)
/*      */       {
/*      */ 
/*  883 */         Iterator wrappers = IdentityMap.keyIterator(this.collectionEntries);
/*  884 */         while (wrappers.hasNext()) {
/*  885 */           PersistentCollection pc = (PersistentCollection)wrappers.next();
/*  886 */           if (pc.isWrapper(collection)) {
/*  887 */             coll = pc;
/*  888 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  894 */     return coll == null ? null : getCollectionEntry(coll);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Object getProxy(EntityKey key)
/*      */   {
/*  901 */     return this.proxiesByKey.get(key);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void addProxy(EntityKey key, Object proxy)
/*      */   {
/*  908 */     this.proxiesByKey.put(key, proxy);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Object removeProxy(EntityKey key)
/*      */   {
/*  915 */     return this.proxiesByKey.remove(key);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HashSet getNullifiableEntityKeys()
/*      */   {
/*  944 */     return this.nullifiableEntityKeys;
/*      */   }
/*      */   
/*      */   public Map getEntitiesByKey() {
/*  948 */     return this.entitiesByKey;
/*      */   }
/*      */   
/*      */   public Map getEntityEntries() {
/*  952 */     return this.entityEntries;
/*      */   }
/*      */   
/*      */   public Map getCollectionEntries() {
/*  956 */     return this.collectionEntries;
/*      */   }
/*      */   
/*      */   public Map getCollectionsByKey() {
/*  960 */     return this.collectionsByKey;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getCascadeLevel()
/*      */   {
/*  980 */     return this.cascading;
/*      */   }
/*      */   
/*      */   public int incrementCascadeLevel() {
/*  984 */     return ++this.cascading;
/*      */   }
/*      */   
/*      */   public int decrementCascadeLevel() {
/*  988 */     return --this.cascading;
/*      */   }
/*      */   
/*      */   public boolean isFlushing() {
/*  992 */     return this.flushing;
/*      */   }
/*      */   
/*      */   public void setFlushing(boolean flushing) {
/*  996 */     this.flushing = flushing;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void beforeLoad()
/*      */   {
/* 1003 */     this.loadCounter += 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void afterLoad()
/*      */   {
/* 1010 */     this.loadCounter -= 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1019 */     return "PersistenceContext[entityKeys=" + this.entitiesByKey.keySet() + ",collectionKeys=" + this.collectionsByKey.keySet() + "]";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Serializable getOwnerId(String entity, String property, Object childEntity, Map mergeMap)
/*      */   {
/* 1035 */     EntityPersister persister = this.session.getFactory().getEntityPersister(entity);
/*      */     
/* 1037 */     CollectionPersister collectionPersister = this.session.getFactory().getCollectionPersister(entity + '.' + property);
/*      */     
/*      */ 
/* 1040 */     Iterator entities = this.entityEntries.entrySet().iterator();
/* 1041 */     while (entities.hasNext()) {
/* 1042 */       Map.Entry me = (Map.Entry)entities.next();
/* 1043 */       EntityEntry ee = (EntityEntry)me.getValue();
/* 1044 */       if (persister.isSubclassEntityName(ee.getEntityName())) {
/* 1045 */         Object instance = me.getKey();
/*      */         
/*      */ 
/* 1048 */         boolean found = isFoundInParent(property, childEntity, persister, collectionPersister, instance);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1056 */         if ((!found) && (mergeMap != null))
/*      */         {
/* 1058 */           Object unmergedInstance = mergeMap.get(instance);
/* 1059 */           Object unmergedChild = mergeMap.get(childEntity);
/* 1060 */           if ((unmergedInstance != null) && (unmergedChild != null)) {
/* 1061 */             found = isFoundInParent(property, unmergedChild, persister, collectionPersister, unmergedInstance);
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1071 */         if (found) {
/* 1072 */           return ee.getId();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1077 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isFoundInParent(String property, Object childEntity, EntityPersister persister, CollectionPersister collectionPersister, Object potentialParent)
/*      */   {
/* 1087 */     Object collection = persister.getPropertyValue(potentialParent, property, this.session.getEntityMode());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1092 */     return (collection != null) && (Hibernate.isInitialized(collection)) && (collectionPersister.getCollectionType().contains(collection, childEntity, this.session));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getIndexInOwner(String entity, String property, Object childEntity, Map mergeMap)
/*      */   {
/* 1103 */     EntityPersister persister = this.session.getFactory().getEntityPersister(entity);
/*      */     
/* 1105 */     CollectionPersister cp = this.session.getFactory().getCollectionPersister(entity + '.' + property);
/*      */     
/* 1107 */     Iterator entities = this.entityEntries.entrySet().iterator();
/* 1108 */     while (entities.hasNext()) {
/* 1109 */       Map.Entry me = (Map.Entry)entities.next();
/* 1110 */       EntityEntry ee = (EntityEntry)me.getValue();
/* 1111 */       if (persister.isSubclassEntityName(ee.getEntityName())) {
/* 1112 */         Object instance = me.getKey();
/*      */         
/* 1114 */         Object index = getIndexInParent(property, childEntity, persister, cp, instance);
/*      */         
/* 1116 */         if ((index == null) && (mergeMap != null)) {
/* 1117 */           Object unmergedInstance = mergeMap.get(instance);
/* 1118 */           Object unmergedChild = mergeMap.get(childEntity);
/* 1119 */           if ((unmergedInstance != null) && (unmergedChild != null)) {
/* 1120 */             index = getIndexInParent(property, unmergedChild, persister, cp, unmergedInstance);
/*      */           }
/*      */         }
/*      */         
/* 1124 */         if (index != null) return index;
/*      */       }
/*      */     }
/* 1127 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Object getIndexInParent(String property, Object childEntity, EntityPersister persister, CollectionPersister collectionPersister, Object potentialParent)
/*      */   {
/* 1137 */     Object collection = persister.getPropertyValue(potentialParent, property, this.session.getEntityMode());
/* 1138 */     if ((collection != null) && (Hibernate.isInitialized(collection))) {
/* 1139 */       return collectionPersister.getCollectionType().indexOf(collection, childEntity);
/*      */     }
/*      */     
/* 1142 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addNullProperty(EntityKey ownerKey, String propertyName)
/*      */   {
/* 1151 */     this.nullAssociations.add(new AssociationKey(ownerKey, propertyName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isPropertyNull(EntityKey ownerKey, String propertyName)
/*      */   {
/* 1158 */     return this.nullAssociations.contains(new AssociationKey(ownerKey, propertyName));
/*      */   }
/*      */   
/*      */   private void clearNullProperties() {
/* 1162 */     this.nullAssociations.clear();
/*      */   }
/*      */   
/*      */   public void setReadOnly(Object entity, boolean readOnly) {
/* 1166 */     EntityEntry entry = getEntry(entity);
/* 1167 */     if (entry == null) {
/* 1168 */       throw new TransientObjectException("Instance was not associated with the session");
/*      */     }
/* 1170 */     entry.setReadOnly(readOnly, entity);
/* 1171 */     this.hasNonReadOnlyEntities = ((this.hasNonReadOnlyEntities) || (!readOnly));
/*      */   }
/*      */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\StatefulPersistenceContext.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */