/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterBinder
/*     */ {
/*  25 */   private static final Log log = LogFactory.getLog(ParameterBinder.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int bindQueryParameters(PreparedStatement st, QueryParameters queryParameters, int start, NamedParameterSource source, SessionImplementor session)
/*     */     throws SQLException, HibernateException
/*     */   {
/*  40 */     int col = start;
/*  41 */     col += bindPositionalParameters(st, queryParameters, col, session);
/*  42 */     col += bindNamedParameters(st, queryParameters, col, source, session);
/*  43 */     return col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static int bindPositionalParameters(PreparedStatement st, QueryParameters queryParameters, int start, SessionImplementor session)
/*     */     throws SQLException, HibernateException
/*     */   {
/*  51 */     return bindPositionalParameters(st, queryParameters.getPositionalParameterValues(), queryParameters.getPositionalParameterTypes(), start, session);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int bindPositionalParameters(PreparedStatement st, Object[] values, Type[] types, int start, SessionImplementor session)
/*     */     throws SQLException, HibernateException
/*     */   {
/*  66 */     int span = 0;
/*  67 */     for (int i = 0; i < values.length; i++) {
/*  68 */       types[i].nullSafeSet(st, values[i], start + span, session);
/*  69 */       span += types[i].getColumnSpan(session.getFactory());
/*     */     }
/*  71 */     return span;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int bindNamedParameters(PreparedStatement ps, QueryParameters queryParameters, int start, NamedParameterSource source, SessionImplementor session)
/*     */     throws SQLException, HibernateException
/*     */   {
/*  80 */     return bindNamedParameters(ps, queryParameters.getNamedParameters(), start, source, session);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int bindNamedParameters(PreparedStatement ps, Map namedParams, int start, NamedParameterSource source, SessionImplementor session)
/*     */     throws SQLException, HibernateException
/*     */   {
/*  89 */     if (namedParams != null)
/*     */     {
/*  91 */       Iterator iter = namedParams.entrySet().iterator();
/*  92 */       int result = 0;
/*  93 */       while (iter.hasNext()) {
/*  94 */         Map.Entry e = (Map.Entry)iter.next();
/*  95 */         String name = (String)e.getKey();
/*  96 */         TypedValue typedval = (TypedValue)e.getValue();
/*  97 */         int[] locations = source.getNamedParameterLocations(name);
/*  98 */         for (int i = 0; i < locations.length; i++) {
/*  99 */           if (log.isDebugEnabled()) {
/* 100 */             log.debug("bindNamedParameters() " + typedval.getValue() + " -> " + name + " [" + (locations[i] + start) + "]");
/*     */           }
/*     */           
/*     */ 
/* 104 */           typedval.getType().nullSafeSet(ps, typedval.getValue(), locations[i] + start, session);
/*     */         }
/* 106 */         result += locations.length;
/*     */       }
/* 108 */       return result;
/*     */     }
/*     */     
/* 111 */     return 0;
/*     */   }
/*     */   
/*     */   public static abstract interface NamedParameterSource
/*     */   {
/*     */     public abstract int[] getNamedParameterLocations(String paramString);
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\ParameterBinder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */