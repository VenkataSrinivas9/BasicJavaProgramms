/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.util.ArrayHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CascadeStyle
/*     */   implements Serializable
/*     */ {
/*     */   public boolean reallyDoCascade(CascadingAction action)
/*     */   {
/*  28 */     return doCascade(action);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean hasOrphanDelete()
/*     */   {
/*  35 */     return false;
/*     */   }
/*     */   
/*     */   public static final class MultipleCascadeStyle extends CascadeStyle {
/*     */     private final CascadeStyle[] styles;
/*     */     
/*  41 */     public MultipleCascadeStyle(CascadeStyle[] styles) { this.styles = styles; }
/*     */     
/*     */     public boolean doCascade(CascadingAction action) {
/*  44 */       for (int i = 0; i < this.styles.length; i++) {
/*  45 */         if (this.styles[i].doCascade(action)) return true;
/*     */       }
/*  47 */       return false;
/*     */     }
/*     */     
/*  50 */     public boolean reallyDoCascade(CascadingAction action) { for (int i = 0; i < this.styles.length; i++) {
/*  51 */         if (this.styles[i].reallyDoCascade(action)) return true;
/*     */       }
/*  53 */       return false;
/*     */     }
/*     */     
/*  56 */     public boolean hasOrphanDelete() { for (int i = 0; i < this.styles.length; i++) {
/*  57 */         if (this.styles[i].hasOrphanDelete()) return true;
/*     */       }
/*  59 */       return false;
/*     */     }
/*     */     
/*  62 */     public String toString() { return ArrayHelper.toString(this.styles); }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */   public static final CascadeStyle ALL_DELETE_ORPHAN = new CascadeStyle() {
/*     */     public boolean doCascade(CascadingAction action) {
/*  71 */       return true;
/*     */     }
/*     */     
/*  74 */     public boolean hasOrphanDelete() { return true; }
/*     */     
/*     */     public String toString() {
/*  77 */       return "STYLE_ALL_DELETE_ORPHAN";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  84 */   public static final CascadeStyle ALL = new CascadeStyle() {
/*     */     public boolean doCascade(CascadingAction action) {
/*  86 */       return true;
/*     */     }
/*     */     
/*  89 */     public String toString() { return "STYLE_ALL"; }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */   public static final CascadeStyle UPDATE = new CascadeStyle() {
/*     */     public boolean doCascade(CascadingAction action) {
/*  98 */       return (action == CascadingAction.SAVE_UPDATE) || (action == CascadingAction.SAVE_UPDATE_COPY);
/*     */     }
/*     */     
/* 101 */     public String toString() { return "STYLE_SAVE_UPDATE"; }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 108 */   public static final CascadeStyle LOCK = new CascadeStyle() {
/*     */     public boolean doCascade(CascadingAction action) {
/* 110 */       return action == CascadingAction.LOCK;
/*     */     }
/*     */     
/* 113 */     public String toString() { return "STYLE_LOCK"; }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */   public static final CascadeStyle REFRESH = new CascadeStyle() {
/*     */     public boolean doCascade(CascadingAction action) {
/* 122 */       return action == CascadingAction.REFRESH;
/*     */     }
/*     */     
/* 125 */     public String toString() { return "STYLE_REFRESH"; }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 132 */   public static final CascadeStyle EVICT = new CascadeStyle() {
/*     */     public boolean doCascade(CascadingAction action) {
/* 134 */       return action == CascadingAction.EVICT;
/*     */     }
/*     */     
/* 137 */     public String toString() { return "STYLE_EVICT"; }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 144 */   public static final CascadeStyle REPLICATE = new CascadeStyle() {
/*     */     public boolean doCascade(CascadingAction action) {
/* 146 */       return action == CascadingAction.REPLICATE;
/*     */     }
/*     */     
/* 149 */     public String toString() { return "STYLE_REPLICATE"; }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 155 */   public static final CascadeStyle MERGE = new CascadeStyle() {
/*     */     public boolean doCascade(CascadingAction action) {
/* 157 */       return action == CascadingAction.MERGE;
/*     */     }
/*     */     
/* 160 */     public String toString() { return "STYLE_MERGE"; }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 167 */   public static final CascadeStyle PERSIST = new CascadeStyle() {
/*     */     public boolean doCascade(CascadingAction action) {
/* 169 */       return (action == CascadingAction.PERSIST) || (action == CascadingAction.PERSIST_ON_FLUSH);
/*     */     }
/*     */     
/*     */     public String toString() {
/* 173 */       return "STYLE_PERSIST";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 180 */   public static final CascadeStyle DELETE = new CascadeStyle() {
/*     */     public boolean doCascade(CascadingAction action) {
/* 182 */       return action == CascadingAction.DELETE;
/*     */     }
/*     */     
/* 185 */     public String toString() { return "STYLE_DELETE"; }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 192 */   public static final CascadeStyle DELETE_ORPHAN = new CascadeStyle() {
/*     */     public boolean doCascade(CascadingAction action) {
/* 194 */       return (action == CascadingAction.DELETE) || (action == CascadingAction.SAVE_UPDATE);
/*     */     }
/*     */     
/* 197 */     public boolean reallyDoCascade(CascadingAction action) { return action == CascadingAction.DELETE; }
/*     */     
/*     */     public boolean hasOrphanDelete() {
/* 200 */       return true;
/*     */     }
/*     */     
/* 203 */     public String toString() { return "STYLE_DELETE_ORPHAN"; }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 210 */   public static final CascadeStyle NONE = new CascadeStyle() {
/*     */     public boolean doCascade(CascadingAction action) {
/* 212 */       return false;
/*     */     }
/*     */     
/* 215 */     public String toString() { return "STYLE_NONE"; }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 221 */   static final Map STYLES = new HashMap();
/*     */   
/* 223 */   static { STYLES.put("all", ALL);
/* 224 */     STYLES.put("all-delete-orphan", ALL_DELETE_ORPHAN);
/* 225 */     STYLES.put("save-update", UPDATE);
/* 226 */     STYLES.put("persist", PERSIST);
/* 227 */     STYLES.put("merge", MERGE);
/* 228 */     STYLES.put("lock", LOCK);
/* 229 */     STYLES.put("refresh", REFRESH);
/* 230 */     STYLES.put("replicate", REPLICATE);
/* 231 */     STYLES.put("evict", EVICT);
/* 232 */     STYLES.put("delete", DELETE);
/* 233 */     STYLES.put("delete-orphan", DELETE_ORPHAN);
/* 234 */     STYLES.put("none", NONE);
/*     */   }
/*     */   
/*     */   public static CascadeStyle getCascadeStyle(String cascade) {
/* 238 */     CascadeStyle style = (CascadeStyle)STYLES.get(cascade);
/* 239 */     if (style == null) {
/* 240 */       throw new MappingException("Unsupported cascade style: " + cascade);
/*     */     }
/*     */     
/* 243 */     return style;
/*     */   }
/*     */   
/*     */   public abstract boolean doCascade(CascadingAction paramCascadingAction);
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\CascadeStyle.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */