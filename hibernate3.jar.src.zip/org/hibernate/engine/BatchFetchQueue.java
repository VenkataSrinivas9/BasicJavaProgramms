/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.collections.SequencedHashMap;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.collection.PersistentCollection;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.MarkerObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BatchFetchQueue
/*     */ {
/*  25 */   public static final Object MARKER = new MarkerObject("MARKER");
/*     */   
/*     */ 
/*     */ 
/*  29 */   private final Map batchLoadableEntityKeys = new SequencedHashMap(8);
/*     */   
/*     */ 
/*  32 */   private final Map subselectsByEntityKey = new HashMap(8);
/*     */   
/*     */   private final PersistenceContext context;
/*     */   
/*     */   public BatchFetchQueue(PersistenceContext context)
/*     */   {
/*  38 */     this.context = context;
/*     */   }
/*     */   
/*     */   public void clear() {
/*  42 */     this.batchLoadableEntityKeys.clear();
/*  43 */     this.subselectsByEntityKey.clear();
/*     */   }
/*     */   
/*     */   public SubselectFetch getSubselect(EntityKey key) {
/*  47 */     return (SubselectFetch)this.subselectsByEntityKey.get(key);
/*     */   }
/*     */   
/*     */   public void addSubselect(EntityKey key, SubselectFetch subquery) {
/*  51 */     this.subselectsByEntityKey.put(key, subquery);
/*     */   }
/*     */   
/*     */   public void clearSubselects() {
/*  55 */     this.subselectsByEntityKey.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeBatchLoadableEntityKey(EntityKey key)
/*     */   {
/*  64 */     if (key.isBatchLoadable()) { this.batchLoadableEntityKeys.remove(key);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeSubselect(EntityKey key)
/*     */   {
/*  74 */     this.subselectsByEntityKey.remove(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addBatchLoadableEntityKey(EntityKey key)
/*     */   {
/*  82 */     if (key.isBatchLoadable()) { this.batchLoadableEntityKeys.put(key, MARKER);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Serializable[] getCollectionBatch(CollectionPersister collectionPersister, Serializable id, int batchSize, EntityMode entityMode)
/*     */   {
/*  98 */     Serializable[] keys = new Serializable[batchSize];
/*  99 */     keys[0] = id;
/* 100 */     int i = 1;
/*     */     
/* 102 */     int end = -1;
/* 103 */     boolean checkForEnd = false;
/*     */     
/*     */ 
/*     */ 
/* 107 */     Iterator iter = this.context.getCollectionEntries().entrySet().iterator();
/* 108 */     while (iter.hasNext()) {
/* 109 */       Map.Entry me = (Map.Entry)iter.next();
/*     */       
/* 111 */       CollectionEntry ce = (CollectionEntry)me.getValue();
/* 112 */       PersistentCollection collection = (PersistentCollection)me.getKey();
/* 113 */       if ((!collection.wasInitialized()) && (ce.getLoadedPersister() == collectionPersister))
/*     */       {
/* 115 */         if ((checkForEnd) && (i == end)) { return keys;
/*     */         }
/*     */         
/*     */ 
/* 119 */         boolean isEqual = collectionPersister.getKeyType().isEqual(id, ce.getLoadedKey(), entityMode, collectionPersister.getFactory());
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 126 */         if (isEqual) {
/* 127 */           end = i;
/*     */         }
/*     */         else
/*     */         {
/* 131 */           keys[(i++)] = ce.getLoadedKey();
/*     */         }
/*     */         
/*     */ 
/* 135 */         if (i == batchSize) {
/* 136 */           i = 1;
/* 137 */           if (end != -1) { checkForEnd = true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 142 */     return keys;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Serializable[] getEntityBatch(EntityPersister persister, Serializable id, int batchSize, EntityMode entityMode)
/*     */   {
/* 161 */     Serializable[] ids = new Serializable[batchSize];
/* 162 */     ids[0] = id;
/* 163 */     int i = 1;
/* 164 */     int end = -1;
/* 165 */     boolean checkForEnd = false;
/*     */     
/* 167 */     Iterator iter = this.batchLoadableEntityKeys.keySet().iterator();
/* 168 */     while (iter.hasNext())
/*     */     {
/* 170 */       EntityKey key = (EntityKey)iter.next();
/* 171 */       if (key.getEntityName().equals(persister.getEntityName()))
/*     */       {
/* 173 */         if ((checkForEnd) && (i == end)) { return ids;
/*     */         }
/*     */         
/*     */ 
/* 177 */         if (persister.getIdentifierType().isEqual(id, key.getIdentifier(), entityMode)) {
/* 178 */           end = i;
/*     */         }
/*     */         else
/*     */         {
/* 182 */           ids[(i++)] = key.getIdentifier();
/*     */         }
/*     */         
/*     */ 
/* 186 */         if (i == batchSize) {
/* 187 */           i = 1;
/* 188 */           if (end != -1) { checkForEnd = true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 194 */     return ids;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\BatchFetchQueue.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */