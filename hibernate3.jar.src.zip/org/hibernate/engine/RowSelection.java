/*    */ package org.hibernate.engine;
/*    */ 
/*    */ 
/*    */ public final class RowSelection
/*    */ {
/*    */   private Integer firstRow;
/*    */   
/*    */   private Integer maxRows;
/*    */   
/*    */   private Integer timeout;
/*    */   private Integer fetchSize;
/*    */   
/*    */   public void setFirstRow(Integer firstRow)
/*    */   {
/* 15 */     this.firstRow = firstRow;
/*    */   }
/*    */   
/*    */   public Integer getFirstRow() {
/* 19 */     return this.firstRow;
/*    */   }
/*    */   
/*    */   public void setMaxRows(Integer maxRows) {
/* 23 */     this.maxRows = maxRows;
/*    */   }
/*    */   
/*    */   public Integer getMaxRows() {
/* 27 */     return this.maxRows;
/*    */   }
/*    */   
/*    */   public void setTimeout(Integer timeout) {
/* 31 */     this.timeout = timeout;
/*    */   }
/*    */   
/*    */   public Integer getTimeout() {
/* 35 */     return this.timeout;
/*    */   }
/*    */   
/*    */   public Integer getFetchSize() {
/* 39 */     return this.fetchSize;
/*    */   }
/*    */   
/*    */   public void setFetchSize(Integer fetchSize) {
/* 43 */     this.fetchSize = fetchSize;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\RowSelection.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */