/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.persister.collection.QueryableCollection;
/*     */ import org.hibernate.persister.entity.Joinable;
/*     */ import org.hibernate.sql.JoinFragment;
/*     */ import org.hibernate.sql.QueryJoinFragment;
/*     */ import org.hibernate.type.AssociationType;
/*     */ import org.hibernate.util.CollectionHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JoinSequence
/*     */ {
/*     */   private final SessionFactoryImplementor factory;
/*  22 */   private final List joins = new ArrayList();
/*  23 */   private boolean useThetaStyle = false;
/*  24 */   private final StringBuffer conditions = new StringBuffer();
/*     */   private String rootAlias;
/*     */   private Joinable rootJoinable;
/*     */   private Selector selector;
/*     */   private JoinSequence next;
/*  29 */   private boolean isFromPart = false;
/*     */   
/*     */   public String toString() {
/*  32 */     StringBuffer buf = new StringBuffer();
/*  33 */     buf.append("JoinSequence{");
/*  34 */     if (this.rootJoinable != null) {
/*  35 */       buf.append(this.rootJoinable).append('[').append(this.rootAlias).append(']');
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  40 */     for (int i = 0; i < this.joins.size(); i++) {
/*  41 */       buf.append("->").append(this.joins.get(i));
/*     */     }
/*  43 */     return '}';
/*     */   }
/*     */   
/*     */   public static abstract interface Selector {
/*     */     public abstract boolean includeSubclasses(String paramString);
/*     */   }
/*     */   
/*     */   final class Join { private final AssociationType associationType;
/*     */     private final Joinable joinable;
/*     */     private final int joinType;
/*     */     private final String alias;
/*     */     private final String[] lhsColumns;
/*     */     
/*  56 */     Join(AssociationType associationType, String alias, int joinType, String[] lhsColumns) throws MappingException { this.associationType = associationType;
/*  57 */       this.joinable = associationType.getAssociatedJoinable(JoinSequence.this.factory);
/*  58 */       this.alias = alias;
/*  59 */       this.joinType = joinType;
/*  60 */       this.lhsColumns = lhsColumns;
/*     */     }
/*     */     
/*     */     String getAlias() {
/*  64 */       return this.alias;
/*     */     }
/*     */     
/*     */     AssociationType getAssociationType() {
/*  68 */       return this.associationType;
/*     */     }
/*     */     
/*     */     Joinable getJoinable() {
/*  72 */       return this.joinable;
/*     */     }
/*     */     
/*     */     int getJoinType() {
/*  76 */       return this.joinType;
/*     */     }
/*     */     
/*     */     String[] getLHSColumns() {
/*  80 */       return this.lhsColumns;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  84 */       return this.joinable.toString() + '[' + this.alias + ']';
/*     */     }
/*     */   }
/*     */   
/*     */   public JoinSequence(SessionFactoryImplementor factory) {
/*  89 */     this.factory = factory;
/*     */   }
/*     */   
/*     */   public JoinSequence getFromPart() {
/*  93 */     JoinSequence fromPart = new JoinSequence(this.factory);
/*  94 */     fromPart.joins.addAll(this.joins);
/*  95 */     fromPart.useThetaStyle = this.useThetaStyle;
/*  96 */     fromPart.rootAlias = this.rootAlias;
/*  97 */     fromPart.rootJoinable = this.rootJoinable;
/*  98 */     fromPart.selector = this.selector;
/*  99 */     fromPart.next = (this.next == null ? null : this.next.getFromPart());
/* 100 */     fromPart.isFromPart = true;
/* 101 */     return fromPart;
/*     */   }
/*     */   
/*     */   public JoinSequence copy() {
/* 105 */     JoinSequence copy = new JoinSequence(this.factory);
/* 106 */     copy.joins.addAll(this.joins);
/* 107 */     copy.useThetaStyle = this.useThetaStyle;
/* 108 */     copy.rootAlias = this.rootAlias;
/* 109 */     copy.rootJoinable = this.rootJoinable;
/* 110 */     copy.selector = this.selector;
/* 111 */     copy.next = (this.next == null ? null : this.next.copy());
/* 112 */     copy.isFromPart = this.isFromPart;
/* 113 */     copy.conditions.append(this.conditions.toString());
/* 114 */     return copy;
/*     */   }
/*     */   
/*     */   public JoinSequence addJoin(AssociationType associationType, String alias, int joinType, String[] referencingKey) throws MappingException
/*     */   {
/* 119 */     this.joins.add(new Join(associationType, alias, joinType, referencingKey));
/* 120 */     return this;
/*     */   }
/*     */   
/*     */   public JoinFragment toJoinFragment() throws MappingException {
/* 124 */     return toJoinFragment(CollectionHelper.EMPTY_MAP, true);
/*     */   }
/*     */   
/*     */   public JoinFragment toJoinFragment(Map enabledFilters, boolean includeExtraJoins) throws MappingException {
/* 128 */     return toJoinFragment(enabledFilters, includeExtraJoins, null);
/*     */   }
/*     */   
/*     */   public JoinFragment toJoinFragment(Map enabledFilters, boolean includeExtraJoins, String extraOnClause) throws MappingException {
/* 132 */     QueryJoinFragment joinFragment = new QueryJoinFragment(this.factory.getDialect(), this.useThetaStyle);
/* 133 */     if (this.rootJoinable != null) {
/* 134 */       joinFragment.addCrossJoin(this.rootJoinable.getTableName(), this.rootAlias);
/* 135 */       String filterCondition = this.rootJoinable.filterFragment(this.rootAlias, enabledFilters);
/*     */       
/*     */ 
/*     */ 
/* 139 */       joinFragment.setHasFilterCondition(joinFragment.addCondition(filterCondition));
/* 140 */       if (includeExtraJoins) {
/* 141 */         addExtraJoins(joinFragment, this.rootAlias, this.rootJoinable, true);
/*     */       }
/*     */     }
/*     */     
/* 145 */     Joinable last = this.rootJoinable;
/*     */     
/* 147 */     for (int i = 0; i < this.joins.size(); i++) {
/* 148 */       Join join = (Join)this.joins.get(i);
/* 149 */       String on = join.getAssociationType().getOnCondition(join.getAlias(), this.factory, enabledFilters);
/* 150 */       String condition = null;
/* 151 */       if ((last != null) && (isManyToManyRoot(last)) && (((QueryableCollection)last).getElementType() == join.getAssociationType()))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 157 */         String manyToManyFilter = ((QueryableCollection)last).getManyToManyFilterFragment(join.getAlias(), enabledFilters);
/*     */         
/* 159 */         condition = on + " and " + manyToManyFilter;
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 166 */         condition = on;
/*     */       }
/* 168 */       if (extraOnClause != null) {
/* 169 */         condition = condition + " and " + extraOnClause;
/*     */       }
/* 171 */       joinFragment.addJoin(join.getJoinable().getTableName(), join.getAlias(), join.getLHSColumns(), JoinHelper.getRHSColumnNames(join.getAssociationType(), this.factory), join.joinType, condition);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 179 */       if (includeExtraJoins) {
/* 180 */         addExtraJoins(joinFragment, join.getAlias(), join.getJoinable(), join.joinType == 0);
/*     */       }
/* 182 */       last = join.getJoinable();
/*     */     }
/* 184 */     if (this.next != null) {
/* 185 */       joinFragment.addFragment(this.next.toJoinFragment(enabledFilters, includeExtraJoins));
/*     */     }
/* 187 */     joinFragment.addCondition(this.conditions.toString());
/* 188 */     if (this.isFromPart) joinFragment.clearWherePart();
/* 189 */     return joinFragment;
/*     */   }
/*     */   
/*     */   private boolean isManyToManyRoot(Joinable joinable) {
/* 193 */     if ((joinable != null) && (joinable.isCollection())) {
/* 194 */       QueryableCollection persister = (QueryableCollection)joinable;
/* 195 */       return persister.isManyToMany();
/*     */     }
/* 197 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isIncluded(String alias) {
/* 201 */     return (this.selector != null) && (this.selector.includeSubclasses(alias));
/*     */   }
/*     */   
/*     */   private void addExtraJoins(JoinFragment joinFragment, String alias, Joinable joinable, boolean innerJoin) {
/* 205 */     boolean include = isIncluded(alias);
/* 206 */     joinFragment.addJoins(joinable.fromJoinFragment(alias, innerJoin, include), joinable.whereJoinFragment(alias, innerJoin, include));
/*     */   }
/*     */   
/*     */   public JoinSequence addCondition(String condition)
/*     */   {
/* 211 */     if (condition.trim().length() != 0) {
/* 212 */       if (!condition.startsWith(" and ")) this.conditions.append(" and ");
/* 213 */       this.conditions.append(condition);
/*     */     }
/* 215 */     return this;
/*     */   }
/*     */   
/*     */   public JoinSequence addCondition(String alias, String[] columns, String condition) {
/* 219 */     for (int i = 0; i < columns.length; i++) {
/* 220 */       this.conditions.append(" and ").append(alias).append('.').append(columns[i]).append(condition);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 226 */     return this;
/*     */   }
/*     */   
/*     */   public JoinSequence setRoot(Joinable joinable, String alias) {
/* 230 */     this.rootAlias = alias;
/* 231 */     this.rootJoinable = joinable;
/* 232 */     return this;
/*     */   }
/*     */   
/*     */   public JoinSequence setNext(JoinSequence next) {
/* 236 */     this.next = next;
/* 237 */     return this;
/*     */   }
/*     */   
/*     */   public JoinSequence setSelector(Selector s) {
/* 241 */     this.selector = s;
/* 242 */     return this;
/*     */   }
/*     */   
/*     */   public JoinSequence setUseThetaStyle(boolean useThetaStyle) {
/* 246 */     this.useThetaStyle = useThetaStyle;
/* 247 */     return this;
/*     */   }
/*     */   
/*     */   public boolean isThetaStyle() {
/* 251 */     return this.useThetaStyle;
/*     */   }
/*     */   
/*     */   public int getJoinCount() {
/* 255 */     return this.joins.size();
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\JoinSequence.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */