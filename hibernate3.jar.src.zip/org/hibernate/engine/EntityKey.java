/*    */ package org.hibernate.engine;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.AssertionFailure;
/*    */ import org.hibernate.EntityMode;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ import org.hibernate.pretty.MessageHelper;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EntityKey
/*    */   implements Serializable
/*    */ {
/*    */   private final Serializable identifier;
/*    */   private final Serializable rootEntityName;
/*    */   private final String entityName;
/*    */   private final Type identifierType;
/*    */   private final boolean isBatchLoadable;
/*    */   private final SessionFactoryImplementor factory;
/*    */   private final int hashCode;
/*    */   private final EntityMode entityMode;
/*    */   
/*    */   public EntityKey(Serializable id, EntityPersister persister, EntityMode entityMode)
/*    */   {
/* 34 */     if (id == null) throw new AssertionFailure("null identifier");
/* 35 */     this.identifier = id;
/* 36 */     this.entityMode = entityMode;
/* 37 */     this.rootEntityName = persister.getRootEntityName();
/* 38 */     this.entityName = persister.getEntityName();
/* 39 */     this.identifierType = persister.getIdentifierType();
/* 40 */     this.isBatchLoadable = persister.isBatchLoadable();
/* 41 */     this.factory = persister.getFactory();
/* 42 */     this.hashCode = getHashCode();
/*    */   }
/*    */   
/*    */   public boolean isBatchLoadable() {
/* 46 */     return this.isBatchLoadable;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Serializable getIdentifier()
/*    */   {
/* 53 */     return this.identifier;
/*    */   }
/*    */   
/*    */   public String getEntityName() {
/* 57 */     return this.entityName;
/*    */   }
/*    */   
/*    */   public boolean equals(Object other) {
/* 61 */     EntityKey otherKey = (EntityKey)other;
/* 62 */     return (otherKey.rootEntityName.equals(this.rootEntityName)) && (this.identifierType.isEqual(otherKey.identifier, this.identifier, this.entityMode, this.factory));
/*    */   }
/*    */   
/*    */   private int getHashCode()
/*    */   {
/* 67 */     int result = 17;
/* 68 */     result = 37 * result + this.rootEntityName.hashCode();
/* 69 */     result = 37 * result + this.identifierType.getHashCode(this.identifier, this.entityMode, this.factory);
/* 70 */     return result;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 74 */     return this.hashCode;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 78 */     return "EntityKey" + MessageHelper.infoString(this.factory.getEntityPersister(this.entityName), this.identifier, this.factory);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\EntityKey.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */