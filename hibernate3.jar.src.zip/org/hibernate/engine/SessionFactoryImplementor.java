package org.hibernate.engine;

import java.sql.Connection;
import java.util.Map;
import java.util.Set;
import javax.transaction.TransactionManager;
import org.hibernate.ConnectionReleaseMode;
import org.hibernate.HibernateException;
import org.hibernate.Interceptor;
import org.hibernate.MappingException;
import org.hibernate.SessionFactory;
import org.hibernate.cache.Cache;
import org.hibernate.cache.QueryCache;
import org.hibernate.cache.UpdateTimestampsCache;
import org.hibernate.cfg.Settings;
import org.hibernate.classic.Session;
import org.hibernate.connection.ConnectionProvider;
import org.hibernate.dialect.Dialect;
import org.hibernate.engine.query.QueryPlanCache;
import org.hibernate.exception.SQLExceptionConverter;
import org.hibernate.id.IdentifierGenerator;
import org.hibernate.persister.collection.CollectionPersister;
import org.hibernate.persister.entity.EntityPersister;
import org.hibernate.stat.StatisticsImplementor;
import org.hibernate.type.Type;

public abstract interface SessionFactoryImplementor
  extends Mapping, SessionFactory
{
  public abstract EntityPersister getEntityPersister(String paramString)
    throws MappingException;
  
  public abstract CollectionPersister getCollectionPersister(String paramString)
    throws MappingException;
  
  public abstract Dialect getDialect();
  
  public abstract Interceptor getInterceptor();
  
  public abstract QueryPlanCache getQueryPlanCache();
  
  public abstract Type[] getReturnTypes(String paramString)
    throws HibernateException;
  
  public abstract String[] getReturnAliases(String paramString)
    throws HibernateException;
  
  public abstract ConnectionProvider getConnectionProvider();
  
  public abstract String[] getImplementors(String paramString)
    throws MappingException;
  
  public abstract String getImportedClassName(String paramString);
  
  public abstract TransactionManager getTransactionManager();
  
  public abstract QueryCache getQueryCache();
  
  public abstract QueryCache getQueryCache(String paramString)
    throws HibernateException;
  
  public abstract UpdateTimestampsCache getUpdateTimestampsCache();
  
  public abstract StatisticsImplementor getStatisticsImplementor();
  
  public abstract NamedQueryDefinition getNamedQuery(String paramString);
  
  public abstract NamedSQLQueryDefinition getNamedSQLQuery(String paramString);
  
  public abstract ResultSetMappingDefinition getResultSetMapping(String paramString);
  
  public abstract IdentifierGenerator getIdentifierGenerator(String paramString);
  
  public abstract Cache getSecondLevelCacheRegion(String paramString);
  
  public abstract Map getAllSecondLevelCacheRegions();
  
  public abstract SQLExceptionConverter getSQLExceptionConverter();
  
  public abstract Settings getSettings();
  
  public abstract Session openTemporarySession()
    throws HibernateException;
  
  public abstract Session openSession(Connection paramConnection, boolean paramBoolean1, boolean paramBoolean2, ConnectionReleaseMode paramConnectionReleaseMode)
    throws HibernateException;
  
  public abstract Set getCollectionRolesByEntityParticipant(String paramString);
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\SessionFactoryImplementor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */