/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.cfg.Settings;
/*     */ import org.hibernate.collection.PersistentCollection;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.pretty.MessageHelper;
/*     */ import org.hibernate.type.CollectionType;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Collections
/*     */ {
/*  24 */   private static final Log log = LogFactory.getLog(Collections.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void processUnreachableCollection(PersistentCollection coll, SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/*  35 */     if (coll.getOwner() == null) {
/*  36 */       processNeverReferencedCollection(coll, session);
/*     */     }
/*     */     else {
/*  39 */       processDereferencedCollection(coll, session);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static void processDereferencedCollection(PersistentCollection coll, SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/*  47 */     PersistenceContext persistenceContext = session.getPersistenceContext();
/*  48 */     CollectionEntry entry = persistenceContext.getCollectionEntry(coll);
/*  49 */     CollectionPersister loadedPersister = entry.getLoadedPersister();
/*     */     
/*  51 */     if ((log.isDebugEnabled()) && (loadedPersister != null)) {
/*  52 */       log.debug("Collection dereferenced: " + MessageHelper.collectionInfoString(loadedPersister, entry.getLoadedKey(), session.getFactory()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  62 */     boolean hasOrphanDelete = (loadedPersister != null) && (loadedPersister.hasOrphanDelete());
/*     */     
/*  64 */     if (hasOrphanDelete) {
/*  65 */       Serializable ownerId = loadedPersister.getOwnerEntityPersister().getIdentifier(coll.getOwner(), session.getEntityMode());
/*     */       
/*  67 */       if (ownerId == null)
/*     */       {
/*     */ 
/*     */ 
/*  71 */         if (session.getFactory().getSettings().isIdentifierRollbackEnabled()) {
/*  72 */           EntityEntry ownerEntry = persistenceContext.getEntry(coll.getOwner());
/*  73 */           if (ownerEntry != null) {
/*  74 */             ownerId = ownerEntry.getId();
/*     */           }
/*     */         }
/*  77 */         if (ownerId == null) {
/*  78 */           throw new AssertionFailure("Unable to determine collection owner identifier for orphan-delete processing");
/*     */         }
/*     */       }
/*  81 */       EntityKey key = new EntityKey(ownerId, loadedPersister.getOwnerEntityPersister(), session.getEntityMode());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  86 */       Object owner = persistenceContext.getEntity(key);
/*  87 */       if (owner == null) {
/*  88 */         throw new AssertionFailure("collection owner not associated with session: " + loadedPersister.getRole());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*  93 */       EntityEntry e = persistenceContext.getEntry(owner);
/*     */       
/*  95 */       if ((e != null) && (e.getStatus() != Status.DELETED) && (e.getStatus() != Status.GONE)) {
/*  96 */         throw new HibernateException("A collection with cascade=\"all-delete-orphan\" was no longer referenced by the owning entity instance: " + loadedPersister.getRole());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 104 */     entry.setCurrentPersister(null);
/* 105 */     entry.setCurrentKey(null);
/* 106 */     prepareCollectionForUpdate(coll, entry, session.getEntityMode(), session.getFactory());
/*     */   }
/*     */   
/*     */ 
/*     */   private static void processNeverReferencedCollection(PersistentCollection coll, SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/* 113 */     PersistenceContext persistenceContext = session.getPersistenceContext();
/* 114 */     CollectionEntry entry = persistenceContext.getCollectionEntry(coll);
/*     */     
/* 116 */     log.debug("Found collection with unloaded owner: " + MessageHelper.collectionInfoString(entry.getLoadedPersister(), entry.getLoadedKey(), session.getFactory()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */     entry.setCurrentPersister(entry.getLoadedPersister());
/* 126 */     entry.setCurrentKey(entry.getLoadedKey());
/*     */     
/* 128 */     prepareCollectionForUpdate(coll, entry, session.getEntityMode(), session.getFactory());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void processReachableCollection(PersistentCollection collection, CollectionType type, Object entity, SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/* 147 */     collection.setOwner(entity);
/*     */     
/* 149 */     CollectionEntry ce = session.getPersistenceContext().getCollectionEntry(collection);
/*     */     
/* 151 */     if (ce == null)
/*     */     {
/* 153 */       throw new HibernateException("Found two representations of same collection: " + type.getRole());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 161 */     if (ce.isReached())
/*     */     {
/* 163 */       throw new HibernateException("Found shared references to a collection: " + type.getRole());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 168 */     ce.setReached(true);
/*     */     
/* 170 */     SessionFactoryImplementor factory = session.getFactory();
/* 171 */     CollectionPersister persister = factory.getCollectionPersister(type.getRole());
/* 172 */     ce.setCurrentPersister(persister);
/* 173 */     ce.setCurrentKey(type.getKeyOfOwner(entity, session));
/*     */     
/* 175 */     if (log.isDebugEnabled()) {
/* 176 */       log.debug("Collection found: " + MessageHelper.collectionInfoString(persister, ce.getCurrentKey(), factory) + ", was: " + MessageHelper.collectionInfoString(ce.getLoadedPersister(), ce.getLoadedKey(), factory) + (collection.wasInitialized() ? " (initialized)" : " (uninitialized)"));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 185 */     prepareCollectionForUpdate(collection, ce, session.getEntityMode(), factory);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void prepareCollectionForUpdate(PersistentCollection collection, CollectionEntry entry, EntityMode entityMode, SessionFactoryImplementor factory)
/*     */     throws HibernateException
/*     */   {
/* 201 */     if (entry.isProcessed()) {
/* 202 */       throw new AssertionFailure("collection was processed twice by flush()");
/*     */     }
/* 204 */     entry.setProcessed(true);
/*     */     
/* 206 */     CollectionPersister loadedPersister = entry.getLoadedPersister();
/* 207 */     CollectionPersister currentPersister = entry.getCurrentPersister();
/* 208 */     if ((loadedPersister != null) || (currentPersister != null))
/*     */     {
/* 210 */       boolean ownerChanged = (loadedPersister != currentPersister) || (!currentPersister.getKeyType().isEqual(entry.getLoadedKey(), entry.getCurrentKey(), entityMode, factory));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 218 */       if (ownerChanged)
/*     */       {
/*     */ 
/* 221 */         boolean orphanDeleteAndRoleChanged = (loadedPersister != null) && (currentPersister != null) && (loadedPersister.hasOrphanDelete());
/*     */         
/*     */ 
/*     */ 
/* 225 */         if (orphanDeleteAndRoleChanged) {
/* 226 */           throw new HibernateException("Don't change the reference to a collection with cascade=\"all-delete-orphan\": " + loadedPersister.getRole());
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 233 */         if (currentPersister != null) {
/* 234 */           entry.setDorecreate(true);
/*     */         }
/*     */         
/* 237 */         if (loadedPersister != null) {
/* 238 */           entry.setDoremove(true);
/* 239 */           if (entry.isDorecreate()) {
/* 240 */             log.trace("Forcing collection initialization");
/* 241 */             collection.forceInitialization();
/*     */           }
/*     */           
/*     */         }
/*     */       }
/* 246 */       else if (collection.isDirty()) {
/* 247 */         entry.setDoupdate(true);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\Collections.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */