/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Interceptor;
/*     */ import org.hibernate.TransientObjectException;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.intercept.LazyPropertyInitializer;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.proxy.HibernateProxy;
/*     */ import org.hibernate.proxy.LazyInitializer;
/*     */ import org.hibernate.type.AbstractComponentType;
/*     */ import org.hibernate.type.EntityType;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ForeignKeys
/*     */ {
/*     */   public static class Nullifier
/*     */   {
/*     */     private final boolean isDelete;
/*     */     private final boolean isEarlyInsert;
/*     */     private final SessionImplementor session;
/*     */     private final Object self;
/*     */     
/*     */     public Nullifier(Object self, boolean isDelete, boolean isEarlyInsert, SessionImplementor session)
/*     */     {
/*  33 */       this.isDelete = isDelete;
/*  34 */       this.isEarlyInsert = isEarlyInsert;
/*  35 */       this.session = session;
/*  36 */       this.self = self;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void nullifyTransientReferences(Object[] values, Type[] types)
/*     */       throws HibernateException
/*     */     {
/*  46 */       for (int i = 0; i < types.length; i++) {
/*  47 */         values[i] = nullifyTransientReferences(values[i], types[i]);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private Object nullifyTransientReferences(Object value, Type type)
/*     */       throws HibernateException
/*     */     {
/*  59 */       if (value == null) {
/*  60 */         return null;
/*     */       }
/*  62 */       if (type.isEntityType()) {
/*  63 */         EntityType entityType = (EntityType)type;
/*  64 */         if (entityType.isOneToOne()) {
/*  65 */           return value;
/*     */         }
/*     */         
/*  68 */         String entityName = entityType.getAssociatedEntityName();
/*  69 */         return isNullifiable(entityName, value) ? null : value;
/*     */       }
/*     */       
/*  72 */       if (type.isAnyType()) {
/*  73 */         return isNullifiable(null, value) ? null : value;
/*     */       }
/*  75 */       if (type.isComponentType()) {
/*  76 */         AbstractComponentType actype = (AbstractComponentType)type;
/*  77 */         Object[] subvalues = actype.getPropertyValues(value, this.session);
/*  78 */         Type[] subtypes = actype.getSubtypes();
/*  79 */         boolean substitute = false;
/*  80 */         for (int i = 0; i < subvalues.length; i++) {
/*  81 */           Object replacement = nullifyTransientReferences(subvalues[i], subtypes[i]);
/*  82 */           if (replacement != subvalues[i]) {
/*  83 */             substitute = true;
/*  84 */             subvalues[i] = replacement;
/*     */           }
/*     */         }
/*  87 */         if (substitute) actype.setPropertyValues(value, subvalues, this.session.getEntityMode());
/*  88 */         return value;
/*     */       }
/*     */       
/*  91 */       return value;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private boolean isNullifiable(String entityName, Object object)
/*     */       throws HibernateException
/*     */     {
/* 102 */       if (object == LazyPropertyInitializer.UNFETCHED_PROPERTY) { return false;
/*     */       }
/* 104 */       if ((object instanceof HibernateProxy))
/*     */       {
/* 106 */         LazyInitializer li = ((HibernateProxy)object).getHibernateLazyInitializer();
/* 107 */         if (li.getImplementation(this.session) == null) {
/* 108 */           return false;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 114 */         object = li.getImplementation();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 121 */       if (object == this.self) {
/* 122 */         return (this.isEarlyInsert) || ((this.isDelete) && (this.session.getFactory().getDialect().hasSelfReferentialForeignKeyBug()));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 135 */       EntityEntry entityEntry = this.session.getPersistenceContext().getEntry(object);
/* 136 */       if (entityEntry == null) {
/* 137 */         return ForeignKeys.isTransient(entityName, object, null, this.session);
/*     */       }
/*     */       
/* 140 */       return entityEntry.isNullifiable(this.isEarlyInsert, this.session);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isNotTransient(String entityName, Object entity, Boolean assumed, SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/* 155 */     if ((entity instanceof HibernateProxy)) return true;
/* 156 */     if (session.getPersistenceContext().isEntryFor(entity)) return true;
/* 157 */     return !isTransient(entityName, entity, assumed, session);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isTransient(String entityName, Object entity, Boolean assumed, SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/* 169 */     if (entity == LazyPropertyInitializer.UNFETCHED_PROPERTY)
/*     */     {
/*     */ 
/* 172 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 176 */     Boolean isUnsaved = session.getInterceptor().isTransient(entity);
/* 177 */     if (isUnsaved != null) { return isUnsaved.booleanValue();
/*     */     }
/*     */     
/* 180 */     EntityPersister persister = session.getEntityPersister(entityName, entity);
/* 181 */     isUnsaved = persister.isTransient(entity, session);
/* 182 */     if (isUnsaved != null) { return isUnsaved.booleanValue();
/*     */     }
/*     */     
/*     */ 
/* 186 */     if (assumed != null) { return assumed.booleanValue();
/*     */     }
/*     */     
/* 189 */     Object[] snapshot = session.getPersistenceContext().getDatabaseSnapshot(persister.getIdentifier(entity, session.getEntityMode()), persister);
/*     */     
/* 191 */     return snapshot == null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Serializable getEntityIdentifierIfNotUnsaved(String entityName, Object object, SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/* 209 */     if (object == null) {
/* 210 */       return null;
/*     */     }
/*     */     
/* 213 */     Serializable id = session.getContextEntityIdentifier(object);
/* 214 */     if (id == null) {
/* 215 */       if (isTransient(entityName, object, Boolean.FALSE, session)) {
/* 216 */         throw new TransientObjectException("object references an unsaved transient instance - save the transient instance before flushing: " + entityName == null ? session.guessEntityName(object) : entityName);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 221 */       id = session.getEntityPersister(entityName, object).getIdentifier(object, session.getEntityMode());
/*     */     }
/*     */     
/* 224 */     return id;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\ForeignKeys.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */