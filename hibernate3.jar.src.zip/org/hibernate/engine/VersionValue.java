/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.id.IdentifierGeneratorFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VersionValue
/*     */ {
/*  37 */   private static final Log log = LogFactory.getLog(VersionValue.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Object value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  51 */   public static final VersionValue NULL = new VersionValue()
/*     */   {
/*     */     public final Boolean isUnsaved(Object version)
/*     */     {
/*  55 */       VersionValue.log.trace("version unsaved-value strategy NULL");
/*     */       
/*  57 */       return version == null ? Boolean.TRUE : Boolean.FALSE;
/*     */     }
/*     */     
/*     */ 
/*     */     public Object getDefaultValue(Object currentValue)
/*     */     {
/*  63 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/*  69 */       return "VERSION_SAVE_NULL";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */   public static final VersionValue UNDEFINED = new VersionValue()
/*     */   {
/*     */     public final Boolean isUnsaved(Object version)
/*     */     {
/*  87 */       VersionValue.log.trace("version unsaved-value strategy UNDEFINED");
/*     */       
/*  89 */       return version == null ? Boolean.TRUE : null;
/*     */     }
/*     */     
/*     */ 
/*     */     public Object getDefaultValue(Object currentValue)
/*     */     {
/*  95 */       return currentValue;
/*     */     }
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/* 101 */       return "VERSION_UNDEFINED";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 115 */   public static final VersionValue NEGATIVE = new VersionValue()
/*     */   {
/*     */ 
/*     */     public final Boolean isUnsaved(Object version)
/*     */       throws MappingException
/*     */     {
/* 121 */       VersionValue.log.trace("version unsaved-value strategy NEGATIVE");
/*     */       
/* 123 */       if (version == null) { return Boolean.TRUE;
/*     */       }
/* 125 */       if ((version instanceof Number))
/*     */       {
/* 127 */         return ((Number)version).longValue() < 0L ? Boolean.TRUE : Boolean.FALSE;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 133 */       throw new MappingException("unsaved-value NEGATIVE may only be used with short, int and long types");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Object getDefaultValue(Object currentValue)
/*     */     {
/* 141 */       return IdentifierGeneratorFactory.createNumber(-1L, currentValue.getClass());
/*     */     }
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/* 147 */       return "VERSION_NEGATIVE";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected VersionValue()
/*     */   {
/* 157 */     this.value = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public VersionValue(Object value)
/*     */   {
/* 175 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean isUnsaved(Object version)
/*     */     throws MappingException
/*     */   {
/* 195 */     if (log.isTraceEnabled()) { log.trace("version unsaved-value: " + this.value);
/*     */     }
/* 197 */     return (version == null) || (version.equals(this.value)) ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getDefaultValue(Object currentValue)
/*     */   {
/* 205 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 213 */     return "version unsaved-value: " + this.value;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\VersionValue.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */