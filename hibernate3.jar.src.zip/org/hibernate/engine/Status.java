/*    */ package org.hibernate.engine;
/*    */ 
/*    */ import java.io.InvalidObjectException;
/*    */ import java.io.ObjectStreamException;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Status
/*    */   implements Serializable
/*    */ {
/* 16 */   public static final Status MANAGED = new Status("MANAGED");
/* 17 */   public static final Status READ_ONLY = new Status("READ_ONLY");
/* 18 */   public static final Status DELETED = new Status("DELETED");
/* 19 */   public static final Status GONE = new Status("GONE");
/* 20 */   public static final Status LOADING = new Status("LOADING");
/* 21 */   public static final Status SAVING = new Status("SAVING");
/*    */   private String name;
/*    */   
/*    */   private Status(String name)
/*    */   {
/* 26 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 30 */     return this.name;
/*    */   }
/*    */   
/*    */   private Object readResolve() throws ObjectStreamException {
/* 34 */     if (this.name.equals(MANAGED.name)) return MANAGED;
/* 35 */     if (this.name.equals(READ_ONLY.name)) return READ_ONLY;
/* 36 */     if (this.name.equals(DELETED.name)) return DELETED;
/* 37 */     if (this.name.equals(GONE.name)) return GONE;
/* 38 */     if (this.name.equals(LOADING.name)) return LOADING;
/* 39 */     if (this.name.equals(SAVING.name)) return SAVING;
/* 40 */     throw new InvalidObjectException("invalid Status");
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\Status.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */