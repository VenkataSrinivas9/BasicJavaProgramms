package org.hibernate.engine;

import org.hibernate.MappingException;
import org.hibernate.type.Type;

public abstract interface Mapping
{
  public abstract Type getIdentifierType(String paramString)
    throws MappingException;
  
  public abstract String getIdentifierPropertyName(String paramString)
    throws MappingException;
  
  public abstract Type getReferencedPropertyType(String paramString1, String paramString2)
    throws MappingException;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\Mapping.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */