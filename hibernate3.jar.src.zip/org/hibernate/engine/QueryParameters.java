/*     */ package org.hibernate.engine;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.ScrollMode;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.pretty.Printer;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.ArrayHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class QueryParameters
/*     */ {
/*  29 */   private static final Log log = LogFactory.getLog(QueryParameters.class);
/*     */   
/*     */   private Type[] positionalParameterTypes;
/*     */   private Object[] positionalParameterValues;
/*     */   private Map namedParameters;
/*     */   private Map lockModes;
/*     */   private RowSelection rowSelection;
/*     */   private boolean cacheable;
/*     */   private String cacheRegion;
/*     */   private String comment;
/*     */   private ScrollMode scrollMode;
/*     */   private Serializable[] collectionKeys;
/*     */   private Object optionalObject;
/*     */   private String optionalEntityName;
/*     */   private Serializable optionalId;
/*     */   private boolean readOnly;
/*  45 */   private boolean callable = false;
/*  46 */   private boolean autodiscovertypes = false;
/*     */   private boolean isNaturalKeyLookup;
/*     */   private String processedSQL;
/*     */   private Type[] processedPositionalParameterTypes;
/*     */   private Object[] processedPositionalParameterValues;
/*     */   
/*     */   public QueryParameters()
/*     */   {
/*  54 */     this(ArrayHelper.EMPTY_TYPE_ARRAY, ArrayHelper.EMPTY_OBJECT_ARRAY);
/*     */   }
/*     */   
/*     */   public QueryParameters(Type type, Object value) {
/*  58 */     this(new Type[] { type }, new Object[] { value });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public QueryParameters(Type[] positionalParameterTypes, Object[] postionalParameterValues, Object optionalObject, String optionalEntityName, Serializable optionalObjectId)
/*     */   {
/*  68 */     this(positionalParameterTypes, postionalParameterValues);
/*  69 */     this.optionalObject = optionalObject;
/*  70 */     this.optionalId = optionalObjectId;
/*  71 */     this.optionalEntityName = optionalEntityName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public QueryParameters(Type[] positionalParameterTypes, Object[] postionalParameterValues)
/*     */   {
/*  79 */     this(positionalParameterTypes, postionalParameterValues, null, null, false, null, null, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public QueryParameters(Type[] positionalParameterTypes, Object[] postionalParameterValues, Serializable[] collectionKeys)
/*     */   {
/*  96 */     this(positionalParameterTypes, postionalParameterValues, null, collectionKeys);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public QueryParameters(Type[] positionalParameterTypes, Object[] postionalParameterValues, Map namedParameters, Serializable[] collectionKeys)
/*     */   {
/* 110 */     this(positionalParameterTypes, postionalParameterValues, namedParameters, null, null, false, false, null, null, collectionKeys);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public QueryParameters(Type[] positionalParameterTypes, Object[] positionalParameterValues, Map lockModes, RowSelection rowSelection, boolean cacheable, String cacheRegion, String comment, boolean isLookupByNaturalKey)
/*     */   {
/* 135 */     this(positionalParameterTypes, positionalParameterValues, null, lockModes, rowSelection, false, cacheable, cacheRegion, comment, null);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 147 */     this.isNaturalKeyLookup = isLookupByNaturalKey;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public QueryParameters(Type[] positionalParameterTypes, Object[] positionalParameterValues, Map namedParameters, Map lockModes, RowSelection rowSelection, boolean readOnly, boolean cacheable, String cacheRegion, String comment, Serializable[] collectionKeys)
/*     */   {
/* 163 */     this.positionalParameterTypes = positionalParameterTypes;
/* 164 */     this.positionalParameterValues = positionalParameterValues;
/* 165 */     this.namedParameters = namedParameters;
/* 166 */     this.lockModes = lockModes;
/* 167 */     this.rowSelection = rowSelection;
/* 168 */     this.cacheable = cacheable;
/* 169 */     this.cacheRegion = cacheRegion;
/*     */     
/* 171 */     this.comment = comment;
/* 172 */     this.collectionKeys = collectionKeys;
/* 173 */     this.readOnly = readOnly;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public QueryParameters(Type[] positionalParameterTypes, Object[] positionalParameterValues, Map namedParameters, Map lockModes, RowSelection rowSelection, boolean readOnly, boolean cacheable, String cacheRegion, String comment, Serializable[] collectionKeys, Object optionalObject, String optionalEntityName, Serializable optionalId)
/*     */   {
/* 192 */     this(positionalParameterTypes, positionalParameterValues, namedParameters, lockModes, rowSelection, readOnly, cacheable, cacheRegion, comment, collectionKeys);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 204 */     this.optionalEntityName = optionalEntityName;
/* 205 */     this.optionalId = optionalId;
/* 206 */     this.optionalObject = optionalObject;
/*     */   }
/*     */   
/*     */   public boolean hasRowSelection() {
/* 210 */     return this.rowSelection != null;
/*     */   }
/*     */   
/*     */   public Map getNamedParameters() {
/* 214 */     return this.namedParameters;
/*     */   }
/*     */   
/*     */   public Type[] getPositionalParameterTypes() {
/* 218 */     return this.positionalParameterTypes;
/*     */   }
/*     */   
/*     */   public Object[] getPositionalParameterValues() {
/* 222 */     return this.positionalParameterValues;
/*     */   }
/*     */   
/*     */   public RowSelection getRowSelection() {
/* 226 */     return this.rowSelection;
/*     */   }
/*     */   
/*     */   public void setNamedParameters(Map map) {
/* 230 */     this.namedParameters = map;
/*     */   }
/*     */   
/*     */   public void setPositionalParameterTypes(Type[] types) {
/* 234 */     this.positionalParameterTypes = types;
/*     */   }
/*     */   
/*     */   public void setPositionalParameterValues(Object[] objects) {
/* 238 */     this.positionalParameterValues = objects;
/*     */   }
/*     */   
/*     */   public void setRowSelection(RowSelection selection) {
/* 242 */     this.rowSelection = selection;
/*     */   }
/*     */   
/*     */   public Map getLockModes() {
/* 246 */     return this.lockModes;
/*     */   }
/*     */   
/*     */   public void setLockModes(Map map) {
/* 250 */     this.lockModes = map;
/*     */   }
/*     */   
/*     */   public void traceParameters(SessionFactoryImplementor factory) throws HibernateException {
/* 254 */     Printer print = new Printer(factory);
/* 255 */     if (this.positionalParameterValues.length != 0) {
/* 256 */       log.trace("parameters: " + print.toString(this.positionalParameterTypes, this.positionalParameterValues));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 261 */     if (this.namedParameters != null) {
/* 262 */       log.trace("named parameters: " + print.toString(this.namedParameters));
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isCacheable() {
/* 267 */     return this.cacheable;
/*     */   }
/*     */   
/*     */   public void setCacheable(boolean b) {
/* 271 */     this.cacheable = b;
/*     */   }
/*     */   
/*     */   public String getCacheRegion() {
/* 275 */     return this.cacheRegion;
/*     */   }
/*     */   
/*     */   public void setCacheRegion(String cacheRegion) {
/* 279 */     this.cacheRegion = cacheRegion;
/*     */   }
/*     */   
/*     */   public void validateParameters() throws QueryException {
/* 283 */     int types = this.positionalParameterTypes == null ? 0 : this.positionalParameterTypes.length;
/* 284 */     int values = this.positionalParameterValues == null ? 0 : this.positionalParameterValues.length;
/* 285 */     if (types != values) {
/* 286 */       throw new QueryException("Number of positional parameter types:" + types + " does not match number of positional parameters: " + values);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getComment()
/*     */   {
/* 294 */     return this.comment;
/*     */   }
/*     */   
/*     */   public void setComment(String comment) {
/* 298 */     this.comment = comment;
/*     */   }
/*     */   
/*     */   public ScrollMode getScrollMode() {
/* 302 */     return this.scrollMode;
/*     */   }
/*     */   
/*     */   public void setScrollMode(ScrollMode scrollMode) {
/* 306 */     this.scrollMode = scrollMode;
/*     */   }
/*     */   
/*     */   public Serializable[] getCollectionKeys() {
/* 310 */     return this.collectionKeys;
/*     */   }
/*     */   
/*     */   public void setCollectionKeys(Serializable[] collectionKeys) {
/* 314 */     this.collectionKeys = collectionKeys;
/*     */   }
/*     */   
/*     */   public String getOptionalEntityName() {
/* 318 */     return this.optionalEntityName;
/*     */   }
/*     */   
/*     */   public void setOptionalEntityName(String optionalEntityName) {
/* 322 */     this.optionalEntityName = optionalEntityName;
/*     */   }
/*     */   
/*     */   public Serializable getOptionalId() {
/* 326 */     return this.optionalId;
/*     */   }
/*     */   
/*     */   public void setOptionalId(Serializable optionalId) {
/* 330 */     this.optionalId = optionalId;
/*     */   }
/*     */   
/*     */   public Object getOptionalObject() {
/* 334 */     return this.optionalObject;
/*     */   }
/*     */   
/*     */   public void setOptionalObject(Object optionalObject) {
/* 338 */     this.optionalObject = optionalObject;
/*     */   }
/*     */   
/*     */   public boolean isReadOnly() {
/* 342 */     return this.readOnly;
/*     */   }
/*     */   
/*     */   public void setReadOnly(boolean readOnly) {
/* 346 */     this.readOnly = readOnly;
/*     */   }
/*     */   
/*     */   public void setCallable(boolean callable) {
/* 350 */     this.callable = callable;
/*     */   }
/*     */   
/*     */   public boolean isCallable() {
/* 354 */     return this.callable;
/*     */   }
/*     */   
/*     */   public boolean hasAutoDiscoverScalarTypes() {
/* 358 */     return this.autodiscovertypes;
/*     */   }
/*     */   
/*     */   public void processFilters(String sql, SessionImplementor session)
/*     */   {
/* 363 */     if ((session.getEnabledFilters().size() == 0) || (sql.indexOf(":") < 0))
/*     */     {
/* 365 */       this.processedPositionalParameterValues = getPositionalParameterValues();
/* 366 */       this.processedPositionalParameterTypes = getPositionalParameterTypes();
/* 367 */       this.processedSQL = sql;
/*     */     }
/*     */     else
/*     */     {
/* 371 */       Dialect dialect = session.getFactory().getDialect();
/* 372 */       String symbols = " \n\r\f\t,()=<>&|+-=/*'^![]#~\\" + dialect.openQuote() + dialect.closeQuote();
/*     */       
/*     */ 
/*     */ 
/* 376 */       StringTokenizer tokens = new StringTokenizer(sql, symbols, true);
/* 377 */       StringBuffer result = new StringBuffer();
/*     */       
/* 379 */       List parameters = new ArrayList();
/* 380 */       List parameterTypes = new ArrayList();
/*     */       
/* 382 */       while (tokens.hasMoreTokens()) {
/* 383 */         String token = tokens.nextToken();
/* 384 */         if (token.startsWith(":")) {
/* 385 */           String filterParameterName = token.substring(1);
/* 386 */           Object value = session.getFilterParameterValue(filterParameterName);
/* 387 */           Type type = session.getFilterParameterType(filterParameterName);
/* 388 */           if ((value != null) && (Collection.class.isAssignableFrom(value.getClass()))) {
/* 389 */             Iterator itr = ((Collection)value).iterator();
/* 390 */             while (itr.hasNext()) {
/* 391 */               Object elementValue = itr.next();
/* 392 */               result.append('?');
/* 393 */               parameters.add(elementValue);
/* 394 */               parameterTypes.add(type);
/* 395 */               if (itr.hasNext()) {
/* 396 */                 result.append(", ");
/*     */               }
/*     */             }
/*     */           }
/*     */           else {
/* 401 */             result.append('?');
/* 402 */             parameters.add(value);
/* 403 */             parameterTypes.add(type);
/*     */           }
/*     */         }
/*     */         else {
/* 407 */           result.append(token);
/*     */         }
/*     */       }
/* 410 */       parameters.addAll(Arrays.asList(getPositionalParameterValues()));
/* 411 */       parameterTypes.addAll(Arrays.asList(getPositionalParameterTypes()));
/* 412 */       this.processedPositionalParameterValues = parameters.toArray();
/* 413 */       this.processedPositionalParameterTypes = ((Type[])parameterTypes.toArray(new Type[0]));
/* 414 */       this.processedSQL = result.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public String getFilteredSQL()
/*     */   {
/* 420 */     return this.processedSQL;
/*     */   }
/*     */   
/*     */   public Object[] getFilteredPositionalParameterValues() {
/* 424 */     return this.processedPositionalParameterValues;
/*     */   }
/*     */   
/*     */   public Type[] getFilteredPositionalParameterTypes() {
/* 428 */     return this.processedPositionalParameterTypes;
/*     */   }
/*     */   
/*     */   public boolean isNaturalKeyLookup() {
/* 432 */     return this.isNaturalKeyLookup;
/*     */   }
/*     */   
/*     */   public void setNaturalKeyLookup(boolean isNaturalKeyLookup) {
/* 436 */     this.isNaturalKeyLookup = isNaturalKeyLookup;
/*     */   }
/*     */   
/*     */   public void setAutoDiscoverScalarTypes(boolean autodiscovertypes) {
/* 440 */     this.autodiscovertypes = autodiscovertypes;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\engine\QueryParameters.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */