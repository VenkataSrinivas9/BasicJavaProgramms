package org.hibernate.classic;

import java.io.Serializable;
import org.hibernate.CallbackException;
import org.hibernate.Session;

public abstract interface Lifecycle
{
  public static final boolean VETO = true;
  public static final boolean NO_VETO = false;
  
  public abstract boolean onSave(Session paramSession)
    throws CallbackException;
  
  public abstract boolean onUpdate(Session paramSession)
    throws CallbackException;
  
  public abstract boolean onDelete(Session paramSession)
    throws CallbackException;
  
  public abstract void onLoad(Session paramSession, Serializable paramSerializable);
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\classic\Lifecycle.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */