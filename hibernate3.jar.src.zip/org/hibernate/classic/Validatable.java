package org.hibernate.classic;

public abstract interface Validatable
{
  public abstract void validate()
    throws ValidationFailure;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\classic\Validatable.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */