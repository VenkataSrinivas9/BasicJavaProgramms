package org.hibernate.classic;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.type.Type;

public abstract interface Session
  extends org.hibernate.Session
{
  /**
   * @deprecated
   */
  public abstract Object saveOrUpdateCopy(Object paramObject)
    throws HibernateException;
  
  /**
   * @deprecated
   */
  public abstract Object saveOrUpdateCopy(Object paramObject, Serializable paramSerializable)
    throws HibernateException;
  
  /**
   * @deprecated
   */
  public abstract Object saveOrUpdateCopy(String paramString, Object paramObject)
    throws HibernateException;
  
  /**
   * @deprecated
   */
  public abstract Object saveOrUpdateCopy(String paramString, Object paramObject, Serializable paramSerializable)
    throws HibernateException;
  
  /**
   * @deprecated
   */
  public abstract List find(String paramString)
    throws HibernateException;
  
  /**
   * @deprecated
   */
  public abstract List find(String paramString, Object paramObject, Type paramType)
    throws HibernateException;
  
  /**
   * @deprecated
   */
  public abstract List find(String paramString, Object[] paramArrayOfObject, Type[] paramArrayOfType)
    throws HibernateException;
  
  /**
   * @deprecated
   */
  public abstract Iterator iterate(String paramString)
    throws HibernateException;
  
  /**
   * @deprecated
   */
  public abstract Iterator iterate(String paramString, Object paramObject, Type paramType)
    throws HibernateException;
  
  /**
   * @deprecated
   */
  public abstract Iterator iterate(String paramString, Object[] paramArrayOfObject, Type[] paramArrayOfType)
    throws HibernateException;
  
  /**
   * @deprecated
   */
  public abstract Collection filter(Object paramObject, String paramString)
    throws HibernateException;
  
  /**
   * @deprecated
   */
  public abstract Collection filter(Object paramObject1, String paramString, Object paramObject2, Type paramType)
    throws HibernateException;
  
  /**
   * @deprecated
   */
  public abstract Collection filter(Object paramObject, String paramString, Object[] paramArrayOfObject, Type[] paramArrayOfType)
    throws HibernateException;
  
  /**
   * @deprecated
   */
  public abstract int delete(String paramString)
    throws HibernateException;
  
  /**
   * @deprecated
   */
  public abstract int delete(String paramString, Object paramObject, Type paramType)
    throws HibernateException;
  
  /**
   * @deprecated
   */
  public abstract int delete(String paramString, Object[] paramArrayOfObject, Type[] paramArrayOfType)
    throws HibernateException;
  
  /**
   * @deprecated
   */
  public abstract Query createSQLQuery(String paramString1, String paramString2, Class paramClass);
  
  /**
   * @deprecated
   */
  public abstract Query createSQLQuery(String paramString, String[] paramArrayOfString, Class[] paramArrayOfClass);
  
  /**
   * @deprecated
   */
  public abstract void save(Object paramObject, Serializable paramSerializable)
    throws HibernateException;
  
  /**
   * @deprecated
   */
  public abstract void save(String paramString, Object paramObject, Serializable paramSerializable)
    throws HibernateException;
  
  /**
   * @deprecated
   */
  public abstract void update(Object paramObject, Serializable paramSerializable)
    throws HibernateException;
  
  /**
   * @deprecated
   */
  public abstract void update(String paramString, Object paramObject, Serializable paramSerializable)
    throws HibernateException;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\classic\Session.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */