/*    */ package org.hibernate.classic;
/*    */ 
/*    */ import org.hibernate.HibernateException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidationFailure
/*    */   extends HibernateException
/*    */ {
/*    */   public ValidationFailure(String message)
/*    */   {
/* 16 */     super(message);
/*    */   }
/*    */   
/*    */   public ValidationFailure(String message, Exception e) {
/* 20 */     super(message, e);
/*    */   }
/*    */   
/*    */   public ValidationFailure(Exception e) {
/* 24 */     super("A validation failure occurred", e);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\classic\ValidationFailure.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */