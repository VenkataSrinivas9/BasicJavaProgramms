/*     */ package org.hibernate.collection;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.dom4j.Element;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.engine.PersistenceContext;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.loader.CollectionAliases;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.type.NullableType;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.CollectionHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PersistentIndexedElementHolder
/*     */   extends AbstractPersistentCollection
/*     */ {
/*     */   protected Element element;
/*     */   
/*     */   public PersistentIndexedElementHolder(SessionImplementor session, Element element)
/*     */   {
/*  34 */     super(session);
/*  35 */     this.element = element;
/*  36 */     setInitialized();
/*     */   }
/*     */   
/*     */   public static final class IndexedValue {
/*     */     String index;
/*     */     Object value;
/*     */     
/*  43 */     IndexedValue(String index, Object value) { this.index = index;
/*  44 */       this.value = value;
/*     */     }
/*     */   }
/*     */   
/*     */   protected static String getIndex(Element element, String indexNodeName, int i) {
/*  49 */     if (indexNodeName != null) {
/*  50 */       return element.attributeValue(indexNodeName);
/*     */     }
/*     */     
/*  53 */     return Integer.toString(i);
/*     */   }
/*     */   
/*     */   protected static void setIndex(Element element, String indexNodeName, String index)
/*     */   {
/*  58 */     if (indexNodeName != null) element.addAttribute(indexNodeName, index);
/*     */   }
/*     */   
/*     */   protected static String getIndexAttributeName(CollectionPersister persister) {
/*  62 */     String node = persister.getIndexNodeName();
/*  63 */     return node == null ? null : node.substring(1);
/*     */   }
/*     */   
/*     */   public Serializable getSnapshot(CollectionPersister persister)
/*     */     throws HibernateException
/*     */   {
/*  69 */     Type elementType = persister.getElementType();
/*  70 */     String indexNode = getIndexAttributeName(persister);
/*  71 */     List elements = this.element.elements(persister.getElementNodeName());
/*  72 */     HashMap snapshot = new HashMap(elements.size());
/*  73 */     for (int i = 0; i < elements.size(); i++) {
/*  74 */       Element elem = (Element)elements.get(i);
/*  75 */       Object value = elementType.fromXMLNode(elem, persister.getFactory());
/*  76 */       Object copy = elementType.deepCopy(value, getSession().getEntityMode(), persister.getFactory());
/*  77 */       snapshot.put(getIndex(elem, indexNode, i), copy);
/*     */     }
/*  79 */     return snapshot;
/*     */   }
/*     */   
/*     */ 
/*     */   public Collection getOrphans(Serializable snapshot, String entityName)
/*     */     throws HibernateException
/*     */   {
/*  86 */     return CollectionHelper.EMPTY_COLLECTION;
/*     */   }
/*     */   
/*     */   public PersistentIndexedElementHolder(SessionImplementor session, CollectionPersister persister, Serializable key) throws HibernateException
/*     */   {
/*  91 */     super(session);
/*  92 */     Element owner = (Element)session.getPersistenceContext().getCollectionOwner(key, persister);
/*  93 */     if (owner == null) { throw new AssertionFailure("null owner");
/*     */     }
/*  95 */     String nodeName = persister.getNodeName();
/*  96 */     if (".".equals(nodeName)) {
/*  97 */       this.element = owner;
/*     */     }
/*     */     else {
/* 100 */       this.element = owner.element(nodeName);
/* 101 */       if (this.element == null) this.element = owner.addElement(nodeName);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isWrapper(Object collection) {
/* 106 */     return this.element == collection;
/*     */   }
/*     */   
/*     */   public boolean equalsSnapshot(CollectionPersister persister) throws HibernateException {
/* 110 */     Type elementType = persister.getElementType();
/* 111 */     String indexNode = getIndexAttributeName(persister);
/* 112 */     HashMap snapshot = (HashMap)getSnapshot();
/* 113 */     List elements = this.element.elements(persister.getElementNodeName());
/* 114 */     if (snapshot.size() != elements.size()) return false;
/* 115 */     for (int i = 0; i < snapshot.size(); i++) {
/* 116 */       Element elem = (Element)elements.get(i);
/* 117 */       Object old = snapshot.get(getIndex(elem, indexNode, i));
/* 118 */       Object current = elementType.fromXMLNode(elem, persister.getFactory());
/* 119 */       if (elementType.isDirty(old, current, getSession())) return false;
/*     */     }
/* 121 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isSnapshotEmpty(Serializable snapshot) {
/* 125 */     return ((HashMap)snapshot).isEmpty();
/*     */   }
/*     */   
/*     */   public boolean empty() {
/* 129 */     return !this.element.elementIterator().hasNext();
/*     */   }
/*     */   
/*     */   public Object readFrom(ResultSet rs, CollectionPersister persister, CollectionAliases descriptor, Object owner) throws HibernateException, SQLException
/*     */   {
/* 134 */     Object object = persister.readElement(rs, owner, descriptor.getSuffixedElementAliases(), getSession());
/* 135 */     Type elementType = persister.getElementType();
/* 136 */     SessionFactoryImplementor factory = persister.getFactory();
/* 137 */     String indexNode = getIndexAttributeName(persister);
/*     */     
/* 139 */     Element elem = this.element.addElement(persister.getElementNodeName());
/* 140 */     elementType.setToXMLNode(elem, object, factory);
/*     */     
/* 142 */     Type indexType = persister.getIndexType();
/* 143 */     Object indexValue = persister.readIndex(rs, descriptor.getSuffixedIndexAliases(), getSession());
/* 144 */     String index = ((NullableType)indexType).toXMLString(indexValue, factory);
/* 145 */     setIndex(elem, indexNode, index);
/* 146 */     return object;
/*     */   }
/*     */   
/*     */   public Iterator entries(CollectionPersister persister)
/*     */   {
/* 151 */     Type elementType = persister.getElementType();
/* 152 */     String indexNode = getIndexAttributeName(persister);
/* 153 */     List elements = this.element.elements(persister.getElementNodeName());
/* 154 */     int length = elements.size();
/* 155 */     List result = new ArrayList(length);
/* 156 */     for (int i = 0; i < length; i++) {
/* 157 */       Element elem = (Element)elements.get(i);
/* 158 */       Object object = elementType.fromXMLNode(elem, persister.getFactory());
/* 159 */       result.add(new IndexedValue(getIndex(elem, indexNode, i), object));
/*     */     }
/* 161 */     return result.iterator();
/*     */   }
/*     */   
/*     */   public void beforeInitialize(CollectionPersister persister) {}
/*     */   
/*     */   public boolean isDirectlyAccessible() {
/* 167 */     return true;
/*     */   }
/*     */   
/*     */   public Object getValue() {
/* 171 */     return this.element;
/*     */   }
/*     */   
/*     */   public Iterator getDeletes(CollectionPersister persister, boolean indexIsFormula)
/*     */     throws HibernateException
/*     */   {
/* 177 */     Type indexType = persister.getIndexType();
/* 178 */     HashMap snapshot = (HashMap)getSnapshot();
/* 179 */     HashMap deletes = (HashMap)snapshot.clone();
/* 180 */     deletes.keySet().removeAll(((HashMap)getSnapshot(persister)).keySet());
/* 181 */     ArrayList deleteList = new ArrayList(deletes.size());
/* 182 */     Iterator iter = deletes.entrySet().iterator();
/* 183 */     while (iter.hasNext()) {
/* 184 */       Map.Entry me = (Map.Entry)iter.next();
/* 185 */       Object object = indexIsFormula ? me.getValue() : ((NullableType)indexType).fromXMLString((String)me.getKey(), persister.getFactory());
/*     */       
/*     */ 
/* 188 */       if (object != null) { deleteList.add(object);
/*     */       }
/*     */     }
/* 191 */     return deleteList.iterator();
/*     */   }
/*     */   
/*     */   public boolean needsInserting(Object entry, int i, Type elementType)
/*     */     throws HibernateException
/*     */   {
/* 197 */     HashMap snapshot = (HashMap)getSnapshot();
/* 198 */     IndexedValue iv = (IndexedValue)entry;
/* 199 */     return (iv.value != null) && (snapshot.get(iv.index) == null);
/*     */   }
/*     */   
/*     */   public boolean needsUpdating(Object entry, int i, Type elementType) throws HibernateException
/*     */   {
/* 204 */     HashMap snapshot = (HashMap)getSnapshot();
/* 205 */     IndexedValue iv = (IndexedValue)entry;
/* 206 */     Object old = snapshot.get(iv.index);
/* 207 */     return (old != null) && (elementType.isDirty(old, iv.value, getSession()));
/*     */   }
/*     */   
/*     */   public Object getIndex(Object entry, int i, CollectionPersister persister) {
/* 211 */     String index = ((IndexedValue)entry).index;
/* 212 */     Type indexType = persister.getIndexType();
/* 213 */     return ((NullableType)indexType).fromXMLString(index, persister.getFactory());
/*     */   }
/*     */   
/*     */   public Object getElement(Object entry) {
/* 217 */     return ((IndexedValue)entry).value;
/*     */   }
/*     */   
/*     */   public Object getSnapshotElement(Object entry, int i) {
/* 221 */     return ((HashMap)getSnapshot()).get(((IndexedValue)entry).index);
/*     */   }
/*     */   
/*     */   public boolean entryExists(Object entry, int i) {
/* 225 */     return entry != null;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\collection\PersistentIndexedElementHolder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */