/*     */ package org.hibernate.collection;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.List;
/*     */ import org.dom4j.Element;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.type.NullableType;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentListElementHolder
/*     */   extends PersistentIndexedElementHolder
/*     */ {
/*     */   public PersistentListElementHolder(SessionImplementor session, Element element)
/*     */   {
/*  39 */     super(session, element);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PersistentListElementHolder(SessionImplementor session, CollectionPersister persister, Serializable key)
/*     */     throws HibernateException
/*     */   {
/*  49 */     super(session, persister, key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initializeFromCache(CollectionPersister persister, Serializable disassembled, Object owner)
/*     */     throws HibernateException
/*     */   {
/*  61 */     Type elementType = persister.getElementType();
/*     */     
/*  63 */     String indexNodeName = getIndexAttributeName(persister);
/*     */     
/*  65 */     Serializable[] cached = (Serializable[])disassembled;
/*     */     
/*  67 */     for (int i = 0; i < cached.length; i++)
/*     */     {
/*  69 */       Object object = elementType.assemble(cached[i], getSession(), owner);
/*     */       
/*  71 */       Element subelement = this.element.addElement(persister.getElementNodeName());
/*     */       
/*  73 */       elementType.setToXMLNode(subelement, object, persister.getFactory());
/*     */       
/*  75 */       setIndex(subelement, indexNodeName, Integer.toString(i));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Serializable disassemble(CollectionPersister persister)
/*     */     throws HibernateException
/*     */   {
/*  89 */     Type elementType = persister.getElementType();
/*     */     
/*  91 */     String indexNodeName = getIndexAttributeName(persister);
/*     */     
/*  93 */     List elements = this.element.elements(persister.getElementNodeName());
/*     */     
/*  95 */     int length = elements.size();
/*     */     
/*  97 */     Serializable[] result = new Serializable[length];
/*     */     
/*  99 */     for (int i = 0; i < length; i++)
/*     */     {
/* 101 */       Element elem = (Element)elements.get(i);
/*     */       
/* 103 */       Object object = elementType.fromXMLNode(elem, persister.getFactory());
/*     */       
/* 105 */       Integer index = (Integer)Hibernate.INTEGER.fromStringValue(getIndex(elem, indexNodeName, i));
/*     */       
/* 107 */       result[index.intValue()] = elementType.disassemble(object, getSession(), null);
/*     */     }
/*     */     
/*     */ 
/* 111 */     return result;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\collection\PersistentListElementHolder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */