/*     */ package org.hibernate.collection;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.List;
/*     */ import org.dom4j.Element;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.type.NullableType;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentMapElementHolder
/*     */   extends PersistentIndexedElementHolder
/*     */ {
/*     */   public PersistentMapElementHolder(SessionImplementor session, Element element)
/*     */   {
/*  39 */     super(session, element);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PersistentMapElementHolder(SessionImplementor session, CollectionPersister persister, Serializable key)
/*     */     throws HibernateException
/*     */   {
/*  49 */     super(session, persister, key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initializeFromCache(CollectionPersister persister, Serializable disassembled, Object owner)
/*     */     throws HibernateException
/*     */   {
/*  61 */     Type elementType = persister.getElementType();
/*     */     
/*  63 */     Type indexType = persister.getIndexType();
/*     */     
/*  65 */     String indexNodeName = getIndexAttributeName(persister);
/*     */     
/*     */ 
/*     */ 
/*  69 */     Serializable[] cached = (Serializable[])disassembled;
/*     */     
/*     */ 
/*     */ 
/*  73 */     for (int i = 0; i < cached.length;)
/*     */     {
/*  75 */       Object index = indexType.assemble(cached[(i++)], getSession(), owner);
/*     */       
/*  77 */       Object object = elementType.assemble(cached[(i++)], getSession(), owner);
/*     */       
/*     */ 
/*     */ 
/*  81 */       Element subelement = this.element.addElement(persister.getElementNodeName());
/*     */       
/*  83 */       elementType.setToXMLNode(subelement, object, persister.getFactory());
/*     */       
/*     */ 
/*     */ 
/*  87 */       String indexString = ((NullableType)indexType).toXMLString(index, persister.getFactory());
/*     */       
/*  89 */       setIndex(subelement, indexNodeName, indexString);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Serializable disassemble(CollectionPersister persister)
/*     */     throws HibernateException
/*     */   {
/* 103 */     Type elementType = persister.getElementType();
/*     */     
/* 105 */     Type indexType = persister.getIndexType();
/*     */     
/* 107 */     String indexNodeName = getIndexAttributeName(persister);
/*     */     
/*     */ 
/*     */ 
/* 111 */     List elements = this.element.elements(persister.getElementNodeName());
/*     */     
/* 113 */     int length = elements.size();
/*     */     
/* 115 */     Serializable[] result = new Serializable[length * 2];
/*     */     
/* 117 */     for (int i = 0; i < length * 2;)
/*     */     {
/* 119 */       Element elem = (Element)elements.get(i / 2);
/*     */       
/* 121 */       Object object = elementType.fromXMLNode(elem, persister.getFactory());
/*     */       
/* 123 */       String indexString = getIndex(elem, indexNodeName, i);
/*     */       
/* 125 */       Object index = ((NullableType)indexType).fromXMLString(indexString, persister.getFactory());
/*     */       
/* 127 */       result[(i++)] = indexType.disassemble(index, getSession(), null);
/*     */       
/* 129 */       result[(i++)] = elementType.disassemble(object, getSession(), null);
/*     */     }
/*     */     
/*     */ 
/* 133 */     return result;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\collection\PersistentMapElementHolder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */