/*     */ package org.hibernate.collection;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.loader.CollectionAliases;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.type.CollectionType;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentBag
/*     */   extends AbstractPersistentCollection
/*     */   implements List
/*     */ {
/*     */   protected List bag;
/*     */   
/*     */   public PersistentBag(SessionImplementor session)
/*     */   {
/*  33 */     super(session);
/*     */   }
/*     */   
/*     */   public PersistentBag(SessionImplementor session, Collection coll) {
/*  37 */     super(session);
/*  38 */     if ((coll instanceof List)) {
/*  39 */       this.bag = ((List)coll);
/*     */     }
/*     */     else {
/*  42 */       this.bag = new ArrayList();
/*  43 */       Iterator iter = coll.iterator();
/*  44 */       while (iter.hasNext()) {
/*  45 */         this.bag.add(iter.next());
/*     */       }
/*     */     }
/*  48 */     setInitialized();
/*  49 */     setDirectlyAccessible(true);
/*     */   }
/*     */   
/*     */   public PersistentBag() {}
/*     */   
/*     */   public boolean isWrapper(Object collection) {
/*  55 */     return this.bag == collection;
/*     */   }
/*     */   
/*  58 */   public boolean empty() { return this.bag.isEmpty(); }
/*     */   
/*     */   public Iterator entries(CollectionPersister persister)
/*     */   {
/*  62 */     return this.bag.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */   public Object readFrom(ResultSet rs, CollectionPersister persister, CollectionAliases descriptor, Object owner)
/*     */     throws HibernateException, SQLException
/*     */   {
/*  69 */     Object element = persister.readElement(rs, owner, descriptor.getSuffixedElementAliases(), getSession());
/*  70 */     if (element != null) this.bag.add(element);
/*  71 */     return element;
/*     */   }
/*     */   
/*     */   public void beforeInitialize(CollectionPersister persister) {
/*  75 */     this.bag = ((List)persister.getCollectionType().instantiate());
/*     */   }
/*     */   
/*     */   public boolean equalsSnapshot(CollectionPersister persister) throws HibernateException {
/*  79 */     Type elementType = persister.getElementType();
/*  80 */     EntityMode entityMode = getSession().getEntityMode();
/*  81 */     List sn = (List)getSnapshot();
/*  82 */     if (sn.size() != this.bag.size()) return false;
/*  83 */     Iterator iter = this.bag.iterator();
/*  84 */     while (iter.hasNext()) {
/*  85 */       Object elt = iter.next();
/*  86 */       boolean unequal = countOccurrences(elt, this.bag, elementType, entityMode) != countOccurrences(elt, sn, elementType, entityMode);
/*     */       
/*  88 */       if (unequal) return false;
/*     */     }
/*  90 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isSnapshotEmpty(Serializable snapshot) {
/*  94 */     return ((Collection)snapshot).isEmpty();
/*     */   }
/*     */   
/*     */   private int countOccurrences(Object element, List list, Type elementType, EntityMode entityMode) throws HibernateException
/*     */   {
/*  99 */     Iterator iter = list.iterator();
/* 100 */     int result = 0;
/* 101 */     while (iter.hasNext()) {
/* 102 */       if (elementType.isSame(element, iter.next(), entityMode)) result++;
/*     */     }
/* 104 */     return result;
/*     */   }
/*     */   
/*     */   public Serializable getSnapshot(CollectionPersister persister) throws HibernateException
/*     */   {
/* 109 */     EntityMode entityMode = getSession().getEntityMode();
/* 110 */     ArrayList clonedList = new ArrayList(this.bag.size());
/* 111 */     Iterator iter = this.bag.iterator();
/* 112 */     while (iter.hasNext()) {
/* 113 */       clonedList.add(persister.getElementType().deepCopy(iter.next(), entityMode, persister.getFactory()));
/*     */     }
/* 115 */     return clonedList;
/*     */   }
/*     */   
/*     */   public Collection getOrphans(Serializable snapshot, String entityName) throws HibernateException {
/* 119 */     List sn = (List)snapshot;
/* 120 */     return getOrphans(sn, this.bag, entityName, getSession());
/*     */   }
/*     */   
/*     */ 
/*     */   public Serializable disassemble(CollectionPersister persister)
/*     */     throws HibernateException
/*     */   {
/* 127 */     int length = this.bag.size();
/* 128 */     Serializable[] result = new Serializable[length];
/* 129 */     for (int i = 0; i < length; i++) {
/* 130 */       result[i] = persister.getElementType().disassemble(this.bag.get(i), getSession(), null);
/*     */     }
/* 132 */     return result;
/*     */   }
/*     */   
/*     */   public void initializeFromCache(CollectionPersister persister, Serializable disassembled, Object owner) throws HibernateException
/*     */   {
/* 137 */     beforeInitialize(persister);
/* 138 */     Serializable[] array = (Serializable[])disassembled;
/* 139 */     for (int i = 0; i < array.length; i++) {
/* 140 */       Object element = persister.getElementType().assemble(array[i], getSession(), owner);
/* 141 */       if (element != null) this.bag.add(element);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean needsRecreate(CollectionPersister persister) {
/* 146 */     return !persister.isOneToMany();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator getDeletes(CollectionPersister persister, boolean indexIsFormula)
/*     */     throws HibernateException
/*     */   {
/* 160 */     Type elementType = persister.getElementType();
/* 161 */     EntityMode entityMode = getSession().getEntityMode();
/* 162 */     ArrayList deletes = new ArrayList();
/* 163 */     List sn = (List)getSnapshot();
/* 164 */     Iterator olditer = sn.iterator();
/* 165 */     int i = 0;
/* 166 */     while (olditer.hasNext()) {
/* 167 */       Object old = olditer.next();
/* 168 */       Iterator newiter = this.bag.iterator();
/* 169 */       boolean found = false;
/* 170 */       if ((this.bag.size() > i) && (elementType.isSame(old, this.bag.get(i++), entityMode)))
/*     */       {
/* 172 */         found = true;
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 177 */         while (newiter.hasNext()) {
/* 178 */           if (elementType.isSame(old, newiter.next(), entityMode)) {
/* 179 */             found = true;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 184 */       if (!found) deletes.add(old);
/*     */     }
/* 186 */     return deletes.iterator();
/*     */   }
/*     */   
/*     */   public boolean needsInserting(Object entry, int i, Type elemType) throws HibernateException
/*     */   {
/* 191 */     List sn = (List)getSnapshot();
/* 192 */     EntityMode entityMode = getSession().getEntityMode();
/* 193 */     if ((sn.size() > i) && (elemType.isSame(sn.get(i), entry, entityMode)))
/*     */     {
/* 195 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 200 */     Iterator olditer = sn.iterator();
/* 201 */     while (olditer.hasNext()) {
/* 202 */       Object old = olditer.next();
/* 203 */       if (elemType.isSame(old, entry, entityMode)) return false;
/*     */     }
/* 205 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isRowUpdatePossible()
/*     */   {
/* 210 */     return false;
/*     */   }
/*     */   
/*     */   public boolean needsUpdating(Object entry, int i, Type elemType)
/*     */   {
/* 215 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/* 222 */     return readSize() ? getCachedSize() : this.bag.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 229 */     return readSize() ? false : getCachedSize() == 0 ? true : this.bag.isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean contains(Object object)
/*     */   {
/* 236 */     Boolean exists = readElementExistence(object);
/* 237 */     return exists == null ? this.bag.contains(object) : exists.booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator iterator()
/*     */   {
/* 246 */     read();
/* 247 */     return new AbstractPersistentCollection.IteratorProxy(this, this.bag.iterator());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object[] toArray()
/*     */   {
/* 254 */     read();
/* 255 */     return this.bag.toArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object[] toArray(Object[] a)
/*     */   {
/* 262 */     read();
/* 263 */     return this.bag.toArray(a);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean add(Object object)
/*     */   {
/* 270 */     if (!isOperationQueueEnabled()) {
/* 271 */       write();
/* 272 */       return this.bag.add(object);
/*     */     }
/*     */     
/* 275 */     queueOperation(new SimpleAdd(object));
/* 276 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean remove(Object o)
/*     */   {
/* 284 */     write();
/* 285 */     return this.bag.remove(o);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean containsAll(Collection c)
/*     */   {
/* 292 */     read();
/* 293 */     return this.bag.containsAll(c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean addAll(Collection values)
/*     */   {
/* 300 */     if (values.size() == 0) return false;
/* 301 */     if (!isOperationQueueEnabled()) {
/* 302 */       write();
/* 303 */       return this.bag.addAll(values);
/*     */     }
/*     */     
/* 306 */     Iterator iter = values.iterator();
/* 307 */     while (iter.hasNext()) {
/* 308 */       queueOperation(new SimpleAdd(iter.next()));
/*     */     }
/* 310 */     return values.size() > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean removeAll(Collection c)
/*     */   {
/* 318 */     if (c.size() > 0) {
/* 319 */       write();
/* 320 */       return this.bag.removeAll(c);
/*     */     }
/*     */     
/* 323 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean retainAll(Collection c)
/*     */   {
/* 331 */     write();
/* 332 */     return this.bag.retainAll(c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 339 */     if (isClearQueueEnabled()) {
/* 340 */       queueOperation(new Clear());
/*     */     }
/*     */     else {
/* 343 */       write();
/* 344 */       this.bag.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public Object getIndex(Object entry, int i, CollectionPersister persister) {
/* 349 */     throw new UnsupportedOperationException("Bags don't have indexes");
/*     */   }
/*     */   
/*     */   public Object getElement(Object entry) {
/* 353 */     return entry;
/*     */   }
/*     */   
/*     */   public Object getSnapshotElement(Object entry, int i) {
/* 357 */     List sn = (List)getSnapshot();
/* 358 */     return sn.get(i);
/*     */   }
/*     */   
/*     */   public int occurrences(Object o) {
/* 362 */     read();
/* 363 */     Iterator iter = this.bag.iterator();
/* 364 */     int result = 0;
/* 365 */     while (iter.hasNext()) {
/* 366 */       if (o.equals(iter.next())) result++;
/*     */     }
/* 368 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(int i, Object o)
/*     */   {
/* 377 */     write();
/* 378 */     this.bag.add(i, o);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean addAll(int i, Collection c)
/*     */   {
/* 385 */     if (c.size() > 0) {
/* 386 */       write();
/* 387 */       return this.bag.addAll(i, c);
/*     */     }
/*     */     
/* 390 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object get(int i)
/*     */   {
/* 398 */     read();
/* 399 */     return this.bag.get(i);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int indexOf(Object o)
/*     */   {
/* 406 */     read();
/* 407 */     return this.bag.indexOf(o);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int lastIndexOf(Object o)
/*     */   {
/* 414 */     read();
/* 415 */     return this.bag.lastIndexOf(o);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ListIterator listIterator()
/*     */   {
/* 422 */     read();
/* 423 */     return new AbstractPersistentCollection.ListIteratorProxy(this, this.bag.listIterator());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ListIterator listIterator(int i)
/*     */   {
/* 430 */     read();
/* 431 */     return new AbstractPersistentCollection.ListIteratorProxy(this, this.bag.listIterator(i));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object remove(int i)
/*     */   {
/* 438 */     write();
/* 439 */     return this.bag.remove(i);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object set(int i, Object o)
/*     */   {
/* 446 */     write();
/* 447 */     return this.bag.set(i, o);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List subList(int start, int end)
/*     */   {
/* 454 */     read();
/* 455 */     return new AbstractPersistentCollection.ListProxy(this, this.bag.subList(start, end));
/*     */   }
/*     */   
/*     */   public String toString() {
/* 459 */     read();
/* 460 */     return this.bag.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean entryExists(Object entry, int i)
/*     */   {
/* 474 */     return entry != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 485 */     return super.equals(obj);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 492 */   public int hashCode() { return super.hashCode(); }
/*     */   
/*     */   final class Clear implements AbstractPersistentCollection.DelayedOperation {
/*     */     Clear() {}
/*     */     
/* 497 */     public void operate() { PersistentBag.this.bag.clear(); }
/*     */     
/*     */     public Object getAddedInstance() {
/* 500 */       return null;
/*     */     }
/*     */     
/* 503 */     public Object getOrphan() { throw new UnsupportedOperationException("queued clear cannot be used with orphan delete"); }
/*     */   }
/*     */   
/*     */   final class SimpleAdd implements AbstractPersistentCollection.DelayedOperation
/*     */   {
/*     */     private Object value;
/*     */     
/*     */     public SimpleAdd(Object value) {
/* 511 */       this.value = value;
/*     */     }
/*     */     
/* 514 */     public void operate() { PersistentBag.this.bag.add(this.value); }
/*     */     
/*     */     public Object getAddedInstance() {
/* 517 */       return this.value;
/*     */     }
/*     */     
/* 520 */     public Object getOrphan() { return null; }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\collection\PersistentBag.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */