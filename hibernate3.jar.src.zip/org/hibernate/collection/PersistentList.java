/*     */ package org.hibernate.collection;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.loader.CollectionAliases;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.type.CollectionType;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentList
/*     */   extends AbstractPersistentCollection
/*     */   implements List
/*     */ {
/*     */   protected List list;
/*     */   
/*     */   public Serializable getSnapshot(CollectionPersister persister)
/*     */     throws HibernateException
/*     */   {
/*  33 */     EntityMode entityMode = getSession().getEntityMode();
/*     */     
/*  35 */     ArrayList clonedList = new ArrayList(this.list.size());
/*  36 */     Iterator iter = this.list.iterator();
/*  37 */     while (iter.hasNext()) {
/*  38 */       Object deepCopy = persister.getElementType().deepCopy(iter.next(), entityMode, persister.getFactory());
/*     */       
/*  40 */       clonedList.add(deepCopy);
/*     */     }
/*  42 */     return clonedList;
/*     */   }
/*     */   
/*     */   public Collection getOrphans(Serializable snapshot, String entityName) throws HibernateException {
/*  46 */     List sn = (List)snapshot;
/*  47 */     return getOrphans(sn, this.list, entityName, getSession());
/*     */   }
/*     */   
/*     */   public boolean equalsSnapshot(CollectionPersister persister) throws HibernateException {
/*  51 */     Type elementType = persister.getElementType();
/*  52 */     List sn = (List)getSnapshot();
/*  53 */     if (sn.size() != this.list.size()) return false;
/*  54 */     Iterator iter = this.list.iterator();
/*  55 */     Iterator sniter = sn.iterator();
/*  56 */     while (iter.hasNext()) {
/*  57 */       if (elementType.isDirty(iter.next(), sniter.next(), getSession())) return false;
/*     */     }
/*  59 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isSnapshotEmpty(Serializable snapshot) {
/*  63 */     return ((Collection)snapshot).isEmpty();
/*     */   }
/*     */   
/*     */   public PersistentList(SessionImplementor session) {
/*  67 */     super(session);
/*     */   }
/*     */   
/*     */   public PersistentList(SessionImplementor session, List list) {
/*  71 */     super(session);
/*  72 */     this.list = list;
/*  73 */     setInitialized();
/*  74 */     setDirectlyAccessible(true);
/*     */   }
/*     */   
/*     */   public void beforeInitialize(CollectionPersister persister) {
/*  78 */     this.list = ((List)persister.getCollectionType().instantiate());
/*     */   }
/*     */   
/*     */   public boolean isWrapper(Object collection) {
/*  82 */     return this.list == collection;
/*     */   }
/*     */   
/*     */ 
/*     */   public PersistentList() {}
/*     */   
/*     */ 
/*     */   public int size()
/*     */   {
/*  91 */     return readSize() ? getCachedSize() : this.list.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/*  98 */     return readSize() ? false : getCachedSize() == 0 ? true : this.list.isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean contains(Object object)
/*     */   {
/* 105 */     Boolean exists = readElementExistence(object);
/* 106 */     return exists == null ? this.list.contains(object) : exists.booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator iterator()
/*     */   {
/* 115 */     read();
/* 116 */     return new AbstractPersistentCollection.IteratorProxy(this, this.list.iterator());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object[] toArray()
/*     */   {
/* 123 */     read();
/* 124 */     return this.list.toArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object[] toArray(Object[] array)
/*     */   {
/* 131 */     read();
/* 132 */     return this.list.toArray(array);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean add(Object object)
/*     */   {
/* 139 */     if (!isOperationQueueEnabled()) {
/* 140 */       write();
/* 141 */       return this.list.add(object);
/*     */     }
/*     */     
/* 144 */     queueOperation(new SimpleAdd(object));
/* 145 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean remove(Object value)
/*     */   {
/* 153 */     Boolean exists = isPutQueueEnabled() ? readElementExistence(value) : null;
/*     */     
/* 155 */     if (exists == null) {
/* 156 */       write();
/* 157 */       return this.list.remove(value);
/*     */     }
/* 159 */     if (exists.booleanValue()) {
/* 160 */       queueOperation(new SimpleRemove(value));
/* 161 */       return true;
/*     */     }
/*     */     
/* 164 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsAll(Collection coll)
/*     */   {
/* 172 */     read();
/* 173 */     return this.list.containsAll(coll);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean addAll(Collection values)
/*     */   {
/* 180 */     if (values.size() == 0) return false;
/* 181 */     if (!isOperationQueueEnabled()) {
/* 182 */       write();
/* 183 */       return this.list.addAll(values);
/*     */     }
/*     */     
/* 186 */     Iterator iter = values.iterator();
/* 187 */     while (iter.hasNext()) {
/* 188 */       queueOperation(new SimpleAdd(iter.next()));
/*     */     }
/* 190 */     return values.size() > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean addAll(int index, Collection coll)
/*     */   {
/* 198 */     if (coll.size() > 0) {
/* 199 */       write();
/* 200 */       return this.list.addAll(index, coll);
/*     */     }
/*     */     
/* 203 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean removeAll(Collection coll)
/*     */   {
/* 211 */     if (coll.size() > 0) {
/* 212 */       write();
/* 213 */       return this.list.removeAll(coll);
/*     */     }
/*     */     
/* 216 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean retainAll(Collection coll)
/*     */   {
/* 224 */     write();
/* 225 */     return this.list.retainAll(coll);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 232 */     if (isClearQueueEnabled()) {
/* 233 */       queueOperation(new Clear());
/*     */     }
/*     */     else {
/* 236 */       write();
/* 237 */       this.list.clear();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object get(int index)
/*     */   {
/* 245 */     if (index < 0) {
/* 246 */       throw new ArrayIndexOutOfBoundsException("negative index");
/*     */     }
/* 248 */     Object result = readElementByIndex(new Integer(index));
/* 249 */     return result == UNKNOWN ? this.list.get(index) : result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object set(int index, Object value)
/*     */   {
/* 256 */     if (index < 0) {
/* 257 */       throw new ArrayIndexOutOfBoundsException("negative index");
/*     */     }
/* 259 */     Object old = isPutQueueEnabled() ? readElementByIndex(new Integer(index)) : UNKNOWN;
/*     */     
/* 261 */     if (old == UNKNOWN) {
/* 262 */       write();
/* 263 */       return this.list.set(index, value);
/*     */     }
/*     */     
/* 266 */     queueOperation(new Set(index, value, old));
/* 267 */     return old;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(int index, Object value)
/*     */   {
/* 275 */     if (index < 0) {
/* 276 */       throw new ArrayIndexOutOfBoundsException("negative index");
/*     */     }
/* 278 */     if (!isOperationQueueEnabled()) {
/* 279 */       write();
/* 280 */       this.list.add(index, value);
/*     */     }
/*     */     else {
/* 283 */       queueOperation(new Add(index, value));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object remove(int index)
/*     */   {
/* 291 */     if (index < 0) {
/* 292 */       throw new ArrayIndexOutOfBoundsException("negative index");
/*     */     }
/* 294 */     Object old = isPutQueueEnabled() ? readElementByIndex(new Integer(index)) : UNKNOWN;
/*     */     
/* 296 */     if (old == UNKNOWN) {
/* 297 */       write();
/* 298 */       return this.list.remove(index);
/*     */     }
/*     */     
/* 301 */     queueOperation(new Remove(index, old));
/* 302 */     return old;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int indexOf(Object value)
/*     */   {
/* 310 */     read();
/* 311 */     return this.list.indexOf(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int lastIndexOf(Object value)
/*     */   {
/* 318 */     read();
/* 319 */     return this.list.lastIndexOf(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ListIterator listIterator()
/*     */   {
/* 326 */     read();
/* 327 */     return new AbstractPersistentCollection.ListIteratorProxy(this, this.list.listIterator());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ListIterator listIterator(int index)
/*     */   {
/* 334 */     read();
/* 335 */     return new AbstractPersistentCollection.ListIteratorProxy(this, this.list.listIterator(index));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List subList(int from, int to)
/*     */   {
/* 342 */     read();
/* 343 */     return new AbstractPersistentCollection.ListProxy(this, this.list.subList(from, to));
/*     */   }
/*     */   
/*     */   public boolean empty() {
/* 347 */     return this.list.isEmpty();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 351 */     read();
/* 352 */     return this.list.toString();
/*     */   }
/*     */   
/*     */   public Object readFrom(ResultSet rs, CollectionPersister persister, CollectionAliases descriptor, Object owner) throws HibernateException, SQLException
/*     */   {
/* 357 */     Object element = persister.readElement(rs, owner, descriptor.getSuffixedElementAliases(), getSession());
/* 358 */     int index = ((Integer)persister.readIndex(rs, descriptor.getSuffixedIndexAliases(), getSession())).intValue();
/*     */     
/*     */ 
/* 361 */     for (int i = this.list.size(); i <= index; i++) {
/* 362 */       this.list.add(i, null);
/*     */     }
/*     */     
/* 365 */     this.list.set(index, element);
/* 366 */     return element;
/*     */   }
/*     */   
/*     */   public Iterator entries(CollectionPersister persister) {
/* 370 */     return this.list.iterator();
/*     */   }
/*     */   
/*     */   public void initializeFromCache(CollectionPersister persister, Serializable disassembled, Object owner) throws HibernateException
/*     */   {
/* 375 */     beforeInitialize(persister);
/* 376 */     Serializable[] array = (Serializable[])disassembled;
/* 377 */     for (int i = 0; i < array.length; i++) {
/* 378 */       this.list.add(persister.getElementType().assemble(array[i], getSession(), owner));
/*     */     }
/*     */   }
/*     */   
/*     */   public Serializable disassemble(CollectionPersister persister)
/*     */     throws HibernateException
/*     */   {
/* 385 */     int length = this.list.size();
/* 386 */     Serializable[] result = new Serializable[length];
/* 387 */     for (int i = 0; i < length; i++) {
/* 388 */       result[i] = persister.getElementType().disassemble(this.list.get(i), getSession(), null);
/*     */     }
/* 390 */     return result;
/*     */   }
/*     */   
/*     */   public Iterator getDeletes(CollectionPersister persister, boolean indexIsFormula) throws HibernateException
/*     */   {
/* 395 */     List deletes = new ArrayList();
/* 396 */     List sn = (List)getSnapshot();
/*     */     int end;
/* 398 */     int end; if (sn.size() > this.list.size()) {
/* 399 */       for (int i = this.list.size(); i < sn.size(); i++) {
/* 400 */         deletes.add(indexIsFormula ? sn.get(i) : new Integer(i));
/*     */       }
/* 402 */       end = this.list.size();
/*     */     }
/*     */     else {
/* 405 */       end = sn.size();
/*     */     }
/* 407 */     for (int i = 0; i < end; i++) {
/* 408 */       if ((this.list.get(i) == null) && (sn.get(i) != null)) {
/* 409 */         deletes.add(indexIsFormula ? sn.get(i) : new Integer(i));
/*     */       }
/*     */     }
/* 412 */     return deletes.iterator();
/*     */   }
/*     */   
/*     */   public boolean needsInserting(Object entry, int i, Type elemType) throws HibernateException {
/* 416 */     List sn = (List)getSnapshot();
/* 417 */     return (this.list.get(i) != null) && ((i >= sn.size()) || (sn.get(i) == null));
/*     */   }
/*     */   
/*     */   public boolean needsUpdating(Object entry, int i, Type elemType) throws HibernateException {
/* 421 */     List sn = (List)getSnapshot();
/* 422 */     return (i < sn.size()) && (sn.get(i) != null) && (this.list.get(i) != null) && (elemType.isDirty(this.list.get(i), sn.get(i), getSession()));
/*     */   }
/*     */   
/*     */   public Object getIndex(Object entry, int i, CollectionPersister persister)
/*     */   {
/* 427 */     return new Integer(i);
/*     */   }
/*     */   
/*     */   public Object getElement(Object entry) {
/* 431 */     return entry;
/*     */   }
/*     */   
/*     */   public Object getSnapshotElement(Object entry, int i) {
/* 435 */     List sn = (List)getSnapshot();
/* 436 */     return sn.get(i);
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/* 440 */     read();
/* 441 */     return this.list.equals(other);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 445 */     read();
/* 446 */     return this.list.hashCode();
/*     */   }
/*     */   
/*     */ 
/* 450 */   public boolean entryExists(Object entry, int i) { return entry != null; }
/*     */   
/*     */   final class Clear implements AbstractPersistentCollection.DelayedOperation {
/*     */     Clear() {}
/*     */     
/* 455 */     public void operate() { PersistentList.this.list.clear(); }
/*     */     
/*     */     public Object getAddedInstance() {
/* 458 */       return null;
/*     */     }
/*     */     
/* 461 */     public Object getOrphan() { throw new UnsupportedOperationException("queued clear cannot be used with orphan delete"); }
/*     */   }
/*     */   
/*     */   final class SimpleAdd implements AbstractPersistentCollection.DelayedOperation
/*     */   {
/*     */     private Object value;
/*     */     
/*     */     public SimpleAdd(Object value) {
/* 469 */       this.value = value;
/*     */     }
/*     */     
/* 472 */     public void operate() { PersistentList.this.list.add(this.value); }
/*     */     
/*     */     public Object getAddedInstance() {
/* 475 */       return this.value;
/*     */     }
/*     */     
/* 478 */     public Object getOrphan() { return null; }
/*     */   }
/*     */   
/*     */   final class Add implements AbstractPersistentCollection.DelayedOperation
/*     */   {
/*     */     private int index;
/*     */     private Object value;
/*     */     
/*     */     public Add(int index, Object value) {
/* 487 */       this.index = index;
/* 488 */       this.value = value;
/*     */     }
/*     */     
/* 491 */     public void operate() { PersistentList.this.list.add(this.index, this.value); }
/*     */     
/*     */     public Object getAddedInstance() {
/* 494 */       return this.value;
/*     */     }
/*     */     
/* 497 */     public Object getOrphan() { return null; }
/*     */   }
/*     */   
/*     */   final class Set implements AbstractPersistentCollection.DelayedOperation
/*     */   {
/*     */     private int index;
/*     */     private Object value;
/*     */     private Object old;
/*     */     
/*     */     public Set(int index, Object value, Object old) {
/* 507 */       this.index = index;
/* 508 */       this.value = value;
/* 509 */       this.old = old;
/*     */     }
/*     */     
/* 512 */     public void operate() { PersistentList.this.list.set(this.index, this.value); }
/*     */     
/*     */     public Object getAddedInstance() {
/* 515 */       return this.value;
/*     */     }
/*     */     
/* 518 */     public Object getOrphan() { return this.old; }
/*     */   }
/*     */   
/*     */   final class Remove implements AbstractPersistentCollection.DelayedOperation
/*     */   {
/*     */     private int index;
/*     */     private Object old;
/*     */     
/*     */     public Remove(int index, Object old) {
/* 527 */       this.index = index;
/* 528 */       this.old = old;
/*     */     }
/*     */     
/* 531 */     public void operate() { PersistentList.this.list.remove(this.index); }
/*     */     
/*     */     public Object getAddedInstance() {
/* 534 */       return null;
/*     */     }
/*     */     
/* 537 */     public Object getOrphan() { return this.old; }
/*     */   }
/*     */   
/*     */   final class SimpleRemove implements AbstractPersistentCollection.DelayedOperation
/*     */   {
/*     */     private Object value;
/*     */     
/*     */     public SimpleRemove(Object value) {
/* 545 */       this.value = value;
/*     */     }
/*     */     
/* 548 */     public void operate() { PersistentList.this.list.remove(this.value); }
/*     */     
/*     */     public Object getAddedInstance() {
/* 551 */       return null;
/*     */     }
/*     */     
/* 554 */     public Object getOrphan() { return this.value; }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\collection\PersistentList.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */