/*     */ package org.hibernate.collection;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeMap;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.persister.collection.BasicCollectionPersister;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentSortedSet
/*     */   extends PersistentSet
/*     */   implements SortedSet
/*     */ {
/*     */   protected Comparator comparator;
/*     */   
/*     */   protected Serializable snapshot(BasicCollectionPersister persister, EntityMode entityMode)
/*     */     throws HibernateException
/*     */   {
/*  30 */     TreeMap clonedSet = new TreeMap(this.comparator);
/*  31 */     Iterator iter = this.set.iterator();
/*  32 */     while (iter.hasNext()) {
/*  33 */       Object copy = persister.getElementType().deepCopy(iter.next(), entityMode, persister.getFactory());
/*  34 */       clonedSet.put(copy, copy);
/*     */     }
/*  36 */     return clonedSet;
/*     */   }
/*     */   
/*     */   public void setComparator(Comparator comparator) {
/*  40 */     this.comparator = comparator;
/*     */   }
/*     */   
/*     */   public PersistentSortedSet(SessionImplementor session) {
/*  44 */     super(session);
/*     */   }
/*     */   
/*     */   public PersistentSortedSet(SessionImplementor session, SortedSet set) {
/*  48 */     super(session, set);
/*  49 */     this.comparator = set.comparator();
/*     */   }
/*     */   
/*     */ 
/*     */   public PersistentSortedSet() {}
/*     */   
/*     */ 
/*     */   public Comparator comparator()
/*     */   {
/*  58 */     return this.comparator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public SortedSet subSet(Object fromElement, Object toElement)
/*     */   {
/*  65 */     read();
/*     */     
/*  67 */     SortedSet s = ((SortedSet)this.set).subSet(fromElement, toElement);
/*  68 */     return new SubSetProxy(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public SortedSet headSet(Object toElement)
/*     */   {
/*  75 */     read();
/*  76 */     SortedSet s = ((SortedSet)this.set).headSet(toElement);
/*  77 */     return new SubSetProxy(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public SortedSet tailSet(Object fromElement)
/*     */   {
/*  84 */     read();
/*  85 */     SortedSet s = ((SortedSet)this.set).tailSet(fromElement);
/*  86 */     return new SubSetProxy(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object first()
/*     */   {
/*  93 */     read();
/*  94 */     return ((SortedSet)this.set).first();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object last()
/*     */   {
/* 101 */     read();
/* 102 */     return ((SortedSet)this.set).last();
/*     */   }
/*     */   
/*     */   class SubSetProxy extends AbstractPersistentCollection.SetProxy implements SortedSet
/*     */   {
/*     */     SubSetProxy(SortedSet s)
/*     */     {
/* 109 */       super(s);
/*     */     }
/*     */     
/*     */     public Comparator comparator() {
/* 113 */       return ((SortedSet)this.set).comparator();
/*     */     }
/*     */     
/*     */     public Object first() {
/* 117 */       return ((SortedSet)this.set).first();
/*     */     }
/*     */     
/*     */     public SortedSet headSet(Object toValue) {
/* 121 */       return new SubSetProxy(PersistentSortedSet.this, ((SortedSet)this.set).headSet(toValue));
/*     */     }
/*     */     
/*     */     public Object last() {
/* 125 */       return ((SortedSet)this.set).last();
/*     */     }
/*     */     
/*     */     public SortedSet subSet(Object fromValue, Object toValue) {
/* 129 */       return new SubSetProxy(PersistentSortedSet.this, ((SortedSet)this.set).subSet(fromValue, toValue));
/*     */     }
/*     */     
/*     */     public SortedSet tailSet(Object fromValue) {
/* 133 */       return new SubSetProxy(PersistentSortedSet.this, ((SortedSet)this.set).tailSet(fromValue));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\collection\PersistentSortedSet.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */