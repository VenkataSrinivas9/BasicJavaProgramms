/*     */ package org.hibernate.collection;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Set;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.LazyInitializationException;
/*     */ import org.hibernate.engine.CollectionEntry;
/*     */ import org.hibernate.engine.ForeignKeys;
/*     */ import org.hibernate.engine.PersistenceContext;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.engine.TypedValue;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.pretty.MessageHelper;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.CollectionHelper;
/*     */ import org.hibernate.util.EmptyIterator;
/*     */ import org.hibernate.util.MarkerObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractPersistentCollection
/*     */   implements Serializable, PersistentCollection
/*     */ {
/*     */   private transient SessionImplementor session;
/*     */   private boolean initialized;
/*     */   private transient List operationQueue;
/*     */   private transient boolean directlyAccessible;
/*     */   private transient boolean initializing;
/*     */   private Object owner;
/*  40 */   private int cachedSize = -1;
/*     */   
/*     */   private String role;
/*     */   
/*     */   private Serializable key;
/*     */   private boolean dirty;
/*     */   private Serializable storedSnapshot;
/*     */   
/*     */   public final String getRole()
/*     */   {
/*  50 */     return this.role;
/*     */   }
/*     */   
/*     */   public final Serializable getKey() {
/*  54 */     return this.key;
/*     */   }
/*     */   
/*     */   public final boolean isUnreferenced() {
/*  58 */     return this.role == null;
/*     */   }
/*     */   
/*     */   public final boolean isDirty() {
/*  62 */     return this.dirty;
/*     */   }
/*     */   
/*     */   public final void clearDirty() {
/*  66 */     this.dirty = false;
/*     */   }
/*     */   
/*     */   public final void dirty() {
/*  70 */     this.dirty = true;
/*     */   }
/*     */   
/*     */   public final Serializable getStoredSnapshot() {
/*  74 */     return this.storedSnapshot;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean empty();
/*     */   
/*     */ 
/*     */ 
/*     */   protected final void read()
/*     */   {
/*  86 */     initialize(false);
/*     */   }
/*     */   
/*     */ 
/*     */   protected boolean readSize()
/*     */   {
/*  92 */     if (!this.initialized) {
/*  93 */       if ((this.cachedSize != -1) && (!hasQueuedOperations())) {
/*  94 */         return true;
/*     */       }
/*     */       
/*  97 */       throwLazyInitializationExceptionIfNotConnected();
/*  98 */       CollectionEntry entry = this.session.getPersistenceContext().getCollectionEntry(this);
/*  99 */       CollectionPersister persister = entry.getLoadedPersister();
/* 100 */       if (persister.isExtraLazy()) {
/* 101 */         if (hasQueuedOperations()) {
/* 102 */           this.session.flush();
/*     */         }
/* 104 */         this.cachedSize = persister.getSize(entry.getLoadedKey(), this.session);
/* 105 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 109 */     read();
/* 110 */     return false;
/*     */   }
/*     */   
/*     */   protected Boolean readIndexExistence(Object index) {
/* 114 */     if (!this.initialized) {
/* 115 */       throwLazyInitializationExceptionIfNotConnected();
/* 116 */       CollectionEntry entry = this.session.getPersistenceContext().getCollectionEntry(this);
/* 117 */       CollectionPersister persister = entry.getLoadedPersister();
/* 118 */       if (persister.isExtraLazy()) {
/* 119 */         if (hasQueuedOperations()) {
/* 120 */           this.session.flush();
/*     */         }
/* 122 */         return new Boolean(persister.indexExists(entry.getLoadedKey(), index, this.session));
/*     */       }
/*     */     }
/* 125 */     read();
/* 126 */     return null;
/*     */   }
/*     */   
/*     */   protected Boolean readElementExistence(Object element)
/*     */   {
/* 131 */     if (!this.initialized) {
/* 132 */       throwLazyInitializationExceptionIfNotConnected();
/* 133 */       CollectionEntry entry = this.session.getPersistenceContext().getCollectionEntry(this);
/* 134 */       CollectionPersister persister = entry.getLoadedPersister();
/* 135 */       if (persister.isExtraLazy()) {
/* 136 */         if (hasQueuedOperations()) {
/* 137 */           this.session.flush();
/*     */         }
/* 139 */         return new Boolean(persister.elementExists(entry.getLoadedKey(), element, this.session));
/*     */       }
/*     */     }
/* 142 */     read();
/* 143 */     return null;
/*     */   }
/*     */   
/*     */ 
/* 147 */   protected static final Object UNKNOWN = new MarkerObject("UNKNOWN");
/*     */   
/*     */   protected Object readElementByIndex(Object index) {
/* 150 */     if (!this.initialized) {
/* 151 */       throwLazyInitializationExceptionIfNotConnected();
/* 152 */       CollectionEntry entry = this.session.getPersistenceContext().getCollectionEntry(this);
/* 153 */       CollectionPersister persister = entry.getLoadedPersister();
/* 154 */       if (persister.isExtraLazy()) {
/* 155 */         if (hasQueuedOperations()) {
/* 156 */           this.session.flush();
/*     */         }
/* 158 */         return persister.getElementByIndex(entry.getLoadedKey(), index, this.session, this.owner);
/*     */       }
/*     */     }
/* 161 */     read();
/* 162 */     return UNKNOWN;
/*     */   }
/*     */   
/*     */   protected int getCachedSize()
/*     */   {
/* 167 */     return this.cachedSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private final boolean isConnectedToSession()
/*     */   {
/* 174 */     return (this.session != null) && (this.session.isOpen()) && (this.session.getPersistenceContext().containsCollection(this));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void write()
/*     */   {
/* 183 */     initialize(true);
/* 184 */     dirty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isOperationQueueEnabled()
/*     */   {
/* 191 */     return (!this.initialized) && (isConnectedToSession()) && (isInverseCollection());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isPutQueueEnabled()
/*     */   {
/* 201 */     return (!this.initialized) && (isConnectedToSession()) && (isInverseOneToManyOrNoOrphanDelete());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isClearQueueEnabled()
/*     */   {
/* 211 */     return (!this.initialized) && (isConnectedToSession()) && (isInverseCollectionNoOrphanDelete());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isInverseCollection()
/*     */   {
/* 220 */     CollectionEntry ce = this.session.getPersistenceContext().getCollectionEntry(this);
/* 221 */     return (ce != null) && (ce.getLoadedPersister().isInverse());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isInverseCollectionNoOrphanDelete()
/*     */   {
/* 229 */     CollectionEntry ce = this.session.getPersistenceContext().getCollectionEntry(this);
/* 230 */     return (ce != null) && (ce.getLoadedPersister().isInverse()) && (!ce.getLoadedPersister().hasOrphanDelete());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isInverseOneToManyOrNoOrphanDelete()
/*     */   {
/* 240 */     CollectionEntry ce = this.session.getPersistenceContext().getCollectionEntry(this);
/* 241 */     return (ce != null) && (ce.getLoadedPersister().isInverse()) && ((ce.getLoadedPersister().isOneToMany()) || (!ce.getLoadedPersister().hasOrphanDelete()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void queueOperation(Object element)
/*     */   {
/* 251 */     if (this.operationQueue == null) this.operationQueue = new ArrayList(10);
/* 252 */     this.operationQueue.add(element);
/* 253 */     this.dirty = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void performQueuedOperations()
/*     */   {
/* 261 */     for (int i = 0; i < this.operationQueue.size(); i++) {
/* 262 */       ((DelayedOperation)this.operationQueue.get(i)).operate();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setSnapshot(Serializable key, String role, Serializable snapshot)
/*     */   {
/* 270 */     this.key = key;
/* 271 */     this.role = role;
/* 272 */     this.storedSnapshot = snapshot;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void postAction()
/*     */   {
/* 280 */     this.operationQueue = null;
/* 281 */     this.cachedSize = -1;
/* 282 */     clearDirty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public AbstractPersistentCollection() {}
/*     */   
/*     */ 
/*     */   protected AbstractPersistentCollection(SessionImplementor session)
/*     */   {
/* 292 */     this.session = session;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getValue()
/*     */   {
/* 299 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void beginRead()
/*     */   {
/* 307 */     this.initializing = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean endRead()
/*     */   {
/* 315 */     return afterInitialize();
/*     */   }
/*     */   
/*     */   public boolean afterInitialize() {
/* 319 */     setInitialized();
/*     */     
/* 321 */     if (this.operationQueue != null) {
/* 322 */       performQueuedOperations();
/* 323 */       this.operationQueue = null;
/* 324 */       this.cachedSize = -1;
/* 325 */       return false;
/*     */     }
/*     */     
/* 328 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void initialize(boolean writing)
/*     */   {
/* 339 */     if (!this.initialized) {
/* 340 */       if (this.initializing) {
/* 341 */         throw new LazyInitializationException("illegal access to loading collection");
/*     */       }
/* 343 */       throwLazyInitializationExceptionIfNotConnected();
/* 344 */       this.session.initializeCollection(this, writing);
/*     */     }
/*     */   }
/*     */   
/*     */   private void throwLazyInitializationExceptionIfNotConnected() {
/* 349 */     if (!isConnectedToSession()) {
/* 350 */       throwLazyInitializationException("no session or session was closed");
/*     */     }
/* 352 */     if (!this.session.isConnected()) {
/* 353 */       throwLazyInitializationException("session is disconnected");
/*     */     }
/*     */   }
/*     */   
/*     */   private void throwLazyInitializationException(String message) {
/* 358 */     throw new LazyInitializationException("failed to lazily initialize a collection" + (this.role == null ? "" : new StringBuffer().append(" of role: ").append(this.role).toString()) + ", " + message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void setInitialized()
/*     */   {
/* 366 */     this.initializing = false;
/* 367 */     this.initialized = true;
/*     */   }
/*     */   
/*     */   protected final void setDirectlyAccessible(boolean directlyAccessible) {
/* 371 */     this.directlyAccessible = directlyAccessible;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDirectlyAccessible()
/*     */   {
/* 379 */     return this.directlyAccessible;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean unsetSession(SessionImplementor currentSession)
/*     */   {
/* 387 */     if (currentSession == this.session) {
/* 388 */       this.session = null;
/* 389 */       return true;
/*     */     }
/*     */     
/* 392 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean setCurrentSession(SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/* 403 */     if (session == this.session) {
/* 404 */       return false;
/*     */     }
/*     */     
/* 407 */     if (isConnectedToSession()) {
/* 408 */       CollectionEntry ce = session.getPersistenceContext().getCollectionEntry(this);
/* 409 */       if (ce == null) {
/* 410 */         throw new HibernateException("Illegal attempt to associate a collection with two open sessions");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 415 */       throw new HibernateException("Illegal attempt to associate a collection with two open sessions: " + MessageHelper.collectionInfoString(ce.getLoadedPersister(), ce.getLoadedKey(), session.getFactory()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 426 */     this.session = session;
/* 427 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean needsRecreate(CollectionPersister persister)
/*     */   {
/* 436 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void forceInitialization()
/*     */     throws HibernateException
/*     */   {
/* 444 */     if (!this.initialized) {
/* 445 */       if (this.initializing) {
/* 446 */         throw new AssertionFailure("force initialize loading collection");
/*     */       }
/* 448 */       if (this.session == null) {
/* 449 */         throw new HibernateException("collection is not associated with any session");
/*     */       }
/* 451 */       if (!this.session.isConnected()) {
/* 452 */         throw new HibernateException("disconnected session");
/*     */       }
/* 454 */       this.session.initializeCollection(this, false);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final Serializable getSnapshot()
/*     */   {
/* 463 */     return this.session.getPersistenceContext().getSnapshot(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean wasInitialized()
/*     */   {
/* 470 */     return this.initialized;
/*     */   }
/*     */   
/*     */   public boolean isRowUpdatePossible() {
/* 474 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean hasQueuedOperations()
/*     */   {
/* 481 */     return this.operationQueue != null;
/*     */   }
/*     */   
/*     */ 
/*     */   public final Iterator queuedAdditionIterator()
/*     */   {
/* 487 */     if (hasQueuedOperations()) {
/* 488 */       new Iterator() {
/* 489 */         int i = 0;
/*     */         
/* 491 */         public Object next() { return ((AbstractPersistentCollection.DelayedOperation)AbstractPersistentCollection.this.operationQueue.get(this.i++)).getAddedInstance(); }
/*     */         
/*     */         public boolean hasNext() {
/* 494 */           return this.i < AbstractPersistentCollection.this.operationQueue.size();
/*     */         }
/*     */         
/* 497 */         public void remove() { throw new UnsupportedOperationException(); }
/*     */       };
/*     */     }
/*     */     
/*     */ 
/* 502 */     return EmptyIterator.INSTANCE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final Collection getQueuedOrphans(String entityName)
/*     */   {
/* 509 */     if (hasQueuedOperations()) {
/* 510 */       Collection additions = new ArrayList(this.operationQueue.size());
/* 511 */       Collection removals = new ArrayList(this.operationQueue.size());
/* 512 */       for (int i = 0; i < this.operationQueue.size(); i++) {
/* 513 */         DelayedOperation op = (DelayedOperation)this.operationQueue.get(i);
/* 514 */         additions.add(op.getAddedInstance());
/* 515 */         removals.add(op.getOrphan());
/*     */       }
/* 517 */       return getOrphans(removals, additions, entityName, this.session);
/*     */     }
/*     */     
/* 520 */     return CollectionHelper.EMPTY_COLLECTION;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void preInsert(CollectionPersister persister)
/*     */     throws HibernateException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void afterRowInsert(CollectionPersister persister, Object entry, int i)
/*     */     throws HibernateException
/*     */   {}
/*     */   
/*     */ 
/*     */   public abstract Collection getOrphans(Serializable paramSerializable, String paramString)
/*     */     throws HibernateException;
/*     */   
/*     */ 
/*     */   protected final SessionImplementor getSession()
/*     */   {
/* 542 */     return this.session;
/*     */   }
/*     */   
/*     */   final class IteratorProxy implements Iterator {
/*     */     private final Iterator iter;
/*     */     
/* 548 */     IteratorProxy(Iterator iter) { this.iter = iter; }
/*     */     
/*     */     public boolean hasNext() {
/* 551 */       return this.iter.hasNext();
/*     */     }
/*     */     
/*     */     public Object next() {
/* 555 */       return this.iter.next();
/*     */     }
/*     */     
/*     */     public void remove() {
/* 559 */       AbstractPersistentCollection.this.write();
/* 560 */       this.iter.remove();
/*     */     }
/*     */   }
/*     */   
/*     */   final class ListIteratorProxy
/*     */     implements ListIterator {
/*     */     private final ListIterator iter;
/*     */     
/* 568 */     ListIteratorProxy(ListIterator iter) { this.iter = iter; }
/*     */     
/*     */     public void add(Object o) {
/* 571 */       AbstractPersistentCollection.this.write();
/* 572 */       this.iter.add(o);
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 576 */       return this.iter.hasNext();
/*     */     }
/*     */     
/*     */     public boolean hasPrevious() {
/* 580 */       return this.iter.hasPrevious();
/*     */     }
/*     */     
/*     */     public Object next() {
/* 584 */       return this.iter.next();
/*     */     }
/*     */     
/*     */     public int nextIndex() {
/* 588 */       return this.iter.nextIndex();
/*     */     }
/*     */     
/*     */     public Object previous() {
/* 592 */       return this.iter.previous();
/*     */     }
/*     */     
/*     */     public int previousIndex() {
/* 596 */       return this.iter.previousIndex();
/*     */     }
/*     */     
/*     */     public void remove() {
/* 600 */       AbstractPersistentCollection.this.write();
/* 601 */       this.iter.remove();
/*     */     }
/*     */     
/*     */     public void set(Object o) {
/* 605 */       AbstractPersistentCollection.this.write();
/* 606 */       this.iter.set(o);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   class SetProxy
/*     */     implements Set
/*     */   {
/*     */     final Collection set;
/*     */     
/* 616 */     SetProxy(Collection set) { this.set = set; }
/*     */     
/*     */     public boolean add(Object o) {
/* 619 */       AbstractPersistentCollection.this.write();
/* 620 */       return this.set.add(o);
/*     */     }
/*     */     
/*     */     public boolean addAll(Collection c) {
/* 624 */       AbstractPersistentCollection.this.write();
/* 625 */       return this.set.addAll(c);
/*     */     }
/*     */     
/*     */     public void clear() {
/* 629 */       AbstractPersistentCollection.this.write();
/* 630 */       this.set.clear();
/*     */     }
/*     */     
/*     */     public boolean contains(Object o) {
/* 634 */       return this.set.contains(o);
/*     */     }
/*     */     
/*     */     public boolean containsAll(Collection c) {
/* 638 */       return this.set.containsAll(c);
/*     */     }
/*     */     
/*     */     public boolean isEmpty() {
/* 642 */       return this.set.isEmpty();
/*     */     }
/*     */     
/*     */     public Iterator iterator() {
/* 646 */       return new AbstractPersistentCollection.IteratorProxy(AbstractPersistentCollection.this, this.set.iterator());
/*     */     }
/*     */     
/*     */     public boolean remove(Object o) {
/* 650 */       AbstractPersistentCollection.this.write();
/* 651 */       return this.set.remove(o);
/*     */     }
/*     */     
/*     */     public boolean removeAll(Collection c) {
/* 655 */       AbstractPersistentCollection.this.write();
/* 656 */       return this.set.removeAll(c);
/*     */     }
/*     */     
/*     */     public boolean retainAll(Collection c) {
/* 660 */       AbstractPersistentCollection.this.write();
/* 661 */       return this.set.retainAll(c);
/*     */     }
/*     */     
/*     */     public int size() {
/* 665 */       return this.set.size();
/*     */     }
/*     */     
/*     */     public Object[] toArray() {
/* 669 */       return this.set.toArray();
/*     */     }
/*     */     
/*     */     public Object[] toArray(Object[] array) {
/* 673 */       return this.set.toArray(array);
/*     */     }
/*     */   }
/*     */   
/*     */   final class ListProxy implements List
/*     */   {
/*     */     private final List list;
/*     */     
/*     */     ListProxy(List list)
/*     */     {
/* 683 */       this.list = list;
/*     */     }
/*     */     
/*     */     public void add(int index, Object value) {
/* 687 */       AbstractPersistentCollection.this.write();
/* 688 */       this.list.add(index, value);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean add(Object o)
/*     */     {
/* 695 */       AbstractPersistentCollection.this.write();
/* 696 */       return this.list.add(o);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean addAll(Collection c)
/*     */     {
/* 703 */       AbstractPersistentCollection.this.write();
/* 704 */       return this.list.addAll(c);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean addAll(int i, Collection c)
/*     */     {
/* 711 */       AbstractPersistentCollection.this.write();
/* 712 */       return this.list.addAll(i, c);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void clear()
/*     */     {
/* 719 */       AbstractPersistentCollection.this.write();
/* 720 */       this.list.clear();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean contains(Object o)
/*     */     {
/* 727 */       return this.list.contains(o);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean containsAll(Collection c)
/*     */     {
/* 734 */       return this.list.containsAll(c);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Object get(int i)
/*     */     {
/* 741 */       return this.list.get(i);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public int indexOf(Object o)
/*     */     {
/* 748 */       return this.list.indexOf(o);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean isEmpty()
/*     */     {
/* 755 */       return this.list.isEmpty();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Iterator iterator()
/*     */     {
/* 762 */       return new AbstractPersistentCollection.IteratorProxy(AbstractPersistentCollection.this, this.list.iterator());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public int lastIndexOf(Object o)
/*     */     {
/* 769 */       return this.list.lastIndexOf(o);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public ListIterator listIterator()
/*     */     {
/* 776 */       return new AbstractPersistentCollection.ListIteratorProxy(AbstractPersistentCollection.this, this.list.listIterator());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public ListIterator listIterator(int i)
/*     */     {
/* 783 */       return new AbstractPersistentCollection.ListIteratorProxy(AbstractPersistentCollection.this, this.list.listIterator(i));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Object remove(int i)
/*     */     {
/* 790 */       AbstractPersistentCollection.this.write();
/* 791 */       return this.list.remove(i);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean remove(Object o)
/*     */     {
/* 798 */       AbstractPersistentCollection.this.write();
/* 799 */       return this.list.remove(o);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean removeAll(Collection c)
/*     */     {
/* 806 */       AbstractPersistentCollection.this.write();
/* 807 */       return this.list.removeAll(c);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean retainAll(Collection c)
/*     */     {
/* 814 */       AbstractPersistentCollection.this.write();
/* 815 */       return this.list.retainAll(c);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Object set(int i, Object o)
/*     */     {
/* 822 */       AbstractPersistentCollection.this.write();
/* 823 */       return this.list.set(i, o);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public int size()
/*     */     {
/* 830 */       return this.list.size();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public List subList(int i, int j)
/*     */     {
/* 837 */       return this.list.subList(i, j);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Object[] toArray()
/*     */     {
/* 844 */       return this.list.toArray();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Object[] toArray(Object[] array)
/*     */     {
/* 851 */       return this.list.toArray(array);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static Collection getOrphans(Collection oldElements, Collection currentElements, String entityName, SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/* 876 */     if (currentElements.size() == 0) return oldElements;
/* 877 */     if (oldElements.size() == 0) { return oldElements;
/*     */     }
/* 879 */     Type idType = session.getFactory().getEntityPersister(entityName).getIdentifierType();
/*     */     
/*     */ 
/* 882 */     Collection res = new ArrayList();
/*     */     
/*     */ 
/* 885 */     Set currentIds = new HashSet();
/* 886 */     for (Iterator it = currentElements.iterator(); it.hasNext();) {
/* 887 */       Object current = it.next();
/* 888 */       if ((current != null) && (ForeignKeys.isNotTransient(entityName, current, null, session))) {
/* 889 */         Serializable currentId = ForeignKeys.getEntityIdentifierIfNotUnsaved(entityName, current, session);
/* 890 */         currentIds.add(new TypedValue(idType, currentId, session.getEntityMode()));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 895 */     for (Iterator it = oldElements.iterator(); it.hasNext();) {
/* 896 */       Object old = it.next();
/* 897 */       Serializable oldId = ForeignKeys.getEntityIdentifierIfNotUnsaved(entityName, old, session);
/* 898 */       if (!currentIds.contains(new TypedValue(idType, oldId, session.getEntityMode()))) {
/* 899 */         res.add(old);
/*     */       }
/*     */     }
/*     */     
/* 903 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void identityRemove(Collection list, Object object, String entityName, SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/* 913 */     if ((object != null) && (ForeignKeys.isNotTransient(entityName, object, null, session)))
/*     */     {
/* 915 */       Type idType = session.getFactory().getEntityPersister(entityName).getIdentifierType();
/*     */       
/* 917 */       Serializable idOfCurrent = ForeignKeys.getEntityIdentifierIfNotUnsaved(entityName, object, session);
/* 918 */       Iterator iter = list.iterator();
/* 919 */       while (iter.hasNext()) {
/* 920 */         Serializable idOfOld = ForeignKeys.getEntityIdentifierIfNotUnsaved(entityName, iter.next(), session);
/* 921 */         if (idType.isEqual(idOfCurrent, idOfOld, session.getEntityMode(), session.getFactory())) {
/* 922 */           iter.remove();
/* 923 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Object getIdentifier(Object entry, int i)
/*     */   {
/* 931 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Object getOwner() {
/* 935 */     return this.owner;
/*     */   }
/*     */   
/*     */   public void setOwner(Object owner) {
/* 939 */     this.owner = owner;
/*     */   }
/*     */   
/*     */   protected static abstract interface DelayedOperation
/*     */   {
/*     */     public abstract void operate();
/*     */     
/*     */     public abstract Object getAddedInstance();
/*     */     
/*     */     public abstract Object getOrphan();
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\collection\AbstractPersistentCollection.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */