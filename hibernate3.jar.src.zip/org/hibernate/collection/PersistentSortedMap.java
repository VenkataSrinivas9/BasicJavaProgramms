/*     */ package org.hibernate.collection;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.persister.collection.BasicCollectionPersister;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentSortedMap
/*     */   extends PersistentMap
/*     */   implements SortedMap
/*     */ {
/*     */   protected Comparator comparator;
/*     */   
/*     */   protected Serializable snapshot(BasicCollectionPersister persister, EntityMode entityMode)
/*     */     throws HibernateException
/*     */   {
/*  32 */     TreeMap clonedMap = new TreeMap(this.comparator);
/*  33 */     Iterator iter = this.map.entrySet().iterator();
/*  34 */     while (iter.hasNext()) {
/*  35 */       Map.Entry e = (Map.Entry)iter.next();
/*  36 */       clonedMap.put(e.getKey(), persister.getElementType().deepCopy(e.getValue(), entityMode, persister.getFactory()));
/*     */     }
/*  38 */     return clonedMap;
/*     */   }
/*     */   
/*     */   public PersistentSortedMap(SessionImplementor session) {
/*  42 */     super(session);
/*     */   }
/*     */   
/*     */   public void setComparator(Comparator comparator) {
/*  46 */     this.comparator = comparator;
/*     */   }
/*     */   
/*     */   public PersistentSortedMap(SessionImplementor session, SortedMap map) {
/*  50 */     super(session, map);
/*  51 */     this.comparator = map.comparator();
/*     */   }
/*     */   
/*     */ 
/*     */   public PersistentSortedMap() {}
/*     */   
/*     */ 
/*     */   public Comparator comparator()
/*     */   {
/*  60 */     return this.comparator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public SortedMap subMap(Object fromKey, Object toKey)
/*     */   {
/*  67 */     read();
/*  68 */     SortedMap m = ((SortedMap)this.map).subMap(fromKey, toKey);
/*  69 */     return new SortedSubMap(m);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public SortedMap headMap(Object toKey)
/*     */   {
/*  76 */     read();
/*     */     
/*  78 */     SortedMap m = ((SortedMap)this.map).headMap(toKey);
/*  79 */     return new SortedSubMap(m);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public SortedMap tailMap(Object fromKey)
/*     */   {
/*  86 */     read();
/*     */     
/*  88 */     SortedMap m = ((SortedMap)this.map).tailMap(fromKey);
/*  89 */     return new SortedSubMap(m);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object firstKey()
/*     */   {
/*  96 */     read();
/*  97 */     return ((SortedMap)this.map).firstKey();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object lastKey()
/*     */   {
/* 104 */     read();
/* 105 */     return ((SortedMap)this.map).lastKey();
/*     */   }
/*     */   
/*     */   class SortedSubMap implements SortedMap
/*     */   {
/*     */     SortedMap submap;
/*     */     
/*     */     SortedSubMap(SortedMap m) {
/* 113 */       this.submap = m;
/*     */     }
/*     */     
/*     */     public int size() {
/* 117 */       return this.submap.size();
/*     */     }
/*     */     
/* 120 */     public boolean isEmpty() { return this.submap.isEmpty(); }
/*     */     
/*     */     public boolean containsKey(Object key) {
/* 123 */       return this.submap.containsKey(key);
/*     */     }
/*     */     
/* 126 */     public boolean containsValue(Object key) { return this.submap.containsValue(key); }
/*     */     
/*     */ 
/* 129 */     public Object get(Object key) { return this.submap.get(key); }
/*     */     
/*     */     public Object put(Object key, Object value) {
/* 132 */       PersistentSortedMap.this.write();
/* 133 */       return this.submap.put(key, value);
/*     */     }
/*     */     
/* 136 */     public Object remove(Object key) { PersistentSortedMap.this.write();
/* 137 */       return this.submap.remove(key);
/*     */     }
/*     */     
/* 140 */     public void putAll(Map other) { PersistentSortedMap.this.write();
/* 141 */       this.submap.putAll(other);
/*     */     }
/*     */     
/* 144 */     public void clear() { PersistentSortedMap.this.write();
/* 145 */       this.submap.clear();
/*     */     }
/*     */     
/* 148 */     public Set keySet() { return new AbstractPersistentCollection.SetProxy(PersistentSortedMap.this, this.submap.keySet()); }
/*     */     
/*     */     public Collection values() {
/* 151 */       return new AbstractPersistentCollection.SetProxy(PersistentSortedMap.this, this.submap.values());
/*     */     }
/*     */     
/* 154 */     public Set entrySet() { return new PersistentMap.EntrySetProxy(PersistentSortedMap.this, this.submap.entrySet()); }
/*     */     
/*     */     public Comparator comparator()
/*     */     {
/* 158 */       return this.submap.comparator();
/*     */     }
/*     */     
/*     */     public SortedMap subMap(Object fromKey, Object toKey) {
/* 162 */       SortedMap m = this.submap.subMap(fromKey, toKey);
/* 163 */       return new SortedSubMap(PersistentSortedMap.this, m);
/*     */     }
/*     */     
/*     */     public SortedMap headMap(Object toKey) {
/* 167 */       SortedMap m = this.submap.headMap(toKey);
/* 168 */       return new SortedSubMap(PersistentSortedMap.this, m);
/*     */     }
/*     */     
/*     */     public SortedMap tailMap(Object fromKey) {
/* 172 */       SortedMap m = this.submap.tailMap(fromKey);
/* 173 */       return new SortedSubMap(PersistentSortedMap.this, m);
/*     */     }
/*     */     
/* 176 */     public Object firstKey() { return this.submap.firstKey(); }
/*     */     
/*     */     public Object lastKey() {
/* 179 */       return this.submap.lastKey();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\collection\PersistentSortedMap.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */