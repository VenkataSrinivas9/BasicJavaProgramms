/*     */ package org.hibernate.collection;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.loader.CollectionAliases;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.type.CollectionType;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentSet
/*     */   extends AbstractPersistentCollection
/*     */   implements Set
/*     */ {
/*     */   protected Set set;
/*     */   protected transient List tempList;
/*     */   
/*     */   public Serializable getSnapshot(CollectionPersister persister)
/*     */     throws HibernateException
/*     */   {
/*  36 */     EntityMode entityMode = getSession().getEntityMode();
/*     */     
/*     */ 
/*  39 */     HashMap clonedSet = new HashMap(this.set.size());
/*  40 */     Iterator iter = this.set.iterator();
/*  41 */     while (iter.hasNext()) {
/*  42 */       Object copied = persister.getElementType().deepCopy(iter.next(), entityMode, persister.getFactory());
/*     */       
/*  44 */       clonedSet.put(copied, copied);
/*     */     }
/*  46 */     return clonedSet;
/*     */   }
/*     */   
/*     */   public Collection getOrphans(Serializable snapshot, String entityName) throws HibernateException {
/*  50 */     Map sn = (Map)snapshot;
/*  51 */     return getOrphans(sn.keySet(), this.set, entityName, getSession());
/*     */   }
/*     */   
/*     */   public boolean equalsSnapshot(CollectionPersister persister) throws HibernateException {
/*  55 */     Type elementType = persister.getElementType();
/*  56 */     Map sn = (Map)getSnapshot();
/*  57 */     if (sn.size() != this.set.size()) {
/*  58 */       return false;
/*     */     }
/*     */     
/*  61 */     Iterator iter = this.set.iterator();
/*  62 */     for (; iter.hasNext(); 
/*     */         
/*     */ 
/*  65 */         return false)
/*     */     {
/*  63 */       Object test = iter.next();
/*  64 */       Object oldValue = sn.get(test);
/*  65 */       if ((oldValue != null) && (!elementType.isDirty(oldValue, test, getSession()))) {}
/*     */     }
/*  67 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isSnapshotEmpty(Serializable snapshot)
/*     */   {
/*  72 */     return ((Map)snapshot).isEmpty();
/*     */   }
/*     */   
/*     */   public PersistentSet(SessionImplementor session) {
/*  76 */     super(session);
/*     */   }
/*     */   
/*     */   public PersistentSet() {}
/*     */   
/*     */   public void beforeInitialize(CollectionPersister persister) {
/*  82 */     this.set = ((Set)persister.getCollectionType().instantiate());
/*     */   }
/*     */   
/*     */   public PersistentSet(SessionImplementor session, Set set) {
/*  86 */     super(session);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  91 */     this.set = set;
/*  92 */     setInitialized();
/*  93 */     setDirectlyAccessible(true);
/*     */   }
/*     */   
/*     */   public void initializeFromCache(CollectionPersister persister, Serializable disassembled, Object owner) throws HibernateException
/*     */   {
/*  98 */     beforeInitialize(persister);
/*  99 */     Serializable[] array = (Serializable[])disassembled;
/* 100 */     for (int i = 0; i < array.length; i++) {
/* 101 */       Object element = persister.getElementType().assemble(array[i], getSession(), owner);
/* 102 */       if (element != null) this.set.add(element);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean empty() {
/* 107 */     return this.set.isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/* 114 */     return readSize() ? getCachedSize() : this.set.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 121 */     return readSize() ? false : getCachedSize() == 0 ? true : this.set.isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean contains(Object object)
/*     */   {
/* 128 */     Boolean exists = readElementExistence(object);
/* 129 */     return exists == null ? this.set.contains(object) : exists.booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator iterator()
/*     */   {
/* 138 */     read();
/* 139 */     return new AbstractPersistentCollection.IteratorProxy(this, this.set.iterator());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object[] toArray()
/*     */   {
/* 146 */     read();
/* 147 */     return this.set.toArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object[] toArray(Object[] array)
/*     */   {
/* 154 */     read();
/* 155 */     return this.set.toArray(array);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean add(Object value)
/*     */   {
/* 162 */     Boolean exists = isOperationQueueEnabled() ? readElementExistence(value) : null;
/*     */     
/* 164 */     if (exists == null) {
/* 165 */       write();
/* 166 */       return this.set.add(value);
/*     */     }
/* 168 */     if (exists.booleanValue()) {
/* 169 */       return false;
/*     */     }
/*     */     
/* 172 */     queueOperation(new SimpleAdd(value));
/* 173 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean remove(Object value)
/*     */   {
/* 181 */     Boolean exists = isPutQueueEnabled() ? readElementExistence(value) : null;
/*     */     
/* 183 */     if (exists == null) {
/* 184 */       write();
/* 185 */       return this.set.remove(value);
/*     */     }
/* 187 */     if (exists.booleanValue()) {
/* 188 */       queueOperation(new SimpleRemove(value));
/* 189 */       return true;
/*     */     }
/*     */     
/* 192 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsAll(Collection coll)
/*     */   {
/* 200 */     read();
/* 201 */     return this.set.containsAll(coll);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean addAll(Collection coll)
/*     */   {
/* 208 */     if (coll.size() > 0) {
/* 209 */       write();
/* 210 */       return this.set.addAll(coll);
/*     */     }
/*     */     
/* 213 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean retainAll(Collection coll)
/*     */   {
/* 221 */     write();
/* 222 */     return this.set.retainAll(coll);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean removeAll(Collection coll)
/*     */   {
/* 229 */     if (coll.size() > 0) {
/* 230 */       write();
/* 231 */       return this.set.removeAll(coll);
/*     */     }
/*     */     
/* 234 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 242 */     if (isClearQueueEnabled()) {
/* 243 */       queueOperation(new Clear());
/*     */     }
/*     */     else {
/* 246 */       write();
/* 247 */       this.set.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 253 */     read();
/* 254 */     return this.set.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object readFrom(ResultSet rs, CollectionPersister persister, CollectionAliases descriptor, Object owner)
/*     */     throws HibernateException, SQLException
/*     */   {
/* 262 */     Object element = persister.readElement(rs, owner, descriptor.getSuffixedElementAliases(), getSession());
/* 263 */     if (element != null) this.tempList.add(element);
/* 264 */     return element;
/*     */   }
/*     */   
/*     */   public void beginRead() {
/* 268 */     super.beginRead();
/* 269 */     this.tempList = new ArrayList();
/*     */   }
/*     */   
/*     */   public boolean endRead() {
/* 273 */     this.set.addAll(this.tempList);
/* 274 */     this.tempList = null;
/* 275 */     setInitialized();
/* 276 */     return true;
/*     */   }
/*     */   
/*     */   public Iterator entries(CollectionPersister persister) {
/* 280 */     return this.set.iterator();
/*     */   }
/*     */   
/*     */   public Serializable disassemble(CollectionPersister persister)
/*     */     throws HibernateException
/*     */   {
/* 286 */     Serializable[] result = new Serializable[this.set.size()];
/* 287 */     Iterator iter = this.set.iterator();
/* 288 */     int i = 0;
/* 289 */     while (iter.hasNext()) {
/* 290 */       result[(i++)] = persister.getElementType().disassemble(iter.next(), getSession(), null);
/*     */     }
/* 292 */     return result;
/*     */   }
/*     */   
/*     */   public Iterator getDeletes(CollectionPersister persister, boolean indexIsFormula) throws HibernateException
/*     */   {
/* 297 */     Type elementType = persister.getElementType();
/* 298 */     Map sn = (Map)getSnapshot();
/* 299 */     ArrayList deletes = new ArrayList(sn.size());
/* 300 */     Iterator iter = sn.keySet().iterator();
/* 301 */     while (iter.hasNext()) {
/* 302 */       Object test = iter.next();
/* 303 */       if (!this.set.contains(test))
/*     */       {
/* 305 */         deletes.add(test);
/*     */       }
/*     */     }
/* 308 */     iter = this.set.iterator();
/* 309 */     while (iter.hasNext()) {
/* 310 */       Object test = iter.next();
/* 311 */       Object oldValue = sn.get(test);
/* 312 */       if ((oldValue != null) && (elementType.isDirty(test, oldValue, getSession())))
/*     */       {
/* 314 */         deletes.add(oldValue);
/*     */       }
/*     */     }
/* 317 */     return deletes.iterator();
/*     */   }
/*     */   
/*     */   public boolean needsInserting(Object entry, int i, Type elemType) throws HibernateException {
/* 321 */     Map sn = (Map)getSnapshot();
/* 322 */     Object oldValue = sn.get(entry);
/*     */     
/*     */ 
/*     */ 
/* 326 */     return (oldValue == null) || (elemType.isDirty(oldValue, entry, getSession()));
/*     */   }
/*     */   
/*     */   public boolean needsUpdating(Object entry, int i, Type elemType) {
/* 330 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isRowUpdatePossible() {
/* 334 */     return false;
/*     */   }
/*     */   
/*     */   public Object getIndex(Object entry, int i, CollectionPersister persister) {
/* 338 */     throw new UnsupportedOperationException("Sets don't have indexes");
/*     */   }
/*     */   
/*     */   public Object getElement(Object entry) {
/* 342 */     return entry;
/*     */   }
/*     */   
/*     */   public Object getSnapshotElement(Object entry, int i) {
/* 346 */     throw new UnsupportedOperationException("Sets don't support updating by element");
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/* 350 */     read();
/* 351 */     return this.set.equals(other);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 355 */     read();
/* 356 */     return this.set.hashCode();
/*     */   }
/*     */   
/*     */   public boolean entryExists(Object key, int i) {
/* 360 */     return true;
/*     */   }
/*     */   
/*     */ 
/* 364 */   public boolean isWrapper(Object collection) { return this.set == collection; }
/*     */   
/*     */   final class Clear implements AbstractPersistentCollection.DelayedOperation {
/*     */     Clear() {}
/*     */     
/* 369 */     public void operate() { PersistentSet.this.set.clear(); }
/*     */     
/*     */     public Object getAddedInstance() {
/* 372 */       return null;
/*     */     }
/*     */     
/* 375 */     public Object getOrphan() { throw new UnsupportedOperationException("queued clear cannot be used with orphan delete"); }
/*     */   }
/*     */   
/*     */   final class SimpleAdd implements AbstractPersistentCollection.DelayedOperation
/*     */   {
/*     */     private Object value;
/*     */     
/*     */     public SimpleAdd(Object value) {
/* 383 */       this.value = value;
/*     */     }
/*     */     
/* 386 */     public void operate() { PersistentSet.this.set.add(this.value); }
/*     */     
/*     */     public Object getAddedInstance() {
/* 389 */       return this.value;
/*     */     }
/*     */     
/* 392 */     public Object getOrphan() { return null; }
/*     */   }
/*     */   
/*     */   final class SimpleRemove implements AbstractPersistentCollection.DelayedOperation
/*     */   {
/*     */     private Object value;
/*     */     
/*     */     public SimpleRemove(Object value) {
/* 400 */       this.value = value;
/*     */     }
/*     */     
/* 403 */     public void operate() { PersistentSet.this.set.remove(this.value); }
/*     */     
/*     */     public Object getAddedInstance() {
/* 406 */       return null;
/*     */     }
/*     */     
/* 409 */     public Object getOrphan() { return this.value; }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\collection\PersistentSet.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */