/*     */ package org.hibernate.collection;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.dom4j.Element;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.engine.PersistenceContext;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.loader.CollectionAliases;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.CollectionHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentElementHolder
/*     */   extends AbstractPersistentCollection
/*     */ {
/*     */   protected Element element;
/*     */   
/*     */   public PersistentElementHolder(SessionImplementor session, Element element)
/*     */   {
/*  30 */     super(session);
/*  31 */     this.element = element;
/*  32 */     setInitialized();
/*     */   }
/*     */   
/*     */   public Serializable getSnapshot(CollectionPersister persister)
/*     */     throws HibernateException
/*     */   {
/*  38 */     Type elementType = persister.getElementType();
/*  39 */     List elements = this.element.elements(persister.getElementNodeName());
/*  40 */     ArrayList snapshot = new ArrayList(elements.size());
/*  41 */     for (int i = 0; i < elements.size(); i++) {
/*  42 */       Element elem = (Element)elements.get(i);
/*  43 */       Object value = elementType.fromXMLNode(elem, persister.getFactory());
/*  44 */       Object copy = elementType.deepCopy(value, getSession().getEntityMode(), persister.getFactory());
/*  45 */       snapshot.add(copy);
/*     */     }
/*  47 */     return snapshot;
/*     */   }
/*     */   
/*     */ 
/*     */   public Collection getOrphans(Serializable snapshot, String entityName)
/*     */     throws HibernateException
/*     */   {
/*  54 */     return CollectionHelper.EMPTY_COLLECTION;
/*     */   }
/*     */   
/*     */   public PersistentElementHolder(SessionImplementor session, CollectionPersister persister, Serializable key) throws HibernateException
/*     */   {
/*  59 */     super(session);
/*  60 */     Element owner = (Element)session.getPersistenceContext().getCollectionOwner(key, persister);
/*  61 */     if (owner == null) { throw new AssertionFailure("null owner");
/*     */     }
/*  63 */     String nodeName = persister.getNodeName();
/*  64 */     if (".".equals(nodeName)) {
/*  65 */       this.element = owner;
/*     */     }
/*     */     else {
/*  68 */       this.element = owner.element(nodeName);
/*  69 */       if (this.element == null) this.element = owner.addElement(nodeName);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isWrapper(Object collection) {
/*  74 */     return this.element == collection;
/*     */   }
/*     */   
/*     */   public boolean equalsSnapshot(CollectionPersister persister) throws HibernateException {
/*  78 */     Type elementType = persister.getElementType();
/*     */     
/*  80 */     ArrayList snapshot = (ArrayList)getSnapshot();
/*  81 */     List elements = this.element.elements(persister.getElementNodeName());
/*  82 */     if (snapshot.size() != elements.size()) return false;
/*  83 */     for (int i = 0; i < snapshot.size(); i++) {
/*  84 */       Object old = snapshot.get(i);
/*  85 */       Element elem = (Element)elements.get(i);
/*  86 */       Object current = elementType.fromXMLNode(elem, persister.getFactory());
/*  87 */       if (elementType.isDirty(old, current, getSession())) return false;
/*     */     }
/*  89 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isSnapshotEmpty(Serializable snapshot) {
/*  93 */     return ((Collection)snapshot).isEmpty();
/*     */   }
/*     */   
/*     */   public boolean empty() {
/*  97 */     return !this.element.elementIterator().hasNext();
/*     */   }
/*     */   
/*     */   public Object readFrom(ResultSet rs, CollectionPersister persister, CollectionAliases descriptor, Object owner) throws HibernateException, SQLException
/*     */   {
/* 102 */     Object object = persister.readElement(rs, owner, descriptor.getSuffixedElementAliases(), getSession());
/* 103 */     Type elementType = persister.getElementType();
/* 104 */     Element subelement = this.element.addElement(persister.getElementNodeName());
/* 105 */     elementType.setToXMLNode(subelement, object, persister.getFactory());
/* 106 */     return object;
/*     */   }
/*     */   
/*     */   public Iterator entries(CollectionPersister persister)
/*     */   {
/* 111 */     Type elementType = persister.getElementType();
/* 112 */     List elements = this.element.elements(persister.getElementNodeName());
/* 113 */     int length = elements.size();
/* 114 */     List result = new ArrayList(length);
/* 115 */     for (int i = 0; i < length; i++) {
/* 116 */       Element elem = (Element)elements.get(i);
/* 117 */       Object object = elementType.fromXMLNode(elem, persister.getFactory());
/* 118 */       result.add(object);
/*     */     }
/* 120 */     return result.iterator();
/*     */   }
/*     */   
/*     */   public void beforeInitialize(CollectionPersister persister) {}
/*     */   
/*     */   public boolean isDirectlyAccessible() {
/* 126 */     return true;
/*     */   }
/*     */   
/*     */   public void initializeFromCache(CollectionPersister persister, Serializable disassembled, Object owner)
/*     */     throws HibernateException
/*     */   {
/* 132 */     Type elementType = persister.getElementType();
/* 133 */     Serializable[] cached = (Serializable[])disassembled;
/* 134 */     for (int i = 0; i < cached.length; i++) {
/* 135 */       Object object = elementType.assemble(cached[i], getSession(), owner);
/* 136 */       Element subelement = this.element.addElement(persister.getElementNodeName());
/* 137 */       elementType.setToXMLNode(subelement, object, persister.getFactory());
/*     */     }
/*     */   }
/*     */   
/*     */   public Serializable disassemble(CollectionPersister persister)
/*     */     throws HibernateException
/*     */   {
/* 144 */     Type elementType = persister.getElementType();
/* 145 */     List elements = this.element.elements(persister.getElementNodeName());
/* 146 */     int length = elements.size();
/* 147 */     Serializable[] result = new Serializable[length];
/* 148 */     for (int i = 0; i < length; i++) {
/* 149 */       Element elem = (Element)elements.get(i);
/* 150 */       Object object = elementType.fromXMLNode(elem, persister.getFactory());
/* 151 */       result[i] = elementType.disassemble(object, getSession(), null);
/*     */     }
/* 153 */     return result;
/*     */   }
/*     */   
/*     */   public Object getValue() {
/* 157 */     return this.element;
/*     */   }
/*     */   
/*     */   public Iterator getDeletes(CollectionPersister persister, boolean indexIsFormula)
/*     */     throws HibernateException
/*     */   {
/* 163 */     Type elementType = persister.getElementType();
/* 164 */     ArrayList snapshot = (ArrayList)getSnapshot();
/* 165 */     List elements = this.element.elements(persister.getElementNodeName());
/* 166 */     ArrayList result = new ArrayList();
/* 167 */     for (int i = 0; i < snapshot.size(); i++) {
/* 168 */       Object old = snapshot.get(i);
/* 169 */       if (i >= elements.size()) {
/* 170 */         result.add(old);
/*     */       }
/*     */       else {
/* 173 */         Element elem = (Element)elements.get(i);
/* 174 */         Object object = elementType.fromXMLNode(elem, persister.getFactory());
/* 175 */         if (elementType.isDirty(old, object, getSession())) result.add(old);
/*     */       }
/*     */     }
/* 178 */     return result.iterator();
/*     */   }
/*     */   
/*     */   public boolean needsInserting(Object entry, int i, Type elementType)
/*     */     throws HibernateException
/*     */   {
/* 184 */     ArrayList snapshot = (ArrayList)getSnapshot();
/* 185 */     return (i >= snapshot.size()) || (elementType.isDirty(snapshot.get(i), entry, getSession()));
/*     */   }
/*     */   
/*     */   public boolean needsUpdating(Object entry, int i, Type elementType) throws HibernateException
/*     */   {
/* 190 */     return false;
/*     */   }
/*     */   
/*     */   public Object getIndex(Object entry, int i, CollectionPersister persister) {
/* 194 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Object getElement(Object entry) {
/* 198 */     return entry;
/*     */   }
/*     */   
/*     */   public Object getSnapshotElement(Object entry, int i) {
/* 202 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean entryExists(Object entry, int i) {
/* 206 */     return entry != null;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\collection\PersistentElementHolder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */