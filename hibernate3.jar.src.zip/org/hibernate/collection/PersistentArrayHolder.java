/*     */ package org.hibernate.collection;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.loader.CollectionAliases;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentArrayHolder
/*     */   extends AbstractPersistentCollection
/*     */ {
/*     */   protected Object array;
/*  31 */   private static final Log log = LogFactory.getLog(PersistentArrayHolder.class);
/*     */   
/*     */   private transient Class elementClass;
/*     */   private transient List tempList;
/*     */   
/*     */   public PersistentArrayHolder(SessionImplementor session, Object array)
/*     */   {
/*  38 */     super(session);
/*  39 */     this.array = array;
/*  40 */     setInitialized();
/*     */   }
/*     */   
/*     */   public Serializable getSnapshot(CollectionPersister persister) throws HibernateException {
/*  44 */     EntityMode entityMode = getSession().getEntityMode();
/*  45 */     int length = Array.getLength(this.array);
/*  46 */     Serializable result = (Serializable)Array.newInstance(persister.getElementClass(), length);
/*  47 */     for (int i = 0; i < length; i++) {
/*  48 */       Object elt = Array.get(this.array, i);
/*     */       try {
/*  50 */         Array.set(result, i, persister.getElementType().deepCopy(elt, entityMode, persister.getFactory()));
/*     */       }
/*     */       catch (IllegalArgumentException iae) {
/*  53 */         log.error("Array element type error", iae);
/*  54 */         throw new HibernateException("Array element type error", iae);
/*     */       }
/*     */     }
/*  57 */     return result;
/*     */   }
/*     */   
/*     */   public boolean isSnapshotEmpty(Serializable snapshot) {
/*  61 */     return Array.getLength(snapshot) == 0;
/*     */   }
/*     */   
/*     */   public Collection getOrphans(Serializable snapshot, String entityName) throws HibernateException {
/*  65 */     Object[] sn = (Object[])snapshot;
/*  66 */     Object[] arr = (Object[])this.array;
/*  67 */     ArrayList result = new ArrayList();
/*  68 */     for (int i = 0; i < sn.length; i++) result.add(sn[i]);
/*  69 */     for (int i = 0; i < sn.length; i++) identityRemove(result, arr[i], entityName, getSession());
/*  70 */     return result;
/*     */   }
/*     */   
/*     */   public PersistentArrayHolder(SessionImplementor session, CollectionPersister persister) throws HibernateException {
/*  74 */     super(session);
/*  75 */     this.elementClass = persister.getElementClass();
/*     */   }
/*     */   
/*     */   public Object getArray() {
/*  79 */     return this.array;
/*     */   }
/*     */   
/*     */   public boolean isWrapper(Object collection) {
/*  83 */     return this.array == collection;
/*     */   }
/*     */   
/*     */   public boolean equalsSnapshot(CollectionPersister persister) throws HibernateException {
/*  87 */     Type elementType = persister.getElementType();
/*  88 */     Serializable snapshot = getSnapshot();
/*  89 */     int xlen = Array.getLength(snapshot);
/*  90 */     if (xlen != Array.getLength(this.array)) return false;
/*  91 */     for (int i = 0; i < xlen; i++) {
/*  92 */       if (elementType.isDirty(Array.get(snapshot, i), Array.get(this.array, i), getSession())) return false;
/*     */     }
/*  94 */     return true;
/*     */   }
/*     */   
/*     */   public Iterator elements()
/*     */   {
/*  99 */     int length = Array.getLength(this.array);
/* 100 */     List list = new ArrayList(length);
/* 101 */     for (int i = 0; i < length; i++) {
/* 102 */       list.add(Array.get(this.array, i));
/*     */     }
/* 104 */     return list.iterator();
/*     */   }
/*     */   
/* 107 */   public boolean empty() { return false; }
/*     */   
/*     */ 
/*     */   public Object readFrom(ResultSet rs, CollectionPersister persister, CollectionAliases descriptor, Object owner)
/*     */     throws HibernateException, SQLException
/*     */   {
/* 113 */     Object element = persister.readElement(rs, owner, descriptor.getSuffixedElementAliases(), getSession());
/* 114 */     int index = ((Integer)persister.readIndex(rs, descriptor.getSuffixedIndexAliases(), getSession())).intValue();
/* 115 */     for (int i = this.tempList.size(); i <= index; i++) {
/* 116 */       this.tempList.add(i, null);
/*     */     }
/* 118 */     this.tempList.set(index, element);
/* 119 */     return element;
/*     */   }
/*     */   
/*     */   public Iterator entries(CollectionPersister persister) {
/* 123 */     return elements();
/*     */   }
/*     */   
/*     */   public void beginRead() {
/* 127 */     super.beginRead();
/* 128 */     this.tempList = new ArrayList();
/*     */   }
/*     */   
/* 131 */   public boolean endRead() { setInitialized();
/* 132 */     this.array = Array.newInstance(this.elementClass, this.tempList.size());
/* 133 */     for (int i = 0; i < this.tempList.size(); i++) {
/* 134 */       Array.set(this.array, i, this.tempList.get(i));
/*     */     }
/* 136 */     this.tempList = null;
/* 137 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void beforeInitialize(CollectionPersister persister) {}
/*     */   
/*     */   public boolean isDirectlyAccessible()
/*     */   {
/* 145 */     return true;
/*     */   }
/*     */   
/*     */   public void initializeFromCache(CollectionPersister persister, Serializable disassembled, Object owner) throws HibernateException
/*     */   {
/* 150 */     Serializable[] cached = (Serializable[])disassembled;
/*     */     
/* 152 */     this.array = Array.newInstance(persister.getElementClass(), cached.length);
/*     */     
/* 154 */     for (int i = 0; i < cached.length; i++) {
/* 155 */       Array.set(this.array, i, persister.getElementType().assemble(cached[i], getSession(), owner));
/*     */     }
/*     */   }
/*     */   
/*     */   public Serializable disassemble(CollectionPersister persister) throws HibernateException {
/* 160 */     int length = Array.getLength(this.array);
/* 161 */     Serializable[] result = new Serializable[length];
/* 162 */     for (int i = 0; i < length; i++) {
/* 163 */       result[i] = persister.getElementType().disassemble(Array.get(this.array, i), getSession(), null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 172 */     return result;
/*     */   }
/*     */   
/*     */   public Object getValue()
/*     */   {
/* 177 */     return this.array;
/*     */   }
/*     */   
/*     */   public Iterator getDeletes(CollectionPersister persister, boolean indexIsFormula) throws HibernateException {
/* 181 */     List deletes = new ArrayList();
/* 182 */     Serializable sn = getSnapshot();
/* 183 */     int snSize = Array.getLength(sn);
/* 184 */     int arraySize = Array.getLength(this.array);
/*     */     int end;
/* 186 */     int end; if (snSize > arraySize) {
/* 187 */       for (int i = arraySize; i < snSize; i++) deletes.add(new Integer(i));
/* 188 */       end = arraySize;
/*     */     }
/*     */     else {
/* 191 */       end = snSize;
/*     */     }
/* 193 */     for (int i = 0; i < end; i++) {
/* 194 */       if ((Array.get(this.array, i) == null) && (Array.get(sn, i) != null)) deletes.add(new Integer(i));
/*     */     }
/* 196 */     return deletes.iterator();
/*     */   }
/*     */   
/*     */   public boolean needsInserting(Object entry, int i, Type elemType) throws HibernateException {
/* 200 */     Serializable sn = getSnapshot();
/* 201 */     return (Array.get(this.array, i) != null) && ((i >= Array.getLength(sn)) || (Array.get(sn, i) == null));
/*     */   }
/*     */   
/*     */   public boolean needsUpdating(Object entry, int i, Type elemType) throws HibernateException {
/* 205 */     Serializable sn = getSnapshot();
/* 206 */     return (i < Array.getLength(sn)) && (Array.get(sn, i) != null) && (Array.get(this.array, i) != null) && (elemType.isDirty(Array.get(this.array, i), Array.get(sn, i), getSession()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getIndex(Object entry, int i, CollectionPersister persister)
/*     */   {
/* 213 */     return new Integer(i);
/*     */   }
/*     */   
/*     */   public Object getElement(Object entry) {
/* 217 */     return entry;
/*     */   }
/*     */   
/*     */   public Object getSnapshotElement(Object entry, int i) {
/* 221 */     Serializable sn = getSnapshot();
/* 222 */     return Array.get(sn, i);
/*     */   }
/*     */   
/*     */   public boolean entryExists(Object entry, int i) {
/* 226 */     return entry != null;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\collection\PersistentArrayHolder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */