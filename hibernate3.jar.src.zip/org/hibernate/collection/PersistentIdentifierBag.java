/*     */ package org.hibernate.collection;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.id.IdentifierGenerator;
/*     */ import org.hibernate.loader.CollectionAliases;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentIdentifierBag
/*     */   extends AbstractPersistentCollection
/*     */   implements List
/*     */ {
/*     */   protected List values;
/*     */   protected Map identifiers;
/*     */   
/*     */   public PersistentIdentifierBag(SessionImplementor session)
/*     */   {
/*  40 */     super(session);
/*     */   }
/*     */   
/*     */   public PersistentIdentifierBag() {}
/*     */   
/*     */   public PersistentIdentifierBag(SessionImplementor session, Collection coll) {
/*  46 */     super(session);
/*  47 */     if ((coll instanceof List)) {
/*  48 */       this.values = ((List)coll);
/*     */     }
/*     */     else {
/*  51 */       this.values = new ArrayList();
/*  52 */       Iterator iter = coll.iterator();
/*  53 */       while (iter.hasNext()) {
/*  54 */         this.values.add(iter.next());
/*     */       }
/*     */     }
/*  57 */     setInitialized();
/*  58 */     setDirectlyAccessible(true);
/*  59 */     this.identifiers = new HashMap();
/*     */   }
/*     */   
/*     */   public void initializeFromCache(CollectionPersister persister, Serializable disassembled, Object owner) throws HibernateException
/*     */   {
/*  64 */     beforeInitialize(persister);
/*  65 */     Serializable[] array = (Serializable[])disassembled;
/*  66 */     for (int i = 0; i < array.length; i += 2) {
/*  67 */       this.identifiers.put(new Integer(i / 2), persister.getIdentifierType().assemble(array[i], getSession(), owner));
/*     */       
/*     */ 
/*     */ 
/*  71 */       this.values.add(persister.getElementType().assemble(array[(i + 1)], getSession(), owner));
/*     */     }
/*     */   }
/*     */   
/*     */   public Object getIdentifier(Object entry, int i) {
/*  76 */     return this.identifiers.get(new Integer(i));
/*     */   }
/*     */   
/*     */   public boolean isWrapper(Object collection) {
/*  80 */     return this.values == collection;
/*     */   }
/*     */   
/*     */   public boolean add(Object o) {
/*  84 */     write();
/*  85 */     this.values.add(o);
/*  86 */     return true;
/*     */   }
/*     */   
/*     */   public void clear() {
/*  90 */     write();
/*  91 */     this.values.clear();
/*  92 */     this.identifiers.clear();
/*     */   }
/*     */   
/*     */   public boolean contains(Object o) {
/*  96 */     read();
/*  97 */     return this.values.contains(o);
/*     */   }
/*     */   
/*     */   public boolean containsAll(Collection c) {
/* 101 */     read();
/* 102 */     return this.values.containsAll(c);
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 106 */     return readSize() ? false : getCachedSize() == 0 ? true : this.values.isEmpty();
/*     */   }
/*     */   
/*     */   public Iterator iterator() {
/* 110 */     read();
/* 111 */     return new AbstractPersistentCollection.IteratorProxy(this, this.values.iterator());
/*     */   }
/*     */   
/*     */   public boolean remove(Object o) {
/* 115 */     write();
/* 116 */     int index = this.values.indexOf(o);
/* 117 */     if (index >= 0) {
/* 118 */       beforeRemove(index);
/* 119 */       this.values.remove(index);
/* 120 */       return true;
/*     */     }
/*     */     
/* 123 */     return false;
/*     */   }
/*     */   
/*     */   public boolean removeAll(Collection c)
/*     */   {
/* 128 */     if (c.size() > 0)
/*     */     {
/*     */ 
/* 131 */       boolean result = false;
/* 132 */       Iterator iter = c.iterator();
/* 133 */       while (iter.hasNext()) {
/* 134 */         if (remove(iter.next())) result = true;
/*     */       }
/* 136 */       return result;
/*     */     }
/*     */     
/* 139 */     return false;
/*     */   }
/*     */   
/*     */   public boolean retainAll(Collection c)
/*     */   {
/* 144 */     write();
/* 145 */     return this.values.retainAll(c);
/*     */   }
/*     */   
/*     */   public int size() {
/* 149 */     return readSize() ? getCachedSize() : this.values.size();
/*     */   }
/*     */   
/*     */   public Object[] toArray() {
/* 153 */     read();
/* 154 */     return this.values.toArray();
/*     */   }
/*     */   
/*     */   public Object[] toArray(Object[] a) {
/* 158 */     read();
/* 159 */     return this.values.toArray(a);
/*     */   }
/*     */   
/*     */   public void beforeInitialize(CollectionPersister persister) {
/* 163 */     this.identifiers = new HashMap();
/* 164 */     this.values = new ArrayList();
/*     */   }
/*     */   
/*     */   public Serializable disassemble(CollectionPersister persister)
/*     */     throws HibernateException
/*     */   {
/* 170 */     Serializable[] result = new Serializable[this.values.size() * 2];
/* 171 */     int i = 0;
/* 172 */     for (int j = 0; j < this.values.size(); j++) {
/* 173 */       Object value = this.values.get(j);
/* 174 */       result[(i++)] = persister.getIdentifierType().disassemble(this.identifiers.get(new Integer(j)), getSession(), null);
/* 175 */       result[(i++)] = persister.getElementType().disassemble(value, getSession(), null);
/*     */     }
/* 177 */     return result;
/*     */   }
/*     */   
/*     */   public boolean empty() {
/* 181 */     return this.values.isEmpty();
/*     */   }
/*     */   
/*     */   public Iterator entries(CollectionPersister persister) {
/* 185 */     return this.values.iterator();
/*     */   }
/*     */   
/*     */   public boolean entryExists(Object entry, int i) {
/* 189 */     return entry != null;
/*     */   }
/*     */   
/*     */   public boolean equalsSnapshot(CollectionPersister persister) throws HibernateException {
/* 193 */     Type elementType = persister.getElementType();
/* 194 */     Map snap = (Map)getSnapshot();
/* 195 */     if (snap.size() != this.values.size()) return false;
/* 196 */     for (int i = 0; i < this.values.size(); i++) {
/* 197 */       Object value = this.values.get(i);
/* 198 */       Object id = this.identifiers.get(new Integer(i));
/* 199 */       if (id == null) return false;
/* 200 */       Object old = snap.get(id);
/* 201 */       if (elementType.isDirty(old, value, getSession())) return false;
/*     */     }
/* 203 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isSnapshotEmpty(Serializable snapshot) {
/* 207 */     return ((Map)snapshot).isEmpty();
/*     */   }
/*     */   
/*     */   public Iterator getDeletes(CollectionPersister persister, boolean indexIsFormula) throws HibernateException {
/* 211 */     Map snap = (Map)getSnapshot();
/* 212 */     List deletes = new ArrayList(snap.keySet());
/* 213 */     for (int i = 0; i < this.values.size(); i++) {
/* 214 */       if (this.values.get(i) != null) deletes.remove(this.identifiers.get(new Integer(i)));
/*     */     }
/* 216 */     return deletes.iterator();
/*     */   }
/*     */   
/*     */   public Object getIndex(Object entry, int i, CollectionPersister persister) {
/* 220 */     throw new UnsupportedOperationException("Bags don't have indexes");
/*     */   }
/*     */   
/*     */   public Object getElement(Object entry) {
/* 224 */     return entry;
/*     */   }
/*     */   
/*     */   public Object getSnapshotElement(Object entry, int i) {
/* 228 */     Map snap = (Map)getSnapshot();
/* 229 */     Object id = this.identifiers.get(new Integer(i));
/* 230 */     return snap.get(id);
/*     */   }
/*     */   
/*     */   public boolean needsInserting(Object entry, int i, Type elemType)
/*     */     throws HibernateException
/*     */   {
/* 236 */     Map snap = (Map)getSnapshot();
/* 237 */     Object id = this.identifiers.get(new Integer(i));
/* 238 */     return (entry != null) && ((id == null) || (snap.get(id) == null));
/*     */   }
/*     */   
/*     */   public boolean needsUpdating(Object entry, int i, Type elemType) throws HibernateException
/*     */   {
/* 243 */     if (entry == null) return false;
/* 244 */     Map snap = (Map)getSnapshot();
/* 245 */     Object id = this.identifiers.get(new Integer(i));
/* 246 */     if (id == null) return false;
/* 247 */     Object old = snap.get(id);
/* 248 */     return (old != null) && (elemType.isDirty(old, entry, getSession()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object readFrom(ResultSet rs, CollectionPersister persister, CollectionAliases descriptor, Object owner)
/*     */     throws HibernateException, SQLException
/*     */   {
/* 259 */     Object element = persister.readElement(rs, owner, descriptor.getSuffixedElementAliases(), getSession());
/* 260 */     Object old = this.identifiers.put(new Integer(this.values.size()), persister.readIdentifier(rs, descriptor.getSuffixedIdentifierAlias(), getSession()));
/*     */     
/*     */ 
/*     */ 
/* 264 */     if (old == null) this.values.add(element);
/* 265 */     return element;
/*     */   }
/*     */   
/*     */   public Serializable getSnapshot(CollectionPersister persister)
/*     */     throws HibernateException
/*     */   {
/* 271 */     EntityMode entityMode = getSession().getEntityMode();
/*     */     
/* 273 */     HashMap map = new HashMap(this.values.size());
/* 274 */     Iterator iter = this.values.iterator();
/* 275 */     int i = 0;
/* 276 */     while (iter.hasNext()) {
/* 277 */       Object value = iter.next();
/* 278 */       map.put(this.identifiers.get(new Integer(i++)), persister.getElementType().deepCopy(value, entityMode, persister.getFactory()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 283 */     return map;
/*     */   }
/*     */   
/*     */   public Collection getOrphans(Serializable snapshot, String entityName) throws HibernateException {
/* 287 */     Map sn = (Map)snapshot;
/* 288 */     return getOrphans(sn.values(), this.values, entityName, getSession());
/*     */   }
/*     */   
/*     */   public void preInsert(CollectionPersister persister) throws HibernateException {
/* 292 */     Iterator iter = this.values.iterator();
/* 293 */     int i = 0;
/* 294 */     while (iter.hasNext()) {
/* 295 */       Object entry = iter.next();
/* 296 */       Integer loc = new Integer(i++);
/* 297 */       if (!this.identifiers.containsKey(loc)) {
/* 298 */         Serializable id = persister.getIdentifierGenerator().generate(getSession(), entry);
/* 299 */         this.identifiers.put(loc, id);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void add(int index, Object element) {
/* 305 */     write();
/* 306 */     beforeAdd(index);
/* 307 */     this.values.add(index, element);
/*     */   }
/*     */   
/*     */   public boolean addAll(int index, Collection c) {
/* 311 */     if (c.size() > 0)
/*     */     {
/*     */ 
/* 314 */       Iterator iter = c.iterator();
/* 315 */       while (iter.hasNext()) add(index++, iter.next());
/* 316 */       return true;
/*     */     }
/*     */     
/* 319 */     return false;
/*     */   }
/*     */   
/*     */   public Object get(int index)
/*     */   {
/* 324 */     read();
/* 325 */     return this.values.get(index);
/*     */   }
/*     */   
/*     */   public int indexOf(Object o) {
/* 329 */     read();
/* 330 */     return this.values.indexOf(o);
/*     */   }
/*     */   
/*     */   public int lastIndexOf(Object o) {
/* 334 */     read();
/* 335 */     return this.values.lastIndexOf(o);
/*     */   }
/*     */   
/*     */   public ListIterator listIterator() {
/* 339 */     read();
/* 340 */     return new AbstractPersistentCollection.ListIteratorProxy(this, this.values.listIterator());
/*     */   }
/*     */   
/*     */   public ListIterator listIterator(int index) {
/* 344 */     read();
/* 345 */     return new AbstractPersistentCollection.ListIteratorProxy(this, this.values.listIterator(index));
/*     */   }
/*     */   
/*     */   private void beforeRemove(int index) {
/* 349 */     Object removedId = this.identifiers.get(new Integer(index));
/* 350 */     int last = this.values.size() - 1;
/* 351 */     for (int i = index; i < last; i++) {
/* 352 */       Object id = this.identifiers.get(new Integer(i + 1));
/* 353 */       if (id == null) {
/* 354 */         this.identifiers.remove(new Integer(i));
/*     */       }
/*     */       else {
/* 357 */         this.identifiers.put(new Integer(i), id);
/*     */       }
/*     */     }
/* 360 */     this.identifiers.put(new Integer(last), removedId);
/*     */   }
/*     */   
/*     */   private void beforeAdd(int index) {
/* 364 */     for (int i = index; i < this.values.size(); i++) {
/* 365 */       this.identifiers.put(new Integer(i + 1), this.identifiers.get(new Integer(i)));
/*     */     }
/* 367 */     this.identifiers.remove(new Integer(index));
/*     */   }
/*     */   
/*     */   public Object remove(int index) {
/* 371 */     write();
/* 372 */     beforeRemove(index);
/* 373 */     return this.values.remove(index);
/*     */   }
/*     */   
/*     */   public Object set(int index, Object element) {
/* 377 */     write();
/* 378 */     return this.values.set(index, element);
/*     */   }
/*     */   
/*     */   public List subList(int fromIndex, int toIndex) {
/* 382 */     read();
/* 383 */     return new AbstractPersistentCollection.ListProxy(this, this.values.subList(fromIndex, toIndex));
/*     */   }
/*     */   
/*     */   public boolean addAll(Collection c) {
/* 387 */     if (c.size() > 0) {
/* 388 */       write();
/* 389 */       return this.values.addAll(c);
/*     */     }
/*     */     
/* 392 */     return false;
/*     */   }
/*     */   
/*     */   public void afterRowInsert(CollectionPersister persister, Object entry, int i)
/*     */     throws HibernateException
/*     */   {}
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\collection\PersistentIdentifierBag.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */