/*     */ package org.hibernate.collection;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.loader.CollectionAliases;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.type.CollectionType;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentMap
/*     */   extends AbstractPersistentCollection
/*     */   implements Map
/*     */ {
/*     */   protected Map map;
/*     */   
/*     */   public Serializable getSnapshot(CollectionPersister persister)
/*     */     throws HibernateException
/*     */   {
/*  36 */     EntityMode entityMode = getSession().getEntityMode();
/*     */     
/*  38 */     HashMap clonedMap = new HashMap(this.map.size());
/*  39 */     Iterator iter = this.map.entrySet().iterator();
/*  40 */     while (iter.hasNext()) {
/*  41 */       Map.Entry e = (Map.Entry)iter.next();
/*  42 */       Object copy = persister.getElementType().deepCopy(e.getValue(), entityMode, persister.getFactory());
/*     */       
/*  44 */       clonedMap.put(e.getKey(), copy);
/*     */     }
/*  46 */     return clonedMap;
/*     */   }
/*     */   
/*     */   public Collection getOrphans(Serializable snapshot, String entityName) throws HibernateException {
/*  50 */     Map sn = (Map)snapshot;
/*  51 */     return getOrphans(sn.values(), this.map.values(), entityName, getSession());
/*     */   }
/*     */   
/*     */   public boolean equalsSnapshot(CollectionPersister persister) throws HibernateException {
/*  55 */     Type elementType = persister.getElementType();
/*  56 */     Map xmap = (Map)getSnapshot();
/*  57 */     if (xmap.size() != this.map.size()) return false;
/*  58 */     Iterator iter = this.map.entrySet().iterator();
/*  59 */     while (iter.hasNext()) {
/*  60 */       Map.Entry entry = (Map.Entry)iter.next();
/*  61 */       if (elementType.isDirty(entry.getValue(), xmap.get(entry.getKey()), getSession())) return false;
/*     */     }
/*  63 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isSnapshotEmpty(Serializable snapshot) {
/*  67 */     return ((Map)snapshot).isEmpty();
/*     */   }
/*     */   
/*     */   public boolean isWrapper(Object collection) {
/*  71 */     return this.map == collection;
/*     */   }
/*     */   
/*     */   public PersistentMap(SessionImplementor session) {
/*  75 */     super(session);
/*     */   }
/*     */   
/*     */   public PersistentMap() {}
/*     */   
/*     */   public void beforeInitialize(CollectionPersister persister) {
/*  81 */     this.map = ((Map)persister.getCollectionType().instantiate());
/*     */   }
/*     */   
/*     */   public PersistentMap(SessionImplementor session, Map map) {
/*  85 */     super(session);
/*  86 */     this.map = map;
/*  87 */     setInitialized();
/*  88 */     setDirectlyAccessible(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/*  95 */     return readSize() ? getCachedSize() : this.map.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 102 */     return readSize() ? false : getCachedSize() == 0 ? true : this.map.isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean containsKey(Object key)
/*     */   {
/* 109 */     Boolean exists = readIndexExistence(key);
/* 110 */     return exists == null ? this.map.containsKey(key) : exists.booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean containsValue(Object value)
/*     */   {
/* 117 */     Boolean exists = readElementExistence(value);
/* 118 */     return exists == null ? this.map.containsValue(value) : exists.booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object get(Object key)
/*     */   {
/* 127 */     Object result = readElementByIndex(key);
/* 128 */     return result == UNKNOWN ? this.map.get(key) : result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object put(Object key, Object value)
/*     */   {
/* 135 */     Object old = isPutQueueEnabled() ? readElementByIndex(key) : UNKNOWN;
/*     */     
/* 137 */     if (old == UNKNOWN) {
/* 138 */       write();
/* 139 */       return this.map.put(key, value);
/*     */     }
/*     */     
/* 142 */     queueOperation(new Put(key, value, old));
/* 143 */     return old;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object remove(Object key)
/*     */   {
/* 151 */     Object old = isPutQueueEnabled() ? readElementByIndex(key) : UNKNOWN;
/*     */     
/* 153 */     if (old == UNKNOWN) {
/* 154 */       write();
/* 155 */       return this.map.remove(key);
/*     */     }
/*     */     
/* 158 */     queueOperation(new Remove(key, old));
/* 159 */     return old;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void putAll(Map puts)
/*     */   {
/* 167 */     if (puts.size() > 0) {
/* 168 */       write();
/* 169 */       this.map.putAll(puts);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 177 */     if (isClearQueueEnabled()) {
/* 178 */       queueOperation(new Clear());
/*     */     }
/*     */     else {
/* 181 */       write();
/* 182 */       this.map.clear();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Set keySet()
/*     */   {
/* 190 */     read();
/* 191 */     return new AbstractPersistentCollection.SetProxy(this, this.map.keySet());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Collection values()
/*     */   {
/* 198 */     read();
/* 199 */     return new AbstractPersistentCollection.SetProxy(this, this.map.values());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Set entrySet()
/*     */   {
/* 206 */     read();
/* 207 */     return new EntrySetProxy(this.map.entrySet());
/*     */   }
/*     */   
/*     */   public boolean empty() {
/* 211 */     return this.map.isEmpty();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 215 */     read();
/* 216 */     return this.map.toString();
/*     */   }
/*     */   
/*     */   public Object readFrom(ResultSet rs, CollectionPersister persister, CollectionAliases descriptor, Object owner) throws HibernateException, SQLException
/*     */   {
/* 221 */     Object element = persister.readElement(rs, owner, descriptor.getSuffixedElementAliases(), getSession());
/* 222 */     Object index = persister.readIndex(rs, descriptor.getSuffixedIndexAliases(), getSession());
/* 223 */     if (element != null) this.map.put(index, element);
/* 224 */     return element;
/*     */   }
/*     */   
/*     */   public Iterator entries(CollectionPersister persister) {
/* 228 */     return this.map.entrySet().iterator();
/*     */   }
/*     */   
/*     */   class EntrySetProxy implements Set {
/*     */     private final Set set;
/*     */     
/*     */     EntrySetProxy(Set set) {
/* 235 */       this.set = set;
/*     */     }
/*     */     
/*     */     public boolean add(Object entry) {
/* 239 */       return this.set.add(entry);
/*     */     }
/*     */     
/*     */ 
/* 243 */     public boolean addAll(Collection entries) { return this.set.addAll(entries); }
/*     */     
/*     */     public void clear() {
/* 246 */       PersistentMap.this.write();
/* 247 */       this.set.clear();
/*     */     }
/*     */     
/* 250 */     public boolean contains(Object entry) { return this.set.contains(entry); }
/*     */     
/*     */     public boolean containsAll(Collection entries) {
/* 253 */       return this.set.containsAll(entries);
/*     */     }
/*     */     
/* 256 */     public boolean isEmpty() { return this.set.isEmpty(); }
/*     */     
/*     */ 
/* 259 */     public Iterator iterator() { return new PersistentMap.EntryIteratorProxy(PersistentMap.this, this.set.iterator()); }
/*     */     
/*     */     public boolean remove(Object entry) {
/* 262 */       PersistentMap.this.write();
/* 263 */       return this.set.remove(entry);
/*     */     }
/*     */     
/* 266 */     public boolean removeAll(Collection entries) { PersistentMap.this.write();
/* 267 */       return this.set.removeAll(entries);
/*     */     }
/*     */     
/* 270 */     public boolean retainAll(Collection entries) { PersistentMap.this.write();
/* 271 */       return this.set.retainAll(entries);
/*     */     }
/*     */     
/* 274 */     public int size() { return this.set.size(); }
/*     */     
/*     */ 
/*     */     public Object[] toArray()
/*     */     {
/* 279 */       return this.set.toArray();
/*     */     }
/*     */     
/* 282 */     public Object[] toArray(Object[] array) { return this.set.toArray(array); }
/*     */   }
/*     */   
/*     */   final class EntryIteratorProxy implements Iterator {
/*     */     private final Iterator iter;
/*     */     
/* 288 */     EntryIteratorProxy(Iterator iter) { this.iter = iter; }
/*     */     
/*     */     public boolean hasNext() {
/* 291 */       return this.iter.hasNext();
/*     */     }
/*     */     
/* 294 */     public Object next() { return new PersistentMap.MapEntryProxy(PersistentMap.this, (Map.Entry)this.iter.next()); }
/*     */     
/*     */     public void remove() {
/* 297 */       PersistentMap.this.write();
/* 298 */       this.iter.remove();
/*     */     }
/*     */   }
/*     */   
/*     */   final class MapEntryProxy implements Map.Entry {
/*     */     private final Map.Entry me;
/*     */     
/* 305 */     MapEntryProxy(Map.Entry me) { this.me = me; }
/*     */     
/* 307 */     public Object getKey() { return this.me.getKey(); }
/* 308 */     public Object getValue() { return this.me.getValue(); }
/* 309 */     public boolean equals(Object o) { return this.me.equals(o); }
/* 310 */     public int hashCode() { return this.me.hashCode(); }
/*     */     
/*     */     public Object setValue(Object value) {
/* 313 */       PersistentMap.this.write();
/* 314 */       return this.me.setValue(value);
/*     */     }
/*     */   }
/*     */   
/*     */   public void initializeFromCache(CollectionPersister persister, Serializable disassembled, Object owner) throws HibernateException
/*     */   {
/* 320 */     beforeInitialize(persister);
/* 321 */     Serializable[] array = (Serializable[])disassembled;
/* 322 */     for (int i = 0; i < array.length; i += 2) {
/* 323 */       this.map.put(persister.getIndexType().assemble(array[i], getSession(), owner), persister.getElementType().assemble(array[(i + 1)], getSession(), owner));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Serializable disassemble(CollectionPersister persister)
/*     */     throws HibernateException
/*     */   {
/* 332 */     Serializable[] result = new Serializable[this.map.size() * 2];
/* 333 */     Iterator iter = this.map.entrySet().iterator();
/* 334 */     int i = 0;
/* 335 */     while (iter.hasNext()) {
/* 336 */       Map.Entry e = (Map.Entry)iter.next();
/* 337 */       result[(i++)] = persister.getIndexType().disassemble(e.getKey(), getSession(), null);
/* 338 */       result[(i++)] = persister.getElementType().disassemble(e.getValue(), getSession(), null);
/*     */     }
/* 340 */     return result;
/*     */   }
/*     */   
/*     */   public Iterator getDeletes(CollectionPersister persister, boolean indexIsFormula)
/*     */     throws HibernateException
/*     */   {
/* 346 */     List deletes = new ArrayList();
/* 347 */     Iterator iter = ((Map)getSnapshot()).entrySet().iterator();
/* 348 */     while (iter.hasNext()) {
/* 349 */       Map.Entry e = (Map.Entry)iter.next();
/* 350 */       Object key = e.getKey();
/* 351 */       if ((e.getValue() != null) && (this.map.get(key) == null)) {
/* 352 */         deletes.add(indexIsFormula ? e.getValue() : key);
/*     */       }
/*     */     }
/* 355 */     return deletes.iterator();
/*     */   }
/*     */   
/*     */   public boolean needsInserting(Object entry, int i, Type elemType) throws HibernateException
/*     */   {
/* 360 */     Map sn = (Map)getSnapshot();
/* 361 */     Map.Entry e = (Map.Entry)entry;
/* 362 */     return (e.getValue() != null) && (sn.get(e.getKey()) == null);
/*     */   }
/*     */   
/*     */   public boolean needsUpdating(Object entry, int i, Type elemType) throws HibernateException
/*     */   {
/* 367 */     Map sn = (Map)getSnapshot();
/* 368 */     Map.Entry e = (Map.Entry)entry;
/* 369 */     Object snValue = sn.get(e.getKey());
/* 370 */     return (e.getValue() != null) && (snValue != null) && (elemType.isDirty(snValue, e.getValue(), getSession()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getIndex(Object entry, int i, CollectionPersister persister)
/*     */   {
/* 377 */     return ((Map.Entry)entry).getKey();
/*     */   }
/*     */   
/*     */   public Object getElement(Object entry) {
/* 381 */     return ((Map.Entry)entry).getValue();
/*     */   }
/*     */   
/*     */   public Object getSnapshotElement(Object entry, int i) {
/* 385 */     Map sn = (Map)getSnapshot();
/* 386 */     return sn.get(((Map.Entry)entry).getKey());
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/* 390 */     read();
/* 391 */     return this.map.equals(other);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 395 */     read();
/* 396 */     return this.map.hashCode();
/*     */   }
/*     */   
/*     */ 
/* 400 */   public boolean entryExists(Object entry, int i) { return ((Map.Entry)entry).getValue() != null; }
/*     */   
/*     */   final class Clear implements AbstractPersistentCollection.DelayedOperation {
/*     */     Clear() {}
/*     */     
/* 405 */     public void operate() { PersistentMap.this.map.clear(); }
/*     */     
/*     */     public Object getAddedInstance() {
/* 408 */       return null;
/*     */     }
/*     */     
/* 411 */     public Object getOrphan() { throw new UnsupportedOperationException("queued clear cannot be used with orphan delete"); }
/*     */   }
/*     */   
/*     */   final class Put implements AbstractPersistentCollection.DelayedOperation
/*     */   {
/*     */     private Object index;
/*     */     private Object value;
/*     */     private Object old;
/*     */     
/*     */     public Put(Object index, Object value, Object old) {
/* 421 */       this.index = index;
/* 422 */       this.value = value;
/* 423 */       this.old = old;
/*     */     }
/*     */     
/* 426 */     public void operate() { PersistentMap.this.map.put(this.index, this.value); }
/*     */     
/*     */     public Object getAddedInstance() {
/* 429 */       return this.value;
/*     */     }
/*     */     
/* 432 */     public Object getOrphan() { return this.old; }
/*     */   }
/*     */   
/*     */   final class Remove implements AbstractPersistentCollection.DelayedOperation
/*     */   {
/*     */     private Object index;
/*     */     private Object old;
/*     */     
/*     */     public Remove(Object index, Object old) {
/* 441 */       this.index = index;
/* 442 */       this.old = old;
/*     */     }
/*     */     
/* 445 */     public void operate() { PersistentMap.this.map.remove(this.index); }
/*     */     
/*     */     public Object getAddedInstance() {
/* 448 */       return null;
/*     */     }
/*     */     
/* 451 */     public Object getOrphan() { return this.old; }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\collection\PersistentMap.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */