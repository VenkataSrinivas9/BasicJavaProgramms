/*     */ package org.hibernate.dialect;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.dialect.function.VarArgsSQLFunction;
/*     */ import org.hibernate.exception.JDBCExceptionHelper;
/*     */ import org.hibernate.exception.TemplatedViolatedConstraintNameExtracter;
/*     */ import org.hibernate.exception.ViolatedConstraintNameExtracter;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InformixDialect
/*     */   extends Dialect
/*     */ {
/*     */   public InformixDialect()
/*     */   {
/*  31 */     registerColumnType(-5, "int8");
/*  32 */     registerColumnType(-2, "byte");
/*  33 */     registerColumnType(-7, "smallint");
/*  34 */     registerColumnType(1, "char($l)");
/*  35 */     registerColumnType(91, "date");
/*  36 */     registerColumnType(3, "decimal");
/*  37 */     registerColumnType(8, "double");
/*  38 */     registerColumnType(6, "float");
/*  39 */     registerColumnType(4, "integer");
/*  40 */     registerColumnType(-4, "blob");
/*  41 */     registerColumnType(-1, "clob");
/*  42 */     registerColumnType(2, "decimal");
/*  43 */     registerColumnType(7, "smallfloat");
/*  44 */     registerColumnType(5, "smallint");
/*  45 */     registerColumnType(93, "datetime year to fraction(5)");
/*  46 */     registerColumnType(92, "datetime hour to second");
/*  47 */     registerColumnType(-6, "smallint");
/*  48 */     registerColumnType(-3, "byte");
/*  49 */     registerColumnType(12, "varchar($l)");
/*  50 */     registerColumnType(12, 255, "varchar($l)");
/*  51 */     registerColumnType(12, 32739, "lvarchar($l)");
/*     */     
/*  53 */     registerFunction("concat", new VarArgsSQLFunction(Hibernate.STRING, "(", "||", ")"));
/*     */   }
/*     */   
/*     */   public String getAddColumnString() {
/*  57 */     return "add";
/*     */   }
/*     */   
/*     */   public boolean supportsIdentityColumns() {
/*  61 */     return true;
/*     */   }
/*     */   
/*     */   public String getIdentitySelectString(String table, String column, int type) throws MappingException
/*     */   {
/*  66 */     return type == -5 ? "select dbinfo('serial8') from systables where tabid=1" : "select dbinfo('sqlca.sqlerrd1') from systables where tabid=1";
/*     */   }
/*     */   
/*     */   public String getIdentityColumnString(int type)
/*     */     throws MappingException
/*     */   {
/*  72 */     return type == -5 ? "serial8 not null" : "serial not null";
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean hasDataTypeInIdentityColumn()
/*     */   {
/*  78 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAddForeignKeyConstraintString(String constraintName, String[] foreignKey, String referencedTable, String[] primaryKey, boolean referencesPrimaryKey)
/*     */   {
/*  92 */     StringBuffer result = new StringBuffer(30);
/*     */     
/*  94 */     result.append(" add constraint ").append(" foreign key (").append(StringHelper.join(", ", foreignKey)).append(") references ").append(referencedTable);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */     if (!referencesPrimaryKey) {
/* 101 */       result.append(" (").append(StringHelper.join(", ", primaryKey)).append(')');
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 106 */     result.append(" constraint ").append(constraintName);
/*     */     
/* 108 */     return result.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAddPrimaryKeyConstraintString(String constraintName)
/*     */   {
/* 117 */     return " add constraint primary key constraint " + constraintName + " ";
/*     */   }
/*     */   
/*     */   public String getCreateSequenceString(String sequenceName) {
/* 121 */     return "create sequence " + sequenceName;
/*     */   }
/*     */   
/* 124 */   public String getDropSequenceString(String sequenceName) { return "drop sequence " + sequenceName + " restrict"; }
/*     */   
/*     */   public String getSequenceNextValString(String sequenceName)
/*     */   {
/* 128 */     return "select " + getSelectSequenceNextValString(sequenceName) + " from systables where tabid=1";
/*     */   }
/*     */   
/*     */   public String getSelectSequenceNextValString(String sequenceName) {
/* 132 */     return sequenceName + ".nextval";
/*     */   }
/*     */   
/*     */   public boolean supportsSequences() {
/* 136 */     return true;
/*     */   }
/*     */   
/*     */   public boolean supportsLimit() {
/* 140 */     return true;
/*     */   }
/*     */   
/*     */   public boolean useMaxForLimit() {
/* 144 */     return true;
/*     */   }
/*     */   
/*     */   public boolean supportsLimitOffset() {
/* 148 */     return false;
/*     */   }
/*     */   
/*     */   public String getLimitString(String querySelect, int offset, int limit) {
/* 152 */     if (offset > 0) throw new UnsupportedOperationException("informix has no offset");
/* 153 */     return new StringBuffer(querySelect.length() + 8).append(querySelect).insert(querySelect.toLowerCase().indexOf("select") + 6, " first " + limit).toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean supportsVariableLimit()
/*     */   {
/* 160 */     return false;
/*     */   }
/*     */   
/*     */   public ViolatedConstraintNameExtracter getViolatedConstraintNameExtracter() {
/* 164 */     return EXTRACTER;
/*     */   }
/*     */   
/* 167 */   private static ViolatedConstraintNameExtracter EXTRACTER = new TemplatedViolatedConstraintNameExtracter()
/*     */   {
/*     */ 
/*     */ 
/*     */ 
/*     */     public String extractConstraintName(SQLException sqle)
/*     */     {
/*     */ 
/*     */ 
/* 176 */       String constraintName = null;
/*     */       
/* 178 */       int errorCode = JDBCExceptionHelper.extractErrorCode(sqle);
/* 179 */       if (errorCode == 65268) {
/* 180 */         constraintName = extractUsingTemplate("Unique constraint (", ") violated.", sqle.getMessage());
/*     */       }
/* 182 */       else if (errorCode == 64845) {
/* 183 */         constraintName = extractUsingTemplate("Missing key in referenced table for referential constraint (", ").", sqle.getMessage());
/*     */       }
/* 185 */       else if (errorCode == 64844) {
/* 186 */         constraintName = extractUsingTemplate("Key value for constraint (", ") is still being referenced.", sqle.getMessage());
/*     */       }
/*     */       
/* 189 */       if (constraintName != null)
/*     */       {
/* 191 */         int i = constraintName.indexOf('.');
/* 192 */         if (i != -1) {
/* 193 */           constraintName = constraintName.substring(i + 1);
/*     */         }
/*     */       }
/*     */       
/* 197 */       return constraintName;
/*     */     }
/*     */   };
/*     */   
/*     */   public boolean supportsCurrentTimestampSelection()
/*     */   {
/* 203 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isCurrentTimestampSelectStringCallable() {
/* 207 */     return false;
/*     */   }
/*     */   
/*     */   public String getCurrentTimestampSelectString() {
/* 211 */     return "select distinct current timestamp from informix.systables";
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\InformixDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */