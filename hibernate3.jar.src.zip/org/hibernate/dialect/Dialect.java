/*      */ package org.hibernate.dialect;
/*      */ 
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.hibernate.Hibernate;
/*      */ import org.hibernate.HibernateException;
/*      */ import org.hibernate.LockMode;
/*      */ import org.hibernate.MappingException;
/*      */ import org.hibernate.QueryException;
/*      */ import org.hibernate.cfg.Environment;
/*      */ import org.hibernate.dialect.function.CastFunction;
/*      */ import org.hibernate.dialect.function.SQLFunction;
/*      */ import org.hibernate.dialect.function.SQLFunctionTemplate;
/*      */ import org.hibernate.dialect.function.StandardSQLFunction;
/*      */ import org.hibernate.engine.Mapping;
/*      */ import org.hibernate.exception.SQLExceptionConverter;
/*      */ import org.hibernate.exception.SQLStateConverter;
/*      */ import org.hibernate.exception.ViolatedConstraintNameExtracter;
/*      */ import org.hibernate.id.IdentityGenerator;
/*      */ import org.hibernate.id.SequenceGenerator;
/*      */ import org.hibernate.id.TableHiLoGenerator;
/*      */ import org.hibernate.sql.ANSICaseFragment;
/*      */ import org.hibernate.sql.ANSIJoinFragment;
/*      */ import org.hibernate.sql.CaseFragment;
/*      */ import org.hibernate.sql.JoinFragment;
/*      */ import org.hibernate.type.NullableType;
/*      */ import org.hibernate.type.Type;
/*      */ import org.hibernate.util.ReflectHelper;
/*      */ import org.hibernate.util.StringHelper;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Dialect
/*      */ {
/*   55 */   private static final Log log = LogFactory.getLog(Dialect.class);
/*      */   
/*      */   static final String DEFAULT_BATCH_SIZE = "15";
/*      */   
/*      */   static final String NO_BATCH = "0";
/*   60 */   private static final Map STANDARD_AGGREGATE_FUNCTIONS = new HashMap();
/*      */   
/*      */   static {
/*   63 */     STANDARD_AGGREGATE_FUNCTIONS.put("count", new StandardSQLFunction("count") {
/*      */       public Type getReturnType(Type columnType, Mapping mapping) {
/*   65 */         return Hibernate.INTEGER;
/*      */       }
/*      */       
/*   68 */     });
/*   69 */     STANDARD_AGGREGATE_FUNCTIONS.put("avg", new StandardSQLFunction("avg")
/*      */     {
/*      */       public Type getReturnType(Type columnType, Mapping mapping) throws QueryException {
/*      */         try {
/*   73 */           sqlTypes = columnType.sqlTypes(mapping);
/*      */         } catch (MappingException me) {
/*      */           int[] sqlTypes;
/*   76 */           throw new QueryException(me); }
/*      */         int[] sqlTypes;
/*   78 */         if (sqlTypes.length != 1) throw new QueryException("multi-column type in avg()");
/*   79 */         int sqlType = sqlTypes[0];
/*   80 */         if ((sqlType == 4) || (sqlType == -5) || (sqlType == -6)) {
/*   81 */           return Hibernate.FLOAT;
/*      */         }
/*      */         
/*   84 */         return columnType;
/*      */       }
/*      */       
/*      */ 
/*   88 */     });
/*   89 */     STANDARD_AGGREGATE_FUNCTIONS.put("max", new StandardSQLFunction("max"));
/*   90 */     STANDARD_AGGREGATE_FUNCTIONS.put("min", new StandardSQLFunction("min"));
/*   91 */     STANDARD_AGGREGATE_FUNCTIONS.put("sum", new StandardSQLFunction("sum"));
/*      */   }
/*      */   
/*   94 */   private final TypeNames typeNames = new TypeNames();
/*   95 */   private final TypeNames hibernateTypeNames = new TypeNames();
/*      */   
/*   97 */   private final Properties properties = new Properties();
/*   98 */   private final Map sqlFunctions = new HashMap();
/*   99 */   private final Set sqlKeywords = new HashSet();
/*      */   public static final String QUOTE = "`\"[";
/*      */   public static final String CLOSED_QUOTE = "`\"]";
/*      */   
/*  103 */   protected Dialect() { log.info("Using dialect: " + this);
/*  104 */     this.sqlFunctions.putAll(STANDARD_AGGREGATE_FUNCTIONS);
/*      */     
/*      */ 
/*  107 */     registerFunction("substring", new SQLFunctionTemplate(Hibernate.STRING, "substring(?1, ?2, ?3)"));
/*  108 */     registerFunction("locate", new SQLFunctionTemplate(Hibernate.INTEGER, "locate(?1, ?2, ?3)"));
/*  109 */     registerFunction("trim", new SQLFunctionTemplate(Hibernate.STRING, "trim(?1 ?2 ?3 ?4)"));
/*  110 */     registerFunction("length", new StandardSQLFunction("length", Hibernate.INTEGER));
/*  111 */     registerFunction("bit_length", new StandardSQLFunction("bit_length", Hibernate.INTEGER));
/*  112 */     registerFunction("coalesce", new StandardSQLFunction("coalesce"));
/*  113 */     registerFunction("nullif", new StandardSQLFunction("nullif"));
/*  114 */     registerFunction("abs", new StandardSQLFunction("abs"));
/*  115 */     registerFunction("mod", new StandardSQLFunction("mod", Hibernate.INTEGER));
/*  116 */     registerFunction("sqrt", new StandardSQLFunction("sqrt", Hibernate.DOUBLE));
/*  117 */     registerFunction("upper", new StandardSQLFunction("upper"));
/*  118 */     registerFunction("lower", new StandardSQLFunction("lower"));
/*  119 */     registerFunction("cast", new CastFunction());
/*  120 */     registerFunction("extract", new SQLFunctionTemplate(Hibernate.INTEGER, "extract(?1 ?2 ?3)"));
/*      */     
/*      */ 
/*  123 */     registerFunction("second", new SQLFunctionTemplate(Hibernate.INTEGER, "extract(second from ?1)"));
/*  124 */     registerFunction("minute", new SQLFunctionTemplate(Hibernate.INTEGER, "extract(minute from ?1)"));
/*  125 */     registerFunction("hour", new SQLFunctionTemplate(Hibernate.INTEGER, "extract(hour from ?1)"));
/*  126 */     registerFunction("day", new SQLFunctionTemplate(Hibernate.INTEGER, "extract(day from ?1)"));
/*  127 */     registerFunction("month", new SQLFunctionTemplate(Hibernate.INTEGER, "extract(month from ?1)"));
/*  128 */     registerFunction("year", new SQLFunctionTemplate(Hibernate.INTEGER, "extract(year from ?1)"));
/*      */     
/*  130 */     registerFunction("str", new SQLFunctionTemplate(Hibernate.STRING, "cast(?1 as char)"));
/*      */     
/*      */ 
/*  133 */     registerHibernateType(-5, Hibernate.BIG_INTEGER.getName());
/*  134 */     registerHibernateType(-2, Hibernate.BINARY.getName());
/*  135 */     registerHibernateType(-7, Hibernate.BOOLEAN.getName());
/*  136 */     registerHibernateType(1, Hibernate.CHARACTER.getName());
/*  137 */     registerHibernateType(91, Hibernate.DATE.getName());
/*  138 */     registerHibernateType(8, Hibernate.DOUBLE.getName());
/*  139 */     registerHibernateType(6, Hibernate.FLOAT.getName());
/*  140 */     registerHibernateType(4, Hibernate.INTEGER.getName());
/*  141 */     registerHibernateType(5, Hibernate.SHORT.getName());
/*  142 */     registerHibernateType(-6, Hibernate.BYTE.getName());
/*  143 */     registerHibernateType(92, Hibernate.TIME.getName());
/*  144 */     registerHibernateType(93, Hibernate.TIMESTAMP.getName());
/*  145 */     registerHibernateType(12, Hibernate.STRING.getName());
/*  146 */     registerHibernateType(-3, Hibernate.BINARY.getName());
/*  147 */     registerHibernateType(2, Hibernate.BIG_DECIMAL.getName());
/*  148 */     registerHibernateType(2004, Hibernate.BLOB.getName());
/*  149 */     registerHibernateType(2005, Hibernate.CLOB.getName());
/*      */   }
/*      */   
/*      */   public String toString()
/*      */   {
/*  154 */     return getClass().getName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getTypeName(int code)
/*      */     throws HibernateException
/*      */   {
/*  173 */     String result = this.typeNames.get(code);
/*  174 */     if (result == null) {
/*  175 */       throw new HibernateException("No default type mapping for (java.sql.Types) " + code);
/*      */     }
/*  177 */     return result;
/*      */   }
/*      */   
/*      */   public String getHibernateTypeName(int code) throws HibernateException
/*      */   {
/*  182 */     String result = this.hibernateTypeNames.get(code);
/*  183 */     if (result == null) {
/*  184 */       throw new HibernateException("No Hibernate type mapping for java.sql.Types code: " + code);
/*      */     }
/*      */     
/*      */ 
/*  188 */     return result;
/*      */   }
/*      */   
/*      */   public String getHibernateTypeName(int code, int length, int precision, int scale) throws HibernateException {
/*  192 */     String result = this.hibernateTypeNames.get(code, length, precision, scale);
/*  193 */     if (result == null) {
/*  194 */       throw new HibernateException("No Hibernate type mapping for java.sql.Types code: " + code + ", length: " + length);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  201 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getTypeName(int code, int length, int precision, int scale)
/*      */     throws HibernateException
/*      */   {
/*  216 */     String result = this.typeNames.get(code, length, precision, scale);
/*  217 */     if (result == null) {
/*  218 */       throw new HibernateException("No type mapping for java.sql.Types code: " + code + ", length: " + length);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  225 */     return result;
/*      */   }
/*      */   
/*      */   public String getCastTypeName(int code) {
/*  229 */     return getTypeName(code, 255, 19, 2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void registerFunction(String name, SQLFunction function)
/*      */   {
/*  238 */     this.sqlFunctions.put(name, function);
/*      */   }
/*      */   
/*      */   protected void registerKeyword(String word) {
/*  242 */     this.sqlKeywords.add(word);
/*      */   }
/*      */   
/*      */   public Set getKeywords() {
/*  246 */     return this.sqlKeywords;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void registerColumnType(int code, int capacity, String name)
/*      */   {
/*  259 */     this.typeNames.put(code, capacity, name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void registerColumnType(int code, String name)
/*      */   {
/*  270 */     this.typeNames.put(code, name);
/*      */   }
/*      */   
/*      */   protected void registerHibernateType(int sqlcode, String name) {
/*  274 */     this.hibernateTypeNames.put(sqlcode, name);
/*      */   }
/*      */   
/*      */   protected void registerHibernateType(int sqlcode, int capacity, String name) {
/*  278 */     this.hibernateTypeNames.put(sqlcode, capacity, name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasAlterTable()
/*      */   {
/*  287 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean dropConstraints()
/*      */   {
/*  296 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean qualifyIndexName()
/*      */   {
/*  305 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean forUpdateOfColumns()
/*      */   {
/*  313 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getForUpdateString(String aliases)
/*      */   {
/*  322 */     return getForUpdateString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getForUpdateNowaitString(String aliases)
/*      */   {
/*  332 */     return getForUpdateString(aliases);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getForUpdateString()
/*      */   {
/*  341 */     return " for update";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getForUpdateNowaitString()
/*      */   {
/*  350 */     return getForUpdateString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsUnique()
/*      */   {
/*  359 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsUniqueConstraintInCreateAlterTable()
/*      */   {
/*  368 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAddColumnString()
/*      */   {
/*  376 */     throw new UnsupportedOperationException("No add column syntax supported by Dialect");
/*      */   }
/*      */   
/*      */   public String getDropForeignKeyString() {
/*  380 */     return " drop constraint ";
/*      */   }
/*      */   
/*      */   public String getTableTypeString() {
/*  384 */     return "";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAddForeignKeyConstraintString(String constraintName, String[] foreignKey, String referencedTable, String[] primaryKey, boolean referencesPrimaryKey)
/*      */   {
/*  402 */     StringBuffer res = new StringBuffer(30);
/*      */     
/*  404 */     res.append(" add constraint ").append(constraintName).append(" foreign key (").append(StringHelper.join(", ", foreignKey)).append(") references ").append(referencedTable);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  411 */     if (!referencesPrimaryKey) {
/*  412 */       res.append(" (").append(StringHelper.join(", ", primaryKey)).append(')');
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  417 */     return res.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAddPrimaryKeyConstraintString(String constraintName)
/*      */   {
/*  426 */     return " add constraint " + constraintName + " primary key ";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getNullColumnString()
/*      */   {
/*  435 */     return "";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsIdentityColumns()
/*      */   {
/*  444 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsSequences()
/*      */   {
/*  453 */     return false;
/*      */   }
/*      */   
/*      */   public boolean supportsInsertSelectIdentity() {
/*  457 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String appendIdentitySelectToInsert(String insertString)
/*      */   {
/*  465 */     return insertString;
/*      */   }
/*      */   
/*      */   protected String getIdentitySelectString() throws MappingException {
/*  469 */     throw new MappingException("Dialect does not support identity key generation");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getIdentitySelectString(String table, String column, int type)
/*      */     throws MappingException
/*      */   {
/*  481 */     return getIdentitySelectString();
/*      */   }
/*      */   
/*      */   protected String getIdentityColumnString() throws MappingException {
/*  485 */     throw new MappingException("Dialect does not support identity key generation");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getIdentityColumnString(int type)
/*      */     throws MappingException
/*      */   {
/*  496 */     return getIdentityColumnString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getIdentityInsertString()
/*      */   {
/*  506 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getNoColumnsInsertString()
/*      */   {
/*  514 */     return "values ( )";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSequenceNextValString(String sequenceName)
/*      */     throws MappingException
/*      */   {
/*  528 */     throw new MappingException("Dialect does not support sequences");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSelectSequenceNextValString(String sequenceName)
/*      */     throws MappingException
/*      */   {
/*  543 */     throw new MappingException("Dialect does not support sequences");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getCreateSequenceString(String sequenceName)
/*      */     throws MappingException
/*      */   {
/*  554 */     throw new MappingException("Dialect does not support sequences");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getCreateSequenceStrings(String sequenceName)
/*      */     throws MappingException
/*      */   {
/*  565 */     return new String[] { getCreateSequenceString(sequenceName) };
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getDropSequenceString(String sequenceName)
/*      */     throws MappingException
/*      */   {
/*  576 */     throw new MappingException("Dialect does not support sequences");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getDropSequenceStrings(String sequenceName)
/*      */     throws MappingException
/*      */   {
/*  587 */     return new String[] { getDropSequenceString(sequenceName) };
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getQuerySequencesString()
/*      */   {
/*  596 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Dialect getDialect()
/*      */     throws HibernateException
/*      */   {
/*  606 */     String dialectName = Environment.getProperties().getProperty("hibernate.dialect");
/*  607 */     if (dialectName == null) throw new HibernateException("The dialect was not set. Set the property hibernate.dialect.");
/*      */     try {
/*  609 */       return (Dialect)ReflectHelper.classForName(dialectName).newInstance();
/*      */     }
/*      */     catch (ClassNotFoundException cnfe) {
/*  612 */       throw new HibernateException("Dialect class not found: " + dialectName);
/*      */     }
/*      */     catch (Exception e) {
/*  615 */       throw new HibernateException("Could not instantiate dialect class", e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Dialect getDialect(Properties props)
/*      */     throws HibernateException
/*      */   {
/*  628 */     String dialectName = props.getProperty("hibernate.dialect");
/*  629 */     if (dialectName == null) return getDialect();
/*      */     try {
/*  631 */       return (Dialect)ReflectHelper.classForName(dialectName).newInstance();
/*      */     }
/*      */     catch (ClassNotFoundException cnfe) {
/*  634 */       throw new HibernateException("Dialect class not found: " + dialectName);
/*      */     }
/*      */     catch (Exception e) {
/*  637 */       throw new HibernateException("Could not instantiate dialect class", e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Properties getDefaultProperties()
/*      */   {
/*  647 */     return this.properties;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCascadeConstraintsString()
/*      */   {
/*  656 */     return "";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JoinFragment createOuterJoinFragment()
/*      */   {
/*  665 */     return new ANSIJoinFragment();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CaseFragment createCaseFragment()
/*      */   {
/*  674 */     return new ANSICaseFragment();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getLowercaseFunction()
/*      */   {
/*  684 */     return "lower";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean supportsLimit()
/*      */   {
/*  691 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean supportsLimitOffset()
/*      */   {
/*  698 */     return supportsLimit();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getLimitString(String querySelect, boolean hasOffset)
/*      */   {
/*  707 */     throw new UnsupportedOperationException("paged queries not supported");
/*      */   }
/*      */   
/*      */   public String getLimitString(String querySelect, int offset, int limit) {
/*  711 */     return getLimitString(querySelect, offset > 0);
/*      */   }
/*      */   
/*      */   public boolean supportsVariableLimit() {
/*  715 */     return supportsLimit();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean bindLimitParametersInReverseOrder()
/*      */   {
/*  725 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean bindLimitParametersFirst()
/*      */   {
/*  735 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean useMaxForLimit()
/*      */   {
/*  743 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public char openQuote()
/*      */   {
/*  750 */     return '"';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public char closeQuote()
/*      */   {
/*  757 */     return '"';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Map getFunctions()
/*      */   {
/*  765 */     return this.sqlFunctions;
/*      */   }
/*      */   
/*      */   public boolean supportsIfExistsBeforeTableName() {
/*  769 */     return false;
/*      */   }
/*      */   
/*      */   public boolean supportsIfExistsAfterTableName() {
/*  773 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean supportsColumnCheck()
/*      */   {
/*  780 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean supportsTableCheck()
/*      */   {
/*  787 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasDataTypeInIdentityColumn()
/*      */   {
/*  797 */     return true;
/*      */   }
/*      */   
/*      */   public boolean supportsCascadeDelete() {
/*  801 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String appendLockHint(LockMode mode, String tableName)
/*      */   {
/*  818 */     return tableName;
/*      */   }
/*      */   
/*      */   public Class getNativeIdentifierGeneratorClass() {
/*  822 */     if (supportsIdentityColumns()) {
/*  823 */       return IdentityGenerator.class;
/*      */     }
/*  825 */     if (supportsSequences()) {
/*  826 */       return SequenceGenerator.class;
/*      */     }
/*      */     
/*  829 */     return TableHiLoGenerator.class;
/*      */   }
/*      */   
/*      */   public String getSelectGUIDString()
/*      */   {
/*  834 */     throw new UnsupportedOperationException("dialect does not support GUIDs");
/*      */   }
/*      */   
/*      */   public boolean supportsOuterJoinForUpdate() {
/*  838 */     return true;
/*      */   }
/*      */   
/*      */   public String getSelectClauseNullString(int sqlType) {
/*  842 */     return "null";
/*      */   }
/*      */   
/*      */   public boolean supportsNotNullUnique() {
/*  846 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SQLExceptionConverter buildSQLExceptionConverter()
/*      */   {
/*  865 */     return new SQLStateConverter(getViolatedConstraintNameExtracter());
/*      */   }
/*      */   
/*  868 */   private static final ViolatedConstraintNameExtracter EXTRACTER = new ViolatedConstraintNameExtracter() {
/*      */     public String extractConstraintName(SQLException sqle) {
/*  870 */       return null;
/*      */     }
/*      */   };
/*      */   
/*      */   public ViolatedConstraintNameExtracter getViolatedConstraintNameExtracter() {
/*  875 */     return EXTRACTER;
/*      */   }
/*      */   
/*      */   public final String quote(String column) {
/*  879 */     if (column.charAt(0) == '`') {
/*  880 */       return openQuote() + column.substring(1, column.length() - 1) + closeQuote();
/*      */     }
/*      */     
/*  883 */     return column;
/*      */   }
/*      */   
/*      */   public boolean hasSelfReferentialForeignKeyBug()
/*      */   {
/*  888 */     return false;
/*      */   }
/*      */   
/*      */   public boolean useInputStreamToInsertBlob()
/*      */   {
/*  893 */     return true;
/*      */   }
/*      */   
/*      */   public int registerResultSetOutParameter(CallableStatement statement, int col) throws SQLException {
/*  897 */     throw new UnsupportedOperationException(getClass().getName() + " does not support resultsets via stored procedures");
/*      */   }
/*      */   
/*      */ 
/*      */   public ResultSet getResultSet(CallableStatement ps)
/*      */     throws SQLException
/*      */   {
/*  904 */     throw new UnsupportedOperationException(getClass().getName() + " does not support resultsets via stored procedures");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean supportsUnionAll()
/*      */   {
/*  911 */     return false;
/*      */   }
/*      */   
/*      */   public boolean supportsCommentOn() {
/*  915 */     return false;
/*      */   }
/*      */   
/*      */   public String getTableComment(String comment) {
/*  919 */     return "";
/*      */   }
/*      */   
/*      */   public String getColumnComment(String comment) {
/*  923 */     return "";
/*      */   }
/*      */   
/*      */   public String transformSelectString(String select) {
/*  927 */     return select;
/*      */   }
/*      */   
/*      */   public boolean supportsTemporaryTables() {
/*  931 */     return false;
/*      */   }
/*      */   
/*      */   public String generateTemporaryTableName(String baseTableName) {
/*  935 */     return "HT_" + baseTableName;
/*      */   }
/*      */   
/*      */   public String getCreateTemporaryTableString() {
/*  939 */     return "create table";
/*      */   }
/*      */   
/*      */   public boolean performTemporaryTableDDLInIsolation() {
/*  943 */     return false;
/*      */   }
/*      */   
/*      */   public String getCreateTemporaryTablePostfix() {
/*  947 */     return "";
/*      */   }
/*      */   
/*      */   public boolean dropTemporaryTableAfterUse() {
/*  951 */     return true;
/*      */   }
/*      */   
/*      */   public String getForUpdateString(LockMode lockMode) {
/*  955 */     if (lockMode == LockMode.UPGRADE) {
/*  956 */       return getForUpdateString();
/*      */     }
/*  958 */     if (lockMode == LockMode.UPGRADE_NOWAIT) {
/*  959 */       return getForUpdateNowaitString();
/*      */     }
/*      */     
/*  962 */     return "";
/*      */   }
/*      */   
/*      */   public int getMaxAliasLength()
/*      */   {
/*  967 */     return 10;
/*      */   }
/*      */   
/*      */   public boolean supportsCurrentTimestampSelection() {
/*  971 */     return false;
/*      */   }
/*      */   
/*      */   public String getCurrentTimestampSelectString() {
/*  975 */     throw new UnsupportedOperationException("Database not known to define a current timestamp function");
/*      */   }
/*      */   
/*      */   public boolean isCurrentTimestampSelectStringCallable() {
/*  979 */     throw new UnsupportedOperationException("Database not known to define a current timestamp function");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String toBooleanValueString(boolean bool)
/*      */   {
/*  986 */     return bool ? "1" : "0";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean supportsParametersInInsertSelect()
/*      */   {
/*  996 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCurrentTimestampSQLFunctionName()
/*      */   {
/* 1007 */     return "current_timestamp";
/*      */   }
/*      */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\Dialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */