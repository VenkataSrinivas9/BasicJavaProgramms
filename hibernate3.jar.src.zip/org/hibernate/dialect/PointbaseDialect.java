/*    */ package org.hibernate.dialect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PointbaseDialect
/*    */   extends Dialect
/*    */ {
/*    */   public PointbaseDialect()
/*    */   {
/* 18 */     registerColumnType(-7, "smallint");
/* 19 */     registerColumnType(-5, "bigint");
/* 20 */     registerColumnType(5, "smallint");
/* 21 */     registerColumnType(-6, "smallint");
/* 22 */     registerColumnType(4, "integer");
/* 23 */     registerColumnType(1, "char(1)");
/* 24 */     registerColumnType(12, "varchar($l)");
/* 25 */     registerColumnType(6, "float");
/* 26 */     registerColumnType(8, "double precision");
/* 27 */     registerColumnType(91, "date");
/* 28 */     registerColumnType(92, "time");
/* 29 */     registerColumnType(93, "timestamp");
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 34 */     registerColumnType(-3, "blob($l)");
/* 35 */     registerColumnType(2, "numeric($p,$s)");
/*    */   }
/*    */   
/*    */   public String getAddColumnString() {
/* 39 */     return "add";
/*    */   }
/*    */   
/*    */   public boolean dropConstraints() {
/* 43 */     return false;
/*    */   }
/*    */   
/*    */   public String getCascadeConstraintsString() {
/* 47 */     return " cascade";
/*    */   }
/*    */   
/*    */   public String getForUpdateString() {
/* 51 */     return "";
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\PointbaseDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */