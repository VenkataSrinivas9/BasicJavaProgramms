/*     */ package org.hibernate.dialect;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.dialect.function.StandardSQLFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MimerSQLDialect
/*     */   extends Dialect
/*     */ {
/*     */   private static final int NATIONAL_CHAR_LENGTH = 2000;
/*     */   private static final int BINARY_MAX_LENGTH = 2000;
/*     */   
/*     */   public MimerSQLDialect()
/*     */   {
/*  57 */     registerColumnType(-7, "ODBC.BIT");
/*     */     
/*  59 */     registerColumnType(-5, "BIGINT");
/*     */     
/*  61 */     registerColumnType(5, "SMALLINT");
/*     */     
/*  63 */     registerColumnType(-6, "ODBC.TINYINT");
/*     */     
/*  65 */     registerColumnType(4, "INTEGER");
/*     */     
/*  67 */     registerColumnType(1, "NCHAR(1)");
/*     */     
/*  69 */     registerColumnType(12, 2000, "NATIONAL CHARACTER VARYING($l)");
/*     */     
/*  71 */     registerColumnType(12, "NCLOB($l)");
/*     */     
/*  73 */     registerColumnType(-1, "CLOB($1)");
/*     */     
/*  75 */     registerColumnType(6, "FLOAT");
/*     */     
/*  77 */     registerColumnType(8, "DOUBLE PRECISION");
/*     */     
/*  79 */     registerColumnType(91, "DATE");
/*     */     
/*  81 */     registerColumnType(92, "TIME");
/*     */     
/*  83 */     registerColumnType(93, "TIMESTAMP");
/*     */     
/*  85 */     registerColumnType(-3, 2000, "BINARY VARYING($l)");
/*     */     
/*  87 */     registerColumnType(-3, "BLOB($1)");
/*     */     
/*  89 */     registerColumnType(-4, "BLOB($1)");
/*     */     
/*  91 */     registerColumnType(-2, 2000, "BINARY");
/*     */     
/*  93 */     registerColumnType(-2, "BLOB($1)");
/*     */     
/*  95 */     registerColumnType(2, "NUMERIC(19, $l)");
/*     */     
/*  97 */     registerColumnType(2004, "BLOB($l)");
/*     */     
/*  99 */     registerColumnType(2005, "NCLOB($l)");
/*     */     
/*     */ 
/*     */ 
/* 103 */     registerFunction("abs", new StandardSQLFunction("abs"));
/*     */     
/* 105 */     registerFunction("sign", new StandardSQLFunction("sign", Hibernate.INTEGER));
/*     */     
/* 107 */     registerFunction("ceiling", new StandardSQLFunction("ceiling"));
/*     */     
/* 109 */     registerFunction("floor", new StandardSQLFunction("floor"));
/*     */     
/* 111 */     registerFunction("round", new StandardSQLFunction("round"));
/*     */     
/*     */ 
/*     */ 
/* 115 */     registerFunction("dacos", new StandardSQLFunction("dacos", Hibernate.DOUBLE));
/*     */     
/* 117 */     registerFunction("acos", new StandardSQLFunction("dacos", Hibernate.DOUBLE));
/*     */     
/* 119 */     registerFunction("dasin", new StandardSQLFunction("dasin", Hibernate.DOUBLE));
/*     */     
/* 121 */     registerFunction("asin", new StandardSQLFunction("dasin", Hibernate.DOUBLE));
/*     */     
/* 123 */     registerFunction("datan", new StandardSQLFunction("datan", Hibernate.DOUBLE));
/*     */     
/* 125 */     registerFunction("atan", new StandardSQLFunction("datan", Hibernate.DOUBLE));
/*     */     
/* 127 */     registerFunction("datan2", new StandardSQLFunction("datan2", Hibernate.DOUBLE));
/*     */     
/* 129 */     registerFunction("atan2", new StandardSQLFunction("datan2", Hibernate.DOUBLE));
/*     */     
/* 131 */     registerFunction("dcos", new StandardSQLFunction("dcos", Hibernate.DOUBLE));
/*     */     
/* 133 */     registerFunction("cos", new StandardSQLFunction("dcos", Hibernate.DOUBLE));
/*     */     
/* 135 */     registerFunction("dcot", new StandardSQLFunction("dcot", Hibernate.DOUBLE));
/*     */     
/* 137 */     registerFunction("cot", new StandardSQLFunction("dcot", Hibernate.DOUBLE));
/*     */     
/* 139 */     registerFunction("ddegrees", new StandardSQLFunction("ddegrees", Hibernate.DOUBLE));
/*     */     
/* 141 */     registerFunction("degrees", new StandardSQLFunction("ddegrees", Hibernate.DOUBLE));
/*     */     
/* 143 */     registerFunction("dexp", new StandardSQLFunction("dexp", Hibernate.DOUBLE));
/*     */     
/* 145 */     registerFunction("exp", new StandardSQLFunction("dexp", Hibernate.DOUBLE));
/*     */     
/* 147 */     registerFunction("dlog", new StandardSQLFunction("dlog", Hibernate.DOUBLE));
/*     */     
/* 149 */     registerFunction("log", new StandardSQLFunction("dlog", Hibernate.DOUBLE));
/*     */     
/* 151 */     registerFunction("dlog10", new StandardSQLFunction("dlog10", Hibernate.DOUBLE));
/*     */     
/* 153 */     registerFunction("log10", new StandardSQLFunction("dlog10", Hibernate.DOUBLE));
/*     */     
/* 155 */     registerFunction("dradian", new StandardSQLFunction("dradian", Hibernate.DOUBLE));
/*     */     
/* 157 */     registerFunction("radian", new StandardSQLFunction("dradian", Hibernate.DOUBLE));
/*     */     
/* 159 */     registerFunction("dsin", new StandardSQLFunction("dsin", Hibernate.DOUBLE));
/*     */     
/* 161 */     registerFunction("sin", new StandardSQLFunction("dsin", Hibernate.DOUBLE));
/*     */     
/* 163 */     registerFunction("soundex", new StandardSQLFunction("soundex", Hibernate.STRING));
/*     */     
/* 165 */     registerFunction("dsqrt", new StandardSQLFunction("dsqrt", Hibernate.DOUBLE));
/*     */     
/* 167 */     registerFunction("sqrt", new StandardSQLFunction("dsqrt", Hibernate.DOUBLE));
/*     */     
/* 169 */     registerFunction("dtan", new StandardSQLFunction("dtan", Hibernate.DOUBLE));
/*     */     
/* 171 */     registerFunction("tan", new StandardSQLFunction("dtan", Hibernate.DOUBLE));
/*     */     
/* 173 */     registerFunction("dpower", new StandardSQLFunction("dpower"));
/*     */     
/* 175 */     registerFunction("power", new StandardSQLFunction("dpower"));
/*     */     
/*     */ 
/*     */ 
/* 179 */     registerFunction("date", new StandardSQLFunction("date", Hibernate.DATE));
/*     */     
/* 181 */     registerFunction("dayofweek", new StandardSQLFunction("dayofweek", Hibernate.INTEGER));
/*     */     
/* 183 */     registerFunction("dayofyear", new StandardSQLFunction("dayofyear", Hibernate.INTEGER));
/*     */     
/* 185 */     registerFunction("time", new StandardSQLFunction("time", Hibernate.TIME));
/*     */     
/* 187 */     registerFunction("timestamp", new StandardSQLFunction("timestamp", Hibernate.TIMESTAMP));
/*     */     
/* 189 */     registerFunction("week", new StandardSQLFunction("week", Hibernate.INTEGER));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 195 */     registerFunction("varchar", new StandardSQLFunction("varchar", Hibernate.STRING));
/*     */     
/* 197 */     registerFunction("real", new StandardSQLFunction("real", Hibernate.FLOAT));
/*     */     
/* 199 */     registerFunction("bigint", new StandardSQLFunction("bigint", Hibernate.LONG));
/*     */     
/* 201 */     registerFunction("char", new StandardSQLFunction("char", Hibernate.CHARACTER));
/*     */     
/* 203 */     registerFunction("integer", new StandardSQLFunction("integer", Hibernate.INTEGER));
/*     */     
/* 205 */     registerFunction("smallint", new StandardSQLFunction("smallint", Hibernate.SHORT));
/*     */     
/*     */ 
/*     */ 
/* 209 */     registerFunction("ascii_char", new StandardSQLFunction("ascii_char", Hibernate.CHARACTER));
/*     */     
/* 211 */     registerFunction("ascii_code", new StandardSQLFunction("ascii_code", Hibernate.STRING));
/*     */     
/* 213 */     registerFunction("unicode_char", new StandardSQLFunction("unicode_char", Hibernate.LONG));
/*     */     
/* 215 */     registerFunction("unicode_code", new StandardSQLFunction("unicode_code", Hibernate.STRING));
/*     */     
/* 217 */     registerFunction("upper", new StandardSQLFunction("upper"));
/*     */     
/* 219 */     registerFunction("lower", new StandardSQLFunction("lower"));
/*     */     
/* 221 */     registerFunction("char_length", new StandardSQLFunction("char_length", Hibernate.LONG));
/*     */     
/* 223 */     registerFunction("bit_length", new StandardSQLFunction("bit_length", Hibernate.STRING));
/*     */     
/*     */ 
/*     */ 
/* 227 */     getDefaultProperties().setProperty("hibernate.jdbc.use_streams_for_binary", "true");
/*     */     
/* 229 */     getDefaultProperties().setProperty("hibernate.jdbc.batch_size", "50");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAddColumnString()
/*     */   {
/* 243 */     return "add column";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean dropConstraints()
/*     */   {
/* 257 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsIdentityColumns()
/*     */   {
/* 271 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsSequences()
/*     */   {
/* 287 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSequenceNextValString(String sequenceName)
/*     */   {
/* 301 */     return "select next_value of " + sequenceName + " from system.onerow";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCreateSequenceString(String sequenceName)
/*     */   {
/* 317 */     return "create unique sequence " + sequenceName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDropSequenceString(String sequenceName)
/*     */   {
/* 331 */     return "drop sequence " + sequenceName + " restrict";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsLimit()
/*     */   {
/* 345 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCascadeConstraintsString()
/*     */   {
/* 359 */     return " cascade";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getQuerySequencesString()
/*     */   {
/* 373 */     return "select sequence_schema || '.' || sequence_name from information_schema.ext_sequences";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean forUpdateOfColumns()
/*     */   {
/* 389 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsForUpdate()
/*     */   {
/* 409 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsOuterJoinForUpdate()
/*     */   {
/* 425 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\MimerSQLDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */