/*     */ package org.hibernate.dialect;
/*     */ 
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.dialect.function.NoArgSQLFunction;
/*     */ import org.hibernate.dialect.function.StandardSQLFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IngresDialect
/*     */   extends Dialect
/*     */ {
/*     */   public IngresDialect()
/*     */   {
/*  37 */     registerColumnType(-7, "tinyint");
/*     */     
/*  39 */     registerColumnType(-6, "tinyint");
/*     */     
/*  41 */     registerColumnType(5, "smallint");
/*     */     
/*  43 */     registerColumnType(4, "integer");
/*     */     
/*  45 */     registerColumnType(-5, "bigint");
/*     */     
/*  47 */     registerColumnType(7, "real");
/*     */     
/*  49 */     registerColumnType(6, "float");
/*     */     
/*  51 */     registerColumnType(8, "float");
/*     */     
/*  53 */     registerColumnType(2, "decimal(19, $l)");
/*     */     
/*  55 */     registerColumnType(3, "decimal(19, $l)");
/*     */     
/*  57 */     registerColumnType(-2, 32000, "byte($l)");
/*     */     
/*  59 */     registerColumnType(-2, "long byte");
/*     */     
/*  61 */     registerColumnType(-3, 32000, "varbyte($l)");
/*     */     
/*  63 */     registerColumnType(-3, "long byte");
/*     */     
/*  65 */     registerColumnType(-4, "long byte");
/*     */     
/*  67 */     registerColumnType(1, "char(1)");
/*     */     
/*  69 */     registerColumnType(12, 32000, "varchar($l)");
/*     */     
/*  71 */     registerColumnType(12, "long varchar");
/*     */     
/*  73 */     registerColumnType(-1, "long varchar");
/*     */     
/*  75 */     registerColumnType(91, "date");
/*     */     
/*  77 */     registerColumnType(92, "date");
/*     */     
/*  79 */     registerColumnType(93, "date");
/*     */     
/*  81 */     registerColumnType(2004, "long byte");
/*     */     
/*  83 */     registerColumnType(2005, "long varchar");
/*     */     
/*     */ 
/*     */ 
/*  87 */     registerFunction("abs", new StandardSQLFunction("abs"));
/*     */     
/*  89 */     registerFunction("atan", new StandardSQLFunction("atan", Hibernate.DOUBLE));
/*     */     
/*  91 */     registerFunction("bit_add", new StandardSQLFunction("bit_add"));
/*     */     
/*  93 */     registerFunction("bit_and", new StandardSQLFunction("bit_and"));
/*     */     
/*  95 */     registerFunction("bit_length", new StandardSQLFunction("bit_length"));
/*     */     
/*  97 */     registerFunction("bit_not", new StandardSQLFunction("bit_not"));
/*     */     
/*  99 */     registerFunction("bit_or", new StandardSQLFunction("bit_or"));
/*     */     
/* 101 */     registerFunction("bit_xor", new StandardSQLFunction("bit_xor"));
/*     */     
/* 103 */     registerFunction("character_length", new StandardSQLFunction("character_length", Hibernate.LONG));
/*     */     
/* 105 */     registerFunction("charextract", new StandardSQLFunction("charextract", Hibernate.STRING));
/*     */     
/* 107 */     registerFunction("concat", new StandardSQLFunction("concat", Hibernate.STRING));
/*     */     
/* 109 */     registerFunction("cos", new StandardSQLFunction("cos", Hibernate.DOUBLE));
/*     */     
/* 111 */     registerFunction("current_user", new NoArgSQLFunction("current_user", Hibernate.STRING, false));
/*     */     
/* 113 */     registerFunction("date_trunc", new StandardSQLFunction("date_trunc", Hibernate.TIMESTAMP));
/*     */     
/* 115 */     registerFunction("dba", new NoArgSQLFunction("dba", Hibernate.STRING, true));
/*     */     
/* 117 */     registerFunction("dow", new StandardSQLFunction("dow", Hibernate.STRING));
/*     */     
/* 119 */     registerFunction("exp", new StandardSQLFunction("exp", Hibernate.DOUBLE));
/*     */     
/* 121 */     registerFunction("gmt_timestamp", new StandardSQLFunction("gmt_timestamp", Hibernate.STRING));
/*     */     
/* 123 */     registerFunction("hash", new StandardSQLFunction("hash", Hibernate.INTEGER));
/*     */     
/* 125 */     registerFunction("hex", new StandardSQLFunction("hex", Hibernate.STRING));
/*     */     
/* 127 */     registerFunction("initial_user", new NoArgSQLFunction("initial_user", Hibernate.STRING, false));
/*     */     
/* 129 */     registerFunction("intextract", new StandardSQLFunction("intextract", Hibernate.INTEGER));
/*     */     
/* 131 */     registerFunction("left", new StandardSQLFunction("left", Hibernate.STRING));
/*     */     
/* 133 */     registerFunction("locate", new StandardSQLFunction("locate", Hibernate.LONG));
/*     */     
/* 135 */     registerFunction("length", new StandardSQLFunction("length", Hibernate.LONG));
/*     */     
/* 137 */     registerFunction("ln", new StandardSQLFunction("ln", Hibernate.DOUBLE));
/*     */     
/* 139 */     registerFunction("log", new StandardSQLFunction("log", Hibernate.DOUBLE));
/*     */     
/* 141 */     registerFunction("lower", new StandardSQLFunction("lower"));
/*     */     
/* 143 */     registerFunction("lowercase", new StandardSQLFunction("lowercase"));
/*     */     
/* 145 */     registerFunction("octet_length", new StandardSQLFunction("octet_length", Hibernate.LONG));
/*     */     
/* 147 */     registerFunction("pad", new StandardSQLFunction("pad", Hibernate.STRING));
/*     */     
/* 149 */     registerFunction("position", new StandardSQLFunction("position", Hibernate.LONG));
/*     */     
/* 151 */     registerFunction("power", new StandardSQLFunction("power", Hibernate.DOUBLE));
/*     */     
/* 153 */     registerFunction("random", new NoArgSQLFunction("random", Hibernate.LONG, true));
/*     */     
/* 155 */     registerFunction("randomf", new NoArgSQLFunction("randomf", Hibernate.DOUBLE, true));
/*     */     
/* 157 */     registerFunction("right", new StandardSQLFunction("right", Hibernate.STRING));
/*     */     
/* 159 */     registerFunction("session_user", new NoArgSQLFunction("session_user", Hibernate.STRING, false));
/*     */     
/* 161 */     registerFunction("size", new NoArgSQLFunction("size", Hibernate.LONG, true));
/*     */     
/* 163 */     registerFunction("squeeze", new StandardSQLFunction("squeeze"));
/*     */     
/* 165 */     registerFunction("sin", new StandardSQLFunction("sin", Hibernate.DOUBLE));
/*     */     
/* 167 */     registerFunction("soundex", new StandardSQLFunction("soundex", Hibernate.STRING));
/*     */     
/* 169 */     registerFunction("sqrt", new StandardSQLFunction("sqrt", Hibernate.DOUBLE));
/*     */     
/* 171 */     registerFunction("system_user", new NoArgSQLFunction("system_user", Hibernate.STRING, false));
/*     */     
/* 173 */     registerFunction("trim", new StandardSQLFunction("trim"));
/*     */     
/* 175 */     registerFunction("unhex", new StandardSQLFunction("unhex", Hibernate.STRING));
/*     */     
/* 177 */     registerFunction("upper", new StandardSQLFunction("upper"));
/*     */     
/* 179 */     registerFunction("uppercase", new StandardSQLFunction("uppercase"));
/*     */     
/* 181 */     registerFunction("user", new NoArgSQLFunction("user", Hibernate.STRING, false));
/*     */     
/* 183 */     registerFunction("usercode", new NoArgSQLFunction("usercode", Hibernate.STRING, true));
/*     */     
/* 185 */     registerFunction("username", new NoArgSQLFunction("username", Hibernate.STRING, true));
/*     */     
/* 187 */     registerFunction("uuid_create", new StandardSQLFunction("uuid_create", Hibernate.BYTE));
/*     */     
/* 189 */     registerFunction("uuid_compare", new StandardSQLFunction("uuid_compare", Hibernate.INTEGER));
/*     */     
/* 191 */     registerFunction("uuid_from_char", new StandardSQLFunction("uuid_from_char", Hibernate.BYTE));
/*     */     
/* 193 */     registerFunction("uuid_to_char", new StandardSQLFunction("uuid_to_char", Hibernate.STRING));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean dropConstraints()
/*     */   {
/* 209 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsForUpdateOf()
/*     */   {
/* 225 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAddColumnString()
/*     */   {
/* 239 */     return "add column";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getNullColumnString()
/*     */   {
/* 255 */     return " with null";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsSequences()
/*     */   {
/* 271 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSequenceNextValString(String sequenceName)
/*     */   {
/* 291 */     return "select nextval for " + sequenceName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCreateSequenceString(String sequenceName)
/*     */   {
/* 311 */     return "create sequence " + sequenceName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDropSequenceString(String sequenceName)
/*     */   {
/* 331 */     return "drop sequence " + sequenceName + " restrict";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getQuerySequencesString()
/*     */   {
/* 345 */     return "select seq_name from iisequence";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLowercaseFunction()
/*     */   {
/* 365 */     return "lowercase";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsLimit()
/*     */   {
/* 379 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsLimitOffset()
/*     */   {
/* 393 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLimitString(String querySelect, int offset, int limit)
/*     */   {
/* 409 */     if (offset > 0)
/*     */     {
/* 411 */       throw new UnsupportedOperationException("offset not supported");
/*     */     }
/*     */     
/*     */ 
/* 415 */     return new StringBuffer(querySelect.length() + 16).append(querySelect).insert(6, " first " + limit).toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsVariableLimit()
/*     */   {
/* 429 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean useMaxForLimit()
/*     */   {
/* 445 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\IngresDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */