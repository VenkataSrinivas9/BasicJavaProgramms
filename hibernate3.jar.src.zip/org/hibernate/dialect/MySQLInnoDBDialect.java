/*    */ package org.hibernate.dialect;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MySQLInnoDBDialect
/*    */   extends MySQLDialect
/*    */ {
/*    */   public boolean supportsCascadeDelete()
/*    */   {
/* 10 */     return true;
/*    */   }
/*    */   
/*    */   public String getTableTypeString() {
/* 14 */     return " type=InnoDB";
/*    */   }
/*    */   
/*    */   public boolean hasSelfReferentialForeignKeyBug() {
/* 18 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\MySQLInnoDBDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */