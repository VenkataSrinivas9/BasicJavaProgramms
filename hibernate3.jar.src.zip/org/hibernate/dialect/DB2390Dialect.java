/*    */ package org.hibernate.dialect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DB2390Dialect
/*    */   extends DB2Dialect
/*    */ {
/*    */   public boolean supportsSequences()
/*    */   {
/* 13 */     return false;
/*    */   }
/*    */   
/*    */   public String getIdentitySelectString() {
/* 17 */     return "select identity_val_local() from sysibm.sysdummy1";
/*    */   }
/*    */   
/*    */   public boolean supportsLimit() {
/* 21 */     return true;
/*    */   }
/*    */   
/*    */   public boolean supportsLimitOffset() {
/* 25 */     return false;
/*    */   }
/*    */   
/*    */   public String getLimitString(String sql, int offset, int limit) {
/* 29 */     return sql.length() + 40 + sql + " fetch first " + limit + " rows only ";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean useMaxForLimit()
/*    */   {
/* 38 */     return true;
/*    */   }
/*    */   
/*    */   public boolean supportsVariableLimit() {
/* 42 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\DB2390Dialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */