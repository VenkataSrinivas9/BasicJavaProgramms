/*     */ package org.hibernate.dialect;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.dialect.function.NoArgSQLFunction;
/*     */ import org.hibernate.dialect.function.StandardSQLFunction;
/*     */ import org.hibernate.sql.JoinFragment;
/*     */ import org.hibernate.sql.OracleJoinFragment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimesTenDialect
/*     */   extends Dialect
/*     */ {
/*     */   public TimesTenDialect()
/*     */   {
/*  31 */     registerColumnType(-7, "TINYINT");
/*  32 */     registerColumnType(-5, "BIGINT");
/*  33 */     registerColumnType(5, "SMALLINT");
/*  34 */     registerColumnType(-6, "TINYINT");
/*  35 */     registerColumnType(4, "INTEGER");
/*  36 */     registerColumnType(1, "CHAR(1)");
/*  37 */     registerColumnType(12, "VARCHAR($l)");
/*  38 */     registerColumnType(6, "FLOAT");
/*  39 */     registerColumnType(8, "DOUBLE");
/*  40 */     registerColumnType(91, "DATE");
/*  41 */     registerColumnType(92, "TIME");
/*  42 */     registerColumnType(93, "TIMESTAMP");
/*  43 */     registerColumnType(-3, "VARBINARY($l)");
/*  44 */     registerColumnType(2, "DECIMAL($p, $s)");
/*     */     
/*     */ 
/*  47 */     registerColumnType(2004, "VARBINARY(4000000)");
/*  48 */     registerColumnType(2005, "VARCHAR(4000000)");
/*     */     
/*  50 */     getDefaultProperties().setProperty("hibernate.jdbc.use_streams_for_binary", "true");
/*  51 */     getDefaultProperties().setProperty("hibernate.jdbc.batch_size", "15");
/*  52 */     registerFunction("lower", new StandardSQLFunction("lower"));
/*  53 */     registerFunction("upper", new StandardSQLFunction("upper"));
/*  54 */     registerFunction("rtrim", new StandardSQLFunction("rtrim"));
/*  55 */     registerFunction("concat", new StandardSQLFunction("concat", Hibernate.STRING));
/*  56 */     registerFunction("mod", new StandardSQLFunction("mod"));
/*  57 */     registerFunction("to_char", new StandardSQLFunction("to_char", Hibernate.STRING));
/*  58 */     registerFunction("to_date", new StandardSQLFunction("to_date", Hibernate.TIMESTAMP));
/*  59 */     registerFunction("sysdate", new NoArgSQLFunction("sysdate", Hibernate.TIMESTAMP, false));
/*  60 */     registerFunction("getdate", new NoArgSQLFunction("getdate", Hibernate.TIMESTAMP, false));
/*  61 */     registerFunction("nvl", new StandardSQLFunction("nvl"));
/*     */   }
/*     */   
/*     */   public boolean dropConstraints()
/*     */   {
/*  66 */     return true;
/*     */   }
/*     */   
/*     */   public boolean qualifyIndexName() {
/*  70 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsUnique() {
/*  74 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsUniqueConstraintInCreateAlterTable() {
/*  78 */     return false;
/*     */   }
/*     */   
/*     */   public String getAddColumnString() {
/*  82 */     return "add";
/*     */   }
/*     */   
/*     */   public boolean supportsSequences() {
/*  86 */     return true;
/*     */   }
/*     */   
/*     */   public String getSelectSequenceNextValString(String sequenceName) {
/*  90 */     return sequenceName + ".nextval";
/*     */   }
/*     */   
/*     */   public String getSequenceNextValString(String sequenceName) {
/*  94 */     return "select first 1 " + sequenceName + ".nextval from sys.tables";
/*     */   }
/*     */   
/*     */   public String getCreateSequenceString(String sequenceName) {
/*  98 */     return "create sequence " + sequenceName;
/*     */   }
/*     */   
/*     */   public String getDropSequenceString(String sequenceName) {
/* 102 */     return "drop sequence " + sequenceName;
/*     */   }
/*     */   
/*     */   public String getQuerySequencesString() {
/* 106 */     return "select NAME from sys.sequences";
/*     */   }
/*     */   
/*     */   public JoinFragment createOuterJoinFragment() {
/* 110 */     return new OracleJoinFragment();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getForUpdateString()
/*     */   {
/* 119 */     return "";
/*     */   }
/*     */   
/*     */   public boolean supportsColumnCheck() {
/* 123 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsTableCheck() {
/* 127 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsLimitOffset() {
/* 131 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsVariableLimit() {
/* 135 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsLimit() {
/* 139 */     return true;
/*     */   }
/*     */   
/*     */   public boolean useMaxForLimit() {
/* 143 */     return true;
/*     */   }
/*     */   
/*     */   private static int getAfterSelectInsertPoint(String sql) {
/* 147 */     return 6;
/*     */   }
/*     */   
/*     */   public String getLimitString(String querySelect, int offset, int limit) {
/* 151 */     if (offset > 0) {
/* 152 */       throw new UnsupportedOperationException("TimesTen does not support offset");
/*     */     }
/* 154 */     return new StringBuffer(querySelect.length() + 8).append(querySelect).insert(getAfterSelectInsertPoint(querySelect), " first " + limit).toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean supportsCurrentTimestampSelection()
/*     */   {
/* 161 */     return true;
/*     */   }
/*     */   
/*     */   public String getCurrentTimestampSelectString() {
/* 165 */     return "select first 1 sysdate from sys.tables";
/*     */   }
/*     */   
/*     */   public boolean isCurrentTimestampSelectStringCallable() {
/* 169 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsTemporaryTables() {
/* 173 */     return true;
/*     */   }
/*     */   
/*     */   public String generateTemporaryTableName(String baseTableName) {
/* 177 */     String name = super.generateTemporaryTableName(baseTableName);
/* 178 */     return name.length() > 30 ? name.substring(1, 30) : name;
/*     */   }
/*     */   
/*     */   public String getCreateTemporaryTableString() {
/* 182 */     return "create global temporary table";
/*     */   }
/*     */   
/*     */   public String getCreateTemporaryTablePostfix() {
/* 186 */     return "on commit delete rows";
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\TimesTenDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */