/*     */ package org.hibernate.dialect;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.dialect.function.NoArgSQLFunction;
/*     */ import org.hibernate.dialect.function.StandardSQLFunction;
/*     */ import org.hibernate.dialect.function.VarArgsSQLFunction;
/*     */ import org.hibernate.sql.CaseFragment;
/*     */ import org.hibernate.sql.DecodeCaseFragment;
/*     */ import org.hibernate.sql.JoinFragment;
/*     */ import org.hibernate.sql.OracleJoinFragment;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SAPDBDialect
/*     */   extends Dialect
/*     */ {
/*     */   public SAPDBDialect()
/*     */   {
/*  26 */     registerColumnType(-7, "boolean");
/*  27 */     registerColumnType(-5, "fixed(19,0)");
/*  28 */     registerColumnType(5, "smallint");
/*  29 */     registerColumnType(-6, "fixed(3,0)");
/*  30 */     registerColumnType(4, "int");
/*  31 */     registerColumnType(1, "char(1)");
/*  32 */     registerColumnType(12, "varchar($l)");
/*  33 */     registerColumnType(6, "float");
/*  34 */     registerColumnType(8, "double precision");
/*  35 */     registerColumnType(91, "date");
/*  36 */     registerColumnType(92, "time");
/*  37 */     registerColumnType(93, "timestamp");
/*  38 */     registerColumnType(-3, "long byte");
/*  39 */     registerColumnType(2, "fixed($p,$s)");
/*  40 */     registerColumnType(2005, "long varchar");
/*  41 */     registerColumnType(2004, "long byte");
/*     */     
/*  43 */     registerFunction("abs", new StandardSQLFunction("abs"));
/*  44 */     registerFunction("sign", new StandardSQLFunction("sign", Hibernate.INTEGER));
/*     */     
/*  46 */     registerFunction("exp", new StandardSQLFunction("exp", Hibernate.DOUBLE));
/*  47 */     registerFunction("ln", new StandardSQLFunction("ln", Hibernate.DOUBLE));
/*  48 */     registerFunction("log", new StandardSQLFunction("ln", Hibernate.DOUBLE));
/*  49 */     registerFunction("pi", new NoArgSQLFunction("pi", Hibernate.DOUBLE));
/*  50 */     registerFunction("power", new StandardSQLFunction("power"));
/*  51 */     registerFunction("acos", new StandardSQLFunction("acos", Hibernate.DOUBLE));
/*  52 */     registerFunction("asin", new StandardSQLFunction("asin", Hibernate.DOUBLE));
/*  53 */     registerFunction("atan", new StandardSQLFunction("atan", Hibernate.DOUBLE));
/*  54 */     registerFunction("cos", new StandardSQLFunction("cos", Hibernate.DOUBLE));
/*  55 */     registerFunction("cosh", new StandardSQLFunction("cosh", Hibernate.DOUBLE));
/*  56 */     registerFunction("cot", new StandardSQLFunction("cos", Hibernate.DOUBLE));
/*  57 */     registerFunction("sin", new StandardSQLFunction("sin", Hibernate.DOUBLE));
/*  58 */     registerFunction("sinh", new StandardSQLFunction("sinh", Hibernate.DOUBLE));
/*  59 */     registerFunction("tan", new StandardSQLFunction("tan", Hibernate.DOUBLE));
/*  60 */     registerFunction("tanh", new StandardSQLFunction("tanh", Hibernate.DOUBLE));
/*  61 */     registerFunction("radians", new StandardSQLFunction("radians", Hibernate.DOUBLE));
/*  62 */     registerFunction("degrees", new StandardSQLFunction("degrees", Hibernate.DOUBLE));
/*  63 */     registerFunction("atan2", new StandardSQLFunction("atan2", Hibernate.DOUBLE));
/*     */     
/*  65 */     registerFunction("round", new StandardSQLFunction("round"));
/*  66 */     registerFunction("trunc", new StandardSQLFunction("trunc"));
/*  67 */     registerFunction("ceil", new StandardSQLFunction("ceil"));
/*  68 */     registerFunction("floor", new StandardSQLFunction("floor"));
/*  69 */     registerFunction("greatest", new StandardSQLFunction("greatest"));
/*  70 */     registerFunction("least", new StandardSQLFunction("least"));
/*     */     
/*  72 */     registerFunction("time", new StandardSQLFunction("time", Hibernate.TIME));
/*  73 */     registerFunction("timestamp", new StandardSQLFunction("timestamp", Hibernate.TIMESTAMP));
/*  74 */     registerFunction("date", new StandardSQLFunction("date", Hibernate.DATE));
/*  75 */     registerFunction("microsecond", new StandardSQLFunction("microsecond", Hibernate.INTEGER));
/*     */     
/*  77 */     registerFunction("dayname", new StandardSQLFunction("dayname", Hibernate.STRING));
/*  78 */     registerFunction("monthname", new StandardSQLFunction("monthname", Hibernate.STRING));
/*  79 */     registerFunction("dayofmonth", new StandardSQLFunction("dayofmonth", Hibernate.INTEGER));
/*  80 */     registerFunction("dayofweek", new StandardSQLFunction("dayofweek", Hibernate.INTEGER));
/*  81 */     registerFunction("dayofyear", new StandardSQLFunction("dayofyear", Hibernate.INTEGER));
/*  82 */     registerFunction("weekofyear", new StandardSQLFunction("weekofyear", Hibernate.INTEGER));
/*     */     
/*  84 */     registerFunction("replace", new StandardSQLFunction("replace", Hibernate.STRING));
/*  85 */     registerFunction("translate", new StandardSQLFunction("translate", Hibernate.STRING));
/*  86 */     registerFunction("lpad", new StandardSQLFunction("lpad", Hibernate.STRING));
/*  87 */     registerFunction("rpad", new StandardSQLFunction("rpad", Hibernate.STRING));
/*  88 */     registerFunction("substr", new StandardSQLFunction("substr", Hibernate.STRING));
/*  89 */     registerFunction("initcap", new StandardSQLFunction("initcap", Hibernate.STRING));
/*  90 */     registerFunction("lower", new StandardSQLFunction("lower", Hibernate.STRING));
/*  91 */     registerFunction("ltrim", new StandardSQLFunction("ltrim", Hibernate.STRING));
/*  92 */     registerFunction("rtrim", new StandardSQLFunction("rtrim", Hibernate.STRING));
/*  93 */     registerFunction("lfill", new StandardSQLFunction("ltrim", Hibernate.STRING));
/*  94 */     registerFunction("rfill", new StandardSQLFunction("rtrim", Hibernate.STRING));
/*  95 */     registerFunction("soundex", new StandardSQLFunction("soundex", Hibernate.STRING));
/*  96 */     registerFunction("upper", new StandardSQLFunction("upper", Hibernate.STRING));
/*  97 */     registerFunction("ascii", new StandardSQLFunction("ascii", Hibernate.STRING));
/*  98 */     registerFunction("index", new StandardSQLFunction("index", Hibernate.INTEGER));
/*     */     
/* 100 */     registerFunction("value", new StandardSQLFunction("value"));
/*     */     
/* 102 */     registerFunction("concat", new VarArgsSQLFunction(Hibernate.STRING, "(", "||", ")"));
/* 103 */     registerFunction("substring", new StandardSQLFunction("substr", Hibernate.STRING));
/* 104 */     registerFunction("locate", new StandardSQLFunction("index", Hibernate.INTEGER));
/* 105 */     registerFunction("coalesce", new StandardSQLFunction("value"));
/*     */     
/* 107 */     getDefaultProperties().setProperty("hibernate.jdbc.batch_size", "15");
/*     */   }
/*     */   
/*     */   public boolean dropConstraints()
/*     */   {
/* 112 */     return false;
/*     */   }
/*     */   
/*     */   public String getAddColumnString() {
/* 116 */     return "add";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAddForeignKeyConstraintString(String constraintName, String[] foreignKey, String referencedTable, String[] primaryKey, boolean referencesPrimaryKey)
/*     */   {
/* 125 */     StringBuffer res = new StringBuffer(30).append(" foreign key ").append(constraintName).append(" (").append(StringHelper.join(", ", foreignKey)).append(") references ").append(referencedTable);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 133 */     if (!referencesPrimaryKey) {
/* 134 */       res.append(" (").append(StringHelper.join(", ", primaryKey)).append(')');
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 139 */     return res.toString();
/*     */   }
/*     */   
/*     */   public String getAddPrimaryKeyConstraintString(String constraintName) {
/* 143 */     return " primary key ";
/*     */   }
/*     */   
/*     */   public String getNullColumnString() {
/* 147 */     return " null";
/*     */   }
/*     */   
/*     */   public String getSequenceNextValString(String sequenceName) {
/* 151 */     return "select " + getSelectSequenceNextValString(sequenceName) + " from dual";
/*     */   }
/*     */   
/*     */   public String getSelectSequenceNextValString(String sequenceName) {
/* 155 */     return sequenceName + ".nextval";
/*     */   }
/*     */   
/*     */   public String getCreateSequenceString(String sequenceName) {
/* 159 */     return "create sequence " + sequenceName;
/*     */   }
/*     */   
/*     */   public String getDropSequenceString(String sequenceName) {
/* 163 */     return "drop sequence " + sequenceName;
/*     */   }
/*     */   
/*     */   public String getQuerySequencesString() {
/* 167 */     return "select sequence_name from domain.sequences";
/*     */   }
/*     */   
/*     */   public JoinFragment createOuterJoinFragment() {
/* 171 */     return new OracleJoinFragment();
/*     */   }
/*     */   
/*     */   public boolean supportsSequences()
/*     */   {
/* 176 */     return true;
/*     */   }
/*     */   
/*     */   public CaseFragment createCaseFragment() {
/* 180 */     return new DecodeCaseFragment();
/*     */   }
/*     */   
/*     */   public boolean supportsTemporaryTables() {
/* 184 */     return true;
/*     */   }
/*     */   
/*     */   public String getCreateTemporaryTablePostfix() {
/* 188 */     return "ignore rollback";
/*     */   }
/*     */   
/*     */   public String generateTemporaryTableName(String baseTableName) {
/* 192 */     return "temp." + super.generateTemporaryTableName(baseTableName);
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\SAPDBDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */