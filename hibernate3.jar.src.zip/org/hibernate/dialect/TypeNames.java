/*     */ package org.hibernate.dialect;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeNames
/*     */ {
/*  46 */   private HashMap weighted = new HashMap();
/*  47 */   private HashMap defaults = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String get(int typecode)
/*     */     throws MappingException
/*     */   {
/*  55 */     String result = (String)this.defaults.get(new Integer(typecode));
/*  56 */     if (result == null) throw new MappingException("No Dialect mapping for JDBC type: " + typecode);
/*  57 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String get(int typecode, int size, int precision, int scale)
/*     */     throws MappingException
/*     */   {
/*  70 */     Map map = (Map)this.weighted.get(new Integer(typecode));
/*  71 */     if ((map != null) && (map.size() > 0))
/*     */     {
/*  73 */       Iterator entries = map.entrySet().iterator();
/*  74 */       while (entries.hasNext()) {
/*  75 */         Map.Entry entry = (Map.Entry)entries.next();
/*  76 */         if (size <= ((Integer)entry.getKey()).intValue()) {
/*  77 */           return replace((String)entry.getValue(), size, precision, scale);
/*     */         }
/*     */       }
/*     */     }
/*  81 */     return replace(get(typecode), size, precision, scale);
/*     */   }
/*     */   
/*     */   private static String replace(String type, int size, int precision, int scale) {
/*  85 */     type = StringHelper.replaceOnce(type, "$s", Integer.toString(scale));
/*  86 */     type = StringHelper.replaceOnce(type, "$l", Integer.toString(size));
/*  87 */     return StringHelper.replaceOnce(type, "$p", Integer.toString(precision));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void put(int typecode, int capacity, String value)
/*     */   {
/*  95 */     TreeMap map = (TreeMap)this.weighted.get(new Integer(typecode));
/*  96 */     if (map == null) {
/*  97 */       map = new TreeMap();
/*  98 */       this.weighted.put(new Integer(typecode), map);
/*     */     }
/* 100 */     map.put(new Integer(capacity), value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void put(int typecode, String value)
/*     */   {
/* 108 */     this.defaults.put(new Integer(typecode), value);
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\TypeNames.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */