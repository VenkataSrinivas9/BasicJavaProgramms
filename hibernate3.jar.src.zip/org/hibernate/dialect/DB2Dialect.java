/*     */ package org.hibernate.dialect;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.dialect.function.NoArgSQLFunction;
/*     */ import org.hibernate.dialect.function.SQLFunctionTemplate;
/*     */ import org.hibernate.dialect.function.StandardSQLFunction;
/*     */ import org.hibernate.dialect.function.VarArgsSQLFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DB2Dialect
/*     */   extends Dialect
/*     */ {
/*     */   public DB2Dialect()
/*     */   {
/*  24 */     registerColumnType(-7, "smallint");
/*  25 */     registerColumnType(-5, "bigint");
/*  26 */     registerColumnType(5, "smallint");
/*  27 */     registerColumnType(-6, "smallint");
/*  28 */     registerColumnType(4, "integer");
/*  29 */     registerColumnType(1, "char(1)");
/*  30 */     registerColumnType(12, "varchar($l)");
/*  31 */     registerColumnType(6, "float");
/*  32 */     registerColumnType(8, "double");
/*  33 */     registerColumnType(91, "date");
/*  34 */     registerColumnType(92, "time");
/*  35 */     registerColumnType(93, "timestamp");
/*  36 */     registerColumnType(-3, "varchar($l) for bit data");
/*  37 */     registerColumnType(2, "numeric($p,$s)");
/*  38 */     registerColumnType(2004, "blob($l)");
/*  39 */     registerColumnType(2005, "clob($l)");
/*     */     
/*  41 */     registerFunction("abs", new StandardSQLFunction("abs"));
/*  42 */     registerFunction("absval", new StandardSQLFunction("absval"));
/*  43 */     registerFunction("sign", new StandardSQLFunction("sign", Hibernate.INTEGER));
/*     */     
/*  45 */     registerFunction("ceiling", new StandardSQLFunction("ceiling"));
/*  46 */     registerFunction("ceil", new StandardSQLFunction("ceil"));
/*  47 */     registerFunction("floor", new StandardSQLFunction("floor"));
/*  48 */     registerFunction("round", new StandardSQLFunction("round"));
/*     */     
/*  50 */     registerFunction("acos", new StandardSQLFunction("acos", Hibernate.DOUBLE));
/*  51 */     registerFunction("asin", new StandardSQLFunction("asin", Hibernate.DOUBLE));
/*  52 */     registerFunction("atan", new StandardSQLFunction("atan", Hibernate.DOUBLE));
/*  53 */     registerFunction("cos", new StandardSQLFunction("cos", Hibernate.DOUBLE));
/*  54 */     registerFunction("cot", new StandardSQLFunction("cot", Hibernate.DOUBLE));
/*  55 */     registerFunction("degrees", new StandardSQLFunction("degrees", Hibernate.DOUBLE));
/*  56 */     registerFunction("exp", new StandardSQLFunction("exp", Hibernate.DOUBLE));
/*  57 */     registerFunction("float", new StandardSQLFunction("float", Hibernate.DOUBLE));
/*  58 */     registerFunction("hex", new StandardSQLFunction("hex", Hibernate.STRING));
/*  59 */     registerFunction("ln", new StandardSQLFunction("ln", Hibernate.DOUBLE));
/*  60 */     registerFunction("log", new StandardSQLFunction("log", Hibernate.DOUBLE));
/*  61 */     registerFunction("log10", new StandardSQLFunction("log10", Hibernate.DOUBLE));
/*  62 */     registerFunction("radians", new StandardSQLFunction("radians", Hibernate.DOUBLE));
/*  63 */     registerFunction("rand", new NoArgSQLFunction("rand", Hibernate.DOUBLE));
/*  64 */     registerFunction("sin", new StandardSQLFunction("sin", Hibernate.DOUBLE));
/*  65 */     registerFunction("soundex", new StandardSQLFunction("soundex", Hibernate.STRING));
/*  66 */     registerFunction("sqrt", new StandardSQLFunction("sqrt", Hibernate.DOUBLE));
/*  67 */     registerFunction("stddev", new StandardSQLFunction("stddev", Hibernate.DOUBLE));
/*  68 */     registerFunction("tan", new StandardSQLFunction("tan", Hibernate.DOUBLE));
/*  69 */     registerFunction("variance", new StandardSQLFunction("variance", Hibernate.DOUBLE));
/*     */     
/*  71 */     registerFunction("julian_day", new StandardSQLFunction("julian_day", Hibernate.INTEGER));
/*  72 */     registerFunction("microsecond", new StandardSQLFunction("microsecond", Hibernate.INTEGER));
/*  73 */     registerFunction("midnight_seconds", new StandardSQLFunction("midnight_seconds", Hibernate.INTEGER));
/*  74 */     registerFunction("minute", new StandardSQLFunction("minute", Hibernate.INTEGER));
/*  75 */     registerFunction("month", new StandardSQLFunction("month", Hibernate.INTEGER));
/*  76 */     registerFunction("monthname", new StandardSQLFunction("monthname", Hibernate.STRING));
/*  77 */     registerFunction("quarter", new StandardSQLFunction("quarter", Hibernate.INTEGER));
/*  78 */     registerFunction("hour", new StandardSQLFunction("hour", Hibernate.INTEGER));
/*  79 */     registerFunction("second", new StandardSQLFunction("second", Hibernate.INTEGER));
/*  80 */     registerFunction("current_date", new NoArgSQLFunction("current date", Hibernate.DATE, false));
/*  81 */     registerFunction("date", new StandardSQLFunction("date", Hibernate.DATE));
/*  82 */     registerFunction("day", new StandardSQLFunction("day", Hibernate.INTEGER));
/*  83 */     registerFunction("dayname", new StandardSQLFunction("dayname", Hibernate.STRING));
/*  84 */     registerFunction("dayofweek", new StandardSQLFunction("dayofweek", Hibernate.INTEGER));
/*  85 */     registerFunction("dayofweek_iso", new StandardSQLFunction("dayofweek_iso", Hibernate.INTEGER));
/*  86 */     registerFunction("dayofyear", new StandardSQLFunction("dayofyear", Hibernate.INTEGER));
/*  87 */     registerFunction("days", new StandardSQLFunction("days", Hibernate.LONG));
/*  88 */     registerFunction("current_time", new NoArgSQLFunction("current time", Hibernate.TIME, false));
/*  89 */     registerFunction("time", new StandardSQLFunction("time", Hibernate.TIME));
/*  90 */     registerFunction("current_timestamp", new NoArgSQLFunction("current timestamp", Hibernate.TIMESTAMP, false));
/*  91 */     registerFunction("timestamp", new StandardSQLFunction("timestamp", Hibernate.TIMESTAMP));
/*  92 */     registerFunction("timestamp_iso", new StandardSQLFunction("timestamp_iso", Hibernate.TIMESTAMP));
/*  93 */     registerFunction("week", new StandardSQLFunction("week", Hibernate.INTEGER));
/*  94 */     registerFunction("week_iso", new StandardSQLFunction("week_iso", Hibernate.INTEGER));
/*  95 */     registerFunction("year", new StandardSQLFunction("year", Hibernate.INTEGER));
/*     */     
/*  97 */     registerFunction("double", new StandardSQLFunction("double", Hibernate.DOUBLE));
/*  98 */     registerFunction("varchar", new StandardSQLFunction("varchar", Hibernate.STRING));
/*  99 */     registerFunction("real", new StandardSQLFunction("real", Hibernate.FLOAT));
/* 100 */     registerFunction("bigint", new StandardSQLFunction("bigint", Hibernate.LONG));
/* 101 */     registerFunction("char", new StandardSQLFunction("char", Hibernate.CHARACTER));
/* 102 */     registerFunction("integer", new StandardSQLFunction("integer", Hibernate.INTEGER));
/* 103 */     registerFunction("smallint", new StandardSQLFunction("smallint", Hibernate.SHORT));
/*     */     
/* 105 */     registerFunction("digits", new StandardSQLFunction("digits", Hibernate.STRING));
/* 106 */     registerFunction("chr", new StandardSQLFunction("chr", Hibernate.CHARACTER));
/* 107 */     registerFunction("upper", new StandardSQLFunction("upper"));
/* 108 */     registerFunction("lower", new StandardSQLFunction("lower"));
/* 109 */     registerFunction("ucase", new StandardSQLFunction("ucase"));
/* 110 */     registerFunction("lcase", new StandardSQLFunction("lcase"));
/* 111 */     registerFunction("length", new StandardSQLFunction("length", Hibernate.LONG));
/* 112 */     registerFunction("ltrim", new StandardSQLFunction("ltrim"));
/* 113 */     registerFunction("rtrim", new StandardSQLFunction("rtrim"));
/* 114 */     registerFunction("substr", new StandardSQLFunction("substr", Hibernate.STRING));
/* 115 */     registerFunction("posstr", new StandardSQLFunction("posstr", Hibernate.INTEGER));
/*     */     
/* 117 */     registerFunction("substring", new StandardSQLFunction("substr", Hibernate.STRING));
/* 118 */     registerFunction("trim", new SQLFunctionTemplate(Hibernate.INTEGER, "ltrim(rtrim(?1))"));
/* 119 */     registerFunction("bit_length", new SQLFunctionTemplate(Hibernate.INTEGER, "length(?1)*8"));
/*     */     
/* 121 */     registerFunction("concat", new VarArgsSQLFunction(Hibernate.STRING, "", "||", ""));
/*     */     
/* 123 */     registerFunction("str", new SQLFunctionTemplate(Hibernate.STRING, "rtrim(char(?1))"));
/*     */     
/* 125 */     registerKeyword("current");
/* 126 */     registerKeyword("date");
/* 127 */     registerKeyword("time");
/* 128 */     registerKeyword("timestamp");
/* 129 */     registerKeyword("fetch");
/* 130 */     registerKeyword("first");
/* 131 */     registerKeyword("rows");
/* 132 */     registerKeyword("only");
/*     */     
/* 134 */     getDefaultProperties().setProperty("hibernate.jdbc.batch_size", "0");
/*     */   }
/*     */   
/*     */   public String getLowercaseFunction() {
/* 138 */     return "lcase";
/*     */   }
/*     */   
/*     */   public String getAddColumnString() {
/* 142 */     return "add column";
/*     */   }
/*     */   
/* 145 */   public boolean dropConstraints() { return false; }
/*     */   
/*     */   public boolean supportsIdentityColumns() {
/* 148 */     return true;
/*     */   }
/*     */   
/* 151 */   public String getIdentitySelectString() { return "values identity_val_local()"; }
/*     */   
/*     */   public String getIdentityColumnString() {
/* 154 */     return "generated by default as identity";
/*     */   }
/*     */   
/* 157 */   public String getIdentityInsertString() { return "default"; }
/*     */   
/*     */   public String getSequenceNextValString(String sequenceName)
/*     */   {
/* 161 */     return "values nextval for " + sequenceName;
/*     */   }
/*     */   
/* 164 */   public String getCreateSequenceString(String sequenceName) { return "create sequence " + sequenceName; }
/*     */   
/*     */   public String getDropSequenceString(String sequenceName) {
/* 167 */     return "drop sequence " + sequenceName + " restrict";
/*     */   }
/*     */   
/*     */   public boolean supportsSequences() {
/* 171 */     return true;
/*     */   }
/*     */   
/*     */   public String getQuerySequencesString() {
/* 175 */     return "select seqname from sysibm.syssequences";
/*     */   }
/*     */   
/*     */   public boolean supportsLimit() {
/* 179 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getRowNumber(String sql)
/*     */   {
/* 207 */     StringBuffer rownumber = new StringBuffer(50).append("rownumber() over(");
/*     */     
/*     */ 
/* 210 */     int orderByIndex = sql.toLowerCase().indexOf("order by");
/*     */     
/* 212 */     if ((orderByIndex > 0) && (!hasDistinct(sql))) {
/* 213 */       rownumber.append(sql.substring(orderByIndex));
/*     */     }
/*     */     
/* 216 */     rownumber.append(") as rownumber_,");
/*     */     
/* 218 */     return rownumber.toString();
/*     */   }
/*     */   
/*     */   public String getLimitString(String sql, boolean hasOffset)
/*     */   {
/* 223 */     int startOfSelect = sql.toLowerCase().indexOf("select");
/*     */     
/* 225 */     StringBuffer pagingSelect = new StringBuffer(sql.length() + 100).append(sql.substring(0, startOfSelect)).append("select * from ( select ").append(getRowNumber(sql));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 230 */     if (hasDistinct(sql)) {
/* 231 */       pagingSelect.append(" row_.* from ( ").append(sql.substring(startOfSelect)).append(" ) as row_");
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 236 */       pagingSelect.append(sql.substring(startOfSelect + 6));
/*     */     }
/*     */     
/* 239 */     pagingSelect.append(" ) as temp_ where rownumber_ ");
/*     */     
/*     */ 
/* 242 */     if (hasOffset) {
/* 243 */       pagingSelect.append("between ?+1 and ?");
/*     */     }
/*     */     else {
/* 246 */       pagingSelect.append("<= ?");
/*     */     }
/*     */     
/* 249 */     return pagingSelect.toString();
/*     */   }
/*     */   
/*     */   private static boolean hasDistinct(String sql) {
/* 253 */     return sql.toLowerCase().indexOf("select distinct") >= 0;
/*     */   }
/*     */   
/*     */   public String getForUpdateString() {
/* 257 */     return " for read only with rs";
/*     */   }
/*     */   
/*     */   public boolean useMaxForLimit() {
/* 261 */     return true;
/*     */   }
/*     */   
/*     */   public boolean supportsOuterJoinForUpdate() {
/* 265 */     return false;
/*     */   }
/*     */   
/*     */ 
/* 269 */   public boolean supportsNotNullUnique() { return false; }
/*     */   
/*     */   public String getSelectClauseNullString(int sqlType) { String literal;
/*     */     String literal;
/*     */     String literal;
/* 274 */     String literal; String literal; switch (sqlType) {
/*     */     case 1: 
/*     */     case 12: 
/* 277 */       literal = "'x'";
/* 278 */       break;
/*     */     case 91: 
/* 280 */       literal = "'2000-1-1'";
/* 281 */       break;
/*     */     case 93: 
/* 283 */       literal = "'2000-1-1 00:00:00'";
/* 284 */       break;
/*     */     case 92: 
/* 286 */       literal = "'00:00:00'";
/* 287 */       break;
/*     */     default: 
/* 289 */       literal = "0";
/*     */     }
/* 291 */     return "nullif(" + literal + ',' + literal + ')';
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 295 */     System.out.println(new DB2Dialect().getLimitString("/*foo*/ select * from foos", true));
/* 296 */     System.out.println(new DB2Dialect().getLimitString("/*foo*/ select distinct * from foos", true));
/* 297 */     System.out.println(new DB2Dialect().getLimitString("/*foo*/ select * from foos foo order by foo.bar, foo.baz", true));
/* 298 */     System.out.println(new DB2Dialect().getLimitString("/*foo*/ select distinct * from foos foo order by foo.bar, foo.baz", true));
/*     */   }
/*     */   
/*     */   public boolean supportsUnionAll() {
/* 302 */     return true;
/*     */   }
/*     */   
/*     */   public int registerResultSetOutParameter(CallableStatement statement, int col) throws SQLException {
/* 306 */     return col;
/*     */   }
/*     */   
/*     */   public ResultSet getResultSet(CallableStatement ps) throws SQLException {
/* 310 */     boolean isResultSet = ps.execute();
/*     */     
/* 312 */     while ((!isResultSet) && (ps.getUpdateCount() != -1)) {
/* 313 */       isResultSet = ps.getMoreResults();
/*     */     }
/* 315 */     ResultSet rs = ps.getResultSet();
/*     */     
/*     */ 
/* 318 */     return rs;
/*     */   }
/*     */   
/*     */   public boolean supportsCommentOn() {
/* 322 */     return true;
/*     */   }
/*     */   
/*     */   public boolean supportsTemporaryTables() {
/* 326 */     return true;
/*     */   }
/*     */   
/*     */   public String getCreateTemporaryTableString() {
/* 330 */     return "declare global temporary table";
/*     */   }
/*     */   
/*     */   public String getCreateTemporaryTablePostfix() {
/* 334 */     return "not logged";
/*     */   }
/*     */   
/*     */   public String generateTemporaryTableName(String baseTableName) {
/* 338 */     return "session." + super.generateTemporaryTableName(baseTableName);
/*     */   }
/*     */   
/*     */   public boolean supportsCurrentTimestampSelection() {
/* 342 */     return true;
/*     */   }
/*     */   
/*     */   public String getCurrentTimestampSelectString() {
/* 346 */     return "values current timestamp";
/*     */   }
/*     */   
/*     */   public boolean isCurrentTimestampSelectStringCallable() {
/* 350 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean supportsParametersInInsertSelect()
/*     */   {
/* 356 */     return false;
/*     */   }
/*     */   
/*     */   public String getCurrentTimestampSQLFunctionName() {
/* 360 */     return "sysdate";
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\DB2Dialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */