/*    */ package org.hibernate.dialect;
/*    */ 
/*    */ import org.hibernate.sql.CaseFragment;
/*    */ import org.hibernate.sql.DecodeCaseFragment;
/*    */ import org.hibernate.sql.JoinFragment;
/*    */ import org.hibernate.sql.OracleJoinFragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OracleDialect
/*    */   extends Oracle9Dialect
/*    */ {
/*    */   public OracleDialect()
/*    */   {
/* 21 */     registerColumnType(93, "date");
/* 22 */     registerColumnType(1, "char(1)");
/* 23 */     registerColumnType(12, 4000, "varchar2($l)");
/*    */   }
/*    */   
/*    */   public JoinFragment createOuterJoinFragment() {
/* 27 */     return new OracleJoinFragment();
/*    */   }
/*    */   
/* 30 */   public CaseFragment createCaseFragment() { return new DecodeCaseFragment(); }
/*    */   
/*    */ 
/*    */   public String getLimitString(String sql, boolean hasOffset)
/*    */   {
/* 35 */     sql = sql.trim();
/* 36 */     boolean isForUpdate = false;
/* 37 */     if (sql.toLowerCase().endsWith(" for update")) {
/* 38 */       sql = sql.substring(0, sql.length() - 11);
/* 39 */       isForUpdate = true;
/*    */     }
/*    */     
/* 42 */     StringBuffer pagingSelect = new StringBuffer(sql.length() + 100);
/* 43 */     if (hasOffset) {
/* 44 */       pagingSelect.append("select * from ( select row_.*, rownum rownum_ from ( ");
/*    */     }
/*    */     else {
/* 47 */       pagingSelect.append("select * from ( ");
/*    */     }
/* 49 */     pagingSelect.append(sql);
/* 50 */     if (hasOffset) {
/* 51 */       pagingSelect.append(" ) row_ ) where rownum_ <= ? and rownum_ > ?");
/*    */     }
/*    */     else {
/* 54 */       pagingSelect.append(" ) where rownum <= ?");
/*    */     }
/*    */     
/* 57 */     if (isForUpdate) {
/* 58 */       pagingSelect.append(" for update");
/*    */     }
/*    */     
/* 61 */     return pagingSelect.toString();
/*    */   }
/*    */   
/*    */   public String getSelectClauseNullString(int sqlType) {
/* 65 */     switch (sqlType) {
/*    */     case 1: 
/*    */     case 12: 
/* 68 */       return "to_char(null)";
/*    */     case 91: 
/*    */     case 92: 
/*    */     case 93: 
/* 72 */       return "to_date(null)";
/*    */     }
/* 74 */     return "to_number(null)";
/*    */   }
/*    */   
/*    */   public String getCurrentTimestampSelectString()
/*    */   {
/* 79 */     return "select sysdate from dual";
/*    */   }
/*    */   
/*    */   public String getCurrentTimestampSQLFunctionName() {
/* 83 */     return "sysdate";
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\OracleDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */