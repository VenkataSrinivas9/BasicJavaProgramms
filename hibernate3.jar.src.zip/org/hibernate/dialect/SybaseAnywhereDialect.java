/*    */ package org.hibernate.dialect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SybaseAnywhereDialect
/*    */   extends SybaseDialect
/*    */ {
/*    */   public String getNoColumnsInsertString()
/*    */   {
/* 16 */     return "values (default)";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean dropConstraints()
/*    */   {
/* 25 */     return false;
/*    */   }
/*    */   
/*    */   public boolean supportsInsertSelectIdentity() {
/* 29 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\SybaseAnywhereDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */