/*     */ package org.hibernate.dialect;
/*     */ 
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.LockMode;
/*     */ import org.hibernate.dialect.function.CharIndexFunction;
/*     */ import org.hibernate.dialect.function.NoArgSQLFunction;
/*     */ import org.hibernate.dialect.function.SQLFunctionTemplate;
/*     */ import org.hibernate.dialect.function.StandardSQLFunction;
/*     */ import org.hibernate.dialect.function.VarArgsSQLFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SybaseDialect
/*     */   extends Dialect
/*     */ {
/*     */   public SybaseDialect()
/*     */   {
/*  26 */     registerColumnType(-7, "tinyint");
/*  27 */     registerColumnType(-5, "numeric(19,0)");
/*  28 */     registerColumnType(5, "smallint");
/*  29 */     registerColumnType(-6, "tinyint");
/*  30 */     registerColumnType(4, "int");
/*  31 */     registerColumnType(1, "char(1)");
/*  32 */     registerColumnType(12, "varchar($l)");
/*  33 */     registerColumnType(6, "float");
/*  34 */     registerColumnType(8, "double precision");
/*  35 */     registerColumnType(91, "datetime");
/*  36 */     registerColumnType(92, "datetime");
/*  37 */     registerColumnType(93, "datetime");
/*  38 */     registerColumnType(-3, "varbinary($l)");
/*  39 */     registerColumnType(2, "numeric($p,$s)");
/*  40 */     registerColumnType(2004, "image");
/*  41 */     registerColumnType(2005, "text");
/*     */     
/*  43 */     registerFunction("ascii", new StandardSQLFunction("ascii", Hibernate.INTEGER));
/*  44 */     registerFunction("char", new StandardSQLFunction("char", Hibernate.CHARACTER));
/*  45 */     registerFunction("len", new StandardSQLFunction("len", Hibernate.LONG));
/*  46 */     registerFunction("lower", new StandardSQLFunction("lower"));
/*  47 */     registerFunction("upper", new StandardSQLFunction("upper"));
/*  48 */     registerFunction("str", new StandardSQLFunction("str", Hibernate.STRING));
/*  49 */     registerFunction("ltrim", new StandardSQLFunction("ltrim"));
/*  50 */     registerFunction("rtrim", new StandardSQLFunction("rtrim"));
/*  51 */     registerFunction("reverse", new StandardSQLFunction("reverse"));
/*  52 */     registerFunction("space", new StandardSQLFunction("space", Hibernate.STRING));
/*     */     
/*  54 */     registerFunction("user", new NoArgSQLFunction("user", Hibernate.STRING));
/*     */     
/*  56 */     registerFunction("current_timestamp", new NoArgSQLFunction("getdate", Hibernate.TIMESTAMP));
/*  57 */     registerFunction("current_time", new NoArgSQLFunction("getdate", Hibernate.TIME));
/*  58 */     registerFunction("current_date", new NoArgSQLFunction("getdate", Hibernate.DATE));
/*     */     
/*  60 */     registerFunction("getdate", new NoArgSQLFunction("getdate", Hibernate.TIMESTAMP));
/*  61 */     registerFunction("getutcdate", new NoArgSQLFunction("getutcdate", Hibernate.TIMESTAMP));
/*  62 */     registerFunction("day", new StandardSQLFunction("day", Hibernate.INTEGER));
/*  63 */     registerFunction("month", new StandardSQLFunction("month", Hibernate.INTEGER));
/*  64 */     registerFunction("year", new StandardSQLFunction("year", Hibernate.INTEGER));
/*  65 */     registerFunction("datename", new StandardSQLFunction("datename", Hibernate.STRING));
/*     */     
/*  67 */     registerFunction("abs", new StandardSQLFunction("abs"));
/*  68 */     registerFunction("sign", new StandardSQLFunction("sign", Hibernate.INTEGER));
/*     */     
/*  70 */     registerFunction("acos", new StandardSQLFunction("acos", Hibernate.DOUBLE));
/*  71 */     registerFunction("asin", new StandardSQLFunction("asin", Hibernate.DOUBLE));
/*  72 */     registerFunction("atan", new StandardSQLFunction("atan", Hibernate.DOUBLE));
/*  73 */     registerFunction("cos", new StandardSQLFunction("cos", Hibernate.DOUBLE));
/*  74 */     registerFunction("cot", new StandardSQLFunction("cot", Hibernate.DOUBLE));
/*  75 */     registerFunction("exp", new StandardSQLFunction("exp", Hibernate.DOUBLE));
/*  76 */     registerFunction("log", new StandardSQLFunction("log", Hibernate.DOUBLE));
/*  77 */     registerFunction("log10", new StandardSQLFunction("log10", Hibernate.DOUBLE));
/*  78 */     registerFunction("sin", new StandardSQLFunction("sin", Hibernate.DOUBLE));
/*  79 */     registerFunction("sqrt", new StandardSQLFunction("sqrt", Hibernate.DOUBLE));
/*  80 */     registerFunction("tan", new StandardSQLFunction("tan", Hibernate.DOUBLE));
/*  81 */     registerFunction("pi", new NoArgSQLFunction("pi", Hibernate.DOUBLE));
/*  82 */     registerFunction("square", new StandardSQLFunction("square"));
/*  83 */     registerFunction("rand", new StandardSQLFunction("rand", Hibernate.FLOAT));
/*     */     
/*  85 */     registerFunction("radians", new StandardSQLFunction("radians", Hibernate.DOUBLE));
/*  86 */     registerFunction("degrees", new StandardSQLFunction("degrees", Hibernate.DOUBLE));
/*     */     
/*  88 */     registerFunction("round", new StandardSQLFunction("round"));
/*  89 */     registerFunction("ceiling", new StandardSQLFunction("ceiling"));
/*  90 */     registerFunction("floor", new StandardSQLFunction("floor"));
/*     */     
/*  92 */     registerFunction("isnull", new StandardSQLFunction("isnull"));
/*     */     
/*  94 */     registerFunction("concat", new VarArgsSQLFunction(Hibernate.STRING, "(", "+", ")"));
/*     */     
/*  96 */     registerFunction("length", new StandardSQLFunction("len", Hibernate.INTEGER));
/*  97 */     registerFunction("trim", new SQLFunctionTemplate(Hibernate.STRING, "ltrim(rtrim(?1))"));
/*  98 */     registerFunction("locate", new CharIndexFunction());
/*     */     
/* 100 */     getDefaultProperties().setProperty("hibernate.jdbc.batch_size", "0");
/*     */   }
/*     */   
/*     */   public String getAddColumnString() {
/* 104 */     return "add";
/*     */   }
/*     */   
/* 107 */   public String getNullColumnString() { return " null"; }
/*     */   
/*     */   public boolean qualifyIndexName() {
/* 110 */     return false;
/*     */   }
/*     */   
/*     */   public String getForUpdateString() {
/* 114 */     return "";
/*     */   }
/*     */   
/*     */   public boolean supportsIdentityColumns() {
/* 118 */     return true;
/*     */   }
/*     */   
/* 121 */   public String getIdentitySelectString() { return "select @@identity"; }
/*     */   
/*     */   public String getIdentityColumnString() {
/* 124 */     return "identity not null";
/*     */   }
/*     */   
/*     */   public boolean supportsInsertSelectIdentity() {
/* 128 */     return true;
/*     */   }
/*     */   
/*     */   public String appendIdentitySelectToInsert(String insertSQL) {
/* 132 */     return insertSQL + "\nselect @@identity";
/*     */   }
/*     */   
/*     */   public String appendLockHint(LockMode mode, String tableName) {
/* 136 */     if (mode.greaterThan(LockMode.READ)) {
/* 137 */       return tableName + " holdlock";
/*     */     }
/*     */     
/* 140 */     return tableName;
/*     */   }
/*     */   
/*     */   public int registerResultSetOutParameter(CallableStatement statement, int col) throws SQLException
/*     */   {
/* 145 */     return col;
/*     */   }
/*     */   
/*     */   public ResultSet getResultSet(CallableStatement ps) throws SQLException {
/* 149 */     boolean isResultSet = ps.execute();
/*     */     
/* 151 */     while ((!isResultSet) && (ps.getUpdateCount() != -1)) {
/* 152 */       isResultSet = ps.getMoreResults();
/*     */     }
/* 154 */     ResultSet rs = ps.getResultSet();
/*     */     
/*     */ 
/* 157 */     return rs;
/*     */   }
/*     */   
/*     */   public boolean supportsCurrentTimestampSelection() {
/* 161 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isCurrentTimestampSelectStringCallable() {
/* 165 */     return false;
/*     */   }
/*     */   
/*     */   public String getCurrentTimestampSelectString() {
/* 169 */     return "select getdate()";
/*     */   }
/*     */   
/*     */   public boolean supportsTemporaryTables() {
/* 173 */     return true;
/*     */   }
/*     */   
/*     */   public String generateTemporaryTableName(String baseTableName) {
/* 177 */     return "#" + baseTableName;
/*     */   }
/*     */   
/*     */   public boolean dropTemporaryTableAfterUse() {
/* 181 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\SybaseDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */