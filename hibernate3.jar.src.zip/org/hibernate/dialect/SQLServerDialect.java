/*     */ package org.hibernate.dialect;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.LockMode;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.dialect.function.SQLFunction;
/*     */ import org.hibernate.dialect.function.SQLFunctionTemplate;
/*     */ import org.hibernate.dialect.function.StandardSQLFunction;
/*     */ import org.hibernate.engine.Mapping;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLServerDialect
/*     */   extends SybaseDialect
/*     */ {
/*     */   public SQLServerDialect()
/*     */   {
/*  25 */     registerColumnType(-3, "image");
/*  26 */     registerColumnType(-3, 8000, "varbinary($l)");
/*     */     
/*  28 */     registerFunction("second", new SQLFunctionTemplate(Hibernate.INTEGER, "datepart(second, ?1)"));
/*  29 */     registerFunction("minute", new SQLFunctionTemplate(Hibernate.INTEGER, "datepart(minute, ?1)"));
/*  30 */     registerFunction("hour", new SQLFunctionTemplate(Hibernate.INTEGER, "datepart(hour, ?1)"));
/*  31 */     registerFunction("locate", new StandardSQLFunction("charindex", Hibernate.INTEGER));
/*     */     
/*  33 */     registerFunction("extract", new SQLFunctionTemplate(Hibernate.INTEGER, "datepart(?1, ?3)"));
/*  34 */     registerFunction("trim", new TrimFunction());
/*  35 */     registerFunction("mod", new SQLFunctionTemplate(Hibernate.INTEGER, "?1 % ?2"));
/*  36 */     registerFunction("bit_length", new SQLFunctionTemplate(Hibernate.INTEGER, "datalength(?1) * 8"));
/*     */     
/*  38 */     registerKeyword("top");
/*     */   }
/*     */   
/*     */   public String getNoColumnsInsertString() {
/*  42 */     return "default values";
/*     */   }
/*     */   
/*     */   static int getAfterSelectInsertPoint(String sql) {
/*  46 */     int selectIndex = sql.toLowerCase().indexOf("select");
/*  47 */     int selectDistinctIndex = sql.toLowerCase().indexOf("select distinct");
/*  48 */     return selectIndex + (selectDistinctIndex == selectIndex ? 15 : 6);
/*     */   }
/*     */   
/*     */   public String getLimitString(String querySelect, int offset, int limit) {
/*  52 */     if (offset > 0) {
/*  53 */       throw new UnsupportedOperationException("sql server has no offset");
/*     */     }
/*  55 */     return new StringBuffer(querySelect.length() + 8).append(querySelect).insert(getAfterSelectInsertPoint(querySelect), " top " + limit).toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String appendIdentitySelectToInsert(String insertSQL)
/*     */   {
/*  65 */     return insertSQL + " select scope_identity()";
/*     */   }
/*     */   
/*     */   public boolean supportsLimit() {
/*  69 */     return true;
/*     */   }
/*     */   
/*     */   public boolean useMaxForLimit() {
/*  73 */     return true;
/*     */   }
/*     */   
/*     */   public boolean supportsLimitOffset() {
/*  77 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsVariableLimit() {
/*  81 */     return false;
/*     */   }
/*     */   
/*     */   public char closeQuote() {
/*  85 */     return ']';
/*     */   }
/*     */   
/*     */   public char openQuote() {
/*  89 */     return '[';
/*     */   }
/*     */   
/*     */   public String appendLockHint(LockMode mode, String tableName) {
/*  93 */     if (mode.greaterThan(LockMode.READ)) {
/*  94 */       return tableName + " with (updlock, rowlock)";
/*     */     }
/*     */     
/*  97 */     return tableName;
/*     */   }
/*     */   
/*     */   public String getSelectGUIDString()
/*     */   {
/* 102 */     return "select newid()";
/*     */   }
/*     */   
/*     */ 
/*     */   public String getCurrentTimestampSelectString()
/*     */   {
/* 108 */     return "select current_timestamp";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class TrimFunction
/*     */     implements SQLFunction
/*     */   {
/* 116 */     private static final SQLFunction LEADING_SPACE_TRIM = new SQLFunctionTemplate(Hibernate.STRING, "ltrim( ?1 )");
/* 117 */     private static final SQLFunction TRAILING_SPACE_TRIM = new SQLFunctionTemplate(Hibernate.STRING, "rtrim( ?1 )");
/* 118 */     private static final SQLFunction BOTH_SPACE_TRIM = new SQLFunctionTemplate(Hibernate.STRING, "ltrim( rtrim( ?1 ) )");
/* 119 */     private static final SQLFunction BOTH_SPACE_TRIM_FROM = new SQLFunctionTemplate(Hibernate.STRING, "ltrim( rtrim( ?2 ) )");
/*     */     
/* 121 */     private static final SQLFunction LEADING_TRIM = new SQLFunctionTemplate(Hibernate.STRING, "replace( replace( rtrim( replace( replace( ?1, ' ', '${space}$' ), ?2, ' ' ) ), ' ', ?2 ), '${space}$', ' ' )");
/* 122 */     private static final SQLFunction TRAILING_TRIM = new SQLFunctionTemplate(Hibernate.STRING, "replace( replace( ltrim( replace( replace( ?1, ' ', '${space}$' ), ?2, ' ' ) ), ' ', ?2 ), '${space}$', ' ' )");
/* 123 */     private static final SQLFunction BOTH_TRIM = new SQLFunctionTemplate(Hibernate.STRING, "replace( replace( ltrim( rtrim( replace( replace( ?1, ' ', '${space}$' ), ?2, ' ' ) ) ), ' ', ?2 ), '${space}$', ' ' )");
/*     */     
/*     */     public Type getReturnType(Type columnType, Mapping mapping) throws QueryException {
/* 126 */       return Hibernate.STRING;
/*     */     }
/*     */     
/*     */     public boolean hasArguments() {
/* 130 */       return true;
/*     */     }
/*     */     
/*     */     public boolean hasParenthesesIfNoArguments() {
/* 134 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String render(List args, SessionFactoryImplementor factory)
/*     */       throws QueryException
/*     */     {
/* 155 */       if (args.size() == 1)
/*     */       {
/*     */ 
/* 158 */         return BOTH_SPACE_TRIM.render(args, factory);
/*     */       }
/* 160 */       if ("from".equalsIgnoreCase((String)args.get(0)))
/*     */       {
/*     */ 
/* 163 */         return BOTH_SPACE_TRIM_FROM.render(args, factory);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 169 */       boolean leading = true;
/* 170 */       boolean trailing = true;
/* 171 */       String trimCharacter = null;
/* 172 */       String trimSource = null;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 177 */       int potentialTrimCharacterArgIndex = 1;
/* 178 */       String firstArg = (String)args.get(0);
/* 179 */       if ("leading".equalsIgnoreCase(firstArg)) {
/* 180 */         trailing = false;
/*     */       }
/* 182 */       else if ("trailing".equalsIgnoreCase(firstArg)) {
/* 183 */         leading = false;
/*     */       }
/* 185 */       else if (!"both".equalsIgnoreCase(firstArg))
/*     */       {
/*     */ 
/* 188 */         potentialTrimCharacterArgIndex = 0;
/*     */       }
/*     */       
/* 191 */       String potentialTrimCharacter = (String)args.get(potentialTrimCharacterArgIndex);
/* 192 */       if ("from".equalsIgnoreCase(potentialTrimCharacter)) {
/* 193 */         trimCharacter = "' '";
/* 194 */         trimSource = (String)args.get(potentialTrimCharacterArgIndex + 1);
/*     */       }
/* 196 */       else if (potentialTrimCharacterArgIndex + 1 >= args.size()) {
/* 197 */         trimCharacter = "' '";
/* 198 */         trimSource = potentialTrimCharacter;
/*     */       }
/*     */       else {
/* 201 */         trimCharacter = potentialTrimCharacter;
/* 202 */         if ("from".equalsIgnoreCase((String)args.get(potentialTrimCharacterArgIndex + 1))) {
/* 203 */           trimSource = (String)args.get(potentialTrimCharacterArgIndex + 2);
/*     */         }
/*     */         else {
/* 206 */           trimSource = (String)args.get(potentialTrimCharacterArgIndex + 1);
/*     */         }
/*     */       }
/*     */       
/* 210 */       List argsToUse = null;
/* 211 */       argsToUse = new ArrayList();
/* 212 */       argsToUse.add(trimSource);
/* 213 */       argsToUse.add(trimCharacter);
/*     */       
/* 215 */       if (trimCharacter.equals("' '")) {
/* 216 */         if ((leading) && (trailing)) {
/* 217 */           return BOTH_SPACE_TRIM.render(argsToUse, factory);
/*     */         }
/* 219 */         if (leading) {
/* 220 */           return LEADING_SPACE_TRIM.render(argsToUse, factory);
/*     */         }
/*     */         
/* 223 */         return TRAILING_SPACE_TRIM.render(argsToUse, factory);
/*     */       }
/*     */       
/*     */ 
/* 227 */       if ((leading) && (trailing)) {
/* 228 */         return BOTH_TRIM.render(argsToUse, factory);
/*     */       }
/* 230 */       if (leading) {
/* 231 */         return LEADING_TRIM.render(argsToUse, factory);
/*     */       }
/*     */       
/* 234 */       return TRAILING_TRIM.render(argsToUse, factory);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\SQLServerDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */