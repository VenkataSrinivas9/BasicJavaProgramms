/*     */ package org.hibernate.dialect;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.util.ReflectHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DialectFactory
/*     */ {
/*     */   public static Dialect buildDialect(Properties props, String databaseName, int databaseMajorVersion)
/*     */     throws HibernateException
/*     */   {
/*  37 */     String dialectName = props.getProperty("hibernate.dialect");
/*  38 */     if (dialectName == null) {
/*  39 */       return determineDialect(databaseName, databaseMajorVersion);
/*     */     }
/*     */     
/*  42 */     return buildDialect(dialectName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Dialect determineDialect(String databaseName, int databaseMajorVersion)
/*     */   {
/*  56 */     if (databaseName == null) {
/*  57 */       throw new HibernateException("Hibernate Dialect must be explicitly set");
/*     */     }
/*     */     
/*  60 */     DatabaseDialectMapper mapper = (DatabaseDialectMapper)MAPPERS.get(databaseName);
/*  61 */     if (mapper == null) {
/*  62 */       throw new HibernateException("Hibernate Dialect must be explicitly set for database: " + databaseName);
/*     */     }
/*     */     
/*  65 */     String dialectName = mapper.getDialectClass(databaseMajorVersion);
/*  66 */     return buildDialect(dialectName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Dialect buildDialect(String dialectName)
/*     */   {
/*     */     try
/*     */     {
/*  78 */       return (Dialect)ReflectHelper.classForName(dialectName).newInstance();
/*     */     }
/*     */     catch (ClassNotFoundException cnfe) {
/*  81 */       throw new HibernateException("Dialect class not found: " + dialectName);
/*     */     }
/*     */     catch (Exception e) {
/*  84 */       throw new HibernateException("Could not instantiate dialect class", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class VersionInsensitiveMapper
/*     */     implements DialectFactory.DatabaseDialectMapper
/*     */   {
/*     */     private String dialectClassName;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public VersionInsensitiveMapper(String dialectClassName)
/*     */     {
/* 104 */       this.dialectClassName = dialectClassName;
/*     */     }
/*     */     
/*     */     public String getDialectClass(int majorVersion) {
/* 108 */       return this.dialectClassName;
/*     */     }
/*     */   }
/*     */   
/* 112 */   private static final Map MAPPERS = new HashMap();
/*     */   
/*     */   static {
/* 115 */     MAPPERS.put("HSQL Database Engine", new VersionInsensitiveMapper("org.hibernate.dialect.HSQLDialect"));
/* 116 */     MAPPERS.put("DB2/NT", new VersionInsensitiveMapper("org.hibernate.dialect.DB2Dialect"));
/* 117 */     MAPPERS.put("MySQL", new VersionInsensitiveMapper("org.hibernate.dialect.MySQLDialect"));
/* 118 */     MAPPERS.put("PostgreSQL", new VersionInsensitiveMapper("org.hibernate.dialect.PostgreSQLDialect"));
/* 119 */     MAPPERS.put("Microsoft SQL Server Database", new VersionInsensitiveMapper("org.hibernate.dialect.SQLServerDialect"));
/* 120 */     MAPPERS.put("Microsoft SQL Server", new VersionInsensitiveMapper("org.hibernate.dialect.SQLServerDialect"));
/* 121 */     MAPPERS.put("Sybase SQL Server", new VersionInsensitiveMapper("org.hibernate.dialect.SybaseDialect"));
/* 122 */     MAPPERS.put("Informix Dynamic Server", new VersionInsensitiveMapper("org.hibernate.dialect.InformixDialect"));
/*     */     
/* 124 */     MAPPERS.put("Oracle", new DatabaseDialectMapper()
/*     */     {
/*     */       public String getDialectClass(int majorVersion)
/*     */       {
/* 128 */         return majorVersion > 8 ? "org.hibernate.dialect.Oracle9Dialect" : "org.hibernate.dialect.OracleDialect";
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public static abstract interface DatabaseDialectMapper
/*     */   {
/*     */     public abstract String getDialectClass(int paramInt);
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\DialectFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */