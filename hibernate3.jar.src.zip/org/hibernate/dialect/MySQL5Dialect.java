/*    */ package org.hibernate.dialect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MySQL5Dialect
/*    */   extends MySQLDialect
/*    */ {
/*    */   protected void registerVarcharTypes()
/*    */   {
/* 12 */     registerColumnType(12, "longtext");
/* 13 */     registerColumnType(12, 16777215, "mediumtext");
/* 14 */     registerColumnType(12, 65535, "varchar($l)");
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\MySQL5Dialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */