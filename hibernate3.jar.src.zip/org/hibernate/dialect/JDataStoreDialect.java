/*     */ package org.hibernate.dialect;
/*     */ 
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDataStoreDialect
/*     */   extends Dialect
/*     */ {
/*     */   public JDataStoreDialect()
/*     */   {
/*  41 */     registerColumnType(-7, "tinyint");
/*     */     
/*  43 */     registerColumnType(-5, "bigint");
/*     */     
/*  45 */     registerColumnType(5, "smallint");
/*     */     
/*  47 */     registerColumnType(-6, "tinyint");
/*     */     
/*  49 */     registerColumnType(4, "integer");
/*     */     
/*  51 */     registerColumnType(1, "char(1)");
/*     */     
/*  53 */     registerColumnType(12, "varchar($l)");
/*     */     
/*  55 */     registerColumnType(6, "float");
/*     */     
/*  57 */     registerColumnType(8, "double");
/*     */     
/*  59 */     registerColumnType(91, "date");
/*     */     
/*  61 */     registerColumnType(92, "time");
/*     */     
/*  63 */     registerColumnType(93, "timestamp");
/*     */     
/*  65 */     registerColumnType(-3, "varbinary($l)");
/*     */     
/*  67 */     registerColumnType(2, "numeric($p, $s)");
/*     */     
/*     */ 
/*     */ 
/*  71 */     registerColumnType(2004, "varbinary");
/*     */     
/*  73 */     registerColumnType(2005, "varchar");
/*     */     
/*     */ 
/*     */ 
/*  77 */     getDefaultProperties().setProperty("hibernate.jdbc.batch_size", "15");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAddColumnString()
/*     */   {
/*  85 */     return "add";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean dropConstraints()
/*     */   {
/*  93 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCascadeConstraintsString()
/*     */   {
/* 101 */     return " cascade";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsIdentityColumns()
/*     */   {
/* 109 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getIdentitySelectString()
/*     */   {
/* 117 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getIdentityColumnString()
/*     */   {
/* 125 */     return "autoincrement";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getNoColumnsInsertString()
/*     */   {
/* 133 */     return "default values";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsColumnCheck()
/*     */   {
/* 141 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsTableCheck()
/*     */   {
/* 149 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\JDataStoreDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */