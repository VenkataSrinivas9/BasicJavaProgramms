/*    */ package org.hibernate.dialect;
/*    */ 
/*    */ import org.hibernate.Hibernate;
/*    */ import org.hibernate.dialect.function.VarArgsSQLFunction;
/*    */ import org.hibernate.id.TableHiLoGenerator;
/*    */ import org.hibernate.sql.CaseFragment;
/*    */ import org.hibernate.sql.DerbyCaseFragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DerbyDialect
/*    */   extends DB2Dialect
/*    */ {
/*    */   public DerbyDialect()
/*    */   {
/* 22 */     registerFunction("concat", new VarArgsSQLFunction(Hibernate.STRING, "(", "||", ")"));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getIdentityColumnString()
/*    */   {
/* 29 */     return "not null generated always as identity";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public CaseFragment createCaseFragment()
/*    */   {
/* 36 */     return new DerbyCaseFragment();
/*    */   }
/*    */   
/*    */   public boolean dropConstraints() {
/* 40 */     return true;
/*    */   }
/*    */   
/*    */   public Class getNativeIdentifierGeneratorClass() {
/* 44 */     return TableHiLoGenerator.class;
/*    */   }
/*    */   
/*    */   public boolean supportsSequences() {
/* 48 */     return false;
/*    */   }
/*    */   
/*    */   public boolean supportsLimit() {
/* 52 */     return false;
/*    */   }
/*    */   
/*    */   public boolean supportsLimitOffset() {
/* 56 */     return false;
/*    */   }
/*    */   
/*    */   public String getQuerySequencesString() {
/* 60 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\DerbyDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */