/*    */ package org.hibernate.dialect;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import org.hibernate.Hibernate;
/*    */ import org.hibernate.dialect.function.StandardSQLFunction;
/*    */ import org.hibernate.sql.CaseFragment;
/*    */ import org.hibernate.sql.MckoiCaseFragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MckoiDialect
/*    */   extends Dialect
/*    */ {
/*    */   public MckoiDialect()
/*    */   {
/* 19 */     registerColumnType(-7, "bit");
/* 20 */     registerColumnType(-5, "bigint");
/* 21 */     registerColumnType(5, "smallint");
/* 22 */     registerColumnType(-6, "tinyint");
/* 23 */     registerColumnType(4, "integer");
/* 24 */     registerColumnType(1, "char(1)");
/* 25 */     registerColumnType(12, "varchar($l)");
/* 26 */     registerColumnType(6, "float");
/* 27 */     registerColumnType(8, "double");
/* 28 */     registerColumnType(91, "date");
/* 29 */     registerColumnType(92, "time");
/* 30 */     registerColumnType(93, "timestamp");
/* 31 */     registerColumnType(-3, "varbinary");
/* 32 */     registerColumnType(2, "numeric");
/* 33 */     registerColumnType(2004, "blob");
/* 34 */     registerColumnType(2005, "clob");
/*    */     
/* 36 */     registerFunction("upper", new StandardSQLFunction("upper"));
/* 37 */     registerFunction("lower", new StandardSQLFunction("lower"));
/* 38 */     registerFunction("sqrt", new StandardSQLFunction("sqrt", Hibernate.DOUBLE));
/* 39 */     registerFunction("abs", new StandardSQLFunction("abs"));
/* 40 */     registerFunction("sign", new StandardSQLFunction("sign", Hibernate.INTEGER));
/* 41 */     registerFunction("length", new StandardSQLFunction("length", Hibernate.INTEGER));
/* 42 */     registerFunction("round", new StandardSQLFunction("round", Hibernate.INTEGER));
/* 43 */     registerFunction("mod", new StandardSQLFunction("mod", Hibernate.INTEGER));
/* 44 */     registerFunction("least", new StandardSQLFunction("least"));
/* 45 */     registerFunction("greatest", new StandardSQLFunction("greatest"));
/* 46 */     registerFunction("user", new StandardSQLFunction("user", Hibernate.STRING));
/* 47 */     registerFunction("concat", new StandardSQLFunction("concat", Hibernate.STRING));
/*    */     
/* 49 */     getDefaultProperties().setProperty("hibernate.jdbc.batch_size", "0");
/*    */   }
/*    */   
/*    */   public String getAddColumnString() {
/* 53 */     return "add column";
/*    */   }
/*    */   
/*    */   public String getSequenceNextValString(String sequenceName) {
/* 57 */     return "select " + getSelectSequenceNextValString(sequenceName);
/*    */   }
/*    */   
/*    */   public String getSelectSequenceNextValString(String sequenceName) {
/* 61 */     return "nextval('" + sequenceName + "')";
/*    */   }
/*    */   
/*    */   public String getCreateSequenceString(String sequenceName) {
/* 65 */     return "create sequence " + sequenceName;
/*    */   }
/*    */   
/*    */   public String getDropSequenceString(String sequenceName) {
/* 69 */     return "drop sequence " + sequenceName;
/*    */   }
/*    */   
/*    */   public String getForUpdateString() {
/* 73 */     return "";
/*    */   }
/*    */   
/*    */   public boolean supportsSequences() {
/* 77 */     return true;
/*    */   }
/*    */   
/*    */   public CaseFragment createCaseFragment() {
/* 81 */     return new MckoiCaseFragment();
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\MckoiDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */