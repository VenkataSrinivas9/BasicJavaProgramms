/*     */ package org.hibernate.dialect;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.dialect.function.NoArgSQLFunction;
/*     */ import org.hibernate.dialect.function.SQLFunctionTemplate;
/*     */ import org.hibernate.dialect.function.StandardSQLFunction;
/*     */ import org.hibernate.sql.CaseFragment;
/*     */ import org.hibernate.sql.DecodeCaseFragment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RDMSOS2200Dialect
/*     */   extends Dialect
/*     */ {
/*  73 */   private static Log log = LogFactory.getLog(RDMSOS2200Dialect.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RDMSOS2200Dialect()
/*     */   {
/*  83 */     log.info("RDMSOS2200Dialect version: 1.0");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */     registerFunction("abs", new StandardSQLFunction("abs"));
/*     */     
/* 109 */     registerFunction("sign", new StandardSQLFunction("sign", Hibernate.INTEGER));
/*     */     
/*     */ 
/*     */ 
/* 113 */     registerFunction("ascii", new StandardSQLFunction("ascii", Hibernate.INTEGER));
/*     */     
/* 115 */     registerFunction("char_length", new StandardSQLFunction("char_length", Hibernate.INTEGER));
/*     */     
/* 117 */     registerFunction("character_length", new StandardSQLFunction("character_length", Hibernate.INTEGER));
/*     */     
/* 119 */     registerFunction("length", new StandardSQLFunction("length", Hibernate.INTEGER));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */     registerFunction("concat", new SQLFunctionTemplate(Hibernate.STRING, "concat(?1, ?2)"));
/*     */     
/* 127 */     registerFunction("instr", new StandardSQLFunction("instr", Hibernate.STRING));
/*     */     
/* 129 */     registerFunction("lpad", new StandardSQLFunction("lpad", Hibernate.STRING));
/*     */     
/* 131 */     registerFunction("replace", new StandardSQLFunction("replace", Hibernate.STRING));
/*     */     
/* 133 */     registerFunction("rpad", new StandardSQLFunction("rpad", Hibernate.STRING));
/*     */     
/* 135 */     registerFunction("substr", new StandardSQLFunction("substr", Hibernate.STRING));
/*     */     
/*     */ 
/*     */ 
/* 139 */     registerFunction("lcase", new StandardSQLFunction("lcase"));
/*     */     
/* 141 */     registerFunction("lower", new StandardSQLFunction("lower"));
/*     */     
/* 143 */     registerFunction("ltrim", new StandardSQLFunction("ltrim"));
/*     */     
/* 145 */     registerFunction("reverse", new StandardSQLFunction("reverse"));
/*     */     
/* 147 */     registerFunction("rtrim", new StandardSQLFunction("rtrim"));
/*     */     
/*     */ 
/*     */ 
/* 151 */     registerFunction("trim", new SQLFunctionTemplate(Hibernate.INTEGER, "ltrim(rtrim(?1))"));
/*     */     
/* 153 */     registerFunction("soundex", new StandardSQLFunction("soundex"));
/*     */     
/* 155 */     registerFunction("space", new StandardSQLFunction("space", Hibernate.STRING));
/*     */     
/* 157 */     registerFunction("ucase", new StandardSQLFunction("ucase"));
/*     */     
/* 159 */     registerFunction("upper", new StandardSQLFunction("upper"));
/*     */     
/*     */ 
/*     */ 
/* 163 */     registerFunction("acos", new StandardSQLFunction("acos", Hibernate.DOUBLE));
/*     */     
/* 165 */     registerFunction("asin", new StandardSQLFunction("asin", Hibernate.DOUBLE));
/*     */     
/* 167 */     registerFunction("atan", new StandardSQLFunction("atan", Hibernate.DOUBLE));
/*     */     
/* 169 */     registerFunction("cos", new StandardSQLFunction("cos", Hibernate.DOUBLE));
/*     */     
/* 171 */     registerFunction("cosh", new StandardSQLFunction("cosh", Hibernate.DOUBLE));
/*     */     
/* 173 */     registerFunction("cot", new StandardSQLFunction("cot", Hibernate.DOUBLE));
/*     */     
/* 175 */     registerFunction("exp", new StandardSQLFunction("exp", Hibernate.DOUBLE));
/*     */     
/* 177 */     registerFunction("ln", new StandardSQLFunction("ln", Hibernate.DOUBLE));
/*     */     
/* 179 */     registerFunction("log", new StandardSQLFunction("log", Hibernate.DOUBLE));
/*     */     
/* 181 */     registerFunction("log10", new StandardSQLFunction("log10", Hibernate.DOUBLE));
/*     */     
/* 183 */     registerFunction("pi", new NoArgSQLFunction("pi", Hibernate.DOUBLE));
/*     */     
/* 185 */     registerFunction("rand", new NoArgSQLFunction("rand", Hibernate.DOUBLE));
/*     */     
/* 187 */     registerFunction("sin", new StandardSQLFunction("sin", Hibernate.DOUBLE));
/*     */     
/* 189 */     registerFunction("sinh", new StandardSQLFunction("sinh", Hibernate.DOUBLE));
/*     */     
/* 191 */     registerFunction("sqrt", new StandardSQLFunction("sqrt", Hibernate.DOUBLE));
/*     */     
/* 193 */     registerFunction("tan", new StandardSQLFunction("tan", Hibernate.DOUBLE));
/*     */     
/* 195 */     registerFunction("tanh", new StandardSQLFunction("tanh", Hibernate.DOUBLE));
/*     */     
/*     */ 
/*     */ 
/* 199 */     registerFunction("round", new StandardSQLFunction("round"));
/*     */     
/* 201 */     registerFunction("trunc", new StandardSQLFunction("trunc"));
/*     */     
/* 203 */     registerFunction("ceil", new StandardSQLFunction("ceil"));
/*     */     
/* 205 */     registerFunction("floor", new StandardSQLFunction("floor"));
/*     */     
/*     */ 
/*     */ 
/* 209 */     registerFunction("chr", new StandardSQLFunction("chr", Hibernate.CHARACTER));
/*     */     
/* 211 */     registerFunction("initcap", new StandardSQLFunction("initcap"));
/*     */     
/*     */ 
/*     */ 
/* 215 */     registerFunction("user", new NoArgSQLFunction("user", Hibernate.STRING, false));
/*     */     
/*     */ 
/*     */ 
/* 219 */     registerFunction("current_date", new NoArgSQLFunction("current_date", Hibernate.DATE, false));
/*     */     
/* 221 */     registerFunction("current_time", new NoArgSQLFunction("current_timestamp", Hibernate.TIME, false));
/*     */     
/* 223 */     registerFunction("current_timestamp", new NoArgSQLFunction("current_timestamp", Hibernate.TIMESTAMP, false));
/*     */     
/* 225 */     registerFunction("curdate", new NoArgSQLFunction("curdate", Hibernate.DATE));
/*     */     
/* 227 */     registerFunction("curtime", new NoArgSQLFunction("curtime", Hibernate.TIME));
/*     */     
/* 229 */     registerFunction("days", new StandardSQLFunction("days", Hibernate.INTEGER));
/*     */     
/* 231 */     registerFunction("dayofmonth", new StandardSQLFunction("dayofmonth", Hibernate.INTEGER));
/*     */     
/* 233 */     registerFunction("dayname", new StandardSQLFunction("dayname", Hibernate.STRING));
/*     */     
/* 235 */     registerFunction("dayofweek", new StandardSQLFunction("dayofweek", Hibernate.INTEGER));
/*     */     
/* 237 */     registerFunction("dayofyear", new StandardSQLFunction("dayofyear", Hibernate.INTEGER));
/*     */     
/* 239 */     registerFunction("hour", new StandardSQLFunction("hour", Hibernate.INTEGER));
/*     */     
/*     */ 
/*     */ 
/* 243 */     registerFunction("last_day", new StandardSQLFunction("last_day", Hibernate.DATE));
/*     */     
/* 245 */     registerFunction("microsecond", new StandardSQLFunction("microsecond", Hibernate.INTEGER));
/*     */     
/* 247 */     registerFunction("minute", new StandardSQLFunction("minute", Hibernate.INTEGER));
/*     */     
/* 249 */     registerFunction("month", new StandardSQLFunction("month", Hibernate.INTEGER));
/*     */     
/* 251 */     registerFunction("monthname", new StandardSQLFunction("monthname", Hibernate.STRING));
/*     */     
/* 253 */     registerFunction("now", new NoArgSQLFunction("now", Hibernate.TIMESTAMP));
/*     */     
/* 255 */     registerFunction("quarter", new StandardSQLFunction("quarter", Hibernate.INTEGER));
/*     */     
/* 257 */     registerFunction("second", new StandardSQLFunction("second", Hibernate.INTEGER));
/*     */     
/* 259 */     registerFunction("time", new StandardSQLFunction("time", Hibernate.TIME));
/*     */     
/* 261 */     registerFunction("timestamp", new StandardSQLFunction("timestamp", Hibernate.TIMESTAMP));
/*     */     
/* 263 */     registerFunction("week", new StandardSQLFunction("week", Hibernate.INTEGER));
/*     */     
/* 265 */     registerFunction("year", new StandardSQLFunction("year", Hibernate.INTEGER));
/*     */     
/* 267 */     registerFunction("atan2", new StandardSQLFunction("atan2", Hibernate.DOUBLE));
/*     */     
/* 269 */     registerFunction("mod", new StandardSQLFunction("mod", Hibernate.INTEGER));
/*     */     
/* 271 */     registerFunction("nvl", new StandardSQLFunction("nvl"));
/*     */     
/* 273 */     registerFunction("power", new StandardSQLFunction("power", Hibernate.DOUBLE));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 327 */     registerColumnType(-7, "SMALLINT");
/*     */     
/* 329 */     registerColumnType(-6, "SMALLINT");
/*     */     
/* 331 */     registerColumnType(-5, "NUMERIC(21,0)");
/*     */     
/* 333 */     registerColumnType(5, "SMALLINT");
/*     */     
/* 335 */     registerColumnType(1, "CHARACTER(1)");
/*     */     
/* 337 */     registerColumnType(8, "DOUBLE PRECISION");
/*     */     
/* 339 */     registerColumnType(6, "FLOAT");
/*     */     
/* 341 */     registerColumnType(7, "REAL");
/*     */     
/* 343 */     registerColumnType(4, "INTEGER");
/*     */     
/* 345 */     registerColumnType(2, "NUMERIC(21,$l)");
/*     */     
/* 347 */     registerColumnType(3, "NUMERIC(21,$l)");
/*     */     
/* 349 */     registerColumnType(91, "DATE");
/*     */     
/* 351 */     registerColumnType(92, "TIME");
/*     */     
/* 353 */     registerColumnType(93, "TIMESTAMP");
/*     */     
/* 355 */     registerColumnType(12, "CHARACTER($l)");
/*     */     
/* 357 */     registerColumnType(2004, "BLOB($l)");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean qualifyIndexName()
/*     */   {
/* 391 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean forUpdateOfColumns()
/*     */   {
/* 411 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getForUpdateString()
/*     */   {
/* 431 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsUniqueConstraintInCreateAlterTable()
/*     */   {
/* 445 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsCascadeDelete()
/*     */   {
/* 463 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsOuterJoinForUpdate()
/*     */   {
/* 479 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAddColumnString()
/*     */   {
/* 575 */     return "add";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getNullColumnString()
/*     */   {
/* 585 */     return " null";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsSequences()
/*     */   {
/* 597 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSequenceNextValString(String sequenceName)
/*     */   {
/* 607 */     return "select permuted_id('NEXT',31) from rdms.rdms_dummy where key_col = 1 ";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCreateSequenceString(String sequenceName)
/*     */   {
/* 619 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDropSequenceString(String sequenceName)
/*     */   {
/* 631 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCascadeConstraintsString()
/*     */   {
/* 645 */     return " including contents";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CaseFragment createCaseFragment()
/*     */   {
/* 653 */     return new DecodeCaseFragment();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsLimit()
/*     */   {
/* 661 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsLimitOffset()
/*     */   {
/* 669 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLimitString(String sql, int offset, int limit)
/*     */   {
/* 677 */     if (offset > 0) { throw new UnsupportedOperationException("RDMS does not support paged queries");
/*     */     }
/* 679 */     return sql.length() + 40 + sql + " fetch first " + limit + " rows only ";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsVariableLimit()
/*     */   {
/* 697 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsUnionAll()
/*     */   {
/* 707 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\RDMSOS2200Dialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */