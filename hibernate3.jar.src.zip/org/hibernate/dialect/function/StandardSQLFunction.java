/*    */ package org.hibernate.dialect.function;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.hibernate.engine.Mapping;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandardSQLFunction
/*    */   implements SQLFunction
/*    */ {
/* 19 */   private Type returnType = null;
/*    */   private String name;
/*    */   
/*    */   public StandardSQLFunction(String name) {
/* 23 */     this.name = name;
/*    */   }
/*    */   
/*    */   public StandardSQLFunction(String name, Type typeValue) {
/* 27 */     this.returnType = typeValue;
/* 28 */     this.name = name;
/*    */   }
/*    */   
/*    */   public Type getReturnType(Type columnType, Mapping mapping) {
/* 32 */     return this.returnType == null ? columnType : this.returnType;
/*    */   }
/*    */   
/*    */   public boolean hasArguments() {
/* 36 */     return true;
/*    */   }
/*    */   
/*    */   public boolean hasParenthesesIfNoArguments() {
/* 40 */     return true;
/*    */   }
/*    */   
/*    */   public String render(List args, SessionFactoryImplementor factory) {
/* 44 */     StringBuffer buf = new StringBuffer();
/* 45 */     buf.append(this.name).append('(');
/*    */     
/* 47 */     for (int i = 0; i < args.size(); i++) {
/* 48 */       buf.append(args.get(i));
/* 49 */       if (i < args.size() - 1) buf.append(", ");
/*    */     }
/* 51 */     return ')';
/*    */   }
/*    */   
/*    */   public String toString() {
/* 55 */     return this.name;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\function\StandardSQLFunction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */