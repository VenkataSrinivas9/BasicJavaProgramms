/*     */ package org.hibernate.dialect.function;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.engine.Mapping;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VarArgsSQLFunction
/*     */   implements SQLFunction
/*     */ {
/*     */   private final String begin;
/*     */   private final String sep;
/*     */   private final String end;
/*     */   private final Type type;
/*     */   
/*     */   public VarArgsSQLFunction(Type type, String begin, String sep, String end)
/*     */   {
/*  47 */     this.begin = begin;
/*     */     
/*  49 */     this.sep = sep;
/*     */     
/*  51 */     this.end = end;
/*     */     
/*  53 */     this.type = type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public VarArgsSQLFunction(String begin, String sep, String end)
/*     */   {
/*  61 */     this.begin = begin;
/*     */     
/*  63 */     this.sep = sep;
/*     */     
/*  65 */     this.end = end;
/*     */     
/*  67 */     this.type = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Type getReturnType(Type columnType, Mapping mapping)
/*     */     throws QueryException
/*     */   {
/*  75 */     return this.type == null ? columnType : this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasArguments()
/*     */   {
/*  83 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasParenthesesIfNoArguments()
/*     */   {
/*  91 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String render(List args, SessionFactoryImplementor factory)
/*     */     throws QueryException
/*     */   {
/*  99 */     StringBuffer buf = new StringBuffer().append(this.begin);
/*     */     
/* 101 */     for (int i = 0; i < args.size(); i++)
/*     */     {
/* 103 */       buf.append(args.get(i));
/*     */       
/* 105 */       if (i < args.size() - 1) { buf.append(this.sep);
/*     */       }
/*     */     }
/*     */     
/* 109 */     return this.end;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\function\VarArgsSQLFunction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */