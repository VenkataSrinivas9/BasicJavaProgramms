/*     */ package org.hibernate.dialect.function;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.engine.Mapping;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLFunctionTemplate
/*     */   implements SQLFunction
/*     */ {
/*     */   private final Type type;
/*     */   private final boolean hasArguments;
/*     */   private final boolean hasParenthesesIfNoArgs;
/*     */   private final String template;
/*     */   private final String[] chunks;
/*     */   private final int[] paramIndexes;
/*     */   
/*     */   public SQLFunctionTemplate(Type type, String template)
/*     */   {
/*  33 */     this(type, template, true);
/*     */   }
/*     */   
/*     */   public SQLFunctionTemplate(Type type, String template, boolean hasParenthesesIfNoArgs) {
/*  37 */     this.type = type;
/*  38 */     this.template = template;
/*     */     
/*  40 */     List chunkList = new ArrayList();
/*  41 */     List paramList = new ArrayList();
/*  42 */     StringBuffer chunk = new StringBuffer(10);
/*  43 */     StringBuffer index = new StringBuffer(2);
/*     */     
/*  45 */     for (int i = 0; i < template.length(); i++) {
/*  46 */       char c = template.charAt(i);
/*  47 */       if (c == '?') {
/*  48 */         chunkList.add(chunk.toString());
/*  49 */         chunk.delete(0, chunk.length());
/*     */         for (;;) {
/*  51 */           i++; if (i >= template.length()) break label155;
/*  52 */           c = template.charAt(i);
/*  53 */           if (!Character.isDigit(c)) break;
/*  54 */           index.append(c);
/*     */         }
/*     */         
/*  57 */         chunk.append(c);
/*     */         
/*     */ 
/*     */         label155:
/*     */         
/*  62 */         paramList.add(new Integer(Integer.parseInt(index.toString()) - 1));
/*  63 */         index.delete(0, index.length());
/*     */       }
/*     */       else {
/*  66 */         chunk.append(c);
/*     */       }
/*     */     }
/*     */     
/*  70 */     if (chunk.length() > 0) {
/*  71 */       chunkList.add(chunk.toString());
/*     */     }
/*     */     
/*  74 */     this.chunks = ((String[])chunkList.toArray(new String[chunkList.size()]));
/*  75 */     this.paramIndexes = new int[paramList.size()];
/*  76 */     for (int i = 0; i < this.paramIndexes.length; i++) {
/*  77 */       this.paramIndexes[i] = ((Integer)paramList.get(i)).intValue();
/*     */     }
/*     */     
/*  80 */     this.hasArguments = (this.paramIndexes.length > 0);
/*  81 */     this.hasParenthesesIfNoArgs = hasParenthesesIfNoArgs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String render(List args, SessionFactoryImplementor factory)
/*     */   {
/*  91 */     StringBuffer buf = new StringBuffer();
/*  92 */     for (int i = 0; i < this.chunks.length; i++) {
/*  93 */       if (i < this.paramIndexes.length) {
/*  94 */         Object arg = this.paramIndexes[i] < args.size() ? args.get(this.paramIndexes[i]) : null;
/*  95 */         if (arg != null) {
/*  96 */           buf.append(this.chunks[i]).append(arg);
/*     */         }
/*     */       }
/*     */       else {
/* 100 */         buf.append(this.chunks[i]);
/*     */       }
/*     */     }
/* 103 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public Type getReturnType(Type columnType, Mapping mapping)
/*     */     throws QueryException
/*     */   {
/* 109 */     return this.type;
/*     */   }
/*     */   
/*     */   public boolean hasArguments() {
/* 113 */     return this.hasArguments;
/*     */   }
/*     */   
/*     */   public boolean hasParenthesesIfNoArguments() {
/* 117 */     return this.hasParenthesesIfNoArgs;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 121 */     return this.template;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\function\SQLFunctionTemplate.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */