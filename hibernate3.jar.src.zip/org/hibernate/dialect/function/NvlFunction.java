/*    */ package org.hibernate.dialect.function;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.hibernate.QueryException;
/*    */ import org.hibernate.engine.Mapping;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NvlFunction
/*    */   implements SQLFunction
/*    */ {
/*    */   public Type getReturnType(Type columnType, Mapping mapping)
/*    */     throws QueryException
/*    */   {
/* 37 */     return columnType;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean hasArguments()
/*    */   {
/* 45 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean hasParenthesesIfNoArguments()
/*    */   {
/* 53 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String render(List args, SessionFactoryImplementor factory)
/*    */     throws QueryException
/*    */   {
/* 61 */     int lastIndex = args.size() - 1;
/*    */     
/* 63 */     Object last = args.remove(lastIndex);
/*    */     
/* 65 */     if (lastIndex == 0) { return last.toString();
/*    */     }
/* 67 */     Object secondLast = args.get(lastIndex - 1);
/*    */     
/* 69 */     String nvl = "nvl(" + secondLast + ", " + last + ")";
/*    */     
/* 71 */     args.set(lastIndex - 1, nvl);
/*    */     
/* 73 */     return render(args, factory);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\function\NvlFunction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */