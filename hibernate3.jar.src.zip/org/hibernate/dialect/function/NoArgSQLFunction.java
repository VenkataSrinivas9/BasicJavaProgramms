/*    */ package org.hibernate.dialect.function;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.hibernate.QueryException;
/*    */ import org.hibernate.engine.Mapping;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoArgSQLFunction
/*    */   implements SQLFunction
/*    */ {
/*    */   private Type returnType;
/*    */   private boolean hasParenthesesIfNoArguments;
/*    */   private String name;
/*    */   
/*    */   public NoArgSQLFunction(String name, Type returnType)
/*    */   {
/* 22 */     this(name, returnType, true);
/*    */   }
/*    */   
/*    */   public NoArgSQLFunction(String name, Type returnType, boolean hasParenthesesIfNoArguments) {
/* 26 */     this.returnType = returnType;
/* 27 */     this.hasParenthesesIfNoArguments = hasParenthesesIfNoArguments;
/* 28 */     this.name = name;
/*    */   }
/*    */   
/*    */   public Type getReturnType(Type columnType, Mapping mapping) throws QueryException {
/* 32 */     return this.returnType;
/*    */   }
/*    */   
/*    */   public boolean hasArguments() {
/* 36 */     return false;
/*    */   }
/*    */   
/*    */   public boolean hasParenthesesIfNoArguments() {
/* 40 */     return this.hasParenthesesIfNoArguments;
/*    */   }
/*    */   
/*    */   public String render(List args, SessionFactoryImplementor factory) throws QueryException {
/* 44 */     if (args.size() > 0) {
/* 45 */       throw new QueryException("function takes no arguments: " + this.name);
/*    */     }
/* 47 */     return this.hasParenthesesIfNoArguments ? this.name + "()" : this.name;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\function\NoArgSQLFunction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */