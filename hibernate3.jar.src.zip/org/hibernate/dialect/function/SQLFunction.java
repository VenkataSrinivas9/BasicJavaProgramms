package org.hibernate.dialect.function;

import java.util.List;
import org.hibernate.QueryException;
import org.hibernate.engine.Mapping;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.type.Type;

public abstract interface SQLFunction
{
  public abstract Type getReturnType(Type paramType, Mapping paramMapping)
    throws QueryException;
  
  public abstract boolean hasArguments();
  
  public abstract boolean hasParenthesesIfNoArguments();
  
  public abstract String render(List paramList, SessionFactoryImplementor paramSessionFactoryImplementor)
    throws QueryException;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\function\SQLFunction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */