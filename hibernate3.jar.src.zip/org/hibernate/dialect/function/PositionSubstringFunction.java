/*    */ package org.hibernate.dialect.function;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.hibernate.Hibernate;
/*    */ import org.hibernate.QueryException;
/*    */ import org.hibernate.engine.Mapping;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PositionSubstringFunction
/*    */   implements SQLFunction
/*    */ {
/*    */   public Type getReturnType(Type columnType, Mapping mapping)
/*    */     throws QueryException
/*    */   {
/* 37 */     return Hibernate.INTEGER;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean hasArguments()
/*    */   {
/* 45 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean hasParenthesesIfNoArguments()
/*    */   {
/* 53 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String render(List args, SessionFactoryImplementor factory)
/*    */     throws QueryException
/*    */   {
/* 61 */     boolean threeArgs = args.size() > 2;
/*    */     
/* 63 */     Object pattern = args.get(0);
/*    */     
/* 65 */     Object string = args.get(1);
/*    */     
/* 67 */     Object start = threeArgs ? args.get(2) : null;
/*    */     
/*    */ 
/*    */ 
/* 71 */     StringBuffer buf = new StringBuffer();
/*    */     
/* 73 */     if (threeArgs) { buf.append('(');
/*    */     }
/* 75 */     buf.append("position(").append(pattern).append(" in ");
/*    */     
/* 77 */     if (threeArgs) { buf.append("substring(");
/*    */     }
/* 79 */     buf.append(string);
/*    */     
/* 81 */     if (threeArgs) { buf.append(", ").append(start).append(')');
/*    */     }
/* 83 */     buf.append(')');
/*    */     
/* 85 */     if (threeArgs) { buf.append('+').append(start).append("-1)");
/*    */     }
/* 87 */     return buf.toString();
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\function\PositionSubstringFunction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */