/*     */ package org.hibernate.dialect.function;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.engine.Mapping;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.type.TypeFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CastFunction
/*     */   implements SQLFunction
/*     */ {
/*     */   public Type getReturnType(Type columnType, Mapping mapping)
/*     */     throws QueryException
/*     */   {
/*  39 */     return columnType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasArguments()
/*     */   {
/*  47 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasParenthesesIfNoArguments()
/*     */   {
/*  55 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String render(List args, SessionFactoryImplementor factory)
/*     */     throws QueryException
/*     */   {
/*  63 */     if (args.size() != 2)
/*     */     {
/*  65 */       throw new QueryException("cast() requires two arguments");
/*     */     }
/*     */     
/*     */ 
/*  69 */     String type = (String)args.get(1);
/*     */     
/*  71 */     int[] sqlTypeCodes = TypeFactory.heuristicType(type).sqlTypes(factory);
/*     */     
/*  73 */     if (sqlTypeCodes.length != 1)
/*     */     {
/*  75 */       throw new QueryException("invalid Hibernate type for cast()");
/*     */     }
/*     */     
/*     */ 
/*  79 */     String sqlType = factory.getDialect().getCastTypeName(sqlTypeCodes[0]);
/*     */     
/*  81 */     if (sqlType == null)
/*     */     {
/*     */ 
/*     */ 
/*  85 */       sqlType = type;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 103 */     return "cast(" + args.get(0) + " as " + sqlType + ')';
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\function\CastFunction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */