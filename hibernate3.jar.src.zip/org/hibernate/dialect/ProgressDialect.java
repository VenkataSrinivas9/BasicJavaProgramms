/*    */ package org.hibernate.dialect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProgressDialect
/*    */   extends Dialect
/*    */ {
/*    */   public ProgressDialect()
/*    */   {
/* 26 */     registerColumnType(-7, "bit");
/* 27 */     registerColumnType(-5, "numeric");
/* 28 */     registerColumnType(5, "smallint");
/* 29 */     registerColumnType(-6, "tinyint");
/* 30 */     registerColumnType(4, "integer");
/* 31 */     registerColumnType(1, "character(1)");
/* 32 */     registerColumnType(12, "varchar($l)");
/* 33 */     registerColumnType(6, "real");
/* 34 */     registerColumnType(8, "double precision");
/* 35 */     registerColumnType(91, "date");
/* 36 */     registerColumnType(92, "time");
/* 37 */     registerColumnType(93, "timestamp");
/* 38 */     registerColumnType(-3, "varbinary($l)");
/* 39 */     registerColumnType(2, "numeric($p,$s)");
/*    */   }
/*    */   
/*    */   public boolean hasAlterTable() {
/* 43 */     return false;
/*    */   }
/*    */   
/*    */   public String getAddColumnString() {
/* 47 */     return "add column";
/*    */   }
/*    */   
/*    */   public boolean qualifyIndexName() {
/* 51 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\ProgressDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */