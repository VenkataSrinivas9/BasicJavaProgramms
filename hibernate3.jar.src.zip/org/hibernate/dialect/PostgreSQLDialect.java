/*     */ package org.hibernate.dialect;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.dialect.function.NoArgSQLFunction;
/*     */ import org.hibernate.dialect.function.PositionSubstringFunction;
/*     */ import org.hibernate.dialect.function.SQLFunctionTemplate;
/*     */ import org.hibernate.dialect.function.StandardSQLFunction;
/*     */ import org.hibernate.dialect.function.VarArgsSQLFunction;
/*     */ import org.hibernate.exception.JDBCExceptionHelper;
/*     */ import org.hibernate.exception.TemplatedViolatedConstraintNameExtracter;
/*     */ import org.hibernate.exception.ViolatedConstraintNameExtracter;
/*     */ import org.hibernate.id.SequenceGenerator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PostgreSQLDialect
/*     */   extends Dialect
/*     */ {
/*     */   public PostgreSQLDialect()
/*     */   {
/*  27 */     registerColumnType(-7, "bool");
/*  28 */     registerColumnType(-5, "int8");
/*  29 */     registerColumnType(5, "int2");
/*  30 */     registerColumnType(-6, "int2");
/*  31 */     registerColumnType(4, "int4");
/*  32 */     registerColumnType(1, "char(1)");
/*  33 */     registerColumnType(12, "varchar($l)");
/*  34 */     registerColumnType(6, "float4");
/*  35 */     registerColumnType(8, "float8");
/*  36 */     registerColumnType(91, "date");
/*  37 */     registerColumnType(92, "time");
/*  38 */     registerColumnType(93, "timestamp");
/*  39 */     registerColumnType(-3, "bytea");
/*  40 */     registerColumnType(2005, "text");
/*  41 */     registerColumnType(2004, "oid");
/*  42 */     registerColumnType(2, "numeric($p, $s)");
/*     */     
/*  44 */     registerFunction("abs", new StandardSQLFunction("abs"));
/*  45 */     registerFunction("sign", new StandardSQLFunction("sign", Hibernate.INTEGER));
/*     */     
/*  47 */     registerFunction("acos", new StandardSQLFunction("acos", Hibernate.DOUBLE));
/*  48 */     registerFunction("asin", new StandardSQLFunction("asin", Hibernate.DOUBLE));
/*  49 */     registerFunction("atan", new StandardSQLFunction("atan", Hibernate.DOUBLE));
/*  50 */     registerFunction("cos", new StandardSQLFunction("cos", Hibernate.DOUBLE));
/*  51 */     registerFunction("cot", new StandardSQLFunction("cot", Hibernate.DOUBLE));
/*  52 */     registerFunction("exp", new StandardSQLFunction("exp", Hibernate.DOUBLE));
/*  53 */     registerFunction("ln", new StandardSQLFunction("ln", Hibernate.DOUBLE));
/*  54 */     registerFunction("log", new StandardSQLFunction("log", Hibernate.DOUBLE));
/*  55 */     registerFunction("sin", new StandardSQLFunction("sin", Hibernate.DOUBLE));
/*  56 */     registerFunction("sqrt", new StandardSQLFunction("sqrt", Hibernate.DOUBLE));
/*  57 */     registerFunction("cbrt", new StandardSQLFunction("cbrt", Hibernate.DOUBLE));
/*  58 */     registerFunction("tan", new StandardSQLFunction("tan", Hibernate.DOUBLE));
/*  59 */     registerFunction("radians", new StandardSQLFunction("radians", Hibernate.DOUBLE));
/*  60 */     registerFunction("degrees", new StandardSQLFunction("degrees", Hibernate.DOUBLE));
/*     */     
/*  62 */     registerFunction("stddev", new StandardSQLFunction("stddev", Hibernate.DOUBLE));
/*  63 */     registerFunction("variance", new StandardSQLFunction("variance", Hibernate.DOUBLE));
/*     */     
/*  65 */     registerFunction("random", new NoArgSQLFunction("random", Hibernate.DOUBLE));
/*     */     
/*  67 */     registerFunction("round", new StandardSQLFunction("round"));
/*  68 */     registerFunction("trunc", new StandardSQLFunction("trunc"));
/*  69 */     registerFunction("ceil", new StandardSQLFunction("ceil"));
/*  70 */     registerFunction("floor", new StandardSQLFunction("floor"));
/*     */     
/*  72 */     registerFunction("chr", new StandardSQLFunction("chr", Hibernate.CHARACTER));
/*  73 */     registerFunction("lower", new StandardSQLFunction("lower"));
/*  74 */     registerFunction("upper", new StandardSQLFunction("upper"));
/*  75 */     registerFunction("substr", new StandardSQLFunction("substr", Hibernate.STRING));
/*  76 */     registerFunction("initcap", new StandardSQLFunction("initcap"));
/*  77 */     registerFunction("to_ascii", new StandardSQLFunction("to_ascii"));
/*  78 */     registerFunction("quote_ident", new StandardSQLFunction("quote_ident", Hibernate.STRING));
/*  79 */     registerFunction("quote_literal", new StandardSQLFunction("quote_literal", Hibernate.STRING));
/*  80 */     registerFunction("md5", new StandardSQLFunction("md5"));
/*  81 */     registerFunction("ascii", new StandardSQLFunction("ascii", Hibernate.INTEGER));
/*  82 */     registerFunction("length", new StandardSQLFunction("length", Hibernate.LONG));
/*  83 */     registerFunction("char_length", new StandardSQLFunction("char_length", Hibernate.LONG));
/*  84 */     registerFunction("bit_length", new StandardSQLFunction("bit_length", Hibernate.LONG));
/*  85 */     registerFunction("octet_length", new StandardSQLFunction("octet_length", Hibernate.LONG));
/*     */     
/*  87 */     registerFunction("current_date", new NoArgSQLFunction("current_date", Hibernate.DATE, false));
/*  88 */     registerFunction("current_time", new NoArgSQLFunction("current_time", Hibernate.TIME, false));
/*  89 */     registerFunction("current_timestamp", new NoArgSQLFunction("current_timestamp", Hibernate.TIMESTAMP, false));
/*  90 */     registerFunction("localtime", new NoArgSQLFunction("localtime", Hibernate.TIME, false));
/*  91 */     registerFunction("localtimestamp", new NoArgSQLFunction("localtimestamp", Hibernate.TIMESTAMP, false));
/*  92 */     registerFunction("now", new NoArgSQLFunction("now", Hibernate.TIMESTAMP));
/*  93 */     registerFunction("timeofday", new NoArgSQLFunction("timeofday", Hibernate.STRING));
/*  94 */     registerFunction("age", new StandardSQLFunction("age"));
/*     */     
/*  96 */     registerFunction("current_user", new NoArgSQLFunction("current_user", Hibernate.STRING, false));
/*  97 */     registerFunction("session_user", new NoArgSQLFunction("session_user", Hibernate.STRING, false));
/*  98 */     registerFunction("user", new NoArgSQLFunction("user", Hibernate.STRING, false));
/*  99 */     registerFunction("current_database", new NoArgSQLFunction("current_database", Hibernate.STRING, true));
/* 100 */     registerFunction("current_schema", new NoArgSQLFunction("current_schema", Hibernate.STRING, true));
/*     */     
/* 102 */     registerFunction("to_char", new StandardSQLFunction("to_char", Hibernate.STRING));
/* 103 */     registerFunction("to_date", new StandardSQLFunction("to_date", Hibernate.DATE));
/* 104 */     registerFunction("to_timestamp", new StandardSQLFunction("to_timestamp", Hibernate.TIMESTAMP));
/* 105 */     registerFunction("to_number", new StandardSQLFunction("to_number", Hibernate.BIG_DECIMAL));
/*     */     
/* 107 */     registerFunction("concat", new VarArgsSQLFunction(Hibernate.STRING, "(", "||", ")"));
/*     */     
/* 109 */     registerFunction("locate", new PositionSubstringFunction());
/*     */     
/* 111 */     registerFunction("str", new SQLFunctionTemplate(Hibernate.STRING, "cast(?1 as varchar)"));
/*     */     
/* 113 */     getDefaultProperties().setProperty("hibernate.jdbc.batch_size", "15");
/*     */   }
/*     */   
/*     */   public String getAddColumnString() {
/* 117 */     return "add column";
/*     */   }
/*     */   
/*     */   public String getSequenceNextValString(String sequenceName) {
/* 121 */     return "select " + getSelectSequenceNextValString(sequenceName);
/*     */   }
/*     */   
/*     */   public String getSelectSequenceNextValString(String sequenceName) {
/* 125 */     return "nextval ('" + sequenceName + "')";
/*     */   }
/*     */   
/*     */   public String getCreateSequenceString(String sequenceName) {
/* 129 */     return "create sequence " + sequenceName;
/*     */   }
/*     */   
/*     */   public String getDropSequenceString(String sequenceName) {
/* 133 */     return "drop sequence " + sequenceName;
/*     */   }
/*     */   
/*     */   public String getCascadeConstraintsString() {
/* 137 */     return "";
/*     */   }
/*     */   
/* 140 */   public boolean dropConstraints() { return true; }
/*     */   
/*     */   public boolean supportsSequences()
/*     */   {
/* 144 */     return true;
/*     */   }
/*     */   
/*     */   public String getQuerySequencesString() {
/* 148 */     return "select relname from pg_class where relkind='S'";
/*     */   }
/*     */   
/*     */   public boolean supportsLimit() {
/* 152 */     return true;
/*     */   }
/*     */   
/*     */   public String getLimitString(String sql, boolean hasOffset) {
/* 156 */     return sql.length() + 20 + sql + (hasOffset ? " limit ? offset ?" : " limit ?");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean bindLimitParametersInReverseOrder()
/*     */   {
/* 163 */     return true;
/*     */   }
/*     */   
/*     */   public boolean supportsIdentityColumns() {
/* 167 */     return true;
/*     */   }
/*     */   
/*     */   public String getForUpdateString(String aliases) {
/* 171 */     return getForUpdateString() + " of " + aliases;
/*     */   }
/*     */   
/*     */   public String getIdentitySelectString(String table, String column, int type) {
/* 175 */     return "select currval('" + table + '_' + column + "_seq')";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getIdentityColumnString(int type)
/*     */   {
/* 184 */     return type == -5 ? "bigserial not null" : "serial not null";
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean hasDataTypeInIdentityColumn()
/*     */   {
/* 190 */     return false;
/*     */   }
/*     */   
/*     */   public String getNoColumnsInsertString() {
/* 194 */     return "default values";
/*     */   }
/*     */   
/*     */   public Class getNativeIdentifierGeneratorClass() {
/* 198 */     return SequenceGenerator.class;
/*     */   }
/*     */   
/*     */   public boolean supportsOuterJoinForUpdate() {
/* 202 */     return false;
/*     */   }
/*     */   
/*     */   public boolean useInputStreamToInsertBlob() {
/* 206 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsUnionAll() {
/* 210 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getSelectClauseNullString(int sqlType)
/*     */   {
/* 217 */     String typeName = getTypeName(sqlType, 1, 1, 0);
/*     */     
/* 219 */     int loc = typeName.indexOf('(');
/* 220 */     if (loc > -1) {
/* 221 */       typeName = typeName.substring(0, loc);
/*     */     }
/* 223 */     return "null::" + typeName;
/*     */   }
/*     */   
/*     */   public boolean supportsCommentOn() {
/* 227 */     return true;
/*     */   }
/*     */   
/*     */   public boolean supportsTemporaryTables() {
/* 231 */     return true;
/*     */   }
/*     */   
/*     */   public String getCreateTemporaryTableString() {
/* 235 */     return "create local temporary table";
/*     */   }
/*     */   
/*     */   public String getCreateTemporaryTablePostfix() {
/* 239 */     return "on commit drop";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsCurrentTimestampSelection()
/*     */   {
/* 249 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isCurrentTimestampSelectStringCallable() {
/* 253 */     return false;
/*     */   }
/*     */   
/*     */   public String getCurrentTimestampSelectString() {
/* 257 */     return "select now()";
/*     */   }
/*     */   
/*     */   public String toBooleanValueString(boolean bool) {
/* 261 */     return bool ? "true" : "false";
/*     */   }
/*     */   
/*     */   public ViolatedConstraintNameExtracter getViolatedConstraintNameExtracter() {
/* 265 */     return EXTRACTER;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 272 */   private static ViolatedConstraintNameExtracter EXTRACTER = new TemplatedViolatedConstraintNameExtracter() {
/*     */     public String extractConstraintName(SQLException sqle) {
/*     */       try {
/* 275 */         int sqlState = Integer.valueOf(JDBCExceptionHelper.extractSqlState(sqle)).intValue();
/* 276 */         switch (sqlState) {
/*     */         case 23514: 
/* 278 */           return extractUsingTemplate("violates check constraint \"", "\"", sqle.getMessage());
/*     */         case 23505: 
/* 280 */           return extractUsingTemplate("violates unique constraint \"", "\"", sqle.getMessage());
/*     */         case 23503: 
/* 282 */           return extractUsingTemplate("violates foreign key constraint \"", "\"", sqle.getMessage());
/*     */         case 23502: 
/* 284 */           return extractUsingTemplate("null value in column \"", "\" violates not-null constraint", sqle.getMessage());
/*     */         case 23001: 
/* 286 */           return null;
/*     */         }
/* 288 */         return null;
/*     */       }
/*     */       catch (NumberFormatException nfe) {}
/* 291 */       return null;
/*     */     }
/*     */   };
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\PostgreSQLDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */