/*     */ package org.hibernate.dialect;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.dialect.function.NoArgSQLFunction;
/*     */ import org.hibernate.dialect.function.StandardSQLFunction;
/*     */ import org.hibernate.dialect.function.VarArgsSQLFunction;
/*     */ import org.hibernate.exception.JDBCExceptionHelper;
/*     */ import org.hibernate.exception.TemplatedViolatedConstraintNameExtracter;
/*     */ import org.hibernate.exception.ViolatedConstraintNameExtracter;
/*     */ import org.hibernate.util.ReflectHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HSQLDialect
/*     */   extends Dialect
/*     */ {
/*     */   private boolean schemaSupport;
/*     */   
/*     */   public HSQLDialect()
/*     */   {
/*  30 */     registerColumnType(-5, "bigint");
/*  31 */     registerColumnType(-2, "binary");
/*  32 */     registerColumnType(-7, "bit");
/*  33 */     registerColumnType(1, "char(1)");
/*  34 */     registerColumnType(91, "date");
/*  35 */     registerColumnType(3, "decimal");
/*  36 */     registerColumnType(8, "double");
/*  37 */     registerColumnType(6, "float");
/*  38 */     registerColumnType(4, "integer");
/*  39 */     registerColumnType(-4, "longvarbinary");
/*  40 */     registerColumnType(-1, "longvarchar");
/*  41 */     registerColumnType(5, "smallint");
/*  42 */     registerColumnType(-6, "tinyint");
/*  43 */     registerColumnType(92, "time");
/*  44 */     registerColumnType(93, "timestamp");
/*  45 */     registerColumnType(12, "varchar($l)");
/*  46 */     registerColumnType(-3, "varbinary($l)");
/*  47 */     registerColumnType(2, "numeric");
/*     */     
/*  49 */     registerColumnType(2004, "longvarbinary");
/*  50 */     registerColumnType(2005, "longvarchar");
/*     */     
/*  52 */     registerFunction("ascii", new StandardSQLFunction("ascii", Hibernate.INTEGER));
/*  53 */     registerFunction("char", new StandardSQLFunction("char", Hibernate.CHARACTER));
/*  54 */     registerFunction("length", new StandardSQLFunction("length", Hibernate.LONG));
/*  55 */     registerFunction("lower", new StandardSQLFunction("lower"));
/*  56 */     registerFunction("upper", new StandardSQLFunction("upper"));
/*  57 */     registerFunction("lcase", new StandardSQLFunction("lcase"));
/*  58 */     registerFunction("ucase", new StandardSQLFunction("ucase"));
/*  59 */     registerFunction("soundex", new StandardSQLFunction("soundex", Hibernate.STRING));
/*  60 */     registerFunction("ltrim", new StandardSQLFunction("ltrim"));
/*  61 */     registerFunction("rtrim", new StandardSQLFunction("rtrim"));
/*  62 */     registerFunction("reverse", new StandardSQLFunction("reverse"));
/*  63 */     registerFunction("space", new StandardSQLFunction("space", Hibernate.STRING));
/*  64 */     registerFunction("rawtohex", new StandardSQLFunction("rawtohex"));
/*  65 */     registerFunction("hextoraw", new StandardSQLFunction("hextoraw"));
/*     */     
/*  67 */     registerFunction("user", new NoArgSQLFunction("user", Hibernate.STRING));
/*  68 */     registerFunction("database", new NoArgSQLFunction("database", Hibernate.STRING));
/*     */     
/*  70 */     registerFunction("current_date", new NoArgSQLFunction("current_date", Hibernate.DATE, false));
/*  71 */     registerFunction("curdate", new NoArgSQLFunction("curdate", Hibernate.DATE));
/*  72 */     registerFunction("current_timestamp", new NoArgSQLFunction("current_timestamp", Hibernate.TIMESTAMP, false));
/*  73 */     registerFunction("now", new NoArgSQLFunction("now", Hibernate.TIMESTAMP));
/*  74 */     registerFunction("current_time", new NoArgSQLFunction("current_time", Hibernate.TIME, false));
/*  75 */     registerFunction("curtime", new NoArgSQLFunction("curtime", Hibernate.TIME));
/*  76 */     registerFunction("day", new StandardSQLFunction("day", Hibernate.INTEGER));
/*  77 */     registerFunction("dayofweek", new StandardSQLFunction("dayofweek", Hibernate.INTEGER));
/*  78 */     registerFunction("dayofyear", new StandardSQLFunction("dayofyear", Hibernate.INTEGER));
/*  79 */     registerFunction("dayofmonth", new StandardSQLFunction("dayofmonth", Hibernate.INTEGER));
/*  80 */     registerFunction("month", new StandardSQLFunction("month", Hibernate.INTEGER));
/*  81 */     registerFunction("year", new StandardSQLFunction("year", Hibernate.INTEGER));
/*  82 */     registerFunction("week", new StandardSQLFunction("week", Hibernate.INTEGER));
/*  83 */     registerFunction("quater", new StandardSQLFunction("quater", Hibernate.INTEGER));
/*  84 */     registerFunction("hour", new StandardSQLFunction("hour", Hibernate.INTEGER));
/*  85 */     registerFunction("minute", new StandardSQLFunction("minute", Hibernate.INTEGER));
/*  86 */     registerFunction("second", new StandardSQLFunction("second", Hibernate.INTEGER));
/*  87 */     registerFunction("dayname", new StandardSQLFunction("dayname", Hibernate.STRING));
/*  88 */     registerFunction("monthname", new StandardSQLFunction("monthname", Hibernate.STRING));
/*     */     
/*  90 */     registerFunction("abs", new StandardSQLFunction("abs"));
/*  91 */     registerFunction("sign", new StandardSQLFunction("sign", Hibernate.INTEGER));
/*     */     
/*  93 */     registerFunction("acos", new StandardSQLFunction("acos", Hibernate.DOUBLE));
/*  94 */     registerFunction("asin", new StandardSQLFunction("asin", Hibernate.DOUBLE));
/*  95 */     registerFunction("atan", new StandardSQLFunction("atan", Hibernate.DOUBLE));
/*  96 */     registerFunction("cos", new StandardSQLFunction("cos", Hibernate.DOUBLE));
/*  97 */     registerFunction("cot", new StandardSQLFunction("cot", Hibernate.DOUBLE));
/*  98 */     registerFunction("exp", new StandardSQLFunction("exp", Hibernate.DOUBLE));
/*  99 */     registerFunction("log", new StandardSQLFunction("log", Hibernate.DOUBLE));
/* 100 */     registerFunction("log10", new StandardSQLFunction("log10", Hibernate.DOUBLE));
/* 101 */     registerFunction("sin", new StandardSQLFunction("sin", Hibernate.DOUBLE));
/* 102 */     registerFunction("sqrt", new StandardSQLFunction("sqrt", Hibernate.DOUBLE));
/* 103 */     registerFunction("tan", new StandardSQLFunction("tan", Hibernate.DOUBLE));
/* 104 */     registerFunction("pi", new NoArgSQLFunction("pi", Hibernate.DOUBLE));
/* 105 */     registerFunction("rand", new StandardSQLFunction("rand", Hibernate.FLOAT));
/*     */     
/* 107 */     registerFunction("radians", new StandardSQLFunction("radians", Hibernate.DOUBLE));
/* 108 */     registerFunction("degrees", new StandardSQLFunction("degrees", Hibernate.DOUBLE));
/* 109 */     registerFunction("roundmagic", new StandardSQLFunction("roundmagic"));
/*     */     
/* 111 */     registerFunction("ceiling", new StandardSQLFunction("ceiling"));
/* 112 */     registerFunction("floor", new StandardSQLFunction("floor"));
/*     */     
/*     */ 
/* 115 */     registerFunction("mod", new StandardSQLFunction("mod", Hibernate.INTEGER));
/*     */     
/*     */ 
/* 118 */     registerFunction("concat", new VarArgsSQLFunction(Hibernate.STRING, "(", "||", ")"));
/*     */     
/* 120 */     getDefaultProperties().setProperty("hibernate.jdbc.batch_size", "15");
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 126 */       ReflectHelper.classForName("org.hsqldb.Database").getDeclaredField("schemaManager");
/* 127 */       this.schemaSupport = true;
/*     */     }
/*     */     catch (Throwable t) {
/* 130 */       this.schemaSupport = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public String getAddColumnString() {
/* 135 */     return "add column";
/*     */   }
/*     */   
/*     */   public boolean supportsIdentityColumns() {
/* 139 */     return true;
/*     */   }
/*     */   
/*     */   public String getIdentityColumnString() {
/* 143 */     return "generated by default as identity (start with 1)";
/*     */   }
/*     */   
/*     */   public String getIdentitySelectString() {
/* 147 */     return "call identity()";
/*     */   }
/*     */   
/*     */   public String getIdentityInsertString() {
/* 151 */     return "null";
/*     */   }
/*     */   
/*     */   public String getForUpdateString() {
/* 155 */     return "";
/*     */   }
/*     */   
/*     */   public boolean supportsUnique() {
/* 159 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsLimit() {
/* 163 */     return true;
/*     */   }
/*     */   
/*     */   public String getLimitString(String sql, boolean hasOffset) {
/* 167 */     return new StringBuffer(sql.length() + 10).append(sql).insert(sql.toLowerCase().indexOf("select") + 6, hasOffset ? " limit ? ?" : " top ?").toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean bindLimitParametersFirst()
/*     */   {
/* 174 */     return true;
/*     */   }
/*     */   
/*     */   public boolean supportsIfExistsAfterTableName() {
/* 178 */     return true;
/*     */   }
/*     */   
/*     */   public boolean supportsColumnCheck() {
/* 182 */     return false;
/*     */   }
/*     */   
/*     */   public String[] getCreateSequenceStrings(String sequenceName) {
/* 186 */     return new String[] { "create table dual_" + sequenceName + " (zero integer)", "insert into dual_" + sequenceName + " values (0)", "create sequence " + sequenceName + " start with 1" };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getDropSequenceStrings(String sequenceName)
/*     */   {
/* 194 */     return new String[] { "drop table dual_" + sequenceName + " if exists", "drop sequence " + sequenceName };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getSelectSequenceNextValString(String sequenceName)
/*     */   {
/* 201 */     return "next value for " + sequenceName;
/*     */   }
/*     */   
/*     */   public String getSequenceNextValString(String sequenceName) {
/* 205 */     return "select next value for " + sequenceName + " from dual_" + sequenceName;
/*     */   }
/*     */   
/*     */   public String getQuerySequencesString() {
/* 209 */     if (this.schemaSupport) {
/* 210 */       return "select sequence_name from information_schema.system_sequences";
/*     */     }
/*     */     
/* 213 */     return "select sequence_name from system_sequences";
/*     */   }
/*     */   
/*     */   public boolean supportsSequences()
/*     */   {
/* 218 */     return true;
/*     */   }
/*     */   
/*     */   public ViolatedConstraintNameExtracter getViolatedConstraintNameExtracter() {
/* 222 */     return EXTRACTER;
/*     */   }
/*     */   
/* 225 */   private static ViolatedConstraintNameExtracter EXTRACTER = new TemplatedViolatedConstraintNameExtracter()
/*     */   {
/*     */ 
/*     */ 
/*     */ 
/*     */     public String extractConstraintName(SQLException sqle)
/*     */     {
/*     */ 
/*     */ 
/* 234 */       String constraintName = null;
/*     */       
/* 236 */       int errorCode = JDBCExceptionHelper.extractErrorCode(sqle);
/*     */       
/* 238 */       if (errorCode == -8) {
/* 239 */         constraintName = extractUsingTemplate("Integrity constraint violation ", " table:", sqle.getMessage());
/*     */ 
/*     */ 
/*     */       }
/* 243 */       else if (errorCode == -9) {
/* 244 */         constraintName = extractUsingTemplate("Violation of unique index: ", " in statement [", sqle.getMessage());
/*     */ 
/*     */ 
/*     */       }
/* 248 */       else if (errorCode == -104) {
/* 249 */         constraintName = extractUsingTemplate("Unique constraint violation: ", " in statement [", sqle.getMessage());
/*     */ 
/*     */ 
/*     */       }
/* 253 */       else if (errorCode == 65359) {
/* 254 */         constraintName = extractUsingTemplate("Integrity constraint violation - no parent ", " table:", sqle.getMessage());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 259 */       return constraintName;
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsTemporaryTables()
/*     */   {
/* 269 */     return true;
/*     */   }
/*     */   
/*     */   public boolean supportsCurrentTimestampSelection() {
/* 273 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\HSQLDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */