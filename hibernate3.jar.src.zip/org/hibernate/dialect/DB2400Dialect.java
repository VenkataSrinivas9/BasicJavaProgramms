/*    */ package org.hibernate.dialect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DB2400Dialect
/*    */   extends DB2Dialect
/*    */ {
/*    */   public boolean supportsSequences()
/*    */   {
/* 12 */     return false;
/*    */   }
/*    */   
/*    */   public String getIdentitySelectString() {
/* 16 */     return "select identity_val_local() from sysibm.sysdummy1";
/*    */   }
/*    */   
/*    */   public boolean supportsLimit() {
/* 20 */     return true;
/*    */   }
/*    */   
/*    */   public boolean supportsLimitOffset() {
/* 24 */     return false;
/*    */   }
/*    */   
/*    */   public String getLimitString(String sql, int offset, int limit) {
/* 28 */     return sql.length() + 40 + sql + " fetch first " + limit + " rows only ";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean useMaxForLimit()
/*    */   {
/* 37 */     return true;
/*    */   }
/*    */   
/*    */   public boolean supportsVariableLimit() {
/* 41 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\DB2400Dialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */