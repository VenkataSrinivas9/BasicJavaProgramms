/*     */ package org.hibernate.dialect;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.dialect.function.VarArgsSQLFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InterbaseDialect
/*     */   extends Dialect
/*     */ {
/*     */   public InterbaseDialect()
/*     */   {
/*  18 */     registerColumnType(-7, "smallint");
/*  19 */     registerColumnType(-5, "numeric(18,0)");
/*  20 */     registerColumnType(5, "smallint");
/*  21 */     registerColumnType(-6, "smallint");
/*  22 */     registerColumnType(4, "integer");
/*  23 */     registerColumnType(1, "char(1)");
/*  24 */     registerColumnType(12, "varchar($l)");
/*  25 */     registerColumnType(6, "float");
/*  26 */     registerColumnType(8, "double precision");
/*  27 */     registerColumnType(91, "date");
/*  28 */     registerColumnType(92, "time");
/*  29 */     registerColumnType(93, "timestamp");
/*  30 */     registerColumnType(-3, "blob");
/*  31 */     registerColumnType(2, "numeric($p,$s)");
/*  32 */     registerColumnType(2004, "blob");
/*  33 */     registerColumnType(2005, "blob sub_type 1");
/*     */     
/*  35 */     registerFunction("concat", new VarArgsSQLFunction(Hibernate.STRING, "(", "||", ")"));
/*     */     
/*  37 */     getDefaultProperties().setProperty("hibernate.jdbc.batch_size", "0");
/*     */   }
/*     */   
/*     */   public String getAddColumnString() {
/*  41 */     return "add";
/*     */   }
/*     */   
/*     */   public String getSequenceNextValString(String sequenceName) {
/*  45 */     return "select " + getSelectSequenceNextValString(sequenceName) + " from RDB$DATABASE";
/*     */   }
/*     */   
/*     */   public String getSelectSequenceNextValString(String sequenceName) {
/*  49 */     return "gen_id( " + sequenceName + ", 1 )";
/*     */   }
/*     */   
/*     */   public String getCreateSequenceString(String sequenceName) {
/*  53 */     return "create generator " + sequenceName;
/*     */   }
/*     */   
/*     */   public String getDropSequenceString(String sequenceName) {
/*  57 */     return "delete from RDB$GENERATORS where RDB$GENERATOR_NAME = '" + sequenceName.toUpperCase() + "'";
/*     */   }
/*     */   
/*     */   public String getQuerySequencesString() {
/*  61 */     return "select RDB$GENERATOR_NAME from RDB$GENERATORS";
/*     */   }
/*     */   
/*     */   public String getForUpdateString() {
/*  65 */     return " with lock";
/*     */   }
/*     */   
/*  68 */   public String getForUpdateString(String aliases) { return " for update of " + aliases + " with lock"; }
/*     */   
/*     */   public boolean supportsSequences()
/*     */   {
/*  72 */     return true;
/*     */   }
/*     */   
/*     */   public boolean supportsLimit() {
/*  76 */     return true;
/*     */   }
/*     */   
/*     */   public String getLimitString(String sql, boolean hasOffset) {
/*  80 */     return sql.length() + 15 + sql + (hasOffset ? " rows ? to ?" : " rows ?");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean bindLimitParametersFirst()
/*     */   {
/*  87 */     return false;
/*     */   }
/*     */   
/*     */   public boolean bindLimitParametersInReverseOrder() {
/*  91 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getCurrentTimestampCallString()
/*     */   {
/*  98 */     return "{?= call CURRENT_TIMESTAMP }";
/*     */   }
/*     */   
/*     */   public boolean isCurrentTimestampSelectStringCallable()
/*     */   {
/* 103 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\InterbaseDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */