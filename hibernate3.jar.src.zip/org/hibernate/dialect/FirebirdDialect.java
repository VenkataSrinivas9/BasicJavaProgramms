/*    */ package org.hibernate.dialect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FirebirdDialect
/*    */   extends InterbaseDialect
/*    */ {
/*    */   public String getDropSequenceString(String sequenceName)
/*    */   {
/* 11 */     return "drop generator " + sequenceName;
/*    */   }
/*    */   
/*    */   public String getLimitString(String sql, boolean hasOffset) {
/* 15 */     return new StringBuffer(sql.length() + 20).append(sql).insert(6, hasOffset ? " first ? skip ?" : " first ?").toString();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean bindLimitParametersFirst()
/*    */   {
/* 22 */     return true;
/*    */   }
/*    */   
/*    */   public boolean bindLimitParametersInReverseOrder() {
/* 26 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\FirebirdDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */