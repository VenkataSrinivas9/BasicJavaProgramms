/*    */ package org.hibernate.dialect;
/*    */ 
/*    */ import org.hibernate.sql.JoinFragment;
/*    */ import org.hibernate.sql.Sybase11JoinFragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Sybase11Dialect
/*    */   extends SybaseDialect
/*    */ {
/*    */   public JoinFragment createOuterJoinFragment()
/*    */   {
/* 17 */     return new Sybase11JoinFragment();
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\Sybase11Dialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */