/*    */ package org.hibernate.dialect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FrontBaseDialect
/*    */   extends Dialect
/*    */ {
/*    */   public FrontBaseDialect()
/*    */   {
/* 27 */     registerColumnType(-7, "bit");
/* 28 */     registerColumnType(-5, "longint");
/* 29 */     registerColumnType(5, "smallint");
/* 30 */     registerColumnType(-6, "tinyint");
/* 31 */     registerColumnType(4, "integer");
/* 32 */     registerColumnType(1, "char(1)");
/* 33 */     registerColumnType(12, "varchar($l)");
/* 34 */     registerColumnType(6, "float");
/* 35 */     registerColumnType(8, "double precision");
/* 36 */     registerColumnType(91, "date");
/* 37 */     registerColumnType(92, "time");
/* 38 */     registerColumnType(93, "timestamp");
/* 39 */     registerColumnType(-3, "bit varying($l)");
/* 40 */     registerColumnType(2, "numeric($p,$s)");
/* 41 */     registerColumnType(2004, "blob");
/* 42 */     registerColumnType(2005, "clob");
/*    */   }
/*    */   
/*    */   public String getAddColumnString() {
/* 46 */     return "add column";
/*    */   }
/*    */   
/*    */   public String getCascadeConstraintsString() {
/* 50 */     return " cascade";
/*    */   }
/*    */   
/*    */   public boolean dropConstraints() {
/* 54 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getForUpdateString()
/*    */   {
/* 64 */     return "";
/*    */   }
/*    */   
/*    */   public String getCurrentTimestampCallString()
/*    */   {
/* 69 */     return "{?= call current_timestamp}";
/*    */   }
/*    */   
/*    */   public boolean isCurrentTimestampSelectStringCallable() {
/* 73 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\FrontBaseDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */