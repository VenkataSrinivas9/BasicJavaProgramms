/*     */ package org.hibernate.dialect;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.dialect.function.NoArgSQLFunction;
/*     */ import org.hibernate.dialect.function.NvlFunction;
/*     */ import org.hibernate.dialect.function.SQLFunctionTemplate;
/*     */ import org.hibernate.dialect.function.StandardSQLFunction;
/*     */ import org.hibernate.dialect.function.VarArgsSQLFunction;
/*     */ import org.hibernate.exception.JDBCExceptionHelper;
/*     */ import org.hibernate.exception.TemplatedViolatedConstraintNameExtracter;
/*     */ import org.hibernate.exception.ViolatedConstraintNameExtracter;
/*     */ import org.hibernate.util.ReflectHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Oracle9Dialect
/*     */   extends Dialect
/*     */ {
/*     */   public Oracle9Dialect()
/*     */   {
/*  30 */     registerColumnType(-7, "number(1,0)");
/*  31 */     registerColumnType(-5, "number(19,0)");
/*  32 */     registerColumnType(5, "number(5,0)");
/*  33 */     registerColumnType(-6, "number(3,0)");
/*  34 */     registerColumnType(4, "number(10,0)");
/*  35 */     registerColumnType(1, "char(1 char)");
/*  36 */     registerColumnType(12, 4000, "varchar2($l char)");
/*  37 */     registerColumnType(12, "long");
/*  38 */     registerColumnType(6, "float");
/*  39 */     registerColumnType(8, "double precision");
/*  40 */     registerColumnType(91, "date");
/*  41 */     registerColumnType(92, "date");
/*  42 */     registerColumnType(93, "timestamp");
/*  43 */     registerColumnType(-3, 2000, "raw($l)");
/*  44 */     registerColumnType(-3, "long raw");
/*  45 */     registerColumnType(2, "number($p,$s)");
/*  46 */     registerColumnType(2004, "blob");
/*  47 */     registerColumnType(2005, "clob");
/*     */     
/*  49 */     getDefaultProperties().setProperty("hibernate.jdbc.use_streams_for_binary", "true");
/*  50 */     getDefaultProperties().setProperty("hibernate.jdbc.batch_size", "15");
/*     */     
/*  52 */     registerFunction("abs", new StandardSQLFunction("abs"));
/*  53 */     registerFunction("sign", new StandardSQLFunction("sign", Hibernate.INTEGER));
/*     */     
/*  55 */     registerFunction("acos", new StandardSQLFunction("acos", Hibernate.DOUBLE));
/*  56 */     registerFunction("asin", new StandardSQLFunction("asin", Hibernate.DOUBLE));
/*  57 */     registerFunction("atan", new StandardSQLFunction("atan", Hibernate.DOUBLE));
/*  58 */     registerFunction("cos", new StandardSQLFunction("cos", Hibernate.DOUBLE));
/*  59 */     registerFunction("cosh", new StandardSQLFunction("cosh", Hibernate.DOUBLE));
/*  60 */     registerFunction("exp", new StandardSQLFunction("exp", Hibernate.DOUBLE));
/*  61 */     registerFunction("ln", new StandardSQLFunction("ln", Hibernate.DOUBLE));
/*  62 */     registerFunction("sin", new StandardSQLFunction("sin", Hibernate.DOUBLE));
/*  63 */     registerFunction("sinh", new StandardSQLFunction("sinh", Hibernate.DOUBLE));
/*  64 */     registerFunction("stddev", new StandardSQLFunction("stddev", Hibernate.DOUBLE));
/*  65 */     registerFunction("sqrt", new StandardSQLFunction("sqrt", Hibernate.DOUBLE));
/*  66 */     registerFunction("tan", new StandardSQLFunction("tan", Hibernate.DOUBLE));
/*  67 */     registerFunction("tanh", new StandardSQLFunction("tanh", Hibernate.DOUBLE));
/*  68 */     registerFunction("variance", new StandardSQLFunction("variance", Hibernate.DOUBLE));
/*     */     
/*  70 */     registerFunction("round", new StandardSQLFunction("round"));
/*  71 */     registerFunction("trunc", new StandardSQLFunction("trunc"));
/*  72 */     registerFunction("ceil", new StandardSQLFunction("ceil"));
/*  73 */     registerFunction("floor", new StandardSQLFunction("floor"));
/*     */     
/*  75 */     registerFunction("chr", new StandardSQLFunction("chr", Hibernate.CHARACTER));
/*  76 */     registerFunction("initcap", new StandardSQLFunction("initcap"));
/*  77 */     registerFunction("lower", new StandardSQLFunction("lower"));
/*  78 */     registerFunction("ltrim", new StandardSQLFunction("ltrim"));
/*  79 */     registerFunction("rtrim", new StandardSQLFunction("rtrim"));
/*  80 */     registerFunction("soundex", new StandardSQLFunction("soundex"));
/*  81 */     registerFunction("upper", new StandardSQLFunction("upper"));
/*  82 */     registerFunction("ascii", new StandardSQLFunction("ascii", Hibernate.INTEGER));
/*  83 */     registerFunction("length", new StandardSQLFunction("length", Hibernate.LONG));
/*     */     
/*  85 */     registerFunction("to_char", new StandardSQLFunction("to_char", Hibernate.STRING));
/*  86 */     registerFunction("to_date", new StandardSQLFunction("to_date", Hibernate.TIMESTAMP));
/*     */     
/*  88 */     registerFunction("current_date", new NoArgSQLFunction("current_date", Hibernate.DATE, false));
/*  89 */     registerFunction("current_time", new NoArgSQLFunction("current_timestamp", Hibernate.TIME, false));
/*  90 */     registerFunction("current_timestamp", new NoArgSQLFunction("current_timestamp", Hibernate.TIMESTAMP, false));
/*     */     
/*  92 */     registerFunction("lastday", new StandardSQLFunction("lastday", Hibernate.DATE));
/*  93 */     registerFunction("sysdate", new NoArgSQLFunction("sysdate", Hibernate.DATE, false));
/*  94 */     registerFunction("systimestamp", new NoArgSQLFunction("systimestamp", Hibernate.TIMESTAMP, false));
/*  95 */     registerFunction("uid", new NoArgSQLFunction("uid", Hibernate.INTEGER, false));
/*  96 */     registerFunction("user", new NoArgSQLFunction("user", Hibernate.STRING, false));
/*     */     
/*  98 */     registerFunction("rowid", new NoArgSQLFunction("rowid", Hibernate.LONG, false));
/*  99 */     registerFunction("rownum", new NoArgSQLFunction("rownum", Hibernate.LONG, false));
/*     */     
/*     */ 
/* 102 */     registerFunction("concat", new VarArgsSQLFunction(Hibernate.STRING, "", "||", ""));
/* 103 */     registerFunction("instr", new StandardSQLFunction("instr", Hibernate.INTEGER));
/* 104 */     registerFunction("instrb", new StandardSQLFunction("instrb", Hibernate.INTEGER));
/* 105 */     registerFunction("lpad", new StandardSQLFunction("lpad", Hibernate.STRING));
/* 106 */     registerFunction("replace", new StandardSQLFunction("replace", Hibernate.STRING));
/* 107 */     registerFunction("rpad", new StandardSQLFunction("rpad", Hibernate.STRING));
/* 108 */     registerFunction("substr", new StandardSQLFunction("substr", Hibernate.STRING));
/* 109 */     registerFunction("substrb", new StandardSQLFunction("substrb", Hibernate.STRING));
/* 110 */     registerFunction("translate", new StandardSQLFunction("translate", Hibernate.STRING));
/*     */     
/* 112 */     registerFunction("substring", new StandardSQLFunction("substr", Hibernate.STRING));
/* 113 */     registerFunction("locate", new StandardSQLFunction("instr", Hibernate.INTEGER));
/* 114 */     registerFunction("bit_length", new SQLFunctionTemplate(Hibernate.INTEGER, "vsize(?1)*8"));
/* 115 */     registerFunction("coalesce", new NvlFunction());
/*     */     
/*     */ 
/* 118 */     registerFunction("atan2", new StandardSQLFunction("atan2", Hibernate.FLOAT));
/* 119 */     registerFunction("log", new StandardSQLFunction("log", Hibernate.INTEGER));
/* 120 */     registerFunction("mod", new StandardSQLFunction("mod", Hibernate.INTEGER));
/* 121 */     registerFunction("nvl", new StandardSQLFunction("nvl"));
/* 122 */     registerFunction("nvl2", new StandardSQLFunction("nvl2"));
/* 123 */     registerFunction("power", new StandardSQLFunction("power", Hibernate.FLOAT));
/*     */     
/*     */ 
/* 126 */     registerFunction("add_months", new StandardSQLFunction("add_months", Hibernate.DATE));
/* 127 */     registerFunction("months_between", new StandardSQLFunction("months_between", Hibernate.FLOAT));
/* 128 */     registerFunction("next_day", new StandardSQLFunction("next_day", Hibernate.DATE));
/*     */     
/* 130 */     registerFunction("str", new StandardSQLFunction("to_char", Hibernate.STRING));
/*     */   }
/*     */   
/*     */   public String getAddColumnString() {
/* 134 */     return "add";
/*     */   }
/*     */   
/*     */   public String getSequenceNextValString(String sequenceName) {
/* 138 */     return "select " + getSelectSequenceNextValString(sequenceName) + " from dual";
/*     */   }
/*     */   
/*     */   public String getSelectSequenceNextValString(String sequenceName) {
/* 142 */     return sequenceName + ".nextval";
/*     */   }
/*     */   
/*     */   public String getCreateSequenceString(String sequenceName) {
/* 146 */     return "create sequence " + sequenceName;
/*     */   }
/*     */   
/*     */   public String getDropSequenceString(String sequenceName) {
/* 150 */     return "drop sequence " + sequenceName;
/*     */   }
/*     */   
/*     */   public String getCascadeConstraintsString() {
/* 154 */     return " cascade constraints";
/*     */   }
/*     */   
/*     */   public boolean dropConstraints() {
/* 158 */     return false;
/*     */   }
/*     */   
/*     */   public String getForUpdateNowaitString() {
/* 162 */     return " for update nowait";
/*     */   }
/*     */   
/*     */   public boolean supportsSequences() {
/* 166 */     return true;
/*     */   }
/*     */   
/*     */   public boolean supportsLimit() {
/* 170 */     return true;
/*     */   }
/*     */   
/*     */   public String getLimitString(String sql, boolean hasOffset)
/*     */   {
/* 175 */     sql = sql.trim();
/* 176 */     boolean isForUpdate = false;
/* 177 */     if (sql.toLowerCase().endsWith(" for update")) {
/* 178 */       sql = sql.substring(0, sql.length() - 11);
/* 179 */       isForUpdate = true;
/*     */     }
/*     */     
/* 182 */     StringBuffer pagingSelect = new StringBuffer(sql.length() + 100);
/* 183 */     if (hasOffset) {
/* 184 */       pagingSelect.append("select * from ( select row_.*, rownum rownum_ from ( ");
/*     */     }
/*     */     else {
/* 187 */       pagingSelect.append("select * from ( ");
/*     */     }
/* 189 */     pagingSelect.append(sql);
/* 190 */     if (hasOffset) {
/* 191 */       pagingSelect.append(" ) row_ where rownum <= ?) where rownum_ > ?");
/*     */     }
/*     */     else {
/* 194 */       pagingSelect.append(" ) where rownum <= ?");
/*     */     }
/*     */     
/* 197 */     if (isForUpdate) {
/* 198 */       pagingSelect.append(" for update");
/*     */     }
/*     */     
/* 201 */     return pagingSelect.toString();
/*     */   }
/*     */   
/*     */   public String getForUpdateString(String aliases) {
/* 205 */     return getForUpdateString() + " of " + aliases;
/*     */   }
/*     */   
/*     */   public String getForUpdateNowaitString(String aliases) {
/* 209 */     return getForUpdateString() + " of " + aliases + " nowait";
/*     */   }
/*     */   
/*     */   public boolean bindLimitParametersInReverseOrder() {
/* 213 */     return true;
/*     */   }
/*     */   
/*     */   public boolean useMaxForLimit() {
/* 217 */     return true;
/*     */   }
/*     */   
/*     */   public boolean forUpdateOfColumns() {
/* 221 */     return true;
/*     */   }
/*     */   
/*     */   public String getQuerySequencesString() {
/* 225 */     return "select sequence_name from user_sequences";
/*     */   }
/*     */   
/*     */   public String getSelectGUIDString() {
/* 229 */     return "select rawtohex(sys_guid()) from dual";
/*     */   }
/*     */   
/*     */   public ViolatedConstraintNameExtracter getViolatedConstraintNameExtracter() {
/* 233 */     return EXTRACTER;
/*     */   }
/*     */   
/* 236 */   private static ViolatedConstraintNameExtracter EXTRACTER = new TemplatedViolatedConstraintNameExtracter()
/*     */   {
/*     */ 
/*     */ 
/*     */ 
/*     */     public String extractConstraintName(SQLException sqle)
/*     */     {
/*     */ 
/*     */ 
/* 245 */       int errorCode = JDBCExceptionHelper.extractErrorCode(sqle);
/* 246 */       if ((errorCode == 1) || (errorCode == 2291) || (errorCode == 2292)) {
/* 247 */         return extractUsingTemplate("constraint (", ") violated", sqle.getMessage());
/*     */       }
/* 249 */       if (errorCode == 1400)
/*     */       {
/* 251 */         return null;
/*     */       }
/*     */       
/* 254 */       return null;
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 261 */   int oracletypes_cursor_value = 0;
/*     */   
/* 263 */   public int registerResultSetOutParameter(CallableStatement statement, int col) throws SQLException { if (this.oracletypes_cursor_value == 0) {
/*     */       try {
/* 265 */         Class types = ReflectHelper.classForName("oracle.jdbc.driver.OracleTypes");
/* 266 */         this.oracletypes_cursor_value = types.getField("CURSOR").getInt(types.newInstance());
/*     */       } catch (Exception se) {
/* 268 */         throw new HibernateException("Problem while trying to load or access OracleTypes.CURSOR value", se);
/*     */       }
/*     */     }
/*     */     
/* 272 */     statement.registerOutParameter(col, this.oracletypes_cursor_value);
/* 273 */     col++;
/* 274 */     return col;
/*     */   }
/*     */   
/*     */   public ResultSet getResultSet(CallableStatement ps) throws SQLException {
/* 278 */     ps.execute();
/* 279 */     ResultSet rs = (ResultSet)ps.getObject(1);
/* 280 */     return rs;
/*     */   }
/*     */   
/*     */   public boolean supportsUnionAll() {
/* 284 */     return true;
/*     */   }
/*     */   
/*     */   public boolean supportsCommentOn() {
/* 288 */     return true;
/*     */   }
/*     */   
/*     */   public boolean supportsTemporaryTables() {
/* 292 */     return true;
/*     */   }
/*     */   
/*     */   public String generateTemporaryTableName(String baseTableName) {
/* 296 */     String name = super.generateTemporaryTableName(baseTableName);
/* 297 */     return name.length() > 30 ? name.substring(1, 30) : name;
/*     */   }
/*     */   
/*     */   public String getCreateTemporaryTableString() {
/* 301 */     return "create global temporary table";
/*     */   }
/*     */   
/*     */   public String getCreateTemporaryTablePostfix() {
/* 305 */     return "on commit delete rows";
/*     */   }
/*     */   
/*     */   public boolean dropTemporaryTableAfterUse() {
/* 309 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsCurrentTimestampSelection() {
/* 313 */     return true;
/*     */   }
/*     */   
/*     */   public String getCurrentTimestampSelectString() {
/* 317 */     return "select systimestamp from dual";
/*     */   }
/*     */   
/*     */   public boolean isCurrentTimestampSelectStringCallable() {
/* 321 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\Oracle9Dialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */