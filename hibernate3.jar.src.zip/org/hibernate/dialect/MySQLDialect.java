/*     */ package org.hibernate.dialect;
/*     */ 
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.dialect.function.NoArgSQLFunction;
/*     */ import org.hibernate.dialect.function.StandardSQLFunction;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MySQLDialect
/*     */   extends Dialect
/*     */ {
/*     */   public MySQLDialect()
/*     */   {
/*  24 */     registerColumnType(-7, "bit");
/*  25 */     registerColumnType(-5, "bigint");
/*  26 */     registerColumnType(5, "smallint");
/*  27 */     registerColumnType(-6, "tinyint");
/*  28 */     registerColumnType(4, "integer");
/*  29 */     registerColumnType(1, "char(1)");
/*  30 */     registerColumnType(6, "float");
/*  31 */     registerColumnType(8, "double precision");
/*  32 */     registerColumnType(91, "date");
/*  33 */     registerColumnType(92, "time");
/*  34 */     registerColumnType(93, "datetime");
/*  35 */     registerColumnType(-3, "longblob");
/*  36 */     registerColumnType(-3, 16777215, "mediumblob");
/*  37 */     registerColumnType(-3, 65535, "blob");
/*  38 */     registerColumnType(-3, 255, "tinyblob");
/*  39 */     registerColumnType(2, "numeric($p,$s)");
/*  40 */     registerColumnType(2004, "longblob");
/*  41 */     registerColumnType(2004, 16777215, "mediumblob");
/*  42 */     registerColumnType(2004, 65535, "blob");
/*  43 */     registerColumnType(2005, "longtext");
/*  44 */     registerColumnType(2005, 16777215, "mediumtext");
/*  45 */     registerColumnType(2005, 65535, "text");
/*  46 */     registerVarcharTypes();
/*     */     
/*  48 */     registerFunction("ascii", new StandardSQLFunction("ascii", Hibernate.INTEGER));
/*  49 */     registerFunction("bin", new StandardSQLFunction("bin", Hibernate.STRING));
/*  50 */     registerFunction("char_length", new StandardSQLFunction("char_length", Hibernate.LONG));
/*  51 */     registerFunction("character_length", new StandardSQLFunction("character_length", Hibernate.LONG));
/*  52 */     registerFunction("lcase", new StandardSQLFunction("lcase"));
/*  53 */     registerFunction("lower", new StandardSQLFunction("lower"));
/*  54 */     registerFunction("length", new StandardSQLFunction("length", Hibernate.LONG));
/*  55 */     registerFunction("ltrim", new StandardSQLFunction("ltrim"));
/*  56 */     registerFunction("ord", new StandardSQLFunction("ord", Hibernate.INTEGER));
/*  57 */     registerFunction("quote", new StandardSQLFunction("quote"));
/*  58 */     registerFunction("reverse", new StandardSQLFunction("reverse"));
/*  59 */     registerFunction("rtrim", new StandardSQLFunction("rtrim"));
/*  60 */     registerFunction("soundex", new StandardSQLFunction("soundex"));
/*  61 */     registerFunction("space", new StandardSQLFunction("space", Hibernate.STRING));
/*  62 */     registerFunction("ucase", new StandardSQLFunction("ucase"));
/*  63 */     registerFunction("upper", new StandardSQLFunction("upper"));
/*  64 */     registerFunction("unhex", new StandardSQLFunction("unhex", Hibernate.STRING));
/*     */     
/*  66 */     registerFunction("abs", new StandardSQLFunction("abs"));
/*  67 */     registerFunction("sign", new StandardSQLFunction("sign", Hibernate.INTEGER));
/*     */     
/*  69 */     registerFunction("acos", new StandardSQLFunction("acos", Hibernate.DOUBLE));
/*  70 */     registerFunction("asin", new StandardSQLFunction("asin", Hibernate.DOUBLE));
/*  71 */     registerFunction("atan", new StandardSQLFunction("atan", Hibernate.DOUBLE));
/*  72 */     registerFunction("cos", new StandardSQLFunction("cos", Hibernate.DOUBLE));
/*  73 */     registerFunction("cot", new StandardSQLFunction("cot", Hibernate.DOUBLE));
/*  74 */     registerFunction("crc32", new StandardSQLFunction("crc32", Hibernate.LONG));
/*  75 */     registerFunction("exp", new StandardSQLFunction("exp", Hibernate.DOUBLE));
/*  76 */     registerFunction("ln", new StandardSQLFunction("ln", Hibernate.DOUBLE));
/*  77 */     registerFunction("log", new StandardSQLFunction("log", Hibernate.DOUBLE));
/*  78 */     registerFunction("log2", new StandardSQLFunction("log2", Hibernate.DOUBLE));
/*  79 */     registerFunction("log10", new StandardSQLFunction("log10", Hibernate.DOUBLE));
/*  80 */     registerFunction("pi", new NoArgSQLFunction("pi", Hibernate.DOUBLE));
/*  81 */     registerFunction("rand", new NoArgSQLFunction("rand", Hibernate.DOUBLE));
/*  82 */     registerFunction("sin", new StandardSQLFunction("sin", Hibernate.DOUBLE));
/*  83 */     registerFunction("sqrt", new StandardSQLFunction("sqrt", Hibernate.DOUBLE));
/*  84 */     registerFunction("tan", new StandardSQLFunction("tan", Hibernate.DOUBLE));
/*     */     
/*  86 */     registerFunction("radians", new StandardSQLFunction("radians", Hibernate.DOUBLE));
/*  87 */     registerFunction("degrees", new StandardSQLFunction("degrees", Hibernate.DOUBLE));
/*     */     
/*  89 */     registerFunction("ceiling", new StandardSQLFunction("ceiling", Hibernate.INTEGER));
/*  90 */     registerFunction("ceil", new StandardSQLFunction("ceil", Hibernate.INTEGER));
/*  91 */     registerFunction("floor", new StandardSQLFunction("floor", Hibernate.INTEGER));
/*  92 */     registerFunction("round", new StandardSQLFunction("round", Hibernate.INTEGER));
/*     */     
/*  94 */     registerFunction("datediff", new StandardSQLFunction("datediff", Hibernate.INTEGER));
/*  95 */     registerFunction("timediff", new StandardSQLFunction("timediff", Hibernate.TIME));
/*  96 */     registerFunction("date_format", new StandardSQLFunction("date_format", Hibernate.STRING));
/*     */     
/*  98 */     registerFunction("curdate", new NoArgSQLFunction("curdate", Hibernate.DATE));
/*  99 */     registerFunction("curtime", new NoArgSQLFunction("curtime", Hibernate.TIME));
/* 100 */     registerFunction("current_date", new NoArgSQLFunction("current_date", Hibernate.DATE, false));
/* 101 */     registerFunction("current_time", new NoArgSQLFunction("current_time", Hibernate.TIME, false));
/* 102 */     registerFunction("current_timestamp", new NoArgSQLFunction("current_timestamp", Hibernate.TIMESTAMP, false));
/* 103 */     registerFunction("date", new StandardSQLFunction("date", Hibernate.DATE));
/* 104 */     registerFunction("day", new StandardSQLFunction("day", Hibernate.INTEGER));
/* 105 */     registerFunction("dayofmonth", new StandardSQLFunction("dayofmonth", Hibernate.INTEGER));
/* 106 */     registerFunction("dayname", new StandardSQLFunction("dayname", Hibernate.STRING));
/* 107 */     registerFunction("dayofweek", new StandardSQLFunction("dayofweek", Hibernate.INTEGER));
/* 108 */     registerFunction("dayofyear", new StandardSQLFunction("dayofyear", Hibernate.INTEGER));
/* 109 */     registerFunction("from_days", new StandardSQLFunction("from_days", Hibernate.DATE));
/* 110 */     registerFunction("from_unixtime", new StandardSQLFunction("from_unixtime", Hibernate.TIMESTAMP));
/* 111 */     registerFunction("hour", new StandardSQLFunction("hour", Hibernate.INTEGER));
/* 112 */     registerFunction("last_day", new StandardSQLFunction("last_day", Hibernate.DATE));
/* 113 */     registerFunction("localtime", new NoArgSQLFunction("localtime", Hibernate.TIMESTAMP));
/* 114 */     registerFunction("localtimestamp", new NoArgSQLFunction("localtimestamp", Hibernate.TIMESTAMP));
/* 115 */     registerFunction("microseconds", new StandardSQLFunction("microseconds", Hibernate.INTEGER));
/* 116 */     registerFunction("minute", new StandardSQLFunction("minute", Hibernate.INTEGER));
/* 117 */     registerFunction("month", new StandardSQLFunction("month", Hibernate.INTEGER));
/* 118 */     registerFunction("monthname", new StandardSQLFunction("monthname", Hibernate.STRING));
/* 119 */     registerFunction("now", new NoArgSQLFunction("now", Hibernate.TIMESTAMP));
/* 120 */     registerFunction("quarter", new StandardSQLFunction("quarter", Hibernate.INTEGER));
/* 121 */     registerFunction("second", new StandardSQLFunction("second", Hibernate.INTEGER));
/* 122 */     registerFunction("sec_to_time", new StandardSQLFunction("sec_to_time", Hibernate.TIME));
/* 123 */     registerFunction("sysdate", new NoArgSQLFunction("sysdate", Hibernate.TIMESTAMP));
/* 124 */     registerFunction("time", new StandardSQLFunction("time", Hibernate.TIME));
/* 125 */     registerFunction("timestamp", new StandardSQLFunction("timestamp", Hibernate.TIMESTAMP));
/* 126 */     registerFunction("time_to_sec", new StandardSQLFunction("time_to_sec", Hibernate.INTEGER));
/* 127 */     registerFunction("to_days", new StandardSQLFunction("to_days", Hibernate.LONG));
/* 128 */     registerFunction("unix_timestamp", new StandardSQLFunction("unix_timestamp", Hibernate.LONG));
/* 129 */     registerFunction("utc_date", new NoArgSQLFunction("utc_date", Hibernate.STRING));
/* 130 */     registerFunction("utc_time", new NoArgSQLFunction("utc_time", Hibernate.STRING));
/* 131 */     registerFunction("utc_timestamp", new NoArgSQLFunction("utc_timestamp", Hibernate.STRING));
/* 132 */     registerFunction("week", new StandardSQLFunction("week", Hibernate.INTEGER));
/* 133 */     registerFunction("weekday", new StandardSQLFunction("weekday", Hibernate.INTEGER));
/* 134 */     registerFunction("weekofyear", new StandardSQLFunction("weekofyear", Hibernate.INTEGER));
/* 135 */     registerFunction("year", new StandardSQLFunction("year", Hibernate.INTEGER));
/* 136 */     registerFunction("yearweek", new StandardSQLFunction("yearweek", Hibernate.INTEGER));
/*     */     
/* 138 */     registerFunction("hex", new StandardSQLFunction("hex", Hibernate.STRING));
/* 139 */     registerFunction("oct", new StandardSQLFunction("oct", Hibernate.STRING));
/*     */     
/* 141 */     registerFunction("octet_length", new StandardSQLFunction("octet_length", Hibernate.LONG));
/* 142 */     registerFunction("bit_length", new StandardSQLFunction("bit_length", Hibernate.LONG));
/*     */     
/* 144 */     registerFunction("bit_count", new StandardSQLFunction("bit_count", Hibernate.LONG));
/* 145 */     registerFunction("encrypt", new StandardSQLFunction("encrypt", Hibernate.STRING));
/* 146 */     registerFunction("md5", new StandardSQLFunction("md5", Hibernate.STRING));
/* 147 */     registerFunction("sha1", new StandardSQLFunction("sha1", Hibernate.STRING));
/* 148 */     registerFunction("sha", new StandardSQLFunction("sha", Hibernate.STRING));
/*     */     
/* 150 */     registerFunction("concat", new StandardSQLFunction("concat", Hibernate.STRING));
/*     */     
/* 152 */     getDefaultProperties().setProperty("hibernate.max_fetch_depth", "2");
/* 153 */     getDefaultProperties().setProperty("hibernate.jdbc.batch_size", "15");
/*     */   }
/*     */   
/*     */   protected void registerVarcharTypes() {
/* 157 */     registerColumnType(12, "longtext");
/* 158 */     registerColumnType(12, 16777215, "mediumtext");
/* 159 */     registerColumnType(12, 65535, "text");
/* 160 */     registerColumnType(12, 255, "varchar($l)");
/*     */   }
/*     */   
/*     */   public String getAddColumnString() {
/* 164 */     return "add column";
/*     */   }
/*     */   
/*     */   public boolean qualifyIndexName() {
/* 168 */     return false;
/*     */   }
/*     */   
/*     */   public boolean supportsIdentityColumns() {
/* 172 */     return true;
/*     */   }
/*     */   
/*     */   public String getIdentitySelectString() {
/* 176 */     return "select last_insert_id()";
/*     */   }
/*     */   
/*     */   public String getIdentityColumnString() {
/* 180 */     return "not null auto_increment";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAddForeignKeyConstraintString(String constraintName, String[] foreignKey, String referencedTable, String[] primaryKey, boolean referencesPrimaryKey)
/*     */   {
/* 189 */     String cols = StringHelper.join(", ", foreignKey);
/* 190 */     return 30 + " add index " + constraintName + " (" + cols + "), add constraint " + constraintName + " foreign key (" + cols + ") references " + referencedTable + " (" + StringHelper.join(", ", primaryKey) + ')';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsLimit()
/*     */   {
/* 208 */     return true;
/*     */   }
/*     */   
/*     */   public String getDropForeignKeyString() {
/* 212 */     return " drop foreign key ";
/*     */   }
/*     */   
/*     */   public String getLimitString(String sql, boolean hasOffset) {
/* 216 */     return sql.length() + 20 + sql + (hasOffset ? " limit ?, ?" : " limit ?");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char closeQuote()
/*     */   {
/* 249 */     return '`';
/*     */   }
/*     */   
/*     */   public char openQuote() {
/* 253 */     return '`';
/*     */   }
/*     */   
/*     */   public boolean supportsIfExistsBeforeTableName() {
/* 257 */     return true;
/*     */   }
/*     */   
/*     */   public String getSelectGUIDString() {
/* 261 */     return "select uuid()";
/*     */   }
/*     */   
/*     */   public boolean supportsCascadeDelete() {
/* 265 */     return false;
/*     */   }
/*     */   
/*     */   public String getTableComment(String comment) {
/* 269 */     return " comment='" + comment + "'";
/*     */   }
/*     */   
/*     */   public String getColumnComment(String comment) {
/* 273 */     return " comment '" + comment + "'";
/*     */   }
/*     */   
/*     */   public boolean supportsTemporaryTables() {
/* 277 */     return true;
/*     */   }
/*     */   
/*     */   public String getCreateTemporaryTableString() {
/* 281 */     return "create temporary table if not exists";
/*     */   }
/*     */   
/*     */   public String getCastTypeName(int code) {
/* 285 */     if (code == 4) {
/* 286 */       return "signed";
/*     */     }
/* 288 */     if (code == 12) {
/* 289 */       return "char";
/*     */     }
/* 291 */     if (code == -3) {
/* 292 */       return "binary";
/*     */     }
/*     */     
/* 295 */     return super.getCastTypeName(code);
/*     */   }
/*     */   
/*     */   public boolean supportsCurrentTimestampSelection()
/*     */   {
/* 300 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isCurrentTimestampSelectStringCallable() {
/* 304 */     return false;
/*     */   }
/*     */   
/*     */   public String getCurrentTimestampSelectString() {
/* 308 */     return "select now()";
/*     */   }
/*     */   
/*     */   public int registerResultSetOutParameter(CallableStatement statement, int col) throws SQLException {
/* 312 */     return col;
/*     */   }
/*     */   
/*     */   public ResultSet getResultSet(CallableStatement ps) throws SQLException {
/* 316 */     boolean isResultSet = ps.execute();
/* 317 */     while ((!isResultSet) && (ps.getUpdateCount() != -1)) {
/* 318 */       isResultSet = ps.getMoreResults();
/*     */     }
/* 320 */     ResultSet rs = ps.getResultSet();
/* 321 */     return rs;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\dialect\MySQLDialect.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */