/*     */ package org.hibernate.exception;
/*     */ 
/*     */ import antlr.RecognitionException;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NestableRuntimeException
/*     */   extends RuntimeException
/*     */   implements Nestable
/*     */ {
/*  81 */   protected NestableDelegate delegate = new NestableDelegate(this);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  87 */   private Throwable cause = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NestableRuntimeException() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NestableRuntimeException(String msg)
/*     */   {
/* 104 */     super(msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NestableRuntimeException(Throwable cause)
/*     */   {
/* 116 */     this.cause = cause;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NestableRuntimeException(String msg, Throwable cause)
/*     */   {
/* 128 */     super(msg);
/* 129 */     this.cause = cause;
/*     */   }
/*     */   
/*     */   public Throwable getCause() {
/* 133 */     return this.cause;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 142 */     if (super.getMessage() != null) {
/* 143 */       return super.getMessage();
/*     */     }
/* 145 */     if (this.cause != null) {
/* 146 */       return this.cause.toString();
/*     */     }
/*     */     
/* 149 */     return null;
/*     */   }
/*     */   
/*     */   public String getMessage(int index)
/*     */   {
/* 154 */     if (index == 0) {
/* 155 */       return super.getMessage();
/*     */     }
/*     */     
/* 158 */     return this.delegate.getMessage(index);
/*     */   }
/*     */   
/*     */   public String[] getMessages()
/*     */   {
/* 163 */     return this.delegate.getMessages();
/*     */   }
/*     */   
/*     */   public Throwable getThrowable(int index) {
/* 167 */     return this.delegate.getThrowable(index);
/*     */   }
/*     */   
/*     */   public int getThrowableCount() {
/* 171 */     return this.delegate.getThrowableCount();
/*     */   }
/*     */   
/*     */   public Throwable[] getThrowables() {
/* 175 */     return this.delegate.getThrowables();
/*     */   }
/*     */   
/*     */   public int indexOfThrowable(Class type) {
/* 179 */     return this.delegate.indexOfThrowable(type, 0);
/*     */   }
/*     */   
/*     */   public int indexOfThrowable(Class type, int fromIndex) {
/* 183 */     return this.delegate.indexOfThrowable(type, fromIndex);
/*     */   }
/*     */   
/*     */   public void printStackTrace() {
/* 187 */     this.delegate.printStackTrace();
/*     */   }
/*     */   
/*     */   public void printStackTrace(PrintStream out) {
/* 191 */     this.delegate.printStackTrace(out);
/*     */   }
/*     */   
/*     */   public void printStackTrace(PrintWriter out) {
/* 195 */     this.delegate.printStackTrace(out);
/*     */   }
/*     */   
/*     */   public final void printPartialStackTrace(PrintWriter out) {
/* 199 */     super.printStackTrace(out);
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream oos)
/*     */     throws IOException
/*     */   {
/* 205 */     Throwable tempCause = this.cause;
/*     */     
/* 207 */     if ((this.cause instanceof RecognitionException)) {
/* 208 */       this.cause = null;
/*     */     }
/* 210 */     oos.defaultWriteObject();
/* 211 */     this.cause = tempCause;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\exception\NestableRuntimeException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */