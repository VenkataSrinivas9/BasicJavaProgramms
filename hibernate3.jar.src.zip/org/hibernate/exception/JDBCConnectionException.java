/*    */ package org.hibernate.exception;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import org.hibernate.JDBCException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JDBCConnectionException
/*    */   extends JDBCException
/*    */ {
/*    */   public JDBCConnectionException(String string, SQLException root)
/*    */   {
/* 16 */     super(string, root);
/*    */   }
/*    */   
/*    */   public JDBCConnectionException(String string, SQLException root, String sql) {
/* 20 */     super(string, root, sql);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\exception\JDBCConnectionException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */