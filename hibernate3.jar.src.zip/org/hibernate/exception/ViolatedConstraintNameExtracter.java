package org.hibernate.exception;

import java.sql.SQLException;

public abstract interface ViolatedConstraintNameExtracter
{
  public abstract String extractConstraintName(SQLException paramSQLException);
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\exception\ViolatedConstraintNameExtracter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */