package org.hibernate.exception;

import java.util.Properties;
import org.hibernate.HibernateException;

public abstract interface Configurable
{
  public abstract void configure(Properties paramProperties)
    throws HibernateException;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\exception\Configurable.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */