/*    */ package org.hibernate.exception;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import org.hibernate.JDBCException;
/*    */ import org.hibernate.util.JDBCExceptionReporter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JDBCExceptionHelper
/*    */ {
/*    */   public static JDBCException convert(SQLExceptionConverter converter, SQLException sqlException, String message)
/*    */   {
/* 29 */     return convert(converter, sqlException, message, "???");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static JDBCException convert(SQLExceptionConverter converter, SQLException sqlException, String message, String sql)
/*    */   {
/* 42 */     JDBCExceptionReporter.logExceptions(sqlException, message + " [" + sql + "]");
/* 43 */     return converter.convert(sqlException, message, sql);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static int extractErrorCode(SQLException sqlException)
/*    */   {
/* 53 */     int errorCode = sqlException.getErrorCode();
/* 54 */     SQLException nested = sqlException.getNextException();
/* 55 */     while ((errorCode == 0) && (nested != null)) {
/* 56 */       errorCode = nested.getErrorCode();
/* 57 */       nested = nested.getNextException();
/*    */     }
/* 59 */     return errorCode;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String extractSqlState(SQLException sqlException)
/*    */   {
/* 69 */     String sqlState = sqlException.getSQLState();
/* 70 */     SQLException nested = sqlException.getNextException();
/* 71 */     while ((sqlState == null) && (nested != null)) {
/* 72 */       sqlState = nested.getSQLState();
/* 73 */       nested = nested.getNextException();
/*    */     }
/* 75 */     return sqlState;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String extractSqlStateClassCode(SQLException sqlException)
/*    */   {
/* 85 */     String sqlState = extractSqlState(sqlException);
/*    */     
/* 87 */     if ((sqlState == null) || (sqlState.length() < 2)) {
/* 88 */       return sqlState;
/*    */     }
/*    */     
/* 91 */     return sqlState.substring(0, 2);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\exception\JDBCExceptionHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */