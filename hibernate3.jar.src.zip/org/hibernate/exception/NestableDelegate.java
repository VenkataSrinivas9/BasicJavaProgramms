/*     */ package org.hibernate.exception;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NestableDelegate
/*     */   implements Serializable
/*     */ {
/*     */   private static final String MUST_BE_THROWABLE = "The Nestable implementation passed to the NestableDelegate(Nestable) constructor must extend java.lang.Throwable";
/*  98 */   private Throwable nestable = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 106 */   private static boolean topDown = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 114 */   private static boolean trimStackFrames = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NestableDelegate(Nestable nestable)
/*     */   {
/* 125 */     if ((nestable instanceof Throwable)) {
/* 126 */       this.nestable = ((Throwable)nestable);
/*     */     }
/*     */     else {
/* 129 */       throw new IllegalArgumentException("The Nestable implementation passed to the NestableDelegate(Nestable) constructor must extend java.lang.Throwable");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(int index)
/*     */   {
/* 147 */     Throwable t = getThrowable(index);
/* 148 */     if (Nestable.class.isInstance(t)) {
/* 149 */       return ((Nestable)t).getMessage(0);
/*     */     }
/*     */     
/* 152 */     return t.getMessage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage(String baseMsg)
/*     */   {
/* 170 */     StringBuffer msg = new StringBuffer();
/* 171 */     if (baseMsg != null) {
/* 172 */       msg.append(baseMsg);
/*     */     }
/*     */     
/* 175 */     Throwable nestedCause = ExceptionUtils.getCause(this.nestable);
/* 176 */     if (nestedCause != null) {
/* 177 */       String causeMsg = nestedCause.getMessage();
/* 178 */       if (causeMsg != null) {
/* 179 */         if (baseMsg != null) {
/* 180 */           msg.append(": ");
/*     */         }
/* 182 */         msg.append(causeMsg);
/*     */       }
/*     */     }
/*     */     
/* 186 */     return msg.length() > 0 ? msg.toString() : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getMessages()
/*     */   {
/* 201 */     Throwable[] throwables = getThrowables();
/* 202 */     String[] msgs = new String[throwables.length];
/* 203 */     for (int i = 0; i < throwables.length; i++) {
/* 204 */       msgs[i] = (Nestable.class.isInstance(throwables[i]) ? ((Nestable)throwables[i]).getMessage(0) : throwables[i].getMessage());
/*     */     }
/*     */     
/*     */ 
/* 208 */     return msgs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Throwable getThrowable(int index)
/*     */   {
/* 224 */     if (index == 0) {
/* 225 */       return this.nestable;
/*     */     }
/* 227 */     Throwable[] throwables = getThrowables();
/* 228 */     return throwables[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getThrowableCount()
/*     */   {
/* 239 */     return ExceptionUtils.getThrowableCount(this.nestable);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Throwable[] getThrowables()
/*     */   {
/* 251 */     return ExceptionUtils.getThrowables(this.nestable);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int indexOfThrowable(Class type, int fromIndex)
/*     */   {
/* 271 */     if (fromIndex < 0) {
/* 272 */       throw new IndexOutOfBoundsException("The start index was out of bounds: " + fromIndex);
/*     */     }
/* 274 */     Throwable[] throwables = ExceptionUtils.getThrowables(this.nestable);
/* 275 */     if (fromIndex >= throwables.length) {
/* 276 */       throw new IndexOutOfBoundsException("The start index was out of bounds: " + fromIndex + " >= " + throwables.length);
/*     */     }
/*     */     
/* 279 */     for (int i = fromIndex; i < throwables.length; i++) {
/* 280 */       if (throwables[i].getClass().equals(type)) {
/* 281 */         return i;
/*     */       }
/*     */     }
/* 284 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace()
/*     */   {
/* 292 */     printStackTrace(System.err);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace(PrintStream out)
/*     */   {
/* 303 */     synchronized (out) {
/* 304 */       PrintWriter pw = new PrintWriter(out, false);
/* 305 */       printStackTrace(pw);
/*     */       
/* 307 */       pw.flush();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void printStackTrace(PrintWriter out)
/*     */   {
/* 323 */     Throwable throwable = this.nestable;
/*     */     
/* 325 */     if (ExceptionUtils.isThrowableNested()) {
/* 326 */       if ((throwable instanceof Nestable)) {
/* 327 */         ((Nestable)throwable).printPartialStackTrace(out);
/*     */       }
/*     */       else {
/* 330 */         throwable.printStackTrace(out);
/*     */       }
/* 332 */       return;
/*     */     }
/*     */     
/*     */ 
/* 336 */     List stacks = new ArrayList();
/* 337 */     while (throwable != null) {
/* 338 */       String[] st = getStackFrames(throwable);
/* 339 */       stacks.add(st);
/* 340 */       throwable = ExceptionUtils.getCause(throwable);
/*     */     }
/*     */     
/*     */ 
/* 344 */     String separatorLine = "Caused by: ";
/* 345 */     if (!topDown) {
/* 346 */       separatorLine = "Rethrown as: ";
/* 347 */       Collections.reverse(stacks);
/*     */     }
/*     */     
/*     */ 
/* 351 */     if (trimStackFrames) trimStackFrames(stacks);
/*     */     Iterator iter;
/* 353 */     synchronized (out) {
/* 354 */       for (iter = stacks.iterator(); iter.hasNext();) {
/* 355 */         String[] st = (String[])iter.next();
/* 356 */         int i = 0; for (int len = st.length; i < len; i++) {
/* 357 */           out.println(st[i]);
/*     */         }
/* 359 */         if (iter.hasNext()) { out.print(separatorLine);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String[] getStackFrames(Throwable t)
/*     */   {
/* 374 */     StringWriter sw = new StringWriter();
/* 375 */     PrintWriter pw = new PrintWriter(sw, true);
/*     */     
/*     */ 
/* 378 */     if ((t instanceof Nestable)) {
/* 379 */       ((Nestable)t).printPartialStackTrace(pw);
/*     */     }
/*     */     else {
/* 382 */       t.printStackTrace(pw);
/*     */     }
/* 384 */     return ExceptionUtils.getStackFrames(sw.getBuffer().toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void trimStackFrames(List stacks)
/*     */   {
/* 396 */     int size = stacks.size(); for (int i = size - 1; i > 0; i--) {
/* 397 */       String[] curr = (String[])stacks.get(i);
/* 398 */       String[] next = (String[])stacks.get(i - 1);
/*     */       
/* 400 */       List currList = new ArrayList(Arrays.asList(curr));
/* 401 */       List nextList = new ArrayList(Arrays.asList(next));
/* 402 */       ExceptionUtils.removeCommonFrames(currList, nextList);
/*     */       
/* 404 */       int trimmed = curr.length - currList.size();
/* 405 */       if (trimmed > 0) {
/* 406 */         currList.add("\t... " + trimmed + " more");
/* 407 */         stacks.set(i, currList.toArray(new String[currList.size()]));
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\exception\NestableDelegate.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */