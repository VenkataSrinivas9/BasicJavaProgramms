/*    */ package org.hibernate.exception;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.hibernate.JDBCException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SQLStateConverter
/*    */   implements SQLExceptionConverter
/*    */ {
/*    */   private ViolatedConstraintNameExtracter extracter;
/* 23 */   private static final Set SQL_GRAMMAR_CATEGORIES = new HashSet();
/* 24 */   private static final Set DATA_CATEGORIES = new HashSet();
/* 25 */   private static final Set INTEGRITY_VIOLATION_CATEGORIES = new HashSet();
/* 26 */   private static final Set CONNECTION_CATEGORIES = new HashSet();
/*    */   
/*    */   static {
/* 29 */     SQL_GRAMMAR_CATEGORIES.add("07");
/* 30 */     SQL_GRAMMAR_CATEGORIES.add("37");
/* 31 */     SQL_GRAMMAR_CATEGORIES.add("42");
/* 32 */     SQL_GRAMMAR_CATEGORIES.add("65");
/* 33 */     SQL_GRAMMAR_CATEGORIES.add("S0");
/* 34 */     SQL_GRAMMAR_CATEGORIES.add("20");
/*    */     
/* 36 */     DATA_CATEGORIES.add("22");
/* 37 */     DATA_CATEGORIES.add("21");
/* 38 */     DATA_CATEGORIES.add("02");
/*    */     
/* 40 */     INTEGRITY_VIOLATION_CATEGORIES.add("23");
/* 41 */     INTEGRITY_VIOLATION_CATEGORIES.add("27");
/* 42 */     INTEGRITY_VIOLATION_CATEGORIES.add("44");
/*    */     
/* 44 */     CONNECTION_CATEGORIES.add("08");
/*    */   }
/*    */   
/*    */   public SQLStateConverter(ViolatedConstraintNameExtracter extracter) {
/* 48 */     this.extracter = extracter;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public JDBCException convert(SQLException sqlException, String message, String sql)
/*    */   {
/* 61 */     String sqlStateClassCode = JDBCExceptionHelper.extractSqlStateClassCode(sqlException);
/*    */     
/* 63 */     if (sqlStateClassCode != null) {
/* 64 */       if (SQL_GRAMMAR_CATEGORIES.contains(sqlStateClassCode)) {
/* 65 */         return new SQLGrammarException(message, sqlException, sql);
/*    */       }
/* 67 */       if (INTEGRITY_VIOLATION_CATEGORIES.contains(sqlStateClassCode)) {
/* 68 */         String constraintName = this.extracter.extractConstraintName(sqlException);
/* 69 */         return new ConstraintViolationException(message, sqlException, sql, constraintName);
/*    */       }
/* 71 */       if (CONNECTION_CATEGORIES.contains(sqlStateClassCode)) {
/* 72 */         return new JDBCConnectionException(message, sqlException, sql);
/*    */       }
/* 74 */       if (DATA_CATEGORIES.contains(sqlStateClassCode)) {
/* 75 */         return new DataException(message, sqlException, sql);
/*    */       }
/*    */     }
/*    */     
/* 79 */     return handledNonSpecificException(sqlException, message, sql);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected JDBCException handledNonSpecificException(SQLException sqlException, String message, String sql)
/*    */   {
/* 91 */     return new GenericJDBCException(message, sqlException, sql);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\exception\SQLStateConverter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */