/*    */ package org.hibernate.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TemplatedViolatedConstraintNameExtracter
/*    */   implements ViolatedConstraintNameExtracter
/*    */ {
/*    */   protected String extractUsingTemplate(String templateStart, String templateEnd, String message)
/*    */   {
/* 23 */     int templateStartPosition = message.indexOf(templateStart);
/* 24 */     if (templateStartPosition < 0) {
/* 25 */       return null;
/*    */     }
/*    */     
/* 28 */     int start = templateStartPosition + templateStart.length();
/* 29 */     int end = message.indexOf(templateEnd, start);
/* 30 */     if (end < 0) {
/* 31 */       end = message.length();
/*    */     }
/*    */     
/* 34 */     return message.substring(start, end);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\exception\TemplatedViolatedConstraintNameExtracter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */