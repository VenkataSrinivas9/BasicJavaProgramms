/*    */ package org.hibernate.exception;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import org.hibernate.JDBCException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataException
/*    */   extends JDBCException
/*    */ {
/*    */   public DataException(String message, SQLException root)
/*    */   {
/* 22 */     super(message, root);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public DataException(String message, SQLException root, String sql)
/*    */   {
/* 32 */     super(message, root, sql);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\exception\DataException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */