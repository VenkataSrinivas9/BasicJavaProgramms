/*     */ package org.hibernate.exception;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.JDBCException;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.util.ReflectHelper;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLExceptionConverterFactory
/*     */ {
/*  24 */   private static final Log log = LogFactory.getLog(SQLExceptionConverterFactory.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SQLExceptionConverter buildSQLExceptionConverter(Dialect dialect, Properties properties)
/*     */     throws HibernateException
/*     */   {
/*  44 */     SQLExceptionConverter converter = null;
/*     */     
/*  46 */     String converterClassName = (String)properties.get("hibernate.jdbc.sql_exception_converter");
/*  47 */     if (StringHelper.isNotEmpty(converterClassName)) {
/*  48 */       converter = constructConverter(converterClassName, dialect.getViolatedConstraintNameExtracter());
/*     */     }
/*     */     
/*  51 */     if (converter == null) {
/*  52 */       log.trace("Using dialect defined converter");
/*  53 */       converter = dialect.buildSQLExceptionConverter();
/*     */     }
/*     */     
/*  56 */     if ((converter instanceof Configurable)) {
/*     */       try {
/*  58 */         ((Configurable)converter).configure(properties);
/*     */       }
/*     */       catch (HibernateException e) {
/*  61 */         log.warn("Unable to configure SQLExceptionConverter", e);
/*  62 */         throw e;
/*     */       }
/*     */     }
/*     */     
/*  66 */     return converter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SQLExceptionConverter buildMinimalSQLExceptionConverter()
/*     */   {
/*  76 */     new SQLExceptionConverter() {
/*     */       public JDBCException convert(SQLException sqlException, String message, String sql) {
/*  78 */         return new GenericJDBCException(message, sqlException, sql);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   private static SQLExceptionConverter constructConverter(String converterClassName, ViolatedConstraintNameExtracter violatedConstraintNameExtracter) {
/*     */     try {
/*  85 */       log.trace("Attempting to construct instance of specified SQLExceptionConverter [" + converterClassName + "]");
/*  86 */       Class converterClass = ReflectHelper.classForName(converterClassName);
/*     */       
/*     */ 
/*  89 */       Constructor[] ctors = converterClass.getDeclaredConstructors();
/*  90 */       for (int i = 0; i < ctors.length; i++) {
/*  91 */         if ((ctors[i].getParameterTypes() != null) && (ctors[i].getParameterTypes().length == 1) && 
/*  92 */           (ViolatedConstraintNameExtracter.class.isAssignableFrom(ctors[i].getParameterTypes()[0]))) {
/*     */           try {
/*  94 */             return (SQLExceptionConverter)ctors[i].newInstance(new Object[] { violatedConstraintNameExtracter });
/*     */           }
/*     */           catch (Throwable t) {}
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */       return (SQLExceptionConverter)converterClass.newInstance();
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 109 */       log.warn("Unable to construct instance of specified SQLExceptionConverter", t);
/*     */     }
/*     */     
/* 112 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\exception\SQLExceptionConverterFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */