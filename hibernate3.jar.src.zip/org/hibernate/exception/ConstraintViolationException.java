/*    */ package org.hibernate.exception;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import org.hibernate.JDBCException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstraintViolationException
/*    */   extends JDBCException
/*    */ {
/*    */   private String constraintName;
/*    */   
/*    */   public ConstraintViolationException(String message, SQLException root, String constraintName)
/*    */   {
/* 19 */     super(message, root);
/* 20 */     this.constraintName = constraintName;
/*    */   }
/*    */   
/*    */   public ConstraintViolationException(String message, SQLException root, String sql, String constraintName) {
/* 24 */     super(message, root, sql);
/* 25 */     this.constraintName = constraintName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getConstraintName()
/*    */   {
/* 34 */     return this.constraintName;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\exception\ConstraintViolationException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */