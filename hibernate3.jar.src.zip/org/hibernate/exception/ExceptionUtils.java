/*     */ package org.hibernate.exception;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import org.hibernate.util.ArrayHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExceptionUtils
/*     */ {
/*  84 */   private static final String LINE_SEPARATOR = System.getProperty("line.separator");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String WRAPPED_MARKER = " [wrapped] ";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  97 */   private static final String[] CAUSE_METHOD_NAMES = { "getCause", "getNextException", "getTargetException", "getException", "getSourceException", "getRootCause", "getCausedByException", "getNested" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final Method THROWABLE_CAUSE_METHOD;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*     */     Method getCauseMethod;
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 116 */       getCauseMethod = Throwable.class.getMethod("getCause", null);
/*     */     } catch (Exception e) {
/*     */       Method getCauseMethod;
/* 119 */       getCauseMethod = null;
/*     */     }
/* 121 */     THROWABLE_CAUSE_METHOD = getCauseMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Throwable getCause(Throwable throwable)
/*     */   {
/* 175 */     return getCause(throwable, CAUSE_METHOD_NAMES);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Throwable getCause(Throwable throwable, String[] methodNames)
/*     */   {
/* 196 */     if (throwable == null) {
/* 197 */       return null;
/*     */     }
/* 199 */     Throwable cause = getCauseUsingWellKnownTypes(throwable);
/* 200 */     if (cause == null) {
/* 201 */       if (methodNames == null) {
/* 202 */         methodNames = CAUSE_METHOD_NAMES;
/*     */       }
/* 204 */       for (int i = 0; i < methodNames.length; i++) {
/* 205 */         String methodName = methodNames[i];
/* 206 */         if (methodName != null) {
/* 207 */           cause = getCauseUsingMethodName(throwable, methodName);
/* 208 */           if (cause != null) {
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 214 */       if (cause == null) {
/* 215 */         cause = getCauseUsingFieldName(throwable, "detail");
/*     */       }
/*     */     }
/* 218 */     return cause;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Throwable getRootCause(Throwable throwable)
/*     */   {
/* 233 */     Throwable cause = getCause(throwable);
/* 234 */     if (cause != null) {
/* 235 */       throwable = cause;
/* 236 */       while ((throwable = getCause(throwable)) != null) {
/* 237 */         cause = throwable;
/*     */       }
/*     */     }
/* 240 */     return cause;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Throwable getCauseUsingWellKnownTypes(Throwable throwable)
/*     */   {
/* 254 */     if ((throwable instanceof Nestable)) {
/* 255 */       return ((Nestable)throwable).getCause();
/*     */     }
/* 257 */     if ((throwable instanceof SQLException)) {
/* 258 */       return ((SQLException)throwable).getNextException();
/*     */     }
/* 260 */     if ((throwable instanceof InvocationTargetException)) {
/* 261 */       return ((InvocationTargetException)throwable).getTargetException();
/*     */     }
/*     */     
/* 264 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Throwable getCauseUsingMethodName(Throwable throwable, String methodName)
/*     */   {
/* 276 */     Method method = null;
/*     */     try {
/* 278 */       method = throwable.getClass().getMethod(methodName, null);
/*     */     }
/*     */     catch (NoSuchMethodException ignored) {}catch (SecurityException ignored) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 285 */     if ((method != null) && (Throwable.class.isAssignableFrom(method.getReturnType()))) {
/*     */       try {
/* 287 */         return (Throwable)method.invoke(throwable, ArrayHelper.EMPTY_OBJECT_ARRAY);
/*     */       }
/*     */       catch (IllegalAccessException ignored) {}catch (IllegalArgumentException ignored) {}catch (InvocationTargetException ignored) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 296 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Throwable getCauseUsingFieldName(Throwable throwable, String fieldName)
/*     */   {
/* 307 */     Field field = null;
/*     */     try {
/* 309 */       field = throwable.getClass().getField(fieldName);
/*     */     }
/*     */     catch (NoSuchFieldException ignored) {}catch (SecurityException ignored) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 316 */     if ((field != null) && (Throwable.class.isAssignableFrom(field.getType()))) {
/*     */       try {
/* 318 */         return (Throwable)field.get(throwable);
/*     */       }
/*     */       catch (IllegalAccessException ignored) {}catch (IllegalArgumentException ignored) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 325 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isThrowableNested()
/*     */   {
/* 338 */     return THROWABLE_CAUSE_METHOD != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isNestedThrowable(Throwable throwable)
/*     */   {
/* 351 */     if (throwable == null) {
/* 352 */       return false;
/*     */     }
/*     */     
/* 355 */     if ((throwable instanceof Nestable)) {
/* 356 */       return true;
/*     */     }
/* 358 */     if ((throwable instanceof SQLException)) {
/* 359 */       return true;
/*     */     }
/* 361 */     if ((throwable instanceof InvocationTargetException)) {
/* 362 */       return true;
/*     */     }
/* 364 */     if (isThrowableNested()) {
/* 365 */       return true;
/*     */     }
/*     */     
/* 368 */     Class cls = throwable.getClass();
/* 369 */     int i = 0; for (int isize = CAUSE_METHOD_NAMES.length; i < isize; i++) {
/*     */       try {
/* 371 */         Method method = cls.getMethod(CAUSE_METHOD_NAMES[i], null);
/* 372 */         if ((method != null) && (Throwable.class.isAssignableFrom(method.getReturnType()))) {
/* 373 */           return true;
/*     */         }
/*     */       }
/*     */       catch (NoSuchMethodException ignored) {}catch (SecurityException ignored) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 383 */       Field field = cls.getField("detail");
/* 384 */       if (field != null) {
/* 385 */         return true;
/*     */       }
/*     */     }
/*     */     catch (NoSuchFieldException ignored) {}catch (SecurityException ignored) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 393 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getThrowableCount(Throwable throwable)
/*     */   {
/* 409 */     int count = 0;
/* 410 */     while (throwable != null) {
/* 411 */       count++;
/* 412 */       throwable = getCause(throwable);
/*     */     }
/* 414 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Throwable[] getThrowables(Throwable throwable)
/*     */   {
/* 431 */     List list = new ArrayList();
/* 432 */     while (throwable != null) {
/* 433 */       list.add(throwable);
/* 434 */       throwable = getCause(throwable);
/*     */     }
/* 436 */     return (Throwable[])list.toArray(new Throwable[list.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int indexOfThrowable(Throwable throwable, Class type)
/*     */   {
/* 453 */     return indexOfThrowable(throwable, type, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int indexOfThrowable(Throwable throwable, Class type, int fromIndex)
/*     */   {
/* 474 */     if (throwable == null) {
/* 475 */       return -1;
/*     */     }
/* 477 */     if (fromIndex < 0) {
/* 478 */       fromIndex = 0;
/*     */     }
/* 480 */     Throwable[] throwables = getThrowables(throwable);
/* 481 */     if (fromIndex >= throwables.length) {
/* 482 */       return -1;
/*     */     }
/* 484 */     for (int i = fromIndex; i < throwables.length; i++) {
/* 485 */       if (throwables[i].getClass().equals(type)) {
/* 486 */         return i;
/*     */       }
/*     */     }
/* 489 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void printRootCauseStackTrace(Throwable throwable)
/*     */   {
/* 509 */     printRootCauseStackTrace(throwable, System.err);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void printRootCauseStackTrace(Throwable throwable, PrintStream stream)
/*     */   {
/* 529 */     if (throwable == null) {
/* 530 */       return;
/*     */     }
/* 532 */     if (stream == null) {
/* 533 */       throw new IllegalArgumentException("The PrintStream must not be null");
/*     */     }
/* 535 */     String[] trace = getRootCauseStackTrace(throwable);
/* 536 */     for (int i = 0; i < trace.length; i++) {
/* 537 */       stream.println(trace[i]);
/*     */     }
/* 539 */     stream.flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void printRootCauseStackTrace(Throwable throwable, PrintWriter writer)
/*     */   {
/* 559 */     if (throwable == null) {
/* 560 */       return;
/*     */     }
/* 562 */     if (writer == null) {
/* 563 */       throw new IllegalArgumentException("The PrintWriter must not be null");
/*     */     }
/* 565 */     String[] trace = getRootCauseStackTrace(throwable);
/* 566 */     for (int i = 0; i < trace.length; i++) {
/* 567 */       writer.println(trace[i]);
/*     */     }
/* 569 */     writer.flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] getRootCauseStackTrace(Throwable throwable)
/*     */   {
/* 582 */     if (throwable == null) {
/* 583 */       return ArrayHelper.EMPTY_STRING_ARRAY;
/*     */     }
/* 585 */     Throwable[] throwables = getThrowables(throwable);
/* 586 */     int count = throwables.length;
/* 587 */     ArrayList frames = new ArrayList();
/* 588 */     List nextTrace = getStackFrameList(throwables[(count - 1)]);
/* 589 */     int i = count; for (;;) { i--; if (i < 0) break;
/* 590 */       List trace = nextTrace;
/* 591 */       if (i != 0) {
/* 592 */         nextTrace = getStackFrameList(throwables[(i - 1)]);
/* 593 */         removeCommonFrames(trace, nextTrace);
/*     */       }
/* 595 */       if (i == count - 1) {
/* 596 */         frames.add(throwables[i].toString());
/*     */       }
/*     */       else {
/* 599 */         frames.add(" [wrapped] " + throwables[i].toString());
/*     */       }
/* 601 */       for (int j = 0; j < trace.size(); j++) {
/* 602 */         frames.add(trace.get(j));
/*     */       }
/*     */     }
/* 605 */     return (String[])frames.toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void removeCommonFrames(List causeFrames, List wrapperFrames)
/*     */   {
/* 617 */     if ((causeFrames == null) || (wrapperFrames == null)) {
/* 618 */       throw new IllegalArgumentException("The List must not be null");
/*     */     }
/* 620 */     int causeFrameIndex = causeFrames.size() - 1;
/* 621 */     int wrapperFrameIndex = wrapperFrames.size() - 1;
/* 622 */     while ((causeFrameIndex >= 0) && (wrapperFrameIndex >= 0))
/*     */     {
/*     */ 
/* 625 */       String causeFrame = (String)causeFrames.get(causeFrameIndex);
/* 626 */       String wrapperFrame = (String)wrapperFrames.get(wrapperFrameIndex);
/* 627 */       if (causeFrame.equals(wrapperFrame)) {
/* 628 */         causeFrames.remove(causeFrameIndex);
/*     */       }
/* 630 */       causeFrameIndex--;
/* 631 */       wrapperFrameIndex--;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getStackTrace(Throwable throwable)
/*     */   {
/* 644 */     StringWriter sw = new StringWriter();
/* 645 */     PrintWriter pw = new PrintWriter(sw, true);
/* 646 */     throwable.printStackTrace(pw);
/* 647 */     return sw.getBuffer().toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getFullStackTrace(Throwable throwable)
/*     */   {
/* 658 */     StringWriter sw = new StringWriter();
/* 659 */     PrintWriter pw = new PrintWriter(sw, true);
/* 660 */     Throwable[] ts = getThrowables(throwable);
/* 661 */     for (int i = 0; i < ts.length; i++) {
/* 662 */       ts[i].printStackTrace(pw);
/* 663 */       if (isNestedThrowable(ts[i])) {
/*     */         break;
/*     */       }
/*     */     }
/* 667 */     return sw.getBuffer().toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] getStackFrames(Throwable throwable)
/*     */   {
/* 680 */     if (throwable == null) {
/* 681 */       return ArrayHelper.EMPTY_STRING_ARRAY;
/*     */     }
/* 683 */     return getStackFrames(getStackTrace(throwable));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String[] getStackFrames(String stackTrace)
/*     */   {
/* 693 */     String linebreak = LINE_SEPARATOR;
/* 694 */     StringTokenizer frames = new StringTokenizer(stackTrace, linebreak);
/* 695 */     List list = new LinkedList();
/* 696 */     while (frames.hasMoreTokens()) {
/* 697 */       list.add(frames.nextToken());
/*     */     }
/* 699 */     return (String[])list.toArray(new String[list.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static List getStackFrameList(Throwable t)
/*     */   {
/* 714 */     String stackTrace = getStackTrace(t);
/* 715 */     String linebreak = LINE_SEPARATOR;
/* 716 */     StringTokenizer frames = new StringTokenizer(stackTrace, linebreak);
/* 717 */     List list = new LinkedList();
/* 718 */     boolean traceStarted = false;
/* 719 */     while (frames.hasMoreTokens()) {
/* 720 */       String token = frames.nextToken();
/*     */       
/* 722 */       int at = token.indexOf("at");
/* 723 */       if ((at != -1) && (token.substring(0, at).trim().length() == 0)) {
/* 724 */         traceStarted = true;
/* 725 */         list.add(token);
/*     */       } else {
/* 727 */         if (traceStarted)
/*     */           break;
/*     */       }
/*     */     }
/* 731 */     return list;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\exception\ExceptionUtils.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */