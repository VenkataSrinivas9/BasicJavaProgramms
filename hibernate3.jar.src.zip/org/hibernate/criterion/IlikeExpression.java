/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.dialect.Dialect;
/*    */ import org.hibernate.dialect.PostgreSQLDialect;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.engine.TypedValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IlikeExpression
/*    */   implements Criterion
/*    */ {
/*    */   private final String propertyName;
/*    */   private final Object value;
/*    */   
/*    */   protected IlikeExpression(String propertyName, Object value)
/*    */   {
/* 21 */     this.propertyName = propertyName;
/* 22 */     this.value = value;
/*    */   }
/*    */   
/*    */   protected IlikeExpression(String propertyName, String value, MatchMode matchMode) {
/* 26 */     this(propertyName, matchMode.toMatchString(value));
/*    */   }
/*    */   
/*    */   public String toSqlString(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 31 */     Dialect dialect = criteriaQuery.getFactory().getDialect();
/* 32 */     String[] columns = criteriaQuery.getColumnsUsingProjection(criteria, this.propertyName);
/* 33 */     if (columns.length != 1) throw new HibernateException("ilike may only be used with single-column properties");
/* 34 */     if ((dialect instanceof PostgreSQLDialect)) {
/* 35 */       return columns[0] + " ilike ?";
/*    */     }
/*    */     
/* 38 */     return dialect.getLowercaseFunction() + '(' + columns[0] + ") like ?";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public TypedValue[] getTypedValues(Criteria criteria, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 46 */     return new TypedValue[] { criteriaQuery.getTypedValue(criteria, this.propertyName, this.value.toString().toLowerCase()) };
/*    */   }
/*    */   
/*    */   public String toString() {
/* 50 */     return this.propertyName + " ilike " + this.value;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\IlikeExpression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */