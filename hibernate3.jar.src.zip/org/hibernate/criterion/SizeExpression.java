/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.EntityMode;
/*    */ import org.hibernate.Hibernate;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.engine.TypedValue;
/*    */ import org.hibernate.persister.collection.QueryableCollection;
/*    */ import org.hibernate.persister.entity.Loadable;
/*    */ import org.hibernate.sql.ConditionFragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SizeExpression
/*    */   implements Criterion
/*    */ {
/*    */   private final String propertyName;
/*    */   private final int size;
/*    */   private final String op;
/*    */   
/*    */   protected SizeExpression(String propertyName, int size, String op)
/*    */   {
/* 24 */     this.propertyName = propertyName;
/* 25 */     this.size = size;
/* 26 */     this.op = op;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 30 */     return this.propertyName + ".size" + this.op + this.size;
/*    */   }
/*    */   
/*    */   public String toSqlString(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 35 */     String role = criteriaQuery.getEntityName(criteria, this.propertyName) + '.' + criteriaQuery.getPropertyName(this.propertyName);
/*    */     
/*    */ 
/* 38 */     QueryableCollection cp = (QueryableCollection)criteriaQuery.getFactory().getCollectionPersister(role);
/*    */     
/*    */ 
/* 41 */     String[] fk = cp.getKeyColumnNames();
/* 42 */     String[] pk = ((Loadable)cp.getOwnerEntityPersister()).getIdentifierColumnNames();
/* 43 */     return "? " + this.op + " (select count(*) from " + cp.getTableName() + " where " + new ConditionFragment().setTableAlias(criteriaQuery.getSQLAlias(criteria, this.propertyName)).setCondition(pk, fk).toFragmentString() + ")";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TypedValue[] getTypedValues(Criteria criteria, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 58 */     return new TypedValue[] { new TypedValue(Hibernate.INTEGER, new Integer(this.size), EntityMode.POJO) };
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\SizeExpression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */