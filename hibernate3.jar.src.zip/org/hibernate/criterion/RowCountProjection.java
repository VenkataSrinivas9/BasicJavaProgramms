/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.Hibernate;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RowCountProjection
/*    */   extends SimpleProjection
/*    */ {
/*    */   public String toString()
/*    */   {
/* 18 */     return "count(*)";
/*    */   }
/*    */   
/*    */   public Type[] getTypes(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 23 */     return new Type[] { Hibernate.INTEGER };
/*    */   }
/*    */   
/*    */   public String toSqlString(Criteria criteria, int position, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 28 */     return "count(*) as y" + position + '_';
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\RowCountProjection.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */