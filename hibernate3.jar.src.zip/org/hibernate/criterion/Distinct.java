/*     */ package org.hibernate.criterion;
/*     */ 
/*     */ import org.hibernate.Criteria;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Distinct
/*     */   implements Projection
/*     */ {
/*     */   private final Projection projection;
/*     */   
/*     */   public Distinct(Projection proj)
/*     */   {
/*  31 */     this.projection = proj;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toSqlString(Criteria criteria, int position, CriteriaQuery criteriaQuery)
/*     */     throws HibernateException
/*     */   {
/*  41 */     return "distinct " + this.projection.toSqlString(criteria, position, criteriaQuery);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toGroupSqlString(Criteria criteria, CriteriaQuery criteriaQuery)
/*     */     throws HibernateException
/*     */   {
/*  51 */     return this.projection.toGroupSqlString(criteria, criteriaQuery);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Type[] getTypes(Criteria criteria, CriteriaQuery criteriaQuery)
/*     */     throws HibernateException
/*     */   {
/*  61 */     return this.projection.getTypes(criteria, criteriaQuery);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Type[] getTypes(String alias, Criteria criteria, CriteriaQuery criteriaQuery)
/*     */     throws HibernateException
/*     */   {
/*  71 */     return this.projection.getTypes(alias, criteria, criteriaQuery);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getColumnAliases(int loc)
/*     */   {
/*  79 */     return this.projection.getColumnAliases(loc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getColumnAliases(String alias, int loc)
/*     */   {
/*  87 */     return this.projection.getColumnAliases(alias, loc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getAliases()
/*     */   {
/*  95 */     return this.projection.getAliases();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isGrouped()
/*     */   {
/* 103 */     return this.projection.isGrouped();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 111 */     return "distinct " + this.projection.toString();
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\Distinct.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */