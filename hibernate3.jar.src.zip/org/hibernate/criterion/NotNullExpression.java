/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.engine.TypedValue;
/*    */ import org.hibernate.util.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotNullExpression
/*    */   implements Criterion
/*    */ {
/*    */   private final String propertyName;
/* 18 */   private static final TypedValue[] NO_VALUES = new TypedValue[0];
/*    */   
/*    */   protected NotNullExpression(String propertyName) {
/* 21 */     this.propertyName = propertyName;
/*    */   }
/*    */   
/*    */   public String toSqlString(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 26 */     String[] columns = criteriaQuery.getColumnsUsingProjection(criteria, this.propertyName);
/* 27 */     String result = StringHelper.join(" or ", StringHelper.suffix(columns, " is not null"));
/*    */     
/*    */ 
/*    */ 
/* 31 */     if (columns.length > 1) result = '(' + result + ')';
/* 32 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public TypedValue[] getTypedValues(Criteria criteria, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 39 */     return NO_VALUES;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 43 */     return this.propertyName + " is not null";
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\NotNullExpression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */