package org.hibernate.criterion;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.engine.TypedValue;
import org.hibernate.type.Type;

public abstract interface CriteriaQuery
{
  public abstract SessionFactoryImplementor getFactory();
  
  public abstract String getColumn(Criteria paramCriteria, String paramString)
    throws HibernateException;
  
  public abstract Type getType(Criteria paramCriteria, String paramString)
    throws HibernateException;
  
  public abstract String[] getColumnsUsingProjection(Criteria paramCriteria, String paramString)
    throws HibernateException;
  
  public abstract Type getTypeUsingProjection(Criteria paramCriteria, String paramString)
    throws HibernateException;
  
  public abstract TypedValue getTypedValue(Criteria paramCriteria, String paramString, Object paramObject)
    throws HibernateException;
  
  public abstract String getEntityName(Criteria paramCriteria);
  
  public abstract String getEntityName(Criteria paramCriteria, String paramString);
  
  public abstract String getSQLAlias(Criteria paramCriteria);
  
  public abstract String getSQLAlias(Criteria paramCriteria, String paramString);
  
  public abstract String getPropertyName(String paramString);
  
  public abstract String[] getIdentifierColumns(Criteria paramCriteria);
  
  public abstract Type getIdentifierType(Criteria paramCriteria);
  
  public abstract TypedValue getTypedIdentifierValue(Criteria paramCriteria, Object paramObject);
  
  public abstract String generateSQLAlias();
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\CriteriaQuery.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */