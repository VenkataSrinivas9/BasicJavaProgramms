/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Conjunction
/*    */   extends Junction
/*    */ {
/*    */   public Conjunction()
/*    */   {
/* 10 */     super("and");
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\Conjunction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */