/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AggregateProjection
/*    */   extends SimpleProjection
/*    */ {
/*    */   protected final String propertyName;
/*    */   private final String aggregate;
/*    */   
/*    */   protected AggregateProjection(String aggregate, String propertyName)
/*    */   {
/* 18 */     this.aggregate = aggregate;
/* 19 */     this.propertyName = propertyName;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 23 */     return this.aggregate + "(" + this.propertyName + ')';
/*    */   }
/*    */   
/*    */   public Type[] getTypes(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 28 */     return new Type[] { criteriaQuery.getType(criteria, this.propertyName) };
/*    */   }
/*    */   
/*    */   public String toSqlString(Criteria criteria, int loc, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 33 */     return this.aggregate + "(" + criteriaQuery.getColumn(criteria, this.propertyName) + ") as y" + loc + '_';
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\AggregateProjection.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */