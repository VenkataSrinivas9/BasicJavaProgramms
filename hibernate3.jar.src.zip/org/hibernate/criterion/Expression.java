/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.type.Type;
/*    */ import org.hibernate.util.ArrayHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Expression
/*    */   extends Restrictions
/*    */ {
/*    */   public static Criterion sql(String sql, Object[] values, Type[] types)
/*    */   {
/* 31 */     return new SQLCriterion(sql, values, types);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Criterion sql(String sql, Object value, Type type)
/*    */   {
/* 44 */     return new SQLCriterion(sql, new Object[] { value }, new Type[] { type });
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Criterion sql(String sql)
/*    */   {
/* 54 */     return new SQLCriterion(sql, ArrayHelper.EMPTY_OBJECT_ARRAY, ArrayHelper.EMPTY_TYPE_ARRAY);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\Expression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */