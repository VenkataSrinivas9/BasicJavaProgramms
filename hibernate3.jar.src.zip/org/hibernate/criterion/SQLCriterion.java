/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.EntityMode;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.engine.TypedValue;
/*    */ import org.hibernate.type.Type;
/*    */ import org.hibernate.util.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SQLCriterion
/*    */   implements Criterion
/*    */ {
/*    */   private final String sql;
/*    */   private final TypedValue[] typedValues;
/*    */   
/*    */   public String toSqlString(Criteria criteria, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 25 */     return StringHelper.replace(this.sql, "{alias}", criteriaQuery.getSQLAlias(criteria));
/*    */   }
/*    */   
/*    */   public TypedValue[] getTypedValues(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 30 */     return this.typedValues;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 34 */     return this.sql;
/*    */   }
/*    */   
/*    */   protected SQLCriterion(String sql, Object[] values, Type[] types) {
/* 38 */     this.sql = sql;
/* 39 */     this.typedValues = new TypedValue[values.length];
/* 40 */     for (int i = 0; i < this.typedValues.length; i++) {
/* 41 */       this.typedValues[i] = new TypedValue(types[i], values[i], EntityMode.POJO);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\SQLCriterion.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */