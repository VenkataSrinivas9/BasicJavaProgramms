/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.EntityMode;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.engine.TypedValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleSubqueryExpression
/*    */   extends SubqueryExpression
/*    */ {
/*    */   private Object value;
/*    */   
/*    */   protected SimpleSubqueryExpression(Object value, String op, String quantifier, DetachedCriteria dc)
/*    */   {
/* 18 */     super(op, quantifier, dc);
/* 19 */     this.value = value;
/*    */   }
/*    */   
/*    */   public TypedValue[] getTypedValues(Criteria criteria, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 25 */     TypedValue[] superTv = super.getTypedValues(criteria, criteriaQuery);
/* 26 */     TypedValue[] result = new TypedValue[superTv.length + 1];
/* 27 */     System.arraycopy(superTv, 0, result, 1, superTv.length);
/* 28 */     result[0] = new TypedValue(getTypes()[0], this.value, EntityMode.POJO);
/* 29 */     return result;
/*    */   }
/*    */   
/*    */   protected String toLeftSqlString(Criteria criteria, CriteriaQuery criteriaQuery) {
/* 33 */     return "?";
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\SimpleSubqueryExpression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */