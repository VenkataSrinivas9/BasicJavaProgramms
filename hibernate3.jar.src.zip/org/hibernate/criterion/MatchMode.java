/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MatchMode
/*    */   implements Serializable
/*    */ {
/*    */   private final String name;
/* 16 */   private static final Map INSTANCES = new HashMap();
/*    */   
/*    */   protected MatchMode(String name) {
/* 19 */     this.name = name;
/*    */   }
/*    */   
/* 22 */   public String toString() { return this.name; }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 28 */   public static final MatchMode EXACT = new MatchMode("EXACT") {
/*    */     public String toMatchString(String pattern) {
/* 30 */       return pattern;
/*    */     }
/*    */   };
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 37 */   public static final MatchMode START = new MatchMode("START") {
/*    */     public String toMatchString(String pattern) {
/* 39 */       return pattern + '%';
/*    */     }
/*    */   };
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 46 */   public static final MatchMode END = new MatchMode("END") {
/*    */     public String toMatchString(String pattern) {
/* 48 */       return '%' + pattern;
/*    */     }
/*    */   };
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 55 */   public static final MatchMode ANYWHERE = new MatchMode("ANYWHERE") {
/*    */     public String toMatchString(String pattern) {
/* 57 */       return '%' + pattern + '%';
/*    */     }
/*    */   };
/*    */   
/*    */   static {
/* 62 */     INSTANCES.put(EXACT.name, EXACT);
/* 63 */     INSTANCES.put(END.name, END);
/* 64 */     INSTANCES.put(START.name, START);
/* 65 */     INSTANCES.put(ANYWHERE.name, ANYWHERE);
/*    */   }
/*    */   
/*    */   private Object readResolve() {
/* 69 */     return INSTANCES.get(this.name);
/*    */   }
/*    */   
/*    */   public abstract String toMatchString(String paramString);
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\MatchMode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */