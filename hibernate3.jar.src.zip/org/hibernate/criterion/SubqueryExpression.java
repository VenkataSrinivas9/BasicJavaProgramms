/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.EntityMode;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.engine.QueryParameters;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.engine.TypedValue;
/*    */ import org.hibernate.impl.CriteriaImpl;
/*    */ import org.hibernate.loader.criteria.CriteriaQueryTranslator;
/*    */ import org.hibernate.persister.entity.OuterJoinLoadable;
/*    */ import org.hibernate.sql.Select;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SubqueryExpression
/*    */   implements Criterion
/*    */ {
/*    */   private CriteriaImpl criteriaImpl;
/*    */   private String quantifier;
/*    */   private String op;
/*    */   private QueryParameters params;
/*    */   private Type[] types;
/*    */   
/*    */   protected Type[] getTypes()
/*    */   {
/* 29 */     return this.types;
/*    */   }
/*    */   
/*    */   protected SubqueryExpression(String op, String quantifier, DetachedCriteria dc) {
/* 33 */     this.criteriaImpl = dc.getCriteriaImpl();
/* 34 */     this.quantifier = quantifier;
/* 35 */     this.op = op;
/*    */   }
/*    */   
/*    */   protected abstract String toLeftSqlString(Criteria paramCriteria, CriteriaQuery paramCriteriaQuery);
/*    */   
/*    */   public String toSqlString(Criteria criteria, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 43 */     SessionImplementor session = ((CriteriaImpl)criteria).getSession();
/* 44 */     SessionFactoryImplementor factory = session.getFactory();
/*    */     
/* 46 */     OuterJoinLoadable persister = (OuterJoinLoadable)factory.getEntityPersister(this.criteriaImpl.getEntityOrClassName());
/* 47 */     CriteriaQueryTranslator innerQuery = new CriteriaQueryTranslator(factory, this.criteriaImpl, this.criteriaImpl.getEntityOrClassName(), criteriaQuery.generateSQLAlias(), criteriaQuery);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 55 */     this.params = innerQuery.getQueryParameters();
/* 56 */     this.types = innerQuery.getProjectedTypes();
/*    */     
/*    */ 
/*    */ 
/* 60 */     String sql = new Select(factory.getDialect()).setWhereClause(innerQuery.getWhereCondition()).setGroupByClause(innerQuery.getGroupBy()).setSelectClause(innerQuery.getSelect()).setFromClause(persister.fromTableFragment(innerQuery.getRootSQLALias()) + persister.fromJoinFragment(innerQuery.getRootSQLALias(), true, false)).toStatementString();
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 70 */     StringBuffer buf = new StringBuffer().append(toLeftSqlString(criteria, criteriaQuery));
/*    */     
/* 72 */     if (this.op != null) buf.append(' ').append(this.op).append(' ');
/* 73 */     if (this.quantifier != null) buf.append(this.quantifier).append(' ');
/* 74 */     return '(' + sql + ')';
/*    */   }
/*    */   
/*    */   public TypedValue[] getTypedValues(Criteria criteria, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 80 */     Type[] types = this.params.getPositionalParameterTypes();
/* 81 */     Object[] values = this.params.getPositionalParameterValues();
/* 82 */     TypedValue[] tv = new TypedValue[types.length];
/* 83 */     for (int i = 0; i < types.length; i++) {
/* 84 */       tv[i] = new TypedValue(types[i], values[i], EntityMode.POJO);
/*    */     }
/* 86 */     return tv;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\SubqueryExpression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */