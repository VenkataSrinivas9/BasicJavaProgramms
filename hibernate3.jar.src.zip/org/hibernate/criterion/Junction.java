/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.engine.TypedValue;
/*    */ import org.hibernate.util.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Junction
/*    */   implements Criterion
/*    */ {
/* 20 */   private final List criteria = new ArrayList();
/*    */   private final String op;
/*    */   
/*    */   protected Junction(String op) {
/* 24 */     this.op = op;
/*    */   }
/*    */   
/*    */   public Junction add(Criterion criterion) {
/* 28 */     this.criteria.add(criterion);
/* 29 */     return this;
/*    */   }
/*    */   
/*    */   public String getOp() {
/* 33 */     return this.op;
/*    */   }
/*    */   
/*    */   public TypedValue[] getTypedValues(Criteria crit, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 38 */     ArrayList typedValues = new ArrayList();
/* 39 */     Iterator iter = this.criteria.iterator();
/* 40 */     while (iter.hasNext()) {
/* 41 */       TypedValue[] subvalues = ((Criterion)iter.next()).getTypedValues(crit, criteriaQuery);
/* 42 */       for (int i = 0; i < subvalues.length; i++) {
/* 43 */         typedValues.add(subvalues[i]);
/*    */       }
/*    */     }
/* 46 */     return (TypedValue[])typedValues.toArray(new TypedValue[typedValues.size()]);
/*    */   }
/*    */   
/*    */   public String toSqlString(Criteria crit, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 52 */     if (this.criteria.size() == 0) { return "1=1";
/*    */     }
/* 54 */     StringBuffer buffer = new StringBuffer().append('(');
/*    */     
/* 56 */     Iterator iter = this.criteria.iterator();
/* 57 */     while (iter.hasNext()) {
/* 58 */       buffer.append(((Criterion)iter.next()).toSqlString(crit, criteriaQuery));
/* 59 */       if (iter.hasNext()) buffer.append(' ').append(this.op).append(' ');
/*    */     }
/* 61 */     return ')';
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 68 */     return '(' + StringHelper.join(new StringBuffer().append(' ').append(this.op).append(' ').toString(), this.criteria.iterator()) + ')';
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\Junction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */