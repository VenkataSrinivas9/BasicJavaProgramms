/*     */ package org.hibernate.criterion;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.hibernate.Criteria;
/*     */ import org.hibernate.FetchMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.impl.CriteriaImpl;
/*     */ import org.hibernate.transform.ResultTransformer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DetachedCriteria
/*     */   implements CriteriaSpecification, Serializable
/*     */ {
/*     */   private final CriteriaImpl impl;
/*     */   private final Criteria criteria;
/*     */   
/*     */   protected DetachedCriteria(String entityName)
/*     */   {
/*  33 */     this.impl = new CriteriaImpl(entityName, null);
/*  34 */     this.criteria = this.impl;
/*     */   }
/*     */   
/*     */   protected DetachedCriteria(String entityName, String alias) {
/*  38 */     this.impl = new CriteriaImpl(entityName, alias, null);
/*  39 */     this.criteria = this.impl;
/*     */   }
/*     */   
/*     */   protected DetachedCriteria(CriteriaImpl impl, Criteria criteria) {
/*  43 */     this.impl = impl;
/*  44 */     this.criteria = criteria;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Criteria getExecutableCriteria(Session session)
/*     */   {
/*  52 */     this.impl.setSession((SessionImplementor)session);
/*  53 */     return this.impl;
/*     */   }
/*     */   
/*     */   public static DetachedCriteria forEntityName(String entityName) {
/*  57 */     return new DetachedCriteria(entityName);
/*     */   }
/*     */   
/*     */   public static DetachedCriteria forEntityName(String entityName, String alias) {
/*  61 */     return new DetachedCriteria(entityName, alias);
/*     */   }
/*     */   
/*     */   public static DetachedCriteria forClass(Class clazz) {
/*  65 */     return new DetachedCriteria(clazz.getName());
/*     */   }
/*     */   
/*     */   public static DetachedCriteria forClass(Class clazz, String alias) {
/*  69 */     return new DetachedCriteria(clazz.getName(), alias);
/*     */   }
/*     */   
/*     */   public DetachedCriteria add(Criterion criterion) {
/*  73 */     this.criteria.add(criterion);
/*  74 */     return this;
/*     */   }
/*     */   
/*     */   public DetachedCriteria addOrder(Order order) {
/*  78 */     this.criteria.addOrder(order);
/*  79 */     return this;
/*     */   }
/*     */   
/*     */   public DetachedCriteria createAlias(String associationPath, String alias) throws HibernateException
/*     */   {
/*  84 */     this.criteria.createAlias(associationPath, alias);
/*  85 */     return this;
/*     */   }
/*     */   
/*     */   public DetachedCriteria createCriteria(String associationPath, String alias) throws HibernateException
/*     */   {
/*  90 */     return new DetachedCriteria(this.impl, this.criteria.createCriteria(associationPath));
/*     */   }
/*     */   
/*     */   public DetachedCriteria createCriteria(String associationPath) throws HibernateException
/*     */   {
/*  95 */     return new DetachedCriteria(this.impl, this.criteria.createCriteria(associationPath));
/*     */   }
/*     */   
/*     */   public String getAlias() {
/*  99 */     return this.criteria.getAlias();
/*     */   }
/*     */   
/*     */   public DetachedCriteria setFetchMode(String associationPath, FetchMode mode) throws HibernateException
/*     */   {
/* 104 */     this.criteria.setFetchMode(associationPath, mode);
/* 105 */     return this;
/*     */   }
/*     */   
/*     */   public DetachedCriteria setProjection(Projection projection) {
/* 109 */     this.criteria.setProjection(projection);
/* 110 */     return this;
/*     */   }
/*     */   
/*     */   public DetachedCriteria setResultTransformer(ResultTransformer resultTransformer) {
/* 114 */     this.criteria.setResultTransformer(resultTransformer);
/* 115 */     return this;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 119 */     return "DetachableCriteria(" + this.criteria.toString() + ')';
/*     */   }
/*     */   
/*     */   CriteriaImpl getCriteriaImpl() {
/* 123 */     return this.impl;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\DetachedCriteria.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */