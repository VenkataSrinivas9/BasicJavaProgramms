/*     */ package org.hibernate.criterion;
/*     */ 
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Projections
/*     */ {
/*     */   public static Projection distinct(Projection proj)
/*     */   {
/*  28 */     return new Distinct(proj);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static ProjectionList projectionList()
/*     */   {
/*  35 */     return new ProjectionList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Projection rowCount()
/*     */   {
/*  42 */     return new RowCountProjection();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static CountProjection count(String propertyName)
/*     */   {
/*  49 */     return new CountProjection(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static CountProjection countDistinct(String propertyName)
/*     */   {
/*  56 */     return new CountProjection(propertyName).setDistinct();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static AggregateProjection max(String propertyName)
/*     */   {
/*  63 */     return new AggregateProjection("max", propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static AggregateProjection min(String propertyName)
/*     */   {
/*  70 */     return new AggregateProjection("min", propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static AggregateProjection avg(String propertyName)
/*     */   {
/*  77 */     return new AvgProjection(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static AggregateProjection sum(String propertyName)
/*     */   {
/*  84 */     return new AggregateProjection("sum", propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Projection sqlProjection(String sql, String[] columnAliases, Type[] types)
/*     */   {
/*  91 */     return new SQLProjection(sql, columnAliases, types);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Projection sqlGroupProjection(String sql, String groupBy, String[] columnAliases, Type[] types)
/*     */   {
/*  98 */     return new SQLProjection(sql, groupBy, columnAliases, types);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static PropertyProjection groupProperty(String propertyName)
/*     */   {
/* 105 */     return new PropertyProjection(propertyName, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static PropertyProjection property(String propertyName)
/*     */   {
/* 112 */     return new PropertyProjection(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static IdentifierProjection id()
/*     */   {
/* 119 */     return new IdentifierProjection();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Projection alias(Projection projection, String alias)
/*     */   {
/* 126 */     return new AliasedProjection(projection, alias);
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\Projections.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */