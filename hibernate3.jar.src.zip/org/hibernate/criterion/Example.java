/*     */ package org.hibernate.criterion;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.hibernate.Criteria;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.TypedValue;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.type.AbstractComponentType;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Example
/*     */   implements Criterion
/*     */ {
/*     */   private final Object entity;
/*  36 */   private final Set excludedProperties = new HashSet();
/*     */   
/*     */ 
/*     */   private PropertySelector selector;
/*     */   
/*     */ 
/*     */   private boolean isLikeEnabled;
/*     */   
/*     */ 
/*     */   private boolean isIgnoreCaseEnabled;
/*     */   
/*     */ 
/*     */   private MatchMode matchMode;
/*     */   
/*     */ 
/*  51 */   private static final PropertySelector NOT_NULL = new NotNullPropertySelector();
/*  52 */   private static final PropertySelector ALL = new AllPropertySelector();
/*  53 */   private static final PropertySelector NOT_NULL_OR_ZERO = new NotNullOrZeroPropertySelector();
/*     */   
/*     */   public static abstract interface PropertySelector extends Serializable { public abstract boolean include(Object paramObject, String paramString, Type paramType); }
/*     */   
/*  57 */   static final class AllPropertySelector implements Example.PropertySelector { public boolean include(Object object, String propertyName, Type type) { return true; }
/*     */     
/*     */     private Object readResolve()
/*     */     {
/*  61 */       return Example.ALL;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class NotNullPropertySelector implements Example.PropertySelector {
/*     */     public boolean include(Object object, String propertyName, Type type) {
/*  67 */       return object != null;
/*     */     }
/*     */     
/*     */     private Object readResolve() {
/*  71 */       return Example.NOT_NULL;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class NotNullOrZeroPropertySelector implements Example.PropertySelector {
/*     */     public boolean include(Object object, String propertyName, Type type) {
/*  77 */       return (object != null) && ((!(object instanceof Number)) || (((Number)object).longValue() != 0L));
/*     */     }
/*     */     
/*     */ 
/*     */     private Object readResolve()
/*     */     {
/*  83 */       return Example.NOT_NULL_OR_ZERO;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Example setPropertySelector(PropertySelector selector)
/*     */   {
/*  91 */     this.selector = selector;
/*  92 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Example excludeZeroes()
/*     */   {
/*  99 */     setPropertySelector(NOT_NULL_OR_ZERO);
/* 100 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Example excludeNone()
/*     */   {
/* 107 */     setPropertySelector(ALL);
/* 108 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Example enableLike(MatchMode matchMode)
/*     */   {
/* 115 */     this.isLikeEnabled = true;
/* 116 */     this.matchMode = matchMode;
/* 117 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Example enableLike()
/*     */   {
/* 124 */     return enableLike(MatchMode.EXACT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Example ignoreCase()
/*     */   {
/* 131 */     this.isIgnoreCaseEnabled = true;
/* 132 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Example excludeProperty(String name)
/*     */   {
/* 139 */     this.excludedProperties.add(name);
/* 140 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Example create(Object entity)
/*     */   {
/* 150 */     if (entity == null) throw new NullPointerException("null example");
/* 151 */     return new Example(entity, NOT_NULL);
/*     */   }
/*     */   
/*     */   protected Example(Object entity, PropertySelector selector) {
/* 155 */     this.entity = entity;
/* 156 */     this.selector = selector;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 160 */     return "example (" + this.entity + ')';
/*     */   }
/*     */   
/*     */   private boolean isPropertyIncluded(Object value, String name, Type type) {
/* 164 */     return (!this.excludedProperties.contains(name)) && (!type.isAssociationType()) && (this.selector.include(value, name, type));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toSqlString(Criteria criteria, CriteriaQuery criteriaQuery)
/*     */     throws HibernateException
/*     */   {
/* 172 */     StringBuffer buf = new StringBuffer().append('(');
/* 173 */     EntityPersister meta = criteriaQuery.getFactory().getEntityPersister(criteriaQuery.getEntityName(criteria));
/* 174 */     String[] propertyNames = meta.getPropertyNames();
/* 175 */     Type[] propertyTypes = meta.getPropertyTypes();
/*     */     
/* 177 */     Object[] propertyValues = meta.getPropertyValues(this.entity, getEntityMode(criteria, criteriaQuery));
/* 178 */     for (int i = 0; i < propertyNames.length; i++) {
/* 179 */       Object propertyValue = propertyValues[i];
/* 180 */       String propertyName = propertyNames[i];
/*     */       
/* 182 */       boolean isPropertyIncluded = (i != meta.getVersionProperty()) && (isPropertyIncluded(propertyValue, propertyName, propertyTypes[i]));
/*     */       
/* 184 */       if (isPropertyIncluded) {
/* 185 */         if (propertyTypes[i].isComponentType()) {
/* 186 */           appendComponentCondition(propertyName, propertyValue, (AbstractComponentType)propertyTypes[i], criteria, criteriaQuery, buf);
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 196 */           appendPropertyCondition(propertyName, propertyValue, criteria, criteriaQuery, buf);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 206 */     if (buf.length() == 1) buf.append("1=1");
/* 207 */     return ')';
/*     */   }
/*     */   
/* 210 */   private static final Object[] TYPED_VALUES = new TypedValue[0];
/*     */   
/*     */   public TypedValue[] getTypedValues(Criteria criteria, CriteriaQuery criteriaQuery)
/*     */     throws HibernateException
/*     */   {
/* 215 */     EntityPersister meta = criteriaQuery.getFactory().getEntityPersister(criteriaQuery.getEntityName(criteria));
/*     */     
/* 217 */     String[] propertyNames = meta.getPropertyNames();
/* 218 */     Type[] propertyTypes = meta.getPropertyTypes();
/*     */     
/* 220 */     Object[] values = meta.getPropertyValues(this.entity, getEntityMode(criteria, criteriaQuery));
/* 221 */     List list = new ArrayList();
/* 222 */     for (int i = 0; i < propertyNames.length; i++) {
/* 223 */       Object value = values[i];
/* 224 */       Type type = propertyTypes[i];
/* 225 */       String name = propertyNames[i];
/*     */       
/* 227 */       boolean isPropertyIncluded = (i != meta.getVersionProperty()) && (isPropertyIncluded(value, name, type));
/*     */       
/*     */ 
/* 230 */       if (isPropertyIncluded) {
/* 231 */         if (propertyTypes[i].isComponentType()) {
/* 232 */           addComponentTypedValues(name, value, (AbstractComponentType)type, list, criteria, criteriaQuery);
/*     */         }
/*     */         else {
/* 235 */           addPropertyTypedValue(value, type, list);
/*     */         }
/*     */       }
/*     */     }
/* 239 */     return (TypedValue[])list.toArray(TYPED_VALUES);
/*     */   }
/*     */   
/*     */   private EntityMode getEntityMode(Criteria criteria, CriteriaQuery criteriaQuery) {
/* 243 */     EntityPersister meta = criteriaQuery.getFactory().getEntityPersister(criteriaQuery.getEntityName(criteria));
/*     */     
/* 245 */     EntityMode result = meta.guessEntityMode(this.entity);
/* 246 */     if (result == null) {
/* 247 */       throw new ClassCastException(this.entity.getClass().getName());
/*     */     }
/* 249 */     return result;
/*     */   }
/*     */   
/*     */   protected void addPropertyTypedValue(Object value, Type type, List list) {
/* 253 */     if (value != null) {
/* 254 */       if ((value instanceof String)) {
/* 255 */         String string = (String)value;
/* 256 */         if (this.isIgnoreCaseEnabled) string = string.toLowerCase();
/* 257 */         if (this.isLikeEnabled) string = this.matchMode.toMatchString(string);
/* 258 */         value = string;
/*     */       }
/* 260 */       list.add(new TypedValue(type, value, null));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addComponentTypedValues(String path, Object component, AbstractComponentType type, List list, Criteria criteria, CriteriaQuery criteriaQuery)
/*     */     throws HibernateException
/*     */   {
/* 273 */     if (component != null) {
/* 274 */       String[] propertyNames = type.getPropertyNames();
/* 275 */       Type[] subtypes = type.getSubtypes();
/* 276 */       Object[] values = type.getPropertyValues(component, getEntityMode(criteria, criteriaQuery));
/* 277 */       for (int i = 0; i < propertyNames.length; i++) {
/* 278 */         Object value = values[i];
/* 279 */         Type subtype = subtypes[i];
/* 280 */         String subpath = StringHelper.qualify(path, propertyNames[i]);
/* 281 */         if (isPropertyIncluded(value, subpath, subtype)) {
/* 282 */           if (subtype.isComponentType()) {
/* 283 */             addComponentTypedValues(subpath, value, (AbstractComponentType)subtype, list, criteria, criteriaQuery);
/*     */           }
/*     */           else {
/* 286 */             addPropertyTypedValue(value, subtype, list);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void appendPropertyCondition(String propertyName, Object propertyValue, Criteria criteria, CriteriaQuery cq, StringBuffer buf)
/*     */     throws HibernateException
/*     */   {
/*     */     Criterion crit;
/*     */     
/*     */     Criterion crit;
/*     */     
/* 301 */     if (propertyValue != null) {
/* 302 */       boolean isString = propertyValue instanceof String;
/* 303 */       String op = (this.isLikeEnabled) && (isString) ? " like " : "=";
/* 304 */       crit = new SimpleExpression(propertyName, propertyValue, op, (this.isIgnoreCaseEnabled) && (isString));
/*     */     }
/*     */     else {
/* 307 */       crit = new NullExpression(propertyName);
/*     */     }
/* 309 */     String critCondition = crit.toSqlString(criteria, cq);
/* 310 */     if ((buf.length() > 1) && (critCondition.trim().length() > 0)) buf.append(" and ");
/* 311 */     buf.append(critCondition);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void appendComponentCondition(String path, Object component, AbstractComponentType type, Criteria criteria, CriteriaQuery criteriaQuery, StringBuffer buf)
/*     */     throws HibernateException
/*     */   {
/* 323 */     if (component != null) {
/* 324 */       String[] propertyNames = type.getPropertyNames();
/* 325 */       Object[] values = type.getPropertyValues(component, getEntityMode(criteria, criteriaQuery));
/* 326 */       Type[] subtypes = type.getSubtypes();
/* 327 */       for (int i = 0; i < propertyNames.length; i++) {
/* 328 */         String subpath = StringHelper.qualify(path, propertyNames[i]);
/* 329 */         Object value = values[i];
/* 330 */         if (isPropertyIncluded(value, subpath, subtypes[i])) {
/* 331 */           Type subtype = subtypes[i];
/* 332 */           if (subtype.isComponentType()) {
/* 333 */             appendComponentCondition(subpath, value, (AbstractComponentType)subtype, criteria, criteriaQuery, buf);
/*     */ 
/*     */ 
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/* 343 */             appendPropertyCondition(subpath, value, criteria, criteriaQuery, buf);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\Example.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */