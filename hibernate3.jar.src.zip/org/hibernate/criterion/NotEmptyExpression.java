/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ 
/*    */ public class NotEmptyExpression
/*    */   extends AbstractEmptinessExpression
/*    */   implements Criterion
/*    */ {
/*    */   protected NotEmptyExpression(String propertyName)
/*    */   {
/* 10 */     super(propertyName);
/*    */   }
/*    */   
/*    */   protected boolean excludeEmpty() {
/* 14 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\NotEmptyExpression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */