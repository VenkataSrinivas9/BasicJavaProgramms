/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.dialect.Dialect;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.engine.TypedValue;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleExpression
/*    */   implements Criterion
/*    */ {
/*    */   private final String propertyName;
/*    */   private final Object value;
/*    */   private boolean ignoreCase;
/*    */   private final String op;
/*    */   
/*    */   protected SimpleExpression(String propertyName, Object value, String op)
/*    */   {
/* 25 */     this.propertyName = propertyName;
/* 26 */     this.value = value;
/* 27 */     this.op = op;
/*    */   }
/*    */   
/*    */   protected SimpleExpression(String propertyName, Object value, String op, boolean ignoreCase) {
/* 31 */     this.propertyName = propertyName;
/* 32 */     this.value = value;
/* 33 */     this.ignoreCase = ignoreCase;
/* 34 */     this.op = op;
/*    */   }
/*    */   
/*    */   public SimpleExpression ignoreCase() {
/* 38 */     this.ignoreCase = true;
/* 39 */     return this;
/*    */   }
/*    */   
/*    */   public String toSqlString(Criteria criteria, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 45 */     String[] columns = criteriaQuery.getColumnsUsingProjection(criteria, this.propertyName);
/* 46 */     Type type = criteriaQuery.getTypeUsingProjection(criteria, this.propertyName);
/* 47 */     StringBuffer fragment = new StringBuffer();
/* 48 */     if (columns.length > 1) fragment.append('(');
/* 49 */     SessionFactoryImplementor factory = criteriaQuery.getFactory();
/* 50 */     int[] sqlTypes = type.sqlTypes(factory);
/* 51 */     for (int i = 0; i < columns.length; i++) {
/* 52 */       boolean lower = (this.ignoreCase) && ((sqlTypes[i] == 12) || (sqlTypes[i] == 1));
/*    */       
/* 54 */       if (lower) {
/* 55 */         fragment.append(factory.getDialect().getLowercaseFunction()).append('(');
/*    */       }
/*    */       
/* 58 */       fragment.append(columns[i]);
/* 59 */       if (lower) fragment.append(')');
/* 60 */       fragment.append(getOp()).append("?");
/* 61 */       if (i < columns.length - 1) fragment.append(" and ");
/*    */     }
/* 63 */     if (columns.length > 1) fragment.append(')');
/* 64 */     return fragment.toString();
/*    */   }
/*    */   
/*    */   public TypedValue[] getTypedValues(Criteria criteria, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 70 */     Object icvalue = this.ignoreCase ? this.value.toString().toLowerCase() : this.value;
/* 71 */     return new TypedValue[] { criteriaQuery.getTypedValue(criteria, this.propertyName, icvalue) };
/*    */   }
/*    */   
/*    */   public String toString() {
/* 75 */     return this.propertyName + getOp() + this.value;
/*    */   }
/*    */   
/*    */   protected final String getOp() {
/* 79 */     return this.op;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\SimpleExpression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */