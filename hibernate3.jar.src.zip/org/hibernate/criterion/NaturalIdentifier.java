/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.engine.TypedValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NaturalIdentifier
/*    */   implements Criterion
/*    */ {
/* 25 */   private Junction conjunction = new Conjunction();
/*    */   
/*    */ 
/*    */   public TypedValue[] getTypedValues(Criteria criteria, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 31 */     return this.conjunction.getTypedValues(criteria, criteriaQuery);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String toSqlString(Criteria criteria, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 39 */     return this.conjunction.toSqlString(criteria, criteriaQuery);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public NaturalIdentifier set(String property, Object value)
/*    */   {
/* 47 */     this.conjunction.add(Restrictions.eq(property, value));
/*    */     
/* 49 */     return this;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\NaturalIdentifier.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */