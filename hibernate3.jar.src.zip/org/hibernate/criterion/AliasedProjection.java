/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AliasedProjection
/*    */   implements Projection
/*    */ {
/*    */   private final Projection projection;
/*    */   private final String alias;
/*    */   
/*    */   public String toString()
/*    */   {
/* 17 */     return this.projection.toString() + " as " + this.alias;
/*    */   }
/*    */   
/*    */   protected AliasedProjection(Projection projection, String alias) {
/* 21 */     this.projection = projection;
/* 22 */     this.alias = alias;
/*    */   }
/*    */   
/*    */   public String toSqlString(Criteria criteria, int position, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 27 */     return this.projection.toSqlString(criteria, position, criteriaQuery);
/*    */   }
/*    */   
/*    */   public String toGroupSqlString(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 32 */     return this.projection.toGroupSqlString(criteria, criteriaQuery);
/*    */   }
/*    */   
/*    */   public Type[] getTypes(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 37 */     return this.projection.getTypes(criteria, criteriaQuery);
/*    */   }
/*    */   
/*    */   public String[] getColumnAliases(int loc) {
/* 41 */     return this.projection.getColumnAliases(loc);
/*    */   }
/*    */   
/*    */   public Type[] getTypes(String alias, Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 46 */     return this.alias.equals(alias) ? getTypes(criteria, criteriaQuery) : null;
/*    */   }
/*    */   
/*    */ 
/*    */   public String[] getColumnAliases(String alias, int loc)
/*    */   {
/* 52 */     return this.alias.equals(alias) ? getColumnAliases(loc) : null;
/*    */   }
/*    */   
/*    */ 
/*    */   public String[] getAliases()
/*    */   {
/* 58 */     return new String[] { this.alias };
/*    */   }
/*    */   
/*    */   public boolean isGrouped() {
/* 62 */     return this.projection.isGrouped();
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\AliasedProjection.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */