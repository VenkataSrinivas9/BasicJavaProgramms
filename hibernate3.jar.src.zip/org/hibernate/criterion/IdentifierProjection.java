/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.type.Type;
/*    */ import org.hibernate.util.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IdentifierProjection
/*    */   extends SimpleProjection
/*    */ {
/*    */   private boolean grouped;
/*    */   
/*    */   protected IdentifierProjection(boolean grouped)
/*    */   {
/* 18 */     this.grouped = grouped;
/*    */   }
/*    */   
/*    */   protected IdentifierProjection() {
/* 22 */     this(false);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 26 */     return "id";
/*    */   }
/*    */   
/*    */   public Type[] getTypes(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 31 */     return new Type[] { criteriaQuery.getIdentifierType(criteria) };
/*    */   }
/*    */   
/*    */   public String toSqlString(Criteria criteria, int position, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 36 */     StringBuffer buf = new StringBuffer();
/* 37 */     String[] cols = criteriaQuery.getIdentifierColumns(criteria);
/* 38 */     for (int i = 0; i < cols.length; i++) {
/* 39 */       buf.append(cols[i]).append(" as y").append(position + i).append('_');
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 44 */     return buf.toString();
/*    */   }
/*    */   
/*    */   public boolean isGrouped() {
/* 48 */     return this.grouped;
/*    */   }
/*    */   
/*    */   public String toGroupSqlString(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 53 */     if (!this.grouped) {
/* 54 */       return super.toGroupSqlString(criteria, criteriaQuery);
/*    */     }
/*    */     
/* 57 */     return StringHelper.join(", ", criteriaQuery.getIdentifierColumns(criteria));
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\IdentifierProjection.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */