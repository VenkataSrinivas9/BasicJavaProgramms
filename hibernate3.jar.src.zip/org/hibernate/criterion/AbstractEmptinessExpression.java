/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.MappingException;
/*    */ import org.hibernate.QueryException;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.engine.TypedValue;
/*    */ import org.hibernate.persister.collection.QueryableCollection;
/*    */ import org.hibernate.persister.entity.Loadable;
/*    */ import org.hibernate.persister.entity.PropertyMapping;
/*    */ import org.hibernate.sql.ConditionFragment;
/*    */ import org.hibernate.type.CollectionType;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractEmptinessExpression
/*    */   implements Criterion
/*    */ {
/* 24 */   private static final TypedValue[] NO_VALUES = new TypedValue[0];
/*    */   protected final String propertyName;
/*    */   
/*    */   protected AbstractEmptinessExpression(String propertyName)
/*    */   {
/* 29 */     this.propertyName = propertyName;
/*    */   }
/*    */   
/*    */   protected abstract boolean excludeEmpty();
/*    */   
/*    */   public final String toSqlString(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException {
/* 35 */     String entityName = criteriaQuery.getEntityName(criteria, this.propertyName);
/* 36 */     String actualPropertyName = criteriaQuery.getPropertyName(this.propertyName);
/* 37 */     String sqlAlias = criteriaQuery.getSQLAlias(criteria, this.propertyName);
/*    */     
/* 39 */     SessionFactoryImplementor factory = criteriaQuery.getFactory();
/* 40 */     QueryableCollection collectionPersister = getQueryableCollection(entityName, actualPropertyName, factory);
/*    */     
/* 42 */     String[] collectionKeys = collectionPersister.getKeyColumnNames();
/* 43 */     String[] ownerKeys = ((Loadable)factory.getEntityPersister(entityName)).getIdentifierColumnNames();
/*    */     
/* 45 */     String innerSelect = "(select 1 from " + collectionPersister.getTableName() + " where " + new ConditionFragment().setTableAlias(sqlAlias).setCondition(ownerKeys, collectionKeys).toFragmentString() + ")";
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 50 */     return "not exists " + innerSelect;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected QueryableCollection getQueryableCollection(String entityName, String propertyName, SessionFactoryImplementor factory)
/*    */     throws HibernateException
/*    */   {
/* 58 */     PropertyMapping ownerMapping = (PropertyMapping)factory.getEntityPersister(entityName);
/* 59 */     Type type = ownerMapping.toType(propertyName);
/* 60 */     if (!type.isCollectionType()) {
/* 61 */       throw new MappingException("Property path [" + entityName + "." + propertyName + "] does not reference a collection");
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 66 */     String role = ((CollectionType)type).getRole();
/*    */     try {
/* 68 */       return (QueryableCollection)factory.getCollectionPersister(role);
/*    */     }
/*    */     catch (ClassCastException cce) {
/* 71 */       throw new QueryException("collection role is not queryable: " + role);
/*    */     }
/*    */     catch (Exception e) {
/* 74 */       throw new QueryException("collection role not found: " + role);
/*    */     }
/*    */   }
/*    */   
/*    */   public final TypedValue[] getTypedValues(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 80 */     return NO_VALUES;
/*    */   }
/*    */   
/*    */   public final String toString() {
/* 84 */     return this.propertyName + (excludeEmpty() ? " is not empty" : " is empty");
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\AbstractEmptinessExpression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */