/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.engine.TypedValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogicalExpression
/*    */   implements Criterion
/*    */ {
/*    */   private final Criterion lhs;
/*    */   private final Criterion rhs;
/*    */   private final String op;
/*    */   
/*    */   protected LogicalExpression(Criterion lhs, Criterion rhs, String op)
/*    */   {
/* 20 */     this.lhs = lhs;
/* 21 */     this.rhs = rhs;
/* 22 */     this.op = op;
/*    */   }
/*    */   
/*    */   public TypedValue[] getTypedValues(Criteria criteria, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 28 */     TypedValue[] lhstv = this.lhs.getTypedValues(criteria, criteriaQuery);
/* 29 */     TypedValue[] rhstv = this.rhs.getTypedValues(criteria, criteriaQuery);
/* 30 */     TypedValue[] result = new TypedValue[lhstv.length + rhstv.length];
/* 31 */     System.arraycopy(lhstv, 0, result, 0, lhstv.length);
/* 32 */     System.arraycopy(rhstv, 0, result, lhstv.length, rhstv.length);
/* 33 */     return result;
/*    */   }
/*    */   
/*    */   public String toSqlString(Criteria criteria, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 39 */     return '(' + this.lhs.toSqlString(criteria, criteriaQuery) + ' ' + getOp() + ' ' + this.rhs.toSqlString(criteria, criteriaQuery) + ')';
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getOp()
/*    */   {
/* 49 */     return this.op;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 53 */     return this.lhs.toString() + ' ' + getOp() + ' ' + this.rhs.toString();
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\LogicalExpression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */