/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.type.Type;
/*    */ import org.hibernate.util.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SQLProjection
/*    */   implements Projection
/*    */ {
/*    */   private final String sql;
/*    */   private final String groupBy;
/*    */   private final Type[] types;
/*    */   private String[] aliases;
/*    */   private String[] columnAliases;
/*    */   private boolean grouped;
/*    */   
/*    */   public String toSqlString(Criteria criteria, int loc, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 28 */     return StringHelper.replace(this.sql, "{alias}", criteriaQuery.getSQLAlias(criteria));
/*    */   }
/*    */   
/*    */   public String toGroupSqlString(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 33 */     return StringHelper.replace(this.groupBy, "{alias}", criteriaQuery.getSQLAlias(criteria));
/*    */   }
/*    */   
/*    */   public Type[] getTypes(Criteria crit, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 38 */     return this.types;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 42 */     return this.sql;
/*    */   }
/*    */   
/*    */   protected SQLProjection(String sql, String[] columnAliases, Type[] types) {
/* 46 */     this(sql, null, columnAliases, types);
/*    */   }
/*    */   
/*    */   protected SQLProjection(String sql, String groupBy, String[] columnAliases, Type[] types) {
/* 50 */     this.sql = sql;
/* 51 */     this.types = types;
/* 52 */     this.aliases = columnAliases;
/* 53 */     this.columnAliases = columnAliases;
/* 54 */     this.grouped = (groupBy != null);
/* 55 */     this.groupBy = groupBy;
/*    */   }
/*    */   
/*    */   public String[] getAliases() {
/* 59 */     return this.aliases;
/*    */   }
/*    */   
/*    */   public String[] getColumnAliases(int loc) {
/* 63 */     return this.columnAliases;
/*    */   }
/*    */   
/*    */   public boolean isGrouped() {
/* 67 */     return this.grouped;
/*    */   }
/*    */   
/*    */   public Type[] getTypes(String alias, Criteria crit, CriteriaQuery criteriaQuery) {
/* 71 */     return null;
/*    */   }
/*    */   
/*    */   public String[] getColumnAliases(String alias, int loc) {
/* 75 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\SQLProjection.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */