/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.transform.AliasToEntityMapResultTransformer;
/*    */ import org.hibernate.transform.DistinctRootEntityResultTransformer;
/*    */ import org.hibernate.transform.PassThroughResultTransformer;
/*    */ import org.hibernate.transform.ResultTransformer;
/*    */ import org.hibernate.transform.RootEntityResultTransformer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface CriteriaSpecification
/*    */ {
/*    */   public static final String ROOT_ALIAS = "this";
/* 23 */   public static final ResultTransformer ALIAS_TO_ENTITY_MAP = new AliasToEntityMapResultTransformer();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 28 */   public static final ResultTransformer ROOT_ENTITY = new RootEntityResultTransformer();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 33 */   public static final ResultTransformer DISTINCT_ROOT_ENTITY = new DistinctRootEntityResultTransformer();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 38 */   public static final ResultTransformer PROJECTION = new PassThroughResultTransformer();
/*    */   public static final int INNER_JOIN = 0;
/*    */   public static final int FULL_JOIN = 4;
/*    */   public static final int LEFT_JOIN = 1;
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\CriteriaSpecification.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */