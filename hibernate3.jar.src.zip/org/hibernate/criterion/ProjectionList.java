/*     */ package org.hibernate.criterion;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.hibernate.Criteria;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.ArrayHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProjectionList
/*     */   implements Projection
/*     */ {
/*  17 */   private List elements = new ArrayList();
/*     */   
/*     */ 
/*     */   public ProjectionList create()
/*     */   {
/*  22 */     return new ProjectionList();
/*     */   }
/*     */   
/*     */   public ProjectionList add(Projection proj) {
/*  26 */     this.elements.add(proj);
/*  27 */     return this;
/*     */   }
/*     */   
/*     */   public ProjectionList add(Projection projection, String alias) {
/*  31 */     return add(Projections.alias(projection, alias));
/*     */   }
/*     */   
/*     */   public Type[] getTypes(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*     */   {
/*  36 */     List types = new ArrayList(getLength());
/*  37 */     for (int i = 0; i < getLength(); i++) {
/*  38 */       Type[] elemTypes = getProjection(i).getTypes(criteria, criteriaQuery);
/*  39 */       ArrayHelper.addAll(types, elemTypes);
/*     */     }
/*  41 */     return ArrayHelper.toTypeArray(types);
/*     */   }
/*     */   
/*     */   public String toSqlString(Criteria criteria, int loc, CriteriaQuery criteriaQuery) throws HibernateException
/*     */   {
/*  46 */     StringBuffer buf = new StringBuffer();
/*  47 */     for (int i = 0; i < getLength(); i++) {
/*  48 */       Projection proj = getProjection(i);
/*  49 */       buf.append(proj.toSqlString(criteria, loc, criteriaQuery));
/*  50 */       loc += proj.getColumnAliases(loc).length;
/*  51 */       if (i < this.elements.size() - 1) buf.append(", ");
/*     */     }
/*  53 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public String toGroupSqlString(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*     */   {
/*  58 */     StringBuffer buf = new StringBuffer();
/*  59 */     for (int i = 0; i < getLength(); i++) {
/*  60 */       Projection proj = getProjection(i);
/*  61 */       if (proj.isGrouped()) {
/*  62 */         buf.append(proj.toGroupSqlString(criteria, criteriaQuery)).append(", ");
/*     */       }
/*     */     }
/*     */     
/*  66 */     if (buf.length() > 2) buf.setLength(buf.length() - 2);
/*  67 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public String[] getColumnAliases(int loc) {
/*  71 */     List result = new ArrayList(getLength());
/*  72 */     for (int i = 0; i < getLength(); i++) {
/*  73 */       String[] colAliases = getProjection(i).getColumnAliases(loc);
/*  74 */       ArrayHelper.addAll(result, colAliases);
/*  75 */       loc += colAliases.length;
/*     */     }
/*  77 */     return ArrayHelper.toStringArray(result);
/*     */   }
/*     */   
/*     */   public String[] getColumnAliases(String alias, int loc) {
/*  81 */     for (int i = 0; i < getLength(); i++) {
/*  82 */       String[] result = getProjection(i).getColumnAliases(alias, loc);
/*  83 */       if (result != null) return result;
/*  84 */       loc += getProjection(i).getColumnAliases(loc).length;
/*     */     }
/*  86 */     return null;
/*     */   }
/*     */   
/*     */   public Type[] getTypes(String alias, Criteria criteria, CriteriaQuery criteriaQuery) {
/*  90 */     for (int i = 0; i < getLength(); i++) {
/*  91 */       Type[] result = getProjection(i).getTypes(alias, criteria, criteriaQuery);
/*  92 */       if (result != null) return result;
/*     */     }
/*  94 */     return null;
/*     */   }
/*     */   
/*     */   public String[] getAliases() {
/*  98 */     List result = new ArrayList(getLength());
/*  99 */     for (int i = 0; i < getLength(); i++) {
/* 100 */       String[] aliases = getProjection(i).getAliases();
/* 101 */       ArrayHelper.addAll(result, aliases);
/*     */     }
/* 103 */     return ArrayHelper.toStringArray(result);
/*     */   }
/*     */   
/*     */   public Projection getProjection(int i)
/*     */   {
/* 108 */     return (Projection)this.elements.get(i);
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 112 */     return this.elements.size();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 116 */     return this.elements.toString();
/*     */   }
/*     */   
/*     */   public boolean isGrouped() {
/* 120 */     for (int i = 0; i < getLength(); i++) {
/* 121 */       if (getProjection(i).isGrouped()) return true;
/*     */     }
/* 123 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\ProjectionList.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */