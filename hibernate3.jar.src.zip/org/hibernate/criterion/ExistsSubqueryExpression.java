/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExistsSubqueryExpression
/*    */   extends SubqueryExpression
/*    */ {
/*    */   protected String toLeftSqlString(Criteria criteria, CriteriaQuery outerQuery)
/*    */   {
/* 12 */     return "";
/*    */   }
/*    */   
/*    */   protected ExistsSubqueryExpression(String quantifier, DetachedCriteria dc) {
/* 16 */     super(null, quantifier, dc);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\ExistsSubqueryExpression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */