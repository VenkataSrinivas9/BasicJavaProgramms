package org.hibernate.criterion;

import java.io.Serializable;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.engine.TypedValue;

public abstract interface Criterion
  extends Serializable
{
  public abstract String toSqlString(Criteria paramCriteria, CriteriaQuery paramCriteriaQuery)
    throws HibernateException;
  
  public abstract TypedValue[] getTypedValues(Criteria paramCriteria, CriteriaQuery paramCriteriaQuery)
    throws HibernateException;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\Criterion.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */