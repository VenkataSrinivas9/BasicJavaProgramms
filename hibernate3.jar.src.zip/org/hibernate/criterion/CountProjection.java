/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.Hibernate;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CountProjection
/*    */   extends AggregateProjection
/*    */ {
/*    */   private boolean distinct;
/*    */   
/*    */   protected CountProjection(String prop)
/*    */   {
/* 18 */     super("count", prop);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 22 */     if (this.distinct) {
/* 23 */       return "distinct " + super.toString();
/*    */     }
/* 25 */     return super.toString();
/*    */   }
/*    */   
/*    */   public Type[] getTypes(Criteria criteria, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 31 */     return new Type[] { Hibernate.INTEGER };
/*    */   }
/*    */   
/*    */   public String toSqlString(Criteria criteria, int position, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 36 */     StringBuffer buf = new StringBuffer();
/* 37 */     buf.append("count(");
/* 38 */     if (this.distinct) buf.append("distinct ");
/* 39 */     return criteriaQuery.getColumn(criteria, this.propertyName) + ") as y" + position + '_';
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public CountProjection setDistinct()
/*    */   {
/* 47 */     this.distinct = true;
/* 48 */     return this;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\CountProjection.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */