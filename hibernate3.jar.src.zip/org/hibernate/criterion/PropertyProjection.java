/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyProjection
/*    */   extends SimpleProjection
/*    */ {
/*    */   private String propertyName;
/*    */   private boolean grouped;
/*    */   
/*    */   protected PropertyProjection(String prop, boolean grouped)
/*    */   {
/* 18 */     this.propertyName = prop;
/* 19 */     this.grouped = grouped;
/*    */   }
/*    */   
/*    */   protected PropertyProjection(String prop) {
/* 23 */     this(prop, false);
/*    */   }
/*    */   
/*    */   public String getPropertyName() {
/* 27 */     return this.propertyName;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 31 */     return this.propertyName;
/*    */   }
/*    */   
/*    */   public Type[] getTypes(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 36 */     return new Type[] { criteriaQuery.getType(criteria, this.propertyName) };
/*    */   }
/*    */   
/*    */   public String toSqlString(Criteria criteria, int position, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 41 */     return criteriaQuery.getColumn(criteria, this.propertyName) + " as y" + position + '_';
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isGrouped()
/*    */   {
/* 50 */     return this.grouped;
/*    */   }
/*    */   
/*    */   public String toGroupSqlString(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 55 */     if (!this.grouped) {
/* 56 */       return super.toGroupSqlString(criteria, criteriaQuery);
/*    */     }
/*    */     
/* 59 */     return criteriaQuery.getColumn(criteria, this.propertyName);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\PropertyProjection.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */