/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.Hibernate;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AvgProjection
/*    */   extends AggregateProjection
/*    */ {
/*    */   public AvgProjection(String propertyName)
/*    */   {
/* 29 */     super("avg", propertyName);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Type[] getTypes(Criteria criteria, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 39 */     return new Type[] { Hibernate.DOUBLE };
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\AvgProjection.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */