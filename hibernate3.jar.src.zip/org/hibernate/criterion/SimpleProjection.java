/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SimpleProjection
/*    */   implements Projection
/*    */ {
/*    */   public Projection as(String alias)
/*    */   {
/* 16 */     return Projections.alias(this, alias);
/*    */   }
/*    */   
/*    */   public String[] getColumnAliases(String alias, int loc) {
/* 20 */     return null;
/*    */   }
/*    */   
/*    */   public Type[] getTypes(String alias, Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 25 */     return null;
/*    */   }
/*    */   
/*    */   public String[] getColumnAliases(int loc) {
/* 29 */     return new String[] { "y" + loc + "_" };
/*    */   }
/*    */   
/*    */   public String[] getAliases() {
/* 33 */     return new String[1];
/*    */   }
/*    */   
/*    */   public String toGroupSqlString(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 38 */     throw new UnsupportedOperationException("not a grouping projection");
/*    */   }
/*    */   
/*    */   public boolean isGrouped() {
/* 42 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\SimpleProjection.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */