/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.dialect.Dialect;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Order
/*    */   implements Serializable
/*    */ {
/*    */   private boolean ascending;
/*    */   private boolean ignoreCase;
/*    */   private String propertyName;
/*    */   
/*    */   public String toString()
/*    */   {
/* 23 */     return this.propertyName + ' ' + (this.ascending ? "asc" : "desc");
/*    */   }
/*    */   
/*    */   public Order ignoreCase() {
/* 27 */     this.ignoreCase = true;
/* 28 */     return this;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected Order(String propertyName, boolean ascending)
/*    */   {
/* 35 */     this.propertyName = propertyName;
/* 36 */     this.ascending = ascending;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toSqlString(Criteria criteria, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 45 */     String[] columns = criteriaQuery.getColumnsUsingProjection(criteria, this.propertyName);
/* 46 */     Type type = criteriaQuery.getTypeUsingProjection(criteria, this.propertyName);
/* 47 */     StringBuffer fragment = new StringBuffer();
/* 48 */     for (int i = 0; i < columns.length; i++) {
/* 49 */       SessionFactoryImplementor factory = criteriaQuery.getFactory();
/* 50 */       boolean lower = (this.ignoreCase) && (type.sqlTypes(factory)[i] == 12);
/* 51 */       if (lower) {
/* 52 */         fragment.append(factory.getDialect().getLowercaseFunction()).append('(');
/*    */       }
/*    */       
/* 55 */       fragment.append(columns[i]);
/* 56 */       if (lower) fragment.append(')');
/* 57 */       fragment.append(this.ascending ? " asc" : " desc");
/* 58 */       if (i < columns.length - 1) fragment.append(", ");
/*    */     }
/* 60 */     return fragment.toString();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Order asc(String propertyName)
/*    */   {
/* 70 */     return new Order(propertyName, true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Order desc(String propertyName)
/*    */   {
/* 80 */     return new Order(propertyName, false);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\Order.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */