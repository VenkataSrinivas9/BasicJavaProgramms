/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.dialect.MySQLDialect;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.engine.TypedValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotExpression
/*    */   implements Criterion
/*    */ {
/*    */   private Criterion criterion;
/*    */   
/*    */   protected NotExpression(Criterion criterion)
/*    */   {
/* 19 */     this.criterion = criterion;
/*    */   }
/*    */   
/*    */   public String toSqlString(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 24 */     if ((criteriaQuery.getFactory().getDialect() instanceof MySQLDialect)) {
/* 25 */       return "not (" + this.criterion.toSqlString(criteria, criteriaQuery) + ')';
/*    */     }
/*    */     
/* 28 */     return "not " + this.criterion.toSqlString(criteria, criteriaQuery);
/*    */   }
/*    */   
/*    */ 
/*    */   public TypedValue[] getTypedValues(Criteria criteria, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 35 */     return this.criterion.getTypedValues(criteria, criteriaQuery);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 39 */     return "not " + this.criterion.toString();
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\NotExpression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */