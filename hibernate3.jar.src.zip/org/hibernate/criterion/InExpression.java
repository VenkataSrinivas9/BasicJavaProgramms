/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.EntityMode;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.engine.TypedValue;
/*    */ import org.hibernate.type.AbstractComponentType;
/*    */ import org.hibernate.type.Type;
/*    */ import org.hibernate.util.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InExpression
/*    */   implements Criterion
/*    */ {
/*    */   private final String propertyName;
/*    */   private final Object[] values;
/*    */   
/*    */   protected InExpression(String propertyName, Object[] values)
/*    */   {
/* 29 */     this.propertyName = propertyName;
/* 30 */     this.values = values;
/*    */   }
/*    */   
/*    */   public String toSqlString(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 35 */     String[] columns = criteriaQuery.getColumnsUsingProjection(criteria, this.propertyName);
/* 36 */     String singleValueParam = StringHelper.repeat("?, ", columns.length - 1) + "?";
/* 37 */     if (columns.length > 1) singleValueParam = '(' + singleValueParam + ')';
/* 38 */     String params = this.values.length > 0 ? StringHelper.repeat(new StringBuffer().append(singleValueParam).append(", ").toString(), this.values.length - 1) + singleValueParam : "";
/*    */     
/*    */ 
/* 41 */     String cols = StringHelper.join(", ", columns);
/* 42 */     if (columns.length > 1) cols = '(' + cols + ')';
/* 43 */     return cols + " in (" + params + ')';
/*    */   }
/*    */   
/*    */   public TypedValue[] getTypedValues(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 48 */     ArrayList list = new ArrayList();
/* 49 */     Type type = criteriaQuery.getTypeUsingProjection(criteria, this.propertyName);
/* 50 */     if (type.isComponentType()) {
/* 51 */       AbstractComponentType actype = (AbstractComponentType)type;
/* 52 */       Type[] types = actype.getSubtypes();
/* 53 */       for (int i = 0; i < types.length; i++) {
/* 54 */         for (int j = 0; j < this.values.length; j++) {
/* 55 */           Object subval = this.values[j] == null ? null : actype.getPropertyValues(this.values[j], EntityMode.POJO)[i];
/*    */           
/*    */ 
/* 58 */           list.add(new TypedValue(types[i], subval, EntityMode.POJO));
/*    */         }
/*    */       }
/*    */     }
/*    */     else {
/* 63 */       for (int j = 0; j < this.values.length; j++) {
/* 64 */         list.add(new TypedValue(type, this.values[j], EntityMode.POJO));
/*    */       }
/*    */     }
/* 67 */     return (TypedValue[])list.toArray(new TypedValue[list.size()]);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 71 */     return this.propertyName + " in (" + StringHelper.toString(this.values) + ')';
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\InExpression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */