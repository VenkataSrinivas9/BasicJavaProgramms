/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertySubqueryExpression
/*    */   extends SubqueryExpression
/*    */ {
/*    */   private String propertyName;
/*    */   
/*    */   protected PropertySubqueryExpression(String propertyName, String op, String quantifier, DetachedCriteria dc)
/*    */   {
/* 15 */     super(op, quantifier, dc);
/* 16 */     this.propertyName = propertyName;
/*    */   }
/*    */   
/*    */   protected String toLeftSqlString(Criteria criteria, CriteriaQuery criteriaQuery) {
/* 20 */     return criteriaQuery.getColumn(criteria, this.propertyName);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\PropertySubqueryExpression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */