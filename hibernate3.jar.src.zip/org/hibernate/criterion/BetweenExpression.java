/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.engine.TypedValue;
/*    */ import org.hibernate.util.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BetweenExpression
/*    */   implements Criterion
/*    */ {
/*    */   private final String propertyName;
/*    */   private final Object lo;
/*    */   private final Object hi;
/*    */   
/*    */   protected BetweenExpression(String propertyName, Object lo, Object hi)
/*    */   {
/* 21 */     this.propertyName = propertyName;
/* 22 */     this.lo = lo;
/* 23 */     this.hi = hi;
/*    */   }
/*    */   
/*    */   public String toSqlString(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 28 */     return StringHelper.join(" and ", StringHelper.suffix(criteriaQuery.getColumnsUsingProjection(criteria, this.propertyName), " between ? and ?"));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TypedValue[] getTypedValues(Criteria criteria, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 38 */     return new TypedValue[] { criteriaQuery.getTypedValue(criteria, this.propertyName, this.lo), criteriaQuery.getTypedValue(criteria, this.propertyName, this.hi) };
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 45 */     return this.propertyName + " between " + this.lo + " and " + this.hi;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\BetweenExpression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */