/*     */ package org.hibernate.criterion;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.ArrayHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Restrictions
/*     */ {
/*     */   public static Criterion idEq(Object value)
/*     */   {
/*  33 */     return new IdentifierEqExpression(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SimpleExpression eq(String propertyName, Object value)
/*     */   {
/*  42 */     return new SimpleExpression(propertyName, value, "=");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SimpleExpression ne(String propertyName, Object value)
/*     */   {
/*  51 */     return new SimpleExpression(propertyName, value, "<>");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SimpleExpression like(String propertyName, Object value)
/*     */   {
/*  60 */     return new SimpleExpression(propertyName, value, " like ");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SimpleExpression like(String propertyName, String value, MatchMode matchMode)
/*     */   {
/*  69 */     return new SimpleExpression(propertyName, matchMode.toMatchString(value), " like ");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Criterion ilike(String propertyName, String value, MatchMode matchMode)
/*     */   {
/*  80 */     return new IlikeExpression(propertyName, value, matchMode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Criterion ilike(String propertyName, Object value)
/*     */   {
/*  91 */     return new IlikeExpression(propertyName, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SimpleExpression gt(String propertyName, Object value)
/*     */   {
/* 100 */     return new SimpleExpression(propertyName, value, ">");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SimpleExpression lt(String propertyName, Object value)
/*     */   {
/* 109 */     return new SimpleExpression(propertyName, value, "<");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SimpleExpression le(String propertyName, Object value)
/*     */   {
/* 118 */     return new SimpleExpression(propertyName, value, "<=");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SimpleExpression ge(String propertyName, Object value)
/*     */   {
/* 127 */     return new SimpleExpression(propertyName, value, ">=");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Criterion between(String propertyName, Object lo, Object hi)
/*     */   {
/* 137 */     return new BetweenExpression(propertyName, lo, hi);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Criterion in(String propertyName, Object[] values)
/*     */   {
/* 146 */     return new InExpression(propertyName, values);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Criterion in(String propertyName, Collection values)
/*     */   {
/* 155 */     return new InExpression(propertyName, values.toArray());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Criterion isNull(String propertyName)
/*     */   {
/* 162 */     return new NullExpression(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */   public static PropertyExpression eqProperty(String propertyName, String otherPropertyName)
/*     */   {
/* 168 */     return new PropertyExpression(propertyName, otherPropertyName, "=");
/*     */   }
/*     */   
/*     */ 
/*     */   public static PropertyExpression neProperty(String propertyName, String otherPropertyName)
/*     */   {
/* 174 */     return new PropertyExpression(propertyName, otherPropertyName, "<>");
/*     */   }
/*     */   
/*     */ 
/*     */   public static PropertyExpression ltProperty(String propertyName, String otherPropertyName)
/*     */   {
/* 180 */     return new PropertyExpression(propertyName, otherPropertyName, "<");
/*     */   }
/*     */   
/*     */ 
/*     */   public static PropertyExpression leProperty(String propertyName, String otherPropertyName)
/*     */   {
/* 186 */     return new PropertyExpression(propertyName, otherPropertyName, "<=");
/*     */   }
/*     */   
/*     */ 
/*     */   public static PropertyExpression gtProperty(String propertyName, String otherPropertyName)
/*     */   {
/* 192 */     return new PropertyExpression(propertyName, otherPropertyName, ">");
/*     */   }
/*     */   
/*     */ 
/*     */   public static PropertyExpression geProperty(String propertyName, String otherPropertyName)
/*     */   {
/* 198 */     return new PropertyExpression(propertyName, otherPropertyName, ">=");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Criterion isNotNull(String propertyName)
/*     */   {
/* 205 */     return new NotNullExpression(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static LogicalExpression and(Criterion lhs, Criterion rhs)
/*     */   {
/* 215 */     return new LogicalExpression(lhs, rhs, "and");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static LogicalExpression or(Criterion lhs, Criterion rhs)
/*     */   {
/* 225 */     return new LogicalExpression(lhs, rhs, "or");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Criterion not(Criterion expression)
/*     */   {
/* 234 */     return new NotExpression(expression);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Criterion sqlRestriction(String sql, Object[] values, Type[] types)
/*     */   {
/* 247 */     return new SQLCriterion(sql, values, types);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Criterion sqlRestriction(String sql, Object value, Type type)
/*     */   {
/* 260 */     return new SQLCriterion(sql, new Object[] { value }, new Type[] { type });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Criterion sqlRestriction(String sql)
/*     */   {
/* 270 */     return new SQLCriterion(sql, ArrayHelper.EMPTY_OBJECT_ARRAY, ArrayHelper.EMPTY_TYPE_ARRAY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Conjunction conjunction()
/*     */   {
/* 279 */     return new Conjunction();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Disjunction disjunction()
/*     */   {
/* 288 */     return new Disjunction();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Criterion allEq(Map propertyNameValues)
/*     */   {
/* 299 */     Conjunction conj = conjunction();
/* 300 */     Iterator iter = propertyNameValues.entrySet().iterator();
/* 301 */     while (iter.hasNext()) {
/* 302 */       Map.Entry me = (Map.Entry)iter.next();
/* 303 */       conj.add(eq((String)me.getKey(), me.getValue()));
/*     */     }
/* 305 */     return conj;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Criterion isEmpty(String propertyName)
/*     */   {
/* 312 */     return new EmptyExpression(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Criterion isNotEmpty(String propertyName)
/*     */   {
/* 319 */     return new NotEmptyExpression(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Criterion sizeEq(String propertyName, int size)
/*     */   {
/* 326 */     return new SizeExpression(propertyName, size, "=");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Criterion sizeNe(String propertyName, int size)
/*     */   {
/* 333 */     return new SizeExpression(propertyName, size, "<>");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Criterion sizeGt(String propertyName, int size)
/*     */   {
/* 340 */     return new SizeExpression(propertyName, size, "<");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Criterion sizeLt(String propertyName, int size)
/*     */   {
/* 347 */     return new SizeExpression(propertyName, size, ">");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Criterion sizeGe(String propertyName, int size)
/*     */   {
/* 354 */     return new SizeExpression(propertyName, size, "<=");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Criterion sizeLe(String propertyName, int size)
/*     */   {
/* 361 */     return new SizeExpression(propertyName, size, ">=");
/*     */   }
/*     */   
/*     */   public static NaturalIdentifier naturalId() {
/* 365 */     return new NaturalIdentifier();
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\Restrictions.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */