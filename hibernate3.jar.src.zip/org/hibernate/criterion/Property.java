/*     */ package org.hibernate.criterion;
/*     */ 
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Property
/*     */   extends PropertyProjection
/*     */ {
/*     */   protected Property(String propertyName)
/*     */   {
/*  13 */     super(propertyName);
/*     */   }
/*     */   
/*     */   public Criterion between(Object min, Object max) {
/*  17 */     return Restrictions.between(getPropertyName(), min, max);
/*     */   }
/*     */   
/*     */   public Criterion in(Collection values) {
/*  21 */     return Restrictions.in(getPropertyName(), values);
/*     */   }
/*     */   
/*     */   public Criterion in(Object[] values) {
/*  25 */     return Restrictions.in(getPropertyName(), values);
/*     */   }
/*     */   
/*     */   public SimpleExpression like(Object value) {
/*  29 */     return Restrictions.like(getPropertyName(), value);
/*     */   }
/*     */   
/*     */   public SimpleExpression like(String value, MatchMode matchMode) {
/*  33 */     return Restrictions.like(getPropertyName(), value, matchMode);
/*     */   }
/*     */   
/*     */   public SimpleExpression eq(Object value) {
/*  37 */     return Restrictions.eq(getPropertyName(), value);
/*     */   }
/*     */   
/*     */   public SimpleExpression ne(Object value) {
/*  41 */     return Restrictions.ne(getPropertyName(), value);
/*     */   }
/*     */   
/*     */   public SimpleExpression gt(Object value) {
/*  45 */     return Restrictions.gt(getPropertyName(), value);
/*     */   }
/*     */   
/*     */   public SimpleExpression lt(Object value) {
/*  49 */     return Restrictions.lt(getPropertyName(), value);
/*     */   }
/*     */   
/*     */   public SimpleExpression le(Object value) {
/*  53 */     return Restrictions.le(getPropertyName(), value);
/*     */   }
/*     */   
/*     */   public SimpleExpression ge(Object value) {
/*  57 */     return Restrictions.ge(getPropertyName(), value);
/*     */   }
/*     */   
/*     */   public PropertyExpression eqProperty(Property other) {
/*  61 */     return Restrictions.eqProperty(getPropertyName(), other.getPropertyName());
/*     */   }
/*     */   
/*     */   public PropertyExpression neProperty(Property other) {
/*  65 */     return Restrictions.neProperty(getPropertyName(), other.getPropertyName());
/*     */   }
/*     */   
/*     */   public PropertyExpression leProperty(Property other) {
/*  69 */     return Restrictions.leProperty(getPropertyName(), other.getPropertyName());
/*     */   }
/*     */   
/*     */   public PropertyExpression geProperty(Property other) {
/*  73 */     return Restrictions.geProperty(getPropertyName(), other.getPropertyName());
/*     */   }
/*     */   
/*     */   public PropertyExpression ltProperty(Property other) {
/*  77 */     return Restrictions.ltProperty(getPropertyName(), other.getPropertyName());
/*     */   }
/*     */   
/*     */   public PropertyExpression gtProperty(Property other) {
/*  81 */     return Restrictions.gtProperty(getPropertyName(), other.getPropertyName());
/*     */   }
/*     */   
/*     */   public PropertyExpression eqProperty(String other) {
/*  85 */     return Restrictions.eqProperty(getPropertyName(), other);
/*     */   }
/*     */   
/*     */   public PropertyExpression neProperty(String other) {
/*  89 */     return Restrictions.neProperty(getPropertyName(), other);
/*     */   }
/*     */   
/*     */   public PropertyExpression leProperty(String other) {
/*  93 */     return Restrictions.leProperty(getPropertyName(), other);
/*     */   }
/*     */   
/*     */   public PropertyExpression geProperty(String other) {
/*  97 */     return Restrictions.geProperty(getPropertyName(), other);
/*     */   }
/*     */   
/*     */   public PropertyExpression ltProperty(String other) {
/* 101 */     return Restrictions.ltProperty(getPropertyName(), other);
/*     */   }
/*     */   
/*     */   public PropertyExpression gtProperty(String other) {
/* 105 */     return Restrictions.gtProperty(getPropertyName(), other);
/*     */   }
/*     */   
/*     */   public Criterion isNull() {
/* 109 */     return Restrictions.isNull(getPropertyName());
/*     */   }
/*     */   
/*     */   public Criterion isNotNull() {
/* 113 */     return Restrictions.isNotNull(getPropertyName());
/*     */   }
/*     */   
/*     */   public Criterion isEmpty() {
/* 117 */     return Restrictions.isEmpty(getPropertyName());
/*     */   }
/*     */   
/*     */   public Criterion isNotEmpty() {
/* 121 */     return Restrictions.isNotEmpty(getPropertyName());
/*     */   }
/*     */   
/*     */   public CountProjection count() {
/* 125 */     return Projections.count(getPropertyName());
/*     */   }
/*     */   
/*     */   public AggregateProjection max() {
/* 129 */     return Projections.max(getPropertyName());
/*     */   }
/*     */   
/*     */   public AggregateProjection min() {
/* 133 */     return Projections.min(getPropertyName());
/*     */   }
/*     */   
/*     */   public AggregateProjection avg() {
/* 137 */     return Projections.avg(getPropertyName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertyProjection group()
/*     */   {
/* 145 */     return Projections.groupProperty(getPropertyName());
/*     */   }
/*     */   
/*     */   public Order asc() {
/* 149 */     return Order.asc(getPropertyName());
/*     */   }
/*     */   
/*     */   public Order desc() {
/* 153 */     return Order.desc(getPropertyName());
/*     */   }
/*     */   
/*     */   public static Property forName(String propertyName) {
/* 157 */     return new Property(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Property getProperty(String propertyName)
/*     */   {
/* 164 */     return forName(getPropertyName() + '.' + propertyName);
/*     */   }
/*     */   
/*     */   public Criterion eq(DetachedCriteria subselect) {
/* 168 */     return Subqueries.propertyEq(getPropertyName(), subselect);
/*     */   }
/*     */   
/*     */   public Criterion ne(DetachedCriteria subselect) {
/* 172 */     return Subqueries.propertyNe(getPropertyName(), subselect);
/*     */   }
/*     */   
/*     */   public Criterion lt(DetachedCriteria subselect) {
/* 176 */     return Subqueries.propertyLt(getPropertyName(), subselect);
/*     */   }
/*     */   
/*     */   public Criterion le(DetachedCriteria subselect) {
/* 180 */     return Subqueries.propertyLe(getPropertyName(), subselect);
/*     */   }
/*     */   
/*     */   public Criterion gt(DetachedCriteria subselect) {
/* 184 */     return Subqueries.propertyGt(getPropertyName(), subselect);
/*     */   }
/*     */   
/*     */   public Criterion ge(DetachedCriteria subselect) {
/* 188 */     return Subqueries.propertyGe(getPropertyName(), subselect);
/*     */   }
/*     */   
/*     */   public Criterion notIn(DetachedCriteria subselect) {
/* 192 */     return Subqueries.propertyNotIn(getPropertyName(), subselect);
/*     */   }
/*     */   
/*     */   public Criterion in(DetachedCriteria subselect) {
/* 196 */     return Subqueries.propertyIn(getPropertyName(), subselect);
/*     */   }
/*     */   
/*     */   public Criterion eqAll(DetachedCriteria subselect) {
/* 200 */     return Subqueries.propertyEqAll(getPropertyName(), subselect);
/*     */   }
/*     */   
/*     */   public Criterion gtAll(DetachedCriteria subselect) {
/* 204 */     return Subqueries.propertyGtAll(getPropertyName(), subselect);
/*     */   }
/*     */   
/*     */   public Criterion ltAll(DetachedCriteria subselect) {
/* 208 */     return Subqueries.propertyLtAll(getPropertyName(), subselect);
/*     */   }
/*     */   
/*     */   public Criterion leAll(DetachedCriteria subselect) {
/* 212 */     return Subqueries.propertyLeAll(getPropertyName(), subselect);
/*     */   }
/*     */   
/*     */   public Criterion geAll(DetachedCriteria subselect) {
/* 216 */     return Subqueries.propertyGeAll(getPropertyName(), subselect);
/*     */   }
/*     */   
/*     */   public Criterion gtSome(DetachedCriteria subselect) {
/* 220 */     return Subqueries.propertyGtSome(getPropertyName(), subselect);
/*     */   }
/*     */   
/*     */   public Criterion ltSome(DetachedCriteria subselect) {
/* 224 */     return Subqueries.propertyLtSome(getPropertyName(), subselect);
/*     */   }
/*     */   
/*     */   public Criterion leSome(DetachedCriteria subselect) {
/* 228 */     return Subqueries.propertyLeSome(getPropertyName(), subselect);
/*     */   }
/*     */   
/*     */   public Criterion geSome(DetachedCriteria subselect) {
/* 232 */     return Subqueries.propertyGeSome(getPropertyName(), subselect);
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\Property.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */