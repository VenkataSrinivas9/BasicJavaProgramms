/*    */ package org.hibernate.criterion;
/*    */ 
/*    */ import org.hibernate.Criteria;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.engine.TypedValue;
/*    */ import org.hibernate.util.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyExpression
/*    */   implements Criterion
/*    */ {
/*    */   private final String propertyName;
/*    */   private final String otherPropertyName;
/*    */   private final String op;
/* 20 */   private static final TypedValue[] NO_TYPED_VALUES = new TypedValue[0];
/*    */   
/*    */   protected PropertyExpression(String propertyName, String otherPropertyName, String op) {
/* 23 */     this.propertyName = propertyName;
/* 24 */     this.otherPropertyName = otherPropertyName;
/* 25 */     this.op = op;
/*    */   }
/*    */   
/*    */   public String toSqlString(Criteria criteria, CriteriaQuery criteriaQuery) throws HibernateException
/*    */   {
/* 30 */     String[] xcols = criteriaQuery.getColumnsUsingProjection(criteria, this.propertyName);
/* 31 */     String[] ycols = criteriaQuery.getColumnsUsingProjection(criteria, this.otherPropertyName);
/* 32 */     String result = StringHelper.join(" and ", StringHelper.add(xcols, getOp(), ycols));
/*    */     
/*    */ 
/*    */ 
/* 36 */     if (xcols.length > 1) result = '(' + result + ')';
/* 37 */     return result;
/*    */   }
/*    */   
/*    */   public TypedValue[] getTypedValues(Criteria criteria, CriteriaQuery criteriaQuery)
/*    */     throws HibernateException
/*    */   {
/* 43 */     return NO_TYPED_VALUES;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 47 */     return this.propertyName + getOp() + this.otherPropertyName;
/*    */   }
/*    */   
/*    */   public String getOp() {
/* 51 */     return this.op;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\criterion\PropertyExpression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */