/*     */ package org.hibernate.context;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import java.util.Map;
/*     */ import javax.transaction.Synchronization;
/*     */ import javax.transaction.Transaction;
/*     */ import javax.transaction.TransactionManager;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.ConnectionReleaseMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.classic.Session;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.util.JTAHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JTASessionContext
/*     */   implements CurrentSessionContext
/*     */ {
/*  42 */   private static final Log log = LogFactory.getLog(JTASessionContext.class);
/*     */   
/*     */   protected final SessionFactoryImplementor factory;
/*  45 */   private transient Map currentSessionMap = new Hashtable();
/*     */   
/*     */   public JTASessionContext(SessionFactoryImplementor factory) {
/*  48 */     this.factory = factory;
/*     */   }
/*     */   
/*     */   public Session currentSession() throws HibernateException {
/*  52 */     TransactionManager transactionManager = this.factory.getTransactionManager();
/*  53 */     if (transactionManager == null) {
/*  54 */       throw new HibernateException("No TransactionManagerLookup specified");
/*     */     }
/*     */     
/*  57 */     Transaction txn = null;
/*     */     try {
/*  59 */       txn = transactionManager.getTransaction();
/*  60 */       if (txn == null) {
/*  61 */         throw new HibernateException("Unable to locate current JTA transaction");
/*     */       }
/*  63 */       if (!JTAHelper.isInProgress(txn.getStatus()))
/*     */       {
/*     */ 
/*     */ 
/*  67 */         throw new HibernateException("Current transaction is not in progress");
/*     */       }
/*     */     }
/*     */     catch (HibernateException e) {
/*  71 */       throw e;
/*     */     }
/*     */     catch (Throwable t) {
/*  74 */       throw new HibernateException("Problem locating/validating JTA transaction", t);
/*     */     }
/*     */     
/*  77 */     Session currentSession = (Session)this.currentSessionMap.get(txn);
/*     */     
/*  79 */     if (currentSession == null) {
/*  80 */       currentSession = buildOrObtainSession();
/*     */       try
/*     */       {
/*  83 */         txn.registerSynchronization(buildCleanupSynch(txn));
/*     */       }
/*     */       catch (Throwable t) {
/*     */         try {
/*  87 */           currentSession.close();
/*     */         }
/*     */         catch (Throwable ignore) {
/*  90 */           log.debug("Unable to release generated current-session on failed synch registration", ignore);
/*     */         }
/*  92 */         throw new HibernateException("Unable to register cleanup Synchronization with TransactionManager");
/*     */       }
/*     */       
/*  95 */       this.currentSessionMap.put(txn, currentSession);
/*     */     }
/*     */     
/*  98 */     return currentSession;
/*     */   }
/*     */   
/*     */   private CleanupSynch buildCleanupSynch(Transaction txn) {
/* 102 */     return new CleanupSynch(txn, this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Session buildOrObtainSession()
/*     */   {
/* 114 */     return this.factory.openSession(null, isAutoFlushEnabled(), isAutoCloseEnabled(), getConnectionReleaseMode());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isAutoCloseEnabled()
/*     */   {
/* 128 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isAutoFlushEnabled()
/*     */   {
/* 137 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ConnectionReleaseMode getConnectionReleaseMode()
/*     */   {
/* 146 */     return ConnectionReleaseMode.AFTER_STATEMENT;
/*     */   }
/*     */   
/*     */   protected static class CleanupSynch
/*     */     implements Synchronization
/*     */   {
/*     */     private Transaction txn;
/*     */     private JTASessionContext context;
/*     */     
/*     */     public CleanupSynch(Transaction txn, JTASessionContext context)
/*     */     {
/* 157 */       this.txn = txn;
/* 158 */       this.context = context;
/*     */     }
/*     */     
/*     */     public void beforeCompletion() {}
/*     */     
/*     */     public void afterCompletion(int i)
/*     */     {
/* 165 */       this.context.currentSessionMap.remove(this.txn);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\context\JTASessionContext.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */