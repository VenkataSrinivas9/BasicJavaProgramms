/*     */ package org.hibernate.context;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.hibernate.classic.Session;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ManagedSessionContext
/*     */   implements CurrentSessionContext
/*     */ {
/*  37 */   private static final ThreadLocal context = new ThreadLocal();
/*     */   private final SessionFactoryImplementor factory;
/*     */   
/*     */   public ManagedSessionContext(SessionFactoryImplementor factory) {
/*  41 */     this.factory = factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Session currentSession()
/*     */   {
/*  48 */     Session current = existingSession(this.factory);
/*  49 */     if (current == null) {
/*  50 */       throw new HibernateException("No session currently bound to execution context");
/*     */     }
/*  52 */     return current;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean hasBind(SessionFactory factory)
/*     */   {
/*  64 */     return existingSession(factory) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Session bind(Session session)
/*     */   {
/*  74 */     return (Session)sessionMap(true).put(session.getSessionFactory(), session);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Session unbind(SessionFactory factory)
/*     */   {
/*  85 */     Session existing = null;
/*  86 */     Map sessionMap = sessionMap();
/*  87 */     if (sessionMap != null) {
/*  88 */       existing = (Session)sessionMap.remove(factory);
/*  89 */       doCleanup();
/*     */     }
/*  91 */     return existing;
/*     */   }
/*     */   
/*     */   private static Session existingSession(SessionFactory factory) {
/*  95 */     Map sessionMap = sessionMap();
/*  96 */     if (sessionMap == null) {
/*  97 */       return null;
/*     */     }
/*     */     
/* 100 */     return (Session)sessionMap.get(factory);
/*     */   }
/*     */   
/*     */   protected static Map sessionMap()
/*     */   {
/* 105 */     return sessionMap(false);
/*     */   }
/*     */   
/*     */   private static synchronized Map sessionMap(boolean createMap) {
/* 109 */     Map sessionMap = (Map)context.get();
/* 110 */     if ((sessionMap == null) && (createMap)) {
/* 111 */       sessionMap = new HashMap();
/* 112 */       context.set(sessionMap);
/*     */     }
/* 114 */     return sessionMap;
/*     */   }
/*     */   
/*     */   private static synchronized void doCleanup() {
/* 118 */     Map sessionMap = sessionMap(false);
/* 119 */     if ((sessionMap != null) && 
/* 120 */       (sessionMap.isEmpty())) {
/* 121 */       context.set(null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\context\ManagedSessionContext.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */