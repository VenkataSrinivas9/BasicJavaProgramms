/*     */ package org.hibernate.context;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.transaction.Synchronization;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.ConnectionReleaseMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.hibernate.Transaction;
/*     */ import org.hibernate.cfg.Settings;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.event.EventSource;
/*     */ import org.hibernate.jdbc.JDBCContext.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThreadLocalSessionContext
/*     */   implements CurrentSessionContext
/*     */ {
/*  51 */   private static final Log log = LogFactory.getLog(ThreadLocalSessionContext.class);
/*  52 */   private static final Class[] SESS_PROXY_INTERFACES = { org.hibernate.classic.Session.class, SessionImplementor.class, JDBCContext.Context.class, EventSource.class };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  65 */   private static final ThreadLocal context = new ThreadLocal();
/*     */   protected final SessionFactoryImplementor factory;
/*     */   
/*     */   public ThreadLocalSessionContext(SessionFactoryImplementor factory)
/*     */   {
/*  70 */     this.factory = factory;
/*     */   }
/*     */   
/*     */   public final org.hibernate.classic.Session currentSession() throws HibernateException {
/*  74 */     org.hibernate.classic.Session current = existingSession(this.factory);
/*  75 */     if (current == null) {
/*  76 */       current = buildOrObtainSession();
/*     */       
/*  78 */       current.getTransaction().registerSynchronization(buildCleanupSynch());
/*     */       
/*  80 */       if (needsWrapping(current)) {
/*  81 */         current = wrap(current);
/*     */       }
/*     */       
/*  84 */       doBind(current, this.factory);
/*     */     }
/*  86 */     return current;
/*     */   }
/*     */   
/*     */   private boolean needsWrapping(org.hibernate.classic.Session session)
/*     */   {
/*  91 */     return ((session != null) && (!Proxy.isProxyClass(session.getClass()))) || ((Proxy.getInvocationHandler(session) != null) && (!(Proxy.getInvocationHandler(session) instanceof TransactionProtectionWrapper)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected SessionFactoryImplementor getFactory()
/*     */   {
/*  98 */     return this.factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected org.hibernate.classic.Session buildOrObtainSession()
/*     */   {
/* 110 */     return this.factory.openSession(null, isAutoFlushEnabled(), isAutoCloseEnabled(), getConnectionReleaseMode());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected CleanupSynch buildCleanupSynch()
/*     */   {
/* 119 */     return new CleanupSynch(this.factory);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isAutoCloseEnabled()
/*     */   {
/* 128 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isAutoFlushEnabled()
/*     */   {
/* 137 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ConnectionReleaseMode getConnectionReleaseMode()
/*     */   {
/* 146 */     return this.factory.getSettings().getConnectionReleaseMode();
/*     */   }
/*     */   
/*     */   protected org.hibernate.classic.Session wrap(org.hibernate.classic.Session session) {
/* 150 */     TransactionProtectionWrapper wrapper = new TransactionProtectionWrapper(session);
/* 151 */     org.hibernate.classic.Session wrapped = (org.hibernate.classic.Session)Proxy.newProxyInstance(org.hibernate.classic.Session.class.getClassLoader(), SESS_PROXY_INTERFACES, wrapper);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 157 */     wrapper.setWrapped(wrapped);
/* 158 */     return wrapped;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void bind(org.hibernate.Session session)
/*     */   {
/* 167 */     SessionFactory factory = session.getSessionFactory();
/* 168 */     cleanupAnyOrphanedSession(factory);
/* 169 */     doBind(session, factory);
/*     */   }
/*     */   
/*     */   private static void cleanupAnyOrphanedSession(SessionFactory factory) {
/* 173 */     org.hibernate.classic.Session orphan = doUnbind(factory, false);
/* 174 */     if (orphan != null) {
/* 175 */       log.warn("Already session bound on call to bind(); make sure you clean up your sessions!");
/*     */       try {
/* 177 */         if ((orphan.getTransaction() != null) && (orphan.getTransaction().isActive())) {
/*     */           try {
/* 179 */             orphan.getTransaction().rollback();
/*     */           }
/*     */           catch (Throwable t) {
/* 182 */             log.debug("Unable to rollback transaction for orphaned session", t);
/*     */           }
/*     */         }
/* 185 */         orphan.close();
/*     */       }
/*     */       catch (Throwable t) {
/* 188 */         log.debug("Unable to close orphaned session", t);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static org.hibernate.classic.Session unbind(SessionFactory factory)
/*     */   {
/* 199 */     return doUnbind(factory, true);
/*     */   }
/*     */   
/*     */   private static org.hibernate.classic.Session existingSession(SessionFactory factory) {
/* 203 */     Map sessionMap = sessionMap();
/* 204 */     if (sessionMap == null) {
/* 205 */       return null;
/*     */     }
/*     */     
/* 208 */     return (org.hibernate.classic.Session)sessionMap.get(factory);
/*     */   }
/*     */   
/*     */   protected static Map sessionMap()
/*     */   {
/* 213 */     return (Map)context.get();
/*     */   }
/*     */   
/*     */   private static void doBind(org.hibernate.Session session, SessionFactory factory) {
/* 217 */     Map sessionMap = sessionMap();
/* 218 */     if (sessionMap == null) {
/* 219 */       sessionMap = new HashMap();
/* 220 */       context.set(sessionMap);
/*     */     }
/* 222 */     sessionMap.put(factory, session);
/*     */   }
/*     */   
/*     */   private static org.hibernate.classic.Session doUnbind(SessionFactory factory, boolean releaseMapIfEmpty) {
/* 226 */     Map sessionMap = sessionMap();
/* 227 */     org.hibernate.classic.Session session = null;
/* 228 */     if (sessionMap != null) {
/* 229 */       session = (org.hibernate.classic.Session)sessionMap.remove(factory);
/* 230 */       if ((releaseMapIfEmpty) && (sessionMap.isEmpty())) {
/* 231 */         context.set(null);
/*     */       }
/*     */     }
/* 234 */     return session;
/*     */   }
/*     */   
/*     */   protected static class CleanupSynch
/*     */     implements Synchronization, Serializable
/*     */   {
/*     */     protected final SessionFactory factory;
/*     */     
/*     */     public CleanupSynch(SessionFactory factory)
/*     */     {
/* 244 */       this.factory = factory;
/*     */     }
/*     */     
/*     */     public void beforeCompletion() {}
/*     */     
/*     */     public void afterCompletion(int i)
/*     */     {
/* 251 */       ThreadLocalSessionContext.unbind(this.factory);
/*     */     }
/*     */   }
/*     */   
/*     */   private class TransactionProtectionWrapper implements InvocationHandler, Serializable {
/*     */     private final org.hibernate.classic.Session realSession;
/*     */     private org.hibernate.classic.Session wrappedSession;
/*     */     
/*     */     public TransactionProtectionWrapper(org.hibernate.classic.Session realSession) {
/* 260 */       this.realSession = realSession;
/*     */     }
/*     */     
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*     */     {
/*     */       try {
/* 266 */         if ("close".equals(method.getName())) {
/* 267 */           ThreadLocalSessionContext.unbind(this.realSession.getSessionFactory());
/*     */         }
/* 269 */         else if ((!"toString".equals(method.getName())) && (!"equals".equals(method.getName())) && (!"hashCode".equals(method.getName())) && (!"getStatistics".equals(method.getName())) && (!"isOpen".equals(method.getName())))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 276 */           if (this.realSession.isOpen())
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 283 */             if (!this.realSession.getTransaction().isActive())
/*     */             {
/* 285 */               if (("beginTransaction".equals(method.getName())) || ("getTransaction".equals(method.getName())) || ("isTransactionInProgress".equals(method.getName())) || ("setFlushMode".equals(method.getName())) || ("getSessionFactory".equals(method.getName())))
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/* 290 */                 ThreadLocalSessionContext.log.trace("allowing method [" + method.getName() + "] in non-transacted context");
/*     */               }
/* 292 */               else if ((!"reconnect".equals(method.getName())) && (!"disconnect".equals(method.getName())))
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/* 297 */                 throw new HibernateException(method.getName() + " is not valid without active transaction"); } }
/*     */           }
/*     */         }
/* 300 */         ThreadLocalSessionContext.log.trace("allowing proxied method [" + method.getName() + "] to proceed to real session");
/* 301 */         return method.invoke(this.realSession, args);
/*     */       }
/*     */       catch (InvocationTargetException e) {
/* 304 */         if ((e.getTargetException() instanceof RuntimeException)) {
/* 305 */           throw ((RuntimeException)e.getTargetException());
/*     */         }
/*     */         
/* 308 */         throw e;
/*     */       }
/*     */     }
/*     */     
/*     */     public void setWrapped(org.hibernate.classic.Session wrapped)
/*     */     {
/* 314 */       this.wrappedSession = wrapped;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void writeObject(ObjectOutputStream oos)
/*     */       throws IOException
/*     */     {
/* 324 */       oos.defaultWriteObject();
/* 325 */       if (ThreadLocalSessionContext.existingSession(ThreadLocalSessionContext.this.factory) == this.wrappedSession) {
/* 326 */         ThreadLocalSessionContext.unbind(ThreadLocalSessionContext.this.factory);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     private void readObject(ObjectInputStream ois)
/*     */       throws IOException, ClassNotFoundException
/*     */     {
/* 334 */       ois.defaultReadObject();
/* 335 */       this.realSession.getTransaction().registerSynchronization(ThreadLocalSessionContext.this.buildCleanupSynch());
/* 336 */       ThreadLocalSessionContext.doBind(this.wrappedSession, ThreadLocalSessionContext.this.factory);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\context\ThreadLocalSessionContext.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */