package org.hibernate.context;

import java.io.Serializable;
import org.hibernate.HibernateException;
import org.hibernate.classic.Session;

public abstract interface CurrentSessionContext
  extends Serializable
{
  public abstract Session currentSession()
    throws HibernateException;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\context\CurrentSessionContext.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */