/*    */ package org.hibernate.event;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PreInsertEvent
/*    */ {
/*    */   private Object entity;
/*    */   private EntityPersister persister;
/*    */   private Object[] state;
/*    */   private Serializable id;
/*    */   private SessionImplementor source;
/*    */   
/*    */   public PreInsertEvent(Object entity, Serializable id, Object[] state, EntityPersister persister, SessionImplementor source)
/*    */   {
/* 28 */     this.source = source;
/* 29 */     this.entity = entity;
/* 30 */     this.id = id;
/* 31 */     this.state = state;
/* 32 */     this.persister = persister;
/*    */   }
/*    */   
/*    */   public Object getEntity() {
/* 36 */     return this.entity;
/*    */   }
/*    */   
/* 39 */   public Serializable getId() { return this.id; }
/*    */   
/*    */   public EntityPersister getPersister() {
/* 42 */     return this.persister;
/*    */   }
/*    */   
/* 45 */   public Object[] getState() { return this.state; }
/*    */   
/*    */   public SessionImplementor getSource() {
/* 48 */     return this.source;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\PreInsertEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */