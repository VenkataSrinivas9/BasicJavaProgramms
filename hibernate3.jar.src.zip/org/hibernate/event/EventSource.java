package org.hibernate.event;

import java.io.Serializable;
import java.util.Map;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.engine.ActionQueue;
import org.hibernate.engine.EntityEntry;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.persister.entity.EntityPersister;

public abstract interface EventSource
  extends SessionImplementor, Session
{
  public abstract ActionQueue getActionQueue();
  
  public abstract Object instantiate(EntityPersister paramEntityPersister, Serializable paramSerializable)
    throws HibernateException;
  
  public abstract void forceFlush(EntityEntry paramEntityEntry)
    throws HibernateException;
  
  public abstract void merge(String paramString, Object paramObject, Map paramMap)
    throws HibernateException;
  
  public abstract void persist(String paramString, Object paramObject, Map paramMap)
    throws HibernateException;
  
  public abstract void persistOnFlush(String paramString, Object paramObject, Map paramMap);
  
  public abstract void refresh(Object paramObject, Map paramMap)
    throws HibernateException;
  
  public abstract void saveOrUpdateCopy(String paramString, Object paramObject, Map paramMap)
    throws HibernateException;
  
  public abstract void delete(String paramString, Object paramObject, boolean paramBoolean);
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\EventSource.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */