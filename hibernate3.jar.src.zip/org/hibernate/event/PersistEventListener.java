package org.hibernate.event;

import java.io.Serializable;
import java.util.Map;
import org.hibernate.HibernateException;

public abstract interface PersistEventListener
  extends Serializable
{
  public abstract void onPersist(PersistEvent paramPersistEvent)
    throws HibernateException;
  
  public abstract void onPersist(PersistEvent paramPersistEvent, Map paramMap)
    throws HibernateException;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\PersistEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */