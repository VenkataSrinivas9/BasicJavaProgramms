/*    */ package org.hibernate.event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlushEvent
/*    */   extends AbstractEvent
/*    */ {
/*    */   public FlushEvent(EventSource source)
/*    */   {
/* 13 */     super(source);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\FlushEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */