/*    */ package org.hibernate.event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeleteEvent
/*    */   extends AbstractEvent
/*    */ {
/*    */   private Object object;
/*    */   
/*    */ 
/*    */ 
/*    */   private String entityName;
/*    */   
/*    */ 
/*    */   private boolean cascadeDeleteEnabled;
/*    */   
/*    */ 
/*    */ 
/*    */   public DeleteEvent(Object object, EventSource source)
/*    */   {
/* 22 */     super(source);
/* 23 */     if (object == null) {
/* 24 */       throw new IllegalArgumentException("attempt to create delete event with null entity");
/*    */     }
/*    */     
/*    */ 
/* 28 */     this.object = object;
/*    */   }
/*    */   
/*    */   public DeleteEvent(String entityName, Object object, EventSource source) {
/* 32 */     this(object, source);
/* 33 */     this.entityName = entityName;
/*    */   }
/*    */   
/*    */   public DeleteEvent(String entityName, Object object, boolean isCascadeDeleteEnabled, EventSource source) {
/* 37 */     this(object, source);
/* 38 */     this.entityName = entityName;
/* 39 */     this.cascadeDeleteEnabled = isCascadeDeleteEnabled;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object getObject()
/*    */   {
/* 48 */     return this.object;
/*    */   }
/*    */   
/*    */   public String getEntityName() {
/* 52 */     return this.entityName;
/*    */   }
/*    */   
/*    */   public boolean isCascadeDeleteEnabled() {
/* 56 */     return this.cascadeDeleteEnabled;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\DeleteEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */