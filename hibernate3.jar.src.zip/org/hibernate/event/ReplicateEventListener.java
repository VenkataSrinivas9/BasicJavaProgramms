package org.hibernate.event;

import java.io.Serializable;
import org.hibernate.HibernateException;

public abstract interface ReplicateEventListener
  extends Serializable
{
  public abstract void onReplicate(ReplicateEvent paramReplicateEvent)
    throws HibernateException;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\ReplicateEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */