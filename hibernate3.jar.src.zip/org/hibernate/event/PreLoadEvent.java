/*    */ package org.hibernate.event;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PreLoadEvent
/*    */   extends AbstractEvent
/*    */ {
/*    */   private Object entity;
/*    */   private Object[] state;
/*    */   private Serializable id;
/*    */   private EntityPersister persister;
/*    */   
/*    */   public PreLoadEvent(EventSource session)
/*    */   {
/* 21 */     super(session);
/*    */   }
/*    */   
/*    */   public Object getEntity() {
/* 25 */     return this.entity;
/*    */   }
/*    */   
/*    */   public Serializable getId() {
/* 29 */     return this.id;
/*    */   }
/*    */   
/*    */   public EntityPersister getPersister() {
/* 33 */     return this.persister;
/*    */   }
/*    */   
/*    */   public Object[] getState() {
/* 37 */     return this.state;
/*    */   }
/*    */   
/*    */   public PreLoadEvent setEntity(Object entity) {
/* 41 */     this.entity = entity;
/* 42 */     return this;
/*    */   }
/*    */   
/*    */   public PreLoadEvent setId(Serializable id) {
/* 46 */     this.id = id;
/* 47 */     return this;
/*    */   }
/*    */   
/*    */   public PreLoadEvent setPersister(EntityPersister persister) {
/* 51 */     this.persister = persister;
/* 52 */     return this;
/*    */   }
/*    */   
/*    */   public PreLoadEvent setState(Object[] state) {
/* 56 */     this.state = state;
/* 57 */     return this;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\PreLoadEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */