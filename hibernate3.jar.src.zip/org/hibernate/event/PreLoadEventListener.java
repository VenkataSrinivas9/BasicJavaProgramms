package org.hibernate.event;

import java.io.Serializable;

public abstract interface PreLoadEventListener
  extends Serializable
{
  public abstract void onPreLoad(PreLoadEvent paramPreLoadEvent);
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\PreLoadEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */