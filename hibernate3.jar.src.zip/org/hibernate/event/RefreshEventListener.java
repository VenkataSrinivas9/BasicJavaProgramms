package org.hibernate.event;

import java.io.Serializable;
import java.util.Map;
import org.hibernate.HibernateException;

public abstract interface RefreshEventListener
  extends Serializable
{
  public abstract void onRefresh(RefreshEvent paramRefreshEvent)
    throws HibernateException;
  
  public abstract void onRefresh(RefreshEvent paramRefreshEvent, Map paramMap)
    throws HibernateException;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\RefreshEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */