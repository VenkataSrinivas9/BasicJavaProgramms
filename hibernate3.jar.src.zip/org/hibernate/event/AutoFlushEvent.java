/*    */ package org.hibernate.event;
/*    */ 
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AutoFlushEvent
/*    */   extends FlushEvent
/*    */ {
/*    */   private Set querySpaces;
/*    */   private boolean flushRequired;
/*    */   
/*    */   public AutoFlushEvent(Set querySpaces, EventSource source)
/*    */   {
/* 17 */     super(source);
/* 18 */     this.querySpaces = querySpaces;
/*    */   }
/*    */   
/*    */   public Set getQuerySpaces() {
/* 22 */     return this.querySpaces;
/*    */   }
/*    */   
/*    */   public void setQuerySpaces(Set querySpaces) {
/* 26 */     this.querySpaces = querySpaces;
/*    */   }
/*    */   
/*    */   public boolean isFlushRequired() {
/* 30 */     return this.flushRequired;
/*    */   }
/*    */   
/*    */   public void setFlushRequired(boolean dirty) {
/* 34 */     this.flushRequired = dirty;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\AutoFlushEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */