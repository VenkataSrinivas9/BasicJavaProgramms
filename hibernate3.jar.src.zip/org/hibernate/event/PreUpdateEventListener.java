package org.hibernate.event;

import java.io.Serializable;

public abstract interface PreUpdateEventListener
  extends Serializable
{
  public abstract boolean onPreUpdate(PreUpdateEvent paramPreUpdateEvent);
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\PreUpdateEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */