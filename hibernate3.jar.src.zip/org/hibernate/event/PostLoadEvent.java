/*    */ package org.hibernate.event;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PostLoadEvent
/*    */   extends AbstractEvent
/*    */ {
/*    */   private Object entity;
/*    */   private Serializable id;
/*    */   private EntityPersister persister;
/*    */   
/*    */   public PostLoadEvent(EventSource session)
/*    */   {
/* 19 */     super(session);
/*    */   }
/*    */   
/*    */   public Object getEntity() {
/* 23 */     return this.entity;
/*    */   }
/*    */   
/*    */   public EntityPersister getPersister() {
/* 27 */     return this.persister;
/*    */   }
/*    */   
/*    */   public Serializable getId() {
/* 31 */     return this.id;
/*    */   }
/*    */   
/*    */   public PostLoadEvent setEntity(Object entity) {
/* 35 */     this.entity = entity;
/* 36 */     return this;
/*    */   }
/*    */   
/*    */   public PostLoadEvent setId(Serializable id) {
/* 40 */     this.id = id;
/* 41 */     return this;
/*    */   }
/*    */   
/*    */   public PostLoadEvent setPersister(EntityPersister persister) {
/* 45 */     this.persister = persister;
/* 46 */     return this;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\PostLoadEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */