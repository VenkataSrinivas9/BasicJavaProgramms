/*    */ package org.hibernate.event;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DirtyCheckEvent
/*    */   extends FlushEvent
/*    */ {
/*    */   private boolean dirty;
/*    */   
/*    */ 
/*    */ 
/*    */   public DirtyCheckEvent(EventSource source)
/*    */   {
/* 14 */     super(source);
/*    */   }
/*    */   
/*    */   public boolean isDirty() {
/* 18 */     return this.dirty;
/*    */   }
/*    */   
/*    */   public void setDirty(boolean dirty) {
/* 22 */     this.dirty = dirty;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\DirtyCheckEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */