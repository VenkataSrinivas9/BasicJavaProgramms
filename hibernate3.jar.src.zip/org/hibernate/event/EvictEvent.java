/*    */ package org.hibernate.event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EvictEvent
/*    */   extends AbstractEvent
/*    */ {
/*    */   private Object object;
/*    */   
/*    */ 
/*    */ 
/*    */   public EvictEvent(Object object, EventSource source)
/*    */   {
/* 15 */     super(source);
/* 16 */     this.object = object;
/*    */   }
/*    */   
/*    */   public Object getObject() {
/* 20 */     return this.object;
/*    */   }
/*    */   
/*    */   public void setObject(Object object) {
/* 24 */     this.object = object;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\EvictEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */