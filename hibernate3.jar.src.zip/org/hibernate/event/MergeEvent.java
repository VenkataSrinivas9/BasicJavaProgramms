/*    */ package org.hibernate.event;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MergeEvent
/*    */   extends AbstractEvent
/*    */ {
/*    */   private Object original;
/*    */   private Serializable requestedId;
/*    */   private String entityName;
/*    */   private Object entity;
/*    */   private Object result;
/*    */   
/*    */   public MergeEvent(String entityName, Object original, EventSource source)
/*    */   {
/* 20 */     this(original, source);
/* 21 */     this.entityName = entityName;
/*    */   }
/*    */   
/*    */   public MergeEvent(String entityName, Object original, Serializable id, EventSource source) {
/* 25 */     this(entityName, original, source);
/* 26 */     this.requestedId = id;
/* 27 */     if (this.requestedId == null) {
/* 28 */       throw new IllegalArgumentException("attempt to create merge event with null identifier");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public MergeEvent(Object object, EventSource source)
/*    */   {
/* 35 */     super(source);
/* 36 */     if (object == null) {
/* 37 */       throw new IllegalArgumentException("attempt to create merge event with null entity");
/*    */     }
/*    */     
/*    */ 
/* 41 */     this.original = object;
/*    */   }
/*    */   
/*    */   public Object getOriginal() {
/* 45 */     return this.original;
/*    */   }
/*    */   
/*    */   public void setOriginal(Object object) {
/* 49 */     this.original = object;
/*    */   }
/*    */   
/*    */   public Serializable getRequestedId() {
/* 53 */     return this.requestedId;
/*    */   }
/*    */   
/*    */   public void setRequestedId(Serializable requestedId) {
/* 57 */     this.requestedId = requestedId;
/*    */   }
/*    */   
/*    */   public String getEntityName() {
/* 61 */     return this.entityName;
/*    */   }
/*    */   
/*    */   public void setEntityName(String entityName) {
/* 65 */     this.entityName = entityName;
/*    */   }
/*    */   
/*    */   public Object getEntity() {
/* 69 */     return this.entity;
/*    */   }
/*    */   
/* 72 */   public void setEntity(Object entity) { this.entity = entity; }
/*    */   
/*    */   public Object getResult()
/*    */   {
/* 76 */     return this.result;
/*    */   }
/*    */   
/*    */   public void setResult(Object result) {
/* 80 */     this.result = result;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\MergeEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */