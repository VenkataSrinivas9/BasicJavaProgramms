/*     */ package org.hibernate.event;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.hibernate.LockMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoadEvent
/*     */   extends AbstractEvent
/*     */ {
/*  15 */   public static final LockMode DEFAULT_LOCK_MODE = LockMode.NONE;
/*     */   private Serializable entityId;
/*     */   private String entityClassName;
/*     */   private Object instanceToLoad;
/*     */   private LockMode lockMode;
/*     */   private boolean isAssociationFetch;
/*     */   private Object result;
/*     */   
/*     */   public LoadEvent(Serializable entityId, Object instanceToLoad, EventSource source)
/*     */   {
/*  25 */     this(entityId, null, instanceToLoad, null, false, source);
/*     */   }
/*     */   
/*     */   public LoadEvent(Serializable entityId, String entityClassName, LockMode lockMode, EventSource source) {
/*  29 */     this(entityId, entityClassName, null, lockMode, false, source);
/*     */   }
/*     */   
/*     */   public LoadEvent(Serializable entityId, String entityClassName, boolean isAssociationFetch, EventSource source) {
/*  33 */     this(entityId, entityClassName, null, null, isAssociationFetch, source);
/*     */   }
/*     */   
/*     */   public boolean isAssociationFetch() {
/*  37 */     return this.isAssociationFetch;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private LoadEvent(Serializable entityId, String entityClassName, Object instanceToLoad, LockMode lockMode, boolean isAssociationFetch, EventSource source)
/*     */   {
/*  48 */     super(source);
/*     */     
/*  50 */     if (entityId == null) {
/*  51 */       throw new IllegalArgumentException("id to load is required for loading");
/*     */     }
/*     */     
/*  54 */     if (lockMode == LockMode.WRITE) {
/*  55 */       throw new IllegalArgumentException("Invalid lock mode for loading");
/*     */     }
/*  57 */     if (lockMode == null) {
/*  58 */       lockMode = DEFAULT_LOCK_MODE;
/*     */     }
/*     */     
/*  61 */     this.entityId = entityId;
/*  62 */     this.entityClassName = entityClassName;
/*  63 */     this.instanceToLoad = instanceToLoad;
/*  64 */     this.lockMode = lockMode;
/*  65 */     this.isAssociationFetch = isAssociationFetch;
/*     */   }
/*     */   
/*     */   public Serializable getEntityId() {
/*  69 */     return this.entityId;
/*     */   }
/*     */   
/*     */   public void setEntityId(Serializable entityId) {
/*  73 */     this.entityId = entityId;
/*     */   }
/*     */   
/*     */   public String getEntityClassName() {
/*  77 */     return this.entityClassName;
/*     */   }
/*     */   
/*     */   public void setEntityClassName(String entityClassName) {
/*  81 */     this.entityClassName = entityClassName;
/*     */   }
/*     */   
/*     */   public Object getInstanceToLoad() {
/*  85 */     return this.instanceToLoad;
/*     */   }
/*     */   
/*     */   public void setInstanceToLoad(Object instanceToLoad) {
/*  89 */     this.instanceToLoad = instanceToLoad;
/*     */   }
/*     */   
/*     */   public LockMode getLockMode() {
/*  93 */     return this.lockMode;
/*     */   }
/*     */   
/*     */   public void setLockMode(LockMode lockMode) {
/*  97 */     this.lockMode = lockMode;
/*     */   }
/*     */   
/*     */   public Object getResult() {
/* 101 */     return this.result;
/*     */   }
/*     */   
/*     */   public void setResult(Object result) {
/* 105 */     this.result = result;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\LoadEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */