/*    */ package org.hibernate.event;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PostInsertEvent
/*    */ {
/*    */   private Object entity;
/*    */   private EntityPersister persister;
/*    */   private Object[] state;
/*    */   private Serializable id;
/*    */   
/*    */   public PostInsertEvent(Object entity, Serializable id, Object[] state, EntityPersister persister)
/*    */   {
/* 49 */     this.entity = entity;
/*    */     
/* 51 */     this.id = id;
/*    */     
/* 53 */     this.state = state;
/*    */     
/* 55 */     this.persister = persister;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object getEntity()
/*    */   {
/* 63 */     return this.entity;
/*    */   }
/*    */   
/*    */ 
/*    */   public Serializable getId()
/*    */   {
/* 69 */     return this.id;
/*    */   }
/*    */   
/*    */ 
/*    */   public EntityPersister getPersister()
/*    */   {
/* 75 */     return this.persister;
/*    */   }
/*    */   
/*    */ 
/*    */   public Object[] getState()
/*    */   {
/* 81 */     return this.state;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\PostInsertEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */