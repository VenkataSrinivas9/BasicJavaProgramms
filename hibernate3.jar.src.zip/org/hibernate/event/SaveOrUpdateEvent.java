/*    */ package org.hibernate.event;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.engine.EntityEntry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SaveOrUpdateEvent
/*    */   extends AbstractEvent
/*    */ {
/*    */   private Object object;
/*    */   private Serializable requestedId;
/*    */   private String entityName;
/*    */   private Object entity;
/*    */   private EntityEntry entry;
/*    */   private Serializable resultId;
/*    */   
/*    */   public SaveOrUpdateEvent(String entityName, Object original, EventSource source)
/*    */   {
/* 23 */     this(original, source);
/* 24 */     this.entityName = entityName;
/*    */   }
/*    */   
/*    */   public SaveOrUpdateEvent(String entityName, Object original, Serializable id, EventSource source) {
/* 28 */     this(entityName, original, source);
/* 29 */     this.requestedId = id;
/* 30 */     if (this.requestedId == null) {
/* 31 */       throw new IllegalArgumentException("attempt to create saveOrUpdate event with null identifier");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public SaveOrUpdateEvent(Object object, EventSource source)
/*    */   {
/* 38 */     super(source);
/* 39 */     if (object == null) {
/* 40 */       throw new IllegalArgumentException("attempt to create saveOrUpdate event with null entity");
/*    */     }
/*    */     
/*    */ 
/* 44 */     this.object = object;
/*    */   }
/*    */   
/*    */   public Object getObject() {
/* 48 */     return this.object;
/*    */   }
/*    */   
/*    */   public void setObject(Object object) {
/* 52 */     this.object = object;
/*    */   }
/*    */   
/*    */   public Serializable getRequestedId() {
/* 56 */     return this.requestedId;
/*    */   }
/*    */   
/*    */   public void setRequestedId(Serializable requestedId) {
/* 60 */     this.requestedId = requestedId;
/*    */   }
/*    */   
/*    */   public String getEntityName() {
/* 64 */     return this.entityName;
/*    */   }
/*    */   
/*    */   public void setEntityName(String entityName) {
/* 68 */     this.entityName = entityName;
/*    */   }
/*    */   
/*    */   public Object getEntity() {
/* 72 */     return this.entity;
/*    */   }
/*    */   
/*    */   public void setEntity(Object entity) {
/* 76 */     this.entity = entity;
/*    */   }
/*    */   
/*    */   public EntityEntry getEntry() {
/* 80 */     return this.entry;
/*    */   }
/*    */   
/*    */   public void setEntry(EntityEntry entry) {
/* 84 */     this.entry = entry;
/*    */   }
/*    */   
/*    */   public Serializable getResultId() {
/* 88 */     return this.resultId;
/*    */   }
/*    */   
/*    */   public void setResultId(Serializable resultId) {
/* 92 */     this.resultId = resultId;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\SaveOrUpdateEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */