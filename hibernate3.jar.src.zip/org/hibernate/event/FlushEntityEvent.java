/*    */ package org.hibernate.event;
/*    */ 
/*    */ import org.hibernate.engine.EntityEntry;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlushEntityEvent
/*    */   extends AbstractEvent
/*    */ {
/*    */   private Object entity;
/*    */   private Object[] propertyValues;
/*    */   private Object[] databaseSnapshot;
/*    */   private int[] dirtyProperties;
/*    */   private boolean hasDirtyCollection;
/*    */   private boolean dirtyCheckPossible;
/*    */   private boolean dirtyCheckHandledByInterceptor;
/*    */   private EntityEntry entityEntry;
/*    */   
/*    */   public FlushEntityEvent(EventSource source, Object entity, EntityEntry entry)
/*    */   {
/* 21 */     super(source);
/* 22 */     this.entity = entity;
/* 23 */     this.entityEntry = entry;
/*    */   }
/*    */   
/*    */   public EntityEntry getEntityEntry() {
/* 27 */     return this.entityEntry;
/*    */   }
/*    */   
/* 30 */   public Object[] getDatabaseSnapshot() { return this.databaseSnapshot; }
/*    */   
/*    */   public void setDatabaseSnapshot(Object[] databaseSnapshot) {
/* 33 */     this.databaseSnapshot = databaseSnapshot;
/*    */   }
/*    */   
/* 36 */   public boolean hasDatabaseSnapshot() { return this.databaseSnapshot != null; }
/*    */   
/*    */   public boolean isDirtyCheckHandledByInterceptor() {
/* 39 */     return this.dirtyCheckHandledByInterceptor;
/*    */   }
/*    */   
/* 42 */   public void setDirtyCheckHandledByInterceptor(boolean dirtyCheckHandledByInterceptor) { this.dirtyCheckHandledByInterceptor = dirtyCheckHandledByInterceptor; }
/*    */   
/*    */   public boolean isDirtyCheckPossible() {
/* 45 */     return this.dirtyCheckPossible;
/*    */   }
/*    */   
/* 48 */   public void setDirtyCheckPossible(boolean dirtyCheckPossible) { this.dirtyCheckPossible = dirtyCheckPossible; }
/*    */   
/*    */   public int[] getDirtyProperties() {
/* 51 */     return this.dirtyProperties;
/*    */   }
/*    */   
/* 54 */   public void setDirtyProperties(int[] dirtyProperties) { this.dirtyProperties = dirtyProperties; }
/*    */   
/*    */   public boolean hasDirtyCollection() {
/* 57 */     return this.hasDirtyCollection;
/*    */   }
/*    */   
/* 60 */   public void setHasDirtyCollection(boolean hasDirtyCollection) { this.hasDirtyCollection = hasDirtyCollection; }
/*    */   
/*    */   public Object[] getPropertyValues() {
/* 63 */     return this.propertyValues;
/*    */   }
/*    */   
/* 66 */   public void setPropertyValues(Object[] propertyValues) { this.propertyValues = propertyValues; }
/*    */   
/*    */   public Object getEntity() {
/* 69 */     return this.entity;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\FlushEntityEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */