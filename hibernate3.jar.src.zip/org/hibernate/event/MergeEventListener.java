package org.hibernate.event;

import java.io.Serializable;
import java.util.Map;
import org.hibernate.HibernateException;

public abstract interface MergeEventListener
  extends Serializable
{
  public abstract void onMerge(MergeEvent paramMergeEvent)
    throws HibernateException;
  
  public abstract void onMerge(MergeEvent paramMergeEvent, Map paramMap)
    throws HibernateException;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\MergeEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */