/*    */ package org.hibernate.event;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PersistEvent
/*    */   extends AbstractEvent
/*    */ {
/*    */   private Object object;
/*    */   
/*    */ 
/*    */   private String entityName;
/*    */   
/*    */ 
/*    */ 
/*    */   public PersistEvent(String entityName, Object original, EventSource source)
/*    */   {
/* 17 */     this(original, source);
/* 18 */     this.entityName = entityName;
/*    */   }
/*    */   
/*    */   public PersistEvent(Object object, EventSource source) {
/* 22 */     super(source);
/* 23 */     if (object == null) {
/* 24 */       throw new IllegalArgumentException("attempt to create create event with null entity");
/*    */     }
/*    */     
/*    */ 
/* 28 */     this.object = object;
/*    */   }
/*    */   
/*    */   public Object getObject() {
/* 32 */     return this.object;
/*    */   }
/*    */   
/*    */   public void setObject(Object object) {
/* 36 */     this.object = object;
/*    */   }
/*    */   
/*    */   public String getEntityName() {
/* 40 */     return this.entityName;
/*    */   }
/*    */   
/*    */   public void setEntityName(String entityName) {
/* 44 */     this.entityName = entityName;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\PersistEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */