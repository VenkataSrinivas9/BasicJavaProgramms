/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.EntityMode;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.ObjectDeletedException;
/*    */ import org.hibernate.engine.EntityEntry;
/*    */ import org.hibernate.engine.PersistenceContext;
/*    */ import org.hibernate.engine.Status;
/*    */ import org.hibernate.event.EventSource;
/*    */ import org.hibernate.event.SaveOrUpdateEvent;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultUpdateEventListener
/*    */   extends DefaultSaveOrUpdateEventListener
/*    */ {
/*    */   protected Serializable performSaveOrUpdate(SaveOrUpdateEvent event)
/*    */   {
/* 23 */     EntityEntry entry = event.getSession().getPersistenceContext().getEntry(event.getEntity());
/* 24 */     if (entry != null) {
/* 25 */       if (entry.getStatus() == Status.DELETED) {
/* 26 */         throw new ObjectDeletedException("deleted instance passed to update()", null, event.getEntityName());
/*    */       }
/*    */       
/* 29 */       return entityIsPersistent(event);
/*    */     }
/*    */     
/*    */ 
/* 33 */     entityIsDetached(event);
/* 34 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Serializable getUpdateId(Object entity, EntityPersister persister, Serializable requestedId, EntityMode entityMode)
/*    */     throws HibernateException
/*    */   {
/* 45 */     if (requestedId == null) {
/* 46 */       return super.getUpdateId(entity, persister, requestedId, entityMode);
/*    */     }
/*    */     
/* 49 */     persister.setIdentifier(entity, requestedId, entityMode);
/* 50 */     return requestedId;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DefaultUpdateEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */