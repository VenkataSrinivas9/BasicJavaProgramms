/*     */ package org.hibernate.event.def;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.ObjectDeletedException;
/*     */ import org.hibernate.PersistentObjectException;
/*     */ import org.hibernate.engine.CascadingAction;
/*     */ import org.hibernate.engine.PersistenceContext;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.event.EventSource;
/*     */ import org.hibernate.event.PersistEvent;
/*     */ import org.hibernate.event.PersistEventListener;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.proxy.HibernateProxy;
/*     */ import org.hibernate.proxy.LazyInitializer;
/*     */ import org.hibernate.util.IdentityMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultPersistEventListener
/*     */   extends AbstractSaveEventListener
/*     */   implements PersistEventListener
/*     */ {
/*  29 */   private static final Log log = LogFactory.getLog(DefaultPersistEventListener.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onPersist(PersistEvent event)
/*     */     throws HibernateException
/*     */   {
/*  38 */     onPersist(event, IdentityMap.instantiate(10));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onPersist(PersistEvent event, Map createCache)
/*     */     throws HibernateException
/*     */   {
/*  50 */     SessionImplementor source = event.getSession();
/*  51 */     Object object = event.getObject();
/*     */     Object entity;
/*     */     Object entity;
/*  54 */     if ((object instanceof HibernateProxy)) {
/*  55 */       LazyInitializer li = ((HibernateProxy)object).getHibernateLazyInitializer();
/*  56 */       if (li.isUninitialized()) {
/*  57 */         if (li.getSession() == source) {
/*  58 */           return;
/*     */         }
/*     */         
/*  61 */         throw new PersistentObjectException("uninitialized proxy passed to persist()");
/*     */       }
/*     */       
/*  64 */       entity = li.getImplementation();
/*     */     }
/*     */     else {
/*  67 */       entity = object;
/*     */     }
/*     */     
/*  70 */     int entityState = getEntityState(entity, event.getEntityName(), source.getPersistenceContext().getEntry(entity), source);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  77 */     switch (entityState) {
/*     */     case 2: 
/*  79 */       throw new PersistentObjectException("detached entity passed to persist: " + getLoggableName(event.getEntityName(), entity));
/*     */     
/*     */ 
/*     */ 
/*     */     case 0: 
/*  84 */       entityIsPersistent(event, createCache);
/*  85 */       break;
/*     */     case 1: 
/*  87 */       entityIsTransient(event, createCache);
/*  88 */       break;
/*     */     default: 
/*  90 */       throw new ObjectDeletedException("deleted entity passed to persist", null, getLoggableName(event.getEntityName(), entity));
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void entityIsPersistent(PersistEvent event, Map createCache)
/*     */   {
/* 100 */     log.trace("ignoring persistent instance");
/* 101 */     EventSource source = event.getSession();
/*     */     
/*     */ 
/*     */ 
/* 105 */     Object entity = source.getPersistenceContext().unproxy(event.getObject());
/* 106 */     EntityPersister persister = source.getEntityPersister(event.getEntityName(), entity);
/*     */     
/* 108 */     if (createCache.put(entity, entity) == null)
/*     */     {
/* 110 */       cascadeBeforeSave(source, persister, entity, createCache);
/* 111 */       cascadeAfterSave(source, persister, entity, createCache);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void entityIsTransient(PersistEvent event, Map createCache)
/*     */     throws HibernateException
/*     */   {
/* 124 */     log.trace("saving transient instance");
/*     */     
/* 126 */     EventSource source = event.getSession();
/*     */     
/* 128 */     Object entity = source.getPersistenceContext().unproxy(event.getObject());
/*     */     
/* 130 */     if (createCache.put(entity, entity) == null) {
/* 131 */       saveWithGeneratedId(entity, event.getEntityName(), createCache, source);
/*     */     }
/*     */   }
/*     */   
/*     */   protected CascadingAction getCascadeAction()
/*     */   {
/* 137 */     return CascadingAction.PERSIST;
/*     */   }
/*     */   
/*     */   protected Boolean getAssumedUnsaved() {
/* 141 */     return Boolean.TRUE;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DefaultPersistEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */