/*     */ package org.hibernate.event.def;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.LockMode;
/*     */ import org.hibernate.PersistentObjectException;
/*     */ import org.hibernate.TransientObjectException;
/*     */ import org.hibernate.classic.Lifecycle;
/*     */ import org.hibernate.engine.Cascade;
/*     */ import org.hibernate.engine.CascadingAction;
/*     */ import org.hibernate.engine.EntityEntry;
/*     */ import org.hibernate.engine.EntityKey;
/*     */ import org.hibernate.engine.PersistenceContext;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.engine.Status;
/*     */ import org.hibernate.event.EventSource;
/*     */ import org.hibernate.event.SaveOrUpdateEvent;
/*     */ import org.hibernate.event.SaveOrUpdateEventListener;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.pretty.MessageHelper;
/*     */ import org.hibernate.proxy.HibernateProxy;
/*     */ import org.hibernate.proxy.LazyInitializer;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultSaveOrUpdateEventListener
/*     */   extends AbstractSaveEventListener
/*     */   implements SaveOrUpdateEventListener
/*     */ {
/*  37 */   private static final Log log = LogFactory.getLog(DefaultSaveOrUpdateEventListener.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onSaveOrUpdate(SaveOrUpdateEvent event)
/*     */     throws HibernateException
/*     */   {
/*  47 */     SessionImplementor source = event.getSession();
/*  48 */     Object object = event.getObject();
/*     */     
/*  50 */     Serializable requestedId = event.getRequestedId();
/*  51 */     if (requestedId != null)
/*     */     {
/*     */ 
/*  54 */       if ((object instanceof HibernateProxy)) {
/*  55 */         ((HibernateProxy)object).getHibernateLazyInitializer().setIdentifier(requestedId);
/*     */       }
/*     */     }
/*     */     
/*  59 */     if (reassociateIfUninitializedProxy(object, source)) {
/*  60 */       log.trace("reassociated uninitialized proxy");
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*  66 */       Object entity = source.getPersistenceContext().unproxyAndReassociate(object);
/*  67 */       event.setEntity(entity);
/*  68 */       event.setEntry(source.getPersistenceContext().getEntry(entity));
/*     */       
/*  70 */       event.setResultId(performSaveOrUpdate(event));
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean reassociateIfUninitializedProxy(Object object, SessionImplementor source)
/*     */   {
/*  76 */     return source.getPersistenceContext().reassociateIfUninitializedProxy(object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Serializable performSaveOrUpdate(SaveOrUpdateEvent event)
/*     */   {
/*  84 */     int entityState = getEntityState(event.getEntity(), event.getEntityName(), event.getEntry(), event.getSession());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  91 */     switch (entityState) {
/*     */     case 2: 
/*  93 */       entityIsDetached(event);
/*  94 */       return null;
/*     */     case 0: 
/*  96 */       return entityIsPersistent(event);
/*     */     }
/*  98 */     return entityIsTransient(event);
/*     */   }
/*     */   
/*     */ 
/*     */   protected Serializable entityIsPersistent(SaveOrUpdateEvent event)
/*     */     throws HibernateException
/*     */   {
/* 105 */     log.trace("ignoring persistent instance");
/*     */     
/* 107 */     EntityEntry entityEntry = event.getEntry();
/* 108 */     if (entityEntry == null) {
/* 109 */       throw new AssertionFailure("entity was transient or detached");
/*     */     }
/*     */     
/*     */ 
/* 113 */     if (entityEntry.getStatus() == Status.DELETED) {
/* 114 */       throw new AssertionFailure("entity was deleted");
/*     */     }
/*     */     
/* 117 */     SessionFactoryImplementor factory = event.getSession().getFactory();
/*     */     
/* 119 */     Serializable requestedId = event.getRequestedId();
/*     */     Serializable savedId;
/*     */     Serializable savedId;
/* 122 */     if (requestedId == null) {
/* 123 */       savedId = entityEntry.getId();
/*     */     }
/*     */     else
/*     */     {
/* 127 */       boolean isEqual = !entityEntry.getPersister().getIdentifierType().isEqual(requestedId, entityEntry.getId(), event.getSession().getEntityMode(), factory);
/*     */       
/*     */ 
/* 130 */       if (isEqual) {
/* 131 */         throw new PersistentObjectException("object passed to save() was already persistent: " + MessageHelper.infoString(entityEntry.getPersister(), requestedId, factory));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 137 */       savedId = requestedId;
/*     */     }
/*     */     
/*     */ 
/* 141 */     if (log.isTraceEnabled()) {
/* 142 */       log.trace("object already associated with session: " + MessageHelper.infoString(entityEntry.getPersister(), savedId, factory));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 148 */     return savedId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Serializable entityIsTransient(SaveOrUpdateEvent event)
/*     */     throws HibernateException
/*     */   {
/* 161 */     log.trace("saving transient instance");
/*     */     
/* 163 */     EventSource source = event.getSession();
/*     */     
/* 165 */     EntityEntry entityEntry = event.getEntry();
/* 166 */     if (entityEntry != null) {
/* 167 */       if (entityEntry.getStatus() == Status.DELETED) {
/* 168 */         source.forceFlush(entityEntry);
/*     */       }
/*     */       else {
/* 171 */         throw new AssertionFailure("entity was persistent");
/*     */       }
/*     */     }
/*     */     
/* 175 */     Serializable id = saveWithGeneratedOrRequestedId(event);
/*     */     
/* 177 */     source.getPersistenceContext().reassociateProxy(event.getObject(), id);
/*     */     
/* 179 */     return id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Serializable saveWithGeneratedOrRequestedId(SaveOrUpdateEvent event)
/*     */   {
/* 186 */     return saveWithGeneratedId(event.getEntity(), event.getEntityName(), null, event.getSession());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void entityIsDetached(SaveOrUpdateEvent event)
/*     */     throws HibernateException
/*     */   {
/* 202 */     log.trace("updating detached instance");
/*     */     
/*     */ 
/* 205 */     if (event.getSession().getPersistenceContext().isEntryFor(event.getEntity()))
/*     */     {
/* 207 */       throw new AssertionFailure("entity was persistent");
/*     */     }
/*     */     
/* 210 */     Object entity = event.getEntity();
/*     */     
/* 212 */     EntityPersister persister = event.getSession().getEntityPersister(event.getEntityName(), entity);
/*     */     
/* 214 */     event.setRequestedId(getUpdateId(entity, persister, event.getRequestedId(), event.getSession().getEntityMode()));
/*     */     
/* 216 */     performUpdate(event, entity, persister);
/*     */   }
/*     */   
/*     */ 
/*     */   protected Serializable getUpdateId(Object entity, EntityPersister persister, Serializable requestedId, EntityMode entityMode)
/*     */     throws HibernateException
/*     */   {
/* 223 */     Serializable id = persister.getIdentifier(entity, entityMode);
/* 224 */     if (id == null)
/*     */     {
/*     */ 
/* 227 */       throw new TransientObjectException("The given object has a null identifier: " + persister.getEntityName());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 233 */     return id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void performUpdate(SaveOrUpdateEvent event, Object entity, EntityPersister persister)
/*     */     throws HibernateException
/*     */   {
/* 241 */     if (!persister.isMutable()) {
/* 242 */       log.trace("immutable instance passed to doUpdate(), locking");
/* 243 */       reassociate(event, entity, event.getRequestedId(), persister);
/*     */     }
/*     */     else
/*     */     {
/* 247 */       if (log.isTraceEnabled()) {
/* 248 */         log.trace("updating " + MessageHelper.infoString(persister, event.getRequestedId(), event.getSession().getFactory()));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 254 */       EventSource source = event.getSession();
/*     */       
/* 256 */       EntityKey key = new EntityKey(event.getRequestedId(), persister, source.getEntityMode());
/*     */       
/* 258 */       source.getPersistenceContext().checkUniqueness(key, entity);
/*     */       
/* 260 */       if (invokeUpdateLifecycle(entity, persister, source)) {
/* 261 */         reassociate(event, event.getObject(), event.getRequestedId(), persister);
/* 262 */         return;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 267 */       new OnUpdateVisitor(source, event.getRequestedId()).process(entity, persister);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 281 */       source.getPersistenceContext().addEntity(entity, Status.MANAGED, null, key, persister.getVersion(entity, source.getEntityMode()), LockMode.NONE, true, persister, false, true);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 294 */       persister.afterReassociate(entity, source);
/*     */       
/* 296 */       if (log.isTraceEnabled()) {
/* 297 */         log.trace("updating " + MessageHelper.infoString(persister, event.getRequestedId(), source.getFactory()));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 303 */       cascadeOnUpdate(event, persister, entity);
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean invokeUpdateLifecycle(Object entity, EntityPersister persister, EventSource source)
/*     */   {
/* 309 */     if (persister.implementsLifecycle(source.getEntityMode())) {
/* 310 */       log.debug("calling onUpdate()");
/* 311 */       if (((Lifecycle)entity).onUpdate(source)) {
/* 312 */         log.debug("update vetoed by onUpdate()");
/* 313 */         return true;
/*     */       }
/*     */     }
/* 316 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void cascadeOnUpdate(SaveOrUpdateEvent event, EntityPersister persister, Object entity)
/*     */   {
/* 328 */     EventSource source = event.getSession();
/* 329 */     source.getPersistenceContext().incrementCascadeLevel();
/*     */     try {
/* 331 */       new Cascade(CascadingAction.SAVE_UPDATE, 0, source).cascade(persister, entity);
/*     */     }
/*     */     finally
/*     */     {
/* 335 */       source.getPersistenceContext().decrementCascadeLevel();
/*     */     }
/*     */   }
/*     */   
/*     */   protected CascadingAction getCascadeAction() {
/* 340 */     return CascadingAction.SAVE_UPDATE;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DefaultSaveOrUpdateEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */