/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import org.hibernate.Interceptor;
/*    */ import org.hibernate.event.EventSource;
/*    */ import org.hibernate.event.PreLoadEvent;
/*    */ import org.hibernate.event.PreLoadEventListener;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultPreLoadEventListener
/*    */   implements PreLoadEventListener
/*    */ {
/*    */   public void onPreLoad(PreLoadEvent event)
/*    */   {
/* 17 */     EntityPersister persister = event.getPersister();
/* 18 */     event.getSession().getInterceptor().onLoad(event.getEntity(), event.getId(), event.getState(), persister.getPropertyNames(), persister.getPropertyTypes());
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DefaultPreLoadEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */