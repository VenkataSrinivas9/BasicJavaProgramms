/*     */ package org.hibernate.event.def;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.CacheMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.cache.CacheConcurrencyStrategy;
/*     */ import org.hibernate.cache.CacheKey;
/*     */ import org.hibernate.cache.entry.CacheEntryStructure;
/*     */ import org.hibernate.cache.entry.CollectionCacheEntry;
/*     */ import org.hibernate.collection.PersistentCollection;
/*     */ import org.hibernate.engine.CollectionEntry;
/*     */ import org.hibernate.engine.PersistenceContext;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.event.InitializeCollectionEvent;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.pretty.MessageHelper;
/*     */ import org.hibernate.stat.Statistics;
/*     */ import org.hibernate.stat.StatisticsImplementor;
/*     */ 
/*     */ public class DefaultInitializeCollectionEventListener implements org.hibernate.event.InitializeCollectionEventListener
/*     */ {
/*  26 */   private static final Log log = LogFactory.getLog(DefaultInitializeCollectionEventListener.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onInitializeCollection(InitializeCollectionEvent event)
/*     */     throws HibernateException
/*     */   {
/*  34 */     PersistentCollection collection = event.getCollection();
/*  35 */     SessionImplementor source = event.getSession();
/*     */     
/*  37 */     CollectionEntry ce = source.getPersistenceContext().getCollectionEntry(collection);
/*  38 */     if (ce == null) throw new HibernateException("collection was evicted");
/*  39 */     if (!collection.wasInitialized()) {
/*  40 */       if (log.isTraceEnabled()) {
/*  41 */         log.trace("initializing collection " + MessageHelper.collectionInfoString(ce.getLoadedPersister(), ce.getLoadedKey(), source.getFactory()));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  47 */       log.trace("checking second-level cache");
/*  48 */       boolean foundInCache = initializeCollectionFromCache(ce.getLoadedKey(), ce.getLoadedPersister(), collection, source);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  55 */       if (foundInCache) {
/*  56 */         log.trace("collection initialized from cache");
/*     */       }
/*     */       else {
/*  59 */         log.trace("collection not cached");
/*  60 */         ce.getLoadedPersister().initialize(ce.getLoadedKey(), source);
/*  61 */         log.trace("collection initialized");
/*     */         
/*  63 */         if (source.getFactory().getStatistics().isStatisticsEnabled()) {
/*  64 */           source.getFactory().getStatisticsImplementor().fetchCollection(ce.getLoadedPersister().getRole());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean initializeCollectionFromCache(Serializable id, CollectionPersister persister, PersistentCollection collection, SessionImplementor source)
/*     */     throws HibernateException
/*     */   {
/*  82 */     if ((!source.getEnabledFilters().isEmpty()) && (persister.isAffectedByEnabledFilters(source))) {
/*  83 */       log.trace("disregarding cached version (if any) of collection due to enabled filters ");
/*  84 */       return false;
/*     */     }
/*     */     
/*  87 */     boolean useCache = (persister.hasCache()) && (source.getCacheMode().isGetEnabled());
/*     */     
/*     */ 
/*  90 */     if (!useCache) {
/*  91 */       return false;
/*     */     }
/*     */     
/*     */ 
/*  95 */     SessionFactoryImplementor factory = source.getFactory();
/*     */     
/*  97 */     CacheKey ck = new CacheKey(id, persister.getKeyType(), persister.getRole(), source.getEntityMode(), source.getFactory());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 104 */     Object ce = persister.getCache().get(ck, source.getTimestamp());
/*     */     
/* 106 */     if (factory.getStatistics().isStatisticsEnabled()) {
/* 107 */       if (ce == null) {
/* 108 */         factory.getStatisticsImplementor().secondLevelCacheMiss(persister.getCache().getRegionName());
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 113 */         factory.getStatisticsImplementor().secondLevelCacheHit(persister.getCache().getRegionName());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 121 */     if (ce == null) {
/* 122 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 126 */     CollectionCacheEntry cacheEntry = (CollectionCacheEntry)persister.getCacheEntryStructure().destructure(ce, factory);
/*     */     
/*     */ 
/* 129 */     PersistenceContext persistenceContext = source.getPersistenceContext();
/* 130 */     cacheEntry.assemble(collection, persister, persistenceContext.getCollectionOwner(id, persister));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 135 */     persistenceContext.getCollectionEntry(collection).postInitialize(collection);
/*     */     
/* 137 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DefaultInitializeCollectionEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */