/*     */ package org.hibernate.event.def;
/*     */ 
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.event.EventSource;
/*     */ import org.hibernate.intercept.LazyPropertyInitializer;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.type.AbstractComponentType;
/*     */ import org.hibernate.type.CollectionType;
/*     */ import org.hibernate.type.EntityType;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractVisitor
/*     */ {
/*     */   private final EventSource session;
/*     */   
/*     */   AbstractVisitor(EventSource session)
/*     */   {
/*  27 */     this.session = session;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void processValues(Object[] values, Type[] types)
/*     */     throws HibernateException
/*     */   {
/*  38 */     for (int i = 0; i < types.length; i++) {
/*  39 */       if (includeProperty(values, i)) {
/*  40 */         processValue(i, values, types);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void processEntityPropertyValues(Object[] values, Type[] types)
/*     */     throws HibernateException
/*     */   {
/*  53 */     for (int i = 0; i < types.length; i++) {
/*  54 */       if (includeEntityProperty(values, i)) {
/*  55 */         processValue(i, values, types);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void processValue(int i, Object[] values, Type[] types) {
/*  61 */     processValue(values[i], types[i]);
/*     */   }
/*     */   
/*     */   boolean includeEntityProperty(Object[] values, int i) {
/*  65 */     return includeProperty(values, i);
/*     */   }
/*     */   
/*     */   boolean includeProperty(Object[] values, int i) {
/*  69 */     return values[i] != LazyPropertyInitializer.UNFETCHED_PROPERTY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Object processComponent(Object component, AbstractComponentType componentType)
/*     */     throws HibernateException
/*     */   {
/*  81 */     if (component != null) {
/*  82 */       processValues(componentType.getPropertyValues(component, this.session), componentType.getSubtypes());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  87 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final Object processValue(Object value, Type type)
/*     */     throws HibernateException
/*     */   {
/*  99 */     if (type.isCollectionType())
/*     */     {
/* 101 */       return processCollection(value, (CollectionType)type);
/*     */     }
/* 103 */     if (type.isEntityType()) {
/* 104 */       return processEntity(value, (EntityType)type);
/*     */     }
/* 106 */     if (type.isComponentType()) {
/* 107 */       return processComponent(value, (AbstractComponentType)type);
/*     */     }
/*     */     
/* 110 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void process(Object object, EntityPersister persister)
/*     */     throws HibernateException
/*     */   {
/* 123 */     processEntityPropertyValues(persister.getPropertyValues(object, getSession().getEntityMode()), persister.getPropertyTypes());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Object processCollection(Object collection, CollectionType type)
/*     */     throws HibernateException
/*     */   {
/* 138 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Object processEntity(Object value, EntityType entityType)
/*     */     throws HibernateException
/*     */   {
/* 151 */     return null;
/*     */   }
/*     */   
/*     */   final EventSource getSession() {
/* 155 */     return this.session;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\AbstractVisitor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */