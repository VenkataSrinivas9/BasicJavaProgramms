/*     */ package org.hibernate.event.def;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.LockMode;
/*     */ import org.hibernate.ReplicationMode;
/*     */ import org.hibernate.TransientObjectException;
/*     */ import org.hibernate.engine.Cascade;
/*     */ import org.hibernate.engine.CascadingAction;
/*     */ import org.hibernate.engine.EntityKey;
/*     */ import org.hibernate.engine.PersistenceContext;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.engine.Status;
/*     */ import org.hibernate.event.EventSource;
/*     */ import org.hibernate.event.ReplicateEvent;
/*     */ import org.hibernate.event.ReplicateEventListener;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.pretty.MessageHelper;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultReplicateEventListener
/*     */   extends AbstractSaveEventListener
/*     */   implements ReplicateEventListener
/*     */ {
/*  33 */   private static final Log log = LogFactory.getLog(DefaultReplicateEventListener.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onReplicate(ReplicateEvent event)
/*     */     throws HibernateException
/*     */   {
/*  43 */     EventSource source = event.getSession();
/*     */     
/*  45 */     if (source.getPersistenceContext().reassociateIfUninitializedProxy(event.getObject())) {
/*  46 */       log.trace("uninitialized proxy passed to replicate()");
/*  47 */       return;
/*     */     }
/*     */     
/*  50 */     Object entity = source.getPersistenceContext().unproxyAndReassociate(event.getObject());
/*     */     
/*  52 */     if (source.getPersistenceContext().isEntryFor(entity)) {
/*  53 */       log.trace("ignoring persistent instance passed to replicate()");
/*     */       
/*  55 */       return;
/*     */     }
/*     */     
/*  58 */     EntityPersister persister = source.getEntityPersister(event.getEntityName(), entity);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  64 */     Serializable id = persister.getIdentifier(entity, source.getEntityMode());
/*  65 */     if (id == null) {
/*  66 */       throw new TransientObjectException("instance with null id passed to replicate()");
/*     */     }
/*     */     
/*  69 */     ReplicationMode replicationMode = event.getReplicationMode();
/*     */     Object oldVersion;
/*     */     Object oldVersion;
/*  72 */     if (replicationMode == ReplicationMode.EXCEPTION)
/*     */     {
/*  74 */       oldVersion = null;
/*     */     }
/*     */     else
/*     */     {
/*  78 */       oldVersion = persister.getCurrentVersion(id, source);
/*     */     }
/*     */     
/*  81 */     if (oldVersion != null)
/*     */     {
/*  83 */       if (log.isTraceEnabled()) {
/*  84 */         log.trace("found existing row for " + MessageHelper.infoString(persister, id, source.getFactory()));
/*     */       }
/*     */       
/*     */ 
/*  88 */       boolean canReplicate = replicationMode.shouldOverwriteCurrentVersion(entity, oldVersion, persister.getVersion(entity, source.getEntityMode()), persister.getVersionType());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  95 */       if (canReplicate)
/*     */       {
/*  97 */         performReplication(entity, id, oldVersion, persister, replicationMode, source);
/*     */       }
/*     */       else
/*     */       {
/* 101 */         log.trace("no need to replicate");
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 108 */       if (log.isTraceEnabled()) {
/* 109 */         log.trace("no existing row, replicating new instance " + MessageHelper.infoString(persister, id, source.getFactory()));
/*     */       }
/*     */       
/*     */ 
/* 113 */       boolean regenerate = persister.isIdentifierAssignedByInsert();
/* 114 */       EntityKey key = regenerate ? null : new EntityKey(id, persister, source.getEntityMode());
/*     */       
/*     */ 
/* 117 */       performSaveOrReplicate(entity, key, persister, regenerate, replicationMode, source);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean visitCollectionsBeforeSave(Serializable id, Object[] values, Type[] types, EventSource source)
/*     */   {
/* 131 */     OnReplicateVisitor visitor = new OnReplicateVisitor(source, id, false);
/* 132 */     visitor.processEntityPropertyValues(values, types);
/* 133 */     return super.visitCollectionsBeforeSave(id, values, types, source);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean substituteValuesIfNecessary(Object entity, Serializable id, Object[] values, EntityPersister persister, SessionImplementor source)
/*     */   {
/* 143 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean isVersionIncrementDisabled() {
/* 147 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final void performReplication(Object entity, Serializable id, Object version, EntityPersister persister, ReplicationMode replicationMode, EventSource source)
/*     */     throws HibernateException
/*     */   {
/* 159 */     if (log.isTraceEnabled()) {
/* 160 */       log.trace("replicating changes to " + MessageHelper.infoString(persister, id, source.getFactory()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 166 */     new OnReplicateVisitor(source, id, true).process(entity, persister);
/*     */     
/* 168 */     source.getPersistenceContext().addEntity(entity, Status.MANAGED, null, new EntityKey(id, persister, source.getEntityMode()), version, LockMode.NONE, true, persister, true, false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 181 */     cascadeAfterReplicate(entity, persister, replicationMode, source);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void cascadeAfterReplicate(Object entity, EntityPersister persister, ReplicationMode replicationMode, EventSource source)
/*     */   {
/* 190 */     source.getPersistenceContext().incrementCascadeLevel();
/*     */     try {
/* 192 */       new Cascade(CascadingAction.REPLICATE, 0, source).cascade(persister, entity, replicationMode);
/*     */     }
/*     */     finally
/*     */     {
/* 196 */       source.getPersistenceContext().decrementCascadeLevel();
/*     */     }
/*     */   }
/*     */   
/*     */   protected CascadingAction getCascadeAction() {
/* 201 */     return CascadingAction.REPLICATE;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DefaultReplicateEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */