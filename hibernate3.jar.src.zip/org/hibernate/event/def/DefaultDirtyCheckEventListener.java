/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.engine.ActionQueue;
/*    */ import org.hibernate.event.DirtyCheckEvent;
/*    */ import org.hibernate.event.DirtyCheckEventListener;
/*    */ import org.hibernate.event.EventSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultDirtyCheckEventListener
/*    */   extends AbstractFlushingEventListener
/*    */   implements DirtyCheckEventListener
/*    */ {
/* 19 */   private static final Log log = LogFactory.getLog(DefaultDirtyCheckEventListener.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void onDirtyCheck(DirtyCheckEvent event)
/*    */     throws HibernateException
/*    */   {
/* 28 */     int oldSize = event.getSession().getActionQueue().numberOfCollectionRemovals();
/*    */     try
/*    */     {
/* 31 */       flushEverythingToExecutions(event);
/* 32 */       boolean wasNeeded = event.getSession().getActionQueue().hasAnyQueuedActions();
/* 33 */       log.debug(wasNeeded ? "session dirty" : "session not dirty");
/* 34 */       event.setDirty(wasNeeded);
/*    */     }
/*    */     finally {
/* 37 */       event.getSession().getActionQueue().clearFromFlushNeededCheck(oldSize);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DefaultDirtyCheckEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */