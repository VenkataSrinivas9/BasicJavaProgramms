/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.LockMode;
/*    */ import org.hibernate.engine.EntityEntry;
/*    */ import org.hibernate.engine.EntityKey;
/*    */ import org.hibernate.engine.PersistenceContext;
/*    */ import org.hibernate.engine.Status;
/*    */ import org.hibernate.engine.Versioning;
/*    */ import org.hibernate.event.AbstractEvent;
/*    */ import org.hibernate.event.EventSource;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ import org.hibernate.pretty.MessageHelper;
/*    */ import org.hibernate.type.TypeFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AbstractReassociateEventListener
/*    */   implements Serializable
/*    */ {
/* 28 */   private static final Log log = LogFactory.getLog(AbstractReassociateEventListener.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected final EntityEntry reassociate(AbstractEvent event, Object object, Serializable id, EntityPersister persister)
/*    */     throws HibernateException
/*    */   {
/* 44 */     if (log.isTraceEnabled()) { log.trace("reassociating transient instance: " + MessageHelper.infoString(persister, id, event.getSession().getFactory()));
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 49 */     EventSource source = event.getSession();
/* 50 */     EntityKey key = new EntityKey(id, persister, source.getEntityMode());
/*    */     
/* 52 */     source.getPersistenceContext().checkUniqueness(key, object);
/*    */     
/*    */ 
/* 55 */     Object[] values = persister.getPropertyValues(object, source.getEntityMode());
/* 56 */     TypeFactory.deepCopy(values, persister.getPropertyTypes(), persister.getPropertyUpdateability(), values, source);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 63 */     Object version = Versioning.getVersion(values, persister);
/*    */     
/* 65 */     EntityEntry newEntry = source.getPersistenceContext().addEntity(object, Status.MANAGED, values, key, version, LockMode.NONE, true, persister, false, true);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 78 */     new OnLockVisitor(source, id).process(object, persister);
/*    */     
/* 80 */     persister.afterReassociate(object, source);
/*    */     
/* 82 */     return newEntry;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\AbstractReassociateEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */