/*     */ package org.hibernate.event.def;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Interceptor;
/*     */ import org.hibernate.StaleObjectStateException;
/*     */ import org.hibernate.action.EntityUpdateAction;
/*     */ import org.hibernate.classic.Validatable;
/*     */ import org.hibernate.engine.ActionQueue;
/*     */ import org.hibernate.engine.EntityEntry;
/*     */ import org.hibernate.engine.EntityKey;
/*     */ import org.hibernate.engine.Nullability;
/*     */ import org.hibernate.engine.PersistenceContext;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.engine.Status;
/*     */ import org.hibernate.engine.Versioning;
/*     */ import org.hibernate.event.EventSource;
/*     */ import org.hibernate.event.FlushEntityEvent;
/*     */ import org.hibernate.event.FlushEntityEventListener;
/*     */ import org.hibernate.intercept.FieldInterceptor;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.pretty.MessageHelper;
/*     */ import org.hibernate.stat.Statistics;
/*     */ import org.hibernate.stat.StatisticsImplementor;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.ArrayHelper;
/*     */ 
/*     */ public class DefaultFlushEntityEventListener
/*     */   implements FlushEntityEventListener
/*     */ {
/*  36 */   private static final Log log = LogFactory.getLog(DefaultFlushEntityEventListener.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void checkId(Object object, EntityPersister persister, Serializable id, EntityMode entityMode)
/*     */     throws HibernateException
/*     */   {
/*  44 */     if (persister.hasIdentifierPropertyOrEmbeddedCompositeIdentifier())
/*     */     {
/*  46 */       Serializable oid = persister.getIdentifier(object, entityMode);
/*  47 */       if (id == null) {
/*  48 */         throw new AssertionFailure("null id in " + persister.getEntityName() + " entry (don't flush the Session after an exception occurs)");
/*     */       }
/*  50 */       if (!persister.getIdentifierType().isEqual(id, oid, entityMode)) {
/*  51 */         throw new HibernateException("identifier of an instance of " + persister.getEntityName() + " was altered from " + id + " to " + oid);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkNaturalId(EntityPersister persister, Serializable identifier, Object[] current, Object[] loaded, EntityMode entityMode, SessionImplementor session)
/*     */   {
/*  69 */     if (persister.hasNaturalIdentifier()) {
/*  70 */       if (loaded == null) {
/*  71 */         loaded = session.getPersistenceContext().getNaturalIdSnapshot(identifier, persister);
/*     */       }
/*  73 */       Type[] types = persister.getPropertyTypes();
/*  74 */       int[] props = persister.getNaturalIdentifierProperties();
/*  75 */       boolean[] updateable = persister.getPropertyUpdateability();
/*  76 */       for (int i = 0; i < props.length; i++) {
/*  77 */         int prop = props[i];
/*  78 */         if ((updateable[prop] == 0) && 
/*  79 */           (!types[prop].isEqual(current[prop], loaded[prop], entityMode))) {
/*  80 */           throw new HibernateException("immutable natural identifier of an instance of " + persister.getEntityName() + " was altered");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onFlushEntity(FlushEntityEvent event)
/*     */     throws HibernateException
/*     */   {
/*  96 */     Object entity = event.getEntity();
/*  97 */     EntityEntry entry = event.getEntityEntry();
/*  98 */     EventSource session = event.getSession();
/*  99 */     EntityPersister persister = entry.getPersister();
/* 100 */     Status status = entry.getStatus();
/* 101 */     EntityMode entityMode = session.getEntityMode();
/* 102 */     Type[] types = persister.getPropertyTypes();
/*     */     
/* 104 */     boolean mightBeDirty = entry.requiresDirtyCheck(entity);
/*     */     
/* 106 */     Object[] values = getValues(entity, entry, entityMode, mightBeDirty, session);
/*     */     
/* 108 */     event.setPropertyValues(values);
/*     */     
/*     */ 
/* 111 */     boolean substitute = wrapCollections(session, persister, types, values);
/*     */     
/* 113 */     if (isUpdateNecessary(event, mightBeDirty)) {
/* 114 */       substitute = (scheduleUpdate(event)) || (substitute);
/*     */     }
/*     */     
/* 117 */     if (status != Status.DELETED)
/*     */     {
/* 119 */       if (substitute) { persister.setPropertyValues(entity, values, entityMode);
/*     */       }
/*     */       
/*     */ 
/* 123 */       if (persister.hasCollections()) {
/* 124 */         new FlushVisitor(session, entity).processEntityPropertyValues(values, types);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object[] getValues(Object entity, EntityEntry entry, EntityMode entityMode, boolean mightBeDirty, SessionImplementor session)
/*     */   {
/* 137 */     Object[] loadedState = entry.getLoadedState();
/* 138 */     Status status = entry.getStatus();
/* 139 */     EntityPersister persister = entry.getPersister();
/*     */     Object[] values;
/*     */     Object[] values;
/* 142 */     if (status == Status.DELETED)
/*     */     {
/* 144 */       values = entry.getDeletedState();
/*     */     } else { Object[] values;
/* 146 */       if ((!mightBeDirty) && (loadedState != null)) {
/* 147 */         values = loadedState;
/*     */       }
/*     */       else {
/* 150 */         checkId(entity, persister, entry.getId(), entityMode);
/*     */         
/*     */ 
/* 153 */         values = persister.getPropertyValues(entity, entityMode);
/*     */         
/* 155 */         checkNaturalId(persister, entry.getId(), values, loadedState, entityMode, session);
/*     */       } }
/* 157 */     return values;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean wrapCollections(EventSource session, EntityPersister persister, Type[] types, Object[] values)
/*     */   {
/* 166 */     if (persister.hasCollections())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 176 */       WrapVisitor visitor = new WrapVisitor(session);
/*     */       
/* 178 */       visitor.processEntityPropertyValues(values, types);
/* 179 */       return visitor.isSubstitutionRequired();
/*     */     }
/*     */     
/* 182 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isUpdateNecessary(FlushEntityEvent event, boolean mightBeDirty)
/*     */   {
/* 187 */     Status status = event.getEntityEntry().getStatus();
/* 188 */     if ((mightBeDirty) || (status == Status.DELETED))
/*     */     {
/* 190 */       dirtyCheck(event);
/* 191 */       if (isUpdateNecessary(event)) {
/* 192 */         return true;
/*     */       }
/*     */       
/* 195 */       FieldInterceptor.clearDirty(event.getEntity());
/* 196 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 200 */     return hasDirtyCollections(event, event.getEntityEntry().getPersister(), status);
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean scheduleUpdate(FlushEntityEvent event)
/*     */   {
/* 206 */     EntityEntry entry = event.getEntityEntry();
/* 207 */     EventSource session = event.getSession();
/* 208 */     Object entity = event.getEntity();
/* 209 */     Status status = entry.getStatus();
/* 210 */     EntityMode entityMode = session.getEntityMode();
/* 211 */     EntityPersister persister = entry.getPersister();
/* 212 */     Object[] values = event.getPropertyValues();
/*     */     
/* 214 */     if (log.isTraceEnabled()) {
/* 215 */       if (status == Status.DELETED) {
/* 216 */         log.trace("Updating deleted entity: " + MessageHelper.infoString(persister, entry.getId(), session.getFactory()));
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 222 */         log.trace("Updating entity: " + MessageHelper.infoString(persister, entry.getId(), session.getFactory()));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     boolean substitute;
/*     */     
/*     */     boolean substitute;
/*     */     
/* 231 */     if (!entry.isBeingReplicated())
/*     */     {
/*     */ 
/* 234 */       substitute = handleInterception(event);
/*     */     }
/*     */     else {
/* 237 */       substitute = false;
/*     */     }
/*     */     
/* 240 */     validate(entity, persister, status, entityMode);
/*     */     
/*     */ 
/* 243 */     Object nextVersion = getNextVersion(event);
/*     */     
/*     */ 
/* 246 */     int[] dirtyProperties = event.getDirtyProperties();
/* 247 */     if ((event.isDirtyCheckPossible()) && (dirtyProperties == null)) {
/* 248 */       if (!event.hasDirtyCollection()) {
/* 249 */         throw new AssertionFailure("dirty, but no dirty properties");
/*     */       }
/* 251 */       dirtyProperties = ArrayHelper.EMPTY_INT_ARRAY;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 256 */     new Nullability(session).checkNullability(values, persister, true);
/*     */     
/*     */ 
/*     */ 
/* 260 */     session.getActionQueue().addAction(new EntityUpdateAction(entry.getId(), values, dirtyProperties, event.hasDirtyCollection(), entry.getLoadedState(), entry.getVersion(), nextVersion, entity, entry.getRowId(), persister, session));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 276 */     return substitute;
/*     */   }
/*     */   
/*     */   protected void validate(Object entity, EntityPersister persister, Status status, EntityMode entityMode)
/*     */   {
/* 281 */     if ((status == Status.MANAGED) && (persister.implementsValidatable(entityMode))) {
/* 282 */       ((Validatable)entity).validate();
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean handleInterception(FlushEntityEvent event) {
/* 287 */     SessionImplementor session = event.getSession();
/* 288 */     EntityEntry entry = event.getEntityEntry();
/* 289 */     EntityPersister persister = entry.getPersister();
/* 290 */     Object entity = event.getEntity();
/*     */     
/*     */ 
/* 293 */     Object[] values = event.getPropertyValues();
/* 294 */     boolean intercepted = invokeInterceptor(session, entity, entry, values, persister);
/*     */     
/*     */ 
/* 297 */     if ((intercepted) && (event.isDirtyCheckPossible()) && (!event.isDirtyCheckHandledByInterceptor())) { int[] dirtyProperties;
/*     */       int[] dirtyProperties;
/* 299 */       if (event.hasDatabaseSnapshot()) {
/* 300 */         dirtyProperties = persister.findModified(event.getDatabaseSnapshot(), values, entity, session);
/*     */       }
/*     */       else {
/* 303 */         dirtyProperties = persister.findDirty(values, entry.getLoadedState(), entity, session);
/*     */       }
/* 305 */       event.setDirtyProperties(dirtyProperties);
/*     */     }
/*     */     
/* 308 */     return intercepted;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean invokeInterceptor(SessionImplementor session, Object entity, EntityEntry entry, Object[] values, EntityPersister persister)
/*     */   {
/* 318 */     boolean intercepted = session.getInterceptor().onFlushDirty(entity, entry.getId(), values, entry.getLoadedState(), persister.getPropertyNames(), persister.getPropertyTypes());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 326 */     return intercepted;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Object getNextVersion(FlushEntityEvent event)
/*     */     throws HibernateException
/*     */   {
/* 334 */     EntityEntry entry = event.getEntityEntry();
/* 335 */     EntityPersister persister = entry.getPersister();
/* 336 */     if (persister.isVersioned())
/*     */     {
/* 338 */       Object[] values = event.getPropertyValues();
/*     */       
/* 340 */       if (entry.isBeingReplicated()) {
/* 341 */         return Versioning.getVersion(values, persister);
/*     */       }
/*     */       
/* 344 */       int[] dirtyProperties = event.getDirtyProperties();
/*     */       
/* 346 */       boolean isVersionIncrementRequired = isVersionIncrementRequired(event, entry, persister, dirtyProperties);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 353 */       Object nextVersion = isVersionIncrementRequired ? Versioning.increment(entry.getVersion(), persister.getVersionType(), event.getSession()) : entry.getVersion();
/*     */       
/*     */ 
/*     */ 
/* 357 */       Versioning.setVersion(values, nextVersion, persister);
/*     */       
/* 359 */       return nextVersion;
/*     */     }
/*     */     
/*     */ 
/* 363 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isVersionIncrementRequired(FlushEntityEvent event, EntityEntry entry, EntityPersister persister, int[] dirtyProperties)
/*     */   {
/* 374 */     boolean isVersionIncrementRequired = (entry.getStatus() != Status.DELETED) && ((dirtyProperties == null) || (Versioning.isVersionIncrementRequired(dirtyProperties, event.hasDirtyCollection(), persister.getPropertyVersionability())));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 382 */     return isVersionIncrementRequired;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final boolean isUpdateNecessary(FlushEntityEvent event)
/*     */     throws HibernateException
/*     */   {
/* 392 */     EntityPersister persister = event.getEntityEntry().getPersister();
/* 393 */     Status status = event.getEntityEntry().getStatus();
/*     */     
/* 395 */     if (!event.isDirtyCheckPossible()) {
/* 396 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 400 */     int[] dirtyProperties = event.getDirtyProperties();
/* 401 */     if ((dirtyProperties != null) && (dirtyProperties.length != 0)) {
/* 402 */       return true;
/*     */     }
/*     */     
/* 405 */     return hasDirtyCollections(event, persister, status);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean hasDirtyCollections(FlushEntityEvent event, EntityPersister persister, Status status)
/*     */   {
/* 412 */     if (isCollectionDirtyCheckNecessary(persister, status)) {
/* 413 */       DirtyCollectionSearchVisitor visitor = new DirtyCollectionSearchVisitor(event.getSession(), persister.getPropertyVersionability());
/*     */       
/*     */ 
/*     */ 
/* 417 */       visitor.processEntityPropertyValues(event.getPropertyValues(), persister.getPropertyTypes());
/* 418 */       boolean hasDirtyCollections = visitor.wasDirtyCollectionFound();
/* 419 */       event.setHasDirtyCollection(hasDirtyCollections);
/* 420 */       return hasDirtyCollections;
/*     */     }
/*     */     
/* 423 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isCollectionDirtyCheckNecessary(EntityPersister persister, Status status)
/*     */   {
/* 428 */     return (status == Status.MANAGED) && (persister.isVersioned()) && (persister.hasCollections());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void dirtyCheck(FlushEntityEvent event)
/*     */     throws HibernateException
/*     */   {
/* 438 */     Object entity = event.getEntity();
/* 439 */     Object[] values = event.getPropertyValues();
/* 440 */     SessionImplementor session = event.getSession();
/* 441 */     EntityEntry entry = event.getEntityEntry();
/* 442 */     EntityPersister persister = entry.getPersister();
/* 443 */     Serializable id = entry.getId();
/* 444 */     Object[] loadedState = entry.getLoadedState();
/*     */     
/* 446 */     int[] dirtyProperties = session.getInterceptor().findDirty(entity, id, values, loadedState, persister.getPropertyNames(), persister.getPropertyTypes());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 455 */     event.setDatabaseSnapshot(null);
/*     */     
/*     */     boolean cannotDirtyCheck;
/*     */     
/*     */     boolean interceptorHandledDirtyCheck;
/* 460 */     if (dirtyProperties == null)
/*     */     {
/* 462 */       boolean interceptorHandledDirtyCheck = false;
/*     */       
/* 464 */       boolean cannotDirtyCheck = loadedState == null;
/* 465 */       if (!cannotDirtyCheck)
/*     */       {
/* 467 */         dirtyProperties = persister.findDirty(values, loadedState, entity, session);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 472 */         Object[] databaseSnapshot = getDatabaseSnapshot(session, persister, id);
/* 473 */         if (databaseSnapshot != null) {
/* 474 */           dirtyProperties = persister.findModified(databaseSnapshot, values, entity, session);
/* 475 */           cannotDirtyCheck = false;
/* 476 */           event.setDatabaseSnapshot(databaseSnapshot);
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 482 */       cannotDirtyCheck = false;
/* 483 */       interceptorHandledDirtyCheck = true;
/*     */     }
/*     */     
/* 486 */     event.setDirtyProperties(dirtyProperties);
/* 487 */     event.setDirtyCheckHandledByInterceptor(interceptorHandledDirtyCheck);
/* 488 */     event.setDirtyCheckPossible(!cannotDirtyCheck);
/*     */   }
/*     */   
/*     */   private Object[] getDatabaseSnapshot(SessionImplementor session, EntityPersister persister, Serializable id)
/*     */   {
/* 493 */     if (persister.isSelectBeforeUpdateRequired()) {
/* 494 */       Object[] snapshot = session.getPersistenceContext().getDatabaseSnapshot(id, persister);
/*     */       
/* 496 */       if (snapshot == null)
/*     */       {
/* 498 */         if (session.getFactory().getStatistics().isStatisticsEnabled()) {
/* 499 */           session.getFactory().getStatisticsImplementor().optimisticFailure(persister.getEntityName());
/*     */         }
/*     */         
/* 502 */         throw new StaleObjectStateException(persister.getEntityName(), id);
/*     */       }
/*     */       
/* 505 */       return snapshot;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 510 */     EntityKey entityKey = new EntityKey(id, persister, session.getEntityMode());
/* 511 */     return session.getPersistenceContext().getCachedDatabaseSnapshot(entityKey);
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DefaultFlushEntityEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */