/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.collection.PersistentCollection;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.event.EventSource;
/*    */ import org.hibernate.persister.collection.CollectionPersister;
/*    */ import org.hibernate.type.CollectionType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OnUpdateVisitor
/*    */   extends ReattachVisitor
/*    */ {
/*    */   OnUpdateVisitor(EventSource session, Serializable key)
/*    */   {
/* 25 */     super(session, key);
/*    */   }
/*    */   
/*    */   Object processCollection(Object collection, CollectionType type)
/*    */     throws HibernateException
/*    */   {
/* 31 */     if (collection == CollectionType.UNFETCHED_COLLECTION) { return null;
/*    */     }
/* 33 */     EventSource session = getSession();
/* 34 */     Serializable key = getKey();
/* 35 */     CollectionPersister persister = session.getFactory().getCollectionPersister(type.getRole());
/*    */     
/* 37 */     if ((collection != null) && ((collection instanceof PersistentCollection))) {
/* 38 */       PersistentCollection wrapper = (PersistentCollection)collection;
/*    */       
/* 40 */       if (wrapper.setCurrentSession(session))
/*    */       {
/*    */ 
/* 43 */         if (!isOwnerUnchanged(wrapper, persister, key))
/*    */         {
/*    */ 
/* 46 */           removeCollection(persister, key, session);
/*    */         }
/*    */         
/* 49 */         reattachCollection(wrapper, type);
/*    */ 
/*    */       }
/*    */       else
/*    */       {
/*    */ 
/* 55 */         removeCollection(persister, key, session);
/*    */       }
/*    */       
/*    */ 
/*    */     }
/*    */     else
/*    */     {
/*    */ 
/* 63 */       removeCollection(persister, key, session);
/*    */     }
/*    */     
/*    */ 
/* 67 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\OnUpdateVisitor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */