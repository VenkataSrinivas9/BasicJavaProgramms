/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.FlushMode;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.engine.ActionQueue;
/*    */ import org.hibernate.engine.PersistenceContext;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.event.AutoFlushEvent;
/*    */ import org.hibernate.event.AutoFlushEventListener;
/*    */ import org.hibernate.event.EventSource;
/*    */ import org.hibernate.stat.Statistics;
/*    */ import org.hibernate.stat.StatisticsImplementor;
/*    */ 
/*    */ public class DefaultAutoFlushEventListener
/*    */   extends AbstractFlushingEventListener
/*    */   implements AutoFlushEventListener
/*    */ {
/* 20 */   private static final Log log = LogFactory.getLog(DefaultAutoFlushEventListener.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void onAutoFlush(AutoFlushEvent event)
/*    */     throws HibernateException
/*    */   {
/* 29 */     EventSource source = event.getSession();
/*    */     
/* 31 */     if (flushMightBeNeeded(source))
/*    */     {
/* 33 */       int oldSize = source.getActionQueue().numberOfCollectionRemovals();
/*    */       
/* 35 */       flushEverythingToExecutions(event);
/*    */       
/* 37 */       if (flushIsReallyNeeded(event, source))
/*    */       {
/* 39 */         log.trace("Need to execute flush");
/*    */         
/* 41 */         performExecutions(source);
/* 42 */         postFlush(source);
/*    */         
/*    */ 
/*    */ 
/* 46 */         if (source.getFactory().getStatistics().isStatisticsEnabled()) {
/* 47 */           source.getFactory().getStatisticsImplementor().flush();
/*    */         }
/*    */         
/*    */       }
/*    */       else
/*    */       {
/* 53 */         log.trace("Dont need to execute flush");
/* 54 */         source.getActionQueue().clearFromFlushNeededCheck(oldSize);
/*    */       }
/*    */       
/* 57 */       event.setFlushRequired(flushIsReallyNeeded(event, source));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   private boolean flushIsReallyNeeded(AutoFlushEvent event, EventSource source)
/*    */   {
/* 64 */     return (source.getActionQueue().areTablesToBeUpdated(event.getQuerySpaces())) || (source.getFlushMode() == FlushMode.ALWAYS);
/*    */   }
/*    */   
/*    */ 
/*    */   private boolean flushMightBeNeeded(EventSource source)
/*    */   {
/* 70 */     return (!source.getFlushMode().lessThan(FlushMode.AUTO)) && (source.getDontFlushFromFind() == 0) && (source.getPersistenceContext().hasNonReadOnlyEntities());
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DefaultAutoFlushEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */