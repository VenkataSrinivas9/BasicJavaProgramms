/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.Hibernate;
/*    */ import org.hibernate.PersistentObjectException;
/*    */ import org.hibernate.engine.EntityEntry;
/*    */ import org.hibernate.engine.PersistenceContext;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.engine.Status;
/*    */ import org.hibernate.event.EventSource;
/*    */ import org.hibernate.event.SaveOrUpdateEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultSaveEventListener
/*    */   extends DefaultSaveOrUpdateEventListener
/*    */ {
/*    */   protected Serializable performSaveOrUpdate(SaveOrUpdateEvent event)
/*    */   {
/* 22 */     EntityEntry entry = event.getSession().getPersistenceContext().getEntry(event.getEntity());
/* 23 */     if ((entry != null) && (entry.getStatus() != Status.DELETED)) {
/* 24 */       return entityIsPersistent(event);
/*    */     }
/*    */     
/* 27 */     return entityIsTransient(event);
/*    */   }
/*    */   
/*    */   protected Serializable saveWithGeneratedOrRequestedId(SaveOrUpdateEvent event)
/*    */   {
/* 32 */     if (event.getRequestedId() == null) {
/* 33 */       return super.saveWithGeneratedOrRequestedId(event);
/*    */     }
/*    */     
/* 36 */     return saveWithRequestedId(event.getEntity(), event.getRequestedId(), event.getEntityName(), null, event.getSession());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected boolean reassociateIfUninitializedProxy(Object object, SessionImplementor source)
/*    */   {
/* 48 */     if (!Hibernate.isInitialized(object)) {
/* 49 */       throw new PersistentObjectException("uninitialized proxy passed to save()");
/*    */     }
/*    */     
/* 52 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DefaultSaveEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */