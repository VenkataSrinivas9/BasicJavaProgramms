/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import org.hibernate.classic.Lifecycle;
/*    */ import org.hibernate.event.EventSource;
/*    */ import org.hibernate.event.PostLoadEvent;
/*    */ import org.hibernate.event.PostLoadEventListener;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultPostLoadEventListener
/*    */   implements PostLoadEventListener
/*    */ {
/*    */   public void onPostLoad(PostLoadEvent event)
/*    */   {
/* 16 */     if (event.getPersister().implementsLifecycle(event.getSession().getEntityMode()))
/*    */     {
/* 18 */       ((Lifecycle)event.getEntity()).onLoad(event.getSession(), event.getId());
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DefaultPostLoadEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */