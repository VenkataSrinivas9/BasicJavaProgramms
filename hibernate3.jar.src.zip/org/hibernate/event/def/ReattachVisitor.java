/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.action.CollectionRemoveAction;
/*    */ import org.hibernate.engine.ActionQueue;
/*    */ import org.hibernate.event.EventSource;
/*    */ import org.hibernate.persister.collection.CollectionPersister;
/*    */ import org.hibernate.pretty.MessageHelper;
/*    */ import org.hibernate.type.AbstractComponentType;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ReattachVisitor
/*    */   extends ProxyVisitor
/*    */ {
/* 22 */   private static final Log log = LogFactory.getLog(ReattachVisitor.class);
/*    */   private final Serializable key;
/*    */   
/*    */   final Serializable getKey()
/*    */   {
/* 27 */     return this.key;
/*    */   }
/*    */   
/*    */   public ReattachVisitor(EventSource session, Serializable key) {
/* 31 */     super(session);
/* 32 */     this.key = key;
/*    */   }
/*    */   
/*    */   Object processComponent(Object component, AbstractComponentType componentType)
/*    */     throws HibernateException
/*    */   {
/* 38 */     Type[] types = componentType.getSubtypes();
/* 39 */     if (component == null) {
/* 40 */       processValues(new Object[types.length], types);
/*    */     }
/*    */     else {
/* 43 */       super.processComponent(component, componentType);
/*    */     }
/*    */     
/*    */ 
/* 47 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void removeCollection(CollectionPersister role, Serializable id, EventSource source)
/*    */     throws HibernateException
/*    */   {
/* 59 */     if (log.isTraceEnabled()) {
/* 60 */       log.trace("collection dereferenced while transient " + MessageHelper.collectionInfoString(role, id, source.getFactory()));
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 70 */     source.getActionQueue().addAction(new CollectionRemoveAction(null, role, id, false, source));
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\ReattachVisitor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */