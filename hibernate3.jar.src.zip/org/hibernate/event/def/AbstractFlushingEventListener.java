/*     */ package org.hibernate.event.def;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Interceptor;
/*     */ import org.hibernate.action.CollectionRecreateAction;
/*     */ import org.hibernate.action.CollectionRemoveAction;
/*     */ import org.hibernate.action.CollectionUpdateAction;
/*     */ import org.hibernate.collection.PersistentCollection;
/*     */ import org.hibernate.engine.ActionQueue;
/*     */ import org.hibernate.engine.BatchFetchQueue;
/*     */ import org.hibernate.engine.Cascade;
/*     */ import org.hibernate.engine.CascadingAction;
/*     */ import org.hibernate.engine.CollectionEntry;
/*     */ import org.hibernate.engine.CollectionKey;
/*     */ import org.hibernate.engine.Collections;
/*     */ import org.hibernate.engine.EntityEntry;
/*     */ import org.hibernate.engine.PersistenceContext;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.engine.Status;
/*     */ import org.hibernate.event.EventListeners;
/*     */ import org.hibernate.event.EventSource;
/*     */ import org.hibernate.event.FlushEntityEvent;
/*     */ import org.hibernate.event.FlushEntityEventListener;
/*     */ import org.hibernate.event.FlushEvent;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.pretty.Printer;
/*     */ import org.hibernate.util.IdentityMap;
/*     */ import org.hibernate.util.LazyIterator;
/*     */ 
/*     */ public abstract class AbstractFlushingEventListener
/*     */   implements Serializable
/*     */ {
/*  42 */   private static final Log log = LogFactory.getLog(AbstractFlushingEventListener.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void flushEverythingToExecutions(FlushEvent event)
/*     */     throws HibernateException
/*     */   {
/*  58 */     log.trace("flushing session");
/*     */     
/*  60 */     EventSource session = event.getSession();
/*     */     
/*  62 */     PersistenceContext persistenceContext = session.getPersistenceContext();
/*  63 */     session.getInterceptor().preFlush(new LazyIterator(persistenceContext.getEntitiesByKey()));
/*     */     
/*  65 */     prepareEntityFlushes(session);
/*     */     
/*     */ 
/*     */ 
/*  69 */     prepareCollectionFlushes(session);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  74 */     persistenceContext.setFlushing(true);
/*     */     try {
/*  76 */       flushEntities(event);
/*  77 */       flushCollections(session);
/*     */     }
/*     */     finally {
/*  80 */       persistenceContext.setFlushing(false);
/*     */     }
/*     */     
/*     */ 
/*  84 */     if (log.isDebugEnabled()) {
/*  85 */       log.debug("Flushed: " + session.getActionQueue().numberOfInsertions() + " insertions, " + session.getActionQueue().numberOfUpdates() + " updates, " + session.getActionQueue().numberOfDeletions() + " deletions to " + persistenceContext.getEntityEntries().size() + " objects");
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  91 */       log.debug("Flushed: " + session.getActionQueue().numberOfCollectionCreations() + " (re)creations, " + session.getActionQueue().numberOfCollectionUpdates() + " updates, " + session.getActionQueue().numberOfCollectionRemovals() + " removals to " + persistenceContext.getCollectionEntries().size() + " collections");
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  97 */       new Printer(session.getFactory()).toString(persistenceContext.getEntitiesByKey().values().iterator(), session.getEntityMode());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void prepareEntityFlushes(EventSource session)
/*     */     throws HibernateException
/*     */   {
/* 111 */     log.debug("processing flush-time cascades");
/*     */     
/* 113 */     Map.Entry[] list = IdentityMap.concurrentEntries(session.getPersistenceContext().getEntityEntries());
/*     */     
/* 115 */     int size = list.length;
/* 116 */     for (int i = 0; i < size; i++) {
/* 117 */       Map.Entry me = list[i];
/* 118 */       EntityEntry entry = (EntityEntry)me.getValue();
/* 119 */       Status status = entry.getStatus();
/* 120 */       if ((status == Status.MANAGED) || (status == Status.SAVING)) {
/* 121 */         cascadeOnFlush(session, entry.getPersister(), me.getKey());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void cascadeOnFlush(EventSource session, EntityPersister persister, Object object) throws HibernateException
/*     */   {
/* 128 */     session.getPersistenceContext().incrementCascadeLevel();
/*     */     try {
/* 130 */       new Cascade(getCascadingAction(), 0, session).cascade(persister, object, getAnything());
/*     */     }
/*     */     finally
/*     */     {
/* 134 */       session.getPersistenceContext().decrementCascadeLevel();
/*     */     }
/*     */   }
/*     */   
/* 138 */   protected Object getAnything() { return null; }
/*     */   
/*     */   protected CascadingAction getCascadingAction() {
/* 141 */     return CascadingAction.SAVE_UPDATE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void prepareCollectionFlushes(SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/* 153 */     log.debug("dirty checking collections");
/*     */     
/* 155 */     List list = IdentityMap.entries(session.getPersistenceContext().getCollectionEntries());
/* 156 */     int size = list.size();
/* 157 */     for (int i = 0; i < size; i++) {
/* 158 */       Map.Entry e = (Map.Entry)list.get(i);
/* 159 */       ((CollectionEntry)e.getValue()).preFlush((PersistentCollection)e.getKey());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void flushEntities(FlushEvent event)
/*     */     throws HibernateException
/*     */   {
/* 170 */     log.trace("Flushing entities and processing referenced collections");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 179 */     EventSource source = event.getSession();
/*     */     
/* 181 */     Map.Entry[] list = IdentityMap.concurrentEntries(source.getPersistenceContext().getEntityEntries());
/* 182 */     int size = list.length;
/* 183 */     for (int i = 0; i < size; i++)
/*     */     {
/*     */ 
/*     */ 
/* 187 */       Map.Entry me = list[i];
/* 188 */       EntityEntry entry = (EntityEntry)me.getValue();
/* 189 */       Status status = entry.getStatus();
/*     */       
/* 191 */       if ((status != Status.LOADING) && (status != Status.GONE)) {
/* 192 */         FlushEntityEvent entityEvent = new FlushEntityEvent(source, me.getKey(), entry);
/* 193 */         FlushEntityEventListener[] listeners = source.getListeners().getFlushEntityEventListeners();
/* 194 */         for (int j = 0; j < listeners.length; j++) {
/* 195 */           listeners[j].onFlushEntity(entityEvent);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 200 */     source.getActionQueue().sortUpdateActions();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void flushCollections(EventSource session)
/*     */     throws HibernateException
/*     */   {
/* 209 */     log.trace("Processing unreferenced collections");
/*     */     
/* 211 */     List list = IdentityMap.entries(session.getPersistenceContext().getCollectionEntries());
/* 212 */     int size = list.size();
/* 213 */     for (int i = 0; i < size; i++) {
/* 214 */       Map.Entry me = (Map.Entry)list.get(i);
/* 215 */       CollectionEntry ce = (CollectionEntry)me.getValue();
/* 216 */       if ((!ce.isReached()) && (!ce.isIgnore())) {
/* 217 */         Collections.processUnreachableCollection((PersistentCollection)me.getKey(), session);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 223 */     log.trace("Scheduling collection removes/(re)creates/updates");
/*     */     
/* 225 */     list = IdentityMap.entries(session.getPersistenceContext().getCollectionEntries());
/* 226 */     size = list.size();
/* 227 */     ActionQueue actionQueue = session.getActionQueue();
/* 228 */     for (int i = 0; i < size; i++) {
/* 229 */       Map.Entry me = (Map.Entry)list.get(i);
/* 230 */       PersistentCollection coll = (PersistentCollection)me.getKey();
/* 231 */       CollectionEntry ce = (CollectionEntry)me.getValue();
/*     */       
/* 233 */       if (ce.isDorecreate()) {
/* 234 */         session.getInterceptor().onCollectionRecreate(coll, ce.getCurrentKey());
/* 235 */         actionQueue.addAction(new CollectionRecreateAction(coll, ce.getCurrentPersister(), ce.getCurrentKey(), session));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 244 */       if (ce.isDoremove()) {
/* 245 */         session.getInterceptor().onCollectionRemove(coll, ce.getLoadedKey());
/* 246 */         actionQueue.addAction(new CollectionRemoveAction(coll, ce.getLoadedPersister(), ce.getLoadedKey(), ce.isSnapshotEmpty(coll), session));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 256 */       if (ce.isDoupdate()) {
/* 257 */         session.getInterceptor().onCollectionUpdate(coll, ce.getLoadedKey());
/* 258 */         actionQueue.addAction(new CollectionUpdateAction(coll, ce.getLoadedPersister(), ce.getLoadedKey(), ce.isSnapshotEmpty(coll), session));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 271 */     actionQueue.sortCollectionActions();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void performExecutions(EventSource session)
/*     */     throws HibernateException
/*     */   {
/* 289 */     log.trace("executing flush");
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 295 */       session.getActionQueue().prepareActions();
/* 296 */       session.getActionQueue().executeActions();
/*     */     }
/*     */     catch (HibernateException he) {
/* 299 */       log.error("Could not synchronize database state with session", he);
/* 300 */       throw he;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void postFlush(SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/* 316 */     log.trace("post flush");
/*     */     
/* 318 */     PersistenceContext persistenceContext = session.getPersistenceContext();
/* 319 */     persistenceContext.getCollectionsByKey().clear();
/* 320 */     persistenceContext.getBatchFetchQueue().clearSubselects();
/*     */     
/*     */ 
/* 323 */     Iterator iter = persistenceContext.getCollectionEntries().entrySet().iterator();
/* 324 */     while (iter.hasNext()) {
/* 325 */       Map.Entry me = (Map.Entry)iter.next();
/* 326 */       CollectionEntry collectionEntry = (CollectionEntry)me.getValue();
/* 327 */       PersistentCollection persistentCollection = (PersistentCollection)me.getKey();
/* 328 */       collectionEntry.postFlush(persistentCollection);
/* 329 */       if (collectionEntry.getLoadedPersister() == null)
/*     */       {
/*     */ 
/* 332 */         persistenceContext.getCollectionEntries().remove(persistentCollection);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 337 */         CollectionKey collectionKey = new CollectionKey(collectionEntry.getLoadedPersister(), collectionEntry.getLoadedKey(), session.getEntityMode());
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 342 */         persistenceContext.getCollectionsByKey().put(collectionKey, persistentCollection);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 347 */     session.getInterceptor().postFlush(new LazyIterator(persistenceContext.getEntitiesByKey()));
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\AbstractFlushingEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */