/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import org.hibernate.engine.CascadingAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultSaveOrUpdateCopyEventListener
/*    */   extends DefaultMergeEventListener
/*    */ {
/*    */   protected CascadingAction getCascadeAction()
/*    */   {
/* 17 */     return CascadingAction.SAVE_UPDATE_COPY;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DefaultSaveOrUpdateCopyEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */