/*     */ package org.hibernate.event.def;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ import net.sf.cglib.transform.impl.InterceptFieldEnabled;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Interceptor;
/*     */ import org.hibernate.LockMode;
/*     */ import org.hibernate.NonUniqueObjectException;
/*     */ import org.hibernate.action.EntityIdentityInsertAction;
/*     */ import org.hibernate.action.EntityInsertAction;
/*     */ import org.hibernate.classic.Lifecycle;
/*     */ import org.hibernate.classic.Validatable;
/*     */ import org.hibernate.engine.ActionQueue;
/*     */ import org.hibernate.engine.Cascade;
/*     */ import org.hibernate.engine.CascadingAction;
/*     */ import org.hibernate.engine.EntityEntry;
/*     */ import org.hibernate.engine.EntityKey;
/*     */ import org.hibernate.engine.ForeignKeys;
/*     */ import org.hibernate.engine.ForeignKeys.Nullifier;
/*     */ import org.hibernate.engine.Nullability;
/*     */ import org.hibernate.engine.PersistenceContext;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.engine.Status;
/*     */ import org.hibernate.engine.Versioning;
/*     */ import org.hibernate.event.EventSource;
/*     */ import org.hibernate.id.IdentifierGenerationException;
/*     */ import org.hibernate.id.IdentifierGenerator;
/*     */ import org.hibernate.id.IdentifierGeneratorFactory;
/*     */ import org.hibernate.intercept.FieldInterceptor;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.pretty.MessageHelper;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.type.TypeFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSaveEventListener
/*     */   extends AbstractReassociateEventListener
/*     */ {
/*     */   protected static final int PERSISTENT = 0;
/*     */   protected static final int TRANSIENT = 1;
/*     */   protected static final int DETACHED = 2;
/*     */   protected static final int DELETED = 3;
/*  48 */   private static final Log log = LogFactory.getLog(AbstractSaveEventListener.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Serializable saveWithRequestedId(Object entity, Serializable requestedId, String entityName, Object anything, EventSource source)
/*     */     throws HibernateException
/*     */   {
/*  65 */     return performSave(entity, requestedId, source.getEntityPersister(entityName, entity), false, anything, source);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Serializable saveWithGeneratedId(Object entity, String entityName, Object anything, EventSource source)
/*     */     throws HibernateException
/*     */   {
/*  89 */     EntityPersister persister = source.getEntityPersister(entityName, entity);
/*     */     
/*  91 */     Serializable generatedId = persister.getIdentifierGenerator().generate(source, entity);
/*     */     
/*     */ 
/*  94 */     if (generatedId == null) {
/*  95 */       throw new IdentifierGenerationException("null id generated for:" + entity.getClass());
/*     */     }
/*  97 */     if (generatedId == IdentifierGeneratorFactory.SHORT_CIRCUIT_INDICATOR) {
/*  98 */       return source.getIdentifier(entity);
/*     */     }
/* 100 */     if (generatedId == IdentifierGeneratorFactory.POST_INSERT_INDICATOR) {
/* 101 */       return performSave(entity, null, persister, true, anything, source);
/*     */     }
/*     */     
/*     */ 
/* 105 */     if (log.isDebugEnabled()) {
/* 106 */       log.debug("generated identifier: " + persister.getIdentifierType().toLoggableString(generatedId, source.getFactory()) + ", using strategy: " + persister.getIdentifierGenerator().getClass().getName());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 114 */     return performSave(entity, generatedId, persister, false, anything, source);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Serializable performSave(Object entity, Serializable id, EntityPersister persister, boolean useIdentityColumn, Object anything, EventSource source)
/*     */     throws HibernateException
/*     */   {
/* 138 */     if (log.isTraceEnabled()) {
/* 139 */       log.trace("saving " + MessageHelper.infoString(persister, id, source.getFactory()));
/*     */     }
/*     */     
/*     */ 
/*     */     EntityKey key;
/*     */     
/*     */ 
/* 146 */     if (!useIdentityColumn) {
/* 147 */       EntityKey key = new EntityKey(id, persister, source.getEntityMode());
/* 148 */       Object old = source.getPersistenceContext().getEntity(key);
/* 149 */       if (old != null) {
/* 150 */         if (source.getPersistenceContext().getEntry(old).getStatus() == Status.DELETED) {
/* 151 */           source.forceFlush(source.getPersistenceContext().getEntry(old));
/*     */         }
/*     */         else {
/* 154 */           throw new NonUniqueObjectException(id, persister.getEntityName());
/*     */         }
/*     */       }
/* 157 */       persister.setIdentifier(entity, id, source.getEntityMode());
/*     */     }
/*     */     else {
/* 160 */       key = null;
/*     */     }
/*     */     
/* 163 */     if (invokeSaveLifecycle(entity, persister, source)) {
/* 164 */       return id;
/*     */     }
/*     */     
/* 167 */     return performSaveOrReplicate(entity, key, persister, useIdentityColumn, anything, source);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean invokeSaveLifecycle(Object entity, EntityPersister persister, EventSource source)
/*     */   {
/* 180 */     if (persister.implementsLifecycle(source.getEntityMode())) {
/* 181 */       log.debug("calling onSave()");
/* 182 */       if (((Lifecycle)entity).onSave(source)) {
/* 183 */         log.debug("insertion vetoed by onSave()");
/* 184 */         return true;
/*     */       }
/*     */     }
/* 187 */     return false;
/*     */   }
/*     */   
/*     */   protected void validate(Object entity, EntityPersister persister, EventSource source) {
/* 191 */     if (persister.implementsValidatable(source.getEntityMode())) {
/* 192 */       ((Validatable)entity).validate();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Serializable performSaveOrReplicate(Object entity, EntityKey key, EntityPersister persister, boolean useIdentityColumn, Object anything, EventSource source)
/*     */     throws HibernateException
/*     */   {
/* 216 */     validate(entity, persister, source);
/*     */     
/* 218 */     Serializable id = key == null ? null : key.getIdentifier();
/*     */     
/* 220 */     if (useIdentityColumn) {
/* 221 */       log.trace("executing insertions");
/* 222 */       source.getActionQueue().executeInserts();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 228 */     source.getPersistenceContext().addEntry(entity, Status.SAVING, null, null, id, null, LockMode.WRITE, useIdentityColumn, persister, false, false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 242 */     cascadeBeforeSave(source, persister, entity, anything);
/*     */     
/* 244 */     Object[] values = persister.getPropertyValuesToInsert(entity, getMergeMap(anything), source);
/* 245 */     Type[] types = persister.getPropertyTypes();
/*     */     
/* 247 */     boolean substitute = substituteValuesIfNecessary(entity, id, values, persister, source);
/*     */     
/* 249 */     if (persister.hasCollections()) {
/* 250 */       substitute = (substitute) || (visitCollectionsBeforeSave(id, values, types, source));
/*     */     }
/*     */     
/* 253 */     if (substitute) { persister.setPropertyValues(entity, values, source.getEntityMode());
/*     */     }
/* 255 */     TypeFactory.deepCopy(values, types, persister.getPropertyUpdateability(), values, source);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 263 */     new ForeignKeys.Nullifier(entity, false, useIdentityColumn, source).nullifyTransientReferences(values, types);
/*     */     
/* 265 */     new Nullability(source).checkNullability(values, persister, false);
/*     */     
/* 267 */     if (useIdentityColumn) {
/* 268 */       EntityIdentityInsertAction insert = new EntityIdentityInsertAction(values, entity, persister, source);
/* 269 */       source.getActionQueue().execute(insert);
/* 270 */       id = insert.getGeneratedId();
/*     */       
/*     */ 
/* 273 */       key = new EntityKey(id, persister, source.getEntityMode());
/* 274 */       source.getPersistenceContext().checkUniqueness(key, entity);
/*     */     }
/*     */     
/*     */ 
/* 278 */     Object version = Versioning.getVersion(values, persister);
/* 279 */     source.getPersistenceContext().addEntity(entity, Status.MANAGED, values, key, version, LockMode.WRITE, useIdentityColumn, persister, isVersionIncrementDisabled(), false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 293 */     if (!useIdentityColumn) {
/* 294 */       source.getActionQueue().addAction(new EntityInsertAction(id, values, entity, version, persister, source));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 299 */     cascadeAfterSave(source, persister, entity, anything);
/*     */     
/* 301 */     markInterceptorDirty(entity, persister, source);
/*     */     
/* 303 */     return id;
/*     */   }
/*     */   
/*     */   private void markInterceptorDirty(Object entity, EntityPersister persister, EventSource source) {
/* 307 */     if ((entity instanceof InterceptFieldEnabled)) {
/* 308 */       FieldInterceptor fieldInterceptor = FieldInterceptor.initFieldInterceptor(entity, persister.getEntityName(), source, null);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 314 */       fieldInterceptor.dirty();
/*     */     }
/*     */   }
/*     */   
/*     */   protected Map getMergeMap(Object anything) {
/* 319 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isVersionIncrementDisabled()
/*     */   {
/* 327 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean visitCollectionsBeforeSave(Serializable id, Object[] values, Type[] types, EventSource source) {
/* 331 */     WrapVisitor visitor = new WrapVisitor(source);
/*     */     
/* 333 */     visitor.processEntityPropertyValues(values, types);
/* 334 */     return visitor.isSubstitutionRequired();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean substituteValuesIfNecessary(Object entity, Serializable id, Object[] values, EntityPersister persister, SessionImplementor source)
/*     */   {
/* 348 */     boolean substitute = source.getInterceptor().onSave(entity, id, values, persister.getPropertyNames(), persister.getPropertyTypes());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 357 */     if (persister.isVersioned()) {
/* 358 */       substitute = (Versioning.seedVersion(values, persister.getVersionProperty(), persister.getVersionType(), source)) || (substitute);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 365 */     return substitute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void cascadeBeforeSave(EventSource source, EntityPersister persister, Object entity, Object anything)
/*     */     throws HibernateException
/*     */   {
/* 383 */     source.getPersistenceContext().incrementCascadeLevel();
/*     */     try {
/* 385 */       new Cascade(getCascadeAction(), 2, source).cascade(persister, entity, anything);
/*     */     }
/*     */     finally
/*     */     {
/* 389 */       source.getPersistenceContext().decrementCascadeLevel();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void cascadeAfterSave(EventSource source, EntityPersister persister, Object entity, Object anything)
/*     */     throws HibernateException
/*     */   {
/* 408 */     source.getPersistenceContext().incrementCascadeLevel();
/*     */     try {
/* 410 */       new Cascade(getCascadeAction(), 1, source).cascade(persister, entity, anything);
/*     */     }
/*     */     finally
/*     */     {
/* 414 */       source.getPersistenceContext().decrementCascadeLevel();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract CascadingAction getCascadeAction();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getEntityState(Object entity, String entityName, EntityEntry entry, SessionImplementor source)
/*     */   {
/* 430 */     if (entry != null)
/*     */     {
/*     */ 
/* 433 */       if (entry.getStatus() != Status.DELETED)
/*     */       {
/* 435 */         if (log.isTraceEnabled()) {
/* 436 */           log.trace("persistent instance of: " + getLoggableName(entityName, entity));
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 441 */         return 0;
/*     */       }
/*     */       
/*     */ 
/* 445 */       if (log.isTraceEnabled()) {
/* 446 */         log.trace("deleted instance of: " + getLoggableName(entityName, entity));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 451 */       return 3;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 460 */     if (ForeignKeys.isTransient(entityName, entity, getAssumedUnsaved(), source)) {
/* 461 */       if (log.isTraceEnabled()) {
/* 462 */         log.trace("transient instance of: " + getLoggableName(entityName, entity));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 467 */       return 1;
/*     */     }
/*     */     
/* 470 */     if (log.isTraceEnabled()) {
/* 471 */       log.trace("detached instance of: " + getLoggableName(entityName, entity));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 476 */     return 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getLoggableName(String entityName, Object entity)
/*     */   {
/* 483 */     return entityName == null ? entity.getClass().getName() : entityName;
/*     */   }
/*     */   
/*     */   protected Boolean getAssumedUnsaved() {
/* 487 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\AbstractSaveEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */