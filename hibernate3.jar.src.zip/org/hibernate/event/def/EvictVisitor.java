/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.collection.PersistentCollection;
/*    */ import org.hibernate.engine.CollectionEntry;
/*    */ import org.hibernate.engine.CollectionKey;
/*    */ import org.hibernate.engine.PersistenceContext;
/*    */ import org.hibernate.event.EventSource;
/*    */ import org.hibernate.pretty.MessageHelper;
/*    */ import org.hibernate.type.CollectionType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EvictVisitor
/*    */   extends AbstractVisitor
/*    */ {
/* 23 */   private static final Log log = LogFactory.getLog(EvictVisitor.class);
/*    */   
/*    */   EvictVisitor(EventSource session) {
/* 26 */     super(session);
/*    */   }
/*    */   
/*    */   Object processCollection(Object collection, CollectionType type)
/*    */     throws HibernateException
/*    */   {
/* 32 */     if (collection != null) { evictCollection(collection, type);
/*    */     }
/* 34 */     return null;
/*    */   }
/*    */   
/*    */   public void evictCollection(Object value, CollectionType type) { Object pc;
/*    */     Object pc;
/* 39 */     if (type.hasHolder(getSession().getEntityMode())) {
/* 40 */       pc = getSession().getPersistenceContext().removeCollectionHolder(value);
/*    */     }
/* 42 */     else if ((value instanceof PersistentCollection)) {
/* 43 */       pc = value;
/*    */     }
/*    */     else {
/* 46 */       return;
/*    */     }
/*    */     
/* 49 */     PersistentCollection collection = (PersistentCollection)pc;
/* 50 */     if (collection.unsetSession(getSession())) evictCollection(collection);
/*    */   }
/*    */   
/*    */   private void evictCollection(PersistentCollection collection) {
/* 54 */     CollectionEntry ce = (CollectionEntry)getSession().getPersistenceContext().getCollectionEntries().remove(collection);
/* 55 */     if (log.isDebugEnabled()) {
/* 56 */       log.debug("evicting collection: " + MessageHelper.collectionInfoString(ce.getLoadedPersister(), ce.getLoadedKey(), getSession().getFactory()));
/*    */     }
/*    */     
/*    */ 
/* 60 */     if ((ce.getLoadedPersister() != null) && (ce.getLoadedKey() != null))
/*    */     {
/* 62 */       getSession().getPersistenceContext().getCollectionsByKey().remove(new CollectionKey(ce.getLoadedPersister(), ce.getLoadedKey(), getSession().getEntityMode()));
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\EvictVisitor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */