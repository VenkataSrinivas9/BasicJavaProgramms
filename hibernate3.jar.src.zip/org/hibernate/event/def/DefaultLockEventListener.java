/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.LockMode;
/*    */ import org.hibernate.TransientObjectException;
/*    */ import org.hibernate.engine.Cascade;
/*    */ import org.hibernate.engine.CascadingAction;
/*    */ import org.hibernate.engine.EntityEntry;
/*    */ import org.hibernate.engine.ForeignKeys;
/*    */ import org.hibernate.engine.PersistenceContext;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.event.EventSource;
/*    */ import org.hibernate.event.LockEvent;
/*    */ import org.hibernate.event.LockEventListener;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultLockEventListener
/*    */   extends AbstractLockUpgradeEventListener
/*    */   implements LockEventListener
/*    */ {
/*    */   public void onLock(LockEvent event)
/*    */     throws HibernateException
/*    */   {
/* 34 */     if (event.getObject() == null) {
/* 35 */       throw new NullPointerException("attempted to lock null");
/*    */     }
/*    */     
/* 38 */     if (event.getLockMode() == LockMode.WRITE) {
/* 39 */       throw new HibernateException("Invalid lock mode for lock()");
/*    */     }
/*    */     
/* 42 */     SessionImplementor source = event.getSession();
/*    */     
/* 44 */     Object entity = source.getPersistenceContext().unproxyAndReassociate(event.getObject());
/*    */     
/*    */ 
/*    */ 
/* 48 */     EntityEntry entry = source.getPersistenceContext().getEntry(entity);
/* 49 */     if (entry == null) {
/* 50 */       EntityPersister persister = source.getEntityPersister(event.getEntityName(), entity);
/* 51 */       Serializable id = persister.getIdentifier(entity, source.getEntityMode());
/* 52 */       if (!ForeignKeys.isNotTransient(event.getEntityName(), entity, Boolean.FALSE, source)) {
/* 53 */         throw new TransientObjectException("cannot lock an unsaved transient instance: " + persister.getEntityName());
/*    */       }
/*    */       
/*    */ 
/*    */ 
/*    */ 
/* 59 */       entry = reassociate(event, entity, id, persister);
/*    */       
/* 61 */       cascadeOnLock(event, persister, entity);
/*    */     }
/*    */     
/* 64 */     upgradeLock(entity, entry, event.getLockMode(), source);
/*    */   }
/*    */   
/*    */   private void cascadeOnLock(LockEvent event, EntityPersister persister, Object entity) {
/* 68 */     EventSource source = event.getSession();
/* 69 */     source.getPersistenceContext().incrementCascadeLevel();
/*    */     try {
/* 71 */       new Cascade(CascadingAction.LOCK, 0, source).cascade(persister, entity, event.getLockMode());
/*    */     }
/*    */     finally
/*    */     {
/* 75 */       source.getPersistenceContext().decrementCascadeLevel();
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DefaultLockEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */