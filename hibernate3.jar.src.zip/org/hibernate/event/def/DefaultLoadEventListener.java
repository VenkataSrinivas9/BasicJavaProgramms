/*     */ package org.hibernate.event.def;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.CacheMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.LockMode;
/*     */ import org.hibernate.NonUniqueObjectException;
/*     */ import org.hibernate.ObjectDeletedException;
/*     */ import org.hibernate.ObjectNotFoundException;
/*     */ import org.hibernate.PersistentObjectException;
/*     */ import org.hibernate.cache.CacheConcurrencyStrategy;
/*     */ import org.hibernate.cache.CacheConcurrencyStrategy.SoftLock;
/*     */ import org.hibernate.cache.CacheKey;
/*     */ import org.hibernate.cache.entry.CacheEntry;
/*     */ import org.hibernate.cache.entry.CacheEntryStructure;
/*     */ import org.hibernate.engine.BatchFetchQueue;
/*     */ import org.hibernate.engine.EntityEntry;
/*     */ import org.hibernate.engine.EntityKey;
/*     */ import org.hibernate.engine.PersistenceContext;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.engine.Status;
/*     */ import org.hibernate.engine.TwoPhaseLoad;
/*     */ import org.hibernate.engine.Versioning;
/*     */ import org.hibernate.event.EventListeners;
/*     */ import org.hibernate.event.EventSource;
/*     */ import org.hibernate.event.LoadEvent;
/*     */ import org.hibernate.event.LoadEventListener;
/*     */ import org.hibernate.event.LoadEventListener.LoadType;
/*     */ import org.hibernate.event.PostLoadEvent;
/*     */ import org.hibernate.event.PostLoadEventListener;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.pretty.MessageHelper;
/*     */ import org.hibernate.proxy.HibernateProxy;
/*     */ import org.hibernate.proxy.LazyInitializer;
/*     */ import org.hibernate.stat.Statistics;
/*     */ import org.hibernate.stat.StatisticsImplementor;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.type.TypeFactory;
/*     */ 
/*     */ public class DefaultLoadEventListener extends AbstractLockUpgradeEventListener implements LoadEventListener
/*     */ {
/*  45 */   private static final Log log = LogFactory.getLog(DefaultLoadEventListener.class);
/*     */   
/*  47 */   public static final LockMode DEFAULT_LOCK_MODE = LockMode.NONE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onLoad(LoadEvent event, LoadEventListener.LoadType loadType)
/*     */     throws HibernateException
/*     */   {
/*  58 */     SessionImplementor source = event.getSession();
/*     */     
/*     */     EntityPersister persister;
/*  61 */     if (event.getInstanceToLoad() != null) {
/*  62 */       EntityPersister persister = source.getEntityPersister(null, event.getInstanceToLoad());
/*  63 */       event.setEntityClassName(event.getInstanceToLoad().getClass().getName());
/*     */     }
/*     */     else {
/*  66 */       persister = source.getFactory().getEntityPersister(event.getEntityClassName());
/*     */     }
/*     */     
/*  69 */     if (persister == null) {
/*  70 */       throw new HibernateException("Unable to locate persister: " + event.getEntityClassName());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  76 */     EntityKey keyToLoad = new EntityKey(event.getEntityId(), persister, source.getEntityMode());
/*     */     try
/*     */     {
/*  79 */       if (loadType.isNakedEntityReturned())
/*     */       {
/*     */ 
/*  82 */         event.setResult(load(event, persister, keyToLoad, loadType));
/*     */ 
/*     */ 
/*     */       }
/*  86 */       else if (event.getLockMode() == LockMode.NONE) {
/*  87 */         event.setResult(proxyOrLoad(event, persister, keyToLoad, loadType));
/*     */       }
/*     */       else {
/*  90 */         event.setResult(lockAndLoad(event, persister, keyToLoad, loadType, source));
/*     */       }
/*     */     }
/*     */     catch (HibernateException e)
/*     */     {
/*  95 */       log.info("Error performing load command", e);
/*  96 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object load(LoadEvent event, EntityPersister persister, EntityKey keyToLoad, LoadEventListener.LoadType options)
/*     */     throws HibernateException
/*     */   {
/* 113 */     if (event.getInstanceToLoad() != null) {
/* 114 */       if (event.getSession().getPersistenceContext().getEntry(event.getInstanceToLoad()) != null) {
/* 115 */         throw new PersistentObjectException("attempted to load into an instance that was already associated with the session: " + MessageHelper.infoString(persister, event.getEntityId(), event.getSession().getFactory()));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 120 */       persister.setIdentifier(event.getInstanceToLoad(), event.getEntityId(), event.getSession().getEntityMode());
/*     */     }
/*     */     
/* 123 */     Object entity = doLoad(event, persister, keyToLoad, options);
/*     */     
/* 125 */     boolean isOptionalInstance = event.getInstanceToLoad() != null;
/*     */     
/* 127 */     if ((!options.isAllowNulls()) || (isOptionalInstance)) {
/* 128 */       ObjectNotFoundException.throwIfNull(entity, event.getEntityId(), event.getEntityClassName());
/*     */     }
/*     */     
/* 131 */     if ((isOptionalInstance) && (entity != event.getInstanceToLoad())) {
/* 132 */       throw new NonUniqueObjectException(event.getEntityId(), event.getEntityClassName());
/*     */     }
/*     */     
/* 135 */     return entity;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object proxyOrLoad(LoadEvent event, EntityPersister persister, EntityKey keyToLoad, LoadEventListener.LoadType options)
/*     */     throws HibernateException
/*     */   {
/* 152 */     if (log.isTraceEnabled()) {
/* 153 */       log.trace("loading entity: " + MessageHelper.infoString(persister, event.getEntityId(), event.getSession().getFactory()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 159 */     if (!persister.hasProxy())
/*     */     {
/* 161 */       return load(event, persister, keyToLoad, options);
/*     */     }
/*     */     
/* 164 */     PersistenceContext persistenceContext = event.getSession().getPersistenceContext();
/*     */     
/*     */ 
/* 167 */     Object proxy = persistenceContext.getProxy(keyToLoad);
/* 168 */     if (proxy != null) {
/* 169 */       return returnNarrowedProxy(event, persister, keyToLoad, options, persistenceContext, proxy);
/*     */     }
/*     */     
/* 172 */     if (options.isAllowProxyCreation()) {
/* 173 */       return createProxyIfNecessary(event, persister, keyToLoad, options, persistenceContext);
/*     */     }
/*     */     
/*     */ 
/* 177 */     return load(event, persister, keyToLoad, options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object returnNarrowedProxy(LoadEvent event, EntityPersister persister, EntityKey keyToLoad, LoadEventListener.LoadType options, PersistenceContext persistenceContext, Object proxy)
/*     */   {
/* 196 */     log.trace("entity proxy found in session cache");
/* 197 */     LazyInitializer li = ((HibernateProxy)proxy).getHibernateLazyInitializer();
/* 198 */     if (li.isUnwrap()) {
/* 199 */       return li.getImplementation();
/*     */     }
/*     */     
/* 202 */     Object impl = options.isAllowProxyCreation() ? null : load(event, persister, keyToLoad, options);
/*     */     
/* 204 */     return persistenceContext.narrowProxy(proxy, persister, keyToLoad, impl);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object createProxyIfNecessary(LoadEvent event, EntityPersister persister, EntityKey keyToLoad, LoadEventListener.LoadType options, PersistenceContext persistenceContext)
/*     */   {
/* 219 */     Object existing = persistenceContext.getEntity(keyToLoad);
/* 220 */     if (existing != null)
/*     */     {
/* 222 */       log.trace("entity found in session cache");
/* 223 */       if (options.isCheckDeleted()) {
/* 224 */         EntityEntry entry = persistenceContext.getEntry(existing);
/* 225 */         throwObjectDeletedIfNecessary(event, entry);
/*     */       }
/* 227 */       return existing;
/*     */     }
/*     */     
/* 230 */     log.trace("creating new proxy for entity");
/*     */     
/* 232 */     Object proxy = persister.createProxy(event.getEntityId(), event.getSession());
/* 233 */     persistenceContext.getBatchFetchQueue().addBatchLoadableEntityKey(keyToLoad);
/* 234 */     persistenceContext.addProxy(keyToLoad, proxy);
/* 235 */     return proxy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object lockAndLoad(LoadEvent event, EntityPersister persister, EntityKey keyToLoad, LoadEventListener.LoadType options, SessionImplementor source)
/*     */     throws HibernateException
/*     */   {
/* 254 */     CacheConcurrencyStrategy.SoftLock lock = null;
/*     */     CacheKey ck;
/* 256 */     if (persister.hasCache()) {
/* 257 */       CacheKey ck = new CacheKey(event.getEntityId(), persister.getIdentifierType(), persister.getRootEntityName(), source.getEntityMode(), source.getFactory());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 264 */       lock = persister.getCache().lock(ck, null);
/*     */     }
/*     */     else {
/* 267 */       ck = null;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 272 */       entity = load(event, persister, keyToLoad, options);
/*     */     } finally {
/*     */       Object entity;
/* 275 */       if (persister.hasCache()) {
/* 276 */         persister.getCache().release(ck, lock);
/*     */       }
/*     */     }
/*     */     Object entity;
/* 280 */     Object proxy = event.getSession().getPersistenceContext().proxyFor(persister, keyToLoad, entity);
/*     */     
/*     */ 
/* 283 */     return proxy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object doLoad(LoadEvent event, EntityPersister persister, EntityKey keyToLoad, LoadEventListener.LoadType options)
/*     */     throws HibernateException
/*     */   {
/* 303 */     if (log.isTraceEnabled()) {
/* 304 */       log.trace("attempting to resolve: " + MessageHelper.infoString(persister, event.getEntityId(), event.getSession().getFactory()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 310 */     Object entity = loadFromSessionCache(event, keyToLoad, options);
/* 311 */     if (entity != null) {
/* 312 */       if (log.isTraceEnabled()) {
/* 313 */         log.trace("resolved object in session cache: " + MessageHelper.infoString(persister, event.getEntityId(), event.getSession().getFactory()));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 318 */       return entity;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 328 */     entity = loadFromSecondLevelCache(event, persister, options);
/* 329 */     if (entity != null) {
/* 330 */       if (log.isTraceEnabled()) {
/* 331 */         log.trace("resolved object in second-level cache: " + MessageHelper.infoString(persister, event.getEntityId(), event.getSession().getFactory()));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 336 */       return entity;
/*     */     }
/*     */     
/* 339 */     if (log.isTraceEnabled()) {
/* 340 */       log.trace("object not resolved in any cache: " + MessageHelper.infoString(persister, event.getEntityId(), event.getSession().getFactory()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 346 */     return loadFromDatasource(event, persister, keyToLoad, options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object loadFromDatasource(LoadEvent event, EntityPersister persister, EntityKey keyToLoad, LoadEventListener.LoadType options)
/*     */     throws HibernateException
/*     */   {
/* 363 */     SessionImplementor source = event.getSession();
/*     */     
/* 365 */     Object entity = persister.load(event.getEntityId(), event.getInstanceToLoad(), event.getLockMode(), source);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 377 */     if ((event.isAssociationFetch()) && (source.getFactory().getStatistics().isStatisticsEnabled())) {
/* 378 */       source.getFactory().getStatisticsImplementor().fetchEntity(event.getEntityClassName());
/*     */     }
/*     */     
/* 381 */     return entity;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object loadFromSessionCache(LoadEvent event, EntityKey keyToLoad, LoadEventListener.LoadType options)
/*     */     throws HibernateException
/*     */   {
/* 399 */     SessionImplementor session = event.getSession();
/* 400 */     Object old = session.getEntityUsingInterceptor(keyToLoad);
/* 401 */     if (old != null)
/*     */     {
/* 403 */       EntityEntry oldEntry = session.getPersistenceContext().getEntry(old);
/* 404 */       if (options.isCheckDeleted()) {
/* 405 */         throwObjectDeletedIfNecessary(event, oldEntry);
/*     */       }
/* 407 */       upgradeLock(old, oldEntry, event.getLockMode(), session);
/*     */     }
/* 409 */     return old;
/*     */   }
/*     */   
/*     */   private void throwObjectDeletedIfNecessary(LoadEvent event, EntityEntry oldEntry) {
/* 413 */     Status status = oldEntry.getStatus();
/* 414 */     if ((status == Status.DELETED) || (status == Status.GONE)) {
/* 415 */       throw new ObjectDeletedException("The object with that id was deleted", event.getEntityId(), event.getEntityClassName());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object loadFromSecondLevelCache(LoadEvent event, EntityPersister persister, LoadEventListener.LoadType options)
/*     */     throws HibernateException
/*     */   {
/* 435 */     SessionImplementor source = event.getSession();
/*     */     
/* 437 */     boolean useCache = (persister.hasCache()) && (source.getCacheMode().isGetEnabled()) && (event.getLockMode().lessThan(LockMode.READ));
/*     */     
/*     */ 
/*     */ 
/* 441 */     if (useCache)
/*     */     {
/* 443 */       SessionFactoryImplementor factory = source.getFactory();
/*     */       
/* 445 */       CacheKey ck = new CacheKey(event.getEntityId(), persister.getIdentifierType(), persister.getRootEntityName(), source.getEntityMode(), source.getFactory());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 452 */       Object ce = persister.getCache().get(ck, source.getTimestamp());
/*     */       
/*     */ 
/* 455 */       if (factory.getStatistics().isStatisticsEnabled()) {
/* 456 */         if (ce == null) {
/* 457 */           factory.getStatisticsImplementor().secondLevelCacheMiss(persister.getCache().getRegionName());
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 462 */           factory.getStatisticsImplementor().secondLevelCacheHit(persister.getCache().getRegionName());
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 468 */       if (ce != null)
/*     */       {
/* 470 */         CacheEntry entry = (CacheEntry)persister.getCacheEntryStructure().destructure(ce, factory);
/*     */         
/*     */ 
/*     */ 
/* 474 */         return assembleCacheEntry(entry, event.getEntityId(), persister, event);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 483 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object assembleCacheEntry(CacheEntry entry, Serializable id, EntityPersister persister, LoadEvent event)
/*     */     throws HibernateException
/*     */   {
/* 493 */     Object optionalObject = event.getInstanceToLoad();
/* 494 */     EventSource session = event.getSession();
/* 495 */     SessionFactoryImplementor factory = session.getFactory();
/*     */     
/* 497 */     if (log.isTraceEnabled()) {
/* 498 */       log.trace("assembling entity from second-level cache: " + MessageHelper.infoString(persister, id, factory));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 504 */     EntityPersister subclassPersister = factory.getEntityPersister(entry.getSubclass());
/* 505 */     Object result = optionalObject == null ? session.instantiate(subclassPersister, id) : optionalObject;
/*     */     
/*     */ 
/*     */ 
/* 509 */     TwoPhaseLoad.addUninitializedCachedEntity(new EntityKey(id, subclassPersister, session.getEntityMode()), result, subclassPersister, LockMode.NONE, entry.areLazyPropertiesUnfetched(), entry.getVersion(), session);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 519 */     Type[] types = subclassPersister.getPropertyTypes();
/* 520 */     Object[] values = entry.assemble(result, id, subclassPersister, session.getInterceptor(), session);
/* 521 */     TypeFactory.deepCopy(values, types, subclassPersister.getPropertyUpdateability(), values, session);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 529 */     Object version = Versioning.getVersion(values, subclassPersister);
/* 530 */     if (log.isTraceEnabled()) { log.trace("Cached Version: " + version);
/*     */     }
/* 532 */     PersistenceContext persistenceContext = session.getPersistenceContext();
/* 533 */     persistenceContext.addEntry(result, Status.MANAGED, values, null, id, version, LockMode.NONE, true, subclassPersister, false, entry.areLazyPropertiesUnfetched());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 546 */     subclassPersister.afterInitialize(result, entry.areLazyPropertiesUnfetched(), session);
/* 547 */     persistenceContext.initializeNonLazyCollections();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 553 */     PostLoadEvent postLoadEvent = new PostLoadEvent(session).setEntity(result).setId(id).setPersister(persister);
/*     */     
/* 555 */     PostLoadEventListener[] listeners = session.getListeners().getPostLoadEventListeners();
/* 556 */     for (int i = 0; i < listeners.length; i++) {
/* 557 */       listeners[i].onPostLoad(postLoadEvent);
/*     */     }
/*     */     
/* 560 */     return result;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DefaultLoadEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */