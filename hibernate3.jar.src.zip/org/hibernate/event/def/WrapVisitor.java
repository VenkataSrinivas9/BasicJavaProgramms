/*     */ package org.hibernate.event.def;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.collection.PersistentCollection;
/*     */ import org.hibernate.engine.PersistenceContext;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.event.EventSource;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.type.AbstractComponentType;
/*     */ import org.hibernate.type.CollectionType;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WrapVisitor
/*     */   extends ProxyVisitor
/*     */ {
/*  25 */   private static final Log log = LogFactory.getLog(WrapVisitor.class);
/*     */   
/*  27 */   boolean substitute = false;
/*     */   
/*     */   boolean isSubstitutionRequired() {
/*  30 */     return this.substitute;
/*     */   }
/*     */   
/*     */   WrapVisitor(EventSource session) {
/*  34 */     super(session);
/*     */   }
/*     */   
/*     */   Object processCollection(Object collection, CollectionType collectionType)
/*     */     throws HibernateException
/*     */   {
/*  40 */     if ((collection != null) && ((collection instanceof PersistentCollection)))
/*     */     {
/*  42 */       SessionImplementor session = getSession();
/*  43 */       PersistentCollection coll = (PersistentCollection)collection;
/*  44 */       if (coll.setCurrentSession(session)) {
/*  45 */         reattachCollection(coll, collectionType);
/*     */       }
/*  47 */       return null;
/*     */     }
/*     */     
/*     */ 
/*  51 */     return processArrayOrNewCollection(collection, collectionType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   final Object processArrayOrNewCollection(Object collection, CollectionType collectionType)
/*     */     throws HibernateException
/*     */   {
/*  59 */     SessionImplementor session = getSession();
/*     */     
/*  61 */     if (collection == null)
/*     */     {
/*  63 */       return null;
/*     */     }
/*     */     
/*  66 */     CollectionPersister persister = session.getFactory().getCollectionPersister(collectionType.getRole());
/*     */     
/*  68 */     PersistenceContext persistenceContext = session.getPersistenceContext();
/*     */     
/*  70 */     if (collectionType.hasHolder(session.getEntityMode()))
/*     */     {
/*  72 */       if (collection == CollectionType.UNFETCHED_COLLECTION) { return null;
/*     */       }
/*  74 */       PersistentCollection ah = persistenceContext.getCollectionHolder(collection);
/*  75 */       if (ah == null) {
/*  76 */         ah = collectionType.wrap(session, collection);
/*  77 */         persistenceContext.addNewCollection(persister, ah);
/*  78 */         persistenceContext.addCollectionHolder(ah);
/*     */       }
/*  80 */       return null;
/*     */     }
/*     */     
/*     */ 
/*  84 */     PersistentCollection persistentCollection = collectionType.wrap(session, collection);
/*  85 */     persistenceContext.addNewCollection(persister, persistentCollection);
/*     */     
/*  87 */     if (log.isTraceEnabled()) { log.trace("Wrapped collection in role: " + collectionType.getRole());
/*     */     }
/*  89 */     return persistentCollection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void processValue(int i, Object[] values, Type[] types)
/*     */   {
/*  98 */     Object result = processValue(values[i], types[i]);
/*  99 */     if (result != null) {
/* 100 */       this.substitute = true;
/* 101 */       values[i] = result;
/*     */     }
/*     */   }
/*     */   
/*     */   Object processComponent(Object component, AbstractComponentType componentType)
/*     */     throws HibernateException
/*     */   {
/* 108 */     if (component != null) {
/* 109 */       Object[] values = componentType.getPropertyValues(component, getSession());
/* 110 */       Type[] types = componentType.getSubtypes();
/* 111 */       boolean substituteComponent = false;
/* 112 */       for (int i = 0; i < types.length; i++) {
/* 113 */         Object result = processValue(values[i], types[i]);
/* 114 */         if (result != null) {
/* 115 */           values[i] = result;
/* 116 */           substituteComponent = true;
/*     */         }
/*     */       }
/* 119 */       if (substituteComponent) {
/* 120 */         componentType.setPropertyValues(component, values, getSession().getEntityMode());
/*     */       }
/*     */     }
/*     */     
/* 124 */     return null;
/*     */   }
/*     */   
/*     */   void process(Object object, EntityPersister persister) throws HibernateException {
/* 128 */     EntityMode entityMode = getSession().getEntityMode();
/* 129 */     Object[] values = persister.getPropertyValues(object, entityMode);
/* 130 */     Type[] types = persister.getPropertyTypes();
/* 131 */     processEntityPropertyValues(values, types);
/* 132 */     if (isSubstitutionRequired()) {
/* 133 */       persister.setPropertyValues(object, values, entityMode);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\WrapVisitor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */