/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.collection.PersistentCollection;
/*    */ import org.hibernate.engine.PersistenceContext;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.event.EventSource;
/*    */ import org.hibernate.persister.collection.CollectionPersister;
/*    */ import org.hibernate.type.CollectionType;
/*    */ import org.hibernate.type.EntityType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ProxyVisitor
/*    */   extends AbstractVisitor
/*    */ {
/*    */   public ProxyVisitor(EventSource session)
/*    */   {
/* 21 */     super(session);
/*    */   }
/*    */   
/*    */   Object processEntity(Object value, EntityType entityType) throws HibernateException
/*    */   {
/* 26 */     if (value != null) {
/* 27 */       getSession().getPersistenceContext().reassociateIfUninitializedProxy(value);
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 32 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected static boolean isOwnerUnchanged(PersistentCollection snapshot, CollectionPersister persister, Serializable id)
/*    */   {
/* 44 */     return (isCollectionSnapshotValid(snapshot)) && (persister.getRole().equals(snapshot.getRole())) && (id.equals(snapshot.getKey()));
/*    */   }
/*    */   
/*    */ 
/*    */   private static boolean isCollectionSnapshotValid(PersistentCollection snapshot)
/*    */   {
/* 50 */     return (snapshot != null) && (snapshot.getRole() != null) && (snapshot.getKey() != null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void reattachCollection(PersistentCollection collection, CollectionType type)
/*    */     throws HibernateException
/*    */   {
/* 62 */     if (collection.wasInitialized()) {
/* 63 */       CollectionPersister collectionPersister = getSession().getFactory().getCollectionPersister(type.getRole());
/*    */       
/* 65 */       getSession().getPersistenceContext().addInitializedDetachedCollection(collectionPersister, collection);
/*    */     }
/*    */     else
/*    */     {
/* 69 */       if (!isCollectionSnapshotValid(collection)) {
/* 70 */         throw new HibernateException("could not reassociate uninitialized transient collection");
/*    */       }
/* 72 */       CollectionPersister collectionPersister = getSession().getFactory().getCollectionPersister(collection.getRole());
/*    */       
/* 74 */       getSession().getPersistenceContext().addUninitializedDetachedCollection(collectionPersister, collection);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\ProxyVisitor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */