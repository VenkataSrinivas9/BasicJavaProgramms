/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.engine.PersistenceContext;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.event.EventSource;
/*    */ import org.hibernate.event.FlushEvent;
/*    */ import org.hibernate.event.FlushEventListener;
/*    */ import org.hibernate.stat.Statistics;
/*    */ import org.hibernate.stat.StatisticsImplementor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultFlushEventListener
/*    */   extends AbstractFlushingEventListener
/*    */   implements FlushEventListener
/*    */ {
/*    */   public void onFlush(FlushEvent event)
/*    */     throws HibernateException
/*    */   {
/* 23 */     EventSource source = event.getSession();
/* 24 */     if (source.getPersistenceContext().hasNonReadOnlyEntities())
/*    */     {
/* 26 */       flushEverythingToExecutions(event);
/* 27 */       performExecutions(source);
/* 28 */       postFlush(source);
/*    */       
/* 30 */       if (source.getFactory().getStatistics().isStatisticsEnabled()) {
/* 31 */         source.getFactory().getStatisticsImplementor().flush();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DefaultFlushEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */