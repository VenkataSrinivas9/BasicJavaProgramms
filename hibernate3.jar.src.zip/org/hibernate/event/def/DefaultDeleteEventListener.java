/*     */ package org.hibernate.event.def;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.HashSet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.CacheMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Interceptor;
/*     */ import org.hibernate.LockMode;
/*     */ import org.hibernate.TransientObjectException;
/*     */ import org.hibernate.action.EntityDeleteAction;
/*     */ import org.hibernate.cfg.Settings;
/*     */ import org.hibernate.classic.Lifecycle;
/*     */ import org.hibernate.engine.ActionQueue;
/*     */ import org.hibernate.engine.Cascade;
/*     */ import org.hibernate.engine.CascadingAction;
/*     */ import org.hibernate.engine.EntityEntry;
/*     */ import org.hibernate.engine.EntityKey;
/*     */ import org.hibernate.engine.ForeignKeys.Nullifier;
/*     */ import org.hibernate.engine.Nullability;
/*     */ import org.hibernate.engine.PersistenceContext;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.Status;
/*     */ import org.hibernate.event.DeleteEvent;
/*     */ import org.hibernate.event.DeleteEventListener;
/*     */ import org.hibernate.event.EventSource;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.pretty.MessageHelper;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.type.TypeFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultDeleteEventListener
/*     */   implements DeleteEventListener
/*     */ {
/*  39 */   private static final Log log = LogFactory.getLog(DefaultDeleteEventListener.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onDelete(DeleteEvent event)
/*     */     throws HibernateException
/*     */   {
/*  47 */     EventSource source = event.getSession();
/*     */     
/*  49 */     PersistenceContext persistenceContext = source.getPersistenceContext();
/*  50 */     Object entity = persistenceContext.unproxyAndReassociate(event.getObject());
/*  51 */     EntityEntry entityEntry = persistenceContext.getEntry(entity);
/*     */     
/*     */     EntityPersister persister;
/*     */     Serializable id;
/*     */     Object version;
/*  56 */     if (entityEntry == null) {
/*  57 */       log.trace("deleting a detached instance");
/*     */       
/*  59 */       EntityPersister persister = source.getEntityPersister(event.getEntityName(), entity);
/*  60 */       Serializable id = persister.getIdentifier(entity, source.getEntityMode());
/*     */       
/*  62 */       if (id == null) {
/*  63 */         throw new TransientObjectException("the detached instance passed to delete() had a null identifier");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*  68 */       EntityKey key = new EntityKey(id, persister, source.getEntityMode());
/*     */       
/*  70 */       persistenceContext.checkUniqueness(key, entity);
/*     */       
/*  72 */       new OnUpdateVisitor(source, id).process(entity, persister);
/*     */       
/*  74 */       Object version = persister.getVersion(entity, source.getEntityMode());
/*     */       
/*  76 */       entityEntry = persistenceContext.addEntity(entity, Status.MANAGED, persister.getPropertyValues(entity, source.getEntityMode()), key, version, LockMode.NONE, true, persister, false, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */       log.trace("deleting a persistent instance");
/*     */       
/*  92 */       if ((entityEntry.getStatus() == Status.DELETED) || (entityEntry.getStatus() == Status.GONE)) {
/*  93 */         log.trace("object was already deleted");
/*  94 */         return;
/*     */       }
/*  96 */       persister = entityEntry.getPersister();
/*  97 */       id = entityEntry.getId();
/*  98 */       version = entityEntry.getVersion();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 108 */     if (invokeDeleteLifecycle(source, entity, persister)) { return;
/*     */     }
/* 110 */     deleteEntity(source, entity, entityEntry, event.isCascadeDeleteEnabled(), persister);
/*     */     
/* 112 */     if (source.getFactory().getSettings().isIdentifierRollbackEnabled()) {
/* 113 */       persister.resetIdentifier(entity, id, version, source.getEntityMode());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void deleteEntity(EventSource session, Object entity, EntityEntry entityEntry, boolean isCascadeDeleteEnabled, EntityPersister persister)
/*     */     throws HibernateException
/*     */   {
/* 126 */     if (log.isTraceEnabled()) {
/* 127 */       log.trace("deleting " + MessageHelper.infoString(persister, entityEntry.getId(), session.getFactory()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 133 */     PersistenceContext persistenceContext = session.getPersistenceContext();
/*     */     
/* 135 */     Type[] propTypes = persister.getPropertyTypes();
/*     */     
/* 137 */     Object version = entityEntry.getVersion();
/*     */     Object[] currentState;
/*     */     Object[] currentState;
/* 140 */     if (entityEntry.getLoadedState() == null) {
/* 141 */       currentState = persister.getPropertyValues(entity, session.getEntityMode());
/*     */     }
/*     */     else {
/* 144 */       currentState = entityEntry.getLoadedState();
/*     */     }
/*     */     
/* 147 */     Object[] deletedState = new Object[propTypes.length];
/* 148 */     TypeFactory.deepCopy(currentState, propTypes, persister.getPropertyUpdateability(), deletedState, session);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 155 */     entityEntry.setDeletedState(deletedState);
/*     */     
/* 157 */     session.getInterceptor().onDelete(entity, entityEntry.getId(), deletedState, persister.getPropertyNames(), propTypes);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 166 */     persistenceContext.setEntryStatus(entityEntry, Status.DELETED);
/* 167 */     EntityKey key = new EntityKey(entityEntry.getId(), persister, session.getEntityMode());
/*     */     
/* 169 */     cascadeBeforeDelete(session, persister, entity, entityEntry);
/*     */     
/* 171 */     new ForeignKeys.Nullifier(entity, true, false, session).nullifyTransientReferences(entityEntry.getDeletedState(), propTypes);
/*     */     
/* 173 */     new Nullability(session).checkNullability(entityEntry.getDeletedState(), persister, true);
/* 174 */     persistenceContext.getNullifiableEntityKeys().add(key);
/*     */     
/*     */ 
/* 177 */     session.getActionQueue().addAction(new EntityDeleteAction(entityEntry.getId(), deletedState, version, entity, persister, isCascadeDeleteEnabled, session));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 189 */     cascadeAfterDelete(session, persister, entity);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean invokeDeleteLifecycle(EventSource session, Object entity, EntityPersister persister)
/*     */   {
/* 199 */     if (persister.implementsLifecycle(session.getEntityMode())) {
/* 200 */       log.debug("calling onDelete()");
/* 201 */       if (((Lifecycle)entity).onDelete(session)) {
/* 202 */         log.debug("deletion vetoed by onDelete()");
/* 203 */         return true;
/*     */       }
/*     */     }
/* 206 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void cascadeBeforeDelete(EventSource session, EntityPersister persister, Object entity, EntityEntry entityEntry)
/*     */     throws HibernateException
/*     */   {
/* 215 */     CacheMode cacheMode = session.getCacheMode();
/* 216 */     session.setCacheMode(CacheMode.GET);
/* 217 */     session.getPersistenceContext().incrementCascadeLevel();
/*     */     try
/*     */     {
/* 220 */       new Cascade(CascadingAction.DELETE, 1, session).cascade(persister, entity);
/*     */     }
/*     */     finally
/*     */     {
/* 224 */       session.getPersistenceContext().decrementCascadeLevel();
/* 225 */       session.setCacheMode(cacheMode);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void cascadeAfterDelete(EventSource session, EntityPersister persister, Object entity)
/*     */     throws HibernateException
/*     */   {
/* 234 */     CacheMode cacheMode = session.getCacheMode();
/* 235 */     session.setCacheMode(CacheMode.GET);
/* 236 */     session.getPersistenceContext().incrementCascadeLevel();
/*     */     try
/*     */     {
/* 239 */       new Cascade(CascadingAction.DELETE, 2, session).cascade(persister, entity);
/*     */     }
/*     */     finally
/*     */     {
/* 243 */       session.getPersistenceContext().decrementCascadeLevel();
/* 244 */       session.setCacheMode(cacheMode);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DefaultDeleteEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */