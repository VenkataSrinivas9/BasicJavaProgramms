/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.collection.PersistentCollection;
/*    */ import org.hibernate.engine.PersistenceContext;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.event.EventSource;
/*    */ import org.hibernate.persister.collection.CollectionPersister;
/*    */ import org.hibernate.type.CollectionType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OnReplicateVisitor
/*    */   extends ReattachVisitor
/*    */ {
/*    */   private boolean isUpdate;
/*    */   
/*    */   OnReplicateVisitor(EventSource session, Serializable key, boolean isUpdate)
/*    */   {
/* 28 */     super(session, key);
/* 29 */     this.isUpdate = isUpdate;
/*    */   }
/*    */   
/*    */   Object processCollection(Object collection, CollectionType type)
/*    */     throws HibernateException
/*    */   {
/* 35 */     if (collection == CollectionType.UNFETCHED_COLLECTION) { return null;
/*    */     }
/* 37 */     EventSource session = getSession();
/* 38 */     Serializable key = getKey();
/* 39 */     CollectionPersister persister = session.getFactory().getCollectionPersister(type.getRole());
/*    */     
/* 41 */     if (this.isUpdate) removeCollection(persister, key, session);
/* 42 */     if ((collection != null) && ((collection instanceof PersistentCollection))) {
/* 43 */       PersistentCollection wrapper = (PersistentCollection)collection;
/* 44 */       wrapper.setCurrentSession(session);
/* 45 */       if (wrapper.wasInitialized()) {
/* 46 */         session.getPersistenceContext().addNewCollection(persister, wrapper);
/*    */       }
/*    */       else {
/* 49 */         reattachCollection(wrapper, type);
/*    */       }
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 59 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\OnReplicateVisitor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */