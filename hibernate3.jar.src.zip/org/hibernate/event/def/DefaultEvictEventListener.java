/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.engine.Cascade;
/*    */ import org.hibernate.engine.CascadingAction;
/*    */ import org.hibernate.engine.EntityEntry;
/*    */ import org.hibernate.engine.EntityKey;
/*    */ import org.hibernate.engine.PersistenceContext;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.event.EventSource;
/*    */ import org.hibernate.event.EvictEvent;
/*    */ import org.hibernate.event.EvictEventListener;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ import org.hibernate.pretty.MessageHelper;
/*    */ import org.hibernate.proxy.HibernateProxy;
/*    */ import org.hibernate.proxy.LazyInitializer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultEvictEventListener
/*    */   implements EvictEventListener
/*    */ {
/* 32 */   private static final Log log = LogFactory.getLog(DefaultEvictEventListener.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void onEvict(EvictEvent event)
/*    */     throws HibernateException
/*    */   {
/* 41 */     EventSource source = event.getSession();
/* 42 */     Object object = event.getObject();
/*    */     
/* 44 */     PersistenceContext persistenceContext = source.getPersistenceContext();
/* 45 */     if ((object instanceof HibernateProxy))
/*    */     {
/* 47 */       LazyInitializer li = ((HibernateProxy)object).getHibernateLazyInitializer();
/* 48 */       Serializable id = li.getIdentifier();
/* 49 */       EntityPersister persister = source.getFactory().getEntityPersister(li.getEntityName());
/* 50 */       if (id == null) {
/* 51 */         throw new IllegalArgumentException("null identifier");
/*    */       }
/*    */       
/* 54 */       EntityKey key = new EntityKey(id, persister, source.getEntityMode());
/* 55 */       persistenceContext.removeProxy(key);
/*    */       
/* 57 */       if (!li.isUninitialized()) {
/* 58 */         Object entity = persistenceContext.removeEntity(key);
/* 59 */         if (entity != null) {
/* 60 */           EntityEntry e = event.getSession().getPersistenceContext().removeEntry(entity);
/* 61 */           doEvict(entity, key, e.getPersister(), event.getSession());
/*    */         }
/*    */         
/*    */       }
/*    */     }
/*    */     else
/*    */     {
/* 68 */       EntityEntry e = persistenceContext.removeEntry(object);
/* 69 */       if (e != null) {
/* 70 */         EntityKey key = new EntityKey(e.getId(), e.getPersister(), source.getEntityMode());
/* 71 */         persistenceContext.removeEntity(key);
/* 72 */         doEvict(object, key, e.getPersister(), source);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void doEvict(Object object, EntityKey key, EntityPersister persister, EventSource session)
/*    */     throws HibernateException
/*    */   {
/* 85 */     if (log.isTraceEnabled()) {
/* 86 */       log.trace("evicting " + MessageHelper.infoString(persister));
/*    */     }
/*    */     
/*    */ 
/* 90 */     if (persister.hasCollections()) { new EvictVisitor(session).process(object, persister);
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 98 */     new Cascade(CascadingAction.EVICT, 0, session).cascade(persister, object);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DefaultEvictEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */