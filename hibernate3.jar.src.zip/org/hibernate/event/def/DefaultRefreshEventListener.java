/*     */ package org.hibernate.event.def;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.PersistentObjectException;
/*     */ import org.hibernate.UnresolvableObjectException;
/*     */ import org.hibernate.cache.CacheConcurrencyStrategy;
/*     */ import org.hibernate.cache.CacheKey;
/*     */ import org.hibernate.engine.Cascade;
/*     */ import org.hibernate.engine.CascadingAction;
/*     */ import org.hibernate.engine.EntityEntry;
/*     */ import org.hibernate.engine.EntityKey;
/*     */ import org.hibernate.engine.PersistenceContext;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.event.EventSource;
/*     */ import org.hibernate.event.RefreshEvent;
/*     */ import org.hibernate.event.RefreshEventListener;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.pretty.MessageHelper;
/*     */ import org.hibernate.type.AbstractComponentType;
/*     */ import org.hibernate.type.CollectionType;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.IdentityMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultRefreshEventListener
/*     */   implements RefreshEventListener
/*     */ {
/*  36 */   private static final Log log = LogFactory.getLog(DefaultRefreshEventListener.class);
/*     */   
/*     */   public void onRefresh(RefreshEvent event) throws HibernateException {
/*  39 */     onRefresh(event, IdentityMap.instantiate(10));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onRefresh(RefreshEvent event, Map refreshedAlready)
/*     */     throws HibernateException
/*     */   {
/*  50 */     EventSource source = event.getSession();
/*     */     
/*  52 */     if (source.getPersistenceContext().reassociateIfUninitializedProxy(event.getObject())) { return;
/*     */     }
/*  54 */     Object object = source.getPersistenceContext().unproxyAndReassociate(event.getObject());
/*     */     
/*  56 */     if (refreshedAlready.containsKey(object)) {
/*  57 */       log.trace("already refreshed");
/*  58 */       return;
/*     */     }
/*     */     
/*  61 */     EntityEntry e = source.getPersistenceContext().getEntry(object);
/*     */     
/*     */     EntityPersister persister;
/*     */     Serializable id;
/*  65 */     if (e == null) {
/*  66 */       EntityPersister persister = source.getEntityPersister(null, object);
/*  67 */       Serializable id = persister.getIdentifier(object, event.getSession().getEntityMode());
/*  68 */       if (log.isTraceEnabled()) {
/*  69 */         log.trace("refreshing transient " + MessageHelper.infoString(persister, id, source.getFactory()));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*  74 */       EntityKey key = new EntityKey(id, persister, source.getEntityMode());
/*  75 */       if (source.getPersistenceContext().getEntry(key) != null) {
/*  76 */         throw new PersistentObjectException("attempted to refresh transient instance when persistent instance was already associated with the Session: " + MessageHelper.infoString(persister, id, source.getFactory()));
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*  83 */       if (log.isTraceEnabled()) {
/*  84 */         log.trace("refreshing " + MessageHelper.infoString(e.getPersister(), e.getId(), source.getFactory()));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*  89 */       if (!e.isExistsInDatabase()) {
/*  90 */         throw new HibernateException("this instance does not yet exist as a row in the database");
/*     */       }
/*     */       
/*  93 */       persister = e.getPersister();
/*  94 */       id = e.getId();
/*     */     }
/*     */     
/*     */ 
/*  98 */     refreshedAlready.put(object, object);
/*  99 */     new Cascade(CascadingAction.REFRESH, 0, source).cascade(persister, object, refreshedAlready);
/*     */     
/*     */ 
/* 102 */     if (e != null) {
/* 103 */       EntityKey key = new EntityKey(id, persister, source.getEntityMode());
/* 104 */       source.getPersistenceContext().removeEntity(key);
/* 105 */       if (persister.hasCollections()) { new EvictVisitor(source).process(object, persister);
/*     */       }
/*     */     }
/* 108 */     if (persister.hasCache()) {
/* 109 */       CacheKey ck = new CacheKey(id, persister.getIdentifierType(), persister.getRootEntityName(), source.getEntityMode(), source.getFactory());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 116 */       persister.getCache().remove(ck);
/*     */     }
/*     */     
/* 119 */     evictCachedCollections(persister, id, source.getFactory());
/*     */     
/* 121 */     String previousFetchProfile = source.getFetchProfile();
/* 122 */     source.setFetchProfile("refresh");
/* 123 */     Object result = persister.load(id, object, event.getLockMode(), source);
/* 124 */     source.setFetchProfile(previousFetchProfile);
/*     */     
/* 126 */     UnresolvableObjectException.throwIfNull(result, id, persister.getEntityName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void evictCachedCollections(EntityPersister persister, Serializable id, SessionFactoryImplementor factory)
/*     */     throws HibernateException
/*     */   {
/* 135 */     evictCachedCollections(persister.getPropertyTypes(), id, factory);
/*     */   }
/*     */   
/*     */   private void evictCachedCollections(Type[] types, Serializable id, SessionFactoryImplementor factory) throws HibernateException
/*     */   {
/* 140 */     for (int i = 0; i < types.length; i++) {
/* 141 */       if (types[i].isCollectionType()) {
/* 142 */         factory.evictCollection(((CollectionType)types[i]).getRole(), id);
/*     */       }
/* 144 */       else if (types[i].isComponentType()) {
/* 145 */         AbstractComponentType actype = (AbstractComponentType)types[i];
/* 146 */         evictCachedCollections(actype.getSubtypes(), id, factory);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DefaultRefreshEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */