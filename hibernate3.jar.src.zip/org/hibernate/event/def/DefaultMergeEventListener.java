/*     */ package org.hibernate.event.def;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ import net.sf.cglib.transform.impl.InterceptFieldEnabled;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.ObjectDeletedException;
/*     */ import org.hibernate.StaleObjectStateException;
/*     */ import org.hibernate.WrongClassException;
/*     */ import org.hibernate.engine.Cascade;
/*     */ import org.hibernate.engine.CascadingAction;
/*     */ import org.hibernate.engine.PersistenceContext;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.event.EventSource;
/*     */ import org.hibernate.event.MergeEvent;
/*     */ import org.hibernate.event.MergeEventListener;
/*     */ import org.hibernate.intercept.FieldInterceptor;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.proxy.HibernateProxy;
/*     */ import org.hibernate.proxy.LazyInitializer;
/*     */ import org.hibernate.stat.Statistics;
/*     */ import org.hibernate.stat.StatisticsImplementor;
/*     */ import org.hibernate.type.ForeignKeyDirection;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.type.TypeFactory;
/*     */ import org.hibernate.type.VersionType;
/*     */ import org.hibernate.util.IdentityMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultMergeEventListener
/*     */   extends AbstractSaveEventListener
/*     */   implements MergeEventListener
/*     */ {
/*  39 */   private static final Log log = LogFactory.getLog(DefaultMergeEventListener.class);
/*     */   
/*     */   protected Map getMergeMap(Object anything) {
/*  42 */     return IdentityMap.invert((Map)anything);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onMerge(MergeEvent event)
/*     */     throws HibernateException
/*     */   {
/*  52 */     onMerge(event, IdentityMap.instantiate(10));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onMerge(MergeEvent event, Map copyCache)
/*     */     throws HibernateException
/*     */   {
/*  63 */     EventSource source = event.getSession();
/*  64 */     Object original = event.getOriginal();
/*     */     
/*  66 */     if (original != null) {
/*     */       Object entity;
/*     */       Object entity;
/*  69 */       if ((original instanceof HibernateProxy)) {
/*  70 */         LazyInitializer li = ((HibernateProxy)original).getHibernateLazyInitializer();
/*  71 */         if (li.isUninitialized()) {
/*  72 */           log.trace("ignoring uninitialized proxy");
/*  73 */           event.setResult(source.load(li.getEntityName(), li.getIdentifier()));
/*  74 */           return;
/*     */         }
/*     */         
/*  77 */         entity = li.getImplementation();
/*     */       }
/*     */       else
/*     */       {
/*  81 */         entity = original;
/*     */       }
/*     */       
/*  84 */       if (copyCache.containsKey(entity)) {
/*  85 */         log.trace("already merged");
/*  86 */         event.setResult(entity);
/*     */       }
/*     */       else {
/*  89 */         event.setEntity(entity);
/*     */         
/*  91 */         int entityState = getEntityState(entity, event.getEntityName(), source.getPersistenceContext().getEntry(entity), source);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  98 */         switch (entityState) {
/*     */         case 2: 
/* 100 */           entityIsDetached(event, copyCache);
/* 101 */           break;
/*     */         case 1: 
/* 103 */           entityIsTransient(event, copyCache);
/* 104 */           break;
/*     */         case 0: 
/* 106 */           entityIsPersistent(event, copyCache);
/* 107 */           break;
/*     */         default: 
/* 109 */           throw new ObjectDeletedException("deleted instance passed to merge", null, getLoggableName(event.getEntityName(), entity));
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void entityIsPersistent(MergeEvent event, Map copyCache)
/*     */   {
/* 122 */     log.trace("ignoring persistent instance");
/*     */     
/*     */ 
/*     */ 
/* 126 */     Object entity = event.getEntity();
/* 127 */     EventSource source = event.getSession();
/* 128 */     EntityPersister persister = source.getEntityPersister(event.getEntityName(), entity);
/*     */     
/* 130 */     copyCache.put(entity, entity);
/*     */     
/* 132 */     cascadeOnMerge(source, persister, entity, copyCache);
/* 133 */     copyValues(persister, entity, entity, source, copyCache);
/*     */     
/* 135 */     event.setResult(entity);
/*     */   }
/*     */   
/*     */   protected void entityIsTransient(MergeEvent event, Map copyCache)
/*     */   {
/* 140 */     log.trace("merging transient instance");
/*     */     
/* 142 */     Object entity = event.getEntity();
/* 143 */     EventSource source = event.getSession();
/*     */     
/* 145 */     EntityPersister persister = source.getEntityPersister(event.getEntityName(), entity);
/* 146 */     String entityName = persister.getEntityName();
/*     */     
/* 148 */     Serializable id = persister.hasIdentifierProperty() ? persister.getIdentifier(entity, source.getEntityMode()) : null;
/*     */     
/*     */ 
/*     */ 
/* 152 */     Object copy = persister.instantiate(id, source.getEntityMode());
/* 153 */     copyCache.put(entity, copy);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 158 */     super.cascadeBeforeSave(source, persister, entity, copyCache);
/* 159 */     copyValues(persister, entity, copy, source, copyCache, ForeignKeyDirection.FOREIGN_KEY_FROM_PARENT);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 164 */     Serializable requestedId = event.getRequestedId();
/* 165 */     if (requestedId == null) {
/* 166 */       saveWithGeneratedId(copy, entityName, copyCache, source);
/*     */     }
/*     */     else {
/* 169 */       saveWithRequestedId(copy, requestedId, entityName, copyCache, source);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 174 */     super.cascadeAfterSave(source, persister, entity, copyCache);
/* 175 */     copyValues(persister, entity, copy, source, copyCache, ForeignKeyDirection.FOREIGN_KEY_TO_PARENT);
/*     */     
/* 177 */     event.setResult(copy);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void entityIsDetached(MergeEvent event, Map copyCache)
/*     */   {
/* 183 */     log.trace("merging detached instance");
/*     */     
/* 185 */     Object entity = event.getEntity();
/* 186 */     EventSource source = event.getSession();
/*     */     
/* 188 */     EntityPersister persister = source.getEntityPersister(event.getEntityName(), entity);
/* 189 */     String entityName = persister.getEntityName();
/*     */     
/* 191 */     Serializable id = event.getRequestedId();
/* 192 */     if (id == null) {
/* 193 */       id = persister.getIdentifier(entity, source.getEntityMode());
/*     */     }
/*     */     else
/*     */     {
/* 197 */       Serializable entityId = persister.getIdentifier(entity, source.getEntityMode());
/* 198 */       if (!persister.getIdentifierType().isEqual(id, entityId, source.getEntityMode(), source.getFactory())) {
/* 199 */         throw new HibernateException("merge requested with id not matching id of passed entity");
/*     */       }
/*     */     }
/*     */     
/* 203 */     String previousFetchProfile = source.getFetchProfile();
/* 204 */     source.setFetchProfile("merge");
/*     */     
/*     */ 
/* 207 */     Serializable clonedIdentifier = (Serializable)persister.getIdentifierType().deepCopy(id, source.getEntityMode(), source.getFactory());
/*     */     
/* 209 */     Object result = source.get(entityName, clonedIdentifier);
/* 210 */     source.setFetchProfile(previousFetchProfile);
/*     */     
/* 212 */     if (result == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 220 */       entityIsTransient(event, copyCache);
/*     */     }
/*     */     else {
/* 223 */       copyCache.put(entity, result);
/*     */       
/* 225 */       Object target = source.getPersistenceContext().unproxy(result);
/* 226 */       if (target == entity) {
/* 227 */         throw new AssertionFailure("entity was not detached");
/*     */       }
/* 229 */       if (!source.getEntityName(target).equals(entityName)) {
/* 230 */         throw new WrongClassException("class of the given object did not match class of persistent copy", event.getRequestedId(), entityName);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 236 */       if (isVersionChanged(entity, source, persister, target)) {
/* 237 */         if (source.getFactory().getStatistics().isStatisticsEnabled()) {
/* 238 */           source.getFactory().getStatisticsImplementor().optimisticFailure(entityName);
/*     */         }
/*     */         
/* 241 */         throw new StaleObjectStateException(entityName, event.getRequestedId());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 246 */       cascadeOnMerge(source, persister, entity, copyCache);
/* 247 */       copyValues(persister, entity, target, source, copyCache);
/*     */       
/*     */ 
/* 250 */       markInterceptorDirty(entity, target);
/*     */       
/* 252 */       event.setResult(result);
/*     */     }
/*     */   }
/*     */   
/*     */   private void markInterceptorDirty(Object entity, Object target)
/*     */   {
/* 258 */     if ((entity instanceof InterceptFieldEnabled)) {
/* 259 */       FieldInterceptor fieldInterceptor = FieldInterceptor.getFieldInterceptor(target);
/* 260 */       if (fieldInterceptor != null) fieldInterceptor.dirty();
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isVersionChanged(Object entity, EventSource source, EntityPersister persister, Object target) {
/* 265 */     return (persister.isVersioned()) && (!persister.getVersionType().isSame(persister.getVersion(target, source.getEntityMode()), persister.getVersion(entity, source.getEntityMode()), source.getEntityMode()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void copyValues(EntityPersister persister, Object entity, Object target, SessionImplementor source, Map copyCache)
/*     */   {
/* 281 */     Object[] copiedValues = TypeFactory.replace(persister.getPropertyValues(entity, source.getEntityMode()), persister.getPropertyValues(target, source.getEntityMode()), persister.getPropertyTypes(), source, target, copyCache);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 290 */     persister.setPropertyValues(target, copiedValues, source.getEntityMode());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void copyValues(EntityPersister persister, Object entity, Object target, SessionImplementor source, Map copyCache, ForeignKeyDirection foreignKeyDirection)
/*     */   {
/* 302 */     Object[] copiedValues = TypeFactory.replace(persister.getPropertyValues(entity, source.getEntityMode()), persister.getPropertyValues(target, source.getEntityMode()), persister.getPropertyTypes(), source, target, copyCache, foreignKeyDirection);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 312 */     persister.setPropertyValues(target, copiedValues, source.getEntityMode());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void cascadeOnMerge(EventSource source, EntityPersister persister, Object entity, Map copyCache)
/*     */   {
/* 329 */     source.getPersistenceContext().incrementCascadeLevel();
/*     */     try {
/* 331 */       new Cascade(getCascadeAction(), 0, source).cascade(persister, entity, copyCache);
/*     */     }
/*     */     finally
/*     */     {
/* 335 */       source.getPersistenceContext().decrementCascadeLevel();
/*     */     }
/*     */   }
/*     */   
/*     */   protected CascadingAction getCascadeAction()
/*     */   {
/* 341 */     return CascadingAction.MERGE;
/*     */   }
/*     */   
/*     */   protected Boolean getAssumedUnsaved() {
/* 345 */     return Boolean.FALSE;
/*     */   }
/*     */   
/*     */   protected void cascadeAfterSave(EventSource source, EntityPersister persister, Object entity, Object anything)
/*     */     throws HibernateException
/*     */   {}
/*     */   
/*     */   protected void cascadeBeforeSave(EventSource source, EntityPersister persister, Object entity, Object anything)
/*     */     throws HibernateException
/*     */   {}
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DefaultMergeEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */