/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.collection.PersistentCollection;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.event.EventSource;
/*    */ import org.hibernate.persister.collection.CollectionPersister;
/*    */ import org.hibernate.type.CollectionType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OnLockVisitor
/*    */   extends ReattachVisitor
/*    */ {
/*    */   public OnLockVisitor(EventSource session, Serializable key)
/*    */   {
/* 25 */     super(session, key);
/*    */   }
/*    */   
/*    */   Object processCollection(Object collection, CollectionType type)
/*    */     throws HibernateException
/*    */   {
/* 31 */     SessionImplementor session = getSession();
/* 32 */     CollectionPersister persister = session.getFactory().getCollectionPersister(type.getRole());
/*    */     
/* 34 */     if (collection != null)
/*    */     {
/*    */ 
/* 37 */       if ((collection instanceof PersistentCollection)) {
/* 38 */         PersistentCollection persistentCollection = (PersistentCollection)collection;
/*    */         
/* 40 */         if (persistentCollection.setCurrentSession(session))
/*    */         {
/* 42 */           if (isOwnerUnchanged(persistentCollection, persister, getKey()))
/*    */           {
/* 44 */             if (persistentCollection.isDirty()) {
/* 45 */               throw new HibernateException("reassociated object has dirty collection");
/*    */             }
/* 47 */             reattachCollection(persistentCollection, type);
/*    */           }
/*    */           else
/*    */           {
/* 51 */             throw new HibernateException("reassociated object has dirty collection reference");
/*    */ 
/*    */           }
/*    */           
/*    */ 
/*    */         }
/*    */         else
/*    */         {
/* 59 */           throw new HibernateException("reassociated object has dirty collection reference");
/*    */         }
/*    */         
/*    */ 
/*    */       }
/*    */       else
/*    */       {
/* 66 */         throw new HibernateException("reassociated object has dirty collection reference (or an array)");
/*    */       }
/*    */     }
/* 69 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\OnLockVisitor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */