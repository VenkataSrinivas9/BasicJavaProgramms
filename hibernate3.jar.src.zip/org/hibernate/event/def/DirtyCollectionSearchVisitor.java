/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.collection.PersistentCollection;
/*    */ import org.hibernate.engine.PersistenceContext;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.event.EventSource;
/*    */ import org.hibernate.type.CollectionType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DirtyCollectionSearchVisitor
/*    */   extends AbstractVisitor
/*    */ {
/* 20 */   private boolean dirty = false;
/*    */   private boolean[] propertyVersionability;
/*    */   
/*    */   DirtyCollectionSearchVisitor(EventSource session, boolean[] propertyVersionability) {
/* 24 */     super(session);
/* 25 */     this.propertyVersionability = propertyVersionability;
/*    */   }
/*    */   
/*    */   boolean wasDirtyCollectionFound() {
/* 29 */     return this.dirty;
/*    */   }
/*    */   
/*    */   Object processCollection(Object collection, CollectionType type)
/*    */     throws HibernateException
/*    */   {
/* 35 */     if (collection != null)
/*    */     {
/* 37 */       SessionImplementor session = getSession();
/*    */       PersistentCollection persistentCollection;
/*    */       PersistentCollection persistentCollection;
/* 40 */       if (type.isArrayType()) {
/* 41 */         persistentCollection = session.getPersistenceContext().getCollectionHolder(collection);
/*    */ 
/*    */ 
/*    */ 
/*    */       }
/*    */       else
/*    */       {
/*    */ 
/*    */ 
/*    */ 
/* 51 */         persistentCollection = (PersistentCollection)collection;
/*    */       }
/*    */       
/* 54 */       if (persistentCollection.isDirty()) {
/* 55 */         this.dirty = true;
/* 56 */         return null;
/*    */       }
/*    */     }
/*    */     
/* 60 */     return null;
/*    */   }
/*    */   
/*    */   boolean includeEntityProperty(Object[] values, int i) {
/* 64 */     return (this.propertyVersionability[i] != 0) && (super.includeEntityProperty(values, i));
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DirtyCollectionSearchVisitor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */