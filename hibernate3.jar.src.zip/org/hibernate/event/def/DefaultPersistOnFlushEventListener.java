/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import org.hibernate.engine.CascadingAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultPersistOnFlushEventListener
/*    */   extends DefaultPersistEventListener
/*    */ {
/*    */   protected CascadingAction getCascadeAction()
/*    */   {
/* 12 */     return CascadingAction.PERSIST_ON_FLUSH;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\DefaultPersistOnFlushEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */