/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.collection.PersistentCollection;
/*    */ import org.hibernate.engine.Collections;
/*    */ import org.hibernate.engine.PersistenceContext;
/*    */ import org.hibernate.event.EventSource;
/*    */ import org.hibernate.type.CollectionType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlushVisitor
/*    */   extends AbstractVisitor
/*    */ {
/*    */   private Object owner;
/*    */   
/*    */   Object processCollection(Object collection, CollectionType type)
/*    */     throws HibernateException
/*    */   {
/* 24 */     if (collection == CollectionType.UNFETCHED_COLLECTION) {
/* 25 */       return null;
/*    */     }
/*    */     
/* 28 */     if (collection != null) { PersistentCollection coll;
/*    */       PersistentCollection coll;
/* 30 */       if (type.hasHolder(getSession().getEntityMode())) {
/* 31 */         coll = getSession().getPersistenceContext().getCollectionHolder(collection);
/*    */       }
/*    */       else {
/* 34 */         coll = (PersistentCollection)collection;
/*    */       }
/*    */       
/* 37 */       Collections.processReachableCollection(coll, type, this.owner, getSession());
/*    */     }
/*    */     
/* 40 */     return null;
/*    */   }
/*    */   
/*    */   FlushVisitor(EventSource session, Object owner)
/*    */   {
/* 45 */     super(session);
/* 46 */     this.owner = owner;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\FlushVisitor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */