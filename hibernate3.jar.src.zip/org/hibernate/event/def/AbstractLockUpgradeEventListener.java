/*    */ package org.hibernate.event.def;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.LockMode;
/*    */ import org.hibernate.ObjectDeletedException;
/*    */ import org.hibernate.cache.CacheConcurrencyStrategy;
/*    */ import org.hibernate.cache.CacheConcurrencyStrategy.SoftLock;
/*    */ import org.hibernate.cache.CacheKey;
/*    */ import org.hibernate.engine.EntityEntry;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.engine.Status;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ import org.hibernate.pretty.MessageHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AbstractLockUpgradeEventListener
/*    */   extends AbstractReassociateEventListener
/*    */ {
/* 26 */   private static final Log log = LogFactory.getLog(AbstractLockUpgradeEventListener.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void upgradeLock(Object object, EntityEntry entry, LockMode requestedLockMode, SessionImplementor source)
/*    */     throws HibernateException
/*    */   {
/* 40 */     if (requestedLockMode.greaterThan(entry.getLockMode()))
/*    */     {
/* 42 */       if (entry.getStatus() != Status.MANAGED) {
/* 43 */         throw new ObjectDeletedException("attempted to lock a deleted instance", entry.getId(), entry.getPersister().getEntityName());
/*    */       }
/*    */       
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 50 */       EntityPersister persister = entry.getPersister();
/*    */       
/* 52 */       if (log.isTraceEnabled()) {
/* 53 */         log.trace("locking " + MessageHelper.infoString(persister, entry.getId(), source.getFactory()) + " in mode: " + requestedLockMode);
/*    */       }
/*    */       
/*    */       CacheConcurrencyStrategy.SoftLock lock;
/*    */       
/*    */       CacheKey ck;
/*    */       
/*    */       CacheConcurrencyStrategy.SoftLock lock;
/*    */       
/* 62 */       if (persister.hasCache()) {
/* 63 */         CacheKey ck = new CacheKey(entry.getId(), persister.getIdentifierType(), persister.getRootEntityName(), source.getEntityMode(), source.getFactory());
/*    */         
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 70 */         lock = persister.getCache().lock(ck, entry.getVersion());
/*    */       }
/*    */       else {
/* 73 */         ck = null;
/* 74 */         lock = null;
/*    */       }
/*    */       try
/*    */       {
/* 78 */         persister.lock(entry.getId(), entry.getVersion(), object, requestedLockMode, source);
/* 79 */         entry.setLockMode(requestedLockMode);
/*    */ 
/*    */       }
/*    */       finally
/*    */       {
/* 84 */         if (persister.hasCache()) {
/* 85 */           persister.getCache().release(ck, lock);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\def\AbstractLockUpgradeEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */