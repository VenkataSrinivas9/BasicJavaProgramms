/*    */ package org.hibernate.event;
/*    */ 
/*    */ import org.hibernate.ReplicationMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReplicateEvent
/*    */   extends AbstractEvent
/*    */ {
/*    */   private Object object;
/*    */   private ReplicationMode replicationMode;
/*    */   private String entityName;
/*    */   
/*    */   public ReplicateEvent(Object object, ReplicationMode replicationMode, EventSource source)
/*    */   {
/* 18 */     this(null, object, replicationMode, source);
/*    */   }
/*    */   
/*    */   public ReplicateEvent(String entityName, Object object, ReplicationMode replicationMode, EventSource source) {
/* 22 */     super(source);
/* 23 */     this.entityName = entityName;
/*    */     
/* 25 */     if (object == null) {
/* 26 */       throw new IllegalArgumentException("attempt to create replication strategy with null entity");
/*    */     }
/*    */     
/*    */ 
/* 30 */     if (replicationMode == null) {
/* 31 */       throw new IllegalArgumentException("attempt to create replication strategy with null replication mode");
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 36 */     this.object = object;
/* 37 */     this.replicationMode = replicationMode;
/*    */   }
/*    */   
/*    */   public Object getObject() {
/* 41 */     return this.object;
/*    */   }
/*    */   
/*    */   public void setObject(Object object) {
/* 45 */     this.object = object;
/*    */   }
/*    */   
/*    */   public ReplicationMode getReplicationMode() {
/* 49 */     return this.replicationMode;
/*    */   }
/*    */   
/*    */   public void setReplicationMode(ReplicationMode replicationMode) {
/* 53 */     this.replicationMode = replicationMode;
/*    */   }
/*    */   
/*    */   public String getEntityName() {
/* 57 */     return this.entityName;
/*    */   }
/*    */   
/* 60 */   public void setEntityName(String entityName) { this.entityName = entityName; }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\ReplicateEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */