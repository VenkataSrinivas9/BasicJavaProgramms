/*    */ package org.hibernate.event;
/*    */ 
/*    */ import org.hibernate.LockMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LockEvent
/*    */   extends AbstractEvent
/*    */ {
/*    */   private Object object;
/*    */   private LockMode lockMode;
/*    */   private String entityName;
/*    */   
/*    */   public LockEvent(String entityName, Object original, LockMode lockMode, EventSource source)
/*    */   {
/* 18 */     this(original, lockMode, source);
/* 19 */     this.entityName = entityName;
/*    */   }
/*    */   
/*    */   public LockEvent(Object object, LockMode lockMode, EventSource source) {
/* 23 */     super(source);
/* 24 */     this.object = object;
/* 25 */     this.lockMode = lockMode;
/*    */   }
/*    */   
/*    */   public Object getObject() {
/* 29 */     return this.object;
/*    */   }
/*    */   
/*    */   public void setObject(Object object) {
/* 33 */     this.object = object;
/*    */   }
/*    */   
/*    */   public LockMode getLockMode() {
/* 37 */     return this.lockMode;
/*    */   }
/*    */   
/*    */   public void setLockMode(LockMode lockMode) {
/* 41 */     this.lockMode = lockMode;
/*    */   }
/*    */   
/*    */   public String getEntityName() {
/* 45 */     return this.entityName;
/*    */   }
/*    */   
/*    */   public void setEntityName(String entityName) {
/* 49 */     this.entityName = entityName;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\LockEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */