/*    */ package org.hibernate.event;
/*    */ 
/*    */ import org.hibernate.collection.PersistentCollection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InitializeCollectionEvent
/*    */   extends AbstractEvent
/*    */ {
/*    */   private final PersistentCollection collection;
/*    */   
/*    */   public InitializeCollectionEvent(PersistentCollection collection, EventSource source)
/*    */   {
/* 33 */     super(source);
/*    */     
/* 35 */     this.collection = collection;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public PersistentCollection getCollection()
/*    */   {
/* 43 */     return this.collection;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\InitializeCollectionEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */