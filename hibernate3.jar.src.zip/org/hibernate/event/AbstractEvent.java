/*    */ package org.hibernate.event;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractEvent
/*    */   implements Serializable
/*    */ {
/*    */   private final EventSource session;
/*    */   
/*    */   public AbstractEvent(EventSource source)
/*    */   {
/* 22 */     this.session = source;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public final EventSource getSession()
/*    */   {
/* 32 */     return this.session;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\AbstractEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */