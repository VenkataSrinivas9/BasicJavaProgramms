/*     */ package org.hibernate.event;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.cfg.Configuration;
/*     */ import org.hibernate.event.def.DefaultAutoFlushEventListener;
/*     */ import org.hibernate.event.def.DefaultDeleteEventListener;
/*     */ import org.hibernate.event.def.DefaultDirtyCheckEventListener;
/*     */ import org.hibernate.event.def.DefaultEvictEventListener;
/*     */ import org.hibernate.event.def.DefaultFlushEntityEventListener;
/*     */ import org.hibernate.event.def.DefaultFlushEventListener;
/*     */ import org.hibernate.event.def.DefaultInitializeCollectionEventListener;
/*     */ import org.hibernate.event.def.DefaultLoadEventListener;
/*     */ import org.hibernate.event.def.DefaultLockEventListener;
/*     */ import org.hibernate.event.def.DefaultMergeEventListener;
/*     */ import org.hibernate.event.def.DefaultPersistEventListener;
/*     */ import org.hibernate.event.def.DefaultPersistOnFlushEventListener;
/*     */ import org.hibernate.event.def.DefaultPostLoadEventListener;
/*     */ import org.hibernate.event.def.DefaultPreLoadEventListener;
/*     */ import org.hibernate.event.def.DefaultRefreshEventListener;
/*     */ import org.hibernate.event.def.DefaultReplicateEventListener;
/*     */ import org.hibernate.event.def.DefaultSaveEventListener;
/*     */ import org.hibernate.event.def.DefaultSaveOrUpdateCopyEventListener;
/*     */ import org.hibernate.event.def.DefaultSaveOrUpdateEventListener;
/*     */ import org.hibernate.event.def.DefaultUpdateEventListener;
/*     */ import org.hibernate.util.Cloneable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EventListeners
/*     */   extends Cloneable
/*     */   implements Serializable
/*     */ {
/*  42 */   private LoadEventListener[] loadEventListeners = { new DefaultLoadEventListener() };
/*  43 */   private SaveOrUpdateEventListener[] saveOrUpdateEventListeners = { new DefaultSaveOrUpdateEventListener() };
/*  44 */   private MergeEventListener[] mergeEventListeners = { new DefaultMergeEventListener() };
/*  45 */   private PersistEventListener[] persistEventListeners = { new DefaultPersistEventListener() };
/*  46 */   private PersistEventListener[] persistOnFlushEventListeners = { new DefaultPersistOnFlushEventListener() };
/*  47 */   private ReplicateEventListener[] replicateEventListeners = { new DefaultReplicateEventListener() };
/*  48 */   private DeleteEventListener[] deleteEventListeners = { new DefaultDeleteEventListener() };
/*  49 */   private AutoFlushEventListener[] autoFlushEventListeners = { new DefaultAutoFlushEventListener() };
/*  50 */   private DirtyCheckEventListener[] dirtyCheckEventListeners = { new DefaultDirtyCheckEventListener() };
/*  51 */   private FlushEventListener[] flushEventListeners = { new DefaultFlushEventListener() };
/*  52 */   private EvictEventListener[] evictEventListeners = { new DefaultEvictEventListener() };
/*  53 */   private LockEventListener[] lockEventListeners = { new DefaultLockEventListener() };
/*  54 */   private RefreshEventListener[] refreshEventListeners = { new DefaultRefreshEventListener() };
/*  55 */   private FlushEntityEventListener[] flushEntityEventListeners = { new DefaultFlushEntityEventListener() };
/*  56 */   private InitializeCollectionEventListener[] initializeCollectionEventListeners = { new DefaultInitializeCollectionEventListener() };
/*     */   
/*     */ 
/*  59 */   private PostLoadEventListener[] postLoadEventListeners = { new DefaultPostLoadEventListener() };
/*  60 */   private PreLoadEventListener[] preLoadEventListeners = { new DefaultPreLoadEventListener() };
/*     */   
/*  62 */   private PreDeleteEventListener[] preDeleteEventListeners = new PreDeleteEventListener[0];
/*  63 */   private PreUpdateEventListener[] preUpdateEventListeners = new PreUpdateEventListener[0];
/*  64 */   private PreInsertEventListener[] preInsertEventListeners = new PreInsertEventListener[0];
/*  65 */   private PostDeleteEventListener[] postDeleteEventListeners = new PostDeleteEventListener[0];
/*  66 */   private PostUpdateEventListener[] postUpdateEventListeners = new PostUpdateEventListener[0];
/*  67 */   private PostInsertEventListener[] postInsertEventListeners = new PostInsertEventListener[0];
/*  68 */   private PostDeleteEventListener[] postCommitDeleteEventListeners = new PostDeleteEventListener[0];
/*  69 */   private PostUpdateEventListener[] postCommitUpdateEventListeners = new PostUpdateEventListener[0];
/*  70 */   private PostInsertEventListener[] postCommitInsertEventListeners = new PostInsertEventListener[0];
/*     */   
/*  72 */   private SaveOrUpdateEventListener[] saveEventListeners = { new DefaultSaveEventListener() };
/*  73 */   private SaveOrUpdateEventListener[] updateEventListeners = { new DefaultUpdateEventListener() };
/*  74 */   private MergeEventListener[] saveOrUpdateCopyEventListeners = { new DefaultSaveOrUpdateCopyEventListener() };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  81 */     eventInterfaceFromType.put("auto-flush", AutoFlushEventListener.class);
/*  82 */     eventInterfaceFromType.put("merge", MergeEventListener.class);
/*  83 */     eventInterfaceFromType.put("create", PersistEventListener.class);
/*  84 */     eventInterfaceFromType.put("create-onflush", PersistEventListener.class);
/*  85 */     eventInterfaceFromType.put("delete", DeleteEventListener.class);
/*  86 */     eventInterfaceFromType.put("dirty-check", DirtyCheckEventListener.class);
/*  87 */     eventInterfaceFromType.put("evict", EvictEventListener.class);
/*  88 */     eventInterfaceFromType.put("flush", FlushEventListener.class);
/*  89 */     eventInterfaceFromType.put("flush-entity", FlushEntityEventListener.class);
/*  90 */     eventInterfaceFromType.put("load", LoadEventListener.class);
/*  91 */     eventInterfaceFromType.put("load-collection", InitializeCollectionEventListener.class);
/*  92 */     eventInterfaceFromType.put("lock", LockEventListener.class);
/*  93 */     eventInterfaceFromType.put("refresh", RefreshEventListener.class);
/*  94 */     eventInterfaceFromType.put("replicate", ReplicateEventListener.class);
/*  95 */     eventInterfaceFromType.put("save-update", SaveOrUpdateEventListener.class);
/*  96 */     eventInterfaceFromType.put("save", SaveOrUpdateEventListener.class);
/*  97 */     eventInterfaceFromType.put("update", SaveOrUpdateEventListener.class);
/*  98 */     eventInterfaceFromType.put("pre-load", PreLoadEventListener.class);
/*  99 */     eventInterfaceFromType.put("pre-update", PreUpdateEventListener.class);
/* 100 */     eventInterfaceFromType.put("pre-delete", PreDeleteEventListener.class);
/* 101 */     eventInterfaceFromType.put("pre-insert", PreInsertEventListener.class);
/* 102 */     eventInterfaceFromType.put("post-load", PostLoadEventListener.class);
/* 103 */     eventInterfaceFromType.put("post-update", PostUpdateEventListener.class);
/* 104 */     eventInterfaceFromType.put("post-delete", PostDeleteEventListener.class);
/* 105 */     eventInterfaceFromType.put("post-insert", PostInsertEventListener.class);
/* 106 */     eventInterfaceFromType.put("post-commit-update", PostUpdateEventListener.class);
/* 107 */     eventInterfaceFromType.put("post-commit-delete", PostDeleteEventListener.class);
/* 108 */     eventInterfaceFromType.put("post-commit-insert", PostInsertEventListener.class); }
/* 109 */   private static Map eventInterfaceFromType = Collections.unmodifiableMap(eventInterfaceFromType);
/*     */   
/*     */   public Class getListenerClassFor(String type)
/*     */   {
/* 113 */     Class clazz = (Class)eventInterfaceFromType.get(type);
/*     */     
/* 115 */     if (clazz == null) {
/* 116 */       throw new MappingException("Unrecognized listener type [" + type + "]");
/*     */     }
/*     */     
/* 119 */     return clazz;
/*     */   }
/*     */   
/*     */   public LoadEventListener[] getLoadEventListeners() {
/* 123 */     return this.loadEventListeners;
/*     */   }
/*     */   
/*     */   public void setLoadEventListeners(LoadEventListener[] loadEventListener) {
/* 127 */     this.loadEventListeners = loadEventListener;
/*     */   }
/*     */   
/*     */   public ReplicateEventListener[] getReplicateEventListeners() {
/* 131 */     return this.replicateEventListeners;
/*     */   }
/*     */   
/*     */   public void setReplicateEventListeners(ReplicateEventListener[] replicateEventListener) {
/* 135 */     this.replicateEventListeners = replicateEventListener;
/*     */   }
/*     */   
/*     */   public DeleteEventListener[] getDeleteEventListeners() {
/* 139 */     return this.deleteEventListeners;
/*     */   }
/*     */   
/*     */   public void setDeleteEventListeners(DeleteEventListener[] deleteEventListener) {
/* 143 */     this.deleteEventListeners = deleteEventListener;
/*     */   }
/*     */   
/*     */   public AutoFlushEventListener[] getAutoFlushEventListeners() {
/* 147 */     return this.autoFlushEventListeners;
/*     */   }
/*     */   
/*     */   public void setAutoFlushEventListeners(AutoFlushEventListener[] autoFlushEventListener) {
/* 151 */     this.autoFlushEventListeners = autoFlushEventListener;
/*     */   }
/*     */   
/*     */   public DirtyCheckEventListener[] getDirtyCheckEventListeners() {
/* 155 */     return this.dirtyCheckEventListeners;
/*     */   }
/*     */   
/*     */   public void setDirtyCheckEventListeners(DirtyCheckEventListener[] dirtyCheckEventListener) {
/* 159 */     this.dirtyCheckEventListeners = dirtyCheckEventListener;
/*     */   }
/*     */   
/*     */   public FlushEventListener[] getFlushEventListeners() {
/* 163 */     return this.flushEventListeners;
/*     */   }
/*     */   
/*     */   public void setFlushEventListeners(FlushEventListener[] flushEventListener) {
/* 167 */     this.flushEventListeners = flushEventListener;
/*     */   }
/*     */   
/*     */   public EvictEventListener[] getEvictEventListeners() {
/* 171 */     return this.evictEventListeners;
/*     */   }
/*     */   
/*     */   public void setEvictEventListeners(EvictEventListener[] evictEventListener) {
/* 175 */     this.evictEventListeners = evictEventListener;
/*     */   }
/*     */   
/*     */   public LockEventListener[] getLockEventListeners() {
/* 179 */     return this.lockEventListeners;
/*     */   }
/*     */   
/*     */   public void setLockEventListeners(LockEventListener[] lockEventListener) {
/* 183 */     this.lockEventListeners = lockEventListener;
/*     */   }
/*     */   
/*     */   public RefreshEventListener[] getRefreshEventListeners() {
/* 187 */     return this.refreshEventListeners;
/*     */   }
/*     */   
/*     */   public void setRefreshEventListeners(RefreshEventListener[] refreshEventListener) {
/* 191 */     this.refreshEventListeners = refreshEventListener;
/*     */   }
/*     */   
/*     */   public InitializeCollectionEventListener[] getInitializeCollectionEventListeners() {
/* 195 */     return this.initializeCollectionEventListeners;
/*     */   }
/*     */   
/*     */   public void setInitializeCollectionEventListeners(InitializeCollectionEventListener[] initializeCollectionEventListener) {
/* 199 */     this.initializeCollectionEventListeners = initializeCollectionEventListener;
/*     */   }
/*     */   
/*     */   public FlushEntityEventListener[] getFlushEntityEventListeners() {
/* 203 */     return this.flushEntityEventListeners;
/*     */   }
/*     */   
/*     */   public void setFlushEntityEventListeners(FlushEntityEventListener[] flushEntityEventListener) {
/* 207 */     this.flushEntityEventListeners = flushEntityEventListener;
/*     */   }
/*     */   
/*     */   public SaveOrUpdateEventListener[] getSaveOrUpdateEventListeners() {
/* 211 */     return this.saveOrUpdateEventListeners;
/*     */   }
/*     */   
/*     */   public void setSaveOrUpdateEventListeners(SaveOrUpdateEventListener[] saveOrUpdateEventListener) {
/* 215 */     this.saveOrUpdateEventListeners = saveOrUpdateEventListener;
/*     */   }
/*     */   
/*     */   public MergeEventListener[] getMergeEventListeners() {
/* 219 */     return this.mergeEventListeners;
/*     */   }
/*     */   
/*     */   public void setMergeEventListeners(MergeEventListener[] mergeEventListener) {
/* 223 */     this.mergeEventListeners = mergeEventListener;
/*     */   }
/*     */   
/*     */   public PersistEventListener[] getPersistEventListeners() {
/* 227 */     return this.persistEventListeners;
/*     */   }
/*     */   
/*     */   public void setPersistEventListeners(PersistEventListener[] createEventListener) {
/* 231 */     this.persistEventListeners = createEventListener;
/*     */   }
/*     */   
/*     */   public PersistEventListener[] getPersistOnFlushEventListeners() {
/* 235 */     return this.persistOnFlushEventListeners;
/*     */   }
/*     */   
/*     */   public void setPersistOnFlushEventListeners(PersistEventListener[] createEventListener) {
/* 239 */     this.persistOnFlushEventListeners = createEventListener;
/*     */   }
/*     */   
/*     */   public MergeEventListener[] getSaveOrUpdateCopyEventListeners() {
/* 243 */     return this.saveOrUpdateCopyEventListeners;
/*     */   }
/*     */   
/*     */   public void setSaveOrUpdateCopyEventListeners(MergeEventListener[] saveOrUpdateCopyEventListener) {
/* 247 */     this.saveOrUpdateCopyEventListeners = saveOrUpdateCopyEventListener;
/*     */   }
/*     */   
/*     */   public SaveOrUpdateEventListener[] getSaveEventListeners() {
/* 251 */     return this.saveEventListeners;
/*     */   }
/*     */   
/*     */   public void setSaveEventListeners(SaveOrUpdateEventListener[] saveEventListener) {
/* 255 */     this.saveEventListeners = saveEventListener;
/*     */   }
/*     */   
/*     */   public SaveOrUpdateEventListener[] getUpdateEventListeners() {
/* 259 */     return this.updateEventListeners;
/*     */   }
/*     */   
/*     */   public void setUpdateEventListeners(SaveOrUpdateEventListener[] updateEventListener) {
/* 263 */     this.updateEventListeners = updateEventListener;
/*     */   }
/*     */   
/*     */   public PostLoadEventListener[] getPostLoadEventListeners() {
/* 267 */     return this.postLoadEventListeners;
/*     */   }
/*     */   
/*     */   public void setPostLoadEventListeners(PostLoadEventListener[] postLoadEventListener) {
/* 271 */     this.postLoadEventListeners = postLoadEventListener;
/*     */   }
/*     */   
/*     */   public PreLoadEventListener[] getPreLoadEventListeners() {
/* 275 */     return this.preLoadEventListeners;
/*     */   }
/*     */   
/*     */   public void setPreLoadEventListeners(PreLoadEventListener[] preLoadEventListener) {
/* 279 */     this.preLoadEventListeners = preLoadEventListener;
/*     */   }
/*     */   
/*     */   public PostDeleteEventListener[] getPostDeleteEventListeners() {
/* 283 */     return this.postDeleteEventListeners;
/*     */   }
/*     */   
/*     */   public PostInsertEventListener[] getPostInsertEventListeners() {
/* 287 */     return this.postInsertEventListeners;
/*     */   }
/*     */   
/*     */   public PostUpdateEventListener[] getPostUpdateEventListeners() {
/* 291 */     return this.postUpdateEventListeners;
/*     */   }
/*     */   
/*     */   public void setPostDeleteEventListeners(PostDeleteEventListener[] postDeleteEventListener) {
/* 295 */     this.postDeleteEventListeners = postDeleteEventListener;
/*     */   }
/*     */   
/*     */   public void setPostInsertEventListeners(PostInsertEventListener[] postInsertEventListener) {
/* 299 */     this.postInsertEventListeners = postInsertEventListener;
/*     */   }
/*     */   
/*     */   public void setPostUpdateEventListeners(PostUpdateEventListener[] postUpdateEventListener) {
/* 303 */     this.postUpdateEventListeners = postUpdateEventListener;
/*     */   }
/*     */   
/*     */   public PreDeleteEventListener[] getPreDeleteEventListeners() {
/* 307 */     return this.preDeleteEventListeners;
/*     */   }
/*     */   
/*     */   public void setPreDeleteEventListeners(PreDeleteEventListener[] preDeleteEventListener) {
/* 311 */     this.preDeleteEventListeners = preDeleteEventListener;
/*     */   }
/*     */   
/*     */   public PreInsertEventListener[] getPreInsertEventListeners() {
/* 315 */     return this.preInsertEventListeners;
/*     */   }
/*     */   
/*     */   public void setPreInsertEventListeners(PreInsertEventListener[] preInsertEventListener) {
/* 319 */     this.preInsertEventListeners = preInsertEventListener;
/*     */   }
/*     */   
/*     */   public PreUpdateEventListener[] getPreUpdateEventListeners() {
/* 323 */     return this.preUpdateEventListeners;
/*     */   }
/*     */   
/*     */   public void setPreUpdateEventListeners(PreUpdateEventListener[] preUpdateEventListener) {
/* 327 */     this.preUpdateEventListeners = preUpdateEventListener;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initializeListeners(Configuration cfg)
/*     */   {
/* 336 */     Field[] fields = getClass().getDeclaredFields();
/* 337 */     for (int i = 0; i < fields.length; i++)
/*     */     {
/*     */       try {
/* 340 */         Object listener = fields[i].get(this);
/* 341 */         Object[] listeners; if ((listener instanceof Object[])) {
/* 342 */           listeners = (Object[])listener;
/*     */         } else {
/*     */           continue;
/*     */         }
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */         Object[] listeners;
/* 350 */         throw new AssertionFailure("could not init listeners"); }
/*     */       Object[] listeners;
/* 352 */       int length = listeners.length;
/* 353 */       for (int index = 0; index < length; index++) {
/* 354 */         Object listener = listeners[index];
/* 355 */         if ((listener instanceof Initializable)) {
/* 356 */           ((Initializable)listener).initialize(cfg);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public PostDeleteEventListener[] getPostCommitDeleteEventListeners()
/*     */   {
/* 364 */     return this.postCommitDeleteEventListeners;
/*     */   }
/*     */   
/*     */   public void setPostCommitDeleteEventListeners(PostDeleteEventListener[] postCommitDeleteEventListeners)
/*     */   {
/* 369 */     this.postCommitDeleteEventListeners = postCommitDeleteEventListeners;
/*     */   }
/*     */   
/*     */   public PostInsertEventListener[] getPostCommitInsertEventListeners() {
/* 373 */     return this.postCommitInsertEventListeners;
/*     */   }
/*     */   
/*     */   public void setPostCommitInsertEventListeners(PostInsertEventListener[] postCommitInsertEventListeners)
/*     */   {
/* 378 */     this.postCommitInsertEventListeners = postCommitInsertEventListeners;
/*     */   }
/*     */   
/*     */   public PostUpdateEventListener[] getPostCommitUpdateEventListeners() {
/* 382 */     return this.postCommitUpdateEventListeners;
/*     */   }
/*     */   
/*     */   public void setPostCommitUpdateEventListeners(PostUpdateEventListener[] postCommitUpdateEventListeners)
/*     */   {
/* 387 */     this.postCommitUpdateEventListeners = postCommitUpdateEventListeners;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\EventListeners.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */