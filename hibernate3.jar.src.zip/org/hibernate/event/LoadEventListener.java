/*     */ package org.hibernate.event;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.hibernate.HibernateException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface LoadEventListener
/*     */   extends Serializable
/*     */ {
/*  24 */   public static final LoadType RELOAD = LoadType.access$300(LoadType.access$200(LoadType.access$100(new LoadType("GET", null), false), false), true).setNakedEntityReturned(false);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  30 */   public static final LoadType GET = LoadType.access$300(LoadType.access$200(LoadType.access$100(new LoadType("GET", null), true), false), true).setNakedEntityReturned(false);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  36 */   public static final LoadType LOAD = LoadType.access$300(LoadType.access$200(LoadType.access$100(new LoadType("LOAD", null), false), true), true).setNakedEntityReturned(false);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  42 */   public static final LoadType IMMEDIATE_LOAD = LoadType.access$300(LoadType.access$200(LoadType.access$100(new LoadType("IMMEDIATE_LOAD", null), true), false), false).setNakedEntityReturned(true);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  48 */   public static final LoadType INTERNAL_LOAD_EAGER = LoadType.access$300(LoadType.access$200(LoadType.access$100(new LoadType("INTERNAL_LOAD_EAGER", null), false), false), false).setNakedEntityReturned(false);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  54 */   public static final LoadType INTERNAL_LOAD_LAZY = LoadType.access$300(LoadType.access$200(LoadType.access$100(new LoadType("INTERNAL_LOAD_LAZY", null), false), true), false).setNakedEntityReturned(false);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  60 */   public static final LoadType INTERNAL_LOAD_NULLABLE = LoadType.access$300(LoadType.access$200(LoadType.access$100(new LoadType("INTERNAL_LOAD_NULLABLE", null), true), false), false).setNakedEntityReturned(false);
/*     */   
/*     */   public abstract void onLoad(LoadEvent paramLoadEvent, LoadType paramLoadType) throws HibernateException;
/*     */   
/*     */   public static final class LoadType { private String name;
/*     */     
/*  66 */     LoadType(String x0, LoadEventListener.1 x1) { this(x0); }
/*     */     
/*     */ 
/*     */     private boolean nakedEntityReturned;
/*     */     private boolean allowNulls;
/*     */     private boolean checkDeleted;
/*     */     private boolean allowProxyCreation;
/*     */     private LoadType(String name)
/*     */     {
/*  75 */       this.name = name;
/*     */     }
/*     */     
/*     */     public boolean isAllowNulls() {
/*  79 */       return this.allowNulls;
/*     */     }
/*     */     
/*     */     private LoadType setAllowNulls(boolean allowNulls) {
/*  83 */       this.allowNulls = allowNulls;
/*  84 */       return this;
/*     */     }
/*     */     
/*     */     public boolean isNakedEntityReturned() {
/*  88 */       return this.nakedEntityReturned;
/*     */     }
/*     */     
/*     */     private LoadType setNakedEntityReturned(boolean immediateLoad) {
/*  92 */       this.nakedEntityReturned = immediateLoad;
/*  93 */       return this;
/*     */     }
/*     */     
/*     */     public boolean isCheckDeleted() {
/*  97 */       return this.checkDeleted;
/*     */     }
/*     */     
/*     */     private LoadType setCheckDeleted(boolean checkDeleted) {
/* 101 */       this.checkDeleted = checkDeleted;
/* 102 */       return this;
/*     */     }
/*     */     
/*     */     public boolean isAllowProxyCreation() {
/* 106 */       return this.allowProxyCreation;
/*     */     }
/*     */     
/*     */     private LoadType setAllowProxyCreation(boolean allowProxyCreation) {
/* 110 */       this.allowProxyCreation = allowProxyCreation;
/* 111 */       return this;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 115 */       return this.name;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 119 */       return this.name;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\LoadEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */