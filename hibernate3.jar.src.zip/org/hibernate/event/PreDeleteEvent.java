/*    */ package org.hibernate.event;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PreDeleteEvent
/*    */ {
/*    */   private Object entity;
/*    */   private EntityPersister persister;
/*    */   private Serializable id;
/*    */   private Object[] deletedState;
/*    */   
/*    */   public Object getEntity()
/*    */   {
/* 20 */     return this.entity;
/*    */   }
/*    */   
/* 23 */   public Serializable getId() { return this.id; }
/*    */   
/*    */   public EntityPersister getPersister() {
/* 26 */     return this.persister;
/*    */   }
/*    */   
/* 29 */   public Object[] getDeletedState() { return this.deletedState; }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PreDeleteEvent(Object entity, Serializable id, Object[] deletedState, EntityPersister persister)
/*    */   {
/* 38 */     this.entity = entity;
/* 39 */     this.persister = persister;
/* 40 */     this.id = id;
/* 41 */     this.deletedState = deletedState;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\PreDeleteEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */