/*    */ package org.hibernate.event;
/*    */ 
/*    */ import org.hibernate.LockMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RefreshEvent
/*    */   extends AbstractEvent
/*    */ {
/*    */   private Object object;
/* 14 */   private LockMode lockMode = LockMode.READ;
/*    */   
/*    */   public RefreshEvent(Object object, EventSource source) {
/* 17 */     super(source);
/* 18 */     if (object == null) {
/* 19 */       throw new IllegalArgumentException("Attempt to generate refresh event with null object");
/*    */     }
/* 21 */     this.object = object;
/*    */   }
/*    */   
/*    */   public RefreshEvent(Object object, LockMode lockMode, EventSource source) {
/* 25 */     this(object, source);
/* 26 */     if (lockMode == null) {
/* 27 */       throw new IllegalArgumentException("Attempt to generate refresh event with null lock mode");
/*    */     }
/*    */   }
/*    */   
/*    */   public Object getObject()
/*    */   {
/* 33 */     return this.object;
/*    */   }
/*    */   
/*    */   public LockMode getLockMode() {
/* 37 */     return this.lockMode;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\RefreshEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */