package org.hibernate.event;

import java.io.Serializable;

public abstract interface PreInsertEventListener
  extends Serializable
{
  public abstract boolean onPreInsert(PreInsertEvent paramPreInsertEvent);
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\PreInsertEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */