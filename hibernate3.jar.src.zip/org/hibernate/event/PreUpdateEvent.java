/*    */ package org.hibernate.event;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PreUpdateEvent
/*    */ {
/*    */   private Object entity;
/*    */   private EntityPersister persister;
/*    */   private Object[] state;
/*    */   private Object[] oldState;
/*    */   private Serializable id;
/*    */   private SessionImplementor source;
/*    */   
/*    */   public PreUpdateEvent(Object entity, Serializable id, Object[] state, Object[] oldState, EntityPersister persister, SessionImplementor source)
/*    */   {
/* 30 */     this.source = source;
/* 31 */     this.entity = entity;
/* 32 */     this.id = id;
/* 33 */     this.state = state;
/* 34 */     this.oldState = oldState;
/* 35 */     this.persister = persister;
/*    */   }
/*    */   
/*    */   public Object getEntity() {
/* 39 */     return this.entity;
/*    */   }
/*    */   
/* 42 */   public Serializable getId() { return this.id; }
/*    */   
/*    */   public Object[] getOldState() {
/* 45 */     return this.oldState;
/*    */   }
/*    */   
/* 48 */   public EntityPersister getPersister() { return this.persister; }
/*    */   
/*    */   public Object[] getState() {
/* 51 */     return this.state;
/*    */   }
/*    */   
/* 54 */   public SessionImplementor getSource() { return this.source; }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\PreUpdateEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */