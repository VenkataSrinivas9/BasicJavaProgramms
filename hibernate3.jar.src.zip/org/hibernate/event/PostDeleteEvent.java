/*    */ package org.hibernate.event;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PostDeleteEvent
/*    */ {
/*    */   private Object entity;
/*    */   private EntityPersister persister;
/*    */   private Serializable id;
/*    */   private Object[] deletedState;
/*    */   
/*    */   public PostDeleteEvent(Object entity, Serializable id, Object[] deletedState, EntityPersister persister)
/*    */   {
/* 25 */     this.entity = entity;
/* 26 */     this.id = id;
/* 27 */     this.persister = persister;
/* 28 */     this.deletedState = deletedState;
/*    */   }
/*    */   
/*    */   public Serializable getId() {
/* 32 */     return this.id;
/*    */   }
/*    */   
/* 35 */   public EntityPersister getPersister() { return this.persister; }
/*    */   
/*    */   public Object getEntity() {
/* 38 */     return this.entity;
/*    */   }
/*    */   
/* 41 */   public Object[] getDeletedState() { return this.deletedState; }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\PostDeleteEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */