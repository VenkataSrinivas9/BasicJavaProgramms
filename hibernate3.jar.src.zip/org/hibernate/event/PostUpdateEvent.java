/*    */ package org.hibernate.event;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PostUpdateEvent
/*    */ {
/*    */   private Object entity;
/*    */   private EntityPersister persister;
/*    */   private Object[] state;
/*    */   private Object[] oldState;
/*    */   private Serializable id;
/*    */   
/*    */   public PostUpdateEvent(Object entity, Serializable id, Object[] state, Object[] oldState, EntityPersister persister)
/*    */   {
/* 53 */     this.entity = entity;
/*    */     
/* 55 */     this.id = id;
/*    */     
/* 57 */     this.state = state;
/*    */     
/* 59 */     this.oldState = oldState;
/*    */     
/* 61 */     this.persister = persister;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object getEntity()
/*    */   {
/* 69 */     return this.entity;
/*    */   }
/*    */   
/*    */ 
/*    */   public Serializable getId()
/*    */   {
/* 75 */     return this.id;
/*    */   }
/*    */   
/*    */ 
/*    */   public Object[] getOldState()
/*    */   {
/* 81 */     return this.oldState;
/*    */   }
/*    */   
/*    */ 
/*    */   public EntityPersister getPersister()
/*    */   {
/* 87 */     return this.persister;
/*    */   }
/*    */   
/*    */ 
/*    */   public Object[] getState()
/*    */   {
/* 93 */     return this.state;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\PostUpdateEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */