package org.hibernate.event;

import java.io.Serializable;
import org.hibernate.HibernateException;

public abstract interface EvictEventListener
  extends Serializable
{
  public abstract void onEvict(EvictEvent paramEvictEvent)
    throws HibernateException;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\event\EvictEventListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */