/*     */ package org.hibernate.hql;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.hibernate.QueryException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HolderInstantiator
/*     */ {
/*     */   private final Constructor constructor;
/*     */   private final boolean returnMaps;
/*     */   private final boolean returnLists;
/*     */   private final String[] queryReturnAliases;
/*     */   
/*     */   public HolderInstantiator(Constructor constructor, boolean returnMaps, boolean returnLists, String[] queryReturnAliases)
/*     */   {
/*  57 */     this.constructor = constructor;
/*     */     
/*  59 */     this.returnLists = returnLists;
/*     */     
/*  61 */     this.returnMaps = returnMaps;
/*     */     
/*  63 */     this.queryReturnAliases = queryReturnAliases;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRequired()
/*     */   {
/*  71 */     return (this.constructor != null) || (this.returnLists) || (this.returnMaps);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object instantiate(Object[] row)
/*     */   {
/*  79 */     if (this.constructor != null)
/*     */     {
/*     */       try
/*     */       {
/*  83 */         return this.constructor.newInstance(row);
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */ 
/*  89 */         throw new QueryException("could not instantiate: " + this.constructor.getDeclaringClass().getName(), e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */     if (this.returnMaps)
/*     */     {
/* 103 */       Map map = new HashMap();
/*     */       
/* 105 */       for (int j = 0; j < row.length; j++)
/*     */       {
/* 107 */         map.put(this.queryReturnAliases[j], row[j]);
/*     */       }
/*     */       
/*     */ 
/* 111 */       return map;
/*     */     }
/*     */     
/*     */ 
/* 115 */     if (this.returnLists)
/*     */     {
/* 117 */       return Arrays.asList(row);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 123 */     return row;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\HolderInstantiator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */