/*     */ package org.hibernate.hql.classic;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.hql.CollectionProperties;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PreprocessingParser
/*     */   implements Parser
/*     */ {
/*  20 */   private static final Set HQL_OPERATORS = new HashSet();
/*  21 */   static { HQL_OPERATORS.add("<=");
/*  22 */     HQL_OPERATORS.add(">=");
/*  23 */     HQL_OPERATORS.add("=>");
/*  24 */     HQL_OPERATORS.add("=<");
/*  25 */     HQL_OPERATORS.add("!=");
/*  26 */     HQL_OPERATORS.add("<>");
/*  27 */     HQL_OPERATORS.add("!#");
/*  28 */     HQL_OPERATORS.add("!~");
/*  29 */     HQL_OPERATORS.add("!<");
/*  30 */     HQL_OPERATORS.add("!>");
/*  31 */     HQL_OPERATORS.add("is not");
/*  32 */     HQL_OPERATORS.add("not like");
/*  33 */     HQL_OPERATORS.add("not in");
/*  34 */     HQL_OPERATORS.add("not between");
/*  35 */     HQL_OPERATORS.add("not exists");
/*     */   }
/*     */   
/*     */   private Map replacements;
/*     */   private boolean quoted;
/*     */   private StringBuffer quotedString;
/*  41 */   private ClauseParser parser = new ClauseParser();
/*     */   private String lastToken;
/*     */   private String currentCollectionProp;
/*     */   
/*     */   public PreprocessingParser(Map replacements) {
/*  46 */     this.replacements = replacements;
/*     */   }
/*     */   
/*     */   public void token(String token, QueryTranslatorImpl q)
/*     */     throws QueryException
/*     */   {
/*  52 */     if (this.quoted) {
/*  53 */       this.quotedString.append(token);
/*     */     }
/*  55 */     if ("'".equals(token)) {
/*  56 */       if (this.quoted) {
/*  57 */         token = this.quotedString.toString();
/*     */       }
/*     */       else {
/*  60 */         this.quotedString = new StringBuffer(20).append(token);
/*     */       }
/*  62 */       this.quoted = (!this.quoted);
/*     */     }
/*  64 */     if (this.quoted) { return;
/*     */     }
/*     */     
/*  67 */     if (ParserHelper.isWhitespace(token)) { return;
/*     */     }
/*     */     
/*  70 */     String substoken = (String)this.replacements.get(token);
/*  71 */     token = substoken == null ? token : substoken;
/*     */     
/*     */ 
/*  74 */     if (this.currentCollectionProp != null) {
/*  75 */       if ("(".equals(token)) {
/*  76 */         return;
/*     */       }
/*  78 */       if (")".equals(token)) {
/*  79 */         this.currentCollectionProp = null;
/*  80 */         return;
/*     */       }
/*     */       
/*  83 */       token = StringHelper.qualify(token, this.currentCollectionProp);
/*     */     }
/*     */     else
/*     */     {
/*  87 */       String prop = CollectionProperties.getNormalizedPropertyName(token.toLowerCase());
/*  88 */       if (prop != null) {
/*  89 */         this.currentCollectionProp = prop;
/*  90 */         return;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  96 */     if (this.lastToken == null) {
/*  97 */       this.lastToken = token;
/*     */     }
/*     */     else {
/* 100 */       String doubleToken = this.lastToken + token;
/*     */       
/*     */ 
/* 103 */       if (HQL_OPERATORS.contains(doubleToken.toLowerCase())) {
/* 104 */         this.parser.token(doubleToken, q);
/* 105 */         this.lastToken = null;
/*     */       }
/*     */       else {
/* 108 */         this.parser.token(this.lastToken, q);
/* 109 */         this.lastToken = token;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void start(QueryTranslatorImpl q) throws QueryException
/*     */   {
/* 116 */     this.quoted = false;
/* 117 */     this.parser.start(q);
/*     */   }
/*     */   
/*     */   public void end(QueryTranslatorImpl q) throws QueryException {
/* 121 */     if (this.lastToken != null) this.parser.token(this.lastToken, q);
/* 122 */     this.parser.end(q);
/* 123 */     this.lastToken = null;
/* 124 */     this.currentCollectionProp = null;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\classic\PreprocessingParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */