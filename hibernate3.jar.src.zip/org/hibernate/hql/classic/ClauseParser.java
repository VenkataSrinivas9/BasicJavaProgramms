/*     */ package org.hibernate.hql.classic;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.hibernate.QueryException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClauseParser
/*     */   implements Parser
/*     */ {
/*     */   private Parser child;
/*     */   private List selectTokens;
/*  17 */   private boolean cacheSelectTokens = false;
/*  18 */   private boolean byExpected = false;
/*  19 */   private int parenCount = 0;
/*     */   
/*     */   public void token(String token, QueryTranslatorImpl q) throws QueryException {
/*  22 */     String lcToken = token.toLowerCase();
/*     */     
/*  24 */     if ("(".equals(token)) {
/*  25 */       this.parenCount += 1;
/*     */     }
/*  27 */     else if (")".equals(token)) {
/*  28 */       this.parenCount -= 1;
/*     */     }
/*     */     
/*  31 */     if ((this.byExpected) && (!lcToken.equals("by"))) {
/*  32 */       throw new QueryException("BY expected after GROUP or ORDER: " + token);
/*     */     }
/*     */     
/*  35 */     boolean isClauseStart = this.parenCount == 0;
/*     */     
/*  37 */     if (isClauseStart) {
/*  38 */       if (lcToken.equals("select")) {
/*  39 */         this.selectTokens = new ArrayList();
/*  40 */         this.cacheSelectTokens = true;
/*     */       }
/*  42 */       else if (lcToken.equals("from")) {
/*  43 */         this.child = new FromParser();
/*  44 */         this.child.start(q);
/*  45 */         this.cacheSelectTokens = false;
/*     */       }
/*  47 */       else if (lcToken.equals("where")) {
/*  48 */         endChild(q);
/*  49 */         this.child = new WhereParser();
/*  50 */         this.child.start(q);
/*     */       }
/*  52 */       else if (lcToken.equals("order")) {
/*  53 */         endChild(q);
/*  54 */         this.child = new OrderByParser();
/*  55 */         this.byExpected = true;
/*     */       }
/*  57 */       else if (lcToken.equals("having")) {
/*  58 */         endChild(q);
/*  59 */         this.child = new HavingParser();
/*  60 */         this.child.start(q);
/*     */       }
/*  62 */       else if (lcToken.equals("group")) {
/*  63 */         endChild(q);
/*  64 */         this.child = new GroupByParser();
/*  65 */         this.byExpected = true;
/*     */       }
/*  67 */       else if (lcToken.equals("by")) {
/*  68 */         if (!this.byExpected) throw new QueryException("GROUP or ORDER expected before BY");
/*  69 */         this.child.start(q);
/*  70 */         this.byExpected = false;
/*     */       }
/*     */       else {
/*  73 */         isClauseStart = false;
/*     */       }
/*     */     }
/*     */     
/*  77 */     if (!isClauseStart) {
/*  78 */       if (this.cacheSelectTokens) {
/*  79 */         this.selectTokens.add(token);
/*     */       }
/*     */       else {
/*  82 */         if (this.child == null) {
/*  83 */           throw new QueryException("query must begin with SELECT or FROM: " + token);
/*     */         }
/*     */         
/*  86 */         this.child.token(token, q);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void endChild(QueryTranslatorImpl q)
/*     */     throws QueryException
/*     */   {
/*  94 */     if (this.child == null)
/*     */     {
/*  96 */       this.cacheSelectTokens = false;
/*     */     }
/*     */     else {
/*  99 */       this.child.end(q);
/*     */     }
/*     */   }
/*     */   
/*     */   public void start(QueryTranslatorImpl q) {}
/*     */   
/*     */   public void end(QueryTranslatorImpl q) throws QueryException
/*     */   {
/* 107 */     endChild(q);
/* 108 */     if (this.selectTokens != null) {
/* 109 */       this.child = new SelectParser();
/* 110 */       this.child.start(q);
/* 111 */       Iterator iter = this.selectTokens.iterator();
/* 112 */       while (iter.hasNext()) {
/* 113 */         token((String)iter.next(), q);
/*     */       }
/* 115 */       this.child.end(q);
/*     */     }
/* 117 */     this.byExpected = false;
/* 118 */     this.parenCount = 0;
/* 119 */     this.cacheSelectTokens = false;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\classic\ClauseParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */