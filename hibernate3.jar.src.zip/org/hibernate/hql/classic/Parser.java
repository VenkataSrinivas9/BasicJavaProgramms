package org.hibernate.hql.classic;

import org.hibernate.QueryException;

public abstract interface Parser
{
  public abstract void token(String paramString, QueryTranslatorImpl paramQueryTranslatorImpl)
    throws QueryException;
  
  public abstract void start(QueryTranslatorImpl paramQueryTranslatorImpl)
    throws QueryException;
  
  public abstract void end(QueryTranslatorImpl paramQueryTranslatorImpl)
    throws QueryException;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\classic\Parser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */