/*     */ package org.hibernate.hql.classic;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.dialect.function.SQLFunction;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.hql.QuerySplitter;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.ReflectHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelectParser
/*     */   implements Parser
/*     */ {
/*  25 */   private static final Set COUNT_MODIFIERS = new HashSet();
/*     */   private LinkedList aggregateFuncTokenList;
/*     */   
/*  28 */   static { COUNT_MODIFIERS.add("distinct");
/*  29 */     COUNT_MODIFIERS.add("all");
/*  30 */     COUNT_MODIFIERS.add("*"); }
/*     */   
/*     */   private boolean ready;
/*  33 */   public SelectParser() { this.aggregateFuncTokenList = new LinkedList();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  47 */     this.pathExpressionParser = new SelectPathExpressionParser();
/*  48 */     this.aggregatePathExpressionParser = new PathExpressionParser();
/*     */     
/*  50 */     this.pathExpressionParser.setUseThetaStyleJoin(true);
/*  51 */     this.aggregatePathExpressionParser.setUseThetaStyleJoin(true);
/*     */   }
/*     */   
/*     */   private boolean aggregate;
/*     */   
/*  56 */   public void token(String token, QueryTranslatorImpl q) throws QueryException { String lctoken = token.toLowerCase();
/*     */     
/*  58 */     if (this.first) {
/*  59 */       this.first = false;
/*  60 */       if ("distinct".equals(lctoken)) {
/*  61 */         q.setDistinct(true);
/*  62 */         return;
/*     */       }
/*  64 */       if ("all".equals(lctoken)) {
/*  65 */         q.setDistinct(false);
/*  66 */         return;
/*     */       }
/*     */     }
/*     */     
/*  70 */     if (this.afterNew) {
/*  71 */       this.afterNew = false;
/*     */       try {
/*  73 */         this.holderClass = ReflectHelper.classForName(QuerySplitter.getImportedClass(token, q.getFactory()));
/*     */       }
/*     */       catch (ClassNotFoundException cnfe) {
/*  76 */         throw new QueryException(cnfe);
/*     */       }
/*  78 */       if (this.holderClass == null) throw new QueryException("class not found: " + token);
/*  79 */       q.setHolderClass(this.holderClass);
/*  80 */       this.insideNew = true;
/*     */     }
/*  82 */     else if (token.equals(",")) {
/*  83 */       if ((!this.aggregate) && (this.ready)) throw new QueryException("alias or expression expected in SELECT");
/*  84 */       q.appendScalarSelectToken(", ");
/*  85 */       this.ready = true;
/*     */     }
/*  87 */     else if ("new".equals(lctoken)) {
/*  88 */       this.afterNew = true;
/*  89 */       this.ready = false;
/*     */     }
/*  91 */     else if ("(".equals(token)) {
/*  92 */       if ((this.insideNew) && (!this.aggregate) && (!this.ready))
/*     */       {
/*  94 */         this.ready = true;
/*     */       }
/*  96 */       else if (this.aggregate) {
/*  97 */         q.appendScalarSelectToken(token);
/*     */       }
/*     */       else {
/* 100 */         throw new QueryException("aggregate function expected before ( in SELECT");
/*     */       }
/* 102 */       this.ready = true;
/*     */     }
/* 104 */     else if (")".equals(token)) {
/* 105 */       if ((this.insideNew) && (!this.aggregate) && (!this.ready))
/*     */       {
/* 107 */         this.insideNew = false;
/*     */       }
/* 109 */       else if ((this.aggregate) && (this.ready)) {
/* 110 */         q.appendScalarSelectToken(token);
/* 111 */         this.aggregateFuncTokenList.removeLast();
/* 112 */         if (this.aggregateFuncTokenList.size() < 1) {
/* 113 */           this.aggregate = false;
/* 114 */           this.ready = false;
/*     */         }
/*     */       }
/*     */       else {
/* 118 */         throw new QueryException("( expected before ) in select");
/*     */       }
/*     */     }
/* 121 */     else if (COUNT_MODIFIERS.contains(lctoken)) {
/* 122 */       if ((!this.ready) || (!this.aggregate)) throw new QueryException(token + " only allowed inside aggregate function in SELECT");
/* 123 */       q.appendScalarSelectToken(token);
/* 124 */       if ("*".equals(token)) q.addSelectScalar(Hibernate.INTEGER);
/*     */     }
/* 126 */     else if ((getFunction(lctoken, q) != null) && (token.equals(q.unalias(token))))
/*     */     {
/* 128 */       if (!this.ready) throw new QueryException(", expected before aggregate function in SELECT: " + token);
/* 129 */       this.aggregate = true;
/* 130 */       this.aggregateAddSelectScalar = true;
/* 131 */       this.aggregateFuncTokenList.add(lctoken);
/* 132 */       this.ready = false;
/* 133 */       q.appendScalarSelectToken(token);
/* 134 */       if (!aggregateHasArgs(lctoken, q)) {
/* 135 */         q.addSelectScalar(aggregateType(this.aggregateFuncTokenList, null, q));
/* 136 */         if (!aggregateFuncNoArgsHasParenthesis(lctoken, q)) {
/* 137 */           this.aggregateFuncTokenList.removeLast();
/* 138 */           if (this.aggregateFuncTokenList.size() < 1) {
/* 139 */             this.aggregate = false;
/* 140 */             this.ready = false;
/*     */           }
/*     */           else {
/* 143 */             this.ready = true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 148 */     else if (this.aggregate) {
/* 149 */       boolean constantToken = false;
/* 150 */       if (!this.ready) throw new QueryException("( expected after aggregate function in SELECT");
/*     */       try {
/* 152 */         ParserHelper.parse(this.aggregatePathExpressionParser, q.unalias(token), ".", q);
/*     */       }
/*     */       catch (QueryException qex) {
/* 155 */         constantToken = true;
/*     */       }
/*     */       
/* 158 */       if (constantToken) {
/* 159 */         q.appendScalarSelectToken(token);
/*     */       }
/*     */       else {
/* 162 */         if (this.aggregatePathExpressionParser.isCollectionValued()) {
/* 163 */           q.addCollection(this.aggregatePathExpressionParser.getCollectionName(), this.aggregatePathExpressionParser.getCollectionRole());
/*     */         }
/*     */         
/* 166 */         q.appendScalarSelectToken(this.aggregatePathExpressionParser.getWhereColumn());
/* 167 */         if (this.aggregateAddSelectScalar) {
/* 168 */           q.addSelectScalar(aggregateType(this.aggregateFuncTokenList, this.aggregatePathExpressionParser.getWhereColumnType(), q));
/* 169 */           this.aggregateAddSelectScalar = false;
/*     */         }
/* 171 */         this.aggregatePathExpressionParser.addAssociation(q);
/*     */       }
/*     */     }
/*     */     else {
/* 175 */       if (!this.ready) throw new QueryException(", expected in SELECT");
/* 176 */       ParserHelper.parse(this.pathExpressionParser, q.unalias(token), ".", q);
/* 177 */       if (this.pathExpressionParser.isCollectionValued()) {
/* 178 */         q.addCollection(this.pathExpressionParser.getCollectionName(), this.pathExpressionParser.getCollectionRole());
/*     */ 
/*     */       }
/* 181 */       else if (this.pathExpressionParser.getWhereColumnType().isEntityType()) {
/* 182 */         q.addSelectClass(this.pathExpressionParser.getSelectName());
/*     */       }
/* 184 */       q.appendScalarSelectTokens(this.pathExpressionParser.getWhereColumns());
/* 185 */       q.addSelectScalar(this.pathExpressionParser.getWhereColumnType());
/* 186 */       this.pathExpressionParser.addAssociation(q);
/*     */       
/* 188 */       this.ready = false; } }
/*     */   
/*     */   private boolean first;
/*     */   private boolean afterNew;
/*     */   
/* 193 */   public boolean aggregateHasArgs(String funcToken, QueryTranslatorImpl q) { return getFunction(funcToken, q).hasArguments(); }
/*     */   
/*     */   private boolean insideNew;
/*     */   
/* 197 */   public boolean aggregateFuncNoArgsHasParenthesis(String funcToken, QueryTranslatorImpl q) { return getFunction(funcToken, q).hasParenthesesIfNoArguments(); }
/*     */   
/*     */   private boolean aggregateAddSelectScalar;
/*     */   
/* 201 */   public Type aggregateType(List funcTokenList, Type type, QueryTranslatorImpl q) throws QueryException { Type retType = type;
/*     */     
/* 203 */     for (int i = funcTokenList.size() - 1; i >= 0; i--) {
/* 204 */       Type argType = retType;
/* 205 */       String funcToken = (String)funcTokenList.get(i);
/* 206 */       retType = getFunction(funcToken, q).getReturnType(argType, q.getFactory());
/*     */     }
/* 208 */     return retType; }
/*     */   
/*     */   private Class holderClass;
/*     */   
/* 212 */   private SQLFunction getFunction(String name, QueryTranslatorImpl q) { return (SQLFunction)q.getFactory().getDialect().getFunctions().get(name); }
/*     */   
/*     */   private final SelectPathExpressionParser pathExpressionParser;
/*     */   private final PathExpressionParser aggregatePathExpressionParser;
/* 216 */   public void start(QueryTranslatorImpl q) { this.ready = true;
/* 217 */     this.first = true;
/* 218 */     this.aggregate = false;
/* 219 */     this.afterNew = false;
/* 220 */     this.insideNew = false;
/* 221 */     this.holderClass = null;
/* 222 */     this.aggregateFuncTokenList.clear();
/*     */   }
/*     */   
/*     */   public void end(QueryTranslatorImpl q) {}
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\classic\SelectParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */