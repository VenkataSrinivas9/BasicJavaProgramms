/*     */ package org.hibernate.hql.classic;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.engine.JoinSequence;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.persister.collection.QueryableCollection;
/*     */ import org.hibernate.persister.entity.Queryable;
/*     */ import org.hibernate.sql.JoinFragment;
/*     */ import org.hibernate.type.EntityType;
/*     */ import org.hibernate.type.LiteralType;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.type.TypeFactory;
/*     */ import org.hibernate.util.ReflectHelper;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WhereParser
/*     */   implements Parser
/*     */ {
/*     */   private final PathExpressionParser pathExpressionParser;
/*  49 */   private static final Set EXPRESSION_TERMINATORS = new HashSet();
/*  50 */   private static final Set EXPRESSION_OPENERS = new HashSet();
/*  51 */   private static final Set BOOLEAN_OPERATORS = new HashSet();
/*  52 */   private static final Map NEGATIONS = new HashMap();
/*     */   private boolean betweenSpecialCase;
/*     */   
/*  55 */   static { EXPRESSION_TERMINATORS.add("and");
/*  56 */     EXPRESSION_TERMINATORS.add("or");
/*  57 */     EXPRESSION_TERMINATORS.add(")");
/*     */     
/*     */ 
/*  60 */     EXPRESSION_OPENERS.add("and");
/*  61 */     EXPRESSION_OPENERS.add("or");
/*  62 */     EXPRESSION_OPENERS.add("(");
/*     */     
/*     */ 
/*  65 */     BOOLEAN_OPERATORS.add("<");
/*  66 */     BOOLEAN_OPERATORS.add("=");
/*  67 */     BOOLEAN_OPERATORS.add(">");
/*  68 */     BOOLEAN_OPERATORS.add("#");
/*  69 */     BOOLEAN_OPERATORS.add("~");
/*  70 */     BOOLEAN_OPERATORS.add("like");
/*  71 */     BOOLEAN_OPERATORS.add("ilike");
/*  72 */     BOOLEAN_OPERATORS.add("regexp");
/*  73 */     BOOLEAN_OPERATORS.add("rlike");
/*  74 */     BOOLEAN_OPERATORS.add("is");
/*  75 */     BOOLEAN_OPERATORS.add("in");
/*  76 */     BOOLEAN_OPERATORS.add("any");
/*  77 */     BOOLEAN_OPERATORS.add("some");
/*  78 */     BOOLEAN_OPERATORS.add("all");
/*  79 */     BOOLEAN_OPERATORS.add("exists");
/*  80 */     BOOLEAN_OPERATORS.add("between");
/*  81 */     BOOLEAN_OPERATORS.add("<=");
/*  82 */     BOOLEAN_OPERATORS.add(">=");
/*  83 */     BOOLEAN_OPERATORS.add("=>");
/*  84 */     BOOLEAN_OPERATORS.add("=<");
/*  85 */     BOOLEAN_OPERATORS.add("!=");
/*  86 */     BOOLEAN_OPERATORS.add("<>");
/*  87 */     BOOLEAN_OPERATORS.add("!#");
/*  88 */     BOOLEAN_OPERATORS.add("!~");
/*  89 */     BOOLEAN_OPERATORS.add("!<");
/*  90 */     BOOLEAN_OPERATORS.add("!>");
/*  91 */     BOOLEAN_OPERATORS.add("is not");
/*  92 */     BOOLEAN_OPERATORS.add("not like");
/*  93 */     BOOLEAN_OPERATORS.add("not ilike");
/*  94 */     BOOLEAN_OPERATORS.add("not regexp");
/*  95 */     BOOLEAN_OPERATORS.add("not rlike");
/*  96 */     BOOLEAN_OPERATORS.add("not in");
/*  97 */     BOOLEAN_OPERATORS.add("not between");
/*  98 */     BOOLEAN_OPERATORS.add("not exists");
/*     */     
/* 100 */     NEGATIONS.put("and", "or");
/* 101 */     NEGATIONS.put("or", "and");
/* 102 */     NEGATIONS.put("<", ">=");
/* 103 */     NEGATIONS.put("=", "<>");
/* 104 */     NEGATIONS.put(">", "<=");
/* 105 */     NEGATIONS.put("#", "!#");
/* 106 */     NEGATIONS.put("~", "!~");
/* 107 */     NEGATIONS.put("like", "not like");
/* 108 */     NEGATIONS.put("ilike", "not ilike");
/* 109 */     NEGATIONS.put("regexp", "not regexp");
/* 110 */     NEGATIONS.put("rlike", "not rlike");
/* 111 */     NEGATIONS.put("is", "is not");
/* 112 */     NEGATIONS.put("in", "not in");
/* 113 */     NEGATIONS.put("exists", "not exists");
/* 114 */     NEGATIONS.put("between", "not between");
/* 115 */     NEGATIONS.put("<=", ">");
/* 116 */     NEGATIONS.put(">=", "<");
/* 117 */     NEGATIONS.put("=>", "<");
/* 118 */     NEGATIONS.put("=<", ">");
/* 119 */     NEGATIONS.put("!=", "=");
/* 120 */     NEGATIONS.put("<>", "=");
/* 121 */     NEGATIONS.put("!#", "#");
/* 122 */     NEGATIONS.put("!~", "~");
/* 123 */     NEGATIONS.put("!<", "<");
/* 124 */     NEGATIONS.put("!>", ">");
/* 125 */     NEGATIONS.put("is not", "is");
/* 126 */     NEGATIONS.put("not like", "like");
/* 127 */     NEGATIONS.put("not ilike", "ilike");
/* 128 */     NEGATIONS.put("not regexp", "regexp");
/* 129 */     NEGATIONS.put("not rlike", "rlike");
/* 130 */     NEGATIONS.put("not in", "in");
/* 131 */     NEGATIONS.put("not between", "between");
/* 132 */     NEGATIONS.put("not exists", "exists");
/*     */   }
/*     */   
/*     */   private boolean negated;
/*     */   private boolean inSubselect;
/*     */   private int bracketsSinceSelect;
/*     */   private StringBuffer subselect;
/*     */   public WhereParser()
/*     */   {
/*  45 */     this.pathExpressionParser = new PathExpressionParser();
/*  46 */     this.pathExpressionParser.setUseThetaStyleJoin(true);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 154 */     this.betweenSpecialCase = false;
/* 155 */     this.negated = false;
/*     */     
/* 157 */     this.inSubselect = false;
/* 158 */     this.bracketsSinceSelect = 0;
/*     */     
/*     */ 
/* 161 */     this.expectingPathContinuation = false;
/* 162 */     this.expectingIndex = 0;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 167 */     this.nots = new LinkedList();
/* 168 */     this.joins = new LinkedList();
/* 169 */     this.booleanTests = new LinkedList();
/*     */   }
/*     */   
/*     */   private String getElementName(PathExpressionParser.CollectionElement element, QueryTranslatorImpl q) throws QueryException { String name;
/* 173 */     if (element.isOneToMany) {
/* 174 */       name = element.alias;
/*     */     }
/*     */     else {
/* 177 */       Type type = element.elementType;
/* 178 */       String name; if (type.isEntityType()) {
/* 179 */         String entityName = ((EntityType)type).getAssociatedEntityName();
/* 180 */         name = this.pathExpressionParser.continueFromManyToMany(entityName, element.elementColumns, q);
/*     */       }
/*     */       else {
/* 183 */         throw new QueryException("illegally dereferenced collection element");
/*     */       } }
/*     */     String name;
/* 186 */     return name;
/*     */   }
/*     */   
/*     */   public void token(String token, QueryTranslatorImpl q) throws QueryException
/*     */   {
/* 191 */     String lcToken = token.toLowerCase();
/*     */     
/*     */ 
/* 194 */     if ((token.equals("[")) && (!this.expectingPathContinuation)) {
/* 195 */       this.expectingPathContinuation = false;
/* 196 */       if (this.expectingIndex == 0) throw new QueryException("unexpected [");
/* 197 */       return;
/*     */     }
/* 199 */     if (token.equals("]")) {
/* 200 */       this.expectingIndex -= 1;
/* 201 */       this.expectingPathContinuation = true;
/* 202 */       return;
/*     */     }
/*     */     
/*     */ 
/* 206 */     if (this.expectingPathContinuation) {
/* 207 */       boolean pathExpressionContinuesFurther = continuePathExpression(token, q);
/* 208 */       if (pathExpressionContinuesFurther) { return;
/*     */       }
/*     */     }
/*     */     
/* 212 */     if ((!this.inSubselect) && ((lcToken.equals("select")) || (lcToken.equals("from")))) {
/* 213 */       this.inSubselect = true;
/* 214 */       this.subselect = new StringBuffer(20);
/*     */     }
/* 216 */     if ((this.inSubselect) && (token.equals(")"))) {
/* 217 */       this.bracketsSinceSelect -= 1;
/*     */       
/* 219 */       if (this.bracketsSinceSelect == -1) {
/* 220 */         QueryTranslatorImpl subq = new QueryTranslatorImpl(this.subselect.toString(), q.getEnabledFilters(), q.getFactory());
/*     */         
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/* 226 */           subq.compile(q);
/*     */         }
/*     */         catch (MappingException me) {
/* 229 */           throw new QueryException("MappingException occurred compiling subquery", me);
/*     */         }
/* 231 */         appendToken(q, subq.getSQLString());
/* 232 */         this.inSubselect = false;
/* 233 */         this.bracketsSinceSelect = 0;
/*     */       }
/*     */     }
/* 236 */     if (this.inSubselect) {
/* 237 */       if (token.equals("(")) this.bracketsSinceSelect += 1;
/* 238 */       this.subselect.append(token).append(' ');
/* 239 */       return;
/*     */     }
/*     */     
/*     */ 
/* 243 */     specialCasesBefore(lcToken);
/*     */     
/*     */ 
/* 246 */     if ((!this.betweenSpecialCase) && (EXPRESSION_TERMINATORS.contains(lcToken))) {
/* 247 */       closeExpression(q, lcToken);
/*     */     }
/*     */     
/*     */ 
/* 251 */     if (BOOLEAN_OPERATORS.contains(lcToken)) {
/* 252 */       this.booleanTests.removeLast();
/* 253 */       this.booleanTests.addLast(Boolean.TRUE);
/*     */     }
/*     */     
/* 256 */     if (lcToken.equals("not")) {
/* 257 */       this.nots.addLast(new Boolean(!((Boolean)this.nots.removeLast()).booleanValue()));
/* 258 */       this.negated = (!this.negated);
/* 259 */       return;
/*     */     }
/*     */     
/*     */ 
/* 263 */     doToken(token, q);
/*     */     
/*     */ 
/* 266 */     if ((!this.betweenSpecialCase) && (EXPRESSION_OPENERS.contains(lcToken))) {
/* 267 */       openExpression(q, lcToken);
/*     */     }
/*     */     
/*     */ 
/* 271 */     specialCasesAfter(lcToken);
/*     */   }
/*     */   
/*     */   public void start(QueryTranslatorImpl q) throws QueryException
/*     */   {
/* 276 */     token("(", q);
/*     */   }
/*     */   
/*     */   public void end(QueryTranslatorImpl q) throws QueryException {
/* 280 */     if (this.expectingPathContinuation) {
/* 281 */       this.expectingPathContinuation = false;
/* 282 */       PathExpressionParser.CollectionElement element = this.pathExpressionParser.lastCollectionElement();
/* 283 */       if (element.elementColumns.length != 1) throw new QueryException("path expression ended in composite collection element");
/* 284 */       appendToken(q, element.elementColumns[0]);
/* 285 */       addToCurrentJoin(element);
/*     */     }
/* 287 */     token(")", q);
/*     */   }
/*     */   
/*     */   private void closeExpression(QueryTranslatorImpl q, String lcToken) {
/* 291 */     if (((Boolean)this.booleanTests.removeLast()).booleanValue())
/*     */     {
/* 293 */       if (this.booleanTests.size() > 0)
/*     */       {
/* 295 */         this.booleanTests.removeLast();
/* 296 */         this.booleanTests.addLast(Boolean.TRUE);
/*     */       }
/*     */       
/*     */ 
/* 300 */       appendToken(q, this.joins.removeLast().toString());
/*     */     }
/*     */     else
/*     */     {
/* 304 */       StringBuffer join = (StringBuffer)this.joins.removeLast();
/* 305 */       ((StringBuffer)this.joins.getLast()).append(join.toString());
/*     */     }
/*     */     
/* 308 */     if (((Boolean)this.nots.removeLast()).booleanValue()) { this.negated = (!this.negated);
/*     */     }
/* 310 */     if (!")".equals(lcToken)) appendToken(q, ")");
/*     */   }
/*     */   
/*     */   private void openExpression(QueryTranslatorImpl q, String lcToken) {
/* 314 */     this.nots.addLast(Boolean.FALSE);
/* 315 */     this.booleanTests.addLast(Boolean.FALSE);
/* 316 */     this.joins.addLast(new StringBuffer());
/* 317 */     if (!"(".equals(lcToken)) appendToken(q, "(");
/*     */   }
/*     */   
/*     */   private void preprocess(String token, QueryTranslatorImpl q)
/*     */     throws QueryException
/*     */   {
/* 323 */     String[] tokens = StringHelper.split(".", token, true);
/* 324 */     if ((tokens.length > 5) && (("elements".equals(tokens[(tokens.length - 1)])) || ("indices".equals(tokens[(tokens.length - 1)]))))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 329 */       this.pathExpressionParser.start(q);
/* 330 */       for (int i = 0; i < tokens.length - 3; i++) {
/* 331 */         this.pathExpressionParser.token(tokens[i], q);
/*     */       }
/* 333 */       this.pathExpressionParser.token(null, q);
/* 334 */       this.pathExpressionParser.end(q);
/* 335 */       addJoin(this.pathExpressionParser.getWhereJoin(), q);
/* 336 */       this.pathExpressionParser.ignoreInitialJoin();
/*     */     }
/*     */   }
/*     */   
/*     */   private void doPathExpression(String token, QueryTranslatorImpl q) throws QueryException
/*     */   {
/* 342 */     preprocess(token, q);
/*     */     
/* 344 */     StringTokenizer tokens = new StringTokenizer(token, ".", true);
/* 345 */     this.pathExpressionParser.start(q);
/* 346 */     while (tokens.hasMoreTokens()) {
/* 347 */       this.pathExpressionParser.token(tokens.nextToken(), q);
/*     */     }
/* 349 */     this.pathExpressionParser.end(q);
/* 350 */     if (this.pathExpressionParser.isCollectionValued()) {
/* 351 */       openExpression(q, "");
/* 352 */       appendToken(q, this.pathExpressionParser.getCollectionSubquery(q.getEnabledFilters()));
/* 353 */       closeExpression(q, "");
/*     */       
/* 355 */       q.addQuerySpaces(q.getCollectionPersister(this.pathExpressionParser.getCollectionRole()).getCollectionSpaces());
/*     */ 
/*     */     }
/* 358 */     else if (this.pathExpressionParser.isExpectingCollectionIndex()) {
/* 359 */       this.expectingIndex += 1;
/*     */     }
/*     */     else {
/* 362 */       addJoin(this.pathExpressionParser.getWhereJoin(), q);
/* 363 */       appendToken(q, this.pathExpressionParser.getWhereColumn());
/*     */     } }
/*     */   
/*     */   private boolean expectingPathContinuation;
/*     */   private int expectingIndex;
/*     */   private LinkedList nots;
/*     */   private LinkedList joins;
/*     */   private LinkedList booleanTests;
/* 371 */   private void addJoin(JoinSequence joinSequence, QueryTranslatorImpl q) throws QueryException { q.addFromJoinOnly(this.pathExpressionParser.getName(), joinSequence);
/*     */     try {
/* 373 */       addToCurrentJoin(joinSequence.toJoinFragment(q.getEnabledFilters(), true).toWhereFragmentString());
/*     */     }
/*     */     catch (MappingException me) {
/* 376 */       throw new QueryException(me);
/*     */     }
/*     */   }
/*     */   
/*     */   private void doToken(String token, QueryTranslatorImpl q) throws QueryException {
/* 381 */     if (q.isName(StringHelper.root(token))) {
/* 382 */       doPathExpression(q.unalias(token), q);
/*     */     }
/* 384 */     else if (token.startsWith(":")) {
/* 385 */       q.addNamedParameter(token.substring(1));
/* 386 */       appendToken(q, "?");
/*     */     }
/*     */     else {
/* 389 */       Queryable persister = q.getEntityPersisterUsingImports(token);
/* 390 */       if (persister != null) {
/* 391 */         String discrim = persister.getDiscriminatorSQLValue();
/* 392 */         if (("null".equals(discrim)) || ("not null".equals(discrim))) {
/* 393 */           throw new QueryException("subclass test not allowed for null or not null discriminator");
/*     */         }
/*     */         
/* 396 */         appendToken(q, discrim);
/*     */       }
/*     */       else
/*     */       {
/*     */         Object constant;
/* 401 */         if ((token.indexOf('.') > -1) && ((constant = ReflectHelper.getConstantValue(token)) != null))
/*     */         {
/*     */ 
/*     */           try
/*     */           {
/*     */ 
/* 407 */             type = TypeFactory.heuristicType(constant.getClass().getName());
/*     */           } catch (MappingException me) {
/*     */             Type type;
/* 410 */             throw new QueryException(me); }
/*     */           Type type;
/* 412 */           if (type == null) throw new QueryException("Could not determine type of: " + token);
/*     */           try {
/* 414 */             appendToken(q, ((LiteralType)type).objectToSQLString(constant, q.getFactory().getDialect()));
/*     */           }
/*     */           catch (Exception e) {
/* 417 */             throw new QueryException("Could not format constant value to SQL literal: " + token, e);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 422 */           String negatedToken = this.negated ? (String)NEGATIONS.get(token.toLowerCase()) : null;
/* 423 */           if ((negatedToken != null) && ((!this.betweenSpecialCase) || (!"or".equals(negatedToken)))) {
/* 424 */             appendToken(q, negatedToken);
/*     */           }
/*     */           else {
/* 427 */             appendToken(q, token);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addToCurrentJoin(String sql) {
/* 435 */     ((StringBuffer)this.joins.getLast()).append(sql);
/*     */   }
/*     */   
/*     */   private void addToCurrentJoin(PathExpressionParser.CollectionElement ce) throws QueryException
/*     */   {
/*     */     try {
/* 441 */       addToCurrentJoin(ce.joinSequence.toJoinFragment().toWhereFragmentString() + ce.indexValue.toString());
/*     */     }
/*     */     catch (MappingException me) {
/* 444 */       throw new QueryException(me);
/*     */     }
/*     */   }
/*     */   
/*     */   private void specialCasesBefore(String lcToken) {
/* 449 */     if ((lcToken.equals("between")) || (lcToken.equals("not between"))) {
/* 450 */       this.betweenSpecialCase = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private void specialCasesAfter(String lcToken) {
/* 455 */     if ((this.betweenSpecialCase) && (lcToken.equals("and"))) {
/* 456 */       this.betweenSpecialCase = false;
/*     */     }
/*     */   }
/*     */   
/*     */   void appendToken(QueryTranslatorImpl q, String token) {
/* 461 */     if (this.expectingIndex > 0) {
/* 462 */       this.pathExpressionParser.setLastCollectionElementIndexValue(token);
/*     */     }
/*     */     else {
/* 465 */       q.appendWhereToken(token);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean continuePathExpression(String token, QueryTranslatorImpl q) throws QueryException
/*     */   {
/* 471 */     this.expectingPathContinuation = false;
/*     */     
/* 473 */     PathExpressionParser.CollectionElement element = this.pathExpressionParser.lastCollectionElement();
/*     */     
/* 475 */     if (token.startsWith("."))
/*     */     {
/* 477 */       doPathExpression(getElementName(element, q) + token, q);
/*     */       
/* 479 */       addToCurrentJoin(element);
/* 480 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 485 */     if (element.elementColumns.length != 1) {
/* 486 */       throw new QueryException("path expression ended in composite collection element");
/*     */     }
/* 488 */     appendToken(q, element.elementColumns[0]);
/* 489 */     addToCurrentJoin(element);
/* 490 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\classic\WhereParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */