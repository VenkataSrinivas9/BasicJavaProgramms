/*    */ package org.hibernate.hql.classic;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.hql.FilterTranslator;
/*    */ import org.hibernate.hql.QueryTranslator;
/*    */ import org.hibernate.hql.QueryTranslatorFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassicQueryTranslatorFactory
/*    */   implements QueryTranslatorFactory
/*    */ {
/*    */   public QueryTranslator createQueryTranslator(String queryIdentifier, String queryString, Map filters, SessionFactoryImplementor factory)
/*    */   {
/* 27 */     return new QueryTranslatorImpl(queryIdentifier, queryString, filters, factory);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public FilterTranslator createFilterTranslator(String queryIdentifier, String queryString, Map filters, SessionFactoryImplementor factory)
/*    */   {
/* 38 */     return new QueryTranslatorImpl(queryIdentifier, queryString, filters, factory);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\classic\ClassicQueryTranslatorFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */