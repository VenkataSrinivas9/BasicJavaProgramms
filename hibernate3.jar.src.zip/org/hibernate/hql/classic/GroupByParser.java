/*    */ package org.hibernate.hql.classic;
/*    */ 
/*    */ import org.hibernate.QueryException;
/*    */ import org.hibernate.util.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GroupByParser
/*    */   implements Parser
/*    */ {
/*    */   private final PathExpressionParser pathExpressionParser;
/*    */   
/*    */   public GroupByParser()
/*    */   {
/* 25 */     this.pathExpressionParser = new PathExpressionParser();
/* 26 */     this.pathExpressionParser.setUseThetaStyleJoin(true);
/*    */   }
/*    */   
/*    */   public void token(String token, QueryTranslatorImpl q) throws QueryException
/*    */   {
/* 31 */     if (q.isName(StringHelper.root(token))) {
/* 32 */       ParserHelper.parse(this.pathExpressionParser, q.unalias(token), ".", q);
/* 33 */       q.appendGroupByToken(this.pathExpressionParser.getWhereColumn());
/* 34 */       this.pathExpressionParser.addAssociation(q);
/*    */     }
/*    */     else {
/* 37 */       q.appendGroupByToken(token);
/*    */     }
/*    */   }
/*    */   
/*    */   public void start(QueryTranslatorImpl q)
/*    */     throws QueryException
/*    */   {}
/*    */   
/*    */   public void end(QueryTranslatorImpl q)
/*    */     throws QueryException
/*    */   {}
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\classic\GroupByParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */