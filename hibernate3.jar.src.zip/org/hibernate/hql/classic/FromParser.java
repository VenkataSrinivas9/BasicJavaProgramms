/*     */ package org.hibernate.hql.classic;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.persister.entity.Queryable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FromParser
/*     */   implements Parser
/*     */ {
/*  19 */   private final PathExpressionParser peParser = new FromPathExpressionParser();
/*     */   
/*     */   private String entityName;
/*     */   
/*     */   private String alias;
/*     */   private boolean afterIn;
/*     */   private boolean afterAs;
/*     */   private boolean afterClass;
/*     */   private boolean expectingJoin;
/*     */   private boolean expectingIn;
/*     */   private boolean expectingAs;
/*     */   private boolean afterJoinType;
/*     */   private int joinType;
/*     */   private boolean afterFetch;
/*     */   private static final int NONE = -666;
/*  34 */   private static final Map JOIN_TYPES = new HashMap();
/*     */   
/*     */   static {
/*  37 */     JOIN_TYPES.put("left", new Integer(1));
/*  38 */     JOIN_TYPES.put("right", new Integer(2));
/*  39 */     JOIN_TYPES.put("full", new Integer(4));
/*  40 */     JOIN_TYPES.put("inner", new Integer(0));
/*     */   }
/*     */   
/*     */   public void token(String token, QueryTranslatorImpl q)
/*     */     throws QueryException
/*     */   {
/*  46 */     String lcToken = token.toLowerCase();
/*  47 */     if (lcToken.equals(",")) {
/*  48 */       if (!(this.expectingJoin | this.expectingAs)) throw new QueryException("unexpected token: ,");
/*  49 */       this.expectingJoin = false;
/*  50 */       this.expectingAs = false;
/*     */     }
/*  52 */     else if (lcToken.equals("join")) {
/*  53 */       if (!this.afterJoinType) {
/*  54 */         if (!(this.expectingJoin | this.expectingAs)) { throw new QueryException("unexpected token: join");
/*     */         }
/*  56 */         this.joinType = 0;
/*  57 */         this.expectingJoin = false;
/*  58 */         this.expectingAs = false;
/*     */       }
/*     */       else {
/*  61 */         this.afterJoinType = false;
/*     */       }
/*     */     }
/*  64 */     else if (lcToken.equals("fetch")) {
/*  65 */       if (q.isShallowQuery()) throw new QueryException("fetch may not be used with scroll() or iterate()");
/*  66 */       if (this.joinType == 64870) throw new QueryException("unexpected token: fetch");
/*  67 */       if ((this.joinType == 4) || (this.joinType == 2)) {
/*  68 */         throw new QueryException("fetch may only be used with inner join or left outer join");
/*     */       }
/*  70 */       this.afterFetch = true;
/*     */     }
/*  72 */     else if (lcToken.equals("outer"))
/*     */     {
/*  74 */       if ((!this.afterJoinType) || ((this.joinType != 1) && (this.joinType != 2)))
/*     */       {
/*     */ 
/*  77 */         throw new QueryException("unexpected token: outer");
/*     */       }
/*     */     }
/*  80 */     else if (JOIN_TYPES.containsKey(lcToken)) {
/*  81 */       if (!(this.expectingJoin | this.expectingAs)) throw new QueryException("unexpected token: " + token);
/*  82 */       this.joinType = ((Integer)JOIN_TYPES.get(lcToken)).intValue();
/*  83 */       this.afterJoinType = true;
/*  84 */       this.expectingJoin = false;
/*  85 */       this.expectingAs = false;
/*     */     }
/*  87 */     else if (lcToken.equals("class")) {
/*  88 */       if (!this.afterIn) throw new QueryException("unexpected token: class");
/*  89 */       if (this.joinType != 64870) throw new QueryException("outer or full join must be followed by path expression");
/*  90 */       this.afterClass = true;
/*     */     }
/*  92 */     else if (lcToken.equals("in")) {
/*  93 */       if (!this.expectingIn) throw new QueryException("unexpected token: in");
/*  94 */       this.afterIn = true;
/*  95 */       this.expectingIn = false;
/*     */     }
/*  97 */     else if (lcToken.equals("as")) {
/*  98 */       if (!this.expectingAs) throw new QueryException("unexpected token: as");
/*  99 */       this.afterAs = true;
/* 100 */       this.expectingAs = false;
/*     */     }
/*     */     else
/*     */     {
/* 104 */       if (this.afterJoinType) throw new QueryException("join expected: " + token);
/* 105 */       if (this.expectingJoin) throw new QueryException("unexpected token: " + token);
/* 106 */       if (this.expectingIn) { throw new QueryException("in expected: " + token);
/*     */       }
/*     */       
/*     */ 
/* 110 */       if ((this.afterAs) || (this.expectingAs))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 118 */         if (this.entityName != null) {
/* 119 */           q.setAliasName(token, this.entityName);
/*     */         }
/*     */         else {
/* 122 */           throw new QueryException("unexpected: as " + token);
/*     */         }
/* 124 */         this.afterAs = false;
/* 125 */         this.expectingJoin = true;
/* 126 */         this.expectingAs = false;
/* 127 */         this.entityName = null;
/*     */ 
/*     */       }
/* 130 */       else if (this.afterIn)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 135 */         if (this.alias == null) { throw new QueryException("alias not specified for: " + token);
/*     */         }
/* 137 */         if (this.joinType != 64870) { throw new QueryException("outer or full join must be followed by path expression");
/*     */         }
/* 139 */         if (this.afterClass)
/*     */         {
/* 141 */           Queryable p = q.getEntityPersisterUsingImports(token);
/* 142 */           if (p == null) throw new QueryException("persister not found: " + token);
/* 143 */           q.addFromClass(this.alias, p);
/*     */         }
/*     */         else
/*     */         {
/* 147 */           this.peParser.setJoinType(0);
/* 148 */           this.peParser.setUseThetaStyleJoin(true);
/* 149 */           ParserHelper.parse(this.peParser, q.unalias(token), ".", q);
/* 150 */           if (!this.peParser.isCollectionValued()) throw new QueryException("path expression did not resolve to collection: " + token);
/* 151 */           String nm = this.peParser.addFromCollection(q);
/* 152 */           q.setAliasName(this.alias, nm);
/*     */         }
/*     */         
/* 155 */         this.alias = null;
/* 156 */         this.afterIn = false;
/* 157 */         this.afterClass = false;
/* 158 */         this.expectingJoin = true;
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/* 167 */         Queryable p = q.getEntityPersisterUsingImports(token);
/* 168 */         if (p != null)
/*     */         {
/* 170 */           if (this.joinType != 64870) throw new QueryException("outer or full join must be followed by path expression");
/* 171 */           this.entityName = q.createNameFor(p.getEntityName());
/* 172 */           q.addFromClass(this.entityName, p);
/* 173 */           this.expectingAs = true;
/*     */         }
/* 175 */         else if (token.indexOf('.') < 0)
/*     */         {
/*     */ 
/* 178 */           this.alias = token;
/* 179 */           this.expectingIn = true;
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 189 */           if (this.joinType != 64870) {
/* 190 */             this.peParser.setJoinType(this.joinType);
/*     */           }
/*     */           else {
/* 193 */             this.peParser.setJoinType(0);
/*     */           }
/* 195 */           this.peParser.setUseThetaStyleJoin(q.isSubquery());
/*     */           
/* 197 */           ParserHelper.parse(this.peParser, q.unalias(token), ".", q);
/* 198 */           this.entityName = this.peParser.addFromAssociation(q);
/*     */           
/* 200 */           this.joinType = 64870;
/* 201 */           this.peParser.setJoinType(0);
/*     */           
/* 203 */           if (this.afterFetch) {
/* 204 */             this.peParser.fetch(q, this.entityName);
/* 205 */             this.afterFetch = false;
/*     */           }
/*     */           
/* 208 */           this.expectingAs = true;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void start(QueryTranslatorImpl q)
/*     */   {
/* 217 */     this.entityName = null;
/* 218 */     this.alias = null;
/* 219 */     this.afterIn = false;
/* 220 */     this.afterAs = false;
/* 221 */     this.afterClass = false;
/* 222 */     this.expectingJoin = false;
/* 223 */     this.expectingIn = false;
/* 224 */     this.expectingAs = false;
/* 225 */     this.joinType = 64870;
/*     */   }
/*     */   
/*     */   public void end(QueryTranslatorImpl q) {}
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\classic\FromParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */