/*    */ package org.hibernate.hql.classic;
/*    */ 
/*    */ import org.hibernate.QueryException;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ public class FromPathExpressionParser
/*    */   extends PathExpressionParser
/*    */ {
/*    */   public void end(QueryTranslatorImpl q) throws QueryException
/*    */   {
/* 11 */     if (!isCollectionValued()) {
/* 12 */       Type type = getPropertyType();
/* 13 */       if (type.isEntityType())
/*    */       {
/* 15 */         token(".", q);
/* 16 */         token(null, q);
/*    */       }
/* 18 */       else if (type.isCollectionType())
/*    */       {
/* 20 */         token(".", q);
/* 21 */         token("elements", q);
/*    */       }
/*    */     }
/* 24 */     super.end(q);
/*    */   }
/*    */   
/*    */   protected void setExpectingCollectionIndex() throws QueryException {
/* 28 */     throw new QueryException("illegal syntax near collection-valued path expression in from: " + getCollectionName());
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\classic\FromPathExpressionParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */