/*    */ package org.hibernate.hql.classic;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HavingParser
/*    */   extends WhereParser
/*    */ {
/*    */   void appendToken(QueryTranslatorImpl q, String token)
/*    */   {
/* 12 */     q.appendHavingToken(token);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\classic\HavingParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */