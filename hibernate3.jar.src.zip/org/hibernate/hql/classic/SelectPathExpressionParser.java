/*    */ package org.hibernate.hql.classic;
/*    */ 
/*    */ import org.hibernate.QueryException;
/*    */ 
/*    */ public class SelectPathExpressionParser extends PathExpressionParser
/*    */ {
/*    */   public void end(QueryTranslatorImpl q) throws QueryException
/*    */   {
/*  9 */     if ((getCurrentProperty() != null) && (!q.isShallowQuery()))
/*    */     {
/* 11 */       token(".", q);
/* 12 */       token(null, q);
/*    */     }
/* 14 */     super.end(q);
/*    */   }
/*    */   
/*    */   protected void setExpectingCollectionIndex() throws QueryException {
/* 18 */     throw new QueryException("illegal syntax near collection-valued path expression in select: " + getCollectionName());
/*    */   }
/*    */   
/*    */   public String getSelectName() {
/* 22 */     return getCurrentName();
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\classic\SelectPathExpressionParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */