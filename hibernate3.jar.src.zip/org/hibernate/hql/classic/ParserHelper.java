/*    */ package org.hibernate.hql.classic;
/*    */ 
/*    */ import java.util.StringTokenizer;
/*    */ import org.hibernate.QueryException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ParserHelper
/*    */ {
/*    */   public static final String HQL_VARIABLE_PREFIX = ":";
/*    */   public static final String HQL_SEPARATORS = " \n\r\f\t,()=<>&|+-=/*'^![]#~\\";
/*    */   public static final String PATH_SEPARATORS = ".";
/*    */   
/*    */   public static boolean isWhitespace(String str)
/*    */   {
/* 18 */     return " \n\r\f\t".indexOf(str) > -1;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static void parse(Parser p, String text, String seperators, QueryTranslatorImpl q)
/*    */     throws QueryException
/*    */   {
/* 26 */     StringTokenizer tokens = new StringTokenizer(text, seperators, true);
/* 27 */     p.start(q);
/* 28 */     while (tokens.hasMoreElements()) p.token(tokens.nextToken(), q);
/* 29 */     p.end(q);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\classic\ParserHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */