/*    */ package org.hibernate.hql.classic;
/*    */ 
/*    */ import org.hibernate.QueryException;
/*    */ import org.hibernate.util.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OrderByParser
/*    */   implements Parser
/*    */ {
/*    */   private final PathExpressionParser pathExpressionParser;
/*    */   
/*    */   public OrderByParser()
/*    */   {
/* 24 */     this.pathExpressionParser = new PathExpressionParser();
/* 25 */     this.pathExpressionParser.setUseThetaStyleJoin(true);
/*    */   }
/*    */   
/*    */   public void token(String token, QueryTranslatorImpl q) throws QueryException
/*    */   {
/* 30 */     if (q.isName(StringHelper.root(token))) {
/* 31 */       ParserHelper.parse(this.pathExpressionParser, q.unalias(token), ".", q);
/* 32 */       q.appendOrderByToken(this.pathExpressionParser.getWhereColumn());
/* 33 */       this.pathExpressionParser.addAssociation(q);
/*    */     }
/* 35 */     else if (token.startsWith(":")) {
/* 36 */       q.addNamedParameter(token.substring(1));
/* 37 */       q.appendOrderByToken("?");
/*    */     }
/*    */     else {
/* 40 */       q.appendOrderByToken(token);
/*    */     }
/*    */   }
/*    */   
/*    */   public void start(QueryTranslatorImpl q)
/*    */     throws QueryException
/*    */   {}
/*    */   
/*    */   public void end(QueryTranslatorImpl q)
/*    */     throws QueryException
/*    */   {}
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\classic\OrderByParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */