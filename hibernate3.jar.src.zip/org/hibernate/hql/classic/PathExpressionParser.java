/*     */ package org.hibernate.hql.classic;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.engine.JoinSequence;
/*     */ import org.hibernate.hql.CollectionSubqueryFactory;
/*     */ import org.hibernate.persister.collection.CollectionPropertyMapping;
/*     */ import org.hibernate.persister.collection.QueryableCollection;
/*     */ import org.hibernate.persister.entity.PropertyMapping;
/*     */ import org.hibernate.persister.entity.Queryable;
/*     */ import org.hibernate.sql.JoinFragment;
/*     */ import org.hibernate.type.AssociationType;
/*     */ import org.hibernate.type.CollectionType;
/*     */ import org.hibernate.type.EntityType;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.type.TypeFactory;
/*     */ 
/*     */ 
/*     */ public class PathExpressionParser
/*     */   implements Parser
/*     */ {
/*     */   private int dotcount;
/*     */   private String currentName;
/*     */   private String currentProperty;
/*     */   private String oneToOneOwnerName;
/*     */   private AssociationType ownerAssociationType;
/*     */   private String[] columns;
/*     */   private String collectionName;
/*     */   private String collectionOwnerName;
/*     */   private String collectionRole;
/*     */   private final StringBuffer componentPath;
/*     */   private Type type;
/*     */   private final StringBuffer path;
/*     */   private boolean ignoreInitialJoin;
/*     */   private boolean continuation;
/*     */   private int joinType;
/*     */   private boolean useThetaStyleJoin;
/*     */   private PropertyMapping currentPropertyMapping;
/*     */   private JoinSequence joinSequence;
/*     */   private boolean expectingCollectionIndex;
/*     */   private LinkedList collectionElements;
/*     */   
/*     */   public PathExpressionParser()
/*     */   {
/*  47 */     this.componentPath = new StringBuffer();
/*     */     
/*  49 */     this.path = new StringBuffer();
/*     */     
/*     */ 
/*  52 */     this.joinType = 0;
/*  53 */     this.useThetaStyleJoin = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  58 */     this.collectionElements = new LinkedList();
/*     */   }
/*     */   
/*  61 */   void setJoinType(int joinType) { this.joinType = joinType; }
/*     */   
/*     */   void setUseThetaStyleJoin(boolean useThetaStyleJoin)
/*     */   {
/*  65 */     this.useThetaStyleJoin = useThetaStyleJoin;
/*     */   }
/*     */   
/*     */   private void addJoin(String name, AssociationType joinableType) throws QueryException {
/*     */     try {
/*  70 */       this.joinSequence.addJoin(joinableType, name, this.joinType, currentColumns());
/*     */     }
/*     */     catch (MappingException me) {
/*  73 */       throw new QueryException(me);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addJoin(String name, AssociationType joinableType, String[] foreignKeyColumns) throws QueryException {
/*     */     try {
/*  79 */       this.joinSequence.addJoin(joinableType, name, this.joinType, foreignKeyColumns);
/*     */     }
/*     */     catch (MappingException me) {
/*  82 */       throw new QueryException(me);
/*     */     }
/*     */   }
/*     */   
/*     */   String continueFromManyToMany(String entityName, String[] joinColumns, QueryTranslatorImpl q) throws QueryException {
/*  87 */     start(q);
/*  88 */     this.continuation = true;
/*  89 */     this.currentName = q.createNameFor(entityName);
/*  90 */     q.addType(this.currentName, entityName);
/*  91 */     Queryable classPersister = q.getEntityPersister(entityName);
/*     */     
/*  93 */     addJoin(this.currentName, TypeFactory.manyToOne(entityName), joinColumns);
/*  94 */     this.currentPropertyMapping = classPersister;
/*  95 */     return this.currentName;
/*     */   }
/*     */   
/*     */   public void ignoreInitialJoin() {
/*  99 */     this.ignoreInitialJoin = true;
/*     */   }
/*     */   
/*     */   public void token(String token, QueryTranslatorImpl q) throws QueryException
/*     */   {
/* 104 */     if (token != null) { this.path.append(token);
/*     */     }
/* 106 */     String alias = q.getPathAlias(this.path.toString());
/* 107 */     if (alias != null) {
/* 108 */       reset(q);
/* 109 */       this.currentName = alias;
/* 110 */       this.currentPropertyMapping = q.getPropertyMapping(this.currentName);
/* 111 */       if (!this.ignoreInitialJoin) {
/* 112 */         JoinSequence ojf = q.getPathJoin(this.path.toString());
/*     */         try {
/* 114 */           this.joinSequence.addCondition(ojf.toJoinFragment(q.getEnabledFilters(), true).toWhereFragmentString());
/*     */         }
/*     */         catch (MappingException me) {
/* 117 */           throw new QueryException(me);
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */ 
/*     */     }
/* 124 */     else if (".".equals(token)) {
/* 125 */       this.dotcount += 1;
/*     */ 
/*     */     }
/* 128 */     else if (this.dotcount == 0) {
/* 129 */       if (!this.continuation) {
/* 130 */         if (!q.isName(token)) throw new QueryException("undefined alias: " + token);
/* 131 */         this.currentName = token;
/* 132 */         this.currentPropertyMapping = q.getPropertyMapping(this.currentName);
/*     */       }
/*     */     }
/* 135 */     else if (this.dotcount == 1) {
/* 136 */       if (this.currentName != null) {
/* 137 */         this.currentProperty = token;
/*     */       }
/* 139 */       else if (this.collectionName != null)
/*     */       {
/* 141 */         this.continuation = false;
/*     */       }
/*     */       else {
/* 144 */         throw new QueryException("unexpected");
/*     */       }
/*     */       
/*     */     }
/*     */     else
/*     */     {
/* 150 */       Type propertyType = getPropertyType();
/*     */       
/* 152 */       if (propertyType == null) {
/* 153 */         throw new QueryException("unresolved property: " + this.path);
/*     */       }
/*     */       
/* 156 */       if (propertyType.isComponentType()) {
/* 157 */         dereferenceComponent(token);
/*     */       }
/* 159 */       else if (propertyType.isEntityType()) {
/* 160 */         if (!isCollectionValued()) dereferenceEntity(token, (EntityType)propertyType, q);
/*     */       }
/* 162 */       else if (propertyType.isCollectionType()) {
/* 163 */         dereferenceCollection(token, ((CollectionType)propertyType).getRole(), q);
/*     */ 
/*     */ 
/*     */       }
/* 167 */       else if (token != null) { throw new QueryException("dereferenced: " + this.path);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void dereferenceEntity(String propertyName, EntityType propertyType, QueryTranslatorImpl q)
/*     */     throws QueryException
/*     */   {
/* 179 */     boolean isIdShortcut = ("id".equals(propertyName)) && (propertyType.isReferenceToPrimaryKey());
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 185 */       idPropertyName = propertyType.getIdentifierOrUniqueKeyPropertyName(q.getFactory());
/*     */     } catch (MappingException me) {
/*     */       String idPropertyName;
/* 188 */       throw new QueryException(me); }
/*     */     String idPropertyName;
/* 190 */     boolean isNamedIdPropertyShortcut = (idPropertyName != null) && (idPropertyName.equals(propertyName));
/*     */     
/*     */ 
/* 193 */     if ((isIdShortcut) || (isNamedIdPropertyShortcut))
/*     */     {
/*     */ 
/* 196 */       if (this.componentPath.length() > 0) this.componentPath.append('.');
/* 197 */       this.componentPath.append(propertyName);
/*     */     }
/*     */     else {
/* 200 */       String entityClass = propertyType.getAssociatedEntityName();
/* 201 */       String name = q.createNameFor(entityClass);
/* 202 */       q.addType(name, entityClass);
/* 203 */       addJoin(name, propertyType);
/* 204 */       if (propertyType.isOneToOne()) this.oneToOneOwnerName = this.currentName;
/* 205 */       this.ownerAssociationType = propertyType;
/* 206 */       this.currentName = name;
/* 207 */       this.currentProperty = propertyName;
/* 208 */       q.addPathAliasAndJoin(this.path.substring(0, this.path.toString().lastIndexOf('.')), name, this.joinSequence.copy());
/* 209 */       this.componentPath.setLength(0);
/* 210 */       this.currentPropertyMapping = q.getEntityPersister(entityClass);
/*     */     }
/*     */   }
/*     */   
/*     */   private void dereferenceComponent(String propertyName) {
/* 215 */     if (propertyName != null) {
/* 216 */       if (this.componentPath.length() > 0) this.componentPath.append('.');
/* 217 */       this.componentPath.append(propertyName);
/*     */     }
/*     */   }
/*     */   
/*     */   private void dereferenceCollection(String propertyName, String role, QueryTranslatorImpl q) throws QueryException {
/* 222 */     this.collectionRole = role;
/* 223 */     QueryableCollection collPersister = q.getCollectionPersister(role);
/* 224 */     String name = q.createNameForCollection(role);
/* 225 */     addJoin(name, collPersister.getCollectionType());
/*     */     
/* 227 */     this.collectionName = name;
/* 228 */     this.collectionOwnerName = this.currentName;
/* 229 */     this.currentName = name;
/* 230 */     this.currentProperty = propertyName;
/* 231 */     this.componentPath.setLength(0);
/* 232 */     this.currentPropertyMapping = new CollectionPropertyMapping(collPersister);
/*     */   }
/*     */   
/*     */   private String getPropertyPath() {
/* 236 */     if (this.currentProperty == null) {
/* 237 */       return "id";
/*     */     }
/*     */     
/* 240 */     if (this.componentPath.length() > 0) {
/* 241 */       return this.currentProperty + '.' + this.componentPath.toString();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 248 */     return this.currentProperty;
/*     */   }
/*     */   
/*     */ 
/*     */   private PropertyMapping getPropertyMapping()
/*     */   {
/* 254 */     return this.currentPropertyMapping;
/*     */   }
/*     */   
/*     */   private void setType() throws QueryException {
/* 258 */     if (this.currentProperty == null) {
/* 259 */       this.type = getPropertyMapping().getType();
/*     */     }
/*     */     else {
/* 262 */       this.type = getPropertyType();
/*     */     }
/*     */   }
/*     */   
/*     */   protected Type getPropertyType() throws QueryException {
/* 267 */     String propertyPath = getPropertyPath();
/* 268 */     Type propertyType = getPropertyMapping().toType(propertyPath);
/* 269 */     if (propertyType == null) {
/* 270 */       throw new QueryException("could not resolve property type: " + propertyPath);
/*     */     }
/* 272 */     return propertyType;
/*     */   }
/*     */   
/*     */   protected String[] currentColumns() throws QueryException {
/* 276 */     String propertyPath = getPropertyPath();
/* 277 */     String[] propertyColumns = getPropertyMapping().toColumns(this.currentName, propertyPath);
/* 278 */     if (propertyColumns == null) {
/* 279 */       throw new QueryException("could not resolve property columns: " + propertyPath);
/*     */     }
/* 281 */     return propertyColumns;
/*     */   }
/*     */   
/*     */   private void reset(QueryTranslatorImpl q)
/*     */   {
/* 286 */     this.dotcount = 0;
/* 287 */     this.currentName = null;
/* 288 */     this.currentProperty = null;
/* 289 */     this.collectionName = null;
/* 290 */     this.collectionRole = null;
/* 291 */     this.componentPath.setLength(0);
/* 292 */     this.type = null;
/* 293 */     this.collectionName = null;
/* 294 */     this.columns = null;
/* 295 */     this.expectingCollectionIndex = false;
/* 296 */     this.continuation = false;
/* 297 */     this.currentPropertyMapping = null;
/*     */   }
/*     */   
/*     */   public void start(QueryTranslatorImpl q) {
/* 301 */     if (!this.continuation) {
/* 302 */       reset(q);
/* 303 */       this.path.setLength(0);
/* 304 */       this.joinSequence = new JoinSequence(q.getFactory()).setUseThetaStyle(this.useThetaStyleJoin);
/*     */     }
/*     */   }
/*     */   
/*     */   public void end(QueryTranslatorImpl q) throws QueryException {
/* 309 */     this.ignoreInitialJoin = false;
/*     */     
/* 311 */     Type propertyType = getPropertyType();
/* 312 */     if ((propertyType != null) && (propertyType.isCollectionType())) {
/* 313 */       this.collectionRole = ((CollectionType)propertyType).getRole();
/* 314 */       this.collectionName = q.createNameForCollection(this.collectionRole);
/* 315 */       prepareForIndex(q);
/*     */     }
/*     */     else {
/* 318 */       this.columns = currentColumns();
/* 319 */       setType();
/*     */     }
/*     */     
/*     */ 
/* 323 */     this.continuation = false;
/*     */   }
/*     */   
/*     */   private void prepareForIndex(QueryTranslatorImpl q)
/*     */     throws QueryException
/*     */   {
/* 329 */     QueryableCollection collPersister = q.getCollectionPersister(this.collectionRole);
/*     */     
/* 331 */     if (!collPersister.hasIndex()) throw new QueryException("unindexed collection before []: " + this.path);
/* 332 */     String[] indexCols = collPersister.getIndexColumnNames();
/* 333 */     if (indexCols.length != 1) { throw new QueryException("composite-index appears in []: " + this.path);
/*     */     }
/*     */     
/* 336 */     JoinSequence fromJoins = new JoinSequence(q.getFactory()).setUseThetaStyle(this.useThetaStyleJoin).setRoot(collPersister, this.collectionName).setNext(this.joinSequence.copy());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 341 */     if (!this.continuation) { addJoin(this.collectionName, collPersister.getCollectionType());
/*     */     }
/* 343 */     this.joinSequence.addCondition(this.collectionName + '.' + indexCols[0] + " = ");
/*     */     
/* 345 */     CollectionElement elem = new CollectionElement();
/* 346 */     elem.elementColumns = collPersister.getElementColumnNames(this.collectionName);
/* 347 */     elem.elementType = collPersister.getElementType();
/* 348 */     elem.isOneToMany = collPersister.isOneToMany();
/* 349 */     elem.alias = this.collectionName;
/* 350 */     elem.joinSequence = this.joinSequence;
/* 351 */     this.collectionElements.addLast(elem);
/* 352 */     setExpectingCollectionIndex();
/*     */     
/* 354 */     q.addCollection(this.collectionName, this.collectionRole);
/* 355 */     q.addFromJoinOnly(this.collectionName, fromJoins);
/*     */   }
/*     */   
/*     */   static final class CollectionElement {
/*     */     Type elementType;
/*     */     boolean isOneToMany;
/*     */     String alias;
/*     */     String[] elementColumns;
/*     */     JoinSequence joinSequence;
/* 364 */     StringBuffer indexValue = new StringBuffer();
/*     */   }
/*     */   
/*     */   public CollectionElement lastCollectionElement() {
/* 368 */     return (CollectionElement)this.collectionElements.removeLast();
/*     */   }
/*     */   
/*     */   public void setLastCollectionElementIndexValue(String value) {
/* 372 */     ((CollectionElement)this.collectionElements.getLast()).indexValue.append(value);
/*     */   }
/*     */   
/*     */   public boolean isExpectingCollectionIndex() {
/* 376 */     return this.expectingCollectionIndex;
/*     */   }
/*     */   
/*     */   protected void setExpectingCollectionIndex() throws QueryException {
/* 380 */     this.expectingCollectionIndex = true;
/*     */   }
/*     */   
/*     */   public JoinSequence getWhereJoin() {
/* 384 */     return this.joinSequence;
/*     */   }
/*     */   
/*     */   public String getWhereColumn() throws QueryException {
/* 388 */     if (this.columns.length != 1) {
/* 389 */       throw new QueryException("path expression ends in a composite value: " + this.path);
/*     */     }
/* 391 */     return this.columns[0];
/*     */   }
/*     */   
/*     */   public String[] getWhereColumns() {
/* 395 */     return this.columns;
/*     */   }
/*     */   
/*     */   public Type getWhereColumnType() {
/* 399 */     return this.type;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 403 */     return this.currentName == null ? this.collectionName : this.currentName;
/*     */   }
/*     */   
/*     */   public String getCollectionSubquery(Map enabledFilters) throws QueryException
/*     */   {
/* 408 */     return CollectionSubqueryFactory.createCollectionSubquery(this.joinSequence, enabledFilters, currentColumns());
/*     */   }
/*     */   
/*     */   public boolean isCollectionValued() throws QueryException
/*     */   {
/* 413 */     return (this.collectionName != null) && (!getPropertyType().isCollectionType());
/*     */   }
/*     */   
/*     */   public void addAssociation(QueryTranslatorImpl q) throws QueryException {
/* 417 */     q.addJoin(getName(), this.joinSequence);
/*     */   }
/*     */   
/*     */   public String addFromAssociation(QueryTranslatorImpl q) throws QueryException {
/* 421 */     if (isCollectionValued()) {
/* 422 */       return addFromCollection(q);
/*     */     }
/*     */     
/* 425 */     q.addFrom(this.currentName, this.joinSequence);
/* 426 */     return this.currentName;
/*     */   }
/*     */   
/*     */   public String addFromCollection(QueryTranslatorImpl q) throws QueryException
/*     */   {
/* 431 */     Type collectionElementType = getPropertyType();
/*     */     
/* 433 */     if (collectionElementType == null) {
/* 434 */       throw new QueryException("must specify 'elements' for collection valued property in from clause: " + this.path);
/*     */     }
/*     */     
/* 437 */     if (collectionElementType.isEntityType())
/*     */     {
/* 439 */       QueryableCollection collectionPersister = q.getCollectionPersister(this.collectionRole);
/* 440 */       Queryable entityPersister = (Queryable)collectionPersister.getElementPersister();
/* 441 */       String clazz = entityPersister.getEntityName();
/*     */       
/*     */       String elementName;
/* 444 */       if (collectionPersister.isOneToMany()) {
/* 445 */         String elementName = this.collectionName;
/*     */         
/* 447 */         q.decoratePropertyMapping(elementName, collectionPersister);
/*     */       }
/*     */       else {
/* 450 */         q.addCollection(this.collectionName, this.collectionRole);
/* 451 */         elementName = q.createNameFor(clazz);
/* 452 */         addJoin(elementName, (AssociationType)collectionElementType);
/*     */       }
/* 454 */       q.addFrom(elementName, clazz, this.joinSequence);
/* 455 */       this.currentPropertyMapping = new CollectionPropertyMapping(collectionPersister);
/* 456 */       return elementName;
/*     */     }
/*     */     
/*     */ 
/* 460 */     q.addFromCollection(this.collectionName, this.collectionRole, this.joinSequence);
/* 461 */     return this.collectionName;
/*     */   }
/*     */   
/*     */ 
/*     */   String getCollectionName()
/*     */   {
/* 467 */     return this.collectionName;
/*     */   }
/*     */   
/*     */   String getCollectionRole() {
/* 471 */     return this.collectionRole;
/*     */   }
/*     */   
/*     */   String getCollectionOwnerName() {
/* 475 */     return this.collectionOwnerName;
/*     */   }
/*     */   
/*     */   String getOneToOneOwnerName() {
/* 479 */     return this.oneToOneOwnerName;
/*     */   }
/*     */   
/*     */   AssociationType getOwnerAssociationType() {
/* 483 */     return this.ownerAssociationType;
/*     */   }
/*     */   
/*     */   String getCurrentProperty() {
/* 487 */     return this.currentProperty;
/*     */   }
/*     */   
/*     */   String getCurrentName() {
/* 491 */     return this.currentName;
/*     */   }
/*     */   
/*     */   public void fetch(QueryTranslatorImpl q, String entityName) throws QueryException {
/* 495 */     if (isCollectionValued()) {
/* 496 */       q.setCollectionToFetch(getCollectionRole(), getCollectionName(), getCollectionOwnerName(), entityName);
/*     */     }
/*     */     else {
/* 499 */       q.addEntityToFetch(entityName, getOneToOneOwnerName(), getOwnerAssociationType());
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\classic\PathExpressionParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */