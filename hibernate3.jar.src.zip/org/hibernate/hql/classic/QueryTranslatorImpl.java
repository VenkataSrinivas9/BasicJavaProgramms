/*      */ package org.hibernate.hql.classic;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.collections.SequencedHashMap;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.hibernate.HibernateException;
/*      */ import org.hibernate.LockMode;
/*      */ import org.hibernate.MappingException;
/*      */ import org.hibernate.QueryException;
/*      */ import org.hibernate.ScrollableResults;
/*      */ import org.hibernate.dialect.Dialect;
/*      */ import org.hibernate.engine.JoinSequence;
/*      */ import org.hibernate.engine.JoinSequence.Selector;
/*      */ import org.hibernate.engine.QueryParameters;
/*      */ import org.hibernate.engine.SessionFactoryImplementor;
/*      */ import org.hibernate.engine.SessionImplementor;
/*      */ import org.hibernate.event.EventSource;
/*      */ import org.hibernate.exception.JDBCExceptionHelper;
/*      */ import org.hibernate.hql.FilterTranslator;
/*      */ import org.hibernate.hql.HolderInstantiator;
/*      */ import org.hibernate.hql.NameGenerator;
/*      */ import org.hibernate.hql.ParameterTranslations;
/*      */ import org.hibernate.impl.IteratorImpl;
/*      */ import org.hibernate.loader.BasicLoader;
/*      */ import org.hibernate.persister.collection.CollectionPersister;
/*      */ import org.hibernate.persister.collection.QueryableCollection;
/*      */ import org.hibernate.persister.entity.Loadable;
/*      */ import org.hibernate.persister.entity.PropertyMapping;
/*      */ import org.hibernate.persister.entity.Queryable;
/*      */ import org.hibernate.sql.ForUpdateFragment;
/*      */ import org.hibernate.sql.JoinFragment;
/*      */ import org.hibernate.sql.QuerySelect;
/*      */ import org.hibernate.stat.Statistics;
/*      */ import org.hibernate.stat.StatisticsImplementor;
/*      */ import org.hibernate.type.AssociationType;
/*      */ import org.hibernate.type.EntityType;
/*      */ import org.hibernate.type.Type;
/*      */ import org.hibernate.type.TypeFactory;
/*      */ import org.hibernate.util.ArrayHelper;
/*      */ import org.hibernate.util.ReflectHelper;
/*      */ import org.hibernate.util.StringHelper;
/*      */ 
/*      */ public class QueryTranslatorImpl
/*      */   extends BasicLoader
/*      */   implements FilterTranslator
/*      */ {
/*   61 */   private static final String[] NO_RETURN_ALIASES = new String[0];
/*      */   
/*      */   private final String queryIdentifier;
/*      */   
/*      */   private final String queryString;
/*   66 */   private final Map typeMap = new SequencedHashMap();
/*   67 */   private final Map collections = new SequencedHashMap();
/*   68 */   private List returnedTypes = new ArrayList();
/*   69 */   private final List fromTypes = new ArrayList();
/*   70 */   private final List scalarTypes = new ArrayList();
/*   71 */   private final Map namedParameters = new HashMap();
/*   72 */   private final Map aliasNames = new HashMap();
/*   73 */   private final Map oneToOneOwnerNames = new HashMap();
/*   74 */   private final Map uniqueKeyOwnerReferences = new HashMap();
/*   75 */   private final Map decoratedPropertyMappings = new HashMap();
/*      */   
/*   77 */   private final List scalarSelectTokens = new ArrayList();
/*   78 */   private final List whereTokens = new ArrayList();
/*   79 */   private final List havingTokens = new ArrayList();
/*   80 */   private final Map joins = new SequencedHashMap();
/*   81 */   private final List orderByTokens = new ArrayList();
/*   82 */   private final List groupByTokens = new ArrayList();
/*   83 */   private final Set querySpaces = new HashSet();
/*   84 */   private final Set entitiesToFetch = new HashSet();
/*      */   
/*   86 */   private final Map pathAliases = new HashMap();
/*   87 */   private final Map pathJoins = new HashMap();
/*      */   
/*      */   private Queryable[] persisters;
/*      */   private int[] owners;
/*      */   private EntityType[] ownerAssociationTypes;
/*      */   private String[] names;
/*      */   private boolean[] includeInSelect;
/*      */   private int selectLength;
/*      */   private Type[] returnTypes;
/*      */   private Type[] actualReturnTypes;
/*      */   private String[][] scalarColumnNames;
/*      */   private Map tokenReplacements;
/*   99 */   private int nameCount = 0;
/*  100 */   private int parameterCount = 0;
/*  101 */   private boolean distinct = false;
/*      */   
/*      */   private boolean compiled;
/*      */   private String sqlString;
/*      */   private Class holderClass;
/*      */   private Constructor holderConstructor;
/*      */   private boolean hasScalars;
/*      */   private boolean shallowQuery;
/*      */   private QueryTranslatorImpl superQuery;
/*      */   private QueryableCollection collectionPersister;
/*  111 */   private int collectionOwnerColumn = -1;
/*      */   
/*      */   private String collectionOwnerName;
/*      */   
/*      */   private String fetchName;
/*      */   
/*      */   private String[] suffixes;
/*      */   private Map enabledFilters;
/*  119 */   private static final Log log = LogFactory.getLog(QueryTranslatorImpl.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public QueryTranslatorImpl(String queryIdentifier, String queryString, Map enabledFilters, SessionFactoryImplementor factory)
/*      */   {
/*  129 */     super(factory);
/*  130 */     this.queryIdentifier = queryIdentifier;
/*  131 */     this.queryString = queryString;
/*  132 */     this.enabledFilters = enabledFilters;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public QueryTranslatorImpl(String queryString, Map enabledFilters, SessionFactoryImplementor factory)
/*      */   {
/*  142 */     this(queryString, queryString, enabledFilters, factory);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void compile(QueryTranslatorImpl superquery)
/*      */     throws QueryException, MappingException
/*      */   {
/*  150 */     this.tokenReplacements = superquery.tokenReplacements;
/*  151 */     this.superQuery = superquery;
/*  152 */     this.shallowQuery = true;
/*  153 */     this.enabledFilters = superquery.getEnabledFilters();
/*  154 */     compile();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void compile(Map replacements, boolean scalar)
/*      */     throws QueryException, MappingException
/*      */   {
/*  164 */     if (!this.compiled) {
/*  165 */       this.tokenReplacements = replacements;
/*  166 */       this.shallowQuery = scalar;
/*  167 */       compile();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void compile(String collectionRole, Map replacements, boolean scalar)
/*      */     throws QueryException, MappingException
/*      */   {
/*  178 */     if (!isCompiled()) {
/*  179 */       addFromAssociation("this", collectionRole);
/*  180 */       compile(replacements, scalar);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void compile()
/*      */     throws QueryException, MappingException
/*      */   {
/*  189 */     log.trace("compiling query");
/*      */     try {
/*  191 */       ParserHelper.parse(new PreprocessingParser(this.tokenReplacements), this.queryString, " \n\r\f\t,()=<>&|+-=/*'^![]#~\\", this);
/*      */       
/*      */ 
/*      */ 
/*  195 */       renderSQL();
/*      */     }
/*      */     catch (QueryException qe) {
/*  198 */       qe.setQueryString(this.queryString);
/*  199 */       throw qe;
/*      */     }
/*      */     catch (MappingException me) {
/*  202 */       throw me;
/*      */     }
/*      */     catch (Exception e) {
/*  205 */       log.debug("unexpected query compilation problem", e);
/*  206 */       e.printStackTrace();
/*  207 */       QueryException qe = new QueryException("Incorrect query syntax", e);
/*  208 */       qe.setQueryString(this.queryString);
/*  209 */       throw qe;
/*      */     }
/*      */     
/*  212 */     postInstantiate();
/*      */     
/*  214 */     this.compiled = true;
/*      */   }
/*      */   
/*      */   public String getSQLString()
/*      */   {
/*  219 */     return this.sqlString;
/*      */   }
/*      */   
/*      */   public List collectSqlStrings() {
/*  223 */     return ArrayHelper.toList(new String[] { this.sqlString });
/*      */   }
/*      */   
/*      */   public String getQueryString() {
/*  227 */     return this.queryString;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Loadable[] getEntityPersisters()
/*      */   {
/*  236 */     return this.persisters;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Type[] getReturnTypes()
/*      */   {
/*  245 */     return this.actualReturnTypes;
/*      */   }
/*      */   
/*      */   public String[] getReturnAliases()
/*      */   {
/*  250 */     return NO_RETURN_ALIASES;
/*      */   }
/*      */   
/*      */   public String[][] getColumnNames() {
/*  254 */     return this.scalarColumnNames;
/*      */   }
/*      */   
/*      */   private static void logQuery(String hql, String sql) {
/*  258 */     if (log.isDebugEnabled()) {
/*  259 */       log.debug("HQL: " + hql);
/*  260 */       log.debug("SQL: " + sql);
/*      */     }
/*      */   }
/*      */   
/*      */   void setAliasName(String alias, String name) {
/*  265 */     this.aliasNames.put(alias, name);
/*      */   }
/*      */   
/*      */   public String getAliasName(String alias) {
/*  269 */     String name = (String)this.aliasNames.get(alias);
/*  270 */     if (name == null) {
/*  271 */       if (this.superQuery != null) {
/*  272 */         name = this.superQuery.getAliasName(alias);
/*      */       }
/*      */       else {
/*  275 */         name = alias;
/*      */       }
/*      */     }
/*  278 */     return name;
/*      */   }
/*      */   
/*      */   String unalias(String path) {
/*  282 */     String alias = StringHelper.root(path);
/*  283 */     String name = getAliasName(alias);
/*  284 */     if (name != null) {
/*  285 */       return name + path.substring(alias.length());
/*      */     }
/*      */     
/*  288 */     return path;
/*      */   }
/*      */   
/*      */   void addEntityToFetch(String name, String oneToOneOwnerName, AssociationType ownerAssociationType)
/*      */   {
/*  293 */     addEntityToFetch(name);
/*  294 */     if (oneToOneOwnerName != null) this.oneToOneOwnerNames.put(name, oneToOneOwnerName);
/*  295 */     if (ownerAssociationType != null) this.uniqueKeyOwnerReferences.put(name, ownerAssociationType);
/*      */   }
/*      */   
/*      */   private void addEntityToFetch(String name) {
/*  299 */     this.entitiesToFetch.add(name);
/*      */   }
/*      */   
/*      */   private int nextCount() {
/*  303 */     return this.superQuery == null ? this.nameCount++ : this.superQuery.nameCount++;
/*      */   }
/*      */   
/*      */   String createNameFor(String type) {
/*  307 */     return StringHelper.generateAlias(type, nextCount());
/*      */   }
/*      */   
/*      */   String createNameForCollection(String role) {
/*  311 */     return StringHelper.generateAlias(role, nextCount());
/*      */   }
/*      */   
/*      */   private String getType(String name) {
/*  315 */     String type = (String)this.typeMap.get(name);
/*  316 */     if ((type == null) && (this.superQuery != null)) {
/*  317 */       type = this.superQuery.getType(name);
/*      */     }
/*  319 */     return type;
/*      */   }
/*      */   
/*      */   private String getRole(String name) {
/*  323 */     String role = (String)this.collections.get(name);
/*  324 */     if ((role == null) && (this.superQuery != null)) {
/*  325 */       role = this.superQuery.getRole(name);
/*      */     }
/*  327 */     return role;
/*      */   }
/*      */   
/*      */   boolean isName(String name) {
/*  331 */     return (this.aliasNames.containsKey(name)) || (this.typeMap.containsKey(name)) || (this.collections.containsKey(name)) || ((this.superQuery != null) && (this.superQuery.isName(name)));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   PropertyMapping getPropertyMapping(String name)
/*      */     throws QueryException
/*      */   {
/*  339 */     PropertyMapping decorator = getDecoratedPropertyMapping(name);
/*  340 */     if (decorator != null) { return decorator;
/*      */     }
/*  342 */     String type = getType(name);
/*  343 */     if (type == null) {
/*  344 */       String role = getRole(name);
/*  345 */       if (role == null) {
/*  346 */         throw new QueryException("alias not found: " + name);
/*      */       }
/*  348 */       return getCollectionPersister(role);
/*      */     }
/*      */     
/*  351 */     Queryable persister = getEntityPersister(type);
/*  352 */     if (persister == null) throw new QueryException("persistent class not found: " + type);
/*  353 */     return persister;
/*      */   }
/*      */   
/*      */   private PropertyMapping getDecoratedPropertyMapping(String name)
/*      */   {
/*  358 */     return (PropertyMapping)this.decoratedPropertyMappings.get(name);
/*      */   }
/*      */   
/*      */   void decoratePropertyMapping(String name, PropertyMapping mapping) {
/*  362 */     this.decoratedPropertyMappings.put(name, mapping);
/*      */   }
/*      */   
/*      */   private Queryable getEntityPersisterForName(String name) throws QueryException {
/*  366 */     String type = getType(name);
/*  367 */     Queryable persister = getEntityPersister(type);
/*  368 */     if (persister == null) throw new QueryException("persistent class not found: " + type);
/*  369 */     return persister;
/*      */   }
/*      */   
/*      */   Queryable getEntityPersisterUsingImports(String className) {
/*  373 */     String importedClassName = getFactory().getImportedClassName(className);
/*  374 */     if (importedClassName == null) {
/*  375 */       return null;
/*      */     }
/*      */     try {
/*  378 */       return (Queryable)getFactory().getEntityPersister(importedClassName);
/*      */     }
/*      */     catch (MappingException me) {}
/*  381 */     return null;
/*      */   }
/*      */   
/*      */   Queryable getEntityPersister(String entityName) throws QueryException
/*      */   {
/*      */     try {
/*  387 */       return (Queryable)getFactory().getEntityPersister(entityName);
/*      */     }
/*      */     catch (Exception e) {
/*  390 */       throw new QueryException("persistent class not found: " + entityName);
/*      */     }
/*      */   }
/*      */   
/*      */   QueryableCollection getCollectionPersister(String role) throws QueryException {
/*      */     try {
/*  396 */       return (QueryableCollection)getFactory().getCollectionPersister(role);
/*      */     }
/*      */     catch (ClassCastException cce) {
/*  399 */       throw new QueryException("collection role is not queryable: " + role);
/*      */     }
/*      */     catch (Exception e) {
/*  402 */       throw new QueryException("collection role not found: " + role);
/*      */     }
/*      */   }
/*      */   
/*      */   void addType(String name, String type) {
/*  407 */     this.typeMap.put(name, type);
/*      */   }
/*      */   
/*      */   void addCollection(String name, String role) {
/*  411 */     this.collections.put(name, role);
/*      */   }
/*      */   
/*      */   void addFrom(String name, String type, JoinSequence joinSequence) throws QueryException
/*      */   {
/*  416 */     addType(name, type);
/*  417 */     addFrom(name, joinSequence);
/*      */   }
/*      */   
/*      */   void addFromCollection(String name, String collectionRole, JoinSequence joinSequence)
/*      */     throws QueryException
/*      */   {
/*  423 */     addCollection(name, collectionRole);
/*  424 */     addJoin(name, joinSequence);
/*      */   }
/*      */   
/*      */   void addFrom(String name, JoinSequence joinSequence) throws QueryException
/*      */   {
/*  429 */     this.fromTypes.add(name);
/*  430 */     addJoin(name, joinSequence);
/*      */   }
/*      */   
/*      */   void addFromClass(String name, Queryable classPersister) throws QueryException
/*      */   {
/*  435 */     JoinSequence joinSequence = new JoinSequence(getFactory()).setRoot(classPersister, name);
/*      */     
/*      */ 
/*  438 */     addFrom(name, classPersister.getEntityName(), joinSequence);
/*      */   }
/*      */   
/*      */   void addSelectClass(String name) {
/*  442 */     this.returnedTypes.add(name);
/*      */   }
/*      */   
/*      */   void addSelectScalar(Type type) {
/*  446 */     this.scalarTypes.add(type);
/*      */   }
/*      */   
/*      */   void appendWhereToken(String token) {
/*  450 */     this.whereTokens.add(token);
/*      */   }
/*      */   
/*      */   void appendHavingToken(String token) {
/*  454 */     this.havingTokens.add(token);
/*      */   }
/*      */   
/*      */   void appendOrderByToken(String token) {
/*  458 */     this.orderByTokens.add(token);
/*      */   }
/*      */   
/*      */   void appendGroupByToken(String token) {
/*  462 */     this.groupByTokens.add(token);
/*      */   }
/*      */   
/*      */   void appendScalarSelectToken(String token) {
/*  466 */     this.scalarSelectTokens.add(token);
/*      */   }
/*      */   
/*      */   void appendScalarSelectTokens(String[] tokens) {
/*  470 */     this.scalarSelectTokens.add(tokens);
/*      */   }
/*      */   
/*      */   void addFromJoinOnly(String name, JoinSequence joinSequence) throws QueryException {
/*  474 */     addJoin(name, joinSequence.getFromPart());
/*      */   }
/*      */   
/*      */   void addJoin(String name, JoinSequence joinSequence) throws QueryException {
/*  478 */     if (!this.joins.containsKey(name)) this.joins.put(name, joinSequence);
/*      */   }
/*      */   
/*      */   void addNamedParameter(String name) {
/*  482 */     if (this.superQuery != null) this.superQuery.addNamedParameter(name);
/*  483 */     Integer loc = new Integer(this.parameterCount++);
/*  484 */     Object o = this.namedParameters.get(name);
/*  485 */     if (o == null) {
/*  486 */       this.namedParameters.put(name, loc);
/*      */     }
/*  488 */     else if ((o instanceof Integer)) {
/*  489 */       ArrayList list = new ArrayList(4);
/*  490 */       list.add(o);
/*  491 */       list.add(loc);
/*  492 */       this.namedParameters.put(name, list);
/*      */     }
/*      */     else {
/*  495 */       ((ArrayList)o).add(loc);
/*      */     }
/*      */   }
/*      */   
/*      */   public int[] getNamedParameterLocs(String name) throws QueryException {
/*  500 */     Object o = this.namedParameters.get(name);
/*  501 */     if (o == null) {
/*  502 */       QueryException qe = new QueryException("Named parameter does not appear in Query: " + name);
/*  503 */       qe.setQueryString(this.queryString);
/*  504 */       throw qe;
/*      */     }
/*  506 */     if ((o instanceof Integer)) {
/*  507 */       return new int[] { ((Integer)o).intValue() };
/*      */     }
/*      */     
/*  510 */     return ArrayHelper.toIntArray((ArrayList)o);
/*      */   }
/*      */   
/*      */   private void renderSQL() throws QueryException, MappingException
/*      */   {
/*      */     int rtsize;
/*      */     int rtsize;
/*  517 */     if ((this.returnedTypes.size() == 0) && (this.scalarTypes.size() == 0))
/*      */     {
/*  519 */       this.returnedTypes = this.fromTypes;
/*  520 */       rtsize = this.returnedTypes.size();
/*      */     }
/*      */     else {
/*  523 */       rtsize = this.returnedTypes.size();
/*  524 */       Iterator iter = this.entitiesToFetch.iterator();
/*  525 */       while (iter.hasNext()) {
/*  526 */         this.returnedTypes.add(iter.next());
/*      */       }
/*      */     }
/*  529 */     int size = this.returnedTypes.size();
/*  530 */     this.persisters = new Queryable[size];
/*  531 */     this.names = new String[size];
/*  532 */     this.owners = new int[size];
/*  533 */     this.ownerAssociationTypes = new EntityType[size];
/*  534 */     this.suffixes = new String[size];
/*  535 */     this.includeInSelect = new boolean[size];
/*  536 */     for (int i = 0; i < size; i++) {
/*  537 */       String name = (String)this.returnedTypes.get(i);
/*      */       
/*  539 */       this.persisters[i] = getEntityPersisterForName(name);
/*      */       
/*  541 */       this.suffixes[i] = (Integer.toString(i) + '_');
/*  542 */       this.names[i] = name;
/*  543 */       this.includeInSelect[i] = (!this.entitiesToFetch.contains(name) ? 1 : false);
/*  544 */       if (this.includeInSelect[i] != 0) this.selectLength += 1;
/*  545 */       if (name.equals(this.collectionOwnerName)) this.collectionOwnerColumn = i;
/*  546 */       String oneToOneOwner = (String)this.oneToOneOwnerNames.get(name);
/*  547 */       this.owners[i] = (oneToOneOwner == null ? -1 : this.returnedTypes.indexOf(oneToOneOwner));
/*  548 */       this.ownerAssociationTypes[i] = ((EntityType)this.uniqueKeyOwnerReferences.get(name));
/*      */     }
/*      */     
/*  551 */     if (ArrayHelper.isAllNegative(this.owners)) { this.owners = null;
/*      */     }
/*  553 */     String scalarSelect = renderScalarSelect();
/*      */     
/*  555 */     int scalarSize = this.scalarTypes.size();
/*  556 */     this.hasScalars = (this.scalarTypes.size() != rtsize);
/*      */     
/*  558 */     this.returnTypes = new Type[scalarSize];
/*  559 */     for (int i = 0; i < scalarSize; i++) {
/*  560 */       this.returnTypes[i] = ((Type)this.scalarTypes.get(i));
/*      */     }
/*      */     
/*  563 */     QuerySelect sql = new QuerySelect(getFactory().getDialect());
/*  564 */     sql.setDistinct(this.distinct);
/*      */     
/*  566 */     if (!this.shallowQuery) {
/*  567 */       renderIdentifierSelect(sql);
/*  568 */       renderPropertiesSelect(sql);
/*      */     }
/*      */     
/*  571 */     if (this.collectionPersister != null) {
/*  572 */       sql.addSelectFragmentString(this.collectionPersister.selectFragment(this.fetchName, "__"));
/*      */     }
/*      */     
/*  575 */     if ((this.hasScalars) || (this.shallowQuery)) { sql.addSelectFragmentString(scalarSelect);
/*      */     }
/*      */     
/*  578 */     mergeJoins(sql.getJoinFragment());
/*      */     
/*  580 */     sql.setWhereTokens(this.whereTokens.iterator());
/*      */     
/*  582 */     sql.setGroupByTokens(this.groupByTokens.iterator());
/*  583 */     sql.setHavingTokens(this.havingTokens.iterator());
/*  584 */     sql.setOrderByTokens(this.orderByTokens.iterator());
/*      */     
/*  586 */     if ((this.collectionPersister != null) && (this.collectionPersister.hasOrdering())) {
/*  587 */       sql.addOrderBy(this.collectionPersister.getSQLOrderByString(this.fetchName));
/*      */     }
/*      */     
/*  590 */     this.scalarColumnNames = NameGenerator.generateColumnNames(this.returnTypes, getFactory());
/*      */     
/*      */ 
/*  593 */     Iterator iter = this.collections.values().iterator();
/*  594 */     while (iter.hasNext()) {
/*  595 */       CollectionPersister p = getCollectionPersister((String)iter.next());
/*  596 */       addQuerySpaces(p.getCollectionSpaces());
/*      */     }
/*  598 */     iter = this.typeMap.keySet().iterator();
/*  599 */     while (iter.hasNext()) {
/*  600 */       Queryable p = getEntityPersisterForName((String)iter.next());
/*  601 */       addQuerySpaces(p.getQuerySpaces());
/*      */     }
/*      */     
/*  604 */     this.sqlString = sql.toQueryString();
/*      */     
/*  606 */     if (this.holderClass != null) { this.holderConstructor = ReflectHelper.getConstructor(this.holderClass, this.returnTypes);
/*      */     }
/*  608 */     if (this.hasScalars) {
/*  609 */       this.actualReturnTypes = this.returnTypes;
/*      */     }
/*      */     else {
/*  612 */       this.actualReturnTypes = new Type[this.selectLength];
/*  613 */       int j = 0;
/*  614 */       for (int i = 0; i < this.persisters.length; i++) {
/*  615 */         if (this.includeInSelect[i] != 0) {
/*  616 */           this.actualReturnTypes[(j++)] = TypeFactory.manyToOne(this.persisters[i].getEntityName(), this.shallowQuery);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void renderIdentifierSelect(QuerySelect sql)
/*      */   {
/*  624 */     int size = this.returnedTypes.size();
/*      */     
/*  626 */     for (int k = 0; k < size; k++) {
/*  627 */       String name = (String)this.returnedTypes.get(k);
/*  628 */       String suffix = Integer.toString(k) + '_';
/*  629 */       sql.addSelectFragmentString(this.persisters[k].identifierSelectFragment(name, suffix));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void renderPropertiesSelect(QuerySelect sql)
/*      */   {
/*  651 */     int size = this.returnedTypes.size();
/*  652 */     for (int k = 0; k < size; k++) {
/*  653 */       String suffix = Integer.toString(k) + '_';
/*  654 */       String name = (String)this.returnedTypes.get(k);
/*  655 */       sql.addSelectFragmentString(this.persisters[k].propertySelectFragment(name, suffix, false));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String renderScalarSelect()
/*      */   {
/*  664 */     boolean isSubselect = this.superQuery != null;
/*      */     
/*  666 */     StringBuffer buf = new StringBuffer(20);
/*      */     
/*  668 */     if (this.scalarTypes.size() == 0)
/*      */     {
/*  670 */       int size = this.returnedTypes.size();
/*  671 */       for (int k = 0; k < size; k++)
/*      */       {
/*  673 */         this.scalarTypes.add(TypeFactory.manyToOne(this.persisters[k].getEntityName(), this.shallowQuery));
/*      */         
/*  675 */         String[] idColumnNames = this.persisters[k].getIdentifierColumnNames();
/*  676 */         for (int i = 0; i < idColumnNames.length; i++) {
/*  677 */           buf.append(this.returnedTypes.get(k)).append('.').append(idColumnNames[i]);
/*  678 */           if (!isSubselect) buf.append(" as ").append(NameGenerator.scalarName(k, i));
/*  679 */           if ((i != idColumnNames.length - 1) || (k != size - 1)) { buf.append(", ");
/*      */           }
/*      */           
/*      */         }
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  687 */       Iterator iter = this.scalarSelectTokens.iterator();
/*  688 */       int c = 0;
/*  689 */       boolean nolast = false;
/*  690 */       int parenCount = 0;
/*  691 */       while (iter.hasNext()) {
/*  692 */         Object next = iter.next();
/*  693 */         if ((next instanceof String)) {
/*  694 */           String token = (String)next;
/*      */           
/*  696 */           if ("(".equals(token)) {
/*  697 */             parenCount++;
/*      */           }
/*  699 */           else if (")".equals(token)) {
/*  700 */             parenCount--;
/*      */           }
/*      */           
/*  703 */           String lc = token.toLowerCase();
/*  704 */           if (lc.equals(", ")) {
/*  705 */             if (nolast) {
/*  706 */               nolast = false;
/*      */ 
/*      */             }
/*  709 */             else if ((!isSubselect) && (parenCount == 0)) {
/*  710 */               int x = c++;
/*  711 */               buf.append(" as ").append(NameGenerator.scalarName(x, 0));
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*  716 */           buf.append(token);
/*  717 */           if ((lc.equals("distinct")) || (lc.equals("all"))) {
/*  718 */             buf.append(' ');
/*      */           }
/*      */         }
/*      */         else {
/*  722 */           nolast = true;
/*  723 */           String[] tokens = (String[])next;
/*  724 */           for (int i = 0; i < tokens.length; i++) {
/*  725 */             buf.append(tokens[i]);
/*  726 */             if (!isSubselect) {
/*  727 */               buf.append(" as ").append(NameGenerator.scalarName(c, i));
/*      */             }
/*      */             
/*  730 */             if (i != tokens.length - 1) buf.append(", ");
/*      */           }
/*  732 */           c++;
/*      */         }
/*      */       }
/*  735 */       if ((!isSubselect) && (!nolast)) {
/*  736 */         int x = c++;
/*  737 */         buf.append(" as ").append(NameGenerator.scalarName(x, 0));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  743 */     return buf.toString();
/*      */   }
/*      */   
/*      */   private void mergeJoins(JoinFragment ojf) throws MappingException, QueryException
/*      */   {
/*  748 */     Iterator iter = this.joins.entrySet().iterator();
/*  749 */     while (iter.hasNext()) {
/*  750 */       Map.Entry me = (Map.Entry)iter.next();
/*  751 */       String name = (String)me.getKey();
/*  752 */       JoinSequence join = (JoinSequence)me.getValue();
/*  753 */       join.setSelector(new JoinSequence.Selector() {
/*      */         public boolean includeSubclasses(String alias) {
/*  755 */           boolean include = (QueryTranslatorImpl.this.returnedTypes.contains(alias)) && (!QueryTranslatorImpl.this.isShallowQuery());
/*  756 */           return include;
/*      */         }
/*      */       });
/*      */       
/*  760 */       if (this.typeMap.containsKey(name)) {
/*  761 */         ojf.addFragment(join.toJoinFragment(this.enabledFilters, true));
/*      */       }
/*  763 */       else if (this.collections.containsKey(name)) {
/*  764 */         ojf.addFragment(join.toJoinFragment(this.enabledFilters, true));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Set getQuerySpaces()
/*      */   {
/*  775 */     return this.querySpaces;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isShallowQuery()
/*      */   {
/*  784 */     return this.shallowQuery;
/*      */   }
/*      */   
/*      */   void addQuerySpaces(Serializable[] spaces) {
/*  788 */     for (int i = 0; i < spaces.length; i++) {
/*  789 */       this.querySpaces.add(spaces[i]);
/*      */     }
/*  791 */     if (this.superQuery != null) this.superQuery.addQuerySpaces(spaces);
/*      */   }
/*      */   
/*      */   void setDistinct(boolean distinct) {
/*  795 */     this.distinct = distinct;
/*      */   }
/*      */   
/*      */   boolean isSubquery() {
/*  799 */     return this.superQuery != null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public CollectionPersister[] getCollectionPersisters()
/*      */   {
/*  806 */     return new CollectionPersister[] { this.collectionPersister == null ? null : this.collectionPersister };
/*      */   }
/*      */   
/*      */   protected String[] getCollectionSuffixes() {
/*  810 */     return new String[] { this.collectionPersister == null ? null : "__" };
/*      */   }
/*      */   
/*      */   void setCollectionToFetch(String role, String name, String ownerName, String entityName) throws QueryException
/*      */   {
/*  815 */     this.fetchName = name;
/*  816 */     this.collectionPersister = getCollectionPersister(role);
/*  817 */     this.collectionOwnerName = ownerName;
/*  818 */     if (this.collectionPersister.getElementType().isEntityType()) {
/*  819 */       addEntityToFetch(entityName);
/*      */     }
/*      */   }
/*      */   
/*      */   protected String[] getSuffixes() {
/*  824 */     return this.suffixes;
/*      */   }
/*      */   
/*      */   protected String[] getAliases() {
/*  828 */     return this.names;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addFromAssociation(String elementName, String collectionRole)
/*      */     throws QueryException
/*      */   {
/*  837 */     QueryableCollection persister = getCollectionPersister(collectionRole);
/*  838 */     Type collectionElementType = persister.getElementType();
/*  839 */     if (!collectionElementType.isEntityType()) {
/*  840 */       throw new QueryException("collection of values in filter: " + elementName);
/*      */     }
/*      */     
/*  843 */     String[] keyColumnNames = persister.getKeyColumnNames();
/*      */     
/*      */ 
/*      */ 
/*  847 */     JoinSequence join = new JoinSequence(getFactory());
/*  848 */     String collectionName = persister.isOneToMany() ? elementName : createNameForCollection(collectionRole);
/*      */     
/*      */ 
/*  851 */     join.setRoot(persister, collectionName);
/*  852 */     if (!persister.isOneToMany())
/*      */     {
/*  854 */       addCollection(collectionName, collectionRole);
/*      */       try {
/*  856 */         join.addJoin((AssociationType)persister.getElementType(), elementName, 0, persister.getElementColumnNames(collectionName));
/*      */ 
/*      */       }
/*      */       catch (MappingException me)
/*      */       {
/*      */ 
/*  862 */         throw new QueryException(me);
/*      */       }
/*      */     }
/*  865 */     join.addCondition(collectionName, keyColumnNames, " = ?");
/*      */     
/*  867 */     EntityType elemType = (EntityType)collectionElementType;
/*  868 */     addFrom(elementName, elemType.getAssociatedEntityName(), join);
/*      */   }
/*      */   
/*      */   String getPathAlias(String path)
/*      */   {
/*  873 */     return (String)this.pathAliases.get(path);
/*      */   }
/*      */   
/*      */   JoinSequence getPathJoin(String path) {
/*  877 */     return (JoinSequence)this.pathJoins.get(path);
/*      */   }
/*      */   
/*      */   void addPathAliasAndJoin(String path, String alias, JoinSequence joinSequence) {
/*  881 */     this.pathAliases.put(path, alias);
/*  882 */     this.pathJoins.put(path, joinSequence);
/*      */   }
/*      */   
/*      */   public List list(SessionImplementor session, QueryParameters queryParameters) throws HibernateException
/*      */   {
/*  887 */     return list(session, queryParameters, getQuerySpaces(), this.actualReturnTypes);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Iterator iterate(QueryParameters queryParameters, EventSource session)
/*      */     throws HibernateException
/*      */   {
/*  896 */     boolean stats = session.getFactory().getStatistics().isStatisticsEnabled();
/*  897 */     long startTime = 0L;
/*  898 */     if (stats) { startTime = System.currentTimeMillis();
/*      */     }
/*      */     try
/*      */     {
/*  902 */       PreparedStatement st = prepareQueryStatement(queryParameters, false, session);
/*  903 */       ResultSet rs = getResultSet(st, queryParameters.hasAutoDiscoverScalarTypes(), false, queryParameters.getRowSelection(), session);
/*  904 */       HolderInstantiator hi = new HolderInstantiator(this.holderConstructor, false, false, null);
/*  905 */       Iterator result = new IteratorImpl(rs, st, session, this.returnTypes, getColumnNames(), hi);
/*      */       
/*  907 */       if (stats) {
/*  908 */         session.getFactory().getStatisticsImplementor().queryExecuted("HQL: " + this.queryString, 0, System.currentTimeMillis() - startTime);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  915 */       return result;
/*      */     }
/*      */     catch (SQLException sqle)
/*      */     {
/*  919 */       throw JDBCExceptionHelper.convert(getFactory().getSQLExceptionConverter(), sqle, "could not execute query using iterate", getSQLString());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int executeUpdate(QueryParameters queryParameters, SessionImplementor session)
/*      */     throws HibernateException
/*      */   {
/*  930 */     throw new UnsupportedOperationException("Not supported!  Use the AST translator...");
/*      */   }
/*      */   
/*      */   protected Object getResultColumnOrRow(Object[] row, ResultSet rs, SessionImplementor session) throws SQLException, HibernateException
/*      */   {
/*  935 */     row = toResultRow(row);
/*  936 */     if (this.hasScalars) {
/*  937 */       String[][] scalarColumns = getColumnNames();
/*  938 */       int queryCols = this.returnTypes.length;
/*  939 */       if ((this.holderClass == null) && (queryCols == 1)) {
/*  940 */         return this.returnTypes[0].nullSafeGet(rs, scalarColumns[0], session, null);
/*      */       }
/*      */       
/*  943 */       row = new Object[queryCols];
/*  944 */       for (int i = 0; i < queryCols; i++)
/*  945 */         row[i] = this.returnTypes[i].nullSafeGet(rs, scalarColumns[i], session, null);
/*  946 */       return row;
/*      */     }
/*      */     
/*  949 */     if (this.holderClass == null) {
/*  950 */       return row.length == 1 ? row[0] : row;
/*      */     }
/*      */     
/*  953 */     return row;
/*      */   }
/*      */   
/*      */   protected List getResultList(List results)
/*      */     throws QueryException
/*      */   {
/*  959 */     if (this.holderClass != null) {
/*  960 */       for (int i = 0; i < results.size(); i++) {
/*  961 */         Object[] row = (Object[])results.get(i);
/*      */         try {
/*  963 */           results.set(i, this.holderConstructor.newInstance(row));
/*      */         }
/*      */         catch (Exception e) {
/*  966 */           throw new QueryException("could not instantiate: " + this.holderClass, e);
/*      */         }
/*      */       }
/*      */     }
/*  970 */     return results;
/*      */   }
/*      */   
/*      */   private Object[] toResultRow(Object[] row) {
/*  974 */     if (this.selectLength == row.length) {
/*  975 */       return row;
/*      */     }
/*      */     
/*  978 */     Object[] result = new Object[this.selectLength];
/*  979 */     int j = 0;
/*  980 */     for (int i = 0; i < row.length; i++) {
/*  981 */       if (this.includeInSelect[i] != 0) result[(j++)] = row[i];
/*      */     }
/*  983 */     return result;
/*      */   }
/*      */   
/*      */   void setHolderClass(Class clazz)
/*      */   {
/*  988 */     this.holderClass = clazz;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected LockMode[] getLockModes(Map lockModes)
/*      */   {
/*  995 */     HashMap nameLockModes = new HashMap();
/*  996 */     if (lockModes != null) {
/*  997 */       Iterator iter = lockModes.entrySet().iterator();
/*  998 */       while (iter.hasNext()) {
/*  999 */         Map.Entry me = (Map.Entry)iter.next();
/* 1000 */         nameLockModes.put(getAliasName((String)me.getKey()), me.getValue());
/*      */       }
/*      */     }
/*      */     
/* 1004 */     LockMode[] lockModeArray = new LockMode[this.names.length];
/* 1005 */     for (int i = 0; i < this.names.length; i++) {
/* 1006 */       LockMode lm = (LockMode)nameLockModes.get(this.names[i]);
/* 1007 */       if (lm == null) lm = LockMode.NONE;
/* 1008 */       lockModeArray[i] = lm;
/*      */     }
/* 1010 */     return lockModeArray;
/*      */   }
/*      */   
/*      */   protected String applyLocks(String sql, Map lockModes, Dialect dialect) throws QueryException {
/*      */     String result;
/*      */     String result;
/* 1016 */     if ((lockModes == null) || (lockModes.size() == 0)) {
/* 1017 */       result = sql;
/*      */     }
/*      */     else {
/* 1020 */       Map aliasedLockModes = new HashMap();
/* 1021 */       Iterator iter = lockModes.entrySet().iterator();
/* 1022 */       while (iter.hasNext()) {
/* 1023 */         Map.Entry me = (Map.Entry)iter.next();
/* 1024 */         aliasedLockModes.put(getAliasName((String)me.getKey()), me.getValue());
/*      */       }
/* 1026 */       Map keyColumnNames = null;
/* 1027 */       if (dialect.forUpdateOfColumns()) {
/* 1028 */         keyColumnNames = new HashMap();
/* 1029 */         for (int i = 0; i < this.names.length; i++) {
/* 1030 */           keyColumnNames.put(this.names[i], this.persisters[i].getIdentifierColumnNames());
/*      */         }
/*      */       }
/* 1033 */       result = sql + new ForUpdateFragment(dialect, aliasedLockModes, keyColumnNames).toFragmentString();
/*      */     }
/* 1035 */     logQuery(this.queryString, result);
/* 1036 */     return result;
/*      */   }
/*      */   
/*      */   protected boolean upgradeLocks() {
/* 1040 */     return true;
/*      */   }
/*      */   
/*      */   protected int[] getCollectionOwners() {
/* 1044 */     return new int[] { this.collectionOwnerColumn };
/*      */   }
/*      */   
/*      */   protected boolean isCompiled() {
/* 1048 */     return this.compiled;
/*      */   }
/*      */   
/*      */   public String toString() {
/* 1052 */     return this.queryString;
/*      */   }
/*      */   
/*      */   protected int[] getOwners() {
/* 1056 */     return this.owners;
/*      */   }
/*      */   
/*      */   protected EntityType[] getOwnerAssociationTypes() {
/* 1060 */     return this.ownerAssociationTypes;
/*      */   }
/*      */   
/*      */   public Class getHolderClass() {
/* 1064 */     return this.holderClass;
/*      */   }
/*      */   
/*      */   public Map getEnabledFilters() {
/* 1068 */     return this.enabledFilters;
/*      */   }
/*      */   
/*      */   public ScrollableResults scroll(QueryParameters queryParameters, SessionImplementor session)
/*      */     throws HibernateException
/*      */   {
/* 1074 */     HolderInstantiator hi = new HolderInstantiator(this.holderConstructor, false, false, null);
/* 1075 */     return scroll(queryParameters, this.returnTypes, hi, session);
/*      */   }
/*      */   
/*      */   public String getQueryIdentifier() {
/* 1079 */     return this.queryIdentifier;
/*      */   }
/*      */   
/*      */   protected boolean isSubselectLoadingEnabled() {
/* 1083 */     return hasSubselectLoadableCollections();
/*      */   }
/*      */   
/*      */   public void validateScrollability() throws HibernateException
/*      */   {
/* 1088 */     if (getCollectionPersisters() != null) {
/* 1089 */       throw new HibernateException("Cannot scroll queries which initialize collections");
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean containsCollectionFetches() {
/* 1094 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isManipulationStatement()
/*      */   {
/* 1099 */     return false;
/*      */   }
/*      */   
/*      */   public ParameterTranslations getParameterTranslations() {
/* 1103 */     new ParameterTranslations()
/*      */     {
/*      */ 
/*      */       public boolean supportsOrdinalParameterMetadata()
/*      */       {
/* 1108 */         return false;
/*      */       }
/*      */       
/*      */       public int getOrdinalParameterCount() {
/* 1112 */         return 0;
/*      */       }
/*      */       
/*      */       public int getOrdinalParameterSqlLocation(int ordinalPosition) {
/* 1116 */         return 0;
/*      */       }
/*      */       
/*      */       public Type getOrdinalParameterExpectedType(int ordinalPosition) {
/* 1120 */         return null;
/*      */       }
/*      */       
/*      */       public Set getNamedParameterNames() {
/* 1124 */         return QueryTranslatorImpl.this.namedParameters.keySet();
/*      */       }
/*      */       
/*      */       public int[] getNamedParameterSqlLocations(String name) {
/* 1128 */         return QueryTranslatorImpl.this.getNamedParameterLocs(name);
/*      */       }
/*      */       
/*      */       public Type getNamedParameterExpectedType(String name) {
/* 1132 */         return null;
/*      */       }
/*      */     };
/*      */   }
/*      */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\classic\QueryTranslatorImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */