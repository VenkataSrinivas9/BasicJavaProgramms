/*    */ package org.hibernate.hql.ast;
/*    */ 
/*    */ import antlr.RecognitionException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.QueryException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ErrorCounter
/*    */   implements ParseErrorHandler
/*    */ {
/* 17 */   private Log log = LogFactory.getLog(ErrorCounter.class);
/* 18 */   private Log hqlLog = LogFactory.getLog("org.hibernate.hql.PARSER");
/*    */   
/* 20 */   private List errorList = new ArrayList();
/* 21 */   private List warningList = new ArrayList();
/* 22 */   private List recognitionExceptions = new ArrayList();
/*    */   
/*    */   public void reportError(RecognitionException e) {
/* 25 */     reportError(e.toString());
/* 26 */     this.recognitionExceptions.add(e);
/* 27 */     if (this.log.isDebugEnabled()) {
/* 28 */       this.log.debug(e, e);
/*    */     }
/*    */   }
/*    */   
/*    */   public void reportError(String message) {
/* 33 */     this.hqlLog.error(message);
/* 34 */     this.errorList.add(message);
/*    */   }
/*    */   
/*    */   public int getErrorCount() {
/* 38 */     return this.errorList.size();
/*    */   }
/*    */   
/*    */   public void reportWarning(String message) {
/* 42 */     this.hqlLog.debug(message);
/* 43 */     this.warningList.add(message);
/*    */   }
/*    */   
/*    */   private String getErrorString() {
/* 47 */     StringBuffer buf = new StringBuffer();
/* 48 */     for (Iterator iterator = this.errorList.iterator(); iterator.hasNext();) {
/* 49 */       buf.append((String)iterator.next());
/* 50 */       if (iterator.hasNext()) { buf.append("\n");
/*    */       }
/*    */     }
/* 53 */     return buf.toString();
/*    */   }
/*    */   
/*    */   public void throwQueryException() throws QueryException {
/* 57 */     if (getErrorCount() > 0) {
/* 58 */       if (this.recognitionExceptions.size() > 0) {
/* 59 */         throw new QuerySyntaxException((RecognitionException)this.recognitionExceptions.get(0));
/*    */       }
/*    */       
/* 62 */       throw new QueryException(getErrorString());
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 67 */     if (this.log.isDebugEnabled()) {
/* 68 */       this.log.debug("throwQueryException() : no errors");
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\ErrorCounter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */