/*    */ package org.hibernate.hql.ast;
/*    */ 
/*    */ import antlr.SemanticException;
/*    */ import java.io.PrintStream;
/*    */ import java.io.PrintWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DetailedSemanticException
/*    */   extends SemanticException
/*    */ {
/*    */   private Throwable cause;
/* 16 */   private boolean showCauseMessage = true;
/*    */   
/*    */   public DetailedSemanticException(String message) {
/* 19 */     super(message);
/*    */   }
/*    */   
/*    */   public DetailedSemanticException(String s, Throwable e) {
/* 23 */     super(s);
/* 24 */     this.cause = e;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 33 */     if ((this.cause == null) || (!this.showCauseMessage)) {
/* 34 */       return super.toString();
/*    */     }
/*    */     
/* 37 */     return super.toString() + "\n[cause=" + this.cause.toString() + "]";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void printStackTrace()
/*    */   {
/* 45 */     super.printStackTrace();
/* 46 */     if (this.cause != null) {
/* 47 */       this.cause.printStackTrace();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void printStackTrace(PrintStream s)
/*    */   {
/* 57 */     super.printStackTrace(s);
/* 58 */     if (this.cause != null) {
/* 59 */       s.println("Cause:");
/* 60 */       this.cause.printStackTrace(s);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void printStackTrace(PrintWriter w)
/*    */   {
/* 70 */     super.printStackTrace(w);
/* 71 */     if (this.cause != null) {
/* 72 */       w.println("Cause:");
/* 73 */       this.cause.printStackTrace(w);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\DetailedSemanticException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */