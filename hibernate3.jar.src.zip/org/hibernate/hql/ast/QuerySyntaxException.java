/*    */ package org.hibernate.hql.ast;
/*    */ 
/*    */ import antlr.RecognitionException;
/*    */ import org.hibernate.QueryException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QuerySyntaxException
/*    */   extends QueryException
/*    */ {
/*    */   public QuerySyntaxException(RecognitionException e)
/*    */   {
/* 15 */     super(e.getMessage() + ((e.getLine() > 0) && (e.getColumn() > 0) ? " near line " + e.getLine() + ", column " + e.getColumn() : ""), e);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public QuerySyntaxException(RecognitionException e, String hql)
/*    */   {
/* 22 */     super(e.getMessage() + ((e.getLine() > 0) && (e.getColumn() > 0) ? " near line " + e.getLine() + ", column " + e.getColumn() : ""), e);
/*    */     
/*    */ 
/*    */ 
/* 26 */     setQueryString(hql);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\QuerySyntaxException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */