/*     */ package org.hibernate.hql.ast;
/*     */ 
/*     */ import antlr.ANTLRException;
/*     */ import antlr.RecognitionException;
/*     */ import antlr.TokenStreamException;
/*     */ import antlr.collections.AST;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.ScrollableResults;
/*     */ import org.hibernate.engine.QueryParameters;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.event.EventSource;
/*     */ import org.hibernate.hql.FilterTranslator;
/*     */ import org.hibernate.hql.ParameterTranslations;
/*     */ import org.hibernate.hql.antlr.HqlTokenTypes;
/*     */ import org.hibernate.hql.antlr.SqlTokenTypes;
/*     */ import org.hibernate.hql.ast.exec.BasicExecutor;
/*     */ import org.hibernate.hql.ast.exec.MultiTableDeleteExecutor;
/*     */ import org.hibernate.hql.ast.exec.MultiTableUpdateExecutor;
/*     */ import org.hibernate.hql.ast.exec.StatementExecutor;
/*     */ import org.hibernate.hql.ast.tree.FromClause;
/*     */ import org.hibernate.hql.ast.tree.FromElement;
/*     */ import org.hibernate.hql.ast.tree.InsertStatement;
/*     */ import org.hibernate.hql.ast.tree.IntoClause;
/*     */ import org.hibernate.hql.ast.tree.OrderByClause;
/*     */ import org.hibernate.hql.ast.tree.QueryNode;
/*     */ import org.hibernate.hql.ast.tree.SelectClause;
/*     */ import org.hibernate.hql.ast.tree.Statement;
/*     */ import org.hibernate.hql.ast.util.ASTPrinter;
/*     */ import org.hibernate.loader.hql.QueryLoader;
/*     */ import org.hibernate.persister.entity.Queryable;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueryTranslatorImpl
/*     */   implements FilterTranslator
/*     */ {
/*  55 */   private static final Log log = LogFactory.getLog(QueryTranslatorImpl.class);
/*  56 */   private static final Log AST_LOG = LogFactory.getLog("org.hibernate.hql.ast.AST");
/*     */   
/*     */ 
/*     */   private SessionFactoryImplementor factory;
/*     */   
/*     */ 
/*     */   private final String queryIdentifier;
/*     */   
/*     */ 
/*     */   private String hql;
/*     */   
/*     */ 
/*     */   private boolean shallowQuery;
/*     */   
/*     */   private Map tokenReplacements;
/*     */   
/*     */   private Map enabledFilters;
/*     */   
/*     */   private boolean compiled;
/*     */   
/*     */   private QueryLoader queryLoader;
/*     */   
/*     */   private StatementExecutor statementExecutor;
/*     */   
/*     */   private Statement sqlAst;
/*     */   
/*     */   private String sql;
/*     */   
/*     */   private ParameterTranslations paramTranslations;
/*     */   
/*     */ 
/*     */   public QueryTranslatorImpl(String queryIdentifier, String query, Map enabledFilters, SessionFactoryImplementor factory)
/*     */   {
/*  89 */     this.queryIdentifier = queryIdentifier;
/*  90 */     this.hql = query;
/*  91 */     this.compiled = false;
/*  92 */     this.shallowQuery = false;
/*  93 */     this.enabledFilters = enabledFilters;
/*  94 */     this.factory = factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void compile(Map replacements, boolean shallow)
/*     */     throws QueryException, MappingException
/*     */   {
/* 109 */     doCompile(replacements, shallow, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void compile(String collectionRole, Map replacements, boolean shallow)
/*     */     throws QueryException, MappingException
/*     */   {
/* 126 */     doCompile(replacements, shallow, collectionRole);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void doCompile(Map replacements, boolean shallow, String collectionRole)
/*     */   {
/* 139 */     if (this.compiled) {
/* 140 */       if (log.isDebugEnabled()) {
/* 141 */         log.debug("compile() : The query is already compiled, skipping...");
/*     */       }
/* 143 */       return;
/*     */     }
/*     */     
/*     */ 
/* 147 */     this.tokenReplacements = replacements;
/* 148 */     if (this.tokenReplacements == null) {
/* 149 */       this.tokenReplacements = new HashMap();
/*     */     }
/* 151 */     this.shallowQuery = shallow;
/*     */     
/*     */     try
/*     */     {
/* 155 */       HqlParser parser = parse(true);
/*     */       
/*     */ 
/* 158 */       HqlSqlWalker w = analyze(parser, collectionRole);
/*     */       
/* 160 */       this.sqlAst = ((Statement)w.getAST());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 173 */       if (this.sqlAst.needsExecutor()) {
/* 174 */         this.statementExecutor = buildAppropriateStatementExecutor(w);
/*     */       }
/*     */       else
/*     */       {
/* 178 */         generate((QueryNode)this.sqlAst);
/* 179 */         this.queryLoader = new QueryLoader(this, this.factory, w.getSelectClause());
/*     */       }
/*     */       
/* 182 */       this.compiled = true;
/*     */     }
/*     */     catch (QueryException qe) {
/* 185 */       qe.setQueryString(this.hql);
/* 186 */       throw qe;
/*     */     }
/*     */     catch (RecognitionException e) {
/* 189 */       throw new QuerySyntaxException(e, this.hql);
/*     */     }
/*     */     catch (ANTLRException e) {
/* 192 */       QueryException qe = new QueryException(e.getMessage(), e);
/* 193 */       qe.setQueryString(this.hql);
/* 194 */       throw qe;
/*     */     }
/*     */     
/* 197 */     this.enabledFilters = null;
/*     */   }
/*     */   
/*     */   private void generate(AST sqlAst) throws QueryException, RecognitionException {
/* 201 */     if (this.sql == null) {
/* 202 */       SqlGenerator gen = new SqlGenerator(this.factory);
/* 203 */       gen.statement(sqlAst);
/* 204 */       this.sql = gen.getSQL();
/* 205 */       if (log.isDebugEnabled()) {
/* 206 */         log.debug("HQL: " + this.hql);
/* 207 */         log.debug("SQL: " + this.sql);
/*     */       }
/* 209 */       gen.getParseErrorHandler().throwQueryException();
/*     */     }
/*     */   }
/*     */   
/*     */   private HqlSqlWalker analyze(HqlParser parser, String collectionRole) throws QueryException, RecognitionException {
/* 214 */     HqlSqlWalker w = new HqlSqlWalker(this, this.factory, parser, this.tokenReplacements, collectionRole);
/* 215 */     AST hqlAst = parser.getAST();
/*     */     
/*     */ 
/* 218 */     w.statement(hqlAst);
/*     */     
/* 220 */     if (AST_LOG.isDebugEnabled()) {
/* 221 */       ASTPrinter printer = new ASTPrinter(SqlTokenTypes.class);
/* 222 */       AST_LOG.debug(printer.showAsString(w.getAST(), "--- SQL AST ---"));
/*     */     }
/*     */     
/* 225 */     w.getParseErrorHandler().throwQueryException();
/*     */     
/* 227 */     return w;
/*     */   }
/*     */   
/*     */   private HqlParser parse(boolean filter) throws TokenStreamException, RecognitionException
/*     */   {
/* 232 */     HqlParser parser = HqlParser.getInstance(this.hql);
/* 233 */     parser.setFilter(filter);
/*     */     
/* 235 */     if (log.isDebugEnabled()) {
/* 236 */       log.debug("parse() - HQL: " + this.hql);
/*     */     }
/* 238 */     parser.statement();
/*     */     
/* 240 */     AST hqlAst = parser.getAST();
/*     */     
/* 242 */     showHqlAst(hqlAst);
/*     */     
/* 244 */     parser.getParseErrorHandler().throwQueryException();
/* 245 */     return parser;
/*     */   }
/*     */   
/*     */   void showHqlAst(AST hqlAst) {
/* 249 */     if (AST_LOG.isDebugEnabled()) {
/* 250 */       ASTPrinter printer = new ASTPrinter(HqlTokenTypes.class);
/* 251 */       printer.setShowClassNames(false);
/* 252 */       AST_LOG.debug(printer.showAsString(hqlAst, "--- HQL AST ---"));
/*     */     }
/*     */   }
/*     */   
/*     */   private void errorIfDML() throws HibernateException {
/* 257 */     if (this.sqlAst.needsExecutor()) {
/* 258 */       throw new HibernateException("Not supported for DML operations");
/*     */     }
/*     */   }
/*     */   
/*     */   private void errorIfSelect() throws HibernateException {
/* 263 */     if (!this.sqlAst.needsExecutor()) {
/* 264 */       throw new HibernateException("Not supported for select queries");
/*     */     }
/*     */   }
/*     */   
/*     */   public String getQueryIdentifier() {
/* 269 */     return this.queryIdentifier;
/*     */   }
/*     */   
/*     */   public Statement getSqlAST() {
/* 273 */     return this.sqlAst;
/*     */   }
/*     */   
/*     */   private HqlSqlWalker getWalker() {
/* 277 */     return this.sqlAst.getWalker();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Type[] getReturnTypes()
/*     */   {
/* 286 */     errorIfDML();
/* 287 */     return getWalker().getReturnTypes();
/*     */   }
/*     */   
/*     */   public String[] getReturnAliases() {
/* 291 */     errorIfDML();
/* 292 */     return getWalker().getReturnAliases();
/*     */   }
/*     */   
/*     */   public String[][] getColumnNames() {
/* 296 */     errorIfDML();
/* 297 */     return getWalker().getSelectClause().getColumnNames();
/*     */   }
/*     */   
/*     */   public Set getQuerySpaces() {
/* 301 */     return getWalker().getQuerySpaces();
/*     */   }
/*     */   
/*     */   public List list(SessionImplementor session, QueryParameters queryParameters)
/*     */     throws HibernateException
/*     */   {
/* 307 */     errorIfDML();
/* 308 */     return this.queryLoader.list(session, queryParameters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator iterate(QueryParameters queryParameters, EventSource session)
/*     */     throws HibernateException
/*     */   {
/* 317 */     errorIfDML();
/* 318 */     return this.queryLoader.iterate(queryParameters, session);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ScrollableResults scroll(QueryParameters queryParameters, SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/* 327 */     errorIfDML();
/* 328 */     return this.queryLoader.scroll(queryParameters, session);
/*     */   }
/*     */   
/*     */   public int executeUpdate(QueryParameters queryParameters, SessionImplementor session) throws HibernateException
/*     */   {
/* 333 */     errorIfSelect();
/* 334 */     return this.statementExecutor.execute(queryParameters, session);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getSQLString()
/*     */   {
/* 341 */     return this.sql;
/*     */   }
/*     */   
/*     */   public List collectSqlStrings() {
/* 345 */     ArrayList list = new ArrayList();
/* 346 */     if (isManipulationStatement()) {
/* 347 */       String[] sqlStatements = this.statementExecutor.getSqlStatements();
/* 348 */       for (int i = 0; i < sqlStatements.length; i++) {
/* 349 */         list.add(sqlStatements[i]);
/*     */       }
/*     */     }
/*     */     else {
/* 353 */       list.add(this.sql);
/*     */     }
/* 355 */     return list;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isShallowQuery()
/*     */   {
/* 361 */     return this.shallowQuery;
/*     */   }
/*     */   
/*     */   public String getQueryString() {
/* 365 */     return this.hql;
/*     */   }
/*     */   
/*     */   public Map getEnabledFilters() {
/* 369 */     return this.enabledFilters;
/*     */   }
/*     */   
/*     */   public int[] getNamedParameterLocs(String name) {
/* 373 */     return getWalker().getNamedParameterLocations(name);
/*     */   }
/*     */   
/*     */   public boolean containsCollectionFetches() {
/* 377 */     errorIfDML();
/* 378 */     List collectionFetches = ((QueryNode)this.sqlAst).getFromClause().getCollectionFetches();
/* 379 */     return (collectionFetches != null) && (collectionFetches.size() > 0);
/*     */   }
/*     */   
/*     */   public boolean isManipulationStatement() {
/* 383 */     return this.sqlAst.needsExecutor();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void validateScrollability()
/*     */     throws HibernateException
/*     */   {
/* 391 */     errorIfDML();
/*     */     
/* 393 */     QueryNode query = (QueryNode)this.sqlAst;
/*     */     
/*     */ 
/* 396 */     List collectionFetches = query.getFromClause().getCollectionFetches();
/* 397 */     if (collectionFetches.isEmpty()) {
/* 398 */       return;
/*     */     }
/*     */     
/*     */ 
/* 402 */     if (isShallowQuery()) {
/* 403 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 408 */     if (getReturnTypes().length > 1) {
/* 409 */       throw new HibernateException("cannot scroll with collection fetches and returned tuples");
/*     */     }
/*     */     
/* 412 */     FromElement owner = null;
/* 413 */     Iterator itr = query.getSelectClause().getFromElementsForLoad().iterator();
/* 414 */     while (itr.hasNext())
/*     */     {
/* 416 */       FromElement fromElement = (FromElement)itr.next();
/* 417 */       if (fromElement.getOrigin() == null) {
/* 418 */         owner = fromElement;
/* 419 */         break;
/*     */       }
/*     */     }
/*     */     
/* 423 */     if (owner == null) {
/* 424 */       throw new HibernateException("unable to locate collection fetch(es) owner for scrollability checks");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 431 */     AST primaryOrdering = query.getOrderByClause().getFirstChild();
/* 432 */     if (primaryOrdering != null)
/*     */     {
/* 434 */       String[] idColNames = owner.getQueryable().getIdentifierColumnNames();
/* 435 */       String expectedPrimaryOrderSeq = StringHelper.join(", ", StringHelper.qualify(owner.getTableAlias(), idColNames));
/*     */       
/*     */ 
/*     */ 
/* 439 */       if (!primaryOrdering.getText().startsWith(expectedPrimaryOrderSeq)) {
/* 440 */         throw new HibernateException("cannot scroll results with collection fetches which are not ordered primarily by the root entity's PK");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private StatementExecutor buildAppropriateStatementExecutor(HqlSqlWalker walker) {
/* 446 */     Statement statement = (Statement)walker.getAST();
/* 447 */     if (walker.getStatementType() == 13) {
/* 448 */       FromElement fromElement = walker.getFinalFromClause().getFromElement();
/* 449 */       Queryable persister = fromElement.getQueryable();
/* 450 */       if (persister.isMultiTable()) {
/* 451 */         return new MultiTableDeleteExecutor(walker);
/*     */       }
/*     */       
/* 454 */       return new BasicExecutor(walker, persister);
/*     */     }
/*     */     
/* 457 */     if (walker.getStatementType() == 51) {
/* 458 */       FromElement fromElement = walker.getFinalFromClause().getFromElement();
/* 459 */       Queryable persister = fromElement.getQueryable();
/* 460 */       if (persister.isMultiTable())
/*     */       {
/*     */ 
/*     */ 
/* 464 */         return new MultiTableUpdateExecutor(walker);
/*     */       }
/*     */       
/* 467 */       return new BasicExecutor(walker, persister);
/*     */     }
/*     */     
/* 470 */     if (walker.getStatementType() == 29) {
/* 471 */       return new BasicExecutor(walker, ((InsertStatement)statement).getIntoClause().getQueryable());
/*     */     }
/*     */     
/* 474 */     throw new QueryException("Unexpected statement type");
/*     */   }
/*     */   
/*     */   public ParameterTranslations getParameterTranslations()
/*     */   {
/* 479 */     if (this.paramTranslations == null) {
/* 480 */       this.paramTranslations = new ParameterTranslationsImpl(getWalker().getParameters());
/*     */     }
/* 482 */     return this.paramTranslations;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\QueryTranslatorImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */