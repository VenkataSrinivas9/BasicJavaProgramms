/*     */ package org.hibernate.hql.ast.util;
/*     */ 
/*     */ import antlr.SemanticException;
/*     */ import antlr.collections.AST;
/*     */ import java.math.BigDecimal;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.hql.antlr.HqlSqlTokenTypes;
/*     */ import org.hibernate.hql.ast.HqlSqlWalker;
/*     */ import org.hibernate.hql.ast.InvalidPathException;
/*     */ import org.hibernate.hql.ast.tree.DotNode;
/*     */ import org.hibernate.hql.ast.tree.FromClause;
/*     */ import org.hibernate.hql.ast.tree.IdentNode;
/*     */ import org.hibernate.persister.entity.Queryable;
/*     */ import org.hibernate.type.LiteralType;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.type.TypeFactory;
/*     */ import org.hibernate.util.ReflectHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LiteralProcessor
/*     */   implements HqlSqlTokenTypes
/*     */ {
/*     */   public static final int EXACT = 0;
/*     */   public static final int APPROXIMATE = 1;
/*  54 */   public static int DECIMAL_LITERAL_FORMAT = 0;
/*     */   
/*  56 */   private static final Log log = LogFactory.getLog(LiteralProcessor.class);
/*     */   private HqlSqlWalker walker;
/*     */   
/*     */   public LiteralProcessor(HqlSqlWalker hqlSqlWalker)
/*     */   {
/*  61 */     this.walker = hqlSqlWalker;
/*     */   }
/*     */   
/*     */   public boolean isAlias(String alias) {
/*  65 */     FromClause from = this.walker.getCurrentFromClause();
/*  66 */     while (from.isSubQuery()) {
/*  67 */       if (from.containsClassAlias(alias)) {
/*  68 */         return true;
/*     */       }
/*  70 */       from = from.getParentFromClause();
/*     */     }
/*  72 */     return from.containsClassAlias(alias);
/*     */   }
/*     */   
/*     */   public void processConstant(AST constant, boolean resolveIdent) throws SemanticException
/*     */   {
/*  77 */     boolean isIdent = (constant.getType() == 119) || (constant.getType() == 90);
/*  78 */     if ((resolveIdent) && (isIdent) && (isAlias(constant.getText()))) {
/*  79 */       IdentNode ident = (IdentNode)constant;
/*     */       
/*  81 */       ident.resolve(false, true);
/*     */     }
/*     */     else {
/*  84 */       Queryable queryable = this.walker.getSessionFactoryHelper().findQueryableUsingImports(constant.getText());
/*  85 */       if ((isIdent) && (queryable != null)) {
/*  86 */         constant.setText(queryable.getDiscriminatorSQLValue());
/*     */       }
/*     */       else
/*     */       {
/*  90 */         processLiteral(constant);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void lookupConstant(DotNode node) throws SemanticException {
/*  96 */     String text = getText(node);
/*  97 */     Queryable persister = this.walker.getSessionFactoryHelper().findQueryableUsingImports(text);
/*  98 */     if (persister != null)
/*     */     {
/* 100 */       String discrim = persister.getDiscriminatorSQLValue();
/* 101 */       if (("null".equals(discrim)) || ("not null".equals(discrim))) {
/* 102 */         throw new InvalidPathException("subclass test not allowed for null or not null discriminator: '" + text + "'");
/*     */       }
/*     */       
/* 105 */       setSQLValue(node, text, discrim);
/*     */     }
/*     */     else
/*     */     {
/* 109 */       Object value = ReflectHelper.getConstantValue(text);
/* 110 */       if (value == null) {
/* 111 */         throw new InvalidPathException("Invalid path: '" + text + "'");
/*     */       }
/*     */       
/* 114 */       setConstantValue(node, text, value);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setSQLValue(DotNode node, String text, String value)
/*     */   {
/* 120 */     if (log.isDebugEnabled()) {
/* 121 */       log.debug("setSQLValue() " + text + " -> " + value);
/*     */     }
/* 123 */     node.setFirstChild(null);
/* 124 */     node.setType(135);
/* 125 */     node.setText(value);
/* 126 */     node.setResolvedConstant(text);
/*     */   }
/*     */   
/*     */   private void setConstantValue(DotNode node, String text, Object value) {
/* 130 */     if (log.isDebugEnabled()) {
/* 131 */       log.debug("setConstantValue() " + text + " -> " + value + " " + value.getClass().getName());
/*     */     }
/* 133 */     node.setFirstChild(null);
/* 134 */     if ((value instanceof String)) {
/* 135 */       node.setType(118);
/*     */     }
/* 137 */     else if ((value instanceof Character)) {
/* 138 */       node.setType(118);
/*     */     }
/* 140 */     else if ((value instanceof Byte)) {
/* 141 */       node.setType(117);
/*     */     }
/* 143 */     else if ((value instanceof Short)) {
/* 144 */       node.setType(117);
/*     */     }
/* 146 */     else if ((value instanceof Integer)) {
/* 147 */       node.setType(117);
/*     */     }
/* 149 */     else if ((value instanceof Long)) {
/* 150 */       node.setType(94);
/*     */     }
/* 152 */     else if ((value instanceof Double)) {
/* 153 */       node.setType(92);
/*     */     }
/* 155 */     else if ((value instanceof Float)) {
/* 156 */       node.setType(93);
/*     */     }
/*     */     else {
/* 159 */       node.setType(91);
/*     */     }
/*     */     try
/*     */     {
/* 163 */       type = TypeFactory.heuristicType(value.getClass().getName());
/*     */     } catch (MappingException me) {
/*     */       Type type;
/* 166 */       throw new QueryException(me); }
/*     */     Type type;
/* 168 */     if (type == null) {
/* 169 */       throw new QueryException("Could not determine type of: " + node.getText());
/*     */     }
/*     */     try {
/* 172 */       LiteralType literalType = (LiteralType)type;
/* 173 */       Dialect dialect = this.walker.getSessionFactoryHelper().getFactory().getDialect();
/* 174 */       node.setText(literalType.objectToSQLString(value, dialect));
/*     */     }
/*     */     catch (Exception e) {
/* 177 */       throw new QueryException("Could not format constant value to SQL literal: " + node.getText(), e);
/*     */     }
/* 179 */     node.setDataType(type);
/* 180 */     node.setResolvedConstant(text);
/*     */   }
/*     */   
/*     */   private String getText(AST node) {
/* 184 */     return ASTUtil.getPathText(node);
/*     */   }
/*     */   
/*     */ 
/*     */   public void processBoolean(AST constant)
/*     */   {
/* 190 */     String replacement = (String)this.walker.getTokenReplacements().get(constant.getText());
/* 191 */     if (replacement != null) {
/* 192 */       constant.setText(replacement);
/*     */     }
/*     */     else {
/* 195 */       boolean bool = "true".equals(constant.getText().toLowerCase());
/* 196 */       Dialect dialect = this.walker.getSessionFactoryHelper().getFactory().getDialect();
/* 197 */       constant.setText(dialect.toBooleanValueString(bool));
/*     */     }
/*     */   }
/*     */   
/*     */   private void processLiteral(AST constant) {
/* 202 */     String replacement = (String)this.walker.getTokenReplacements().get(constant.getText());
/* 203 */     if (replacement != null) {
/* 204 */       if (log.isDebugEnabled()) {
/* 205 */         log.debug("processConstant() : Replacing '" + constant.getText() + "' with '" + replacement + "'");
/*     */       }
/* 207 */       constant.setText(replacement);
/*     */     }
/*     */   }
/*     */   
/*     */   public void processNumeric(AST literal) {
/* 212 */     if ((literal.getType() == 117) || (literal.getType() == 94)) {
/* 213 */       literal.setText(determineIntegerRepresentation(literal.getText(), literal.getType()));
/*     */     }
/* 215 */     else if ((literal.getType() == 93) || (literal.getType() == 92)) {
/* 216 */       literal.setText(determineDecimalRepresentation(literal.getText(), literal.getType()));
/*     */     }
/*     */     else {
/* 219 */       log.warn("Unexpected literal token type [" + literal.getType() + "] passed for numeric processing");
/*     */     }
/*     */   }
/*     */   
/*     */   private String determineIntegerRepresentation(String text, int type) {
/*     */     try {
/* 225 */       if (type == 117) {
/*     */         try {
/* 227 */           return Integer.valueOf(text).toString();
/*     */         }
/*     */         catch (NumberFormatException e) {
/* 230 */           log.trace("could not format incoming text [" + text + "] as a NUM_INT; assuming numeric overflow and attempting as NUM_LONG");
/*     */         }
/*     */       }
/* 233 */       String literalValue = text;
/* 234 */       if ((literalValue.endsWith("l")) || (literalValue.endsWith("L"))) {
/* 235 */         literalValue = literalValue.substring(0, literalValue.length() - 1);
/*     */       }
/* 237 */       return Long.valueOf(literalValue).toString();
/*     */     }
/*     */     catch (Throwable t) {
/* 240 */       throw new HibernateException("Could not parse literal [" + text + "] as integer", t);
/*     */     }
/*     */   }
/*     */   
/*     */   public String determineDecimalRepresentation(String text, int type) {
/* 245 */     String literalValue = text;
/* 246 */     if (type == 93) {
/* 247 */       if ((literalValue.endsWith("f")) || (literalValue.endsWith("F"))) {
/* 248 */         literalValue = literalValue.substring(0, literalValue.length() - 1);
/*     */       }
/*     */     }
/* 251 */     else if ((type == 92) && (
/* 252 */       (literalValue.endsWith("d")) || (literalValue.endsWith("D")))) {
/* 253 */       literalValue = literalValue.substring(0, literalValue.length() - 1);
/*     */     }
/*     */     
/*     */ 
/* 257 */     BigDecimal number = null;
/*     */     try {
/* 259 */       number = new BigDecimal(literalValue);
/*     */     }
/*     */     catch (Throwable t) {
/* 262 */       throw new HibernateException("Could not parse literal [" + text + "] as big-decimal", t);
/*     */     }
/*     */     
/* 265 */     return formatters[DECIMAL_LITERAL_FORMAT].format(number);
/*     */   }
/*     */   
/*     */   private static abstract interface DecimalFormatter {
/*     */     public abstract String format(BigDecimal paramBigDecimal);
/*     */   }
/*     */   
/* 272 */   private static class ExactDecimalFormatter implements LiteralProcessor.DecimalFormatter { ExactDecimalFormatter(LiteralProcessor.1 x0) { this(); }
/*     */     
/* 274 */     public String format(BigDecimal number) { return number.toString(); }
/*     */     
/*     */     private ExactDecimalFormatter() {} }
/*     */   
/* 278 */   private static class ApproximateDecimalFormatter implements LiteralProcessor.DecimalFormatter { ApproximateDecimalFormatter(LiteralProcessor.1 x0) { this(); }
/*     */     
/*     */     private static final String FORMAT_STRING = "#0.0E0";
/*     */     public String format(BigDecimal number)
/*     */     {
/*     */       try
/*     */       {
/* 285 */         DecimalFormat jdkFormatter = new DecimalFormat("#0.0E0");
/* 286 */         jdkFormatter.setMinimumIntegerDigits(1);
/* 287 */         jdkFormatter.setMaximumFractionDigits(Integer.MAX_VALUE);
/* 288 */         return jdkFormatter.format(number);
/*     */       }
/*     */       catch (Throwable t) {
/* 291 */         throw new HibernateException("Unable to format decimal literal in approximate format [" + number.toString() + "]", t);
/*     */       } }
/*     */     
/*     */     private ApproximateDecimalFormatter() {} }
/*     */   
/* 296 */   private static final DecimalFormatter[] formatters = { new ExactDecimalFormatter(null), new ApproximateDecimalFormatter(null) };
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\util\LiteralProcessor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */