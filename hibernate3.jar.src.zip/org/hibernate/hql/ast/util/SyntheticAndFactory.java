/*     */ package org.hibernate.hql.ast.util;
/*     */ 
/*     */ import antlr.ASTFactory;
/*     */ import antlr.collections.AST;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.hql.antlr.HqlSqlTokenTypes;
/*     */ import org.hibernate.hql.ast.tree.FromElement;
/*     */ import org.hibernate.hql.ast.tree.QueryNode;
/*     */ import org.hibernate.hql.ast.tree.RestrictableStatement;
/*     */ import org.hibernate.hql.ast.tree.SqlFragment;
/*     */ import org.hibernate.persister.entity.Queryable;
/*     */ import org.hibernate.sql.JoinFragment;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyntheticAndFactory
/*     */   implements HqlSqlTokenTypes
/*     */ {
/*  28 */   private static final Log log = LogFactory.getLog(SyntheticAndFactory.class);
/*     */   private ASTFactory astFactory;
/*     */   private AST thetaJoins;
/*     */   private AST filters;
/*     */   
/*     */   public SyntheticAndFactory(ASTFactory astFactory)
/*     */   {
/*  35 */     this.astFactory = astFactory;
/*     */   }
/*     */   
/*     */   public void addWhereFragment(JoinFragment joinFragment, String whereFragment, QueryNode query, FromElement fromElement)
/*     */   {
/*  40 */     if (whereFragment == null) {
/*  41 */       return;
/*     */     }
/*     */     
/*  44 */     whereFragment = whereFragment.trim();
/*  45 */     if (StringHelper.isEmpty(whereFragment)) {
/*  46 */       return;
/*     */     }
/*  48 */     if ((!fromElement.useWhereFragment()) && (!joinFragment.hasThetaJoins())) {
/*  49 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  54 */     if (whereFragment.startsWith("and")) {
/*  55 */       whereFragment = whereFragment.substring(4);
/*     */     }
/*     */     
/*  58 */     if (log.isDebugEnabled()) { log.debug("Using WHERE fragment [" + whereFragment + "]");
/*     */     }
/*  60 */     SqlFragment fragment = (SqlFragment)ASTUtil.create(this.astFactory, 135, whereFragment);
/*  61 */     fragment.setJoinFragment(joinFragment);
/*  62 */     fragment.setFromElement(fromElement);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  67 */     if ((fragment.getFromElement().isFilter()) || (fragment.hasFilterCondition())) {
/*  68 */       if (this.filters == null)
/*     */       {
/*  70 */         AST where = query.getWhereClause();
/*     */         
/*  72 */         this.filters = this.astFactory.create(139, "{filter conditions}");
/*     */         
/*  74 */         ASTUtil.insertChild(where, this.filters);
/*     */       }
/*     */       
/*     */ 
/*  78 */       this.filters.addChild(fragment);
/*     */     }
/*     */     else {
/*  81 */       if (this.thetaJoins == null)
/*     */       {
/*  83 */         AST where = query.getWhereClause();
/*     */         
/*  85 */         this.thetaJoins = this.astFactory.create(138, "{theta joins}");
/*     */         
/*  87 */         if (this.filters == null) {
/*  88 */           ASTUtil.insertChild(where, this.thetaJoins);
/*     */         }
/*     */         else {
/*  91 */           ASTUtil.insertSibling(this.thetaJoins, this.filters);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*  96 */       this.thetaJoins.addChild(fragment);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addDiscriminatorWhereFragment(RestrictableStatement statement, Queryable persister, Map enabledFilters, String alias)
/*     */   {
/* 102 */     String whereFragment = persister.filterFragment(alias, enabledFilters).trim();
/* 103 */     if ("".equals(whereFragment)) {
/* 104 */       return;
/*     */     }
/* 106 */     if (whereFragment.startsWith("and")) {
/* 107 */       whereFragment = whereFragment.substring(4);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 112 */     whereFragment = StringHelper.replace(whereFragment, persister.generateFilterConditionAlias(alias) + ".", "");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 121 */     AST discrimNode = this.astFactory.create(135, whereFragment);
/*     */     
/* 123 */     if (statement.getWhereClause().getNumberOfChildren() == 0) {
/* 124 */       statement.getWhereClause().setFirstChild(discrimNode);
/*     */     }
/*     */     else {
/* 127 */       AST and = this.astFactory.create(6, "{and}");
/* 128 */       AST currentFirstChild = statement.getWhereClause().getFirstChild();
/* 129 */       and.setFirstChild(discrimNode);
/* 130 */       and.addChild(currentFirstChild);
/* 131 */       statement.getWhereClause().setFirstChild(and);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\util\SyntheticAndFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */