/*     */ package org.hibernate.hql.ast.util;
/*     */ 
/*     */ import antlr.ASTFactory;
/*     */ import antlr.collections.AST;
/*     */ import antlr.collections.impl.ASTArray;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ASTUtil
/*     */ {
/*     */   public static AST create(ASTFactory astFactory, int type, String text)
/*     */   {
/*  35 */     AST node = astFactory.create(type, text);
/*  36 */     return node;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AST createSibling(ASTFactory astFactory, int type, String text, AST prevSibling)
/*     */   {
/*  49 */     AST node = astFactory.create(type, text);
/*  50 */     node.setNextSibling(prevSibling.getNextSibling());
/*  51 */     prevSibling.setNextSibling(node);
/*  52 */     return node;
/*     */   }
/*     */   
/*     */   public static AST insertSibling(AST node, AST prevSibling) {
/*  56 */     node.setNextSibling(prevSibling.getNextSibling());
/*  57 */     prevSibling.setNextSibling(node);
/*  58 */     return node;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AST createBinarySubtree(ASTFactory factory, int parentType, String parentText, AST child1, AST child2)
/*     */   {
/*  73 */     ASTArray array = createAstArray(factory, 3, parentType, parentText, child1);
/*  74 */     array.add(child2);
/*  75 */     return factory.make(array);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AST createParent(ASTFactory factory, int parentType, String parentText, AST child)
/*     */   {
/*  89 */     ASTArray array = createAstArray(factory, 2, parentType, parentText, child);
/*  90 */     return factory.make(array);
/*     */   }
/*     */   
/*     */   public static AST createTree(ASTFactory factory, AST[] nestedChildren) {
/*  94 */     AST[] array = new AST[2];
/*  95 */     int limit = nestedChildren.length - 1;
/*  96 */     for (int i = limit; i >= 0; i--) {
/*  97 */       if (i != limit) {
/*  98 */         array[1] = nestedChildren[(i + 1)];
/*  99 */         array[0] = nestedChildren[i];
/* 100 */         factory.make(array);
/*     */       }
/*     */     }
/* 103 */     return array[0];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AST findTypeInChildren(AST parent, int type)
/*     */   {
/* 114 */     AST n = parent.getFirstChild();
/* 115 */     while ((n != null) && (n.getType() != type))
/* 116 */       n = n.getNextSibling();
/* 117 */     return n;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AST getLastChild(AST n)
/*     */   {
/* 127 */     return getLastSibling(n.getFirstChild());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static AST getLastSibling(AST a)
/*     */   {
/* 137 */     AST last = null;
/* 138 */     while (a != null) {
/* 139 */       last = a;
/* 140 */       a = a.getNextSibling();
/*     */     }
/* 142 */     return last;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getDebugString(AST n)
/*     */   {
/* 152 */     StringBuffer buf = new StringBuffer();
/* 153 */     buf.append("[ ");
/* 154 */     buf.append(n == null ? "{null}" : n.toStringTree());
/* 155 */     buf.append(" ]");
/* 156 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AST findPreviousSibling(AST parent, AST child)
/*     */   {
/* 167 */     AST prev = null;
/* 168 */     AST n = parent.getFirstChild();
/* 169 */     while (n != null) {
/* 170 */       if (n == child) {
/* 171 */         return prev;
/*     */       }
/* 173 */       prev = n;
/* 174 */       n = n.getNextSibling();
/*     */     }
/* 176 */     throw new IllegalArgumentException("Child not found in parent!");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void makeSiblingOfParent(AST parent, AST child)
/*     */   {
/* 186 */     AST prev = findPreviousSibling(parent, child);
/* 187 */     if (prev != null) {
/* 188 */       prev.setNextSibling(child.getNextSibling());
/*     */     }
/*     */     else {
/* 191 */       parent.setFirstChild(child.getNextSibling());
/*     */     }
/* 193 */     child.setNextSibling(parent.getNextSibling());
/* 194 */     parent.setNextSibling(child);
/*     */   }
/*     */   
/*     */   public static String getPathText(AST n) {
/* 198 */     StringBuffer buf = new StringBuffer();
/* 199 */     getPathText(buf, n);
/* 200 */     return buf.toString();
/*     */   }
/*     */   
/*     */   private static void getPathText(StringBuffer buf, AST n) {
/* 204 */     AST firstChild = n.getFirstChild();
/*     */     
/* 206 */     if (firstChild != null) {
/* 207 */       getPathText(buf, firstChild);
/*     */     }
/*     */     
/* 210 */     buf.append(n.getText());
/*     */     
/* 212 */     if ((firstChild != null) && (firstChild.getNextSibling() != null)) {
/* 213 */       getPathText(buf, firstChild.getNextSibling());
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean hasExactlyOneChild(AST n) {
/* 218 */     return (n != null) && (n.getFirstChild() != null) && (n.getFirstChild().getNextSibling() == null);
/*     */   }
/*     */   
/*     */   public static void appendSibling(AST n, AST s) {
/* 222 */     while (n.getNextSibling() != null)
/* 223 */       n = n.getNextSibling();
/* 224 */     n.setNextSibling(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void insertChild(AST parent, AST child)
/*     */   {
/* 234 */     if (parent.getFirstChild() == null) {
/* 235 */       parent.setFirstChild(child);
/*     */     }
/*     */     else {
/* 238 */       AST n = parent.getFirstChild();
/* 239 */       parent.setFirstChild(child);
/* 240 */       child.setNextSibling(n);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static abstract class IncludePredicate
/*     */     implements ASTUtil.FilterPredicate
/*     */   {
/*     */     public final boolean exclude(AST node)
/*     */     {
/* 262 */       return !include(node);
/*     */     }
/*     */     
/*     */     public abstract boolean include(AST paramAST);
/*     */   }
/*     */   
/*     */   private static ASTArray createAstArray(ASTFactory factory, int size, int parentType, String parentText, AST child1) {
/* 269 */     ASTArray array = new ASTArray(size);
/* 270 */     array.add(factory.create(parentType, parentText));
/* 271 */     array.add(child1);
/* 272 */     return array;
/*     */   }
/*     */   
/*     */   public static List collectChildren(AST root, FilterPredicate predicate) {
/* 276 */     List children = new ArrayList();
/* 277 */     collectChildren(children, root, predicate);
/* 278 */     return children;
/*     */   }
/*     */   
/*     */   private static void collectChildren(List children, AST root, FilterPredicate predicate) {
/* 282 */     for (AST n = root.getFirstChild(); n != null; n = n.getNextSibling()) {
/* 283 */       if ((predicate == null) || (!predicate.exclude(n))) {
/* 284 */         children.add(n);
/*     */       }
/* 286 */       collectChildren(children, n, predicate);
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract interface FilterPredicate
/*     */   {
/*     */     public abstract boolean exclude(AST paramAST);
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\util\ASTUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */