/*    */ package org.hibernate.hql.ast.util;
/*    */ 
/*    */ import antlr.collections.AST;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ASTParentsFirstIterator
/*    */   implements Iterator
/*    */ {
/*    */   private AST next;
/*    */   private AST current;
/*    */   private AST tree;
/* 16 */   private LinkedList parents = new LinkedList();
/*    */   
/*    */   public void remove() {
/* 19 */     throw new UnsupportedOperationException("remove() is not supported");
/*    */   }
/*    */   
/*    */   public boolean hasNext() {
/* 23 */     return this.next != null;
/*    */   }
/*    */   
/*    */   public Object next() {
/* 27 */     return nextNode();
/*    */   }
/*    */   
/*    */   public ASTParentsFirstIterator(AST tree) {
/* 31 */     this.tree = (this.next = tree);
/*    */   }
/*    */   
/*    */   public AST nextNode() {
/* 35 */     this.current = this.next;
/* 36 */     if (this.next != null) {
/* 37 */       AST child = this.next.getFirstChild();
/* 38 */       if (child == null) {
/* 39 */         AST sibling = this.next.getNextSibling();
/* 40 */         if (sibling == null) {
/* 41 */           AST parent = pop();
/* 42 */           while ((parent != null) && (parent.getNextSibling() == null))
/* 43 */             parent = pop();
/* 44 */           this.next = (parent != null ? parent.getNextSibling() : null);
/*    */         }
/*    */         else {
/* 47 */           this.next = sibling;
/*    */         }
/*    */       }
/*    */       else {
/* 51 */         if (this.next != this.tree) {
/* 52 */           push(this.next);
/*    */         }
/* 54 */         this.next = child;
/*    */       }
/*    */     }
/* 57 */     return this.current;
/*    */   }
/*    */   
/*    */   private void push(AST parent) {
/* 61 */     this.parents.addFirst(parent);
/*    */   }
/*    */   
/*    */   private AST pop() {
/* 65 */     if (this.parents.size() == 0) {
/* 66 */       return null;
/*    */     }
/*    */     
/* 69 */     return (AST)this.parents.removeFirst();
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\util\ASTParentsFirstIterator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */