/*    */ package org.hibernate.hql.ast.util;
/*    */ 
/*    */ import antlr.ASTFactory;
/*    */ import antlr.collections.AST;
/*    */ import org.hibernate.hql.NameGenerator;
/*    */ import org.hibernate.hql.ast.tree.HqlSqlWalkerNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ColumnHelper
/*    */ {
/*    */   public static void generateSingleScalarColumn(HqlSqlWalkerNode node, int i)
/*    */   {
/* 25 */     ASTFactory factory = node.getASTFactory();
/* 26 */     ASTUtil.createSibling(factory, 136, " as " + NameGenerator.scalarName(i, 0), node);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static void generateScalarColumns(HqlSqlWalkerNode node, String[] sqlColumns, int i)
/*    */   {
/* 33 */     if (sqlColumns.length == 1) {
/* 34 */       generateSingleScalarColumn(node, i);
/*    */     }
/*    */     else {
/* 37 */       ASTFactory factory = node.getASTFactory();
/* 38 */       AST n = node;
/* 39 */       n.setText(sqlColumns[0]);
/*    */       
/* 41 */       for (int j = 0; j < sqlColumns.length; j++) {
/* 42 */         if (j > 0) {
/* 43 */           n = ASTUtil.createSibling(factory, 135, sqlColumns[j], n);
/*    */         }
/* 45 */         n = ASTUtil.createSibling(factory, 136, " as " + NameGenerator.scalarName(i, j), n);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\util\ColumnHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */