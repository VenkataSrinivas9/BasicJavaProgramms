/*    */ package org.hibernate.hql.ast.util;
/*    */ 
/*    */ import antlr.ASTFactory;
/*    */ import antlr.collections.AST;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ASTAppender
/*    */ {
/*    */   private AST parent;
/*    */   private AST last;
/*    */   private ASTFactory factory;
/*    */   
/*    */   public ASTAppender(ASTFactory factory, AST parent)
/*    */   {
/* 18 */     this(parent);
/* 19 */     this.factory = factory;
/*    */   }
/*    */   
/*    */   public ASTAppender(AST parent) {
/* 23 */     this.parent = parent;
/* 24 */     this.last = ASTUtil.getLastChild(parent);
/*    */   }
/*    */   
/*    */   public AST append(int type, String text, boolean appendIfEmpty) {
/* 28 */     if ((text != null) && ((appendIfEmpty) || (text.length() > 0))) {
/* 29 */       return append(this.factory.create(type, text));
/*    */     }
/*    */     
/* 32 */     return null;
/*    */   }
/*    */   
/*    */   public AST append(AST child)
/*    */   {
/* 37 */     if (this.last == null) {
/* 38 */       this.parent.setFirstChild(child);
/*    */     }
/*    */     else {
/* 41 */       this.last.setNextSibling(child);
/*    */     }
/* 43 */     this.last = child;
/* 44 */     return this.last;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\util\ASTAppender.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */