/*    */ package org.hibernate.hql.ast.util;
/*    */ 
/*    */ import antlr.ASTFactory;
/*    */ import antlr.collections.AST;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.util.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PathHelper
/*    */ {
/* 20 */   private static final Log log = LogFactory.getLog(PathHelper.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static AST parsePath(String path, ASTFactory factory)
/*    */   {
/* 33 */     String[] identifiers = StringHelper.split(".", path);
/* 34 */     AST lhs = null;
/* 35 */     for (int i = 0; i < identifiers.length; i++) {
/* 36 */       String identifier = identifiers[i];
/* 37 */       AST child = ASTUtil.create(factory, 119, identifier);
/* 38 */       if (i == 0) {
/* 39 */         lhs = child;
/*    */       }
/*    */       else {
/* 42 */         lhs = ASTUtil.createBinarySubtree(factory, 15, ".", lhs, child);
/*    */       }
/*    */     }
/* 45 */     if (log.isDebugEnabled()) {
/* 46 */       log.debug("parsePath() : " + path + " -> " + ASTUtil.getDebugString(lhs));
/*    */     }
/* 48 */     return lhs;
/*    */   }
/*    */   
/*    */   public static String getAlias(String path) {
/* 52 */     return StringHelper.root(path);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\util\PathHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */