/*    */ package org.hibernate.hql.ast.util;
/*    */ 
/*    */ import org.hibernate.util.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AliasGenerator
/*    */ {
/* 13 */   private int next = 0;
/*    */   
/*    */   private int nextCount() {
/* 16 */     return this.next++;
/*    */   }
/*    */   
/*    */   public String createName(String name) {
/* 20 */     return StringHelper.generateAlias(name, nextCount());
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\util\AliasGenerator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */