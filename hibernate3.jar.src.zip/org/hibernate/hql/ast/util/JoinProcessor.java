/*     */ package org.hibernate.hql.ast.util;
/*     */ 
/*     */ import antlr.ASTFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.engine.JoinSequence;
/*     */ import org.hibernate.engine.JoinSequence.Selector;
/*     */ import org.hibernate.hql.antlr.SqlTokenTypes;
/*     */ import org.hibernate.hql.ast.QueryTranslatorImpl;
/*     */ import org.hibernate.hql.ast.tree.FromClause;
/*     */ import org.hibernate.hql.ast.tree.FromElement;
/*     */ import org.hibernate.hql.ast.tree.QueryNode;
/*     */ import org.hibernate.sql.JoinFragment;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JoinProcessor
/*     */   implements SqlTokenTypes
/*     */ {
/*  33 */   private static final Log log = LogFactory.getLog(JoinProcessor.class);
/*     */   
/*     */ 
/*     */   private QueryTranslatorImpl queryTranslatorImpl;
/*     */   
/*     */ 
/*     */   private SyntheticAndFactory andFactory;
/*     */   
/*     */ 
/*     */ 
/*     */   public JoinProcessor(ASTFactory astFactory, QueryTranslatorImpl queryTranslatorImpl)
/*     */   {
/*  45 */     this.andFactory = new SyntheticAndFactory(astFactory);
/*  46 */     this.queryTranslatorImpl = queryTranslatorImpl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int toHibernateJoinType(int astJoinType)
/*     */   {
/*  58 */     switch (astJoinType) {
/*     */     case 131: 
/*  60 */       return 1;
/*     */     case 28: 
/*  62 */       return 0;
/*     */     case 132: 
/*  64 */       return 2;
/*     */     }
/*  66 */     throw new AssertionFailure("undefined join type " + astJoinType);
/*     */   }
/*     */   
/*     */   public void processJoins(QueryNode query, boolean inSubquery)
/*     */   {
/*  71 */     final FromClause fromClause = query.getFromClause();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  78 */     ArrayList orderedFromElements = new ArrayList();
/*  79 */     ListIterator liter = fromClause.getFromElements().listIterator(fromClause.getFromElements().size());
/*  80 */     while (liter.hasPrevious()) {
/*  81 */       orderedFromElements.add(liter.previous());
/*     */     }
/*     */     
/*     */ 
/*  85 */     Iterator iter = orderedFromElements.iterator();
/*  86 */     while (iter.hasNext()) {
/*  87 */       final FromElement fromElement = (FromElement)iter.next();
/*  88 */       JoinSequence join = fromElement.getJoinSequence();
/*  89 */       join.setSelector(new JoinSequence.Selector()
/*     */       {
/*     */         public boolean includeSubclasses(String alias) {
/*  92 */           boolean shallowQuery = JoinProcessor.this.queryTranslatorImpl.isShallowQuery();
/*  93 */           boolean containsTableAlias = fromClause.containsTableAlias(alias);
/*  94 */           boolean includeSubclasses = fromElement.isIncludeSubclasses();
/*  95 */           boolean subQuery = fromClause.isSubQuery();
/*  96 */           return (includeSubclasses) && (containsTableAlias) && (!subQuery) && (!shallowQuery);
/*     */         }
/*     */         
/*  99 */       });
/* 100 */       addJoinNodes(query, join, fromElement, inSubquery);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void addJoinNodes(QueryNode query, JoinSequence join, FromElement fromElement, boolean inSubquery)
/*     */   {
/* 107 */     JoinFragment joinFragment = join.toJoinFragment(inSubquery ? Collections.EMPTY_MAP : this.queryTranslatorImpl.getEnabledFilters(), fromElement.useFromFragment(), fromElement.getAdHocOnClauseFragment());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 113 */     String frag = joinFragment.toFromFragmentString();
/* 114 */     String whereFrag = joinFragment.toWhereFragmentString();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 119 */     if ((fromElement.getType() == 129) && ((join.isThetaStyle()) || (StringHelper.isNotEmpty(whereFrag))))
/*     */     {
/* 121 */       fromElement.setType(127);
/* 122 */       fromElement.getJoinSequence().setUseThetaStyle(true);
/*     */     }
/*     */     
/*     */ 
/* 126 */     if (fromElement.useFromFragment()) {
/* 127 */       String fromFragment = processFromFragment(frag, join);
/* 128 */       if (log.isDebugEnabled()) log.debug("Using FROM fragment [" + fromFragment + "]");
/* 129 */       fromElement.setText(fromFragment.trim());
/*     */     }
/* 131 */     this.andFactory.addWhereFragment(joinFragment, whereFrag, query, fromElement);
/*     */   }
/*     */   
/*     */   private String processFromFragment(String frag, JoinSequence join) {
/* 135 */     String fromFragment = frag.trim();
/*     */     
/* 137 */     if (fromFragment.startsWith(", ")) {
/* 138 */       fromFragment = fromFragment.substring(2);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */     return fromFragment;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\util\JoinProcessor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */