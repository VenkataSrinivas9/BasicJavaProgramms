/*    */ package org.hibernate.hql.ast.util;
/*    */ 
/*    */ import antlr.collections.AST;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ASTIterator
/*    */   implements Iterator
/*    */ {
/*    */   private AST next;
/*    */   private AST current;
/* 16 */   private LinkedList parents = new LinkedList();
/*    */   
/*    */   public void remove() {
/* 19 */     throw new UnsupportedOperationException("remove() is not supported");
/*    */   }
/*    */   
/*    */   public boolean hasNext() {
/* 23 */     return this.next != null;
/*    */   }
/*    */   
/*    */   public Object next() {
/* 27 */     return nextNode();
/*    */   }
/*    */   
/*    */   public ASTIterator(AST tree) {
/* 31 */     this.next = tree;
/* 32 */     down();
/*    */   }
/*    */   
/*    */   public AST nextNode() {
/* 36 */     this.current = this.next;
/* 37 */     if (this.next != null) {
/* 38 */       AST nextSibling = this.next.getNextSibling();
/* 39 */       if (nextSibling == null) {
/* 40 */         this.next = pop();
/*    */       }
/*    */       else {
/* 43 */         this.next = nextSibling;
/* 44 */         down();
/*    */       }
/*    */     }
/* 47 */     return this.current;
/*    */   }
/*    */   
/*    */   private void down() {
/* 51 */     while ((this.next != null) && (this.next.getFirstChild() != null)) {
/* 52 */       push(this.next);
/* 53 */       this.next = this.next.getFirstChild();
/*    */     }
/*    */   }
/*    */   
/*    */   private void push(AST parent) {
/* 58 */     this.parents.addFirst(parent);
/*    */   }
/*    */   
/*    */   private AST pop() {
/* 62 */     if (this.parents.size() == 0) {
/* 63 */       return null;
/*    */     }
/*    */     
/* 66 */     return (AST)this.parents.removeFirst();
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\util\ASTIterator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */