/*     */ package org.hibernate.hql.ast.util;
/*     */ 
/*     */ import antlr.SemanticException;
/*     */ import antlr.collections.AST;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.dialect.function.SQLFunction;
/*     */ import org.hibernate.engine.JoinSequence;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.hql.NameGenerator;
/*     */ import org.hibernate.hql.ast.DetailedSemanticException;
/*     */ import org.hibernate.hql.ast.QuerySyntaxException;
/*     */ import org.hibernate.hql.ast.tree.SqlNode;
/*     */ import org.hibernate.persister.collection.CollectionPropertyMapping;
/*     */ import org.hibernate.persister.collection.QueryableCollection;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.persister.entity.PropertyMapping;
/*     */ import org.hibernate.persister.entity.Queryable;
/*     */ import org.hibernate.type.AssociationType;
/*     */ import org.hibernate.type.CollectionType;
/*     */ import org.hibernate.type.EntityType;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.type.TypeFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionFactoryHelper
/*     */ {
/*     */   private SessionFactoryImplementor sfi;
/*     */   private Map collectionPropertyMappingByRole;
/*     */   
/*     */   public SessionFactoryHelper(SessionFactoryImplementor sfi)
/*     */   {
/*  46 */     this.sfi = sfi;
/*  47 */     this.collectionPropertyMappingByRole = new HashMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SessionFactoryImplementor getFactory()
/*     */   {
/*  56 */     return this.sfi;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasPhysicalDiscriminatorColumn(Queryable persister)
/*     */   {
/*  67 */     if (persister.getDiscriminatorType() != null) {
/*  68 */       String discrimColumnName = persister.getDiscriminatorColumnName();
/*     */       
/*     */ 
/*  71 */       if ((discrimColumnName != null) && (!"clazz_".equals(discrimColumnName))) {
/*  72 */         return true;
/*     */       }
/*     */     }
/*  75 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getImportedClassName(String className)
/*     */   {
/*  85 */     return this.sfi.getImportedClassName(className);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Queryable findQueryableUsingImports(String className)
/*     */   {
/*  95 */     return findQueryableUsingImports(this.sfi, className);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Queryable findQueryableUsingImports(SessionFactoryImplementor sfi, String className)
/*     */   {
/* 107 */     String importedClassName = sfi.getImportedClassName(className);
/* 108 */     if (importedClassName == null) {
/* 109 */       return null;
/*     */     }
/*     */     try {
/* 112 */       return (Queryable)sfi.getEntityPersister(importedClassName);
/*     */     }
/*     */     catch (MappingException me) {}
/* 115 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private EntityPersister findEntityPersisterByName(String name)
/*     */     throws MappingException
/*     */   {
/*     */     try
/*     */     {
/* 129 */       return this.sfi.getEntityPersister(name);
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (MappingException ignore)
/*     */     {
/*     */ 
/* 136 */       String importedClassName = this.sfi.getImportedClassName(name);
/* 137 */       if (importedClassName == null) {
/* 138 */         return null;
/*     */       }
/* 140 */       return this.sfi.getEntityPersister(importedClassName);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EntityPersister requireClassPersister(String name)
/*     */     throws SemanticException
/*     */   {
/*     */     try
/*     */     {
/* 154 */       EntityPersister cp = findEntityPersisterByName(name);
/* 155 */       if (cp == null)
/*     */       {
/* 157 */         throw new QuerySyntaxException(new SemanticException(name + " is not mapped."));
/*     */       }
/*     */     }
/*     */     catch (MappingException e) {
/* 161 */       throw new DetailedSemanticException(e.getMessage(), e); }
/*     */     EntityPersister cp;
/* 163 */     return cp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public QueryableCollection getCollectionPersister(String role)
/*     */   {
/*     */     try
/*     */     {
/* 174 */       return (QueryableCollection)this.sfi.getCollectionPersister(role);
/*     */     }
/*     */     catch (ClassCastException cce) {
/* 177 */       throw new QueryException("collection is not queryable: " + role);
/*     */     }
/*     */     catch (Exception e) {
/* 180 */       throw new QueryException("collection not found: " + role);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public QueryableCollection requireQueryableCollection(String role)
/*     */     throws QueryException
/*     */   {
/*     */     try
/*     */     {
/* 194 */       QueryableCollection queryableCollection = (QueryableCollection)this.sfi.getCollectionPersister(role);
/* 195 */       if (queryableCollection != null) {
/* 196 */         this.collectionPropertyMappingByRole.put(role, new CollectionPropertyMapping(queryableCollection));
/*     */       }
/* 198 */       return queryableCollection;
/*     */     }
/*     */     catch (ClassCastException cce) {
/* 201 */       throw new QueryException("collection role is not queryable: " + role);
/*     */     }
/*     */     catch (Exception e) {
/* 204 */       throw new QueryException("collection role not found: " + role);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private PropertyMapping getCollectionPropertyMapping(String role)
/*     */   {
/* 215 */     return (PropertyMapping)this.collectionPropertyMappingByRole.get(role);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getCollectionElementColumns(String role, String roleAlias)
/*     */   {
/* 227 */     return getCollectionPropertyMapping(role).toColumns(roleAlias, "elements");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JoinSequence createJoinSequence()
/*     */   {
/* 236 */     return new JoinSequence(this.sfi);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JoinSequence createJoinSequence(boolean implicit, AssociationType associationType, String tableAlias, int joinType, String[] columns)
/*     */   {
/* 250 */     JoinSequence joinSequence = createJoinSequence();
/* 251 */     joinSequence.setUseThetaStyle(implicit);
/* 252 */     joinSequence.addJoin(associationType, tableAlias, joinType, columns);
/* 253 */     return joinSequence;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JoinSequence createCollectionJoinSequence(QueryableCollection collPersister, String collectionName)
/*     */   {
/* 264 */     JoinSequence joinSequence = createJoinSequence();
/* 265 */     joinSequence.setRoot(collPersister, collectionName);
/* 266 */     joinSequence.setUseThetaStyle(true);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 271 */     return joinSequence;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getIdentifierOrUniqueKeyPropertyName(EntityType entityType)
/*     */   {
/*     */     try
/*     */     {
/* 284 */       return entityType.getIdentifierOrUniqueKeyPropertyName(this.sfi);
/*     */     }
/*     */     catch (MappingException me) {
/* 287 */       throw new QueryException(me);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumnSpan(Type type)
/*     */   {
/* 298 */     return type.getColumnSpan(this.sfi);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAssociatedEntityName(CollectionType collectionType)
/*     */   {
/* 309 */     return collectionType.getAssociatedEntityName(this.sfi);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Type getElementType(CollectionType collectionType)
/*     */   {
/* 320 */     return collectionType.getElementType(this.sfi);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AssociationType getElementAssociationType(CollectionType collectionType)
/*     */   {
/* 331 */     return (AssociationType)getElementType(collectionType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SQLFunction findSQLFunction(String functionName)
/*     */   {
/* 341 */     return (SQLFunction)this.sfi.getDialect().getFunctions().get(functionName.toLowerCase());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private SQLFunction requireSQLFunction(String functionName)
/*     */   {
/* 352 */     SQLFunction f = findSQLFunction(functionName);
/* 353 */     if (f == null) {
/* 354 */       throw new QueryException("Unable to find SQL function: " + functionName);
/*     */     }
/* 356 */     return f;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Type findFunctionReturnType(String functionName, AST first)
/*     */   {
/* 367 */     Type argumentType = null;
/* 368 */     if ("cast".equals(functionName)) {
/* 369 */       argumentType = TypeFactory.heuristicType(first.getNextSibling().getText());
/*     */     }
/* 371 */     else if ((first != null) && ((first instanceof SqlNode))) {
/* 372 */       argumentType = ((SqlNode)first).getDataType();
/*     */     }
/*     */     
/* 375 */     return requireSQLFunction(functionName).getReturnType(argumentType, this.sfi);
/*     */   }
/*     */   
/*     */   public String[][] generateColumnNames(Type[] sqlResultTypes) {
/* 379 */     return NameGenerator.generateColumnNames(sqlResultTypes, this.sfi);
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\util\SessionFactoryHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */