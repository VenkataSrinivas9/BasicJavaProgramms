/*     */ package org.hibernate.hql.ast.util;
/*     */ 
/*     */ import antlr.collections.AST;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.hibernate.hql.ast.tree.DisplayableNode;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ASTPrinter
/*     */ {
/*     */   private Map tokenTypeNamesByTokenType;
/*     */   private Class tokenTypeConstants;
/*  26 */   private boolean showClassNames = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ASTPrinter(Class tokenTypeConstants)
/*     */   {
/*  36 */     this.tokenTypeConstants = tokenTypeConstants;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isShowClassNames()
/*     */   {
/*  45 */     return this.showClassNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setShowClassNames(boolean showClassNames)
/*     */   {
/*  54 */     this.showClassNames = showClassNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void showAst(AST ast, PrintStream out)
/*     */   {
/*  64 */     showAst(ast, new PrintWriter(out));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void showAst(AST ast, PrintWriter pw)
/*     */   {
/*  74 */     ArrayList parents = new ArrayList();
/*  75 */     showAst(parents, pw, ast);
/*  76 */     pw.flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String showAsString(AST ast, String header)
/*     */   {
/*  87 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*  88 */     PrintStream ps = new PrintStream(baos);
/*  89 */     ps.println(header);
/*  90 */     showAst(ast, ps);
/*  91 */     ps.flush();
/*  92 */     return new String(baos.toByteArray());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getConstantName(Class tokenTypeConstants, int type)
/*     */   {
/* 103 */     String tokenTypeName = null;
/* 104 */     if (tokenTypeConstants != null) {
/* 105 */       Field[] fields = tokenTypeConstants.getFields();
/* 106 */       for (int i = 0; i < fields.length; i++) {
/* 107 */         Field field = fields[i];
/* 108 */         tokenTypeName = getTokenTypeName(field, type, true);
/* 109 */         if (tokenTypeName != null) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 116 */     if (tokenTypeName == null) {
/* 117 */       tokenTypeName = Integer.toString(type);
/*     */     }
/*     */     
/* 120 */     return tokenTypeName;
/*     */   }
/*     */   
/*     */   private static String getTokenTypeName(Field field, int type, boolean checkType) {
/* 124 */     if (Modifier.isStatic(field.getModifiers())) {
/*     */       try {
/* 126 */         Object value = field.get(null);
/* 127 */         if (!checkType) {
/* 128 */           return field.getName();
/*     */         }
/* 130 */         if ((value instanceof Integer)) {
/* 131 */           Integer integer = (Integer)value;
/* 132 */           if (integer.intValue() == type) {
/* 133 */             return field.getName();
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (IllegalArgumentException ignore) {}catch (IllegalAccessException ignore) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 142 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getTokenTypeName(int type)
/*     */   {
/* 155 */     if (this.tokenTypeConstants == null) {
/* 156 */       return Integer.toString(type);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 161 */     if (this.tokenTypeNamesByTokenType == null) {
/* 162 */       Field[] fields = this.tokenTypeConstants.getFields();
/* 163 */       this.tokenTypeNamesByTokenType = new HashMap();
/* 164 */       String tokenTypeName = null;
/* 165 */       for (int i = 0; i < fields.length; i++) {
/* 166 */         Field field = fields[i];
/* 167 */         tokenTypeName = getTokenTypeName(field, type, false);
/* 168 */         if (tokenTypeName != null) {
/*     */           try {
/* 170 */             this.tokenTypeNamesByTokenType.put(field.get(null), field.getName());
/*     */           }
/*     */           catch (IllegalAccessException ignore) {}
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 178 */     return (String)this.tokenTypeNamesByTokenType.get(new Integer(type));
/*     */   }
/*     */   
/*     */   private void showAst(ArrayList parents, PrintWriter pw, AST ast) {
/* 182 */     if (ast == null) {
/* 183 */       pw.println("AST is null!");
/* 184 */       return;
/*     */     }
/*     */     
/* 187 */     for (int i = 0; i < parents.size(); i++) {
/* 188 */       AST parent = (AST)parents.get(i);
/* 189 */       if (parent.getNextSibling() == null)
/*     */       {
/* 191 */         pw.print("   ");
/*     */       }
/*     */       else {
/* 194 */         pw.print(" | ");
/*     */       }
/*     */     }
/*     */     
/* 198 */     if (ast.getNextSibling() == null) {
/* 199 */       pw.print(" \\-");
/*     */     }
/*     */     else {
/* 202 */       pw.print(" +-");
/*     */     }
/*     */     
/* 205 */     showNode(pw, ast);
/*     */     
/* 207 */     ArrayList newParents = new ArrayList(parents);
/* 208 */     newParents.add(ast);
/* 209 */     for (AST child = ast.getFirstChild(); child != null; child = child.getNextSibling()) {
/* 210 */       showAst(newParents, pw, child);
/*     */     }
/* 212 */     newParents.clear();
/*     */   }
/*     */   
/*     */   private void showNode(PrintWriter pw, AST ast) {
/* 216 */     String s = nodeToString(ast, isShowClassNames());
/* 217 */     pw.println(s);
/*     */   }
/*     */   
/*     */   public String nodeToString(AST ast, boolean showClassName) {
/* 221 */     if (ast == null) {
/* 222 */       return "{null}";
/*     */     }
/* 224 */     StringBuffer buf = new StringBuffer();
/* 225 */     buf.append("[").append(getTokenTypeName(ast.getType())).append("] ");
/* 226 */     if (showClassName) {
/* 227 */       buf.append(StringHelper.unqualify(ast.getClass().getName())).append(": ");
/*     */     }
/*     */     
/* 230 */     buf.append("'");
/* 231 */     String text = ast.getText();
/* 232 */     appendEscapedMultibyteChars(text, buf);
/* 233 */     buf.append("'");
/* 234 */     if ((ast instanceof DisplayableNode)) {
/* 235 */       DisplayableNode displayableNode = (DisplayableNode)ast;
/*     */       
/* 237 */       buf.append(" ").append(displayableNode.getDisplayText());
/*     */     }
/* 239 */     String s = buf.toString();
/* 240 */     return s;
/*     */   }
/*     */   
/*     */   public static void appendEscapedMultibyteChars(String text, StringBuffer buf) {
/* 244 */     char[] chars = text.toCharArray();
/* 245 */     for (int i = 0; i < chars.length; i++) {
/* 246 */       char aChar = chars[i];
/* 247 */       if (aChar > 'Ā') {
/* 248 */         buf.append("\\u");
/* 249 */         buf.append(Integer.toHexString(aChar));
/*     */       }
/*     */       else {
/* 252 */         buf.append(aChar);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static String escapeMultibyteChars(String text) {
/* 258 */     StringBuffer buf = new StringBuffer();
/* 259 */     appendEscapedMultibyteChars(text, buf);
/* 260 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\util\ASTPrinter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */