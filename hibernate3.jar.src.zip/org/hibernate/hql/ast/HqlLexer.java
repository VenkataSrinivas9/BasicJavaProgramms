/*    */ package org.hibernate.hql.ast;
/*    */ 
/*    */ import antlr.Token;
/*    */ import java.io.InputStream;
/*    */ import java.io.Reader;
/*    */ import org.hibernate.QueryException;
/*    */ import org.hibernate.hql.antlr.HqlBaseLexer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class HqlLexer
/*    */   extends HqlBaseLexer
/*    */ {
/* 19 */   private boolean possibleID = false;
/*    */   
/*    */   public HqlLexer(InputStream in) {
/* 22 */     super(in);
/*    */   }
/*    */   
/*    */   public HqlLexer(Reader in) {
/* 26 */     super(in);
/*    */   }
/*    */   
/*    */   public void setTokenObjectClass(String cl)
/*    */   {
/* 31 */     super.setTokenObjectClass(HqlToken.class.getName());
/*    */   }
/*    */   
/*    */   protected void setPossibleID(boolean possibleID) {
/* 35 */     this.possibleID = possibleID;
/*    */   }
/*    */   
/*    */   protected Token makeToken(int i) {
/* 39 */     HqlToken token = (HqlToken)super.makeToken(i);
/* 40 */     token.setPossibleID(this.possibleID);
/* 41 */     this.possibleID = false;
/* 42 */     return token;
/*    */   }
/*    */   
/*    */   public int testLiteralsTable(int i) {
/* 46 */     int ttype = super.testLiteralsTable(i);
/* 47 */     return ttype;
/*    */   }
/*    */   
/*    */   public void panic()
/*    */   {
/* 52 */     panic("CharScanner: panic");
/*    */   }
/*    */   
/*    */   public void panic(String s)
/*    */   {
/* 57 */     throw new QueryException(s);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\HqlLexer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */