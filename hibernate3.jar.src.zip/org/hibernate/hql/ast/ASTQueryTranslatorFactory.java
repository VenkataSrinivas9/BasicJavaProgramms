/*    */ package org.hibernate.hql.ast;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.hql.FilterTranslator;
/*    */ import org.hibernate.hql.QueryTranslator;
/*    */ import org.hibernate.hql.QueryTranslatorFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ASTQueryTranslatorFactory
/*    */   implements QueryTranslatorFactory
/*    */ {
/* 21 */   private static final Log log = LogFactory.getLog(ASTQueryTranslatorFactory.class);
/*    */   
/*    */   public ASTQueryTranslatorFactory() {
/* 24 */     log.info("Using ASTQueryTranslatorFactory");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public QueryTranslator createQueryTranslator(String queryIdentifier, String queryString, Map filters, SessionFactoryImplementor factory)
/*    */   {
/* 35 */     return new QueryTranslatorImpl(queryIdentifier, queryString, filters, factory);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public FilterTranslator createFilterTranslator(String queryIdentifier, String queryString, Map filters, SessionFactoryImplementor factory)
/*    */   {
/* 46 */     return new QueryTranslatorImpl(queryIdentifier, queryString, filters, factory);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\ASTQueryTranslatorFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */