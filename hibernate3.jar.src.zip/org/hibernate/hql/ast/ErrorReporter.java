package org.hibernate.hql.ast;

import antlr.RecognitionException;

public abstract interface ErrorReporter
{
  public abstract void reportError(RecognitionException paramRecognitionException);
  
  public abstract void reportError(String paramString);
  
  public abstract void reportWarning(String paramString);
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\ErrorReporter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */