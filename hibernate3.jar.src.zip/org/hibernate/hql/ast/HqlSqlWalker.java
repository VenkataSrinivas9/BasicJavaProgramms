/*     */ package org.hibernate.hql.ast;
/*     */ 
/*     */ import antlr.ASTFactory;
/*     */ import antlr.RecognitionException;
/*     */ import antlr.SemanticException;
/*     */ import antlr.collections.AST;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.engine.JoinSequence;
/*     */ import org.hibernate.engine.ParameterBinder.NamedParameterSource;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.hql.antlr.HqlSqlBaseWalker;
/*     */ import org.hibernate.hql.antlr.SqlTokenTypes;
/*     */ import org.hibernate.hql.ast.tree.AssignmentSpecification;
/*     */ import org.hibernate.hql.ast.tree.CollectionFunction;
/*     */ import org.hibernate.hql.ast.tree.ConstructorNode;
/*     */ import org.hibernate.hql.ast.tree.DeleteStatement;
/*     */ import org.hibernate.hql.ast.tree.DotNode;
/*     */ import org.hibernate.hql.ast.tree.FromClause;
/*     */ import org.hibernate.hql.ast.tree.FromElement;
/*     */ import org.hibernate.hql.ast.tree.FromReferenceNode;
/*     */ import org.hibernate.hql.ast.tree.IdentNode;
/*     */ import org.hibernate.hql.ast.tree.IndexNode;
/*     */ import org.hibernate.hql.ast.tree.InsertStatement;
/*     */ import org.hibernate.hql.ast.tree.IntoClause;
/*     */ import org.hibernate.hql.ast.tree.MethodNode;
/*     */ import org.hibernate.hql.ast.tree.Node;
/*     */ import org.hibernate.hql.ast.tree.OperatorNode;
/*     */ import org.hibernate.hql.ast.tree.OrderByClause;
/*     */ import org.hibernate.hql.ast.tree.ParameterNode;
/*     */ import org.hibernate.hql.ast.tree.QueryNode;
/*     */ import org.hibernate.hql.ast.tree.ResolvableNode;
/*     */ import org.hibernate.hql.ast.tree.RestrictableStatement;
/*     */ import org.hibernate.hql.ast.tree.SelectClause;
/*     */ import org.hibernate.hql.ast.tree.SelectExpression;
/*     */ import org.hibernate.hql.ast.tree.UpdateStatement;
/*     */ import org.hibernate.hql.ast.util.ASTPrinter;
/*     */ import org.hibernate.hql.ast.util.ASTUtil;
/*     */ import org.hibernate.hql.ast.util.AliasGenerator;
/*     */ import org.hibernate.hql.ast.util.JoinProcessor;
/*     */ import org.hibernate.hql.ast.util.LiteralProcessor;
/*     */ import org.hibernate.hql.ast.util.SessionFactoryHelper;
/*     */ import org.hibernate.hql.ast.util.SyntheticAndFactory;
/*     */ import org.hibernate.id.IdentifierGenerator;
/*     */ import org.hibernate.id.PostInsertIdentifierGenerator;
/*     */ import org.hibernate.id.SequenceGenerator;
/*     */ import org.hibernate.param.NamedParameterSpecification;
/*     */ import org.hibernate.param.ParameterSpecification;
/*     */ import org.hibernate.param.PositionalParameterSpecification;
/*     */ import org.hibernate.param.VersionTypeSeedParameterSpecification;
/*     */ import org.hibernate.persister.collection.QueryableCollection;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.persister.entity.PropertyMapping;
/*     */ import org.hibernate.persister.entity.Queryable;
/*     */ import org.hibernate.type.AssociationType;
/*     */ import org.hibernate.type.DbTimestampType;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.type.VersionType;
/*     */ import org.hibernate.usertype.UserVersionType;
/*     */ import org.hibernate.util.ArrayHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HqlSqlWalker
/*     */   extends HqlSqlBaseWalker
/*     */   implements ErrorReporter, ParameterBinder.NamedParameterSource
/*     */ {
/*  88 */   private static Log log = LogFactory.getLog(HqlSqlWalker.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private SessionFactoryHelper sessionFactoryHelper;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private LiteralProcessor literalProcessor;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ParseErrorHandler parseErrorHandler;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 108 */   private FromClause currentFromClause = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private SelectClause selectClause;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 118 */   private AliasGenerator aliasGenerator = new AliasGenerator();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 123 */   private Set querySpaces = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map tokenReplacements;
/*     */   
/*     */ 
/*     */ 
/*     */   private QueryTranslatorImpl queryTranslatorImpl;
/*     */   
/*     */ 
/*     */ 
/*     */   private int parameterCount;
/*     */   
/*     */ 
/*     */ 
/* 140 */   private Map namedParameters = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */   private String filterCollectionRole;
/*     */   
/*     */ 
/*     */ 
/*     */   private HqlParser hqlParser;
/*     */   
/*     */ 
/*     */ 
/*     */   private ASTPrinter printer;
/*     */   
/*     */ 
/*     */ 
/*     */   private int impliedJoinType;
/*     */   
/*     */ 
/* 159 */   private ArrayList parameters = new ArrayList();
/*     */   
/*     */   private int numberOfParametersInSetClause;
/*     */   private int positionalParameterCount;
/* 163 */   private ArrayList assignmentSpecifications = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HqlSqlWalker(QueryTranslatorImpl qti, SessionFactoryImplementor sfi, HqlParser parser, Map tokenReplacements, String collectionRole)
/*     */   {
/* 180 */     setASTFactory(new SqlASTFactory(this));
/*     */     
/* 182 */     this.parseErrorHandler = new ErrorCounter();
/* 183 */     this.queryTranslatorImpl = qti;
/* 184 */     this.sessionFactoryHelper = new SessionFactoryHelper(sfi);
/* 185 */     this.literalProcessor = new LiteralProcessor(this);
/* 186 */     this.tokenReplacements = tokenReplacements;
/* 187 */     this.filterCollectionRole = collectionRole;
/* 188 */     this.hqlParser = parser;
/* 189 */     this.printer = new ASTPrinter(SqlTokenTypes.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void prepareFromClauseInputTree(AST fromClauseInput)
/*     */   {
/* 196 */     if ((isFilter()) && (!isSubQuery())) {
/* 197 */       QueryableCollection persister = this.sessionFactoryHelper.getCollectionPersister(this.filterCollectionRole);
/* 198 */       Type collectionElementType = persister.getElementType();
/* 199 */       if (!collectionElementType.isEntityType()) {
/* 200 */         throw new QueryException("collection of values in filter: this");
/*     */       }
/*     */       
/* 203 */       String collectionElementEntityName = persister.getElementPersister().getEntityName();
/* 204 */       ASTFactory inputAstFactory = this.hqlParser.getASTFactory();
/* 205 */       AST fromElement = ASTUtil.create(inputAstFactory, 73, collectionElementEntityName);
/* 206 */       ASTUtil.createSibling(inputAstFactory, 69, "this", fromElement);
/* 207 */       fromClauseInput.addChild(fromElement);
/*     */       
/* 209 */       if (log.isDebugEnabled()) {
/* 210 */         log.debug("prepareFromClauseInputTree() : Filter - Added 'this' as a from element...");
/*     */       }
/* 212 */       this.queryTranslatorImpl.showHqlAst(this.hqlParser.getAST());
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isFilter() {
/* 217 */     return this.filterCollectionRole != null;
/*     */   }
/*     */   
/*     */   public SessionFactoryHelper getSessionFactoryHelper() {
/* 221 */     return this.sessionFactoryHelper;
/*     */   }
/*     */   
/*     */   public Map getTokenReplacements() {
/* 225 */     return this.tokenReplacements;
/*     */   }
/*     */   
/*     */   public AliasGenerator getAliasGenerator() {
/* 229 */     return this.aliasGenerator;
/*     */   }
/*     */   
/*     */   public FromClause getCurrentFromClause() {
/* 233 */     return this.currentFromClause;
/*     */   }
/*     */   
/*     */   public ParseErrorHandler getParseErrorHandler() {
/* 237 */     return this.parseErrorHandler;
/*     */   }
/*     */   
/*     */   public void reportError(RecognitionException e) {
/* 241 */     this.parseErrorHandler.reportError(e);
/*     */   }
/*     */   
/*     */   public void reportError(String s) {
/* 245 */     this.parseErrorHandler.reportError(s);
/*     */   }
/*     */   
/*     */   public void reportWarning(String s) {
/* 249 */     this.parseErrorHandler.reportWarning(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set getQuerySpaces()
/*     */   {
/* 259 */     return this.querySpaces;
/*     */   }
/*     */   
/*     */   protected AST createFromElement(String path, AST alias, AST propertyFetch) throws SemanticException {
/* 263 */     FromElement fromElement = this.currentFromClause.addFromElement(path, alias);
/* 264 */     fromElement.setAllPropertyFetch(propertyFetch != null);
/* 265 */     return fromElement;
/*     */   }
/*     */   
/*     */   protected AST createFromFilterElement(AST filterEntity, AST alias) throws SemanticException {
/* 269 */     FromElement fromElement = this.currentFromClause.addFromElement(filterEntity.getText(), alias);
/* 270 */     FromClause fromClause = fromElement.getFromClause();
/* 271 */     QueryableCollection persister = this.sessionFactoryHelper.getCollectionPersister(this.filterCollectionRole);
/*     */     
/*     */ 
/* 274 */     String[] keyColumnNames = persister.getKeyColumnNames();
/* 275 */     String fkTableAlias = persister.isOneToMany() ? fromElement.getTableAlias() : fromClause.getAliasGenerator().createName(this.filterCollectionRole);
/*     */     
/*     */ 
/* 278 */     JoinSequence join = this.sessionFactoryHelper.createJoinSequence();
/* 279 */     join.setRoot(persister, fkTableAlias);
/* 280 */     if (!persister.isOneToMany()) {
/* 281 */       join.addJoin((AssociationType)persister.getElementType(), fromElement.getTableAlias(), 0, persister.getElementColumnNames(fkTableAlias));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 286 */     join.addCondition(fkTableAlias, keyColumnNames, " = ?");
/* 287 */     fromElement.setJoinSequence(join);
/* 288 */     fromElement.setFilter(true);
/* 289 */     if (log.isDebugEnabled()) {
/* 290 */       log.debug("createFromFilterElement() : processed filter FROM element.");
/*     */     }
/* 292 */     return fromElement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void createFromJoinElement(AST path, AST alias, int joinType, AST fetchNode, AST propertyFetch, AST with)
/*     */     throws SemanticException
/*     */   {
/* 302 */     boolean fetch = fetchNode != null;
/*     */     
/* 304 */     if (path.getType() != 15) {
/* 305 */       throw new SemanticException("Path expected for join!");
/*     */     }
/* 307 */     DotNode dot = (DotNode)path;
/* 308 */     int hibernateJoinType = JoinProcessor.toHibernateJoinType(joinType);
/* 309 */     dot.setJoinType(hibernateJoinType);
/* 310 */     dot.setFetch(fetch);
/*     */     
/*     */ 
/* 313 */     dot.resolve(true, false, alias == null ? null : alias.getText());
/* 314 */     FromElement fromElement = dot.getImpliedJoin();
/* 315 */     fromElement.setAllPropertyFetch(propertyFetch != null);
/*     */     
/* 317 */     if (with != null) {
/* 318 */       if (fetch) {
/* 319 */         throw new SemanticException("with-clause not allowed on fetched associations; use filters");
/*     */       }
/* 321 */       handleWithFragment(fromElement, with);
/*     */     }
/*     */     
/* 324 */     if (log.isDebugEnabled()) {
/* 325 */       log.debug("createFromJoinElement() : " + getASTPrinter().showAsString(fromElement, "-- join tree --"));
/*     */     }
/*     */   }
/*     */   
/*     */   private void handleWithFragment(FromElement fromElement, AST hqlWithNode) throws SemanticException
/*     */   {
/*     */     try {
/* 332 */       withClause(hqlWithNode);
/* 333 */       AST hqlSqlWithNode = this.returnAST;
/* 334 */       SqlGenerator sql = new SqlGenerator(getSessionFactoryHelper().getFactory());
/* 335 */       sql.whereExpr(hqlSqlWithNode.getFirstChild());
/* 336 */       fromElement.setAdHocOnClauseFragment("(" + sql.getSQL() + ")");
/*     */     }
/*     */     catch (Exception e) {
/* 339 */       throw new SemanticException(e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void pushFromClause(AST fromNode, AST inputFromNode)
/*     */   {
/* 350 */     FromClause newFromClause = (FromClause)fromNode;
/* 351 */     newFromClause.setParentFromClause(this.currentFromClause);
/* 352 */     this.currentFromClause = newFromClause;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void popFromClause()
/*     */   {
/* 359 */     this.currentFromClause = this.currentFromClause.getParentFromClause();
/*     */   }
/*     */   
/*     */   protected void lookupAlias(AST aliasRef) throws SemanticException
/*     */   {
/* 364 */     FromElement alias = this.currentFromClause.getFromElement(aliasRef.getText());
/* 365 */     FromReferenceNode aliasRefNode = (FromReferenceNode)aliasRef;
/* 366 */     aliasRefNode.setFromElement(alias);
/*     */   }
/*     */   
/*     */   protected void setImpliedJoinType(int joinType) {
/* 370 */     this.impliedJoinType = JoinProcessor.toHibernateJoinType(joinType);
/*     */   }
/*     */   
/*     */   public int getImpliedJoinType() {
/* 374 */     return this.impliedJoinType;
/*     */   }
/*     */   
/*     */   protected AST lookupProperty(AST dot, boolean root, boolean inSelect) throws SemanticException {
/* 378 */     DotNode dotNode = (DotNode)dot;
/* 379 */     FromReferenceNode lhs = dotNode.getLhs();
/* 380 */     AST rhs = lhs.getNextSibling();
/* 381 */     switch (rhs.getType()) {
/*     */     case 17: 
/*     */     case 27: 
/* 384 */       if (log.isDebugEnabled()) {
/* 385 */         log.debug("lookupProperty() " + dotNode.getPath() + " => " + rhs.getText() + "(" + lhs.getPath() + ")");
/*     */       }
/* 387 */       CollectionFunction f = (CollectionFunction)rhs;
/*     */       
/* 389 */       f.setFirstChild(lhs);
/* 390 */       lhs.setNextSibling(null);
/* 391 */       dotNode.setFirstChild(f);
/* 392 */       resolve(lhs);
/* 393 */       f.resolve(inSelect);
/* 394 */       return f;
/*     */     }
/*     */     
/* 397 */     dotNode.resolveFirstChild();
/* 398 */     return dotNode;
/*     */   }
/*     */   
/*     */   protected boolean isNonQualifiedPropertyRef(AST ident)
/*     */   {
/* 403 */     String identText = ident.getText();
/* 404 */     if (this.currentFromClause.isFromElementAlias(identText)) {
/* 405 */       return false;
/*     */     }
/*     */     
/* 408 */     List fromElements = this.currentFromClause.getExplicitFromElements();
/* 409 */     if (fromElements.size() == 1) {
/* 410 */       FromElement fromElement = (FromElement)fromElements.get(0);
/*     */       try {
/* 412 */         log.trace("attempting to resolve property [" + identText + "] as a non-qualified ref");
/* 413 */         return fromElement.getPropertyMapping(identText).toType(identText) != null;
/*     */       }
/*     */       catch (QueryException e) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 420 */     return false;
/*     */   }
/*     */   
/*     */   protected AST lookupNonQualifiedProperty(AST property) throws SemanticException {
/* 424 */     FromElement fromElement = (FromElement)this.currentFromClause.getExplicitFromElements().get(0);
/* 425 */     AST syntheticDotNode = generateSyntheticDotNodeForNonQualifiedPropertyRef(property, fromElement);
/* 426 */     return lookupProperty(syntheticDotNode, false, getCurrentClauseType() == 45);
/*     */   }
/*     */   
/*     */   private AST generateSyntheticDotNodeForNonQualifiedPropertyRef(AST property, FromElement fromElement) {
/* 430 */     AST dot = getASTFactory().create(15, "{non-qualified-property-ref}");
/*     */     
/* 432 */     ((DotNode)dot).setPropertyPath(((FromReferenceNode)property).getPath());
/*     */     
/* 434 */     IdentNode syntheticAlias = (IdentNode)getASTFactory().create(119, "{synthetic-alias}");
/* 435 */     syntheticAlias.setFromElement(fromElement);
/* 436 */     syntheticAlias.setResolved();
/*     */     
/* 438 */     dot.setFirstChild(syntheticAlias);
/* 439 */     dot.addChild(property);
/*     */     
/* 441 */     return dot;
/*     */   }
/*     */   
/*     */   protected void processQuery(AST select, AST query) throws SemanticException {
/* 445 */     if (log.isDebugEnabled()) {
/* 446 */       log.debug("processQuery() : " + query.toStringTree());
/*     */     }
/*     */     try
/*     */     {
/* 450 */       QueryNode qn = (QueryNode)query;
/*     */       
/*     */ 
/* 453 */       boolean explicitSelect = (select != null) && (select.getNumberOfChildren() > 0);
/*     */       
/* 455 */       if (!explicitSelect)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 461 */         createSelectClauseFromFromClause(qn);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 466 */         useSelectClause(select);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 471 */       JoinProcessor joinProcessor = new JoinProcessor(this.astFactory, this.queryTranslatorImpl);
/* 472 */       joinProcessor.processJoins(qn, isSubQuery());
/*     */       
/*     */ 
/* 475 */       Iterator itr = qn.getFromClause().getProjectionList().iterator();
/* 476 */       while (itr.hasNext()) {
/* 477 */         FromElement fromElement = (FromElement)itr.next();
/*     */         
/* 479 */         if ((fromElement.isFetch()) && (fromElement.getQueryableCollection() != null))
/*     */         {
/*     */ 
/*     */ 
/* 483 */           if (fromElement.getQueryableCollection().hasOrdering()) {
/* 484 */             String orderByFragment = fromElement.getQueryableCollection().getSQLOrderByString(fromElement.getCollectionTableAlias());
/*     */             
/*     */ 
/* 487 */             qn.getOrderByClause().addOrderFragment(orderByFragment);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     finally {
/* 493 */       popFromClause();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void postProcessDML(RestrictableStatement statement) throws SemanticException {
/* 498 */     statement.getFromClause().resolve();
/*     */     
/* 500 */     FromElement fromElement = (FromElement)statement.getFromClause().getFromElements().get(0);
/* 501 */     Queryable persister = fromElement.getQueryable();
/*     */     
/* 503 */     fromElement.setText(persister.getTableName());
/*     */     
/*     */ 
/*     */ 
/* 507 */     if (persister.getDiscriminatorType() != null) {
/* 508 */       new SyntheticAndFactory(getASTFactory()).addDiscriminatorWhereFragment(statement, persister, Collections.EMPTY_MAP, fromElement.getTableAlias());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void postProcessUpdate(AST update)
/*     */     throws SemanticException
/*     */   {
/* 519 */     UpdateStatement updateStatement = (UpdateStatement)update;
/*     */     
/* 521 */     postProcessDML(updateStatement);
/*     */   }
/*     */   
/*     */   protected void postProcessDelete(AST delete) throws SemanticException {
/* 525 */     postProcessDML((DeleteStatement)delete);
/*     */   }
/*     */   
/*     */   public static boolean supportsIdGenWithBulkInsertion(IdentifierGenerator generator) {
/* 529 */     return (SequenceGenerator.class.isAssignableFrom(generator.getClass())) || (PostInsertIdentifierGenerator.class.isAssignableFrom(generator.getClass()));
/*     */   }
/*     */   
/*     */   protected void postProcessInsert(AST insert) throws SemanticException, QueryException
/*     */   {
/* 534 */     InsertStatement insertStatement = (InsertStatement)insert;
/* 535 */     insertStatement.validate();
/*     */     
/* 537 */     SelectClause selectClause = insertStatement.getSelectClause();
/* 538 */     Queryable persister = insertStatement.getIntoClause().getQueryable();
/*     */     
/* 540 */     if (!insertStatement.getIntoClause().isExplicitIdInsertion())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 545 */       IdentifierGenerator generator = persister.getIdentifierGenerator();
/* 546 */       if (!supportsIdGenWithBulkInsertion(generator)) {
/* 547 */         throw new QueryException("can only generate ids as part of bulk insert with either sequence or post-insert style generators");
/*     */       }
/*     */       
/* 550 */       AST idSelectExprNode = null;
/*     */       
/* 552 */       if (SequenceGenerator.class.isAssignableFrom(generator.getClass())) {
/* 553 */         String seqName = (String)((SequenceGenerator)generator).generatorKey();
/* 554 */         String nextval = this.sessionFactoryHelper.getFactory().getDialect().getSelectSequenceNextValString(seqName);
/* 555 */         idSelectExprNode = getASTFactory().create(135, nextval);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 566 */       if (idSelectExprNode != null) {
/* 567 */         AST currentFirstSelectExprNode = selectClause.getFirstChild();
/* 568 */         selectClause.setFirstChild(idSelectExprNode);
/* 569 */         idSelectExprNode.setNextSibling(currentFirstSelectExprNode);
/*     */         
/* 571 */         insertStatement.getIntoClause().prependIdColumnSpec();
/*     */       }
/*     */     }
/*     */     
/* 575 */     boolean includeVersionProperty = (persister.isVersioned()) && (!insertStatement.getIntoClause().isExplicitVersionInsertion()) && (persister.isVersionPropertyInsertable());
/*     */     
/*     */ 
/* 578 */     if (includeVersionProperty)
/*     */     {
/* 580 */       VersionType versionType = persister.getVersionType();
/* 581 */       AST versionValueNode = null;
/*     */       
/* 583 */       if (this.sessionFactoryHelper.getFactory().getDialect().supportsParametersInInsertSelect()) {
/* 584 */         versionValueNode = getASTFactory().create(116, "?");
/* 585 */         ParameterSpecification paramSpec = new VersionTypeSeedParameterSpecification(versionType);
/* 586 */         ((ParameterNode)versionValueNode).setHqlParameterSpecification(paramSpec);
/* 587 */         this.parameters.add(0, paramSpec);
/*     */ 
/*     */       }
/* 590 */       else if (isIntegral(versionType)) {
/*     */         try {
/* 592 */           Object seedValue = versionType.seed(null);
/* 593 */           versionValueNode = getASTFactory().create(135, seedValue.toString());
/*     */         }
/*     */         catch (Throwable t) {
/* 596 */           throw new QueryException("could not determine seed value for version on bulk insert [" + versionType + "]");
/*     */         }
/*     */       }
/* 599 */       else if (isDatabaseGeneratedTimestamp(versionType)) {
/* 600 */         String functionName = this.sessionFactoryHelper.getFactory().getDialect().getCurrentTimestampSQLFunctionName();
/* 601 */         versionValueNode = getASTFactory().create(135, functionName);
/*     */       }
/*     */       else {
/* 604 */         throw new QueryException("cannot handle version type [" + versionType + "] on bulk inserts with dialects not supporting parameters in insert-select statements");
/*     */       }
/*     */       
/*     */ 
/* 608 */       AST currentFirstSelectExprNode = selectClause.getFirstChild();
/* 609 */       selectClause.setFirstChild(versionValueNode);
/* 610 */       versionValueNode.setNextSibling(currentFirstSelectExprNode);
/*     */       
/* 612 */       insertStatement.getIntoClause().prependVersionColumnSpec();
/*     */     }
/*     */     
/* 615 */     if (insertStatement.getIntoClause().isDiscriminated()) {
/* 616 */       String sqlValue = insertStatement.getIntoClause().getQueryable().getDiscriminatorSQLValue();
/* 617 */       AST discrimValue = getASTFactory().create(135, sqlValue);
/* 618 */       insertStatement.getSelectClause().addChild(discrimValue);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean isDatabaseGeneratedTimestamp(Type type)
/*     */   {
/* 625 */     return DbTimestampType.class.isAssignableFrom(type.getClass());
/*     */   }
/*     */   
/*     */   private boolean isIntegral(Type type) {
/* 629 */     return (Long.class.isAssignableFrom(type.getReturnedClass())) || (Integer.class.isAssignableFrom(type.getReturnedClass())) || (Long.TYPE.isAssignableFrom(type.getReturnedClass())) || (Integer.TYPE.isAssignableFrom(type.getReturnedClass()));
/*     */   }
/*     */   
/*     */ 
/*     */   private void useSelectClause(AST select)
/*     */     throws SemanticException
/*     */   {
/* 636 */     this.selectClause = ((SelectClause)select);
/* 637 */     this.selectClause.initializeExplicitSelectClause(this.currentFromClause);
/*     */   }
/*     */   
/*     */   private void createSelectClauseFromFromClause(QueryNode qn) throws SemanticException {
/* 641 */     AST select = this.astFactory.create(130, "{derived select clause}");
/* 642 */     AST sibling = qn.getFromClause();
/* 643 */     qn.setFirstChild(select);
/* 644 */     select.setNextSibling(sibling);
/* 645 */     this.selectClause = ((SelectClause)select);
/* 646 */     this.selectClause.initializeDerivedSelectClause(this.currentFromClause);
/* 647 */     if (log.isDebugEnabled()) {
/* 648 */       log.debug("Derived SELECT clause created.");
/*     */     }
/*     */   }
/*     */   
/*     */   protected void resolve(AST node) throws SemanticException {
/* 653 */     if (node != null)
/*     */     {
/* 655 */       ResolvableNode r = (ResolvableNode)node;
/* 656 */       if (isInFunctionCall()) {
/* 657 */         r.resolveInFunctionCall(false, true);
/*     */       }
/*     */       else {
/* 660 */         r.resolve(false, true);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void resolveSelectExpression(AST node) throws SemanticException
/*     */   {
/* 667 */     int type = node.getType();
/* 668 */     switch (type) {
/*     */     case 15: 
/* 670 */       DotNode dot = (DotNode)node;
/* 671 */       dot.resolveSelectExpression();
/* 672 */       break;
/*     */     
/*     */     case 133: 
/* 675 */       FromReferenceNode aliasRefNode = (FromReferenceNode)node;
/*     */       
/* 677 */       aliasRefNode.resolve(false, false);
/* 678 */       FromElement fromElement = aliasRefNode.getFromElement();
/* 679 */       if (fromElement != null) {
/* 680 */         fromElement.setIncludeSubclasses(true);
/*     */       }
/*     */       break;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void beforeSelectClause()
/*     */     throws SemanticException
/*     */   {
/* 689 */     FromClause from = getCurrentFromClause();
/* 690 */     List fromElements = from.getFromElements();
/* 691 */     for (Iterator iterator = fromElements.iterator(); iterator.hasNext();) {
/* 692 */       FromElement fromElement = (FromElement)iterator.next();
/* 693 */       fromElement.setIncludeSubclasses(false);
/*     */     }
/*     */   }
/*     */   
/*     */   protected AST generatePositionalParameter(AST inputNode) throws SemanticException {
/* 698 */     if (this.namedParameters.size() > 0) {
/* 699 */       throw new SemanticException("cannot define positional parameter after any named parameters have been defined");
/*     */     }
/* 701 */     ParameterNode parameter = (ParameterNode)this.astFactory.create(116, "?");
/* 702 */     PositionalParameterSpecification paramSpec = new PositionalParameterSpecification(((Node)inputNode).getLine(), ((Node)inputNode).getColumn(), this.positionalParameterCount++);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 707 */     parameter.setHqlParameterSpecification(paramSpec);
/* 708 */     this.parameters.add(paramSpec);
/* 709 */     return parameter;
/*     */   }
/*     */   
/*     */   protected AST generateNamedParameter(AST delimiterNode, AST nameNode) throws SemanticException {
/* 713 */     String name = nameNode.getText();
/* 714 */     trackNamedParameterPositions(name);
/*     */     
/*     */ 
/*     */ 
/* 718 */     ParameterNode parameter = (ParameterNode)this.astFactory.create(141, name);
/* 719 */     parameter.setText("?");
/*     */     
/* 721 */     NamedParameterSpecification paramSpec = new NamedParameterSpecification(((Node)delimiterNode).getLine(), ((Node)delimiterNode).getColumn(), name);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 726 */     parameter.setHqlParameterSpecification(paramSpec);
/* 727 */     this.parameters.add(paramSpec);
/* 728 */     return parameter;
/*     */   }
/*     */   
/*     */   private void trackNamedParameterPositions(String name) {
/* 732 */     Integer loc = new Integer(this.parameterCount++);
/* 733 */     Object o = this.namedParameters.get(name);
/* 734 */     if (o == null) {
/* 735 */       this.namedParameters.put(name, loc);
/*     */     }
/* 737 */     else if ((o instanceof Integer)) {
/* 738 */       ArrayList list = new ArrayList(4);
/* 739 */       list.add(o);
/* 740 */       list.add(loc);
/* 741 */       this.namedParameters.put(name, list);
/*     */     }
/*     */     else {
/* 744 */       ((ArrayList)o).add(loc);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void processConstant(AST constant) throws SemanticException {
/* 749 */     this.literalProcessor.processConstant(constant, true);
/*     */   }
/*     */   
/*     */   protected void processBoolean(AST constant) throws SemanticException {
/* 753 */     this.literalProcessor.processBoolean(constant);
/*     */   }
/*     */   
/*     */   protected void processNumericLiteral(AST literal) {
/* 757 */     this.literalProcessor.processNumeric(literal);
/*     */   }
/*     */   
/*     */   protected void processIndex(AST indexOp) throws SemanticException {
/* 761 */     IndexNode indexNode = (IndexNode)indexOp;
/* 762 */     indexNode.resolve(true, true);
/*     */   }
/*     */   
/*     */   protected void processFunction(AST functionCall, boolean inSelect) throws SemanticException {
/* 766 */     MethodNode methodNode = (MethodNode)functionCall;
/* 767 */     methodNode.resolve(inSelect);
/*     */   }
/*     */   
/*     */   protected void processConstructor(AST constructor) throws SemanticException {
/* 771 */     ConstructorNode constructorNode = (ConstructorNode)constructor;
/* 772 */     constructorNode.prepare();
/*     */   }
/*     */   
/*     */   protected void setAlias(AST selectExpr, AST ident) {
/* 776 */     ((SelectExpression)selectExpr).setAlias(ident.getText());
/*     */   }
/*     */   
/*     */ 
/*     */   public int[] getNamedParameterLocations(String name)
/*     */     throws QueryException
/*     */   {
/* 783 */     Object o = this.namedParameters.get(name);
/* 784 */     if (o == null) {
/* 785 */       QueryException qe = new QueryException("Named parameter does not appear in Query: " + name);
/* 786 */       qe.setQueryString(this.queryTranslatorImpl.getQueryString());
/* 787 */       throw qe;
/*     */     }
/* 789 */     if ((o instanceof Integer)) {
/* 790 */       return new int[] { ((Integer)o).intValue() };
/*     */     }
/*     */     
/* 793 */     return ArrayHelper.toIntArray((ArrayList)o);
/*     */   }
/*     */   
/*     */   public void addQuerySpaces(Serializable[] spaces)
/*     */   {
/* 798 */     for (int i = 0; i < spaces.length; i++) {
/* 799 */       this.querySpaces.add(spaces[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public Type[] getReturnTypes() {
/* 804 */     return this.selectClause.getQueryReturnTypes();
/*     */   }
/*     */   
/*     */   public String[] getReturnAliases() {
/* 808 */     return this.selectClause.getQueryReturnAliases();
/*     */   }
/*     */   
/*     */   public SelectClause getSelectClause() {
/* 812 */     return this.selectClause;
/*     */   }
/*     */   
/*     */   public FromClause getFinalFromClause()
/*     */   {
/* 817 */     return this.currentFromClause;
/*     */   }
/*     */   
/*     */   public boolean isShallowQuery()
/*     */   {
/* 822 */     return (getStatementType() == 29) || (this.queryTranslatorImpl.isShallowQuery());
/*     */   }
/*     */   
/*     */   public Map getEnabledFilters() {
/* 826 */     return this.queryTranslatorImpl.getEnabledFilters();
/*     */   }
/*     */   
/*     */   public LiteralProcessor getLiteralProcessor() {
/* 830 */     return this.literalProcessor;
/*     */   }
/*     */   
/*     */   public ASTPrinter getASTPrinter() {
/* 834 */     return this.printer;
/*     */   }
/*     */   
/*     */   public ArrayList getParameters() {
/* 838 */     return this.parameters;
/*     */   }
/*     */   
/*     */   public int getNumberOfParametersInSetClause() {
/* 842 */     return this.numberOfParametersInSetClause;
/*     */   }
/*     */   
/*     */   protected void evaluateAssignment(AST eq) throws SemanticException {
/* 846 */     Queryable persister = getCurrentFromClause().getFromElement().getQueryable();
/* 847 */     evaluateAssignment(eq, persister, -1);
/*     */   }
/*     */   
/*     */   private void evaluateAssignment(AST eq, Queryable persister, int targetIndex) {
/* 851 */     if (persister.isMultiTable())
/*     */     {
/* 853 */       AssignmentSpecification specification = new AssignmentSpecification(eq, persister);
/* 854 */       if (targetIndex >= 0) {
/* 855 */         this.assignmentSpecifications.add(targetIndex, specification);
/*     */       }
/*     */       else {
/* 858 */         this.assignmentSpecifications.add(specification);
/*     */       }
/* 860 */       this.numberOfParametersInSetClause += specification.getParameters().length;
/*     */     }
/*     */   }
/*     */   
/*     */   public ArrayList getAssignmentSpecifications() {
/* 865 */     return this.assignmentSpecifications;
/*     */   }
/*     */   
/*     */   protected AST createIntoClause(String path, AST propertySpec) throws SemanticException {
/* 869 */     Queryable persister = (Queryable)getSessionFactoryHelper().requireClassPersister(path);
/*     */     
/* 871 */     IntoClause intoClause = (IntoClause)getASTFactory().create(30, persister.getEntityName());
/* 872 */     intoClause.setFirstChild(propertySpec);
/* 873 */     intoClause.initialize(persister);
/*     */     
/* 875 */     addQuerySpaces(persister.getQuerySpaces());
/*     */     
/* 877 */     return intoClause;
/*     */   }
/*     */   
/*     */   protected void prepareVersioned(AST updateNode, AST versioned) throws SemanticException {
/* 881 */     UpdateStatement updateStatement = (UpdateStatement)updateNode;
/* 882 */     FromClause fromClause = updateStatement.getFromClause();
/* 883 */     if (versioned != null)
/*     */     {
/* 885 */       Queryable persister = fromClause.getFromElement().getQueryable();
/* 886 */       if (!persister.isVersioned()) {
/* 887 */         throw new SemanticException("increment option specified for update of non-versioned entity");
/*     */       }
/*     */       
/* 890 */       VersionType versionType = persister.getVersionType();
/* 891 */       if ((versionType instanceof UserVersionType)) {
/* 892 */         throw new SemanticException("user-defined version types not supported for increment option");
/*     */       }
/*     */       
/* 895 */       AST eq = getASTFactory().create(96, "=");
/* 896 */       AST versionPropertyNode = generateVersionPropertyNode(persister);
/*     */       
/* 898 */       eq.setFirstChild(versionPropertyNode);
/*     */       
/* 900 */       AST versionIncrementNode = null;
/* 901 */       if (Date.class.isAssignableFrom(versionType.getReturnedClass())) {
/* 902 */         versionIncrementNode = getASTFactory().create(116, "?");
/* 903 */         ParameterSpecification paramSpec = new VersionTypeSeedParameterSpecification(versionType);
/* 904 */         ((ParameterNode)versionIncrementNode).setHqlParameterSpecification(paramSpec);
/* 905 */         this.parameters.add(0, paramSpec);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 910 */         versionIncrementNode = getASTFactory().create(109, "+");
/* 911 */         versionIncrementNode.setFirstChild(generateVersionPropertyNode(persister));
/* 912 */         versionIncrementNode.addChild(getASTFactory().create(119, "1"));
/*     */       }
/*     */       
/* 915 */       eq.addChild(versionIncrementNode);
/*     */       
/* 917 */       evaluateAssignment(eq, persister, 0);
/*     */       
/* 919 */       AST setClause = updateStatement.getSetClause();
/* 920 */       AST currentFirstSetElement = setClause.getFirstChild();
/* 921 */       setClause.setFirstChild(eq);
/* 922 */       eq.setNextSibling(currentFirstSetElement);
/*     */     }
/*     */   }
/*     */   
/*     */   private AST generateVersionPropertyNode(Queryable persister) throws SemanticException {
/* 927 */     String versionPropertyName = persister.getPropertyNames()[persister.getVersionProperty()];
/* 928 */     AST versionPropertyRef = getASTFactory().create(119, versionPropertyName);
/* 929 */     AST versionPropertyNode = lookupNonQualifiedProperty(versionPropertyRef);
/* 930 */     resolve(versionPropertyNode);
/* 931 */     return versionPropertyNode;
/*     */   }
/*     */   
/*     */   protected void prepareLogicOperator(AST operator) throws SemanticException {
/* 935 */     ((OperatorNode)operator).initialize();
/*     */   }
/*     */   
/*     */   protected void prepareArithmeticOperator(AST operator) throws SemanticException {
/* 939 */     ((OperatorNode)operator).initialize();
/*     */   }
/*     */   
/*     */   public static void panic() {
/* 943 */     throw new QueryException("TreeWalker: panic");
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\HqlSqlWalker.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */