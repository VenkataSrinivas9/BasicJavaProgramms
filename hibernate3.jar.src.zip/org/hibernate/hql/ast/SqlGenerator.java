/*     */ package org.hibernate.hql.ast;
/*     */ 
/*     */ import antlr.RecognitionException;
/*     */ import antlr.collections.AST;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.dialect.function.SQLFunction;
/*     */ import org.hibernate.engine.JoinSequence;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.hql.antlr.SqlGeneratorBase;
/*     */ import org.hibernate.hql.ast.tree.FromElement;
/*     */ import org.hibernate.hql.ast.tree.MethodNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlGenerator
/*     */   extends SqlGeneratorBase
/*     */   implements ErrorReporter
/*     */ {
/*     */   private ParseErrorHandler parseErrorHandler;
/*  37 */   private SqlWriter writer = new DefaultWriter();
/*     */   
/*     */   private SessionFactoryImplementor sessionFactory;
/*     */   
/*  41 */   private LinkedList outputStack = new LinkedList();
/*     */   
/*     */   protected void out(String s) {
/*  44 */     this.writer.clause(s);
/*     */   }
/*     */   
/*     */   protected void commaBetweenParameters(String comma) {
/*  48 */     this.writer.commaBetweenParameters(comma);
/*     */   }
/*     */   
/*     */   public void reportError(RecognitionException e) {
/*  52 */     this.parseErrorHandler.reportError(e);
/*     */   }
/*     */   
/*     */   public void reportError(String s) {
/*  56 */     this.parseErrorHandler.reportError(s);
/*     */   }
/*     */   
/*     */   public void reportWarning(String s) {
/*  60 */     this.parseErrorHandler.reportWarning(s);
/*     */   }
/*     */   
/*     */   public ParseErrorHandler getParseErrorHandler() {
/*  64 */     return this.parseErrorHandler;
/*     */   }
/*     */   
/*     */   public SqlGenerator(SessionFactoryImplementor sfi)
/*     */   {
/*  69 */     this.parseErrorHandler = new ErrorCounter();
/*  70 */     this.sessionFactory = sfi;
/*     */   }
/*     */   
/*     */   public String getSQL() {
/*  74 */     return getStringBuffer().toString();
/*     */   }
/*     */   
/*     */   protected void optionalSpace() {
/*  78 */     int c = getLastChar();
/*  79 */     switch (c) {
/*     */     case -1: 
/*  81 */       return;
/*     */     case 32: 
/*  83 */       return;
/*     */     case 41: 
/*  85 */       return;
/*     */     case 40: 
/*  87 */       return;
/*     */     }
/*  89 */     out(" ");
/*     */   }
/*     */   
/*     */   protected void beginFunctionTemplate(AST m, AST i)
/*     */   {
/*  94 */     MethodNode methodNode = (MethodNode)m;
/*  95 */     SQLFunction template = methodNode.getSQLFunction();
/*  96 */     if (template == null)
/*     */     {
/*  98 */       super.beginFunctionTemplate(m, i);
/*     */     }
/*     */     else
/*     */     {
/* 102 */       this.outputStack.addFirst(this.writer);
/* 103 */       this.writer = new FunctionArguments();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void endFunctionTemplate(AST m) {
/* 108 */     MethodNode methodNode = (MethodNode)m;
/* 109 */     SQLFunction template = methodNode.getSQLFunction();
/* 110 */     if (template == null) {
/* 111 */       super.endFunctionTemplate(m);
/*     */     }
/*     */     else
/*     */     {
/* 115 */       FunctionArguments functionArguments = (FunctionArguments)this.writer;
/* 116 */       this.writer = ((SqlWriter)this.outputStack.removeFirst());
/* 117 */       out(template.render(functionArguments.getArgs(), this.sessionFactory));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static abstract interface SqlWriter
/*     */   {
/*     */     public abstract void clause(String paramString);
/*     */     
/*     */ 
/*     */ 
/*     */     public abstract void commaBetweenParameters(String paramString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   class FunctionArguments
/*     */     implements SqlGenerator.SqlWriter
/*     */   {
/*     */     private int argInd;
/*     */     
/*     */ 
/*     */ 
/*     */     FunctionArguments() {}
/*     */     
/*     */ 
/*     */ 
/* 145 */     private final List args = new ArrayList(3);
/*     */     
/*     */     public void clause(String clause) {
/* 148 */       if (this.argInd == this.args.size()) {
/* 149 */         this.args.add(clause);
/*     */       }
/*     */       else {
/* 152 */         this.args.set(this.argInd, this.args.get(this.argInd) + clause);
/*     */       }
/*     */     }
/*     */     
/*     */     public void commaBetweenParameters(String comma) {
/* 157 */       this.argInd += 1;
/*     */     }
/*     */     
/*     */     public List getArgs() {
/* 161 */       return this.args;
/*     */     }
/*     */   }
/*     */   
/*     */   class DefaultWriter implements SqlGenerator.SqlWriter
/*     */   {
/*     */     DefaultWriter() {}
/*     */     
/*     */     public void clause(String clause) {
/* 170 */       SqlGenerator.this.getStringBuffer().append(clause);
/*     */     }
/*     */     
/*     */     public void commaBetweenParameters(String comma) {
/* 174 */       SqlGenerator.this.getStringBuffer().append(comma);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void panic() {
/* 179 */     throw new QueryException("TreeWalker: panic");
/*     */   }
/*     */   
/*     */   protected void fromFragmentSeparator(AST a)
/*     */   {
/* 184 */     AST next = a.getNextSibling();
/* 185 */     if ((next == null) || (!hasText(a))) {
/* 186 */       return;
/*     */     }
/*     */     
/* 189 */     FromElement left = (FromElement)a;
/* 190 */     FromElement right = (FromElement)next;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 201 */     while ((right != null) && (!hasText(right))) {
/* 202 */       right = (FromElement)right.getNextSibling();
/*     */     }
/* 204 */     if (right == null) {
/* 205 */       return;
/*     */     }
/*     */     
/*     */ 
/* 209 */     if (!hasText(right)) {
/* 210 */       return;
/*     */     }
/*     */     
/* 213 */     if ((right.getRealOrigin() == left) || ((right.getRealOrigin() != null) && (right.getRealOrigin() == left.getRealOrigin())))
/*     */     {
/*     */ 
/*     */ 
/* 217 */       if ((right.getJoinSequence() != null) && (right.getJoinSequence().isThetaStyle())) {
/* 218 */         out(", ");
/*     */       }
/*     */       else {
/* 221 */         out(" ");
/*     */       }
/*     */       
/*     */     }
/*     */     else {
/* 226 */       out(", ");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void nestedFromFragment(AST d, AST parent)
/*     */   {
/* 233 */     if ((d != null) && (hasText(d))) {
/* 234 */       if ((parent != null) && (hasText(parent)))
/*     */       {
/* 236 */         FromElement left = (FromElement)parent;
/* 237 */         FromElement right = (FromElement)d;
/* 238 */         if (right.getRealOrigin() == left)
/*     */         {
/* 240 */           if ((right.getJoinSequence() != null) && (right.getJoinSequence().isThetaStyle())) {
/* 241 */             out(", ");
/*     */           }
/*     */           else {
/* 244 */             out(" ");
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         else {
/* 250 */           out(", ");
/*     */         }
/*     */       }
/* 253 */       out(d);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\SqlGenerator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */