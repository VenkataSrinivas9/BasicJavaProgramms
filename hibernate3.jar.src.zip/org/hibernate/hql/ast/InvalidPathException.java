/*    */ package org.hibernate.hql.ast;
/*    */ 
/*    */ import antlr.SemanticException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidPathException
/*    */   extends SemanticException
/*    */ {
/*    */   public InvalidPathException(String s)
/*    */   {
/* 13 */     super(s);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\InvalidPathException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */