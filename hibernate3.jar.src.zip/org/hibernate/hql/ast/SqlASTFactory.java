/*     */ package org.hibernate.hql.ast;
/*     */ 
/*     */ import antlr.ASTFactory;
/*     */ import antlr.Token;
/*     */ import antlr.collections.AST;
/*     */ import java.lang.reflect.Constructor;
/*     */ import org.hibernate.hql.antlr.HqlSqlTokenTypes;
/*     */ import org.hibernate.hql.ast.tree.AggregateNode;
/*     */ import org.hibernate.hql.ast.tree.BetweenOperatorNode;
/*     */ import org.hibernate.hql.ast.tree.BinaryArithmeticOperatorNode;
/*     */ import org.hibernate.hql.ast.tree.BinaryLogicOperatorNode;
/*     */ import org.hibernate.hql.ast.tree.Case2Node;
/*     */ import org.hibernate.hql.ast.tree.CaseNode;
/*     */ import org.hibernate.hql.ast.tree.CollectionFunction;
/*     */ import org.hibernate.hql.ast.tree.ConstructorNode;
/*     */ import org.hibernate.hql.ast.tree.CountNode;
/*     */ import org.hibernate.hql.ast.tree.DeleteStatement;
/*     */ import org.hibernate.hql.ast.tree.DotNode;
/*     */ import org.hibernate.hql.ast.tree.FromClause;
/*     */ import org.hibernate.hql.ast.tree.FromElement;
/*     */ import org.hibernate.hql.ast.tree.IdentNode;
/*     */ import org.hibernate.hql.ast.tree.ImpliedFromElement;
/*     */ import org.hibernate.hql.ast.tree.InLogicOperatorNode;
/*     */ import org.hibernate.hql.ast.tree.IndexNode;
/*     */ import org.hibernate.hql.ast.tree.InitializeableNode;
/*     */ import org.hibernate.hql.ast.tree.InsertStatement;
/*     */ import org.hibernate.hql.ast.tree.IntoClause;
/*     */ import org.hibernate.hql.ast.tree.LiteralNode;
/*     */ import org.hibernate.hql.ast.tree.MethodNode;
/*     */ import org.hibernate.hql.ast.tree.OrderByClause;
/*     */ import org.hibernate.hql.ast.tree.ParameterNode;
/*     */ import org.hibernate.hql.ast.tree.QueryNode;
/*     */ import org.hibernate.hql.ast.tree.SelectClause;
/*     */ import org.hibernate.hql.ast.tree.SelectExpressionImpl;
/*     */ import org.hibernate.hql.ast.tree.SqlFragment;
/*     */ import org.hibernate.hql.ast.tree.SqlNode;
/*     */ import org.hibernate.hql.ast.tree.UnaryArithmeticNode;
/*     */ import org.hibernate.hql.ast.tree.UnaryLogicOperatorNode;
/*     */ import org.hibernate.hql.ast.tree.UpdateStatement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlASTFactory
/*     */   extends ASTFactory
/*     */   implements HqlSqlTokenTypes
/*     */ {
/*     */   private HqlSqlWalker walker;
/*     */   
/*     */   public SqlASTFactory(HqlSqlWalker walker)
/*     */   {
/*  61 */     this.walker = walker;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class getASTNodeType(int tokenType)
/*     */   {
/*  71 */     switch (tokenType) {
/*     */     case 45: 
/*     */     case 83: 
/*  74 */       return QueryNode.class;
/*     */     case 51: 
/*  76 */       return UpdateStatement.class;
/*     */     case 13: 
/*  78 */       return DeleteStatement.class;
/*     */     case 29: 
/*  80 */       return InsertStatement.class;
/*     */     case 30: 
/*  82 */       return IntoClause.class;
/*     */     case 22: 
/*  84 */       return FromClause.class;
/*     */     case 127: 
/*  86 */       return FromElement.class;
/*     */     case 128: 
/*  88 */       return ImpliedFromElement.class;
/*     */     case 15: 
/*  90 */       return DotNode.class;
/*     */     case 75: 
/*  92 */       return IndexNode.class;
/*     */     
/*     */     case 119: 
/*     */     case 133: 
/*  96 */       return IdentNode.class;
/*     */     case 135: 
/*  98 */       return SqlFragment.class;
/*     */     case 78: 
/* 100 */       return MethodNode.class;
/*     */     case 17: 
/*     */     case 27: 
/* 103 */       return CollectionFunction.class;
/*     */     case 130: 
/* 105 */       return SelectClause.class;
/*     */     case 137: 
/* 107 */       return SelectExpressionImpl.class;
/*     */     case 68: 
/* 109 */       return AggregateNode.class;
/*     */     case 12: 
/* 111 */       return CountNode.class;
/*     */     case 70: 
/* 113 */       return ConstructorNode.class;
/*     */     case 20: 
/*     */     case 49: 
/*     */     case 92: 
/*     */     case 93: 
/*     */     case 94: 
/*     */     case 117: 
/*     */     case 118: 
/* 121 */       return LiteralNode.class;
/*     */     case 41: 
/* 123 */       return OrderByClause.class;
/*     */     case 109: 
/*     */     case 110: 
/*     */     case 111: 
/*     */     case 112: 
/* 128 */       return BinaryArithmeticOperatorNode.class;
/*     */     case 87: 
/*     */     case 88: 
/* 131 */       return UnaryArithmeticNode.class;
/*     */     case 71: 
/* 133 */       return Case2Node.class;
/*     */     case 54: 
/* 135 */       return CaseNode.class;
/*     */     case 116: 
/*     */     case 141: 
/* 138 */       return ParameterNode.class;
/*     */     case 34: 
/*     */     case 81: 
/*     */     case 96: 
/*     */     case 102: 
/*     */     case 104: 
/*     */     case 105: 
/*     */     case 106: 
/*     */     case 107: 
/* 147 */       return BinaryLogicOperatorNode.class;
/*     */     case 26: 
/*     */     case 80: 
/* 150 */       return InLogicOperatorNode.class;
/*     */     case 10: 
/*     */     case 79: 
/* 153 */       return BetweenOperatorNode.class;
/*     */     case 19: 
/*     */     case 76: 
/*     */     case 77: 
/* 157 */       return UnaryLogicOperatorNode.class;
/*     */     }
/* 159 */     return SqlNode.class;
/*     */   }
/*     */   
/*     */ 
/*     */   protected AST createUsingCtor(Token token, String className)
/*     */   {
/*     */     try
/*     */     {
/* 167 */       Class c = Class.forName(className);
/* 168 */       Class[] tokenArgType = { Token.class };
/* 169 */       Constructor ctor = c.getConstructor(tokenArgType);
/* 170 */       if (ctor != null) {
/* 171 */         AST t = (AST)ctor.newInstance(new Object[] { token });
/* 172 */         initializeSqlNode(t);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 177 */         t = create(c);
/*     */       }
/*     */     } catch (Exception e) {
/*     */       AST t;
/* 181 */       throw new IllegalArgumentException("Invalid class or can't make instance, " + className); }
/*     */     AST t;
/* 183 */     Class c; return t;
/*     */   }
/*     */   
/*     */   private void initializeSqlNode(AST t)
/*     */   {
/* 188 */     if ((t instanceof InitializeableNode)) {
/* 189 */       InitializeableNode initializeableNode = (InitializeableNode)t;
/* 190 */       initializeableNode.initialize(this.walker);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AST create(Class c)
/*     */   {
/*     */     try
/*     */     {
/* 203 */       AST t = (AST)c.newInstance();
/* 204 */       initializeSqlNode(t);
/*     */     }
/*     */     catch (Exception e) {
/* 207 */       error("Can't create AST Node " + c.getName());
/* 208 */       return null; }
/*     */     AST t;
/* 210 */     return t;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\SqlASTFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */