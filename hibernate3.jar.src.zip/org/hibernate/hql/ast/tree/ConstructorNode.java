/*     */ package org.hibernate.hql.ast.tree;
/*     */ 
/*     */ import antlr.SemanticException;
/*     */ import antlr.collections.AST;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.hibernate.PropertyNotFoundException;
/*     */ import org.hibernate.hql.ast.DetailedSemanticException;
/*     */ import org.hibernate.hql.ast.util.SessionFactoryHelper;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.ReflectHelper;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstructorNode
/*     */   extends SelectExpressionList
/*     */   implements SelectExpression
/*     */ {
/*     */   private Constructor constructor;
/*     */   private Type[] constructorArgumentTypes;
/*     */   private boolean isMap;
/*     */   private boolean isList;
/*     */   
/*     */   public boolean isMap()
/*     */   {
/*  30 */     return this.isMap;
/*     */   }
/*     */   
/*     */   public boolean isList() {
/*  34 */     return this.isList;
/*     */   }
/*     */   
/*     */   public String[] getAliases() {
/*  38 */     SelectExpression[] selectExpressions = collectSelectExpressions();
/*  39 */     String[] aliases = new String[selectExpressions.length];
/*  40 */     for (int i = 0; i < selectExpressions.length; i++) {
/*  41 */       String alias = selectExpressions[i].getAlias();
/*  42 */       aliases[i] = (alias == null ? Integer.toString(i) : alias);
/*     */     }
/*  44 */     return aliases;
/*     */   }
/*     */   
/*     */   public void setScalarColumnText(int i) throws SemanticException {
/*  48 */     SelectExpression[] selectExpressions = collectSelectExpressions();
/*     */     
/*  50 */     for (int j = 0; j < selectExpressions.length; j++) {
/*  51 */       SelectExpression selectExpression = selectExpressions[j];
/*  52 */       selectExpression.setScalarColumnText(j);
/*     */     }
/*     */   }
/*     */   
/*     */   protected AST getFirstSelectExpression()
/*     */   {
/*  58 */     return getFirstChild().getNextSibling();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public Type getDataType()
/*     */   {
/*  75 */     throw new UnsupportedOperationException("getDataType() is not supported by ConstructorNode!");
/*     */   }
/*     */   
/*     */   public void prepare() throws SemanticException {
/*  79 */     this.constructorArgumentTypes = resolveConstructorArgumentTypes();
/*  80 */     String path = ((PathNode)getFirstChild()).getPath();
/*  81 */     if ("map".equals(path.toLowerCase())) {
/*  82 */       this.isMap = true;
/*     */     }
/*  84 */     else if ("list".equals(path.toLowerCase())) {
/*  85 */       this.isList = true;
/*     */     }
/*     */     else {
/*  88 */       this.constructor = resolveConstructor(path);
/*     */     }
/*     */   }
/*     */   
/*     */   private Type[] resolveConstructorArgumentTypes() throws SemanticException {
/*  93 */     SelectExpression[] argumentExpressions = collectSelectExpressions();
/*  94 */     if (argumentExpressions == null)
/*     */     {
/*  96 */       return new Type[0];
/*     */     }
/*     */     
/*  99 */     Type[] types = new Type[argumentExpressions.length];
/* 100 */     for (int x = 0; x < argumentExpressions.length; x++) {
/* 101 */       types[x] = argumentExpressions[x].getDataType();
/*     */     }
/* 103 */     return types;
/*     */   }
/*     */   
/*     */   private Constructor resolveConstructor(String path) throws SemanticException {
/* 107 */     String importedClassName = getSessionFactoryHelper().getImportedClassName(path);
/* 108 */     String className = StringHelper.isEmpty(importedClassName) ? path : importedClassName;
/* 109 */     if (className == null) {
/* 110 */       throw new SemanticException("Unable to locate class [" + path + "]");
/*     */     }
/*     */     try {
/* 113 */       Class holderClass = ReflectHelper.classForName(className);
/* 114 */       return ReflectHelper.getConstructor(holderClass, this.constructorArgumentTypes);
/*     */     }
/*     */     catch (ClassNotFoundException e) {
/* 117 */       throw new DetailedSemanticException("Unable to locate class [" + className + "]", e);
/*     */ 
/*     */     }
/*     */     catch (PropertyNotFoundException e)
/*     */     {
/* 122 */       throw new DetailedSemanticException("Unable to locate appropriate constructor on class [" + className + "]", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public Constructor getConstructor() {
/* 127 */     return this.constructor;
/*     */   }
/*     */   
/*     */   public List getConstructorArgumentTypeList() {
/* 131 */     return Arrays.asList(this.constructorArgumentTypes);
/*     */   }
/*     */   
/*     */   public FromElement getFromElement() {
/* 135 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isConstructor() {
/* 139 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isReturnableEntity() throws SemanticException {
/* 143 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isScalar()
/*     */   {
/* 148 */     return true;
/*     */   }
/*     */   
/*     */   public void setAlias(String alias) {
/* 152 */     throw new UnsupportedOperationException("constructor may not be aliased");
/*     */   }
/*     */   
/*     */   public String getAlias() {
/* 156 */     throw new UnsupportedOperationException("constructor may not be aliased");
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\ConstructorNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */