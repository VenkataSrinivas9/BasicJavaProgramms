/*     */ package org.hibernate.hql.ast.tree;
/*     */ 
/*     */ import antlr.SemanticException;
/*     */ import antlr.collections.AST;
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.dialect.function.SQLFunction;
/*     */ import org.hibernate.hql.CollectionProperties;
/*     */ import org.hibernate.hql.ast.HqlSqlWalker;
/*     */ import org.hibernate.hql.ast.util.ASTUtil;
/*     */ import org.hibernate.hql.ast.util.ColumnHelper;
/*     */ import org.hibernate.hql.ast.util.SessionFactoryHelper;
/*     */ import org.hibernate.persister.collection.QueryableCollection;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.persister.entity.Queryable;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodNode
/*     */   extends AbstractSelectExpression
/*     */   implements SelectExpression
/*     */ {
/*  28 */   private static final Log log = LogFactory.getLog(MethodNode.class);
/*     */   private String methodName;
/*     */   private FromElement fromElement;
/*     */   private String[] selectColumns;
/*     */   private SQLFunction function;
/*     */   private boolean inSelect;
/*     */   
/*     */   public void resolve(boolean inSelect)
/*     */     throws SemanticException
/*     */   {
/*  38 */     AST name = getFirstChild();
/*  39 */     initializeMethodNode(name, inSelect);
/*  40 */     AST exprList = name.getNextSibling();
/*     */     
/*     */ 
/*  43 */     if ((ASTUtil.hasExactlyOneChild(exprList)) && (isCollectionPropertyMethod())) {
/*  44 */       collectionProperty(exprList.getFirstChild(), name);
/*     */     }
/*     */     else {
/*  47 */       dialectFunction(exprList);
/*     */     }
/*     */   }
/*     */   
/*     */   public SQLFunction getSQLFunction() {
/*  52 */     return this.function;
/*     */   }
/*     */   
/*     */   private void dialectFunction(AST exprList) {
/*  56 */     this.function = getSessionFactoryHelper().findSQLFunction(this.methodName);
/*  57 */     if (this.function != null) {
/*  58 */       AST firstChild = exprList != null ? exprList.getFirstChild() : null;
/*  59 */       Type functionReturnType = getSessionFactoryHelper().findFunctionReturnType(this.methodName, firstChild);
/*     */       
/*  61 */       setDataType(functionReturnType);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCollectionPropertyMethod()
/*     */   {
/*  70 */     return CollectionProperties.isAnyCollectionProperty(this.methodName);
/*     */   }
/*     */   
/*     */   public void initializeMethodNode(AST name, boolean inSelect) {
/*  74 */     name.setType(140);
/*  75 */     String text = name.getText();
/*  76 */     this.methodName = text.toLowerCase();
/*  77 */     this.inSelect = inSelect;
/*     */   }
/*     */   
/*     */   private String getMethodName() {
/*  81 */     return this.methodName;
/*     */   }
/*     */   
/*     */   private void collectionProperty(AST path, AST name) throws SemanticException {
/*  85 */     if (path == null) {
/*  86 */       throw new SemanticException("Collection function " + name.getText() + " has no path!");
/*     */     }
/*     */     
/*  89 */     SqlNode expr = (SqlNode)path;
/*  90 */     Type type = expr.getDataType();
/*  91 */     if (log.isDebugEnabled()) {
/*  92 */       log.debug("collectionProperty() :  name=" + name + " type=" + type);
/*     */     }
/*     */     
/*  95 */     resolveCollectionProperty(expr);
/*     */   }
/*     */   
/*     */   public boolean isScalar() throws SemanticException
/*     */   {
/* 100 */     return true;
/*     */   }
/*     */   
/*     */   public void resolveCollectionProperty(AST expr) throws SemanticException {
/* 104 */     String propertyName = CollectionProperties.getNormalizedPropertyName(getMethodName());
/* 105 */     if ((expr instanceof FromReferenceNode)) {
/* 106 */       FromReferenceNode collectionNode = (FromReferenceNode)expr;
/*     */       
/* 108 */       if ("elements".equals(propertyName)) {
/* 109 */         handleElements(collectionNode, propertyName);
/*     */       }
/*     */       else
/*     */       {
/* 113 */         this.fromElement = collectionNode.getFromElement();
/* 114 */         setDataType(this.fromElement.getPropertyType(propertyName, propertyName));
/* 115 */         this.selectColumns = this.fromElement.toColumns(this.fromElement.getTableAlias(), propertyName, this.inSelect);
/*     */       }
/* 117 */       if ((collectionNode instanceof DotNode)) {
/* 118 */         prepareAnyImplicitJoins((DotNode)collectionNode);
/*     */       }
/* 120 */       if (!this.inSelect) {
/* 121 */         this.fromElement.setText("");
/* 122 */         this.fromElement.setUseWhereFragment(false);
/*     */       }
/* 124 */       prepareSelectColumns(this.selectColumns);
/* 125 */       setText(this.selectColumns[0]);
/* 126 */       setType(135);
/*     */     }
/*     */     else {
/* 129 */       throw new SemanticException("Unexpected expression " + expr + " found for collection function " + propertyName);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void prepareAnyImplicitJoins(DotNode dotNode)
/*     */     throws SemanticException
/*     */   {
/* 137 */     if ((dotNode.getLhs() instanceof DotNode)) {
/* 138 */       DotNode lhs = (DotNode)dotNode.getLhs();
/* 139 */       FromElement lhsOrigin = lhs.getFromElement();
/* 140 */       if ((lhsOrigin != null) && ("".equals(lhsOrigin.getText()))) {
/* 141 */         String lhsOriginText = lhsOrigin.getQueryable().getTableName() + " " + lhsOrigin.getTableAlias();
/*     */         
/* 143 */         lhsOrigin.setText(lhsOriginText);
/*     */       }
/* 145 */       prepareAnyImplicitJoins(lhs);
/*     */     }
/*     */   }
/*     */   
/*     */   private void handleElements(FromReferenceNode collectionNode, String propertyName) {
/* 150 */     FromElement collectionFromElement = collectionNode.getFromElement();
/* 151 */     QueryableCollection queryableCollection = collectionFromElement.getQueryableCollection();
/*     */     
/* 153 */     String path = collectionNode.getPath() + "[]." + propertyName;
/* 154 */     log.debug("Creating elements for " + path);
/*     */     
/* 156 */     this.fromElement = collectionFromElement;
/* 157 */     if (!collectionFromElement.isCollectionOfValuesOrComponents()) {
/* 158 */       getWalker().addQuerySpaces(queryableCollection.getElementPersister().getQuerySpaces());
/*     */     }
/*     */     
/* 161 */     setDataType(queryableCollection.getElementType());
/* 162 */     this.selectColumns = collectionFromElement.toColumns(this.fromElement.getTableAlias(), propertyName, this.inSelect);
/*     */   }
/*     */   
/*     */   public void setScalarColumnText(int i) throws SemanticException {
/* 166 */     if (this.selectColumns == null) {
/* 167 */       ColumnHelper.generateSingleScalarColumn(this, i);
/*     */     }
/*     */     else {
/* 170 */       ColumnHelper.generateScalarColumns(this, this.selectColumns, i);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void prepareSelectColumns(String[] columns) {}
/*     */   
/*     */   public FromElement getFromElement()
/*     */   {
/* 179 */     return this.fromElement;
/*     */   }
/*     */   
/*     */   public String getDisplayText() {
/* 183 */     return "{method=" + getMethodName() + ",selectColumns=" + (this.selectColumns == null ? null : Arrays.asList(this.selectColumns)) + ",fromElement=" + this.fromElement.getTableAlias() + "}";
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\MethodNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */