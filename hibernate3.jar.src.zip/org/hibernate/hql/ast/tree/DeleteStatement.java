/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeleteStatement
/*    */   extends AbstractRestrictableStatement
/*    */ {
/* 17 */   private static final Log log = LogFactory.getLog(DeleteStatement.class);
/*    */   
/*    */ 
/*    */ 
/*    */   public int getStatementType()
/*    */   {
/* 23 */     return 13;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean needsExecutor()
/*    */   {
/* 30 */     return true;
/*    */   }
/*    */   
/*    */   protected int getWhereClauseParentTokenType() {
/* 34 */     return 22;
/*    */   }
/*    */   
/*    */   protected Log getLog() {
/* 38 */     return log;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\DeleteStatement.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */