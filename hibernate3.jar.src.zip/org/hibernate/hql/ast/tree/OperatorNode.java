package org.hibernate.hql.ast.tree;

import antlr.SemanticException;
import org.hibernate.type.Type;

public abstract interface OperatorNode
{
  public abstract void initialize()
    throws SemanticException;
  
  public abstract Type getDataType();
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\OperatorNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */