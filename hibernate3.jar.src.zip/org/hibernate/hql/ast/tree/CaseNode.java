/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import antlr.SemanticException;
/*    */ import antlr.collections.AST;
/*    */ import org.hibernate.hql.ast.util.ColumnHelper;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CaseNode
/*    */   extends AbstractSelectExpression
/*    */   implements SelectExpression
/*    */ {
/*    */   public Type getDataType()
/*    */   {
/* 17 */     return getFirstThenNode().getDataType();
/*    */   }
/*    */   
/*    */   private SelectExpression getFirstThenNode() {
/* 21 */     return (SelectExpression)getFirstChild().getFirstChild().getNextSibling();
/*    */   }
/*    */   
/*    */   public void setScalarColumnText(int i) throws SemanticException {
/* 25 */     ColumnHelper.generateSingleScalarColumn(this, i);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\CaseNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */