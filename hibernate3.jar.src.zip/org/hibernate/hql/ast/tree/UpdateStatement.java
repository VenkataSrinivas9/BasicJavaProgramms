/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import antlr.collections.AST;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.hql.ast.util.ASTUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UpdateStatement
/*    */   extends AbstractRestrictableStatement
/*    */ {
/* 20 */   private static final Log log = LogFactory.getLog(UpdateStatement.class);
/*    */   
/*    */ 
/*    */ 
/*    */   public int getStatementType()
/*    */   {
/* 26 */     return 51;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean needsExecutor()
/*    */   {
/* 33 */     return true;
/*    */   }
/*    */   
/*    */   protected int getWhereClauseParentTokenType() {
/* 37 */     return 46;
/*    */   }
/*    */   
/*    */   protected Log getLog() {
/* 41 */     return log;
/*    */   }
/*    */   
/*    */   public AST getSetClause() {
/* 45 */     return ASTUtil.findTypeInChildren(this, 46);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\UpdateStatement.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */