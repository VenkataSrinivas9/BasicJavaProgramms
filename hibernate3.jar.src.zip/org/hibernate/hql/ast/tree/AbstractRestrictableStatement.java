/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import antlr.collections.AST;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.hibernate.hql.ast.HqlSqlWalker;
/*    */ import org.hibernate.hql.ast.util.ASTUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractRestrictableStatement
/*    */   extends AbstractStatement
/*    */   implements RestrictableStatement
/*    */ {
/*    */   private FromClause fromClause;
/*    */   private AST whereClause;
/*    */   
/*    */   protected abstract int getWhereClauseParentTokenType();
/*    */   
/*    */   protected abstract Log getLog();
/*    */   
/*    */   public final FromClause getFromClause()
/*    */   {
/* 28 */     if (this.fromClause == null) {
/* 29 */       this.fromClause = ((FromClause)ASTUtil.findTypeInChildren(this, 22));
/*    */     }
/* 31 */     return this.fromClause;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public final boolean hasWhereClause()
/*    */   {
/* 38 */     AST whereClause = locateWhereClause();
/* 39 */     return (whereClause != null) && (whereClause.getNumberOfChildren() > 0);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public final AST getWhereClause()
/*    */   {
/* 46 */     if (this.whereClause == null) {
/* 47 */       this.whereClause = locateWhereClause();
/*    */       
/* 49 */       if (this.whereClause == null) {
/* 50 */         getLog().debug("getWhereClause() : Creating a new WHERE clause...");
/* 51 */         this.whereClause = ASTUtil.create(getWalker().getASTFactory(), 53, "WHERE");
/*    */         
/* 53 */         AST parent = ASTUtil.findTypeInChildren(this, getWhereClauseParentTokenType());
/* 54 */         this.whereClause.setNextSibling(parent.getNextSibling());
/* 55 */         parent.setNextSibling(this.whereClause);
/*    */       }
/*    */     }
/* 58 */     return this.whereClause;
/*    */   }
/*    */   
/*    */   protected AST locateWhereClause() {
/* 62 */     return ASTUtil.findTypeInChildren(this, 53);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\AbstractRestrictableStatement.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */