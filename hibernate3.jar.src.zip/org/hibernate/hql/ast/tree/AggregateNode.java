/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import antlr.SemanticException;
/*    */ import org.hibernate.hql.ast.util.ColumnHelper;
/*    */ import org.hibernate.hql.ast.util.SessionFactoryHelper;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AggregateNode
/*    */   extends AbstractSelectExpression
/*    */   implements SelectExpression
/*    */ {
/*    */   public Type getDataType()
/*    */   {
/* 21 */     return getSessionFactoryHelper().findFunctionReturnType(getText(), getFirstChild());
/*    */   }
/*    */   
/*    */   public void setScalarColumnText(int i) throws SemanticException {
/* 25 */     ColumnHelper.generateSingleScalarColumn(this, i);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\AggregateNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */