/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import antlr.CommonAST;
/*    */ import antlr.Token;
/*    */ import antlr.collections.AST;
/*    */ import org.hibernate.util.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Node
/*    */   extends CommonAST
/*    */ {
/*    */   private String filename;
/*    */   private int line;
/*    */   private int column;
/*    */   private int textLength;
/*    */   
/*    */   public Node() {}
/*    */   
/*    */   public Node(Token tok)
/*    */   {
/* 24 */     super(tok);
/*    */   }
/*    */   
/*    */   public void initialize(Token tok) {
/* 28 */     super.initialize(tok);
/* 29 */     this.filename = tok.getFilename();
/* 30 */     this.line = tok.getLine();
/* 31 */     this.column = tok.getColumn();
/* 32 */     String text = tok.getText();
/* 33 */     this.textLength = (StringHelper.isEmpty(text) ? 0 : text.length());
/*    */   }
/*    */   
/*    */   public void initialize(AST t) {
/* 37 */     super.initialize(t);
/* 38 */     if ((t instanceof Node))
/*    */     {
/* 40 */       Node n = (Node)t;
/* 41 */       this.filename = n.filename;
/* 42 */       this.line = n.line;
/* 43 */       this.column = n.column;
/* 44 */       this.textLength = n.textLength;
/*    */     }
/*    */   }
/*    */   
/*    */   public String getFilename() {
/* 49 */     return this.filename;
/*    */   }
/*    */   
/*    */   public int getLine() {
/* 53 */     return this.line;
/*    */   }
/*    */   
/*    */   public int getColumn() {
/* 57 */     return this.column;
/*    */   }
/*    */   
/*    */   public int getTextLength() {
/* 61 */     return this.textLength;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\Node.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */