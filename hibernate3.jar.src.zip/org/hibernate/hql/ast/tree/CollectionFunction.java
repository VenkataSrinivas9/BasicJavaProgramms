/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import antlr.SemanticException;
/*    */ import antlr.collections.AST;
/*    */ 
/*    */ 
/*    */ public class CollectionFunction
/*    */   extends MethodNode
/*    */   implements DisplayableNode
/*    */ {
/*    */   public void resolve(boolean inSelect)
/*    */     throws SemanticException
/*    */   {
/* 14 */     initializeMethodNode(this, inSelect);
/* 15 */     if (!isCollectionPropertyMethod()) {
/* 16 */       throw new SemanticException(getText() + " is not a collection property name!");
/*    */     }
/* 18 */     AST expr = getFirstChild();
/* 19 */     if (expr == null) {
/* 20 */       throw new SemanticException(getText() + " requires a path!");
/*    */     }
/* 22 */     resolveCollectionProperty(expr);
/*    */   }
/*    */   
/*    */   protected void prepareSelectColumns(String[] selectColumns)
/*    */   {
/* 27 */     String subselect = selectColumns[0].trim();
/* 28 */     if ((subselect.startsWith("(")) && (subselect.endsWith(")"))) {
/* 29 */       subselect = subselect.substring(1, subselect.length() - 1);
/*    */     }
/* 31 */     selectColumns[0] = subselect;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\CollectionFunction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */