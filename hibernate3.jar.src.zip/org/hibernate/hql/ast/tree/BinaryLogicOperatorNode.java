/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import antlr.SemanticException;
/*    */ import antlr.collections.AST;
/*    */ import org.hibernate.Hibernate;
/*    */ import org.hibernate.param.ParameterSpecification;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BinaryLogicOperatorNode
/*    */   extends SqlNode
/*    */   implements BinaryOperatorNode
/*    */ {
/*    */   public void initialize()
/*    */     throws SemanticException
/*    */   {
/* 18 */     Node lhs = getLeftHandOperand();
/* 19 */     if (lhs == null) {
/* 20 */       throw new SemanticException("left-hand operand of a binary operator was null");
/*    */     }
/* 22 */     Node rhs = getRightHandOperand();
/* 23 */     if (rhs == null) {
/* 24 */       throw new SemanticException("right-hand operand of a binary operator was null");
/*    */     }
/* 26 */     if ((ParameterNode.class.isAssignableFrom(lhs.getClass())) && (SqlNode.class.isAssignableFrom(rhs.getClass())))
/*    */     {
/* 28 */       ((ParameterNode)lhs).getHqlParameterSpecification().setExpectedType(((SqlNode)rhs).getDataType());
/*    */ 
/*    */ 
/*    */     }
/* 32 */     else if ((ParameterNode.class.isAssignableFrom(rhs.getClass())) && (SqlNode.class.isAssignableFrom(lhs.getClass())))
/*    */     {
/* 34 */       ((ParameterNode)rhs).getHqlParameterSpecification().setExpectedType(((SqlNode)lhs).getDataType());
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Type getDataType()
/*    */   {
/* 42 */     return Hibernate.BOOLEAN;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Node getLeftHandOperand()
/*    */   {
/* 51 */     return (Node)getFirstChild();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Node getRightHandOperand()
/*    */   {
/* 60 */     return (Node)getFirstChild().getNextSibling();
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\BinaryLogicOperatorNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */