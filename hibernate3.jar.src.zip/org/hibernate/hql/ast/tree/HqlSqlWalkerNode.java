/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import antlr.ASTFactory;
/*    */ import org.hibernate.hql.ast.HqlSqlWalker;
/*    */ import org.hibernate.hql.ast.util.AliasGenerator;
/*    */ import org.hibernate.hql.ast.util.SessionFactoryHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HqlSqlWalkerNode
/*    */   extends SqlNode
/*    */   implements InitializeableNode
/*    */ {
/*    */   private HqlSqlWalker walker;
/*    */   
/*    */   public void initialize(Object param)
/*    */   {
/* 22 */     this.walker = ((HqlSqlWalker)param);
/*    */   }
/*    */   
/*    */   public HqlSqlWalker getWalker() {
/* 26 */     return this.walker;
/*    */   }
/*    */   
/*    */   public SessionFactoryHelper getSessionFactoryHelper() {
/* 30 */     return this.walker.getSessionFactoryHelper();
/*    */   }
/*    */   
/*    */   public ASTFactory getASTFactory() {
/* 34 */     return this.walker.getASTFactory();
/*    */   }
/*    */   
/*    */   public AliasGenerator getAliasGenerator() {
/* 38 */     return this.walker.getAliasGenerator();
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\HqlSqlWalkerNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */