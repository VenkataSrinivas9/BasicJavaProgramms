/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import antlr.SemanticException;
/*    */ import antlr.collections.AST;
/*    */ import org.hibernate.param.ParameterSpecification;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ public class InLogicOperatorNode
/*    */   extends BinaryLogicOperatorNode implements BinaryOperatorNode
/*    */ {
/*    */   public Node getInList()
/*    */   {
/* 13 */     return getRightHandOperand();
/*    */   }
/*    */   
/*    */   public void initialize() throws SemanticException {
/* 17 */     Node lhs = getLeftHandOperand();
/* 18 */     if (lhs == null) {
/* 19 */       throw new SemanticException("left-hand operand of in operator was null");
/*    */     }
/* 21 */     Node inList = getInList();
/* 22 */     if (inList == null) {
/* 23 */       throw new SemanticException("right-hand operand of in operator was null");
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 29 */     if (SqlNode.class.isAssignableFrom(lhs.getClass())) {
/* 30 */       Type lhsType = ((SqlNode)lhs).getDataType();
/* 31 */       AST inListChild = inList.getFirstChild();
/* 32 */       while (inListChild != null) {
/* 33 */         if (ParameterNode.class.isAssignableFrom(inListChild.getClass())) {
/* 34 */           ((ParameterNode)inListChild).getHqlParameterSpecification().setExpectedType(lhsType);
/*    */         }
/* 36 */         inListChild = inListChild.getNextSibling();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\InLogicOperatorNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */