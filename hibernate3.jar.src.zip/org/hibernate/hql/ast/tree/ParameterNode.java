/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import org.hibernate.param.ParameterSpecification;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParameterNode
/*    */   extends HqlSqlWalkerNode
/*    */   implements DisplayableNode
/*    */ {
/*    */   private ParameterSpecification parameterSpecification;
/*    */   
/*    */   public ParameterSpecification getHqlParameterSpecification()
/*    */   {
/* 15 */     return this.parameterSpecification;
/*    */   }
/*    */   
/*    */   public void setHqlParameterSpecification(ParameterSpecification parameterSpecification) {
/* 19 */     this.parameterSpecification = parameterSpecification;
/*    */   }
/*    */   
/*    */   public String getDisplayText() {
/* 23 */     return "{" + (this.parameterSpecification == null ? "???" : this.parameterSpecification.renderDisplayInfo()) + "}";
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\ParameterNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */