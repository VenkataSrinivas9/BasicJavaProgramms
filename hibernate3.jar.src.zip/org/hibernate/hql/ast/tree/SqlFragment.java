/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import org.hibernate.sql.JoinFragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SqlFragment
/*    */   extends Node
/*    */ {
/*    */   private JoinFragment joinFragment;
/*    */   private FromElement fromElement;
/*    */   
/*    */   public void setJoinFragment(JoinFragment joinFragment)
/*    */   {
/* 16 */     this.joinFragment = joinFragment;
/*    */   }
/*    */   
/*    */   public boolean hasFilterCondition() {
/* 20 */     return this.joinFragment.hasFilterCondition();
/*    */   }
/*    */   
/*    */   public void setFromElement(FromElement fromElement) {
/* 24 */     this.fromElement = fromElement;
/*    */   }
/*    */   
/*    */   public FromElement getFromElement() {
/* 28 */     return this.fromElement;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\SqlFragment.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */