/*     */ package org.hibernate.hql.ast.tree;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.engine.JoinSequence;
/*     */ import org.hibernate.hql.CollectionProperties;
/*     */ import org.hibernate.hql.CollectionSubqueryFactory;
/*     */ import org.hibernate.hql.NameGenerator;
/*     */ import org.hibernate.hql.ast.HqlSqlWalker;
/*     */ import org.hibernate.hql.ast.util.SessionFactoryHelper;
/*     */ import org.hibernate.persister.collection.CollectionPropertyMapping;
/*     */ import org.hibernate.persister.collection.QueryableCollection;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.persister.entity.Joinable;
/*     */ import org.hibernate.persister.entity.PropertyMapping;
/*     */ import org.hibernate.persister.entity.Queryable;
/*     */ import org.hibernate.type.EntityType;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.type.TypeFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FromElementType
/*     */ {
/*  32 */   private static final Log log = LogFactory.getLog(FromElementType.class);
/*     */   
/*     */   private FromElement fromElement;
/*     */   private EntityType entityType;
/*     */   private EntityPersister persister;
/*     */   private QueryableCollection queryableCollection;
/*     */   private CollectionPropertyMapping collectionPropertyMapping;
/*     */   private JoinSequence joinSequence;
/*     */   private String collectionSuffix;
/*     */   
/*     */   public FromElementType(FromElement fromElement, EntityPersister persister, EntityType entityType)
/*     */   {
/*  44 */     this.fromElement = fromElement;
/*  45 */     this.persister = persister;
/*  46 */     this.entityType = entityType;
/*  47 */     if (persister != null) {
/*  48 */       fromElement.setText(((Queryable)persister).getTableName() + " " + getTableAlias());
/*     */     }
/*     */   }
/*     */   
/*     */   private String getTableAlias() {
/*  53 */     return this.fromElement.getTableAlias();
/*     */   }
/*     */   
/*     */   private String getCollectionTableAlias() {
/*  57 */     return this.fromElement.getCollectionTableAlias();
/*     */   }
/*     */   
/*     */   public String getCollectionSuffix() {
/*  61 */     return this.collectionSuffix;
/*     */   }
/*     */   
/*     */   public void setCollectionSuffix(String suffix) {
/*  65 */     this.collectionSuffix = suffix;
/*     */   }
/*     */   
/*     */   public EntityPersister getEntityPersister() {
/*  69 */     return this.persister;
/*     */   }
/*     */   
/*     */   public Type getDataType() {
/*  73 */     if (this.persister == null) {
/*  74 */       if (this.queryableCollection == null) {
/*  75 */         return null;
/*     */       }
/*  77 */       return this.queryableCollection.getType();
/*     */     }
/*     */     
/*  80 */     return this.entityType;
/*     */   }
/*     */   
/*     */   public Type getSelectType()
/*     */   {
/*  85 */     if (this.entityType == null) return null;
/*  86 */     boolean shallow = this.fromElement.getFromClause().getWalker().isShallowQuery();
/*  87 */     return TypeFactory.manyToOne(this.entityType.getAssociatedEntityName(), shallow);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Queryable getQueryable()
/*     */   {
/*  96 */     return (this.persister instanceof Queryable) ? (Queryable)this.persister : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String renderScalarIdentifierSelect(int i)
/*     */   {
/* 106 */     checkInitialized();
/* 107 */     String[] cols = getPropertyMapping("id").toColumns(getTableAlias(), "id");
/* 108 */     StringBuffer buf = new StringBuffer();
/*     */     
/* 110 */     for (int j = 0; j < cols.length; j++) {
/* 111 */       String column = cols[j];
/* 112 */       if (j > 0) {
/* 113 */         buf.append(", ");
/*     */       }
/* 115 */       buf.append(column).append(" as ").append(NameGenerator.scalarName(i, j));
/*     */     }
/* 117 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String renderIdentifierSelect(int size, int k)
/*     */   {
/* 128 */     checkInitialized();
/*     */     
/* 130 */     if (this.fromElement.getFromClause().isSubQuery())
/*     */     {
/* 132 */       String[] idColumnNames = this.persister != null ? ((Queryable)this.persister).getIdentifierColumnNames() : new String[0];
/*     */       
/* 134 */       StringBuffer buf = new StringBuffer();
/* 135 */       for (int i = 0; i < idColumnNames.length; i++) {
/* 136 */         buf.append(this.fromElement.getTableAlias()).append('.').append(idColumnNames[i]);
/* 137 */         if (i != idColumnNames.length - 1) buf.append(", ");
/*     */       }
/* 139 */       return buf.toString();
/*     */     }
/*     */     
/* 142 */     if (this.persister == null) {
/* 143 */       throw new QueryException("not an entity");
/*     */     }
/* 145 */     String fragment = ((Queryable)this.persister).identifierSelectFragment(getTableAlias(), getSuffix(size, k));
/* 146 */     return trimLeadingCommaAndSpaces(fragment);
/*     */   }
/*     */   
/*     */   private String getSuffix(int size, int sequence)
/*     */   {
/* 151 */     return generateSuffix(size, sequence);
/*     */   }
/*     */   
/*     */   private static String generateSuffix(int size, int k) {
/* 155 */     String suffix = Integer.toString(k) + '_';
/* 156 */     return suffix;
/*     */   }
/*     */   
/*     */   private void checkInitialized() {
/* 160 */     this.fromElement.checkInitialized();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String renderPropertySelect(int size, int k, boolean allProperties)
/*     */   {
/* 170 */     checkInitialized();
/* 171 */     if (this.persister == null) {
/* 172 */       return "";
/*     */     }
/*     */     
/* 175 */     String fragment = ((Queryable)this.persister).propertySelectFragment(getTableAlias(), getSuffix(size, k), allProperties);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 180 */     return trimLeadingCommaAndSpaces(fragment);
/*     */   }
/*     */   
/*     */   String renderCollectionSelectFragment(int size, int k)
/*     */   {
/* 185 */     if (this.queryableCollection == null) {
/* 186 */       return "";
/*     */     }
/*     */     
/* 189 */     if (this.collectionSuffix == null) {
/* 190 */       this.collectionSuffix = generateSuffix(size, k);
/*     */     }
/* 192 */     String fragment = this.queryableCollection.selectFragment(getCollectionTableAlias(), this.collectionSuffix);
/* 193 */     return trimLeadingCommaAndSpaces(fragment);
/*     */   }
/*     */   
/*     */   public String renderValueCollectionSelectFragment(int size, int k)
/*     */   {
/* 198 */     if (this.queryableCollection == null) {
/* 199 */       return "";
/*     */     }
/*     */     
/* 202 */     if (this.collectionSuffix == null) {
/* 203 */       this.collectionSuffix = generateSuffix(size, k);
/*     */     }
/* 205 */     String fragment = this.queryableCollection.selectFragment(getTableAlias(), this.collectionSuffix);
/* 206 */     return trimLeadingCommaAndSpaces(fragment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String trimLeadingCommaAndSpaces(String fragment)
/*     */   {
/* 218 */     if ((fragment.length() > 0) && (fragment.charAt(0) == ',')) {
/* 219 */       fragment = fragment.substring(1);
/*     */     }
/* 221 */     fragment = fragment.trim();
/* 222 */     return fragment.trim();
/*     */   }
/*     */   
/*     */   public void setJoinSequence(JoinSequence joinSequence) {
/* 226 */     this.joinSequence = joinSequence;
/*     */   }
/*     */   
/*     */   public JoinSequence getJoinSequence() {
/* 230 */     if (this.joinSequence != null) {
/* 231 */       return this.joinSequence;
/*     */     }
/*     */     
/*     */ 
/* 235 */     if ((this.persister instanceof Joinable)) {
/* 236 */       Joinable joinable = (Joinable)this.persister;
/* 237 */       return this.fromElement.getSessionFactoryHelper().createJoinSequence().setRoot(joinable, getTableAlias());
/*     */     }
/*     */     
/* 240 */     return null;
/*     */   }
/*     */   
/*     */   public void setQueryableCollection(QueryableCollection queryableCollection)
/*     */   {
/* 245 */     if (this.queryableCollection != null) {
/* 246 */       throw new IllegalStateException("QueryableCollection is already defined for " + this + "!");
/*     */     }
/* 248 */     this.queryableCollection = queryableCollection;
/* 249 */     if (!queryableCollection.isOneToMany())
/*     */     {
/* 251 */       this.fromElement.setText(queryableCollection.getTableName() + " " + getTableAlias());
/*     */     }
/*     */   }
/*     */   
/*     */   public QueryableCollection getQueryableCollection() {
/* 256 */     return this.queryableCollection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Type getPropertyType(String propertyName, String propertyPath)
/*     */   {
/* 267 */     checkInitialized();
/* 268 */     Type type = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 274 */     if ((this.persister != null) && (propertyName.equals(propertyPath)) && (propertyName.equals(this.persister.getIdentifierPropertyName()))) {
/* 275 */       type = this.persister.getIdentifierType();
/*     */     }
/*     */     else {
/* 278 */       PropertyMapping mapping = getPropertyMapping(propertyName);
/* 279 */       type = mapping.toType(propertyPath);
/*     */     }
/* 281 */     if (type == null) {
/* 282 */       throw new MappingException("Property " + propertyName + " does not exist in " + (this.queryableCollection == null ? "class" : "collection") + " " + (this.queryableCollection == null ? this.fromElement.getClassName() : this.queryableCollection.getRole()));
/*     */     }
/*     */     
/*     */ 
/* 286 */     return type;
/*     */   }
/*     */   
/*     */   String[] toColumns(String tableAlias, String path, boolean inSelect) {
/* 290 */     return toColumns(tableAlias, path, inSelect, false);
/*     */   }
/*     */   
/*     */   String[] toColumns(String tableAlias, String path, boolean inSelect, boolean forceAlias) {
/* 294 */     checkInitialized();
/* 295 */     PropertyMapping propertyMapping = getPropertyMapping(path);
/*     */     
/*     */ 
/* 298 */     if ((!inSelect) && (this.queryableCollection != null) && (CollectionProperties.isCollectionProperty(path))) {
/* 299 */       Map enabledFilters = this.fromElement.getWalker().getEnabledFilters();
/* 300 */       String subquery = CollectionSubqueryFactory.createCollectionSubquery(this.joinSequence, enabledFilters, propertyMapping.toColumns(tableAlias, path));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 305 */       if (log.isDebugEnabled()) {
/* 306 */         log.debug("toColumns(" + tableAlias + "," + path + ") : subquery = " + subquery);
/*     */       }
/* 308 */       return new String[] { "(" + subquery + ")" };
/*     */     }
/*     */     
/*     */ 
/* 312 */     boolean useTableAlias = (this.fromElement.getWalker().getStatementType() == 45) || (this.fromElement.getWalker().getCurrentClauseType() == 45) || (forceAlias);
/*     */     
/*     */ 
/* 315 */     if (useTableAlias) {
/* 316 */       return propertyMapping.toColumns(tableAlias, path);
/*     */     }
/*     */     
/* 319 */     return propertyMapping.toColumns(path);
/*     */   }
/*     */   
/*     */ 
/*     */   PropertyMapping getPropertyMapping(String propertyName)
/*     */   {
/* 325 */     checkInitialized();
/* 326 */     if (this.queryableCollection == null) {
/* 327 */       return (PropertyMapping)this.persister;
/*     */     }
/*     */     
/* 330 */     if (CollectionProperties.isCollectionProperty(propertyName)) {
/* 331 */       if (this.collectionPropertyMapping == null) {
/* 332 */         this.collectionPropertyMapping = new CollectionPropertyMapping(this.queryableCollection);
/*     */       }
/* 334 */       return this.collectionPropertyMapping;
/*     */     }
/* 336 */     if ((this.queryableCollection.getElementType().isComponentType()) && 
/* 337 */       (propertyName.equals("id"))) {
/* 338 */       return (PropertyMapping)this.queryableCollection.getOwnerEntityPersister();
/*     */     }
/*     */     
/* 341 */     return this.queryableCollection;
/*     */   }
/*     */   
/*     */   public boolean isCollectionOfValuesOrComponents() {
/* 345 */     if (this.persister == null) {
/* 346 */       if (this.queryableCollection == null) {
/* 347 */         return false;
/*     */       }
/*     */       
/* 350 */       return !this.queryableCollection.getElementType().isEntityType();
/*     */     }
/*     */     
/*     */ 
/* 354 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isEntity()
/*     */   {
/* 359 */     return this.persister != null;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\FromElementType.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */