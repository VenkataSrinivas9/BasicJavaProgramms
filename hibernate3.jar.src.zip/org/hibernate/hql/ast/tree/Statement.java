package org.hibernate.hql.ast.tree;

import org.hibernate.hql.ast.HqlSqlWalker;

public abstract interface Statement
{
  public abstract HqlSqlWalker getWalker();
  
  public abstract int getStatementType();
  
  public abstract boolean needsExecutor();
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\Statement.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */