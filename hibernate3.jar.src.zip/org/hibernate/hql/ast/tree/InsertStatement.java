/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import org.hibernate.QueryException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InsertStatement
/*    */   extends AbstractStatement
/*    */ {
/*    */   public int getStatementType()
/*    */   {
/* 18 */     return 29;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean needsExecutor()
/*    */   {
/* 25 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void validate()
/*    */     throws QueryException
/*    */   {
/* 34 */     getIntoClause().validateTypes(getSelectClause());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public IntoClause getIntoClause()
/*    */   {
/* 43 */     return (IntoClause)getFirstChild();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SelectClause getSelectClause()
/*    */   {
/* 52 */     return ((QueryNode)getIntoClause().getNextSibling()).getSelectClause();
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\InsertStatement.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */