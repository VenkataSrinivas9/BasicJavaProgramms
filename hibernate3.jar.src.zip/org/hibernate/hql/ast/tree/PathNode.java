package org.hibernate.hql.ast.tree;

public abstract interface PathNode
{
  public abstract String getPath();
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\PathNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */