/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import antlr.SemanticException;
/*    */ import antlr.collections.AST;
/*    */ import org.hibernate.Hibernate;
/*    */ import org.hibernate.param.ParameterSpecification;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ public class BetweenOperatorNode
/*    */   extends SqlNode
/*    */   implements OperatorNode
/*    */ {
/*    */   public void initialize() throws SemanticException
/*    */   {
/* 15 */     Node fixture = getFixtureOperand();
/* 16 */     if (fixture == null) {
/* 17 */       throw new SemanticException("fixture operand of a between operator was null");
/*    */     }
/* 19 */     Node low = getLowOperand();
/* 20 */     if (low == null) {
/* 21 */       throw new SemanticException("low operand of a between operator was null");
/*    */     }
/* 23 */     Node high = getHighOperand();
/* 24 */     if (high == null) {
/* 25 */       throw new SemanticException("high operand of a between operator was null");
/*    */     }
/* 27 */     check(fixture, low, high);
/* 28 */     check(low, high, fixture);
/* 29 */     check(high, fixture, low);
/*    */   }
/*    */   
/*    */   public Type getDataType()
/*    */   {
/* 34 */     return Hibernate.BOOLEAN;
/*    */   }
/*    */   
/*    */   public Node getFixtureOperand() {
/* 38 */     return (Node)getFirstChild();
/*    */   }
/*    */   
/*    */   public Node getLowOperand() {
/* 42 */     return (Node)getFirstChild().getNextSibling();
/*    */   }
/*    */   
/*    */   public Node getHighOperand() {
/* 46 */     return (Node)getFirstChild().getNextSibling().getNextSibling();
/*    */   }
/*    */   
/*    */   private void check(Node check, Node first, Node second) {
/* 50 */     if (ParameterNode.class.isAssignableFrom(check.getClass())) {
/* 51 */       Type expectedType = null;
/* 52 */       if (SqlNode.class.isAssignableFrom(first.getClass())) {
/* 53 */         expectedType = ((SqlNode)first).getDataType();
/*    */       }
/* 55 */       if ((expectedType == null) && (SqlNode.class.isAssignableFrom(second.getClass()))) {
/* 56 */         expectedType = ((SqlNode)second).getDataType();
/*    */       }
/* 58 */       ((ParameterNode)check).getHqlParameterSpecification().setExpectedType(expectedType);
/* 59 */       ((ParameterNode)check).setDataType(expectedType);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\BetweenOperatorNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */