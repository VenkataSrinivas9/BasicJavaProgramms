package org.hibernate.hql.ast.tree;

import antlr.SemanticException;
import org.hibernate.type.Type;

public abstract interface SelectExpression
{
  public abstract Type getDataType();
  
  public abstract void setScalarColumnText(int paramInt)
    throws SemanticException;
  
  public abstract FromElement getFromElement();
  
  public abstract boolean isConstructor();
  
  public abstract boolean isReturnableEntity()
    throws SemanticException;
  
  public abstract void setText(String paramString);
  
  public abstract boolean isScalar()
    throws SemanticException;
  
  public abstract void setAlias(String paramString);
  
  public abstract String getAlias();
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\SelectExpression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */