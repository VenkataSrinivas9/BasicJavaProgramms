/*     */ package org.hibernate.hql.ast.tree;
/*     */ 
/*     */ import antlr.RecognitionException;
/*     */ import antlr.SemanticException;
/*     */ import antlr.collections.AST;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.engine.JoinSequence;
/*     */ import org.hibernate.hql.ast.SqlGenerator;
/*     */ import org.hibernate.hql.ast.util.SessionFactoryHelper;
/*     */ import org.hibernate.persister.collection.QueryableCollection;
/*     */ import org.hibernate.type.CollectionType;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IndexNode
/*     */   extends FromReferenceNode
/*     */ {
/*  26 */   private static final Log log = LogFactory.getLog(IndexNode.class);
/*     */   
/*     */   public void setScalarColumnText(int i) throws SemanticException {
/*  29 */     throw new UnsupportedOperationException("An IndexNode cannot generate column text!");
/*     */   }
/*     */   
/*     */   public void prepareForDot(String propertyName) throws SemanticException {
/*  33 */     FromElement fromElement = getFromElement();
/*  34 */     if (fromElement == null) {
/*  35 */       throw new IllegalStateException("No FROM element for index operator!");
/*     */     }
/*  37 */     QueryableCollection queryableCollection = fromElement.getQueryableCollection();
/*  38 */     if ((queryableCollection != null) && (!queryableCollection.isOneToMany()))
/*     */     {
/*  40 */       FromReferenceNode collectionNode = (FromReferenceNode)getFirstChild();
/*  41 */       String path = collectionNode.getPath() + "[]." + propertyName;
/*  42 */       if (log.isDebugEnabled()) {
/*  43 */         log.debug("Creating join for many-to-many elements for " + path);
/*     */       }
/*  45 */       FromElementFactory factory = new FromElementFactory(fromElement.getFromClause(), fromElement, path);
/*     */       
/*  47 */       FromElement elementJoin = factory.createElementJoin(queryableCollection);
/*  48 */       setFromElement(elementJoin);
/*     */     }
/*     */   }
/*     */   
/*     */   public void resolveIndex(AST parent) throws SemanticException {
/*  53 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void resolve(boolean generateJoin, boolean implicitJoin, String classAlias, AST parent) throws SemanticException
/*     */   {
/*  58 */     if (isResolved()) {
/*  59 */       return;
/*     */     }
/*  61 */     FromReferenceNode collectionNode = (FromReferenceNode)getFirstChild();
/*  62 */     SessionFactoryHelper sessionFactoryHelper = getSessionFactoryHelper();
/*  63 */     collectionNode.resolveIndex(this);
/*     */     
/*  65 */     Type type = collectionNode.getDataType();
/*  66 */     if (!type.isCollectionType()) {
/*  67 */       throw new SemanticException("The [] operator cannot be applied to type " + type.toString());
/*     */     }
/*  69 */     String collectionRole = ((CollectionType)type).getRole();
/*  70 */     QueryableCollection queryableCollection = sessionFactoryHelper.requireQueryableCollection(collectionRole);
/*  71 */     if (!queryableCollection.hasIndex()) {
/*  72 */       throw new QueryException("unindexed fromElement before []: " + collectionNode.getPath());
/*     */     }
/*     */     
/*     */ 
/*  76 */     FromElement fromElement = collectionNode.getFromElement();
/*  77 */     String elementTable = fromElement.getTableAlias();
/*  78 */     FromClause fromClause = fromElement.getFromClause();
/*  79 */     String path = collectionNode.getPath();
/*     */     
/*  81 */     FromElement elem = fromClause.findCollectionJoin(path);
/*  82 */     if (elem == null) {
/*  83 */       FromElementFactory factory = new FromElementFactory(fromClause, fromElement, path);
/*  84 */       elem = factory.createCollectionElementsJoin(queryableCollection, elementTable);
/*  85 */       if (log.isDebugEnabled()) {
/*  86 */         log.debug("No FROM element found for the elements of collection join path " + path + ", created " + elem);
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*  91 */     else if (log.isDebugEnabled()) {
/*  92 */       log.debug("FROM element found for collection join path " + path);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  97 */     AST index = collectionNode.getNextSibling();
/*  98 */     if (index == null) {
/*  99 */       throw new QueryException("No index value!");
/*     */     }
/*     */     
/* 102 */     setFromElement(fromElement);
/*     */     
/*     */ 
/* 105 */     String collectionTableAlias = elementTable;
/* 106 */     if (elem.getCollectionTableAlias() != null) {
/* 107 */       collectionTableAlias = elem.getCollectionTableAlias();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 112 */     JoinSequence joinSequence = fromElement.getJoinSequence();
/* 113 */     String[] indexCols = queryableCollection.getIndexColumnNames();
/* 114 */     if (indexCols.length != 1) {
/* 115 */       throw new QueryException("composite-index appears in []: " + collectionNode.getPath());
/*     */     }
/* 117 */     SqlGenerator gen = new SqlGenerator(getSessionFactoryHelper().getFactory());
/*     */     try {
/* 119 */       gen.simpleExpr(index);
/*     */     }
/*     */     catch (RecognitionException e) {
/* 122 */       throw new QueryException(e.getMessage(), e);
/*     */     }
/* 124 */     String expression = gen.getSQL();
/* 125 */     joinSequence.addCondition(collectionTableAlias + '.' + indexCols[0] + " = " + expression);
/*     */     
/*     */ 
/* 128 */     String[] elementColumns = queryableCollection.getElementColumnNames(elementTable);
/* 129 */     setText(elementColumns[0]);
/* 130 */     setResolved();
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\IndexNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */