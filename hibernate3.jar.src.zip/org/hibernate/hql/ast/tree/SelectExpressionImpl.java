/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import antlr.SemanticException;
/*    */ import antlr.collections.AST;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SelectExpressionImpl
/*    */   extends FromReferenceNode
/*    */   implements SelectExpression
/*    */ {
/*    */   public void resolveIndex(AST parent)
/*    */     throws SemanticException
/*    */   {
/* 15 */     throw new UnsupportedOperationException();
/*    */   }
/*    */   
/*    */   public void setScalarColumnText(int i) throws SemanticException {
/* 19 */     String text = getFromElement().renderScalarIdentifierSelect(i);
/* 20 */     setText(text);
/*    */   }
/*    */   
/*    */   public void resolve(boolean generateJoin, boolean implicitJoin, String classAlias, AST parent)
/*    */     throws SemanticException
/*    */   {}
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\SelectExpressionImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */