/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImpliedFromElement
/*    */   extends FromElement
/*    */ {
/* 14 */   private boolean impliedInFromClause = false;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 19 */   private boolean inProjectionList = false;
/*    */   
/*    */   public boolean isImplied() {
/* 22 */     return true;
/*    */   }
/*    */   
/*    */   public void setImpliedInFromClause(boolean flag) {
/* 26 */     this.impliedInFromClause = flag;
/*    */   }
/*    */   
/*    */   public boolean isImpliedInFromClause() {
/* 30 */     return this.impliedInFromClause;
/*    */   }
/*    */   
/*    */   public void setInProjectionList(boolean inProjectionList) {
/* 34 */     this.inProjectionList = inProjectionList;
/*    */   }
/*    */   
/*    */   public boolean inProjectionList() {
/* 38 */     return (this.inProjectionList) && (isFromOrJoinFragment());
/*    */   }
/*    */   
/*    */   public boolean isIncludeSubclasses() {
/* 42 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getDisplayText()
/*    */   {
/* 51 */     StringBuffer buf = new StringBuffer();
/* 52 */     buf.append("ImpliedFromElement{");
/* 53 */     appendDisplayText(buf);
/* 54 */     buf.append("}");
/* 55 */     return buf.toString();
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\ImpliedFromElement.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */