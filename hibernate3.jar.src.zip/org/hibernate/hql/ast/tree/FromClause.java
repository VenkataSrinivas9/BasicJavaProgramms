/*     */ package org.hibernate.hql.ast.tree;
/*     */ 
/*     */ import antlr.SemanticException;
/*     */ import antlr.collections.AST;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.hql.antlr.HqlSqlTokenTypes;
/*     */ import org.hibernate.hql.ast.util.ASTIterator;
/*     */ import org.hibernate.hql.ast.util.ASTUtil;
/*     */ import org.hibernate.hql.ast.util.ASTUtil.FilterPredicate;
/*     */ import org.hibernate.hql.ast.util.ASTUtil.IncludePredicate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FromClause
/*     */   extends HqlSqlWalkerNode
/*     */   implements HqlSqlTokenTypes, DisplayableNode
/*     */ {
/*  27 */   private static Log log = LogFactory.getLog(FromClause.class);
/*     */   
/*     */   public static final int ROOT_LEVEL = 1;
/*  30 */   private int level = 1;
/*  31 */   private Set fromElements = new HashSet();
/*  32 */   private Map fromElementByClassAlias = new HashMap();
/*  33 */   private Map fromElementByTableAlias = new HashMap();
/*  34 */   private Map fromElementsByPath = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  40 */   private Map collectionJoinFromElementsByPath = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */   private FromClause parentFromClause;
/*     */   
/*     */ 
/*     */ 
/*     */   private Set childFromClauses;
/*     */   
/*     */ 
/*     */ 
/*  52 */   private int fromElementCounter = 0;
/*     */   
/*     */ 
/*     */ 
/*  56 */   private List impliedElements = new LinkedList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FromElement addFromElement(String path, AST alias)
/*     */     throws SemanticException
/*     */   {
/*  67 */     String classAlias = alias == null ? null : alias.getText();
/*  68 */     checkForDuplicateClassAlias(classAlias);
/*  69 */     FromElementFactory factory = new FromElementFactory(this, null, path, classAlias, null, false);
/*  70 */     return factory.addFromElement();
/*     */   }
/*     */   
/*     */   void registerFromElement(FromElement element) {
/*  74 */     this.fromElements.add(element);
/*  75 */     String classAlias = element.getClassAlias();
/*  76 */     if (classAlias != null)
/*     */     {
/*  78 */       this.fromElementByClassAlias.put(classAlias, element);
/*     */     }
/*     */     
/*  81 */     String tableAlias = element.getTableAlias();
/*  82 */     if (tableAlias != null) {
/*  83 */       this.fromElementByTableAlias.put(tableAlias, element);
/*     */     }
/*     */   }
/*     */   
/*     */   void addDuplicateAlias(String alias, FromElement element) {
/*  88 */     this.fromElementByClassAlias.put(alias, element);
/*     */   }
/*     */   
/*     */   private void checkForDuplicateClassAlias(String classAlias) throws SemanticException {
/*  92 */     if ((classAlias != null) && (this.fromElementByClassAlias.containsKey(classAlias))) {
/*  93 */       throw new SemanticException("Duplicate definition of alias '" + classAlias + "'");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FromElement getFromElement(String aliasOrClassName)
/*     */   {
/* 105 */     FromElement fromElement = (FromElement)this.fromElementByClassAlias.get(aliasOrClassName);
/* 106 */     if ((fromElement == null) && (this.parentFromClause != null)) {
/* 107 */       fromElement = this.parentFromClause.getFromElement(aliasOrClassName);
/*     */     }
/* 109 */     return fromElement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFromElementAlias(String possibleAlias)
/*     */   {
/* 120 */     boolean isAlias = this.fromElementByClassAlias.containsKey(possibleAlias);
/* 121 */     if ((!isAlias) && (this.parentFromClause != null))
/*     */     {
/* 123 */       isAlias = this.parentFromClause.isFromElementAlias(possibleAlias);
/*     */     }
/* 125 */     return isAlias;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getFromElements()
/*     */   {
/* 134 */     return ASTUtil.collectChildren(this, fromElementPredicate);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FromElement getFromElement()
/*     */   {
/* 143 */     return (FromElement)getFromElements().get(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getProjectionList()
/*     */   {
/* 152 */     return ASTUtil.collectChildren(this, projectionListPredicate);
/*     */   }
/*     */   
/*     */   public List getCollectionFetches() {
/* 156 */     return ASTUtil.collectChildren(this, collectionFetchPredicate);
/*     */   }
/*     */   
/*     */   public boolean hasCollectionFecthes() {
/* 160 */     return getCollectionFetches().size() > 0;
/*     */   }
/*     */   
/*     */   public List getExplicitFromElements() {
/* 164 */     return ASTUtil.collectChildren(this, explicitFromPredicate);
/*     */   }
/*     */   
/* 167 */   private static ASTUtil.FilterPredicate fromElementPredicate = new ASTUtil.IncludePredicate() {
/*     */     public boolean include(AST node) {
/* 169 */       FromElement fromElement = (FromElement)node;
/* 170 */       return fromElement.isFromOrJoinFragment();
/*     */     }
/*     */   };
/*     */   
/* 174 */   private static ASTUtil.FilterPredicate projectionListPredicate = new ASTUtil.IncludePredicate() {
/*     */     public boolean include(AST node) {
/* 176 */       FromElement fromElement = (FromElement)node;
/* 177 */       return fromElement.inProjectionList();
/*     */     }
/*     */   };
/*     */   
/* 181 */   private static ASTUtil.FilterPredicate collectionFetchPredicate = new ASTUtil.IncludePredicate() {
/*     */     public boolean include(AST node) {
/* 183 */       FromElement fromElement = (FromElement)node;
/* 184 */       return (fromElement.isFetch()) && (fromElement.getQueryableCollection() != null);
/*     */     }
/*     */   };
/*     */   
/* 188 */   private static ASTUtil.FilterPredicate explicitFromPredicate = new ASTUtil.IncludePredicate() {
/*     */     public boolean include(AST node) {
/* 190 */       FromElement fromElement = (FromElement)node;
/* 191 */       return !fromElement.isImplied();
/*     */     }
/*     */   };
/*     */   
/*     */   FromElement findCollectionJoin(String path) {
/* 196 */     return (FromElement)this.collectionJoinFromElementsByPath.get(path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   FromElement findJoinByPath(String path)
/*     */   {
/* 204 */     FromElement elem = findJoinByPathLocal(path);
/* 205 */     if ((elem == null) && (this.parentFromClause != null)) {
/* 206 */       elem = this.parentFromClause.findJoinByPath(path);
/*     */     }
/* 208 */     return elem;
/*     */   }
/*     */   
/*     */   FromElement findJoinByPathLocal(String path) {
/* 212 */     Map joinsByPath = this.fromElementsByPath;
/* 213 */     return (FromElement)joinsByPath.get(path);
/*     */   }
/*     */   
/*     */   void addJoinByPathMap(String path, FromElement destination) {
/* 217 */     if (log.isDebugEnabled()) {
/* 218 */       log.debug("addJoinByPathMap() : " + path + " -> " + destination);
/*     */     }
/* 220 */     this.fromElementsByPath.put(path, destination);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsClassAlias(String alias)
/*     */   {
/* 230 */     return this.fromElementByClassAlias.keySet().contains(alias);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsTableAlias(String alias)
/*     */   {
/* 240 */     return this.fromElementByTableAlias.keySet().contains(alias);
/*     */   }
/*     */   
/*     */   public String getDisplayText() {
/* 244 */     return "FromClause{level=" + this.level + ", fromElementCounter=" + this.fromElementCounter + ", fromElements=" + this.fromElements.size() + ", fromElementByClassAlias=" + this.fromElementByClassAlias.keySet() + ", fromElementByTableAlias=" + this.fromElementByTableAlias.keySet() + ", fromElementsByPath=" + this.fromElementsByPath.keySet() + ", collectionJoinFromElementsByPath=" + this.collectionJoinFromElementsByPath.keySet() + ", impliedElements=" + this.impliedElements + "}";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParentFromClause(FromClause parentFromClause)
/*     */   {
/* 257 */     this.parentFromClause = parentFromClause;
/* 258 */     if (parentFromClause != null) {
/* 259 */       this.level = (parentFromClause.getLevel() + 1);
/* 260 */       parentFromClause.addChild(this);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addChild(FromClause fromClause) {
/* 265 */     if (this.childFromClauses == null) {
/* 266 */       this.childFromClauses = new HashSet();
/*     */     }
/* 268 */     this.childFromClauses.add(fromClause);
/*     */   }
/*     */   
/*     */   public FromClause locateChildFromClauseWithJoinByPath(String path) {
/* 272 */     if ((this.childFromClauses != null) && (!this.childFromClauses.isEmpty())) {
/* 273 */       Iterator children = this.childFromClauses.iterator();
/* 274 */       while (children.hasNext()) {
/* 275 */         FromClause child = (FromClause)children.next();
/* 276 */         if (child.findJoinByPathLocal(path) != null) {
/* 277 */           return child;
/*     */         }
/*     */       }
/*     */     }
/* 281 */     return null;
/*     */   }
/*     */   
/*     */   public void promoteJoin(FromElement elem) {
/* 285 */     if (log.isDebugEnabled()) {
/* 286 */       log.debug("Promoting [" + elem + "] to [" + this + "]");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSubQuery()
/*     */   {
/* 299 */     return this.parentFromClause != null;
/*     */   }
/*     */   
/*     */   void addCollectionJoinFromElementByPath(String path, FromElement destination) {
/* 303 */     if (log.isDebugEnabled()) {
/* 304 */       log.debug("addCollectionJoinFromElementByPath() : " + path + " -> " + destination);
/*     */     }
/* 306 */     this.collectionJoinFromElementsByPath.put(path, destination);
/*     */   }
/*     */   
/*     */   public FromClause getParentFromClause() {
/* 310 */     return this.parentFromClause;
/*     */   }
/*     */   
/*     */   public int getLevel() {
/* 314 */     return this.level;
/*     */   }
/*     */   
/*     */   public int nextFromElementCounter() {
/* 318 */     return this.fromElementCounter++;
/*     */   }
/*     */   
/*     */   public void resolve()
/*     */   {
/* 323 */     ASTIterator iter = new ASTIterator(getFirstChild());
/* 324 */     Set childrenInTree = new HashSet();
/* 325 */     while (iter.hasNext()) {
/* 326 */       childrenInTree.add(iter.next());
/*     */     }
/* 328 */     for (Iterator iterator = this.fromElements.iterator(); iterator.hasNext();) {
/* 329 */       FromElement fromElement = (FromElement)iterator.next();
/* 330 */       if (!childrenInTree.contains(fromElement)) {
/* 331 */         throw new IllegalStateException("Element not in AST: " + fromElement);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void addImpliedFromElement(FromElement element) {
/* 337 */     this.impliedElements.add(element);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 341 */     return "FromClause{level=" + this.level + "}";
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\FromClause.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */