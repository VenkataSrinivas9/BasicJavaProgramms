/*     */ package org.hibernate.hql.ast.tree;
/*     */ 
/*     */ import antlr.SemanticException;
/*     */ import antlr.collections.AST;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FromReferenceNode
/*     */   extends AbstractSelectExpression
/*     */   implements ResolvableNode, DisplayableNode, InitializeableNode, PathNode
/*     */ {
/*  18 */   private static final Log log = LogFactory.getLog(FromReferenceNode.class);
/*     */   
/*     */   private FromElement fromElement;
/*  21 */   private boolean resolved = false;
/*     */   public static final int ROOT_LEVEL = 0;
/*     */   
/*     */   public FromElement getFromElement() {
/*  25 */     return this.fromElement;
/*     */   }
/*     */   
/*     */   public void setFromElement(FromElement fromElement) {
/*  29 */     this.fromElement = fromElement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void resolveFirstChild()
/*     */     throws SemanticException
/*     */   {}
/*     */   
/*     */ 
/*     */   public String getPath()
/*     */   {
/*  41 */     return getOriginalText();
/*     */   }
/*     */   
/*     */   public boolean isResolved() {
/*  45 */     return this.resolved;
/*     */   }
/*     */   
/*     */   public void setResolved() {
/*  49 */     this.resolved = true;
/*  50 */     if (log.isDebugEnabled()) {
/*  51 */       log.debug("Resolved :  " + getPath() + " -> " + getText());
/*     */     }
/*     */   }
/*     */   
/*     */   public String getDisplayText() {
/*  56 */     StringBuffer buf = new StringBuffer();
/*  57 */     buf.append("{").append(this.fromElement == null ? "no fromElement" : this.fromElement.getDisplayText());
/*  58 */     buf.append("}");
/*  59 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public void recursiveResolve(int level, boolean impliedAtRoot, String classAlias) throws SemanticException {
/*  63 */     recursiveResolve(level, impliedAtRoot, classAlias, this);
/*     */   }
/*     */   
/*     */   public void recursiveResolve(int level, boolean impliedAtRoot, String classAlias, AST parent) throws SemanticException {
/*  67 */     AST lhs = getFirstChild();
/*  68 */     int nextLevel = level + 1;
/*  69 */     if (lhs != null) {
/*  70 */       FromReferenceNode n = (FromReferenceNode)lhs;
/*  71 */       n.recursiveResolve(nextLevel, impliedAtRoot, null, this);
/*     */     }
/*  73 */     resolveFirstChild();
/*  74 */     boolean impliedJoin = true;
/*  75 */     if ((level == 0) && (!impliedAtRoot)) {
/*  76 */       impliedJoin = false;
/*     */     }
/*  78 */     resolve(true, impliedJoin, classAlias, parent);
/*     */   }
/*     */   
/*     */   public boolean isReturnableEntity() throws SemanticException {
/*  82 */     return (!isScalar()) && (this.fromElement.isEntity());
/*     */   }
/*     */   
/*     */   public void resolveInFunctionCall(boolean generateJoin, boolean implicitJoin) throws SemanticException {
/*  86 */     resolve(generateJoin, implicitJoin);
/*     */   }
/*     */   
/*     */   public void resolve(boolean generateJoin, boolean implicitJoin) throws SemanticException {
/*  90 */     resolve(generateJoin, implicitJoin, null);
/*     */   }
/*     */   
/*     */   public void resolve(boolean generateJoin, boolean implicitJoin, String classAlias) throws SemanticException {
/*  94 */     resolve(generateJoin, implicitJoin, classAlias, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void prepareForDot(String propertyName)
/*     */     throws SemanticException
/*     */   {}
/*     */   
/*     */ 
/*     */   public FromElement getImpliedJoin()
/*     */   {
/* 106 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\FromReferenceNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */