/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import antlr.collections.AST;
/*    */ import java.util.ArrayList;
/*    */ import org.hibernate.hql.antlr.SqlTokenTypes;
/*    */ import org.hibernate.hql.ast.util.ASTPrinter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SelectExpressionList
/*    */   extends HqlSqlWalkerNode
/*    */ {
/*    */   public SelectExpression[] collectSelectExpressions()
/*    */   {
/* 25 */     AST firstChild = getFirstSelectExpression();
/* 26 */     AST parent = this;
/* 27 */     ArrayList list = new ArrayList(parent.getNumberOfChildren());
/* 28 */     for (AST n = firstChild; n != null; n = n.getNextSibling()) {
/* 29 */       if ((n instanceof SelectExpression)) {
/* 30 */         list.add(n);
/*    */       }
/*    */       else {
/* 33 */         throw new IllegalStateException("Unexpected AST: " + n.getClass().getName() + " " + new ASTPrinter(SqlTokenTypes.class).showAsString(n, ""));
/*    */       }
/*    */     }
/* 36 */     return (SelectExpression[])list.toArray(new SelectExpression[list.size()]);
/*    */   }
/*    */   
/*    */   protected abstract AST getFirstSelectExpression();
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\SelectExpressionList.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */