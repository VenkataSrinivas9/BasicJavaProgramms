/*     */ package org.hibernate.hql.ast.tree;
/*     */ 
/*     */ import antlr.collections.AST;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.hql.ast.SqlGenerator;
/*     */ import org.hibernate.hql.ast.util.ASTUtil;
/*     */ import org.hibernate.hql.ast.util.ASTUtil.IncludePredicate;
/*     */ import org.hibernate.param.ParameterSpecification;
/*     */ import org.hibernate.persister.entity.Queryable;
/*     */ import org.hibernate.persister.entity.UnionSubclassEntityPersister;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AssignmentSpecification
/*     */ {
/*     */   private final Set tableNames;
/*     */   private final ParameterSpecification[] hqlParameters;
/*     */   private final AST eq;
/*     */   private final SessionFactoryImplementor factory;
/*     */   private String sqlAssignmentString;
/*     */   
/*     */   public AssignmentSpecification(AST eq, Queryable persister)
/*     */   {
/*  38 */     if (eq.getType() != 96) {
/*  39 */       throw new QueryException("assignment in set-clause not associated with equals");
/*     */     }
/*     */     
/*  42 */     this.eq = eq;
/*  43 */     this.factory = persister.getFactory();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  49 */     DotNode lhs = (DotNode)eq.getFirstChild();
/*  50 */     SqlNode rhs = (SqlNode)lhs.getNextSibling();
/*     */     
/*  52 */     validateLhs(lhs);
/*     */     
/*  54 */     String propertyPath = lhs.getPropertyPath();
/*  55 */     Set temp = new HashSet();
/*     */     
/*  57 */     if ((persister instanceof UnionSubclassEntityPersister)) {
/*  58 */       UnionSubclassEntityPersister usep = (UnionSubclassEntityPersister)persister;
/*  59 */       String[] tables = persister.getConstraintOrderedTableNameClosure();
/*  60 */       int size = tables.length;
/*  61 */       for (int i = 0; i < size; i++) {
/*  62 */         temp.add(tables[i]);
/*     */       }
/*     */     }
/*     */     else {
/*  66 */       temp.add(persister.getSubclassTableName(persister.getSubclassPropertyTableNumber(propertyPath)));
/*     */     }
/*     */     
/*     */ 
/*  70 */     this.tableNames = Collections.unmodifiableSet(temp);
/*     */     
/*  72 */     if (rhs == null) {
/*  73 */       this.hqlParameters = new ParameterSpecification[0];
/*     */     }
/*  75 */     else if (isParam(rhs)) {
/*  76 */       this.hqlParameters = new ParameterSpecification[] { ((ParameterNode)rhs).getHqlParameterSpecification() };
/*     */     }
/*     */     else {
/*  79 */       List parameterList = ASTUtil.collectChildren(rhs, new ASTUtil.IncludePredicate()
/*     */       {
/*     */         public boolean include(AST node)
/*     */         {
/*  83 */           return AssignmentSpecification.isParam(node);
/*     */         }
/*     */         
/*  86 */       });
/*  87 */       this.hqlParameters = new ParameterSpecification[parameterList.size()];
/*  88 */       Iterator itr = parameterList.iterator();
/*  89 */       int i = 0;
/*  90 */       while (itr.hasNext()) {
/*  91 */         this.hqlParameters[(i++)] = ((ParameterNode)itr.next()).getHqlParameterSpecification();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean affectsTable(String tableName) {
/*  97 */     return this.tableNames.contains(tableName);
/*     */   }
/*     */   
/*     */   public ParameterSpecification[] getParameters() {
/* 101 */     return this.hqlParameters;
/*     */   }
/*     */   
/*     */   public String getSqlAssignmentFragment() {
/* 105 */     if (this.sqlAssignmentString == null) {
/*     */       try {
/* 107 */         SqlGenerator sqlGenerator = new SqlGenerator(this.factory);
/* 108 */         sqlGenerator.comparisonExpr(this.eq, false);
/* 109 */         this.sqlAssignmentString = sqlGenerator.getSQL();
/*     */       }
/*     */       catch (Throwable t) {
/* 112 */         throw new QueryException("cannot interpret set-clause assignment");
/*     */       }
/*     */     }
/* 115 */     return this.sqlAssignmentString;
/*     */   }
/*     */   
/*     */   private static boolean isParam(AST node) {
/* 119 */     return (node.getType() == 116) || (node.getType() == 141);
/*     */   }
/*     */   
/*     */   private void validateLhs(FromReferenceNode lhs)
/*     */   {
/* 124 */     if (!lhs.isResolved()) {
/* 125 */       throw new UnsupportedOperationException("cannot validate assignablity of unresolved node");
/*     */     }
/*     */     
/* 128 */     if (lhs.getDataType().isCollectionType()) {
/* 129 */       throw new QueryException("collections not assignable in update statements");
/*     */     }
/* 131 */     if (lhs.getDataType().isComponentType()) {
/* 132 */       throw new QueryException("Components currently not assignable in update statements");
/*     */     }
/* 134 */     if ((!lhs.getDataType().isEntityType()) || (
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 139 */       (lhs.getImpliedJoin() != null) || (lhs.getFromElement().isImplied()))) {
/* 140 */       throw new QueryException("Implied join paths are not assignable in update statements");
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\AssignmentSpecification.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */