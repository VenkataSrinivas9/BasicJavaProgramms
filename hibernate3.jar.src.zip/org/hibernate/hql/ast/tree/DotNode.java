/*     */ package org.hibernate.hql.ast.tree;
/*     */ 
/*     */ import antlr.SemanticException;
/*     */ import antlr.collections.AST;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.engine.JoinSequence;
/*     */ import org.hibernate.hql.CollectionProperties;
/*     */ import org.hibernate.hql.ast.HqlSqlWalker;
/*     */ import org.hibernate.hql.ast.util.ASTPrinter;
/*     */ import org.hibernate.hql.ast.util.ASTUtil;
/*     */ import org.hibernate.hql.ast.util.AliasGenerator;
/*     */ import org.hibernate.hql.ast.util.ColumnHelper;
/*     */ import org.hibernate.hql.ast.util.LiteralProcessor;
/*     */ import org.hibernate.hql.ast.util.SessionFactoryHelper;
/*     */ import org.hibernate.persister.collection.QueryableCollection;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.persister.entity.Queryable;
/*     */ import org.hibernate.type.CollectionType;
/*     */ import org.hibernate.type.EntityType;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DotNode
/*     */   extends FromReferenceNode
/*     */   implements DisplayableNode, SelectExpression
/*     */ {
/*  38 */   private static final Log log = LogFactory.getLog(DotNode.class);
/*     */   
/*     */ 
/*     */   private static final int DEREF_UNKNOWN = 0;
/*     */   
/*     */ 
/*     */   private static final int DEREF_ENTITY = 1;
/*     */   
/*     */ 
/*     */   private static final int DEREF_COMPONENT = 2;
/*     */   
/*     */ 
/*     */   private static final int DEREF_COLLECTION = 3;
/*     */   
/*     */ 
/*     */   private static final int DEREF_PRIMITIVE = 4;
/*     */   
/*     */ 
/*     */   private static final int DEREF_IDENTIFIER = 5;
/*     */   
/*     */ 
/*     */   private static final int DEREF_JAVA_CONSTANT = 6;
/*     */   
/*     */   private String propertyName;
/*     */   
/*     */   private String path;
/*     */   
/*     */   private String propertyPath;
/*     */   
/*     */   private String[] columns;
/*     */   
/*  69 */   private int joinType = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  74 */   private boolean fetch = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  79 */   private int dereferenceType = 0;
/*     */   
/*     */ 
/*     */ 
/*     */   private FromElement impliedJoin;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setJoinType(int joinType)
/*     */   {
/*  90 */     this.joinType = joinType;
/*     */   }
/*     */   
/*     */   private String[] getColumns() throws QueryException {
/*  94 */     if (this.columns == null)
/*     */     {
/*  96 */       String tableAlias = getLhs().getFromElement().getTableAlias();
/*  97 */       this.columns = getFromElement().toColumns(tableAlias, this.propertyPath, false);
/*     */     }
/*  99 */     return this.columns;
/*     */   }
/*     */   
/*     */   public String getDisplayText() {
/* 103 */     StringBuffer buf = new StringBuffer();
/* 104 */     FromElement fromElement = getFromElement();
/* 105 */     buf.append("{propertyName=").append(this.propertyName);
/* 106 */     buf.append(",dereferenceType=").append(ASTPrinter.getConstantName(getClass(), this.dereferenceType));
/* 107 */     buf.append(",propertyPath=").append(this.propertyPath);
/* 108 */     buf.append(",path=").append(getPath());
/* 109 */     if (fromElement != null) {
/* 110 */       buf.append(",tableAlias=").append(fromElement.getTableAlias());
/* 111 */       buf.append(",className=").append(fromElement.getClassName());
/* 112 */       buf.append(",classAlias=").append(fromElement.getClassAlias());
/*     */     }
/*     */     else {
/* 115 */       buf.append(",no from element");
/*     */     }
/* 117 */     buf.append('}');
/* 118 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void resolveFirstChild()
/*     */     throws SemanticException
/*     */   {
/* 127 */     FromReferenceNode lhs = (FromReferenceNode)getFirstChild();
/* 128 */     SqlNode property = (SqlNode)lhs.getNextSibling();
/*     */     
/*     */ 
/* 131 */     String propName = property.getText();
/* 132 */     this.propertyName = propName;
/*     */     
/* 134 */     if (this.propertyPath == null) {
/* 135 */       this.propertyPath = propName;
/*     */     }
/*     */     
/*     */ 
/* 139 */     lhs.resolve(true, true, null, this);
/* 140 */     setFromElement(lhs.getFromElement());
/*     */   }
/*     */   
/*     */   public void resolveInFunctionCall(boolean generateJoin, boolean implicitJoin) throws SemanticException {
/* 144 */     if (isResolved()) {
/* 145 */       return;
/*     */     }
/* 147 */     Type propertyType = prepareLhs();
/* 148 */     if ((propertyType != null) && (propertyType.isCollectionType())) {
/* 149 */       resolveIndex(null);
/*     */     }
/*     */     else {
/* 152 */       resolveFirstChild();
/* 153 */       super.resolve(generateJoin, implicitJoin);
/*     */     }
/*     */   }
/*     */   
/*     */   public void resolveIndex(AST parent) throws SemanticException
/*     */   {
/* 159 */     if (isResolved()) {
/* 160 */       return;
/*     */     }
/* 162 */     Type propertyType = prepareLhs();
/* 163 */     dereferenceCollection((CollectionType)propertyType, true, true, null, parent);
/*     */   }
/*     */   
/*     */   public void resolve(boolean generateJoin, boolean implicitJoin, String classAlias, AST parent)
/*     */     throws SemanticException
/*     */   {
/* 169 */     if (isResolved()) {
/* 170 */       return;
/*     */     }
/* 172 */     Type propertyType = prepareLhs();
/*     */     
/*     */ 
/*     */ 
/* 176 */     if (propertyType == null) {
/* 177 */       if (parent == null) {
/* 178 */         getWalker().getLiteralProcessor().lookupConstant(this);
/*     */       }
/*     */       
/*     */ 
/* 182 */       return;
/*     */     }
/*     */     
/*     */ 
/* 186 */     if (propertyType.isComponentType()) {
/* 187 */       checkLhsIsNotCollection();
/* 188 */       dereferenceComponent(parent);
/* 189 */       initText();
/*     */ 
/*     */     }
/* 192 */     else if (propertyType.isEntityType()) {
/* 193 */       checkLhsIsNotCollection();
/* 194 */       dereferenceEntity((EntityType)propertyType, implicitJoin, classAlias, generateJoin, parent);
/* 195 */       initText();
/*     */ 
/*     */     }
/* 198 */     else if (propertyType.isCollectionType()) {
/* 199 */       checkLhsIsNotCollection();
/* 200 */       dereferenceCollection((CollectionType)propertyType, implicitJoin, false, classAlias, parent);
/*     */     }
/*     */     else {
/* 203 */       this.dereferenceType = 4;
/* 204 */       initText();
/*     */     }
/* 206 */     setResolved();
/*     */   }
/*     */   
/*     */   private void initText() {
/* 210 */     String[] cols = getColumns();
/* 211 */     String text = StringHelper.join(", ", cols);
/* 212 */     if ((cols.length > 1) && (getWalker().isComparativeExpressionClause())) {
/* 213 */       text = "(" + text + ")";
/*     */     }
/* 215 */     setText(text);
/*     */   }
/*     */   
/*     */   private Type prepareLhs() throws SemanticException {
/* 219 */     FromReferenceNode lhs = getLhs();
/* 220 */     lhs.prepareForDot(this.propertyName);
/* 221 */     Type propertyType = getDataType();
/* 222 */     return propertyType;
/*     */   }
/*     */   
/*     */   private void dereferenceCollection(CollectionType collectionType, boolean implicitJoin, boolean indexed, String classAlias, AST parent)
/*     */     throws SemanticException
/*     */   {
/* 228 */     this.dereferenceType = 3;
/* 229 */     String role = collectionType.getRole();
/*     */     
/*     */ 
/* 232 */     boolean isSizeProperty = (getNextSibling() != null) && (CollectionProperties.isAnyCollectionProperty(getNextSibling().getText()));
/*     */     
/*     */ 
/* 235 */     if (isSizeProperty) { indexed = true;
/*     */     }
/* 237 */     QueryableCollection queryableCollection = getSessionFactoryHelper().requireQueryableCollection(role);
/* 238 */     String propName = getPath();
/* 239 */     FromClause currentFromClause = getWalker().getCurrentFromClause();
/*     */     
/* 241 */     if ((getWalker().getStatementType() != 45) && (indexed) && (classAlias == null))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 248 */       String alias = getLhs().getFromElement().getQueryable().getTableName();
/* 249 */       this.columns = getFromElement().toColumns(alias, this.propertyPath, false, true);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 254 */     FromElementFactory factory = new FromElementFactory(currentFromClause, getLhs().getFromElement(), propName, classAlias, getColumns(), implicitJoin);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 262 */     FromElement elem = factory.createCollection(queryableCollection, role, this.joinType, this.fetch, indexed);
/*     */     
/* 264 */     if (log.isDebugEnabled()) {
/* 265 */       log.debug("dereferenceCollection() : Created new FROM element for " + propName + " : " + elem);
/*     */     }
/*     */     
/* 268 */     setImpliedJoin(elem);
/* 269 */     setFromElement(elem);
/*     */     
/* 271 */     if (isSizeProperty) {
/* 272 */       elem.setText("");
/* 273 */       elem.setUseWhereFragment(false);
/*     */     }
/*     */     
/* 276 */     if (!implicitJoin) {
/* 277 */       EntityPersister entityPersister = elem.getEntityPersister();
/* 278 */       if (entityPersister != null) {
/* 279 */         getWalker().addQuerySpaces(entityPersister.getQuerySpaces());
/*     */       }
/*     */     }
/* 282 */     getWalker().addQuerySpaces(queryableCollection.getCollectionSpaces());
/*     */   }
/*     */   
/*     */   private void dereferenceEntity(EntityType entityType, boolean implicitJoin, String classAlias, boolean generateJoin, AST parent) throws SemanticException {
/* 286 */     checkForCorrelatedSubquery("dereferenceEntity");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 305 */     DotNode parentAsDotNode = null;
/* 306 */     String property = this.propertyName;
/* 307 */     boolean joinIsNeeded = false;
/*     */     
/* 309 */     if (isDotNode(parent)) {
/* 310 */       parentAsDotNode = (DotNode)parent;
/* 311 */       property = parentAsDotNode.propertyName;
/* 312 */       joinIsNeeded = (generateJoin) && (!isReferenceToPrimaryKey(parentAsDotNode.propertyName, entityType));
/*     */     }
/*     */     else {
/* 315 */       joinIsNeeded = (generateJoin) && ((!getWalker().isInSelect()) || (!getWalker().isShallowQuery()));
/*     */     }
/*     */     
/* 318 */     if (joinIsNeeded) {
/* 319 */       dereferenceEntityJoin(classAlias, entityType, implicitJoin, parent);
/*     */     }
/*     */     else {
/* 322 */       dereferenceEntityIdentifier(property, parentAsDotNode);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean unresolvedComponent(boolean generateJoin)
/*     */   {
/* 328 */     AST c = getFirstChild();
/* 329 */     if ((generateJoin) && (isDotNode(c))) {
/* 330 */       DotNode dot = (DotNode)c;
/* 331 */       if (((dot.dereferenceType == 2) || (dot.dereferenceType == 5)) && 
/* 332 */         (StringHelper.isNotEmpty(this.propertyPath))) {
/* 333 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 337 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isDotNode(AST n) {
/* 341 */     return (n != null) && (n.getType() == 15);
/*     */   }
/*     */   
/*     */   private void dereferenceEntityJoin(String classAlias, EntityType propertyType, boolean impliedJoin, AST parent) throws SemanticException
/*     */   {
/* 346 */     this.dereferenceType = 1;
/* 347 */     if (log.isDebugEnabled()) {
/* 348 */       log.debug("dereferenceEntityJoin() : generating join for " + this.propertyName + " in " + getFromElement().getClassName() + " " + (classAlias == null ? "{no alias}" : new StringBuffer().append("(").append(classAlias).append(")").toString()) + " parent = " + ASTUtil.getDebugString(parent));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 355 */     String associatedEntityName = propertyType.getAssociatedEntityName();
/* 356 */     String tableAlias = getAliasGenerator().createName(associatedEntityName);
/*     */     
/* 358 */     String[] joinColumns = getColumns();
/* 359 */     String joinPath = getPath();
/*     */     
/* 361 */     if ((impliedJoin) && (getWalker().isInFrom())) {
/* 362 */       int impliedJoinType = getWalker().getImpliedJoinType();
/* 363 */       this.joinType = impliedJoinType;
/*     */     }
/*     */     
/* 366 */     FromClause currentFromClause = getWalker().getCurrentFromClause();
/* 367 */     FromElement elem = null;
/* 368 */     elem = currentFromClause.findJoinByPath(joinPath);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 397 */     if (elem == null)
/*     */     {
/*     */ 
/* 400 */       JoinSequence joinSequence = getSessionFactoryHelper().createJoinSequence(impliedJoin, propertyType, tableAlias, this.joinType, joinColumns);
/*     */       
/*     */ 
/* 403 */       FromElementFactory factory = new FromElementFactory(currentFromClause, getLhs().getFromElement(), joinPath, classAlias, joinColumns, impliedJoin);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 411 */       elem = factory.createEntityJoin(associatedEntityName, tableAlias, joinSequence, this.fetch, getWalker().isInFrom(), propertyType);
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 421 */       currentFromClause.addDuplicateAlias(classAlias, elem);
/*     */     }
/* 423 */     setImpliedJoin(elem);
/* 424 */     getWalker().addQuerySpaces(elem.getEntityPersister().getQuerySpaces());
/* 425 */     setFromElement(elem);
/*     */   }
/*     */   
/*     */   private void setImpliedJoin(FromElement elem) {
/* 429 */     this.impliedJoin = elem;
/* 430 */     if (getFirstChild().getType() == 15) {
/* 431 */       DotNode dotLhs = (DotNode)getFirstChild();
/* 432 */       if (dotLhs.getImpliedJoin() != null) {
/* 433 */         this.impliedJoin = dotLhs.getImpliedJoin();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public FromElement getImpliedJoin() {
/* 439 */     return this.impliedJoin;
/*     */   }
/*     */   
/*     */   private boolean isReferenceToPrimaryKey(String propertyName, EntityType propertyType) {
/* 443 */     if ("id".equals(propertyName))
/*     */     {
/* 445 */       return propertyType.isReferenceToPrimaryKey();
/*     */     }
/*     */     
/* 448 */     String keyPropertyName = getSessionFactoryHelper().getIdentifierOrUniqueKeyPropertyName(propertyType);
/*     */     
/* 450 */     return (keyPropertyName != null) && (keyPropertyName.equals(propertyName));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkForCorrelatedSubquery(String methodName)
/*     */   {
/* 469 */     if ((isCorrelatedSubselect()) && 
/* 470 */       (log.isDebugEnabled())) {
/* 471 */       log.debug(methodName + "() : correlated subquery");
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isCorrelatedSubselect()
/*     */   {
/* 477 */     return (getWalker().isSubQuery()) && (getFromElement().getFromClause() != getWalker().getCurrentFromClause());
/*     */   }
/*     */   
/*     */   private void checkLhsIsNotCollection() throws SemanticException
/*     */   {
/* 482 */     if ((getLhs().getDataType() != null) && (getLhs().getDataType().isCollectionType()))
/*     */     {
/*     */ 
/* 485 */       throw new SemanticException("illegal syntax near collection: " + this.propertyName); }
/*     */   }
/*     */   
/*     */   private void dereferenceComponent(AST parent) {
/* 489 */     this.dereferenceType = 2;
/* 490 */     setPropertyNameAndPath(parent);
/*     */   }
/*     */   
/*     */ 
/*     */   private void dereferenceEntityIdentifier(String propertyName, DotNode dotParent)
/*     */   {
/* 496 */     if (log.isDebugEnabled()) {
/* 497 */       log.debug("dereferenceShortcut() : property " + propertyName + " in " + getFromElement().getClassName() + " does not require a join.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 502 */     initText();
/* 503 */     setPropertyNameAndPath(dotParent);
/*     */     
/* 505 */     if (dotParent != null) {
/* 506 */       dotParent.dereferenceType = 5;
/* 507 */       dotParent.setText(getText());
/* 508 */       dotParent.columns = getColumns();
/*     */     }
/*     */   }
/*     */   
/*     */   private void setPropertyNameAndPath(AST parent) {
/* 513 */     if (isDotNode(parent)) {
/* 514 */       DotNode dotNode = (DotNode)parent;
/* 515 */       AST lhs = dotNode.getFirstChild();
/* 516 */       AST rhs = lhs.getNextSibling();
/* 517 */       this.propertyName = rhs.getText();
/* 518 */       this.propertyPath = (this.propertyPath + "." + this.propertyName);
/* 519 */       dotNode.propertyPath = this.propertyPath;
/* 520 */       if (log.isDebugEnabled()) {
/* 521 */         log.debug("Unresolved property path is now '" + dotNode.propertyPath + "'");
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 526 */       AST lhs = getFirstChild();
/* 527 */       AST rhs = lhs.getNextSibling();
/* 528 */       this.propertyPath = rhs.getText();
/*     */     }
/*     */   }
/*     */   
/*     */   public Type getDataType() {
/* 533 */     if (super.getDataType() == null) {
/* 534 */       FromElement fromElement = getLhs().getFromElement();
/* 535 */       if (fromElement == null) {
/* 536 */         return null;
/*     */       }
/*     */       
/* 539 */       Type propertyType = fromElement.getPropertyType(this.propertyName, this.propertyPath);
/* 540 */       if (log.isDebugEnabled()) {
/* 541 */         log.debug("getDataType() : " + this.propertyPath + " -> " + propertyType);
/*     */       }
/* 543 */       super.setDataType(propertyType);
/*     */     }
/* 545 */     return super.getDataType();
/*     */   }
/*     */   
/*     */   public void setPropertyPath(String propertyPath) {
/* 549 */     this.propertyPath = propertyPath;
/*     */   }
/*     */   
/*     */   public String getPropertyPath() {
/* 553 */     return this.propertyPath;
/*     */   }
/*     */   
/*     */   public FromReferenceNode getLhs() {
/* 557 */     FromReferenceNode lhs = (FromReferenceNode)getFirstChild();
/* 558 */     if (lhs == null) {
/* 559 */       throw new IllegalStateException("DOT node with no left-hand-side!");
/*     */     }
/* 561 */     return lhs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPath()
/*     */   {
/* 570 */     if (this.path == null) {
/* 571 */       FromReferenceNode lhs = getLhs();
/* 572 */       if (lhs == null) {
/* 573 */         this.path = getText();
/*     */       }
/*     */       else {
/* 576 */         SqlNode rhs = (SqlNode)lhs.getNextSibling();
/* 577 */         this.path = (lhs.getPath() + "." + rhs.getOriginalText());
/*     */       }
/*     */     }
/* 580 */     return this.path;
/*     */   }
/*     */   
/*     */   public void setFetch(boolean fetch) {
/* 584 */     this.fetch = fetch;
/*     */   }
/*     */   
/*     */   public void setScalarColumnText(int i) throws SemanticException {
/* 588 */     String[] sqlColumns = getColumns();
/* 589 */     ColumnHelper.generateScalarColumns(this, sqlColumns, i);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void resolveSelectExpression()
/*     */     throws SemanticException
/*     */   {
/* 598 */     if ((getWalker().isShallowQuery()) || (getWalker().getCurrentFromClause().isSubQuery())) {
/* 599 */       resolve(false, true);
/*     */     }
/*     */     else {
/* 602 */       resolve(true, false);
/* 603 */       Type type = getDataType();
/* 604 */       if (type.isEntityType()) {
/* 605 */         FromElement fromElement = getFromElement();
/* 606 */         fromElement.setIncludeSubclasses(true);
/* 607 */         if (useThetaStyleImplicitJoins) {
/* 608 */           fromElement.getJoinSequence().setUseThetaStyle(true);
/*     */           
/* 610 */           FromElement origin = fromElement.getOrigin();
/* 611 */           if (origin != null) {
/* 612 */             ASTUtil.makeSiblingOfParent(origin, fromElement);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 622 */   public static boolean useThetaStyleImplicitJoins = false;
/*     */   
/*     */   public void setResolvedConstant(String text) {
/* 625 */     this.path = text;
/* 626 */     this.dereferenceType = 6;
/* 627 */     setResolved();
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\DotNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */