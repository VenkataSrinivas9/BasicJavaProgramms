/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import antlr.collections.AST;
/*    */ import org.hibernate.hql.antlr.HqlSqlTokenTypes;
/*    */ import org.hibernate.hql.ast.util.ASTUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OrderByClause
/*    */   extends HqlSqlWalkerNode
/*    */   implements HqlSqlTokenTypes
/*    */ {
/*    */   public void addOrderFragment(String orderByFragment)
/*    */   {
/* 17 */     AST fragment = ASTUtil.create(getASTFactory(), 135, orderByFragment);
/* 18 */     if (getFirstChild() == null) {
/* 19 */       setFirstChild(fragment);
/*    */     }
/*    */     else {
/* 22 */       addChild(fragment);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\OrderByClause.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */