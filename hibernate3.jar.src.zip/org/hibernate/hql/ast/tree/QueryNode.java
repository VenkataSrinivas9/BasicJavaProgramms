/*     */ package org.hibernate.hql.ast.tree;
/*     */ 
/*     */ import antlr.SemanticException;
/*     */ import antlr.collections.AST;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.hql.ast.HqlSqlWalker;
/*     */ import org.hibernate.hql.ast.util.ASTUtil;
/*     */ import org.hibernate.hql.ast.util.ColumnHelper;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueryNode
/*     */   extends AbstractRestrictableStatement
/*     */   implements SelectExpression
/*     */ {
/*  23 */   private static final Log log = LogFactory.getLog(QueryNode.class);
/*     */   
/*     */   private OrderByClause orderByClause;
/*     */   
/*     */   private String alias;
/*     */   
/*     */   public int getStatementType()
/*     */   {
/*  31 */     return 83;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean needsExecutor()
/*     */   {
/*  38 */     return false;
/*     */   }
/*     */   
/*     */   protected int getWhereClauseParentTokenType() {
/*  42 */     return 22;
/*     */   }
/*     */   
/*     */   protected Log getLog() {
/*  46 */     return log;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final SelectClause getSelectClause()
/*     */   {
/*  63 */     return (SelectClause)ASTUtil.findTypeInChildren(this, 130);
/*     */   }
/*     */   
/*     */   public final boolean hasOrderByClause() {
/*  67 */     OrderByClause orderByClause = locateOrderByClause();
/*  68 */     return (orderByClause != null) && (orderByClause.getNumberOfChildren() > 0);
/*     */   }
/*     */   
/*     */   public final OrderByClause getOrderByClause() {
/*  72 */     if (this.orderByClause == null) {
/*  73 */       this.orderByClause = locateOrderByClause();
/*     */       
/*     */ 
/*  76 */       if (this.orderByClause == null) {
/*  77 */         log.debug("getOrderByClause() : Creating a new ORDER BY clause");
/*  78 */         this.orderByClause = ((OrderByClause)ASTUtil.create(getWalker().getASTFactory(), 41, "ORDER"));
/*     */         
/*     */ 
/*  81 */         AST prevSibling = ASTUtil.findTypeInChildren(this, 53);
/*  82 */         if (prevSibling == null) {
/*  83 */           prevSibling = ASTUtil.findTypeInChildren(this, 22);
/*     */         }
/*     */         
/*     */ 
/*  87 */         this.orderByClause.setNextSibling(prevSibling.getNextSibling());
/*  88 */         prevSibling.setNextSibling(this.orderByClause);
/*     */       }
/*     */     }
/*  91 */     return this.orderByClause;
/*     */   }
/*     */   
/*     */   private OrderByClause locateOrderByClause() {
/*  95 */     return (OrderByClause)ASTUtil.findTypeInChildren(this, 41);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getAlias()
/*     */   {
/* 102 */     return this.alias;
/*     */   }
/*     */   
/*     */   public FromElement getFromElement() {
/* 106 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isConstructor() {
/* 110 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isReturnableEntity() throws SemanticException {
/* 114 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isScalar() throws SemanticException {
/* 118 */     return true;
/*     */   }
/*     */   
/*     */   public void setAlias(String alias) {
/* 122 */     this.alias = alias;
/*     */   }
/*     */   
/*     */   public void setScalarColumnText(int i) throws SemanticException {
/* 126 */     ColumnHelper.generateSingleScalarColumn(this, i);
/*     */   }
/*     */   
/*     */   public Type getDataType() {
/* 130 */     return ((SelectExpression)getSelectClause().getFirstSelectExpression()).getDataType();
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\QueryNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */