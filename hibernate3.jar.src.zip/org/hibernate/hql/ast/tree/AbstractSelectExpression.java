/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import antlr.SemanticException;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractSelectExpression
/*    */   extends HqlSqlWalkerNode
/*    */   implements SelectExpression
/*    */ {
/*    */   private String alias;
/*    */   
/*    */   public final void setAlias(String alias)
/*    */   {
/* 18 */     this.alias = alias;
/*    */   }
/*    */   
/*    */   public final String getAlias() {
/* 22 */     return this.alias;
/*    */   }
/*    */   
/*    */   public boolean isConstructor() {
/* 26 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isReturnableEntity() throws SemanticException {
/* 30 */     return false;
/*    */   }
/*    */   
/*    */   public FromElement getFromElement() {
/* 34 */     return null;
/*    */   }
/*    */   
/*    */   public boolean isScalar()
/*    */     throws SemanticException
/*    */   {
/* 40 */     Type type = getDataType();
/* 41 */     return (type != null) && (!type.isAssociationType());
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\AbstractSelectExpression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */