/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import antlr.SemanticException;
/*    */ import org.hibernate.Hibernate;
/*    */ import org.hibernate.hql.antlr.HqlSqlTokenTypes;
/*    */ import org.hibernate.hql.ast.util.ColumnHelper;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LiteralNode
/*    */   extends AbstractSelectExpression
/*    */   implements HqlSqlTokenTypes
/*    */ {
/*    */   public void setScalarColumnText(int i)
/*    */     throws SemanticException
/*    */   {
/* 19 */     ColumnHelper.generateSingleScalarColumn(this, i);
/*    */   }
/*    */   
/*    */   public Type getDataType() {
/* 23 */     switch (getType()) {
/*    */     case 117: 
/* 25 */       return Hibernate.INTEGER;
/*    */     case 93: 
/* 27 */       return Hibernate.FLOAT;
/*    */     case 94: 
/* 29 */       return Hibernate.LONG;
/*    */     case 92: 
/* 31 */       return Hibernate.DOUBLE;
/*    */     case 118: 
/* 33 */       return Hibernate.STRING;
/*    */     case 20: 
/*    */     case 49: 
/* 36 */       return Hibernate.BOOLEAN;
/*    */     }
/* 38 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\LiteralNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */