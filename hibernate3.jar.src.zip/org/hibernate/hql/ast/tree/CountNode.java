/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import antlr.SemanticException;
/*    */ import org.hibernate.hql.ast.util.ColumnHelper;
/*    */ import org.hibernate.hql.ast.util.SessionFactoryHelper;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CountNode
/*    */   extends AbstractSelectExpression
/*    */   implements SelectExpression
/*    */ {
/*    */   public Type getDataType()
/*    */   {
/* 17 */     return getSessionFactoryHelper().findFunctionReturnType(getText(), null);
/*    */   }
/*    */   
/*    */   public void setScalarColumnText(int i) throws SemanticException {
/* 21 */     ColumnHelper.generateSingleScalarColumn(this, i);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\CountNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */