/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import org.hibernate.Hibernate;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ public class UnaryLogicOperatorNode
/*    */   extends SqlNode implements UnaryOperatorNode
/*    */ {
/*    */   public Node getOperand()
/*    */   {
/* 11 */     return (Node)getFirstChild();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void initialize() {}
/*    */   
/*    */ 
/*    */   public Type getDataType()
/*    */   {
/* 21 */     return Hibernate.BOOLEAN;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\UnaryLogicOperatorNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */