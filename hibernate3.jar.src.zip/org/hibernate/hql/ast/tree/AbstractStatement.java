/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ import org.hibernate.hql.ast.HqlSqlWalker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractStatement
/*    */   extends HqlSqlWalkerNode
/*    */   implements DisplayableNode, Statement
/*    */ {
/*    */   public String getDisplayText()
/*    */   {
/* 19 */     StringBuffer buf = new StringBuffer();
/* 20 */     if (getWalker().getQuerySpaces().size() > 0) {
/* 21 */       buf.append(" querySpaces (");
/* 22 */       for (Iterator iterator = getWalker().getQuerySpaces().iterator(); iterator.hasNext();) {
/* 23 */         buf.append(iterator.next());
/* 24 */         if (iterator.hasNext()) {
/* 25 */           buf.append(",");
/*    */         }
/*    */       }
/* 28 */       buf.append(")");
/*    */     }
/* 30 */     return buf.toString();
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\AbstractStatement.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */