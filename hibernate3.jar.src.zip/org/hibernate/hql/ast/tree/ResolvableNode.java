package org.hibernate.hql.ast.tree;

import antlr.SemanticException;
import antlr.collections.AST;

public abstract interface ResolvableNode
{
  public abstract void resolve(boolean paramBoolean1, boolean paramBoolean2, String paramString, AST paramAST)
    throws SemanticException;
  
  public abstract void resolve(boolean paramBoolean1, boolean paramBoolean2, String paramString)
    throws SemanticException;
  
  public abstract void resolve(boolean paramBoolean1, boolean paramBoolean2)
    throws SemanticException;
  
  public abstract void resolveInFunctionCall(boolean paramBoolean1, boolean paramBoolean2)
    throws SemanticException;
  
  public abstract void resolveIndex(AST paramAST)
    throws SemanticException;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\ResolvableNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */