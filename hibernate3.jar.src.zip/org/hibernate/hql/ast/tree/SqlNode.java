/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SqlNode
/*    */   extends Node
/*    */ {
/*    */   private String originalText;
/*    */   private Type dataType;
/*    */   
/*    */   public void setText(String s)
/*    */   {
/* 23 */     super.setText(s);
/* 24 */     if ((s != null) && (s.length() > 0) && (this.originalText == null)) {
/* 25 */       this.originalText = s;
/*    */     }
/*    */   }
/*    */   
/*    */   public String getOriginalText() {
/* 30 */     return this.originalText;
/*    */   }
/*    */   
/*    */   public Type getDataType() {
/* 34 */     return this.dataType;
/*    */   }
/*    */   
/*    */   public void setDataType(Type dataType) {
/* 38 */     this.dataType = dataType;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\SqlNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */