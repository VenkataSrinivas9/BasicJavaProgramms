/*     */ package org.hibernate.hql.ast.tree;
/*     */ 
/*     */ import antlr.collections.AST;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.hql.ast.HqlSqlWalker;
/*     */ import org.hibernate.hql.ast.util.SessionFactoryHelper;
/*     */ import org.hibernate.persister.entity.Queryable;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.ArrayHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntoClause
/*     */   extends HqlSqlWalkerNode
/*     */   implements DisplayableNode
/*     */ {
/*     */   private Queryable persister;
/*  24 */   private String columnSpec = "";
/*     */   
/*     */   private Type[] types;
/*     */   private boolean discriminated;
/*     */   private boolean explicitIdInsertion;
/*     */   private boolean explicitVersionInsertion;
/*     */   
/*     */   public void initialize(Queryable persister)
/*     */   {
/*  33 */     if (persister.isAbstract()) {
/*  34 */       throw new QueryException("cannot insert into abstract class (no table)");
/*     */     }
/*  36 */     this.persister = persister;
/*  37 */     initializeColumns();
/*     */     
/*  39 */     if (getWalker().getSessionFactoryHelper().hasPhysicalDiscriminatorColumn(persister)) {
/*  40 */       this.discriminated = true;
/*  41 */       this.columnSpec = (this.columnSpec + ", " + persister.getDiscriminatorColumnName());
/*     */     }
/*     */     
/*  44 */     resetText();
/*     */   }
/*     */   
/*     */   private void resetText() {
/*  48 */     setText("into " + getTableName() + " ( " + this.columnSpec + " )");
/*     */   }
/*     */   
/*     */   public String getTableName() {
/*  52 */     return this.persister.getSubclassTableName(0);
/*     */   }
/*     */   
/*     */   public Queryable getQueryable() {
/*  56 */     return this.persister;
/*     */   }
/*     */   
/*     */   public String getEntityName() {
/*  60 */     return this.persister.getEntityName();
/*     */   }
/*     */   
/*     */   public Type[] getInsertionTypes() {
/*  64 */     return this.types;
/*     */   }
/*     */   
/*     */   public boolean isDiscriminated() {
/*  68 */     return this.discriminated;
/*     */   }
/*     */   
/*     */   public boolean isExplicitIdInsertion() {
/*  72 */     return this.explicitIdInsertion;
/*     */   }
/*     */   
/*     */   public boolean isExplicitVersionInsertion() {
/*  76 */     return this.explicitVersionInsertion;
/*     */   }
/*     */   
/*     */   public void prependIdColumnSpec() {
/*  80 */     this.columnSpec = (this.persister.getIdentifierColumnNames()[0] + ", " + this.columnSpec);
/*  81 */     resetText();
/*     */   }
/*     */   
/*     */   public void prependVersionColumnSpec() {
/*  85 */     this.columnSpec = (this.persister.getPropertyColumnNames(this.persister.getVersionProperty())[0] + ", " + this.columnSpec);
/*  86 */     resetText();
/*     */   }
/*     */   
/*     */   public void validateTypes(SelectClause selectClause) throws QueryException {
/*  90 */     Type[] selectTypes = selectClause.getQueryReturnTypes();
/*  91 */     if (selectTypes.length != this.types.length) {
/*  92 */       throw new QueryException("number of select types did not match those for insert");
/*     */     }
/*     */     
/*  95 */     for (int i = 0; i < this.types.length; i++) {
/*  96 */       if (!areCompatible(this.types[i], selectTypes[i])) {
/*  97 */         throw new QueryException("insertion type [" + this.types[i] + "] and selection type [" + selectTypes[i] + "] at position " + i + " are not compatible");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDisplayText()
/*     */   {
/* 113 */     StringBuffer buf = new StringBuffer();
/* 114 */     buf.append("IntoClause{");
/* 115 */     buf.append("entityName=").append(getEntityName());
/* 116 */     buf.append(",tableName=").append(getTableName());
/* 117 */     buf.append(",columns={").append(this.columnSpec).append("}");
/* 118 */     buf.append("}");
/* 119 */     return buf.toString();
/*     */   }
/*     */   
/*     */   private void initializeColumns() {
/* 123 */     AST propertySpec = getFirstChild();
/* 124 */     List types = new ArrayList();
/* 125 */     visitPropertySpecNodes(propertySpec.getFirstChild(), types);
/* 126 */     this.types = ArrayHelper.toTypeArray(types);
/* 127 */     this.columnSpec = this.columnSpec.substring(0, this.columnSpec.length() - 2);
/*     */   }
/*     */   
/*     */   private void visitPropertySpecNodes(AST propertyNode, List types) {
/* 131 */     if (propertyNode == null) {
/* 132 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 142 */     String name = propertyNode.getText();
/* 143 */     if (isSuperclassProperty(name)) {
/* 144 */       throw new QueryException("INSERT statements cannot refer to superclass/joined properties [" + name + "]");
/*     */     }
/*     */     
/* 147 */     if (name.equals(this.persister.getIdentifierPropertyName())) {
/* 148 */       this.explicitIdInsertion = true;
/*     */     }
/*     */     
/* 151 */     if ((this.persister.isVersioned()) && 
/* 152 */       (name.equals(this.persister.getPropertyNames()[this.persister.getVersionProperty()]))) {
/* 153 */       this.explicitVersionInsertion = true;
/*     */     }
/*     */     
/*     */ 
/* 157 */     String[] columnNames = this.persister.toColumns(name);
/* 158 */     renderColumns(columnNames);
/* 159 */     types.add(this.persister.toType(name));
/*     */     
/*     */ 
/* 162 */     visitPropertySpecNodes(propertyNode.getNextSibling(), types);
/* 163 */     visitPropertySpecNodes(propertyNode.getFirstChild(), types);
/*     */   }
/*     */   
/*     */   private void renderColumns(String[] columnNames) {
/* 167 */     for (int i = 0; i < columnNames.length; i++) {
/* 168 */       this.columnSpec = (this.columnSpec + columnNames[i] + ", ");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isSuperclassProperty(String propertyName)
/*     */   {
/* 184 */     return this.persister.getSubclassPropertyTableNumber(propertyName) != 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean areCompatible(Type target, Type source)
/*     */   {
/* 195 */     if (target.equals(source))
/*     */     {
/* 197 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 202 */     if (!target.getReturnedClass().isAssignableFrom(source.getReturnedClass())) {
/* 203 */       return false;
/*     */     }
/*     */     
/* 206 */     int[] targetDatatypes = target.sqlTypes(getSessionFactoryHelper().getFactory());
/* 207 */     int[] sourceDatatypes = source.sqlTypes(getSessionFactoryHelper().getFactory());
/*     */     
/* 209 */     if (targetDatatypes.length != sourceDatatypes.length) {
/* 210 */       return false;
/*     */     }
/*     */     
/* 213 */     for (int i = 0; i < targetDatatypes.length; i++) {
/* 214 */       if (!areSqlTypesCompatible(targetDatatypes[i], sourceDatatypes[i])) {
/* 215 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 219 */     return true;
/*     */   }
/*     */   
/*     */   private boolean areSqlTypesCompatible(int target, int source) {
/* 223 */     switch (target) {
/*     */     case 93: 
/* 225 */       return (source == 91) || (source == 92) || (source == 93);
/*     */     case 91: 
/* 227 */       return (source == 91) || (source == 93);
/*     */     case 92: 
/* 229 */       return (source == 92) || (source == 93);
/*     */     }
/* 231 */     return target == source;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\IntoClause.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */