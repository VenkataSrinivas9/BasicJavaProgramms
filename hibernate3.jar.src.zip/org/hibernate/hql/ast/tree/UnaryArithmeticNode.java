/*    */ package org.hibernate.hql.ast.tree;
/*    */ 
/*    */ import antlr.SemanticException;
/*    */ import org.hibernate.hql.ast.util.ColumnHelper;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ public class UnaryArithmeticNode
/*    */   extends AbstractSelectExpression implements UnaryOperatorNode
/*    */ {
/*    */   public Type getDataType()
/*    */   {
/* 12 */     return ((SqlNode)getOperand()).getDataType();
/*    */   }
/*    */   
/*    */   public void setScalarColumnText(int i) throws SemanticException {
/* 16 */     ColumnHelper.generateSingleScalarColumn(this, i);
/*    */   }
/*    */   
/*    */ 
/*    */   public void initialize() {}
/*    */   
/*    */ 
/*    */   public Node getOperand()
/*    */   {
/* 25 */     return (Node)getFirstChild();
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\UnaryArithmeticNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */