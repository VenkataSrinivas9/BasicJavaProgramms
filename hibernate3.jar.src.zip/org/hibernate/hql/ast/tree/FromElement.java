/*     */ package org.hibernate.hql.ast.tree;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.engine.JoinSequence;
/*     */ import org.hibernate.hql.ast.HqlSqlWalker;
/*     */ import org.hibernate.hql.ast.util.ASTUtil;
/*     */ import org.hibernate.persister.collection.QueryableCollection;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.persister.entity.PropertyMapping;
/*     */ import org.hibernate.persister.entity.Queryable;
/*     */ import org.hibernate.type.EntityType;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FromElement
/*     */   extends HqlSqlWalkerNode
/*     */   implements DisplayableNode
/*     */ {
/*  39 */   private static final Log log = LogFactory.getLog(FromElement.class);
/*     */   
/*     */   private String className;
/*     */   private String classAlias;
/*     */   private String tableAlias;
/*     */   private String collectionTableAlias;
/*     */   private FromClause fromClause;
/*  46 */   private boolean includeSubclasses = true;
/*  47 */   private boolean collectionJoin = false;
/*     */   private FromElement origin;
/*     */   private String[] columns;
/*     */   private String role;
/*     */   private boolean fetch;
/*     */   private boolean isAllPropertyFetch;
/*  53 */   private boolean filter = false;
/*  54 */   private int sequence = -1;
/*  55 */   private boolean useFromFragment = false;
/*  56 */   private boolean initialized = false;
/*     */   private FromElementType elementType;
/*  58 */   private boolean useWhereFragment = true;
/*  59 */   private List destinations = new LinkedList();
/*  60 */   private boolean manyToMany = false;
/*  61 */   private String adHocOnClauseFragment = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public String getCollectionSuffix()
/*     */   {
/*  67 */     return this.elementType.getCollectionSuffix();
/*     */   }
/*     */   
/*     */   public void setCollectionSuffix(String suffix) {
/*  71 */     this.elementType.setCollectionSuffix(suffix);
/*     */   }
/*     */   
/*     */   public void initializeCollection(FromClause fromClause, String classAlias, String tableAlias) {
/*  75 */     doInitialize(fromClause, tableAlias, null, classAlias, null, null);
/*  76 */     this.initialized = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initializeEntity(FromClause fromClause, String className, EntityPersister persister, EntityType type, String classAlias, String tableAlias)
/*     */   {
/*  86 */     doInitialize(fromClause, tableAlias, className, classAlias, persister, type);
/*  87 */     this.sequence = fromClause.nextFromElementCounter();
/*  88 */     this.initialized = true;
/*     */   }
/*     */   
/*     */   private void doInitialize(FromClause fromClause, String tableAlias, String className, String classAlias, EntityPersister persister, EntityType type)
/*     */   {
/*  93 */     if (this.initialized) {
/*  94 */       throw new IllegalStateException("Already initialized!!");
/*     */     }
/*  96 */     this.fromClause = fromClause;
/*  97 */     this.tableAlias = tableAlias;
/*  98 */     this.className = className;
/*  99 */     this.classAlias = classAlias;
/* 100 */     this.elementType = new FromElementType(this, persister, type);
/*     */     
/* 102 */     fromClause.registerFromElement(this);
/* 103 */     if (log.isDebugEnabled()) {
/* 104 */       log.debug(fromClause + " :  " + className + " (" + (classAlias == null ? "no alias" : classAlias) + ") -> " + tableAlias);
/*     */     }
/*     */   }
/*     */   
/*     */   public EntityPersister getEntityPersister()
/*     */   {
/* 110 */     return this.elementType.getEntityPersister();
/*     */   }
/*     */   
/*     */   public Type getDataType() {
/* 114 */     return this.elementType.getDataType();
/*     */   }
/*     */   
/*     */   public Type getSelectType() {
/* 118 */     return this.elementType.getSelectType();
/*     */   }
/*     */   
/*     */   public Queryable getQueryable() {
/* 122 */     return this.elementType.getQueryable();
/*     */   }
/*     */   
/*     */   public String getClassName() {
/* 126 */     return this.className;
/*     */   }
/*     */   
/*     */   public String getClassAlias() {
/* 130 */     return this.classAlias;
/*     */   }
/*     */   
/*     */   private String getTableName()
/*     */   {
/* 135 */     Queryable queryable = getQueryable();
/* 136 */     return queryable != null ? queryable.getTableName() : "{none}";
/*     */   }
/*     */   
/*     */   public String getTableAlias() {
/* 140 */     return this.tableAlias;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String renderScalarIdentifierSelect(int i)
/*     */   {
/* 150 */     return this.elementType.renderScalarIdentifierSelect(i);
/*     */   }
/*     */   
/*     */   void checkInitialized() {
/* 154 */     if (!this.initialized) {
/* 155 */       throw new IllegalStateException("FromElement has not been initialized!");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String renderIdentifierSelect(int size, int k)
/*     */   {
/* 167 */     return this.elementType.renderIdentifierSelect(size, k);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String renderPropertySelect(int size, int k)
/*     */   {
/* 178 */     return this.elementType.renderPropertySelect(size, k, this.isAllPropertyFetch);
/*     */   }
/*     */   
/*     */   String renderCollectionSelectFragment(int size, int k) {
/* 182 */     return this.elementType.renderCollectionSelectFragment(size, k);
/*     */   }
/*     */   
/*     */   String renderValueCollectionSelectFragment(int size, int k) {
/* 186 */     return this.elementType.renderValueCollectionSelectFragment(size, k);
/*     */   }
/*     */   
/*     */   public FromClause getFromClause() {
/* 190 */     return this.fromClause;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isImplied()
/*     */   {
/* 200 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDisplayText()
/*     */   {
/* 209 */     StringBuffer buf = new StringBuffer();
/* 210 */     buf.append("FromElement{");
/* 211 */     appendDisplayText(buf);
/* 212 */     buf.append("}");
/* 213 */     return buf.toString();
/*     */   }
/*     */   
/*     */   protected void appendDisplayText(StringBuffer buf) {
/* 217 */     buf.append(isImplied() ? "implied" : isImpliedInFromClause() ? "implied in FROM clause" : "explicit");
/*     */     
/*     */ 
/* 220 */     buf.append(",").append(isCollectionJoin() ? "collection join" : "not a collection join");
/* 221 */     buf.append(",").append(this.fetch ? "fetch join" : "not a fetch join");
/* 222 */     buf.append(",").append(this.isAllPropertyFetch ? "fetch all properties" : "fetch non-lazy properties");
/* 223 */     buf.append(",classAlias=").append(getClassAlias());
/* 224 */     buf.append(",role=").append(this.role);
/* 225 */     buf.append(",tableName=").append(getTableName());
/* 226 */     buf.append(",tableAlias=").append(getTableAlias());
/* 227 */     FromElement origin = getRealOrigin();
/* 228 */     buf.append(",origin=").append(origin == null ? "null" : origin.getText());
/* 229 */     buf.append(",colums={");
/* 230 */     if (this.columns != null) {
/* 231 */       for (int i = 0; i < this.columns.length; i++) {
/* 232 */         buf.append(this.columns[i]);
/* 233 */         if (i < this.columns.length) {
/* 234 */           buf.append(" ");
/*     */         }
/*     */       }
/*     */     }
/* 238 */     buf.append(",className=").append(this.className);
/* 239 */     buf.append("}");
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 243 */     return super.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 247 */     return super.equals(obj);
/*     */   }
/*     */   
/*     */   public void setJoinSequence(JoinSequence joinSequence)
/*     */   {
/* 252 */     this.elementType.setJoinSequence(joinSequence);
/*     */   }
/*     */   
/*     */   public JoinSequence getJoinSequence() {
/* 256 */     return this.elementType.getJoinSequence();
/*     */   }
/*     */   
/*     */   public void setIncludeSubclasses(boolean includeSubclasses) {
/* 260 */     this.includeSubclasses = includeSubclasses;
/*     */   }
/*     */   
/*     */   public boolean isIncludeSubclasses() {
/* 264 */     return this.includeSubclasses;
/*     */   }
/*     */   
/*     */   public String getIdentityColumn() {
/* 268 */     checkInitialized();
/* 269 */     String table = getTableAlias();
/* 270 */     if (table == null)
/* 271 */       throw new IllegalStateException("No table alias for node " + this);
/*     */     String[] cols;
/*     */     String[] cols;
/* 274 */     if (getWalker().getStatementType() == 45) {
/* 275 */       cols = getPropertyMapping("id").toColumns(table, "id");
/*     */     }
/*     */     else {
/* 278 */       cols = getPropertyMapping("id").toColumns("id");
/*     */     }
/* 280 */     String result = StringHelper.join(", ", cols);
/* 281 */     return "(" + result + ")";
/*     */   }
/*     */   
/*     */   public void setCollectionJoin(boolean collectionJoin) {
/* 285 */     this.collectionJoin = collectionJoin;
/*     */   }
/*     */   
/*     */   public boolean isCollectionJoin() {
/* 289 */     return this.collectionJoin;
/*     */   }
/*     */   
/*     */   public void setRole(String role) {
/* 293 */     this.role = role;
/*     */   }
/*     */   
/*     */   public void setQueryableCollection(QueryableCollection queryableCollection) {
/* 297 */     this.elementType.setQueryableCollection(queryableCollection);
/*     */   }
/*     */   
/*     */   public QueryableCollection getQueryableCollection() {
/* 301 */     return this.elementType.getQueryableCollection();
/*     */   }
/*     */   
/*     */   public void setColumns(String[] columns) {
/* 305 */     this.columns = columns;
/*     */   }
/*     */   
/*     */   public void setOrigin(FromElement origin, boolean manyToMany) {
/* 309 */     this.origin = origin;
/* 310 */     this.manyToMany = manyToMany;
/* 311 */     origin.addDestination(this);
/* 312 */     if (origin.getFromClause() == getFromClause())
/*     */     {
/*     */ 
/* 315 */       if (manyToMany) {
/* 316 */         ASTUtil.appendSibling(origin, this);
/*     */ 
/*     */       }
/* 319 */       else if ((!getWalker().isInFrom()) && (!getWalker().isInSelect())) {
/* 320 */         getFromClause().addChild(this);
/*     */       }
/*     */       else {
/* 323 */         origin.addChild(this);
/*     */       }
/*     */       
/*     */     }
/* 327 */     else if (!getWalker().isInFrom())
/*     */     {
/*     */ 
/* 330 */       getFromClause().addChild(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isManyToMany()
/*     */   {
/* 339 */     return this.manyToMany;
/*     */   }
/*     */   
/*     */   private void addDestination(FromElement fromElement) {
/* 343 */     this.destinations.add(fromElement);
/*     */   }
/*     */   
/*     */   public List getDestinations() {
/* 347 */     return this.destinations;
/*     */   }
/*     */   
/*     */   public FromElement getOrigin() {
/* 351 */     return this.origin;
/*     */   }
/*     */   
/*     */   public FromElement getRealOrigin() {
/* 355 */     if (this.origin == null) {
/* 356 */       return null;
/*     */     }
/* 358 */     if ((this.origin.getText() == null) || ("".equals(this.origin.getText()))) {
/* 359 */       return this.origin.getRealOrigin();
/*     */     }
/* 361 */     return this.origin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Type getPropertyType(String propertyName, String propertyPath)
/*     */   {
/* 372 */     return this.elementType.getPropertyType(propertyName, propertyPath);
/*     */   }
/*     */   
/*     */   public String[] toColumns(String tableAlias, String path, boolean inSelect) {
/* 376 */     return this.elementType.toColumns(tableAlias, path, inSelect);
/*     */   }
/*     */   
/*     */   public String[] toColumns(String tableAlias, String path, boolean inSelect, boolean forceAlias) {
/* 380 */     return this.elementType.toColumns(tableAlias, path, inSelect, forceAlias);
/*     */   }
/*     */   
/*     */   public PropertyMapping getPropertyMapping(String propertyName) {
/* 384 */     return this.elementType.getPropertyMapping(propertyName);
/*     */   }
/*     */   
/*     */   public void setFetch(boolean fetch) {
/* 388 */     this.fetch = fetch;
/*     */     
/* 390 */     if ((fetch) && (getWalker().isShallowQuery())) {
/* 391 */       throw new QueryException("fetch may not be used with scroll() or iterate()");
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isFetch() {
/* 396 */     return this.fetch;
/*     */   }
/*     */   
/*     */   public int getSequence() {
/* 400 */     return this.sequence;
/*     */   }
/*     */   
/*     */   public void setFilter(boolean b) {
/* 404 */     this.filter = b;
/*     */   }
/*     */   
/*     */   public boolean isFilter() {
/* 408 */     return this.filter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean useFromFragment()
/*     */   {
/* 415 */     checkInitialized();
/*     */     
/* 417 */     return (!isImplied()) || (this.useFromFragment);
/*     */   }
/*     */   
/*     */   public void setUseFromFragment(boolean useFromFragment) {
/* 421 */     this.useFromFragment = useFromFragment;
/*     */   }
/*     */   
/*     */   public boolean useWhereFragment() {
/* 425 */     return this.useWhereFragment;
/*     */   }
/*     */   
/*     */   public void setUseWhereFragment(boolean b) {
/* 429 */     this.useWhereFragment = b;
/*     */   }
/*     */   
/*     */   public void setCollectionTableAlias(String collectionTableAlias)
/*     */   {
/* 434 */     this.collectionTableAlias = collectionTableAlias;
/*     */   }
/*     */   
/*     */   public String getCollectionTableAlias() {
/* 438 */     return this.collectionTableAlias;
/*     */   }
/*     */   
/*     */   public boolean isCollectionOfValuesOrComponents() {
/* 442 */     return this.elementType.isCollectionOfValuesOrComponents();
/*     */   }
/*     */   
/*     */   public boolean isEntity() {
/* 446 */     return this.elementType.isEntity();
/*     */   }
/*     */   
/*     */   public void setImpliedInFromClause(boolean flag) {
/* 450 */     throw new UnsupportedOperationException("Explicit FROM elements can't be implied in the FROM clause!");
/*     */   }
/*     */   
/*     */   public boolean isImpliedInFromClause() {
/* 454 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInProjectionList(boolean inProjectionList) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean inProjectionList()
/*     */   {
/* 466 */     return (!isImplied()) && (isFromOrJoinFragment());
/*     */   }
/*     */   
/*     */   public boolean isFromOrJoinFragment() {
/* 470 */     return (getType() == 127) || (getType() == 129);
/*     */   }
/*     */   
/*     */   public boolean isAllPropertyFetch() {
/* 474 */     return this.isAllPropertyFetch;
/*     */   }
/*     */   
/*     */   public void setAllPropertyFetch(boolean fetch) {
/* 478 */     this.isAllPropertyFetch = fetch;
/*     */   }
/*     */   
/*     */   public String getAdHocOnClauseFragment() {
/* 482 */     return this.adHocOnClauseFragment;
/*     */   }
/*     */   
/*     */   public void setAdHocOnClauseFragment(String adHocOnClauseFragment) {
/* 486 */     this.adHocOnClauseFragment = adHocOnClauseFragment;
/*     */   }
/*     */   
/*     */   public boolean hasCacheablePersister() {
/* 490 */     if (getQueryableCollection() != null) {
/* 491 */       return getQueryableCollection().hasCache();
/*     */     }
/*     */     
/* 494 */     return getQueryable().hasCache();
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\FromElement.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */