/*     */ package org.hibernate.hql.ast.tree;
/*     */ 
/*     */ import antlr.SemanticException;
/*     */ import antlr.collections.AST;
/*     */ import java.util.List;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.dialect.function.SQLFunction;
/*     */ import org.hibernate.hql.ast.HqlSqlWalker;
/*     */ import org.hibernate.hql.ast.util.ColumnHelper;
/*     */ import org.hibernate.hql.ast.util.LiteralProcessor;
/*     */ import org.hibernate.hql.ast.util.SessionFactoryHelper;
/*     */ import org.hibernate.persister.collection.QueryableCollection;
/*     */ import org.hibernate.persister.entity.Queryable;
/*     */ import org.hibernate.type.CollectionType;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IdentNode
/*     */   extends FromReferenceNode
/*     */   implements SelectExpression
/*     */ {
/*     */   private static final int UNKNOWN = 0;
/*     */   private static final int PROPERTY_REF = 1;
/*     */   private static final int COMPONENT_REF = 2;
/*  32 */   private boolean nakedPropertyRef = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void resolveIndex(AST parent)
/*     */     throws SemanticException
/*     */   {
/*  42 */     if ((!isResolved()) || (!this.nakedPropertyRef)) {
/*  43 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*  46 */     String propertyName = getOriginalText();
/*  47 */     if (!getDataType().isCollectionType()) {
/*  48 */       throw new SemanticException("Collection expected; [" + propertyName + "] does not refer to a collection property");
/*     */     }
/*     */     
/*     */ 
/*  52 */     CollectionType type = (CollectionType)getDataType();
/*  53 */     String role = type.getRole();
/*  54 */     QueryableCollection queryableCollection = getSessionFactoryHelper().requireQueryableCollection(role);
/*     */     
/*  56 */     String alias = null;
/*  57 */     String columnTableAlias = getFromElement().getTableAlias();
/*  58 */     int joinType = 0;
/*  59 */     boolean fetch = false;
/*     */     
/*  61 */     FromElementFactory factory = new FromElementFactory(getWalker().getCurrentFromClause(), getFromElement(), propertyName, alias, getFromElement().toColumns(columnTableAlias, propertyName, false), true);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */     FromElement elem = factory.createCollection(queryableCollection, role, joinType, fetch, true);
/*  70 */     setFromElement(elem);
/*  71 */     getWalker().addQuerySpaces(queryableCollection.getCollectionSpaces());
/*     */   }
/*     */   
/*     */   public void resolve(boolean generateJoin, boolean implicitJoin, String classAlias, AST parent) {
/*  75 */     if (!isResolved()) {
/*  76 */       if (getWalker().getCurrentFromClause().isFromElementAlias(getText())) {
/*  77 */         if (resolveAsAlias()) {
/*  78 */           setResolved();
/*     */         }
/*     */         
/*     */       }
/*  82 */       else if ((parent != null) && (parent.getType() == 15)) {
/*  83 */         DotNode dot = (DotNode)parent;
/*  84 */         if (parent.getFirstChild() == this) {
/*  85 */           if (resolveAsNakedComponentPropertyRefLHS(dot))
/*     */           {
/*  87 */             setResolved();
/*     */           }
/*     */           
/*     */         }
/*  91 */         else if (resolveAsNakedComponentPropertyRefRHS(dot))
/*     */         {
/*  93 */           setResolved();
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*  98 */         int result = resolveAsNakedPropertyRef();
/*  99 */         if (result == 1)
/*     */         {
/* 101 */           setResolved();
/*     */         }
/* 103 */         else if (result == 2)
/*     */         {
/*     */ 
/* 106 */           return;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 115 */       if (!isResolved()) {
/*     */         try {
/* 117 */           getWalker().getLiteralProcessor().processConstant(this, false);
/*     */         }
/*     */         catch (Throwable ignore) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean resolveAsAlias()
/*     */   {
/* 128 */     FromElement element = getWalker().getCurrentFromClause().getFromElement(getText());
/* 129 */     if (element != null) {
/* 130 */       setFromElement(element);
/* 131 */       setText(element.getIdentityColumn());
/* 132 */       setType(133);
/* 133 */       return true;
/*     */     }
/* 135 */     return false;
/*     */   }
/*     */   
/*     */   private Type getNakedPropertyType(FromElement fromElement)
/*     */   {
/* 140 */     if (fromElement == null) {
/* 141 */       return null;
/*     */     }
/* 143 */     String property = getOriginalText();
/* 144 */     Type propertyType = null;
/*     */     try {
/* 146 */       propertyType = fromElement.getPropertyType(property, property);
/*     */     }
/*     */     catch (Throwable t) {}
/*     */     
/* 150 */     return propertyType;
/*     */   }
/*     */   
/*     */   private int resolveAsNakedPropertyRef() {
/* 154 */     FromElement fromElement = locateSingleFromElement();
/* 155 */     if (fromElement == null) {
/* 156 */       return 0;
/*     */     }
/* 158 */     Queryable persister = fromElement.getQueryable();
/* 159 */     if (persister == null) {
/* 160 */       return 0;
/*     */     }
/* 162 */     Type propertyType = getNakedPropertyType(fromElement);
/* 163 */     if (propertyType == null)
/*     */     {
/* 165 */       return 0;
/*     */     }
/*     */     
/* 168 */     if ((propertyType.isComponentType()) || (propertyType.isAssociationType())) {
/* 169 */       return 2;
/*     */     }
/*     */     
/* 172 */     setFromElement(fromElement);
/* 173 */     String property = getText();
/* 174 */     String[] columns = getWalker().isSelectStatement() ? persister.toColumns(fromElement.getTableAlias(), property) : persister.toColumns(property);
/*     */     
/*     */ 
/* 177 */     String text = StringHelper.join(", ", columns);
/* 178 */     setText("(" + text + ")");
/* 179 */     setType(135);
/*     */     
/*     */ 
/* 182 */     super.setDataType(propertyType);
/* 183 */     this.nakedPropertyRef = true;
/*     */     
/* 185 */     return 1;
/*     */   }
/*     */   
/*     */   private boolean resolveAsNakedComponentPropertyRefLHS(DotNode parent) {
/* 189 */     FromElement fromElement = locateSingleFromElement();
/* 190 */     if (fromElement == null) {
/* 191 */       return false;
/*     */     }
/*     */     
/* 194 */     Type componentType = getNakedPropertyType(fromElement);
/* 195 */     if (!componentType.isComponentType()) {
/* 196 */       throw new QueryException("Property '" + getOriginalText() + "' is not a component.  Use an alias to reference associations or collections.");
/*     */     }
/*     */     
/* 199 */     Type propertyType = null;
/* 200 */     String propertyPath = getText() + "." + getNextSibling().getText();
/*     */     
/*     */     try
/*     */     {
/* 204 */       propertyType = fromElement.getPropertyType(getText(), propertyPath);
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 208 */       return false;
/*     */     }
/*     */     
/* 211 */     setFromElement(fromElement);
/* 212 */     parent.setPropertyPath(propertyPath);
/* 213 */     parent.setDataType(propertyType);
/*     */     
/* 215 */     return true;
/*     */   }
/*     */   
/*     */   private boolean resolveAsNakedComponentPropertyRefRHS(DotNode parent) {
/* 219 */     FromElement fromElement = locateSingleFromElement();
/* 220 */     if (fromElement == null) {
/* 221 */       return false;
/*     */     }
/*     */     
/* 224 */     Type propertyType = null;
/* 225 */     String propertyPath = parent.getLhs().getText() + "." + getText();
/*     */     
/*     */     try
/*     */     {
/* 229 */       propertyType = fromElement.getPropertyType(getText(), propertyPath);
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 233 */       return false;
/*     */     }
/*     */     
/* 236 */     setFromElement(fromElement);
/*     */     
/* 238 */     super.setDataType(propertyType);
/* 239 */     this.nakedPropertyRef = true;
/*     */     
/* 241 */     return true;
/*     */   }
/*     */   
/*     */   private FromElement locateSingleFromElement() {
/* 245 */     List fromElements = getWalker().getCurrentFromClause().getFromElements();
/* 246 */     if ((fromElements == null) || (fromElements.size() != 1))
/*     */     {
/* 248 */       return null;
/*     */     }
/* 250 */     FromElement element = (FromElement)fromElements.get(0);
/* 251 */     if (element.getClassAlias() != null)
/*     */     {
/* 253 */       return null;
/*     */     }
/* 255 */     return element;
/*     */   }
/*     */   
/*     */   public Type getDataType() {
/* 259 */     Type type = super.getDataType();
/* 260 */     if (type != null) return type;
/* 261 */     FromElement fe = getFromElement();
/* 262 */     if (fe != null) return fe.getDataType();
/* 263 */     SQLFunction sf = getWalker().getSessionFactoryHelper().findSQLFunction(getText());
/* 264 */     return sf == null ? null : sf.getReturnType(null, null);
/*     */   }
/*     */   
/*     */   public void setScalarColumnText(int i) throws SemanticException {
/* 268 */     if (this.nakedPropertyRef)
/*     */     {
/*     */ 
/* 271 */       ColumnHelper.generateSingleScalarColumn(this, i);
/*     */     }
/*     */     else {
/* 274 */       FromElement fe = getFromElement();
/* 275 */       if (fe != null) {
/* 276 */         setText(fe.renderScalarIdentifierSelect(i));
/*     */       }
/*     */       else {
/* 279 */         ColumnHelper.generateSingleScalarColumn(this, i);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String getDisplayText() {
/* 285 */     StringBuffer buf = new StringBuffer();
/*     */     
/* 287 */     if (getType() == 133) {
/* 288 */       buf.append("{alias=").append(getOriginalText());
/* 289 */       if (getFromElement() == null) {
/* 290 */         buf.append(", no from element");
/*     */       }
/*     */       else {
/* 293 */         buf.append(", className=").append(getFromElement().getClassName());
/* 294 */         buf.append(", tableAlias=").append(getFromElement().getTableAlias());
/*     */       }
/* 296 */       buf.append("}");
/*     */     }
/*     */     else {
/* 299 */       buf.append("{originalText=" + getOriginalText()).append("}");
/*     */     }
/* 301 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\IdentNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */