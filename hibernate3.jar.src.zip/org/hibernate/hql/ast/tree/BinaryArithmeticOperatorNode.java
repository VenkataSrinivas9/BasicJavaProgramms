/*     */ package org.hibernate.hql.ast.tree;
/*     */ 
/*     */ import antlr.SemanticException;
/*     */ import antlr.collections.AST;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.hql.ast.util.ColumnHelper;
/*     */ import org.hibernate.param.ParameterSpecification;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ public class BinaryArithmeticOperatorNode
/*     */   extends AbstractSelectExpression
/*     */   implements BinaryOperatorNode, DisplayableNode
/*     */ {
/*     */   public void initialize()
/*     */     throws SemanticException
/*     */   {
/*  19 */     Node lhs = getLeftHandOperand();
/*  20 */     Node rhs = getRightHandOperand();
/*  21 */     if (lhs == null) {
/*  22 */       throw new SemanticException("left-hand operand of a binary operator was null");
/*     */     }
/*  24 */     if (rhs == null) {
/*  25 */       throw new SemanticException("right-hand operand of a binary operator was null");
/*     */     }
/*     */     
/*  28 */     Type lhType = (lhs instanceof SqlNode) ? ((SqlNode)lhs).getDataType() : null;
/*  29 */     Type rhType = (rhs instanceof SqlNode) ? ((SqlNode)rhs).getDataType() : null;
/*     */     
/*  31 */     if ((ParameterNode.class.isAssignableFrom(lhs.getClass())) && (rhType != null)) {
/*  32 */       Type expectedType = null;
/*     */       
/*  34 */       if (isDateTimeType(rhType))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  40 */         expectedType = getType() == 109 ? Hibernate.DOUBLE : rhType;
/*     */       }
/*     */       else {
/*  43 */         expectedType = rhType;
/*     */       }
/*  45 */       ((ParameterNode)lhs).getHqlParameterSpecification().setExpectedType(expectedType);
/*     */     }
/*  47 */     else if ((ParameterNode.class.isAssignableFrom(rhs.getClass())) && (lhType != null)) {
/*  48 */       Type expectedType = null;
/*     */       
/*  50 */       if (isDateTimeType(lhType))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  57 */         if (getType() == 109) {
/*  58 */           expectedType = Hibernate.DOUBLE;
/*     */         }
/*     */       }
/*     */       else {
/*  62 */         expectedType = lhType;
/*     */       }
/*  64 */       ((ParameterNode)rhs).getHqlParameterSpecification().setExpectedType(expectedType);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Type getDataType()
/*     */   {
/*  74 */     if (super.getDataType() == null) {
/*  75 */       super.setDataType(resolveDataType());
/*     */     }
/*  77 */     return super.getDataType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Type resolveDataType()
/*     */   {
/*  84 */     Node lhs = getLeftHandOperand();
/*  85 */     Node rhs = getRightHandOperand();
/*  86 */     Type lhType = (lhs instanceof SqlNode) ? ((SqlNode)lhs).getDataType() : null;
/*  87 */     Type rhType = (rhs instanceof SqlNode) ? ((SqlNode)rhs).getDataType() : null;
/*  88 */     if ((isDateTimeType(lhType)) || (isDateTimeType(rhType))) {
/*  89 */       return resolveDateTimeArithmeticResultType(lhType, rhType);
/*     */     }
/*     */     
/*  92 */     if (lhType == null) {
/*  93 */       if (rhType == null)
/*     */       {
/*  95 */         return Hibernate.DOUBLE;
/*     */       }
/*     */       
/*     */ 
/*  99 */       return rhType;
/*     */     }
/*     */     
/*     */ 
/* 103 */     if (rhType == null)
/*     */     {
/* 105 */       return lhType;
/*     */     }
/*     */     
/* 108 */     if ((lhType == Hibernate.DOUBLE) || (rhType == Hibernate.DOUBLE)) return Hibernate.DOUBLE;
/* 109 */     if ((lhType == Hibernate.FLOAT) || (rhType == Hibernate.FLOAT)) return Hibernate.FLOAT;
/* 110 */     if ((lhType == Hibernate.BIG_DECIMAL) || (rhType == Hibernate.BIG_DECIMAL)) return Hibernate.BIG_DECIMAL;
/* 111 */     if ((lhType == Hibernate.BIG_INTEGER) || (rhType == Hibernate.BIG_INTEGER)) return Hibernate.BIG_INTEGER;
/* 112 */     if ((lhType == Hibernate.LONG) || (rhType == Hibernate.LONG)) return Hibernate.LONG;
/* 113 */     if ((lhType == Hibernate.INTEGER) || (rhType == Hibernate.INTEGER)) return Hibernate.INTEGER;
/* 114 */     return lhType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean isDateTimeType(Type type)
/*     */   {
/* 121 */     if (type == null) {
/* 122 */       return false;
/*     */     }
/* 124 */     return (Date.class.isAssignableFrom(type.getReturnedClass())) || (Calendar.class.isAssignableFrom(type.getReturnedClass()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Type resolveDateTimeArithmeticResultType(Type lhType, Type rhType)
/*     */   {
/* 144 */     boolean lhsIsDateTime = isDateTimeType(lhType);
/* 145 */     boolean rhsIsDateTime = isDateTimeType(rhType);
/*     */     
/*     */ 
/*     */ 
/* 149 */     if (getType() == 109)
/*     */     {
/* 151 */       return lhsIsDateTime ? lhType : rhType;
/*     */     }
/* 153 */     if (getType() == 110)
/*     */     {
/* 155 */       if ((lhsIsDateTime) && (!rhsIsDateTime)) {
/* 156 */         return lhType;
/*     */       }
/*     */       
/* 159 */       if ((lhsIsDateTime) && (rhsIsDateTime)) {
/* 160 */         return Hibernate.DOUBLE;
/*     */       }
/*     */     }
/* 163 */     return null;
/*     */   }
/*     */   
/*     */   public void setScalarColumnText(int i) throws SemanticException {
/* 167 */     ColumnHelper.generateSingleScalarColumn(this, i);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getLeftHandOperand()
/*     */   {
/* 176 */     return (Node)getFirstChild();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getRightHandOperand()
/*     */   {
/* 185 */     return (Node)getFirstChild().getNextSibling();
/*     */   }
/*     */   
/*     */   public String getDisplayText() {
/* 189 */     return "{dataType=" + getDataType() + "}";
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\BinaryArithmeticOperatorNode.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */