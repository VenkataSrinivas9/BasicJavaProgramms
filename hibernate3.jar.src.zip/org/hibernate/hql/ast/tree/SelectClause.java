/*     */ package org.hibernate.hql.ast.tree;
/*     */ 
/*     */ import antlr.SemanticException;
/*     */ import antlr.collections.AST;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.hql.antlr.SqlTokenTypes;
/*     */ import org.hibernate.hql.ast.HqlSqlWalker;
/*     */ import org.hibernate.hql.ast.util.ASTAppender;
/*     */ import org.hibernate.hql.ast.util.ASTIterator;
/*     */ import org.hibernate.hql.ast.util.ASTPrinter;
/*     */ import org.hibernate.hql.ast.util.SessionFactoryHelper;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelectClause
/*     */   extends SelectExpressionList
/*     */ {
/*  26 */   private boolean prepared = false;
/*     */   
/*     */   private boolean scalarSelect;
/*  29 */   private List fromElementsForLoad = new ArrayList();
/*     */   
/*     */   private Type[] queryReturnTypes;
/*     */   
/*     */   private String[][] columnNames;
/*     */   
/*     */   private ConstructorNode constructorNode;
/*     */   
/*     */   private List collectionFromElements;
/*     */   
/*     */   private String[] aliases;
/*     */   
/*     */   public boolean isScalarSelect()
/*     */   {
/*  43 */     return this.scalarSelect;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List getFromElementsForLoad()
/*     */   {
/*  52 */     return this.fromElementsForLoad;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Type[] getQueryReturnTypes()
/*     */   {
/*  70 */     return this.queryReturnTypes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] getQueryReturnAliases()
/*     */   {
/*  77 */     return this.aliases;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[][] getColumnNames()
/*     */   {
/*  86 */     return this.columnNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Constructor getConstructor()
/*     */   {
/*  96 */     return this.constructorNode == null ? null : this.constructorNode.getConstructor();
/*     */   }
/*     */   
/*     */   public boolean isMap() {
/* 100 */     return this.constructorNode == null ? false : this.constructorNode.isMap();
/*     */   }
/*     */   
/*     */   public boolean isList() {
/* 104 */     return this.constructorNode == null ? false : this.constructorNode.isList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initializeExplicitSelectClause(FromClause fromClause)
/*     */     throws SemanticException
/*     */   {
/* 114 */     if (this.prepared) {
/* 115 */       throw new IllegalStateException("SelectClause was already prepared!");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 120 */     ArrayList queryReturnTypeList = new ArrayList();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 125 */     SelectExpression[] selectExpressions = collectSelectExpressions();
/*     */     
/* 127 */     for (int i = 0; i < selectExpressions.length; i++) {
/* 128 */       SelectExpression expr = selectExpressions[i];
/*     */       
/* 130 */       if (expr.isConstructor()) {
/* 131 */         this.constructorNode = ((ConstructorNode)expr);
/* 132 */         List constructorArgumentTypeList = this.constructorNode.getConstructorArgumentTypeList();
/*     */         
/* 134 */         queryReturnTypeList.addAll(constructorArgumentTypeList);
/* 135 */         this.scalarSelect = true;
/*     */       }
/*     */       else {
/* 138 */         Type type = expr.getDataType();
/* 139 */         if (type == null) {
/* 140 */           throw new IllegalStateException("No data type for node: " + expr.getClass().getName() + " " + new ASTPrinter(SqlTokenTypes.class).showAsString((AST)expr, ""));
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 146 */         if (expr.isScalar()) {
/* 147 */           this.scalarSelect = true;
/*     */         }
/*     */         
/* 150 */         if (isReturnableEntity(expr)) {
/* 151 */           this.fromElementsForLoad.add(expr.getFromElement());
/*     */         }
/*     */         
/*     */ 
/* 155 */         queryReturnTypeList.add(type);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 160 */     initAliases(selectExpressions);
/*     */     
/* 162 */     if (!getWalker().isShallowQuery())
/*     */     {
/* 164 */       List fromElements = fromClause.getProjectionList();
/*     */       
/* 166 */       ASTAppender appender = new ASTAppender(getASTFactory(), this);
/* 167 */       int size = fromElements.size();
/*     */       
/* 169 */       Iterator iterator = fromElements.iterator();
/* 170 */       for (int k = 0; iterator.hasNext(); k++) {
/* 171 */         FromElement fromElement = (FromElement)iterator.next();
/*     */         
/* 173 */         if (fromElement.isFetch()) {
/* 174 */           FromElement origin = null;
/* 175 */           if (fromElement.getRealOrigin() == null)
/*     */           {
/*     */ 
/*     */ 
/* 179 */             if (fromElement.getOrigin() == null) {
/* 180 */               throw new QueryException("Unable to determine origin of join fetch [" + fromElement.getDisplayText() + "]");
/*     */             }
/*     */             
/* 183 */             origin = fromElement.getOrigin();
/*     */           }
/*     */           else
/*     */           {
/* 187 */             origin = fromElement.getRealOrigin();
/*     */           }
/* 189 */           if (!this.fromElementsForLoad.contains(origin)) {
/* 190 */             throw new QueryException("query specified join fetching, but the owner of the fetched association was not present in the select list [" + fromElement.getDisplayText() + "]");
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 196 */           Type type = fromElement.getSelectType();
/* 197 */           addCollectionFromElement(fromElement);
/* 198 */           if (type != null) {
/* 199 */             boolean collectionOfElements = fromElement.isCollectionOfValuesOrComponents();
/* 200 */             if (!collectionOfElements)
/*     */             {
/* 202 */               fromElement.setIncludeSubclasses(true);
/* 203 */               this.fromElementsForLoad.add(fromElement);
/*     */               
/*     */ 
/* 206 */               String text = fromElement.renderIdentifierSelect(size, k);
/* 207 */               SelectExpressionImpl generatedExpr = (SelectExpressionImpl)appender.append(137, text, false);
/* 208 */               if (generatedExpr != null) {
/* 209 */                 generatedExpr.setFromElement(fromElement);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 218 */       renderNonScalarSelects(collectSelectExpressions(), fromClause);
/*     */     }
/*     */     
/* 221 */     if ((this.scalarSelect) || (getWalker().isShallowQuery()))
/*     */     {
/* 223 */       renderScalarSelects(selectExpressions, fromClause);
/*     */     }
/*     */     
/* 226 */     finishInitialization(queryReturnTypeList);
/*     */   }
/*     */   
/*     */   private void finishInitialization(ArrayList queryReturnTypeList)
/*     */   {
/* 231 */     this.queryReturnTypes = ((Type[])queryReturnTypeList.toArray(new Type[queryReturnTypeList.size()]));
/* 232 */     initializeColumnNames();
/* 233 */     this.prepared = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initializeColumnNames()
/*     */   {
/* 242 */     this.columnNames = getSessionFactoryHelper().generateColumnNames(this.queryReturnTypes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initializeDerivedSelectClause(FromClause fromClause)
/*     */     throws SemanticException
/*     */   {
/* 251 */     if (this.prepared) {
/* 252 */       throw new IllegalStateException("SelectClause was already prepared!");
/*     */     }
/* 254 */     List fromElements = fromClause.getProjectionList();
/*     */     
/* 256 */     ASTAppender appender = new ASTAppender(getASTFactory(), this);
/* 257 */     int size = fromElements.size();
/* 258 */     ArrayList sqlResultTypeList = new ArrayList(size);
/* 259 */     ArrayList queryReturnTypeList = new ArrayList(size);
/*     */     
/* 261 */     Iterator iterator = fromElements.iterator();
/* 262 */     for (int k = 0; iterator.hasNext(); k++) {
/* 263 */       FromElement fromElement = (FromElement)iterator.next();
/* 264 */       Type type = fromElement.getSelectType();
/*     */       
/* 266 */       addCollectionFromElement(fromElement);
/*     */       
/* 268 */       if (type != null) {
/* 269 */         boolean collectionOfElements = fromElement.isCollectionOfValuesOrComponents();
/* 270 */         if (!collectionOfElements) {
/* 271 */           if (!fromElement.isFetch())
/*     */           {
/* 273 */             queryReturnTypeList.add(type);
/*     */           }
/* 275 */           this.fromElementsForLoad.add(fromElement);
/* 276 */           sqlResultTypeList.add(type);
/*     */           
/* 278 */           String text = fromElement.renderIdentifierSelect(size, k);
/* 279 */           SelectExpressionImpl generatedExpr = (SelectExpressionImpl)appender.append(137, text, false);
/* 280 */           if (generatedExpr != null) {
/* 281 */             generatedExpr.setFromElement(fromElement);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 288 */     SelectExpression[] selectExpressions = collectSelectExpressions();
/*     */     
/* 290 */     if (getWalker().isShallowQuery()) {
/* 291 */       renderScalarSelects(selectExpressions, fromClause);
/*     */     }
/*     */     else {
/* 294 */       renderNonScalarSelects(selectExpressions, fromClause);
/*     */     }
/* 296 */     finishInitialization(queryReturnTypeList);
/*     */   }
/*     */   
/* 299 */   public static boolean VERSION2_SQL = false;
/*     */   
/*     */   private void addCollectionFromElement(FromElement fromElement) {
/* 302 */     if ((fromElement.isFetch()) && (
/* 303 */       (fromElement.isCollectionJoin()) || (fromElement.getQueryableCollection() != null))) { String suffix;
/*     */       String suffix;
/* 305 */       if (this.collectionFromElements == null) {
/* 306 */         this.collectionFromElements = new ArrayList();
/* 307 */         suffix = VERSION2_SQL ? "__" : "0__";
/*     */       }
/*     */       else {
/* 310 */         suffix = Integer.toString(this.collectionFromElements.size()) + "__";
/*     */       }
/* 312 */       this.collectionFromElements.add(fromElement);
/* 313 */       fromElement.setCollectionSuffix(suffix);
/*     */     }
/*     */   }
/*     */   
/*     */   protected AST getFirstSelectExpression()
/*     */   {
/* 319 */     AST n = getFirstChild();
/*     */     
/* 321 */     while ((n != null) && ((n.getType() == 16) || (n.getType() == 4))) {
/* 322 */       n = n.getNextSibling();
/*     */     }
/* 324 */     return n;
/*     */   }
/*     */   
/*     */   private boolean isReturnableEntity(SelectExpression selectExpression) throws SemanticException {
/* 328 */     FromElement fromElement = selectExpression.getFromElement();
/* 329 */     boolean isFetchOrValueCollection = (fromElement != null) && ((fromElement.isFetch()) || (fromElement.isCollectionOfValuesOrComponents()));
/*     */     
/* 331 */     if (isFetchOrValueCollection) {
/* 332 */       return false;
/*     */     }
/*     */     
/* 335 */     return selectExpression.isReturnableEntity();
/*     */   }
/*     */   
/*     */   private void renderScalarSelects(SelectExpression[] se, FromClause currentFromClause) throws SemanticException
/*     */   {
/* 340 */     if (!currentFromClause.isSubQuery()) {
/* 341 */       for (int i = 0; i < se.length; i++) {
/* 342 */         SelectExpression expr = se[i];
/* 343 */         expr.setScalarColumnText(i);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void initAliases(SelectExpression[] selectExpressions) {
/* 349 */     if (this.constructorNode == null) {
/* 350 */       this.aliases = new String[selectExpressions.length];
/* 351 */       for (int i = 0; i < selectExpressions.length; i++) {
/* 352 */         String alias = selectExpressions[i].getAlias();
/* 353 */         this.aliases[i] = (alias == null ? Integer.toString(i) : alias);
/*     */       }
/*     */     }
/*     */     else {
/* 357 */       this.aliases = this.constructorNode.getAliases();
/*     */     }
/*     */   }
/*     */   
/*     */   private void renderNonScalarSelects(SelectExpression[] selectExpressions, FromClause currentFromClause) throws SemanticException
/*     */   {
/* 363 */     ASTAppender appender = new ASTAppender(getASTFactory(), this);
/* 364 */     int size = selectExpressions.length;
/* 365 */     int nonscalarSize = 0;
/* 366 */     for (int i = 0; i < size; i++) {
/* 367 */       if (!selectExpressions[i].isScalar()) { nonscalarSize++;
/*     */       }
/*     */     }
/* 370 */     int j = 0;
/* 371 */     for (int i = 0; i < size; i++) {
/* 372 */       if (!selectExpressions[i].isScalar()) {
/* 373 */         SelectExpression expr = selectExpressions[i];
/* 374 */         FromElement fromElement = expr.getFromElement();
/* 375 */         if (fromElement != null) {
/* 376 */           renderNonScalarIdentifiers(fromElement, nonscalarSize, j, expr, appender);
/* 377 */           j++;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 382 */     if (!currentFromClause.isSubQuery())
/*     */     {
/* 384 */       int k = 0;
/* 385 */       for (int i = 0; i < size; i++) {
/* 386 */         if (!selectExpressions[i].isScalar()) {
/* 387 */           FromElement fromElement = selectExpressions[i].getFromElement();
/* 388 */           if (fromElement != null) {
/* 389 */             renderNonScalarProperties(appender, fromElement, nonscalarSize, k);
/* 390 */             k++;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void renderNonScalarIdentifiers(FromElement fromElement, int nonscalarSize, int j, SelectExpression expr, ASTAppender appender) {
/* 398 */     String text = fromElement.renderIdentifierSelect(nonscalarSize, j);
/* 399 */     if (!fromElement.getFromClause().isSubQuery()) {
/* 400 */       if ((!this.scalarSelect) && (!getWalker().isShallowQuery()))
/*     */       {
/* 402 */         expr.setText(text);
/*     */       }
/*     */       else {
/* 405 */         appender.append(135, text, false);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void renderNonScalarProperties(ASTAppender appender, FromElement fromElement, int nonscalarSize, int k) {
/* 411 */     String text = fromElement.renderPropertySelect(nonscalarSize, k);
/* 412 */     appender.append(135, text, false);
/* 413 */     if ((fromElement.getQueryableCollection() != null) && (fromElement.isFetch())) {
/* 414 */       text = fromElement.renderCollectionSelectFragment(nonscalarSize, k);
/* 415 */       appender.append(135, text, false);
/*     */     }
/*     */     
/* 418 */     ASTIterator iter = new ASTIterator(fromElement);
/* 419 */     while (iter.hasNext()) {
/* 420 */       FromElement child = (FromElement)iter.next();
/* 421 */       if ((child.isCollectionOfValuesOrComponents()) && (child.isFetch()))
/*     */       {
/* 423 */         text = child.renderValueCollectionSelectFragment(nonscalarSize, nonscalarSize + k);
/* 424 */         appender.append(135, text, false);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public List getCollectionFromElements() {
/* 430 */     return this.collectionFromElements;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\SelectClause.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */