/*     */ package org.hibernate.hql.ast.tree;
/*     */ 
/*     */ import antlr.ASTFactory;
/*     */ import antlr.SemanticException;
/*     */ import antlr.collections.AST;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.engine.JoinSequence;
/*     */ import org.hibernate.hql.antlr.SqlTokenTypes;
/*     */ import org.hibernate.hql.ast.HqlSqlWalker;
/*     */ import org.hibernate.hql.ast.util.ASTUtil;
/*     */ import org.hibernate.hql.ast.util.AliasGenerator;
/*     */ import org.hibernate.hql.ast.util.PathHelper;
/*     */ import org.hibernate.hql.ast.util.SessionFactoryHelper;
/*     */ import org.hibernate.persister.collection.QueryableCollection;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.persister.entity.Joinable;
/*     */ import org.hibernate.persister.entity.Queryable;
/*     */ import org.hibernate.type.AssociationType;
/*     */ import org.hibernate.type.CollectionType;
/*     */ import org.hibernate.type.EntityType;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FromElementFactory
/*     */   implements SqlTokenTypes
/*     */ {
/*  34 */   private static final Log log = LogFactory.getLog(FromElementFactory.class);
/*     */   
/*     */   private FromClause fromClause;
/*     */   
/*     */   private FromElement origin;
/*     */   
/*     */   private String path;
/*     */   
/*     */   private String classAlias;
/*     */   private String[] columns;
/*     */   private boolean implied;
/*     */   private boolean inElementsFunction;
/*     */   private boolean collection;
/*     */   private QueryableCollection queryableCollection;
/*     */   private CollectionType collectionType;
/*     */   
/*     */   public FromElementFactory(FromClause fromClause, FromElement origin, String path)
/*     */   {
/*  52 */     this.fromClause = fromClause;
/*  53 */     this.origin = origin;
/*  54 */     this.path = path;
/*  55 */     this.collection = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FromElementFactory(FromClause fromClause, FromElement origin, String path, String classAlias, String[] columns, boolean implied)
/*     */   {
/*  68 */     this(fromClause, origin, path);
/*  69 */     this.classAlias = classAlias;
/*  70 */     this.columns = columns;
/*  71 */     this.implied = implied;
/*  72 */     this.collection = true;
/*     */   }
/*     */   
/*     */   FromElement addFromElement() throws SemanticException {
/*  76 */     FromClause parentFromClause = this.fromClause.getParentFromClause();
/*  77 */     if (parentFromClause != null)
/*     */     {
/*  79 */       String pathAlias = PathHelper.getAlias(this.path);
/*  80 */       FromElement parentFromElement = parentFromClause.getFromElement(pathAlias);
/*  81 */       if (parentFromElement != null) {
/*  82 */         return createFromElementInSubselect(this.path, pathAlias, parentFromElement, this.classAlias);
/*     */       }
/*     */     }
/*     */     
/*  86 */     EntityPersister entityPersister = this.fromClause.getSessionFactoryHelper().requireClassPersister(this.path);
/*     */     
/*  88 */     FromElement elem = createAndAddFromElement(this.path, this.classAlias, entityPersister, (EntityType)((Queryable)entityPersister).getType(), null);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  95 */     this.fromClause.getWalker().addQuerySpaces(entityPersister.getQuerySpaces());
/*     */     
/*  97 */     return elem;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private FromElement createFromElementInSubselect(String path, String pathAlias, FromElement parentFromElement, String classAlias)
/*     */     throws SemanticException
/*     */   {
/* 105 */     if (log.isDebugEnabled()) {
/* 106 */       log.debug("createFromElementInSubselect() : path = " + path);
/*     */     }
/*     */     
/* 109 */     FromElement fromElement = evaluateFromElementPath(path, classAlias);
/* 110 */     EntityPersister entityPersister = fromElement.getEntityPersister();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 115 */     String tableAlias = null;
/* 116 */     boolean correlatedSubselect = pathAlias.equals(parentFromElement.getClassAlias());
/* 117 */     if (correlatedSubselect) {
/* 118 */       tableAlias = fromElement.getTableAlias();
/*     */     }
/*     */     else {
/* 121 */       tableAlias = null;
/*     */     }
/*     */     
/*     */ 
/* 125 */     if (fromElement.getFromClause() != this.fromClause) {
/* 126 */       if (log.isDebugEnabled()) {
/* 127 */         log.debug("createFromElementInSubselect() : creating a new FROM element...");
/*     */       }
/* 129 */       fromElement = createFromElement(entityPersister);
/* 130 */       initializeAndAddFromElement(fromElement, path, classAlias, entityPersister, (EntityType)((Queryable)entityPersister).getType(), tableAlias);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 138 */     if (log.isDebugEnabled()) {
/* 139 */       log.debug("createFromElementInSubselect() : " + path + " -> " + fromElement);
/*     */     }
/* 141 */     return fromElement;
/*     */   }
/*     */   
/*     */   private FromElement evaluateFromElementPath(String path, String classAlias) throws SemanticException {
/* 145 */     ASTFactory factory = this.fromClause.getASTFactory();
/* 146 */     FromReferenceNode pathNode = (FromReferenceNode)PathHelper.parsePath(path, factory);
/* 147 */     pathNode.recursiveResolve(0, false, classAlias, null);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 152 */     if (pathNode.getImpliedJoin() != null) {
/* 153 */       return pathNode.getImpliedJoin();
/*     */     }
/*     */     
/* 156 */     return pathNode.getFromElement();
/*     */   }
/*     */   
/*     */ 
/*     */   FromElement createCollectionElementsJoin(QueryableCollection queryableCollection, String collectionName)
/*     */     throws SemanticException
/*     */   {
/* 163 */     JoinSequence collectionJoinSequence = this.fromClause.getSessionFactoryHelper().createCollectionJoinSequence(queryableCollection, collectionName);
/*     */     
/* 165 */     this.queryableCollection = queryableCollection;
/* 166 */     return createCollectionJoin(collectionJoinSequence, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   FromElement createCollection(QueryableCollection queryableCollection, String role, int joinType, boolean fetchFlag, boolean indexed)
/*     */     throws SemanticException
/*     */   {
/* 176 */     if (!this.collection) {
/* 177 */       throw new IllegalStateException("FromElementFactory not initialized for collections!");
/*     */     }
/* 179 */     this.inElementsFunction = indexed;
/*     */     
/* 181 */     this.queryableCollection = queryableCollection;
/* 182 */     this.collectionType = queryableCollection.getCollectionType();
/* 183 */     String roleAlias = this.fromClause.getAliasGenerator().createName(role);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 188 */     boolean explicitSubqueryFromElement = (this.fromClause.isSubQuery()) && (!this.implied);
/* 189 */     if (explicitSubqueryFromElement) {
/* 190 */       this.implied = true;
/*     */     }
/*     */     
/* 193 */     Type elementType = queryableCollection.getElementType();
/* 194 */     FromElement elem; FromElement elem; if (elementType.isEntityType()) {
/* 195 */       elem = createEntityAssociation(role, roleAlias, joinType);
/*     */     } else { FromElement elem;
/* 197 */       if (elementType.isComponentType()) {
/* 198 */         JoinSequence joinSequence = createJoinSequence(roleAlias, joinType);
/* 199 */         elem = createCollectionJoin(joinSequence, roleAlias);
/*     */       }
/*     */       else {
/* 202 */         JoinSequence joinSequence = createJoinSequence(roleAlias, joinType);
/* 203 */         elem = createCollectionJoin(joinSequence, roleAlias);
/*     */       }
/*     */     }
/* 206 */     elem.setRole(role);
/* 207 */     elem.setQueryableCollection(queryableCollection);
/*     */     
/* 209 */     if (this.implied) {
/* 210 */       elem.setIncludeSubclasses(false);
/*     */     }
/*     */     
/* 213 */     if (explicitSubqueryFromElement) {
/* 214 */       elem.setInProjectionList(true);
/*     */     }
/*     */     
/* 217 */     if (fetchFlag) {
/* 218 */       elem.setFetch(true);
/*     */     }
/* 220 */     return elem;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   FromElement createEntityJoin(String entityClass, String tableAlias, JoinSequence joinSequence, boolean fetchFlag, boolean inFrom, EntityType type)
/*     */     throws SemanticException
/*     */   {
/* 230 */     FromElement elem = createJoin(entityClass, tableAlias, joinSequence, type, false);
/* 231 */     elem.setFetch(fetchFlag);
/* 232 */     EntityPersister entityPersister = elem.getEntityPersister();
/* 233 */     int numberOfTables = entityPersister.getQuerySpaces().length;
/* 234 */     if ((numberOfTables > 1) && (this.implied) && (!elem.useFromFragment())) {
/* 235 */       if (log.isDebugEnabled()) {
/* 236 */         log.debug("createEntityJoin() : Implied multi-table entity join");
/*     */       }
/* 238 */       elem.setUseFromFragment(true);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 243 */     if ((this.implied) && (inFrom)) {
/* 244 */       joinSequence.setUseThetaStyle(false);
/* 245 */       elem.setUseFromFragment(true);
/* 246 */       elem.setImpliedInFromClause(true);
/*     */     }
/* 248 */     if (elem.getWalker().isSubQuery())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 253 */       if ((elem.getFromClause() != elem.getOrigin().getFromClause()) || (DotNode.useThetaStyleImplicitJoins))
/*     */       {
/*     */ 
/*     */ 
/* 257 */         elem.setType(127);
/* 258 */         joinSequence.setUseThetaStyle(true);
/* 259 */         elem.setUseFromFragment(false);
/*     */       }
/*     */     }
/*     */     
/* 263 */     return elem;
/*     */   }
/*     */   
/*     */   FromElement createElementJoin(QueryableCollection queryableCollection)
/*     */     throws SemanticException
/*     */   {
/* 269 */     this.implied = true;
/* 270 */     this.inElementsFunction = true;
/* 271 */     Type elementType = queryableCollection.getElementType();
/* 272 */     if (!elementType.isEntityType()) {
/* 273 */       throw new IllegalArgumentException("Cannot create element join for a collection of non-entities!");
/*     */     }
/* 275 */     this.queryableCollection = queryableCollection;
/* 276 */     SessionFactoryHelper sfh = this.fromClause.getSessionFactoryHelper();
/* 277 */     FromElement destination = null;
/* 278 */     String tableAlias = null;
/* 279 */     EntityPersister entityPersister = queryableCollection.getElementPersister();
/* 280 */     tableAlias = this.fromClause.getAliasGenerator().createName(entityPersister.getEntityName());
/* 281 */     String associatedEntityName = entityPersister.getEntityName();
/* 282 */     EntityPersister targetEntityPersister = sfh.requireClassPersister(associatedEntityName);
/*     */     
/* 284 */     destination = createAndAddFromElement(associatedEntityName, this.classAlias, targetEntityPersister, (EntityType)queryableCollection.getElementType(), tableAlias);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 292 */     if (this.implied) {
/* 293 */       destination.setIncludeSubclasses(false);
/*     */     }
/* 295 */     this.fromClause.addCollectionJoinFromElementByPath(this.path, destination);
/*     */     
/*     */ 
/* 298 */     this.fromClause.getWalker().addQuerySpaces(entityPersister.getQuerySpaces());
/*     */     
/* 300 */     CollectionType type = queryableCollection.getCollectionType();
/* 301 */     String role = type.getRole();
/* 302 */     String roleAlias = this.origin.getTableAlias();
/*     */     
/* 304 */     String[] targetColumns = sfh.getCollectionElementColumns(role, roleAlias);
/* 305 */     AssociationType elementAssociationType = sfh.getElementAssociationType(type);
/*     */     
/*     */ 
/* 308 */     int joinType = 0;
/* 309 */     JoinSequence joinSequence = sfh.createJoinSequence(this.implied, elementAssociationType, tableAlias, joinType, targetColumns);
/* 310 */     FromElement elem = initializeJoin(this.path, destination, joinSequence, targetColumns, this.origin, false);
/* 311 */     elem.setUseFromFragment(true);
/* 312 */     elem.setCollectionTableAlias(roleAlias);
/* 313 */     return elem;
/*     */   }
/*     */   
/*     */   private FromElement createCollectionJoin(JoinSequence collectionJoinSequence, String tableAlias) throws SemanticException {
/* 317 */     String text = this.queryableCollection.getTableName();
/* 318 */     AST ast = createFromElement(text);
/* 319 */     FromElement destination = (FromElement)ast;
/* 320 */     Type elementType = this.queryableCollection.getElementType();
/* 321 */     if (elementType.isCollectionType()) {
/* 322 */       throw new SemanticException("Collections of collections are not supported!");
/*     */     }
/* 324 */     destination.initializeCollection(this.fromClause, this.classAlias, tableAlias);
/* 325 */     destination.setType(129);
/* 326 */     destination.setIncludeSubclasses(false);
/* 327 */     destination.setCollectionJoin(true);
/* 328 */     destination.setJoinSequence(collectionJoinSequence);
/* 329 */     destination.setOrigin(this.origin, false);
/* 330 */     destination.setCollectionTableAlias(tableAlias);
/*     */     
/*     */ 
/*     */ 
/* 334 */     this.origin.setText("");
/* 335 */     this.origin.setCollectionJoin(true);
/* 336 */     this.fromClause.addCollectionJoinFromElementByPath(this.path, destination);
/* 337 */     this.fromClause.getWalker().addQuerySpaces(this.queryableCollection.getCollectionSpaces());
/* 338 */     return destination;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private FromElement createEntityAssociation(String role, String roleAlias, int joinType)
/*     */     throws SemanticException
/*     */   {
/* 346 */     Queryable entityPersister = (Queryable)this.queryableCollection.getElementPersister();
/* 347 */     String associatedEntityName = entityPersister.getEntityName();
/*     */     FromElement elem;
/* 349 */     FromElement elem; if (this.queryableCollection.isOneToMany()) {
/* 350 */       if (log.isDebugEnabled()) {
/* 351 */         log.debug("createEntityAssociation() : One to many - path = " + this.path + " role = " + role + " associatedEntityName = " + associatedEntityName);
/*     */       }
/* 353 */       JoinSequence joinSequence = createJoinSequence(roleAlias, joinType);
/*     */       
/* 355 */       elem = createJoin(associatedEntityName, roleAlias, joinSequence, (EntityType)this.queryableCollection.getElementType(), false);
/*     */     }
/*     */     else {
/* 358 */       if (log.isDebugEnabled()) {
/* 359 */         log.debug("createManyToMany() : path = " + this.path + " role = " + role + " associatedEntityName = " + associatedEntityName);
/*     */       }
/* 361 */       elem = createManyToMany(role, associatedEntityName, roleAlias, entityPersister, (EntityType)this.queryableCollection.getElementType(), joinType);
/*     */       
/* 363 */       this.fromClause.getWalker().addQuerySpaces(this.queryableCollection.getCollectionSpaces());
/*     */     }
/* 365 */     elem.setCollectionTableAlias(roleAlias);
/* 366 */     return elem;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private FromElement createJoin(String entityClass, String tableAlias, JoinSequence joinSequence, EntityType type, boolean manyToMany)
/*     */     throws SemanticException
/*     */   {
/* 376 */     EntityPersister entityPersister = this.fromClause.getSessionFactoryHelper().requireClassPersister(entityClass);
/* 377 */     FromElement destination = createAndAddFromElement(entityClass, this.classAlias, entityPersister, type, tableAlias);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 382 */     return initializeJoin(this.path, destination, joinSequence, getColumns(), this.origin, manyToMany);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private FromElement createManyToMany(String role, String associatedEntityName, String roleAlias, Queryable entityPersister, EntityType type, int joinType)
/*     */     throws SemanticException
/*     */   {
/* 393 */     SessionFactoryHelper sfh = this.fromClause.getSessionFactoryHelper();
/* 394 */     FromElement elem; FromElement elem; if (this.inElementsFunction)
/*     */     {
/* 396 */       JoinSequence joinSequence = createJoinSequence(roleAlias, joinType);
/* 397 */       elem = createJoin(associatedEntityName, roleAlias, joinSequence, type, true);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 403 */       String tableAlias = this.fromClause.getAliasGenerator().createName(entityPersister.getEntityName());
/* 404 */       String[] secondJoinColumns = sfh.getCollectionElementColumns(role, roleAlias);
/*     */       
/* 406 */       JoinSequence joinSequence = createJoinSequence(roleAlias, joinType);
/* 407 */       joinSequence.addJoin(sfh.getElementAssociationType(this.collectionType), tableAlias, joinType, secondJoinColumns);
/* 408 */       elem = createJoin(associatedEntityName, tableAlias, joinSequence, type, false);
/* 409 */       elem.setUseFromFragment(true);
/*     */     }
/* 411 */     return elem;
/*     */   }
/*     */   
/*     */   private JoinSequence createJoinSequence(String roleAlias, int joinType) {
/* 415 */     SessionFactoryHelper sessionFactoryHelper = this.fromClause.getSessionFactoryHelper();
/* 416 */     String[] joinColumns = getColumns();
/* 417 */     if (this.collectionType == null) {
/* 418 */       throw new IllegalStateException("collectionType is null!");
/*     */     }
/* 420 */     return sessionFactoryHelper.createJoinSequence(this.implied, this.collectionType, roleAlias, joinType, joinColumns);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private FromElement createAndAddFromElement(String className, String classAlias, EntityPersister entityPersister, EntityType type, String tableAlias)
/*     */   {
/* 429 */     if (!(entityPersister instanceof Joinable)) {
/* 430 */       throw new IllegalArgumentException("EntityPersister " + entityPersister + " does not implement Joinable!");
/*     */     }
/* 432 */     FromElement element = createFromElement(entityPersister);
/* 433 */     initializeAndAddFromElement(element, className, classAlias, entityPersister, type, tableAlias);
/* 434 */     return element;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initializeAndAddFromElement(FromElement element, String className, String classAlias, EntityPersister entityPersister, EntityType type, String tableAlias)
/*     */   {
/* 444 */     if (tableAlias == null) {
/* 445 */       AliasGenerator aliasGenerator = this.fromClause.getAliasGenerator();
/* 446 */       tableAlias = aliasGenerator.createName(entityPersister.getEntityName());
/*     */     }
/* 448 */     element.initializeEntity(this.fromClause, className, entityPersister, type, classAlias, tableAlias);
/*     */   }
/*     */   
/*     */   private FromElement createFromElement(EntityPersister entityPersister) {
/* 452 */     Joinable joinable = (Joinable)entityPersister;
/* 453 */     String text = joinable.getTableName();
/* 454 */     AST ast = createFromElement(text);
/* 455 */     FromElement element = (FromElement)ast;
/* 456 */     return element;
/*     */   }
/*     */   
/*     */   private AST createFromElement(String text) {
/* 460 */     AST ast = ASTUtil.create(this.fromClause.getASTFactory(), this.implied ? 128 : 127, text);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 466 */     ast.setType(127);
/* 467 */     return ast;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private FromElement initializeJoin(String path, FromElement destination, JoinSequence joinSequence, String[] columns, FromElement origin, boolean manyToMany)
/*     */   {
/* 477 */     destination.setType(129);
/* 478 */     destination.setJoinSequence(joinSequence);
/* 479 */     destination.setColumns(columns);
/* 480 */     destination.setOrigin(origin, manyToMany);
/* 481 */     this.fromClause.addJoinByPathMap(path, destination);
/* 482 */     return destination;
/*     */   }
/*     */   
/*     */   private String[] getColumns() {
/* 486 */     if (this.columns == null) {
/* 487 */       throw new IllegalStateException("No foriegn key columns were supplied!");
/*     */     }
/* 489 */     return this.columns;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\tree\FromElementFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */