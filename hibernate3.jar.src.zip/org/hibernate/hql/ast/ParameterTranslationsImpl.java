/*     */ package org.hibernate.hql.ast;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.hibernate.hql.ParameterTranslations;
/*     */ import org.hibernate.param.NamedParameterSpecification;
/*     */ import org.hibernate.param.ParameterSpecification;
/*     */ import org.hibernate.param.PositionalParameterSpecification;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.ArrayHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterTranslationsImpl
/*     */   implements ParameterTranslations
/*     */ {
/*     */   private final Map namedParameters;
/*     */   private final ParameterInfo[] ordinalParameters;
/*     */   
/*     */   public boolean supportsOrdinalParameterMetadata()
/*     */   {
/*  30 */     return true;
/*     */   }
/*     */   
/*     */   public int getOrdinalParameterCount() {
/*  34 */     return this.ordinalParameters.length;
/*     */   }
/*     */   
/*     */   public ParameterInfo getOrdinalParameterInfo(int ordinalPosition)
/*     */   {
/*  39 */     return this.ordinalParameters[(ordinalPosition - 1)];
/*     */   }
/*     */   
/*     */   public int getOrdinalParameterSqlLocation(int ordinalPosition) {
/*  43 */     return getOrdinalParameterInfo(ordinalPosition).getSqlLocations()[0];
/*     */   }
/*     */   
/*     */   public Type getOrdinalParameterExpectedType(int ordinalPosition) {
/*  47 */     return getOrdinalParameterInfo(ordinalPosition).getExpectedType();
/*     */   }
/*     */   
/*     */   public Set getNamedParameterNames() {
/*  51 */     return this.namedParameters.keySet();
/*     */   }
/*     */   
/*     */   public ParameterInfo getNamedParameterInfo(String name) {
/*  55 */     return (ParameterInfo)this.namedParameters.get(name);
/*     */   }
/*     */   
/*     */   public int[] getNamedParameterSqlLocations(String name) {
/*  59 */     return getNamedParameterInfo(name).getSqlLocations();
/*     */   }
/*     */   
/*     */   public Type getNamedParameterExpectedType(String name) {
/*  63 */     return getNamedParameterInfo(name).getExpectedType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParameterTranslationsImpl(List parameterSpecifications)
/*     */   {
/*  83 */     int size = parameterSpecifications.size();
/*  84 */     List ordinalParameterList = new ArrayList();
/*  85 */     Map namedParameterMap = new HashMap();
/*  86 */     for (int i = 0; i < size; i++) {
/*  87 */       ParameterSpecification spec = (ParameterSpecification)parameterSpecifications.get(i);
/*  88 */       if (PositionalParameterSpecification.class.isAssignableFrom(spec.getClass())) {
/*  89 */         PositionalParameterSpecification ordinalSpec = (PositionalParameterSpecification)spec;
/*  90 */         ordinalParameterList.add(ordinalSpec.getHqlPosition(), new ParameterInfo(i, ordinalSpec.getExpectedType()));
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*  95 */       else if (NamedParameterSpecification.class.isAssignableFrom(spec.getClass())) {
/*  96 */         NamedParameterSpecification namedSpec = (NamedParameterSpecification)spec;
/*  97 */         Object paramHolder = (1NamedParamTempHolder)namedParameterMap.get(namedSpec.getName());
/*  98 */         if (paramHolder == null) {
/*  99 */           paramHolder = new Object()
/*     */           {
/*     */             String name;
/*     */             Type type;
/*  80 */             List positions = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */           };
/* 100 */           paramHolder.name = namedSpec.getName();
/* 101 */           paramHolder.type = namedSpec.getExpectedType();
/* 102 */           namedParameterMap.put(namedSpec.getName(), paramHolder);
/*     */         }
/* 104 */         paramHolder.positions.add(new Integer(i));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 111 */     this.ordinalParameters = ((ParameterInfo[])ordinalParameterList.toArray(new ParameterInfo[ordinalParameterList.size()]));
/*     */     
/* 113 */     if (namedParameterMap.isEmpty()) {
/* 114 */       this.namedParameters = Collections.EMPTY_MAP;
/*     */     }
/*     */     else {
/* 117 */       Map namedParametersBacking = new HashMap(namedParameterMap.size());
/* 118 */       Iterator itr = namedParameterMap.values().iterator();
/* 119 */       while (itr.hasNext()) {
/* 120 */         Object holder = (1NamedParamTempHolder)itr.next();
/* 121 */         namedParametersBacking.put(holder.name, new ParameterInfo(ArrayHelper.toIntArray(holder.positions), holder.type));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 126 */       this.namedParameters = Collections.unmodifiableMap(namedParametersBacking);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ParameterInfo implements Serializable {
/*     */     private final int[] sqlLocations;
/*     */     private final Type expectedType;
/*     */     
/*     */     public ParameterInfo(int[] sqlPositions, Type expectedType) {
/* 135 */       this.sqlLocations = sqlPositions;
/* 136 */       this.expectedType = expectedType;
/*     */     }
/*     */     
/*     */     public ParameterInfo(int sqlPosition, Type expectedType) {
/* 140 */       this.sqlLocations = new int[] { sqlPosition };
/* 141 */       this.expectedType = expectedType;
/*     */     }
/*     */     
/*     */     public int[] getSqlLocations() {
/* 145 */       return this.sqlLocations;
/*     */     }
/*     */     
/*     */     public Type getExpectedType() {
/* 149 */       return this.expectedType;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\ParameterTranslationsImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */