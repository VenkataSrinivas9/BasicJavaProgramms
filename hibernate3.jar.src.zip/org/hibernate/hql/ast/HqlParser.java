/*     */ package org.hibernate.hql.ast;
/*     */ 
/*     */ import antlr.ASTFactory;
/*     */ import antlr.ASTPair;
/*     */ import antlr.MismatchedTokenException;
/*     */ import antlr.RecognitionException;
/*     */ import antlr.Token;
/*     */ import antlr.TokenStream;
/*     */ import antlr.TokenStreamException;
/*     */ import antlr.collections.AST;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringReader;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.hql.antlr.HqlBaseParser;
/*     */ import org.hibernate.hql.antlr.HqlTokenTypes;
/*     */ import org.hibernate.hql.ast.util.ASTPrinter;
/*     */ import org.hibernate.hql.ast.util.ASTUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HqlParser
/*     */   extends HqlBaseParser
/*     */ {
/*  33 */   private static final Log log = LogFactory.getLog(HqlParser.class);
/*     */   
/*     */   private ParseErrorHandler parseErrorHandler;
/*  36 */   private ASTPrinter printer = getASTPrinter();
/*     */   
/*     */   private static ASTPrinter getASTPrinter() {
/*  39 */     return new ASTPrinter(HqlTokenTypes.class);
/*     */   }
/*     */   
/*     */   public static HqlParser getInstance(String hql)
/*     */   {
/*  44 */     HqlLexer lexer = new HqlLexer(new StringReader(hql));
/*  45 */     return new HqlParser(lexer);
/*     */   }
/*     */   
/*     */   private HqlParser(TokenStream lexer) {
/*  49 */     super(lexer);
/*  50 */     initialize();
/*     */   }
/*     */   
/*     */   public void reportError(RecognitionException e) {
/*  54 */     this.parseErrorHandler.reportError(e);
/*     */   }
/*     */   
/*     */   public void reportError(String s) {
/*  58 */     this.parseErrorHandler.reportError(s);
/*     */   }
/*     */   
/*     */   public void reportWarning(String s) {
/*  62 */     this.parseErrorHandler.reportWarning(s);
/*     */   }
/*     */   
/*     */   public ParseErrorHandler getParseErrorHandler() {
/*  66 */     return this.parseErrorHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AST handleIdentifierError(Token token, RecognitionException ex)
/*     */     throws RecognitionException, TokenStreamException
/*     */   {
/*  80 */     if ((token instanceof HqlToken)) {
/*  81 */       HqlToken hqlToken = (HqlToken)token;
/*     */       
/*     */ 
/*  84 */       if ((hqlToken.isPossibleID()) && ((ex instanceof MismatchedTokenException))) {
/*  85 */         MismatchedTokenException mte = (MismatchedTokenException)ex;
/*     */         
/*  87 */         if (mte.expecting == 119)
/*     */         {
/*  89 */           reportWarning("Keyword  '" + token.getText() + "' is being interpreted as an identifier due to: " + mte.getMessage());
/*     */           
/*     */ 
/*     */ 
/*  93 */           ASTPair currentAST = new ASTPair();
/*  94 */           token.setType(90);
/*  95 */           this.astFactory.addASTChild(currentAST, this.astFactory.create(token));
/*  96 */           consume();
/*  97 */           AST identifierAST = currentAST.root;
/*  98 */           return identifierAST;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 103 */     return super.handleIdentifierError(token, ex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AST negateNode(AST x)
/*     */   {
/* 117 */     switch (x.getType()) {
/*     */     case 40: 
/* 119 */       x.setType(6);
/* 120 */       x.setText("{and}");
/* 121 */       negateNode(x.getFirstChild());
/* 122 */       negateNode(x.getFirstChild().getNextSibling());
/* 123 */       return x;
/*     */     case 6: 
/* 125 */       x.setType(40);
/* 126 */       x.setText("{or}");
/* 127 */       negateNode(x.getFirstChild());
/* 128 */       negateNode(x.getFirstChild().getNextSibling());
/* 129 */       return x;
/*     */     case 96: 
/* 131 */       x.setType(102);
/* 132 */       x.setText("{not}" + x.getText());
/* 133 */       return x;
/*     */     case 102: 
/* 135 */       x.setType(96);
/* 136 */       x.setText("{not}" + x.getText());
/* 137 */       return x;
/*     */     case 105: 
/* 139 */       x.setType(106);
/* 140 */       x.setText("{not}" + x.getText());
/* 141 */       return x;
/*     */     case 104: 
/* 143 */       x.setType(107);
/* 144 */       x.setText("{not}" + x.getText());
/* 145 */       return x;
/*     */     case 107: 
/* 147 */       x.setType(104);
/* 148 */       x.setText("{not}" + x.getText());
/* 149 */       return x;
/*     */     case 106: 
/* 151 */       x.setType(105);
/* 152 */       x.setText("{not}" + x.getText());
/* 153 */       return x;
/*     */     case 34: 
/* 155 */       x.setType(81);
/* 156 */       x.setText("{not}" + x.getText());
/* 157 */       return x;
/*     */     case 81: 
/* 159 */       x.setType(34);
/* 160 */       x.setText("{not}" + x.getText());
/* 161 */       return x;
/*     */     case 26: 
/* 163 */       x.setType(80);
/* 164 */       x.setText("{not}" + x.getText());
/* 165 */       return x;
/*     */     case 80: 
/* 167 */       x.setType(26);
/* 168 */       x.setText("{not}" + x.getText());
/* 169 */       return x;
/*     */     case 77: 
/* 171 */       x.setType(76);
/* 172 */       x.setText("{not}" + x.getText());
/* 173 */       return x;
/*     */     case 76: 
/* 175 */       x.setType(77);
/* 176 */       x.setText("{not}" + x.getText());
/* 177 */       return x;
/*     */     case 10: 
/* 179 */       x.setType(79);
/* 180 */       x.setText("{not}" + x.getText());
/* 181 */       return x;
/*     */     case 79: 
/* 183 */       x.setType(10);
/* 184 */       x.setText("{not}" + x.getText());
/* 185 */       return x;
/*     */     }
/*     */     
/*     */     
/*     */ 
/*     */ 
/* 191 */     return super.negateNode(x);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AST processEqualityExpression(AST x)
/*     */   {
/* 202 */     if (x == null) {
/* 203 */       log.warn("processEqualityExpression() : No expression to process!");
/* 204 */       return null;
/*     */     }
/*     */     
/* 207 */     int type = x.getType();
/* 208 */     if ((type == 96) || (type == 102)) {
/* 209 */       boolean negated = type == 102;
/* 210 */       if (x.getNumberOfChildren() == 2) {
/* 211 */         AST a = x.getFirstChild();
/* 212 */         AST b = a.getNextSibling();
/*     */         
/* 214 */         if ((a.getType() == 39) && (b.getType() != 39)) {
/* 215 */           return createIsNullParent(b, negated);
/*     */         }
/*     */         
/* 218 */         if ((b.getType() == 39) && (a.getType() != 39)) {
/* 219 */           return createIsNullParent(a, negated);
/*     */         }
/* 221 */         if (b.getType() == 62) {
/* 222 */           return processIsEmpty(a, negated);
/*     */         }
/*     */         
/* 225 */         return x;
/*     */       }
/*     */       
/*     */ 
/* 229 */       return x;
/*     */     }
/*     */     
/*     */ 
/* 233 */     return x;
/*     */   }
/*     */   
/*     */   private AST createIsNullParent(AST node, boolean negated)
/*     */   {
/* 238 */     node.setNextSibling(null);
/* 239 */     int type = negated ? 76 : 77;
/* 240 */     String text = negated ? "is not null" : "is null";
/* 241 */     return ASTUtil.createParent(this.astFactory, type, text, node);
/*     */   }
/*     */   
/*     */   private AST processIsEmpty(AST node, boolean negated) {
/* 245 */     node.setNextSibling(null);
/*     */     
/*     */ 
/* 248 */     AST ast = createSubquery(node);
/* 249 */     ast = ASTUtil.createParent(this.astFactory, 19, "exists", ast);
/*     */     
/* 251 */     if (!negated) {
/* 252 */       ast = ASTUtil.createParent(this.astFactory, 38, "not", ast);
/*     */     }
/* 254 */     return ast;
/*     */   }
/*     */   
/*     */   private AST createSubquery(AST node) {
/* 258 */     AST ast = ASTUtil.createParent(this.astFactory, 84, "RANGE", node);
/* 259 */     ast = ASTUtil.createParent(this.astFactory, 22, "from", ast);
/* 260 */     ast = ASTUtil.createParent(this.astFactory, 86, "SELECT_FROM", ast);
/* 261 */     ast = ASTUtil.createParent(this.astFactory, 83, "QUERY", ast);
/* 262 */     return ast;
/*     */   }
/*     */   
/*     */   public void showAst(AST ast, PrintStream out) {
/* 266 */     showAst(ast, new PrintWriter(out));
/*     */   }
/*     */   
/*     */   private void showAst(AST ast, PrintWriter pw) {
/* 270 */     this.printer.showAst(ast, pw);
/*     */   }
/*     */   
/*     */   private void initialize()
/*     */   {
/* 275 */     this.parseErrorHandler = new ErrorCounter();
/* 276 */     setASTFactory(new HqlASTFactory());
/*     */   }
/*     */   
/*     */   public void weakKeywords() throws TokenStreamException
/*     */   {
/* 281 */     int t = LA(1);
/* 282 */     switch (t)
/*     */     {
/*     */ 
/*     */     case 24: 
/*     */     case 41: 
/* 287 */       if (LA(2) != 99) {
/* 288 */         LT(1).setType(119);
/* 289 */         if (log.isDebugEnabled()) {
/* 290 */           log.debug("weakKeywords() : new LT(1) token - " + LT(1));
/*     */         }
/*     */       }
/*     */       
/*     */       break;
/*     */     default: 
/* 296 */       if ((LA(0) == 22) && (t != 119) && (LA(2) == 15)) {
/* 297 */         HqlToken hqlToken = (HqlToken)LT(1);
/* 298 */         if (hqlToken.isPossibleID()) {
/* 299 */           hqlToken.setType(119);
/* 300 */           if (log.isDebugEnabled()) {
/* 301 */             log.debug("weakKeywords() : new LT(1) token - " + LT(1));
/*     */           }
/*     */         }
/*     */       }
/*     */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */   public void handleDotIdent() throws TokenStreamException
/*     */   {
/* 312 */     if ((LA(1) == 15) && (LA(2) != 119))
/*     */     {
/* 314 */       HqlToken t = (HqlToken)LT(2);
/* 315 */       if (t.isPossibleID())
/*     */       {
/*     */ 
/* 318 */         LT(2).setType(119);
/* 319 */         if (log.isDebugEnabled()) {
/* 320 */           log.debug("handleDotIdent() : new LT(2) token - " + LT(1));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void processMemberOf(Token n, AST p, ASTPair currentAST) {
/* 327 */     AST inAst = n == null ? this.astFactory.create(26, "in") : this.astFactory.create(80, "not in");
/* 328 */     this.astFactory.makeASTRoot(currentAST, inAst);
/* 329 */     AST ast = createSubquery(p);
/* 330 */     ast = ASTUtil.createParent(this.astFactory, 74, "inList", ast);
/* 331 */     inAst.addChild(ast);
/*     */   }
/*     */   
/*     */   public static void panic()
/*     */   {
/* 336 */     throw new QueryException("Parser: panic");
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\HqlParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */