package org.hibernate.hql.ast.exec;

import org.hibernate.HibernateException;
import org.hibernate.engine.QueryParameters;
import org.hibernate.engine.SessionImplementor;

public abstract interface StatementExecutor
{
  public abstract String[] getSqlStatements();
  
  public abstract int execute(QueryParameters paramQueryParameters, SessionImplementor paramSessionImplementor)
    throws HibernateException;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\exec\StatementExecutor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */