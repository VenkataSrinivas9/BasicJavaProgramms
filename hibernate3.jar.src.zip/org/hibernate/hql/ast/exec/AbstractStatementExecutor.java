/*     */ package org.hibernate.hql.ast.exec;
/*     */ 
/*     */ import antlr.RecognitionException;
/*     */ import antlr.collections.AST;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.Statement;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.action.BulkOperationCleanupAction;
/*     */ import org.hibernate.cfg.Settings;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.engine.ActionQueue;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.engine.transaction.IsolatedWork;
/*     */ import org.hibernate.engine.transaction.Isolater;
/*     */ import org.hibernate.event.EventSource;
/*     */ import org.hibernate.hql.ast.HqlSqlWalker;
/*     */ import org.hibernate.hql.ast.SqlGenerator;
/*     */ import org.hibernate.hql.ast.util.SessionFactoryHelper;
/*     */ import org.hibernate.jdbc.Batcher;
/*     */ import org.hibernate.jdbc.ConnectionManager;
/*     */ import org.hibernate.jdbc.JDBCContext;
/*     */ import org.hibernate.persister.entity.Queryable;
/*     */ import org.hibernate.sql.InsertSelect;
/*     */ import org.hibernate.sql.Select;
/*     */ import org.hibernate.sql.SelectFragment;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ public abstract class AbstractStatementExecutor
/*     */   implements StatementExecutor
/*     */ {
/*     */   private final Log log;
/*     */   private final HqlSqlWalker walker;
/*     */   
/*     */   public AbstractStatementExecutor(HqlSqlWalker walker, Log log)
/*     */   {
/*  39 */     this.walker = walker;
/*  40 */     this.log = log;
/*     */   }
/*     */   
/*     */   protected HqlSqlWalker getWalker() {
/*  44 */     return this.walker;
/*     */   }
/*     */   
/*     */   protected SessionFactoryImplementor getFactory() {
/*  48 */     return this.walker.getSessionFactoryHelper().getFactory();
/*     */   }
/*     */   
/*     */   protected abstract Queryable[] getAffectedQueryables();
/*     */   
/*     */   protected String generateIdInsertSelect(Queryable persister, AST whereClause) {
/*  54 */     Select select = new Select(getFactory().getDialect());
/*  55 */     String tableAlias = "bulk_target";
/*  56 */     SelectFragment selectFragment = new SelectFragment().addColumns(tableAlias, persister.getIdentifierColumnNames(), persister.getIdentifierColumnNames());
/*     */     
/*  58 */     select.setSelectClause(selectFragment.toFragmentString().substring(2));
/*     */     
/*  60 */     String rootTableName = persister.getTableName();
/*  61 */     String fromJoinFragment = persister.fromJoinFragment(tableAlias, true, false);
/*  62 */     String whereJoinFragment = persister.whereJoinFragment(tableAlias, true, false);
/*     */     
/*  64 */     select.setFromClause(rootTableName + ' ' + tableAlias + fromJoinFragment);
/*     */     
/*  66 */     if (whereJoinFragment == null) {
/*  67 */       whereJoinFragment = "";
/*     */     }
/*     */     else {
/*  70 */       whereJoinFragment = whereJoinFragment.trim();
/*  71 */       if (whereJoinFragment.startsWith("and")) {
/*  72 */         whereJoinFragment = whereJoinFragment.substring(4);
/*     */       }
/*     */     }
/*     */     
/*  76 */     String userWhereClause = "";
/*  77 */     if (whereClause.getNumberOfChildren() != 0)
/*     */     {
/*     */       try
/*     */       {
/*  81 */         SqlGenerator sqlGenerator = new SqlGenerator(getFactory());
/*  82 */         sqlGenerator.whereClause(whereClause);
/*  83 */         userWhereClause = sqlGenerator.getSQL().substring(7);
/*     */       }
/*     */       catch (RecognitionException e) {
/*  86 */         throw new HibernateException("Unable to generate id select for DML operation", e);
/*     */       }
/*  88 */       if (whereJoinFragment.length() > 0) {
/*  89 */         whereJoinFragment = whereJoinFragment + " and ";
/*     */       }
/*     */     }
/*     */     
/*  93 */     select.setWhereClause(whereJoinFragment + userWhereClause);
/*     */     
/*  95 */     InsertSelect insert = new InsertSelect(getFactory().getDialect());
/*  96 */     if ((getFactory().getSettings().isCommentsEnabled()) && (getFactory().getDialect().supportsCommentOn())) {
/*  97 */       insert.setComment("insert-select for " + persister.getEntityName() + " ids");
/*     */     }
/*  99 */     insert.setTableName(persister.getTemporaryIdTableName());
/* 100 */     insert.setSelect(select);
/* 101 */     return insert.toStatementString();
/*     */   }
/*     */   
/*     */   protected String generateIdSubselect(Queryable persister) {
/* 105 */     return "select " + StringHelper.join(", ", persister.getIdentifierColumnNames()) + " from " + persister.getTemporaryIdTableName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void createTemporaryTableIfNecessary(final Queryable persister, SessionImplementor session)
/*     */   {
/* 112 */     IsolatedWork work = new IsolatedWork() {
/*     */       public void doWork(Connection connection) throws HibernateException {
/* 114 */         Statement stmnt = null;
/*     */         try {
/* 116 */           stmnt = connection.createStatement();
/* 117 */           stmnt.executeUpdate(persister.getTemporaryIdTableDDL());
/*     */         }
/*     */         catch (Throwable t) {
/* 120 */           AbstractStatementExecutor.this.log.debug("unable to create temporary id table [" + t.getMessage() + "]");
/*     */         }
/*     */         finally {
/* 123 */           if (stmnt != null) {
/*     */             try {
/* 125 */               stmnt.close();
/*     */             }
/*     */             catch (Throwable ignore) {}
/*     */           }
/*     */         }
/*     */       }
/*     */     };
/*     */     
/*     */ 
/* 134 */     if (getFactory().getDialect().performTemporaryTableDDLInIsolation()) {
/* 135 */       Isolater.doIsolatedWork(work, session);
/*     */     }
/*     */     else {
/* 138 */       work.doWork(session.getJDBCContext().getConnectionManager().getConnection());
/* 139 */       session.getJDBCContext().getConnectionManager().afterStatement();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void dropTemporaryTableIfNecessary(final Queryable persister, SessionImplementor session) {
/* 144 */     if (getFactory().getDialect().dropTemporaryTableAfterUse()) {
/* 145 */       IsolatedWork work = new IsolatedWork() {
/*     */         public void doWork(Connection connection) throws HibernateException {
/* 147 */           Statement stmnt = null;
/*     */           try {
/* 149 */             stmnt = connection.createStatement();
/* 150 */             stmnt.executeUpdate("drop table " + persister.getTemporaryIdTableName());
/*     */           }
/*     */           catch (Throwable t) {
/* 153 */             AbstractStatementExecutor.this.log.warn("unable to drop temporary id table after use", t);
/*     */           }
/*     */           finally {
/* 156 */             if (stmnt != null) {
/*     */               try {
/* 158 */                 stmnt.close();
/*     */               }
/*     */               catch (Throwable ignore) {}
/*     */             }
/*     */           }
/*     */         }
/*     */       };
/*     */       
/*     */ 
/* 167 */       if (getFactory().getDialect().performTemporaryTableDDLInIsolation()) {
/* 168 */         Isolater.doIsolatedWork(work, session);
/*     */       }
/*     */       else {
/* 171 */         work.doWork(session.getJDBCContext().getConnectionManager().getConnection());
/* 172 */         session.getJDBCContext().getConnectionManager().afterStatement();
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 177 */       PreparedStatement ps = null;
/*     */       try {
/* 179 */         ps = session.getBatcher().prepareStatement("delete from " + persister.getTemporaryIdTableName());
/* 180 */         ps.executeUpdate();
/*     */       }
/*     */       catch (Throwable t) {
/* 183 */         this.log.warn("unable to cleanup temporary id table after use", t);
/*     */       }
/*     */       finally {
/* 186 */         if (ps != null) {
/*     */           try {
/* 188 */             session.getBatcher().closeStatement(ps);
/*     */           }
/*     */           catch (Throwable ignore) {}
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void coordinateSharedCacheCleanup(SessionImplementor session)
/*     */   {
/* 199 */     BulkOperationCleanupAction action = new BulkOperationCleanupAction(session, getAffectedQueryables());
/*     */     
/* 201 */     action.init();
/*     */     
/* 203 */     if (session.isEventSource()) {
/* 204 */       ((EventSource)session).getActionQueue().addAction(action);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\exec\AbstractStatementExecutor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */