/*     */ package org.hibernate.hql.ast.exec;
/*     */ 
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.cfg.Settings;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.engine.QueryParameters;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.exception.JDBCExceptionHelper;
/*     */ import org.hibernate.hql.ast.HqlSqlWalker;
/*     */ import org.hibernate.hql.ast.tree.AssignmentSpecification;
/*     */ import org.hibernate.hql.ast.tree.FromClause;
/*     */ import org.hibernate.hql.ast.tree.FromElement;
/*     */ import org.hibernate.hql.ast.tree.UpdateStatement;
/*     */ import org.hibernate.hql.ast.util.SessionFactoryHelper;
/*     */ import org.hibernate.jdbc.Batcher;
/*     */ import org.hibernate.param.ParameterSpecification;
/*     */ import org.hibernate.persister.entity.Queryable;
/*     */ import org.hibernate.sql.Update;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ public class MultiTableUpdateExecutor
/*     */   extends AbstractStatementExecutor
/*     */ {
/*  32 */   private static final Log log = LogFactory.getLog(MultiTableUpdateExecutor.class);
/*     */   private final Queryable persister;
/*     */   private final String idInsertSelect;
/*     */   private final String[] updates;
/*     */   private final ParameterSpecification[][] hqlParameters;
/*     */   
/*     */   public MultiTableUpdateExecutor(HqlSqlWalker walker)
/*     */   {
/*  40 */     super(walker, log);
/*     */     
/*  42 */     if (!walker.getSessionFactoryHelper().getFactory().getDialect().supportsTemporaryTables()) {
/*  43 */       throw new HibernateException("cannot perform multi-table updates using dialect not supporting temp tables");
/*     */     }
/*     */     
/*  46 */     UpdateStatement updateStatement = (UpdateStatement)walker.getAST();
/*  47 */     FromElement fromElement = updateStatement.getFromClause().getFromElement();
/*  48 */     this.persister = fromElement.getQueryable();
/*     */     
/*  50 */     this.idInsertSelect = generateIdInsertSelect(this.persister, updateStatement.getWhereClause());
/*  51 */     log.trace("Generated ID-INSERT-SELECT SQL (multi-table update) : " + this.idInsertSelect);
/*     */     
/*  53 */     String[] tableNames = this.persister.getConstraintOrderedTableNameClosure();
/*  54 */     String[][] columnNames = this.persister.getContraintOrderedTableKeyColumnClosure();
/*     */     
/*  56 */     String idSubselect = generateIdSubselect(this.persister);
/*  57 */     List assignmentSpecifications = walker.getAssignmentSpecifications();
/*     */     
/*  59 */     this.updates = new String[tableNames.length];
/*  60 */     this.hqlParameters = new ParameterSpecification[tableNames.length][];
/*  61 */     for (int tableIndex = 0; tableIndex < tableNames.length; tableIndex++) {
/*  62 */       boolean affected = false;
/*  63 */       List parameterList = new ArrayList();
/*  64 */       Update update = new Update(getFactory().getDialect()).setTableName(tableNames[tableIndex]).setWhere("(" + StringHelper.join(", ", columnNames[tableIndex]) + ") IN (" + idSubselect + ")");
/*     */       
/*     */ 
/*  67 */       if ((getFactory().getSettings().isCommentsEnabled()) && (getFactory().getDialect().supportsCommentOn())) {
/*  68 */         update.setComment("bulk update");
/*     */       }
/*  70 */       Iterator itr = assignmentSpecifications.iterator();
/*  71 */       while (itr.hasNext()) {
/*  72 */         AssignmentSpecification specification = (AssignmentSpecification)itr.next();
/*  73 */         if (specification.affectsTable(tableNames[tableIndex])) {
/*  74 */           affected = true;
/*  75 */           update.appendAssignmentFragment(specification.getSqlAssignmentFragment());
/*  76 */           if (specification.getParameters() != null) {
/*  77 */             for (int paramIndex = 0; paramIndex < specification.getParameters().length; paramIndex++) {
/*  78 */               parameterList.add(specification.getParameters()[paramIndex]);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*  83 */       if (affected) {
/*  84 */         this.updates[tableIndex] = update.toStatementString();
/*  85 */         this.hqlParameters[tableIndex] = ((ParameterSpecification[])parameterList.toArray(new ParameterSpecification[0]));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Queryable getAffectedQueryable() {
/*  91 */     return this.persister;
/*     */   }
/*     */   
/*     */   public String[] getSqlStatements() {
/*  95 */     return this.updates;
/*     */   }
/*     */   
/*     */   public int execute(QueryParameters parameters, SessionImplementor session) throws HibernateException {
/*  99 */     coordinateSharedCacheCleanup(session);
/*     */     
/* 101 */     createTemporaryTableIfNecessary(this.persister, session);
/*     */     
/*     */     try
/*     */     {
/* 105 */       PreparedStatement ps = null;
/* 106 */       int resultCount = 0;
/*     */       try {
/*     */         try {
/* 109 */           ps = session.getBatcher().prepareStatement(this.idInsertSelect);
/* 110 */           int parameterStart = getWalker().getNumberOfParametersInSetClause();
/* 111 */           List allParams = getWalker().getParameters();
/* 112 */           Iterator whereParams = allParams.subList(parameterStart, allParams.size()).iterator();
/* 113 */           int sum = 1;
/* 114 */           while (whereParams.hasNext()) {
/* 115 */             sum += ((ParameterSpecification)whereParams.next()).bind(ps, parameters, session, sum);
/*     */           }
/* 117 */           resultCount = ps.executeUpdate();
/*     */         }
/*     */         finally {
/* 120 */           if (ps != null) {
/* 121 */             session.getBatcher().closeStatement(ps);
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (SQLException e) {
/* 126 */         throw JDBCExceptionHelper.convert(getFactory().getSQLExceptionConverter(), e, "could not insert/select ids for bulk update", this.idInsertSelect);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 135 */       for (int i = 0; i < this.updates.length; i++) {
/* 136 */         if (this.updates[i] != null) {
/*     */           try
/*     */           {
/*     */             try
/*     */             {
/* 141 */               ps = session.getBatcher().prepareStatement(this.updates[i]);
/* 142 */               if (this.hqlParameters[i] != null) {
/* 143 */                 int position = 1;
/* 144 */                 for (int x = 0; x < this.hqlParameters[i].length; x++) {
/* 145 */                   position += this.hqlParameters[i][x].bind(ps, parameters, session, position);
/*     */                 }
/*     */               }
/* 148 */               ps.executeUpdate();
/*     */             }
/*     */             finally {
/* 151 */               if (ps != null) {
/* 152 */                 session.getBatcher().closeStatement(ps);
/*     */               }
/*     */             }
/*     */           }
/*     */           catch (SQLException e) {
/* 157 */             throw JDBCExceptionHelper.convert(getFactory().getSQLExceptionConverter(), e, "error performing bulk update", this.updates[i]);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 166 */       return resultCount;
/*     */     }
/*     */     finally {
/* 169 */       dropTemporaryTableIfNecessary(this.persister, session);
/*     */     }
/*     */   }
/*     */   
/*     */   protected Queryable[] getAffectedQueryables() {
/* 174 */     return new Queryable[] { this.persister };
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\exec\MultiTableUpdateExecutor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */