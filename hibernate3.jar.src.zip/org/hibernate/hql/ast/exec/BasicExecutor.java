/*    */ package org.hibernate.hql.ast.exec;
/*    */ 
/*    */ import antlr.RecognitionException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.hql.ast.HqlSqlWalker;
/*    */ import org.hibernate.hql.ast.ParseErrorHandler;
/*    */ import org.hibernate.hql.ast.QuerySyntaxException;
/*    */ import org.hibernate.hql.ast.SqlGenerator;
/*    */ import org.hibernate.persister.entity.Queryable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BasicExecutor
/*    */   extends AbstractStatementExecutor
/*    */ {
/* 30 */   private static final Log log = LogFactory.getLog(BasicExecutor.class);
/*    */   private final Queryable persister;
/*    */   private final String sql;
/*    */   
/*    */   public BasicExecutor(HqlSqlWalker walker, Queryable persister)
/*    */   {
/* 36 */     super(walker, log);
/* 37 */     this.persister = persister;
/*    */     try {
/* 39 */       SqlGenerator gen = new SqlGenerator(getFactory());
/* 40 */       gen.statement(walker.getAST());
/* 41 */       this.sql = gen.getSQL();
/* 42 */       gen.getParseErrorHandler().throwQueryException();
/*    */     }
/*    */     catch (RecognitionException e) {
/* 45 */       throw new QuerySyntaxException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   public String[] getSqlStatements() {
/* 50 */     return new String[] { this.sql };
/*    */   }
/*    */   
/*    */   /* Error */
/*    */   public int execute(org.hibernate.engine.QueryParameters parameters, org.hibernate.engine.SessionImplementor session)
/*    */     throws org.hibernate.HibernateException
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_2
/*    */     //   2: invokevirtual 22	org/hibernate/hql/ast/exec/BasicExecutor:coordinateSharedCacheCleanup	(Lorg/hibernate/engine/SessionImplementor;)V
/*    */     //   5: aconst_null
/*    */     //   6: astore_3
/*    */     //   7: aload_1
/*    */     //   8: invokevirtual 23	org/hibernate/engine/QueryParameters:getRowSelection	()Lorg/hibernate/engine/RowSelection;
/*    */     //   11: astore 4
/*    */     //   13: aload_2
/*    */     //   14: invokeinterface 24 1 0
/*    */     //   19: aload_0
/*    */     //   20: getfield 15	org/hibernate/hql/ast/exec/BasicExecutor:sql	Ljava/lang/String;
/*    */     //   23: invokeinterface 25 2 0
/*    */     //   28: astore_3
/*    */     //   29: aload_0
/*    */     //   30: invokevirtual 26	org/hibernate/hql/ast/exec/BasicExecutor:getWalker	()Lorg/hibernate/hql/ast/HqlSqlWalker;
/*    */     //   33: invokevirtual 27	org/hibernate/hql/ast/HqlSqlWalker:getParameters	()Ljava/util/ArrayList;
/*    */     //   36: invokevirtual 28	java/util/ArrayList:iterator	()Ljava/util/Iterator;
/*    */     //   39: astore 5
/*    */     //   41: iconst_1
/*    */     //   42: istore 6
/*    */     //   44: aload 5
/*    */     //   46: invokeinterface 29 1 0
/*    */     //   51: ifeq +35 -> 86
/*    */     //   54: aload 5
/*    */     //   56: invokeinterface 30 1 0
/*    */     //   61: checkcast 31	org/hibernate/param/ParameterSpecification
/*    */     //   64: astore 7
/*    */     //   66: iload 6
/*    */     //   68: aload 7
/*    */     //   70: aload_3
/*    */     //   71: aload_1
/*    */     //   72: aload_2
/*    */     //   73: iload 6
/*    */     //   75: invokeinterface 32 5 0
/*    */     //   80: iadd
/*    */     //   81: istore 6
/*    */     //   83: goto -39 -> 44
/*    */     //   86: aload 4
/*    */     //   88: ifnull +25 -> 113
/*    */     //   91: aload 4
/*    */     //   93: invokevirtual 33	org/hibernate/engine/RowSelection:getTimeout	()Ljava/lang/Integer;
/*    */     //   96: ifnull +17 -> 113
/*    */     //   99: aload_3
/*    */     //   100: aload 4
/*    */     //   102: invokevirtual 33	org/hibernate/engine/RowSelection:getTimeout	()Ljava/lang/Integer;
/*    */     //   105: invokevirtual 34	java/lang/Integer:intValue	()I
/*    */     //   108: invokeinterface 35 2 0
/*    */     //   113: aload_3
/*    */     //   114: invokeinterface 36 1 0
/*    */     //   119: istore 7
/*    */     //   121: jsr +14 -> 135
/*    */     //   124: iload 7
/*    */     //   126: ireturn
/*    */     //   127: astore 8
/*    */     //   129: jsr +6 -> 135
/*    */     //   132: aload 8
/*    */     //   134: athrow
/*    */     //   135: astore 9
/*    */     //   137: aload_3
/*    */     //   138: ifnull +15 -> 153
/*    */     //   141: aload_2
/*    */     //   142: invokeinterface 24 1 0
/*    */     //   147: aload_3
/*    */     //   148: invokeinterface 37 2 0
/*    */     //   153: ret 9
/*    */     //   155: astore 5
/*    */     //   157: aload_0
/*    */     //   158: invokevirtual 10	org/hibernate/hql/ast/exec/BasicExecutor:getFactory	()Lorg/hibernate/engine/SessionFactoryImplementor;
/*    */     //   161: invokeinterface 39 1 0
/*    */     //   166: aload 5
/*    */     //   168: ldc 40
/*    */     //   170: aload_0
/*    */     //   171: getfield 15	org/hibernate/hql/ast/exec/BasicExecutor:sql	Ljava/lang/String;
/*    */     //   174: invokestatic 41	org/hibernate/exception/JDBCExceptionHelper:convert	(Lorg/hibernate/exception/SQLExceptionConverter;Ljava/sql/SQLException;Ljava/lang/String;Ljava/lang/String;)Lorg/hibernate/JDBCException;
/*    */     //   177: athrow
/*    */     // Line number table:
/*    */     //   Java source line #55	-> byte code offset #0
/*    */     //   Java source line #57	-> byte code offset #5
/*    */     //   Java source line #58	-> byte code offset #7
/*    */     //   Java source line #62	-> byte code offset #13
/*    */     //   Java source line #63	-> byte code offset #29
/*    */     //   Java source line #64	-> byte code offset #41
/*    */     //   Java source line #65	-> byte code offset #44
/*    */     //   Java source line #66	-> byte code offset #54
/*    */     //   Java source line #67	-> byte code offset #66
/*    */     //   Java source line #69	-> byte code offset #86
/*    */     //   Java source line #70	-> byte code offset #91
/*    */     //   Java source line #71	-> byte code offset #99
/*    */     //   Java source line #75	-> byte code offset #113
/*    */     //   Java source line #78	-> byte code offset #127
/*    */     //   Java source line #79	-> byte code offset #141
/*    */     //   Java source line #83	-> byte code offset #155
/*    */     //   Java source line #84	-> byte code offset #157
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	178	0	this	BasicExecutor
/*    */     //   0	178	1	parameters	org.hibernate.engine.QueryParameters
/*    */     //   0	178	2	session	org.hibernate.engine.SessionImplementor
/*    */     //   6	142	3	st	java.sql.PreparedStatement
/*    */     //   11	90	4	selection	org.hibernate.engine.RowSelection
/*    */     //   39	16	5	paramSpecifications	java.util.Iterator
/*    */     //   155	12	5	sqle	java.sql.SQLException
/*    */     //   42	40	6	pos	int
/*    */     //   64	61	7	paramSpec	org.hibernate.param.ParameterSpecification
/*    */     //   127	6	8	localObject1	Object
/*    */     //   135	1	9	localObject2	Object
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   13	124	127	finally
/*    */     //   127	132	127	finally
/*    */     //   13	124	155	java/sql/SQLException
/*    */     //   127	155	155	java/sql/SQLException
/*    */   }
/*    */   
/*    */   protected Queryable[] getAffectedQueryables()
/*    */   {
/* 94 */     return new Queryable[] { this.persister };
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\exec\BasicExecutor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */