/*     */ package org.hibernate.hql.ast.exec;
/*     */ 
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.cfg.Settings;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.engine.QueryParameters;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.exception.JDBCExceptionHelper;
/*     */ import org.hibernate.hql.ast.HqlSqlWalker;
/*     */ import org.hibernate.hql.ast.tree.DeleteStatement;
/*     */ import org.hibernate.hql.ast.tree.FromClause;
/*     */ import org.hibernate.hql.ast.tree.FromElement;
/*     */ import org.hibernate.hql.ast.util.SessionFactoryHelper;
/*     */ import org.hibernate.jdbc.Batcher;
/*     */ import org.hibernate.param.ParameterSpecification;
/*     */ import org.hibernate.persister.entity.Queryable;
/*     */ import org.hibernate.sql.Delete;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ public class MultiTableDeleteExecutor extends AbstractStatementExecutor
/*     */ {
/*  29 */   private static final Log log = LogFactory.getLog(MultiTableDeleteExecutor.class);
/*     */   private final Queryable persister;
/*     */   private final String idInsertSelect;
/*     */   private final String[] deletes;
/*     */   
/*     */   public MultiTableDeleteExecutor(HqlSqlWalker walker)
/*     */   {
/*  36 */     super(walker, log);
/*     */     
/*  38 */     if (!walker.getSessionFactoryHelper().getFactory().getDialect().supportsTemporaryTables()) {
/*  39 */       throw new HibernateException("cannot perform multi-table deletes using dialect not supporting temp tables");
/*     */     }
/*     */     
/*  42 */     DeleteStatement deleteStatement = (DeleteStatement)walker.getAST();
/*  43 */     FromElement fromElement = deleteStatement.getFromClause().getFromElement();
/*  44 */     this.persister = fromElement.getQueryable();
/*     */     
/*  46 */     this.idInsertSelect = generateIdInsertSelect(this.persister, ((DeleteStatement)walker.getAST()).getWhereClause());
/*  47 */     log.trace("Generated ID-INSERT-SELECT SQL (multi-table delete) : " + this.idInsertSelect);
/*     */     
/*  49 */     String[] tableNames = this.persister.getConstraintOrderedTableNameClosure();
/*  50 */     String[][] columnNames = this.persister.getContraintOrderedTableKeyColumnClosure();
/*  51 */     String idSubselect = generateIdSubselect(this.persister);
/*     */     
/*  53 */     this.deletes = new String[tableNames.length];
/*  54 */     for (int i = tableNames.length - 1; i >= 0; i--)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*  59 */       Delete delete = new Delete().setTableName(tableNames[i]).setWhere("(" + StringHelper.join(", ", columnNames[i]) + ") IN (" + idSubselect + ")");
/*     */       
/*     */ 
/*  62 */       if ((getFactory().getSettings().isCommentsEnabled()) && (getFactory().getDialect().supportsCommentOn())) {
/*  63 */         delete.setComment("bulk delete");
/*     */       }
/*     */       
/*  66 */       this.deletes[i] = delete.toStatementString();
/*     */     }
/*     */   }
/*     */   
/*     */   public String[] getSqlStatements() {
/*  71 */     return this.deletes;
/*     */   }
/*     */   
/*     */   public int execute(QueryParameters parameters, SessionImplementor session) throws HibernateException {
/*  75 */     coordinateSharedCacheCleanup(session);
/*     */     
/*  77 */     createTemporaryTableIfNecessary(this.persister, session);
/*     */     
/*     */     try
/*     */     {
/*  81 */       PreparedStatement ps = null;
/*  82 */       int resultCount = 0;
/*     */       try {
/*     */         try {
/*  85 */           ps = session.getBatcher().prepareStatement(this.idInsertSelect);
/*  86 */           Iterator paramSpecifications = getWalker().getParameters().iterator();
/*  87 */           int pos = 1;
/*  88 */           while (paramSpecifications.hasNext()) {
/*  89 */             ParameterSpecification paramSpec = (ParameterSpecification)paramSpecifications.next();
/*  90 */             pos += paramSpec.bind(ps, parameters, session, pos);
/*     */           }
/*  92 */           resultCount = ps.executeUpdate();
/*     */         }
/*     */         finally {
/*  95 */           if (ps != null) {
/*  96 */             session.getBatcher().closeStatement(ps);
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (SQLException e) {
/* 101 */         throw JDBCExceptionHelper.convert(getFactory().getSQLExceptionConverter(), e, "could not insert/select ids for bulk delete", this.idInsertSelect);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 110 */       for (int i = 0; i < this.deletes.length; i++) {
/*     */         try {
/*     */           try {
/* 113 */             ps = session.getBatcher().prepareStatement(this.deletes[i]);
/* 114 */             ps.executeUpdate();
/*     */           }
/*     */           finally {
/* 117 */             if (ps != null) {
/* 118 */               session.getBatcher().closeStatement(ps);
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (SQLException e) {
/* 123 */           throw JDBCExceptionHelper.convert(getFactory().getSQLExceptionConverter(), e, "error performing bulk delete", this.deletes[i]);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 132 */       return resultCount;
/*     */     }
/*     */     finally {
/* 135 */       dropTemporaryTableIfNecessary(this.persister, session);
/*     */     }
/*     */   }
/*     */   
/*     */   protected Queryable[] getAffectedQueryables() {
/* 140 */     return new Queryable[] { this.persister };
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\exec\MultiTableDeleteExecutor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */