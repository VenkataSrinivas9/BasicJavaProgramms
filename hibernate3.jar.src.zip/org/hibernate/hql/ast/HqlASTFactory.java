/*    */ package org.hibernate.hql.ast;
/*    */ 
/*    */ import antlr.ASTFactory;
/*    */ import org.hibernate.hql.ast.tree.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HqlASTFactory
/*    */   extends ASTFactory
/*    */ {
/*    */   public Class getASTNodeType(int tokenType)
/*    */   {
/* 20 */     return Node.class;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\HqlASTFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */