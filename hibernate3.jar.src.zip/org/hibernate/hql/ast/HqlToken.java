/*    */ package org.hibernate.hql.ast;
/*    */ 
/*    */ import antlr.CommonToken;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HqlToken
/*    */   extends CommonToken
/*    */ {
/* 13 */   private boolean possibleID = false;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private int tokenType;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isPossibleID()
/*    */   {
/* 26 */     return this.possibleID;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setType(int t)
/*    */   {
/* 35 */     this.tokenType = getType();
/* 36 */     super.setType(t);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private int getPreviousType()
/*    */   {
/* 45 */     return this.tokenType;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setPossibleID(boolean possibleID)
/*    */   {
/* 55 */     this.possibleID = possibleID;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 64 */     return "[\"" + getText() + "\",<" + getType() + "> previously: <" + getPreviousType() + ">,line=" + this.line + ",col=" + this.col + ",possibleID=" + this.possibleID + "]";
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\HqlToken.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */