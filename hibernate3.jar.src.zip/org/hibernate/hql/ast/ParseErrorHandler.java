package org.hibernate.hql.ast;

import org.hibernate.QueryException;

public abstract interface ParseErrorHandler
  extends ErrorReporter
{
  public abstract int getErrorCount();
  
  public abstract void throwQueryException()
    throws QueryException;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ast\ParseErrorHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */