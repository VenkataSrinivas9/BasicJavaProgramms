package org.hibernate.hql;

import java.util.Map;
import org.hibernate.engine.SessionFactoryImplementor;

public abstract interface QueryTranslatorFactory
{
  public abstract QueryTranslator createQueryTranslator(String paramString1, String paramString2, Map paramMap, SessionFactoryImplementor paramSessionFactoryImplementor);
  
  public abstract FilterTranslator createFilterTranslator(String paramString1, String paramString2, Map paramMap, SessionFactoryImplementor paramSessionFactoryImplementor);
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\QueryTranslatorFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */