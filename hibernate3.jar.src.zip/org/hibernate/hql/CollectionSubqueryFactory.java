/*    */ package org.hibernate.hql;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.hibernate.MappingException;
/*    */ import org.hibernate.QueryException;
/*    */ import org.hibernate.engine.JoinSequence;
/*    */ import org.hibernate.sql.JoinFragment;
/*    */ import org.hibernate.util.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CollectionSubqueryFactory
/*    */ {
/*    */   public static String createCollectionSubquery(JoinSequence joinSequence, Map enabledFilters, String[] columns)
/*    */   {
/*    */     try
/*    */     {
/* 31 */       JoinFragment join = joinSequence.toJoinFragment(enabledFilters, true);
/* 32 */       return "select " + StringHelper.join(", ", columns) + " from " + join.toFromFragmentString().substring(2) + " where " + join.toWhereFragmentString().substring(5);
/*    */ 
/*    */ 
/*    */ 
/*    */     }
/*    */     catch (MappingException me)
/*    */     {
/*    */ 
/*    */ 
/* 41 */       throw new QueryException(me);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\CollectionSubqueryFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */