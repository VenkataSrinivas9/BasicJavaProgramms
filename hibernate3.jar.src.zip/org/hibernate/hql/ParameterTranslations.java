package org.hibernate.hql;

import java.util.Set;
import org.hibernate.type.Type;

public abstract interface ParameterTranslations
{
  public abstract boolean supportsOrdinalParameterMetadata();
  
  public abstract int getOrdinalParameterCount();
  
  public abstract int getOrdinalParameterSqlLocation(int paramInt);
  
  public abstract Type getOrdinalParameterExpectedType(int paramInt);
  
  public abstract Set getNamedParameterNames();
  
  public abstract int[] getNamedParameterSqlLocations(String paramString);
  
  public abstract Type getNamedParameterExpectedType(String paramString);
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\ParameterTranslations.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */