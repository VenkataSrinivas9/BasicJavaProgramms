/*      */ package org.hibernate.hql.antlr;
/*      */ 
/*      */ import antlr.ASTFactory;
/*      */ import antlr.ASTPair;
/*      */ import antlr.LLkParser;
/*      */ import antlr.NoViableAltException;
/*      */ import antlr.ParserSharedInputState;
/*      */ import antlr.RecognitionException;
/*      */ import antlr.SemanticException;
/*      */ import antlr.Token;
/*      */ import antlr.TokenBuffer;
/*      */ import antlr.TokenStream;
/*      */ import antlr.TokenStreamException;
/*      */ import antlr.collections.AST;
/*      */ import antlr.collections.impl.ASTArray;
/*      */ import antlr.collections.impl.BitSet;
/*      */ import org.hibernate.hql.ast.util.ASTUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HqlBaseParser
/*      */   extends LLkParser
/*      */   implements HqlTokenTypes
/*      */ {
/*   44 */   private boolean filter = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFilter(boolean f)
/*      */   {
/*   51 */     this.filter = f;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isFilter()
/*      */   {
/*   59 */     return this.filter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AST handleIdentifierError(Token token, RecognitionException ex)
/*      */     throws RecognitionException, TokenStreamException
/*      */   {
/*   70 */     throw ex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleDotIdent()
/*      */     throws TokenStreamException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public AST negateNode(AST x)
/*      */   {
/*   86 */     return ASTUtil.createParent(this.astFactory, 38, "not", x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public AST processEqualityExpression(AST x)
/*      */     throws RecognitionException
/*      */   {
/*   94 */     return x;
/*      */   }
/*      */   
/*      */   public void weakKeywords() throws TokenStreamException
/*      */   {}
/*      */   
/*      */   public void processMemberOf(Token n, AST p, ASTPair currentAST) {}
/*      */   
/*      */   protected HqlBaseParser(TokenBuffer tokenBuf, int k) {
/*  103 */     super(tokenBuf, k);
/*  104 */     this.tokenNames = _tokenNames;
/*  105 */     buildTokenTypeASTClassMap();
/*  106 */     this.astFactory = new ASTFactory(getTokenTypeToASTClassMap());
/*      */   }
/*      */   
/*      */   public HqlBaseParser(TokenBuffer tokenBuf) {
/*  110 */     this(tokenBuf, 3);
/*      */   }
/*      */   
/*      */   protected HqlBaseParser(TokenStream lexer, int k) {
/*  114 */     super(lexer, k);
/*  115 */     this.tokenNames = _tokenNames;
/*  116 */     buildTokenTypeASTClassMap();
/*  117 */     this.astFactory = new ASTFactory(getTokenTypeToASTClassMap());
/*      */   }
/*      */   
/*      */   public HqlBaseParser(TokenStream lexer) {
/*  121 */     this(lexer, 3);
/*      */   }
/*      */   
/*      */   public HqlBaseParser(ParserSharedInputState state) {
/*  125 */     super(state, 3);
/*  126 */     this.tokenNames = _tokenNames;
/*  127 */     buildTokenTypeASTClassMap();
/*  128 */     this.astFactory = new ASTFactory(getTokenTypeToASTClassMap());
/*      */   }
/*      */   
/*      */   public final void statement() throws RecognitionException, TokenStreamException
/*      */   {
/*  133 */     this.returnAST = null;
/*  134 */     ASTPair currentAST = new ASTPair();
/*  135 */     AST statement_AST = null;
/*      */     
/*      */     try
/*      */     {
/*  139 */       switch (LA(1))
/*      */       {
/*      */       case 51: 
/*  142 */         updateStatement();
/*  143 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*  144 */         break;
/*      */       
/*      */ 
/*      */       case 13: 
/*  148 */         deleteStatement();
/*  149 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*  150 */         break;
/*      */       
/*      */ 
/*      */       case 1: 
/*      */       case 22: 
/*      */       case 24: 
/*      */       case 41: 
/*      */       case 45: 
/*      */       case 53: 
/*  159 */         selectStatement();
/*  160 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*  161 */         break;
/*      */       
/*      */ 
/*      */       case 29: 
/*  165 */         insertStatement();
/*  166 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*  167 */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  171 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/*  175 */       statement_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  178 */       reportError(ex);
/*  179 */       recover(ex, _tokenSet_0);
/*      */     }
/*  181 */     this.returnAST = statement_AST;
/*      */   }
/*      */   
/*      */   public final void updateStatement() throws RecognitionException, TokenStreamException
/*      */   {
/*  186 */     this.returnAST = null;
/*  187 */     ASTPair currentAST = new ASTPair();
/*  188 */     AST updateStatement_AST = null;
/*      */     try
/*      */     {
/*  191 */       AST tmp1_AST = null;
/*  192 */       tmp1_AST = this.astFactory.create(LT(1));
/*  193 */       this.astFactory.makeASTRoot(currentAST, tmp1_AST);
/*  194 */       match(51);
/*      */       
/*  196 */       switch (LA(1))
/*      */       {
/*      */       case 52: 
/*  199 */         AST tmp2_AST = null;
/*  200 */         tmp2_AST = this.astFactory.create(LT(1));
/*  201 */         this.astFactory.addASTChild(currentAST, tmp2_AST);
/*  202 */         match(52);
/*  203 */         break;
/*      */       
/*      */ 
/*      */       case 22: 
/*      */       case 119: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  212 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/*  216 */       optionalFromTokenFromClause();
/*  217 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*  218 */       setClause();
/*  219 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*  221 */       switch (LA(1))
/*      */       {
/*      */       case 53: 
/*  224 */         whereClause();
/*  225 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*  226 */         break;
/*      */       
/*      */ 
/*      */       case 1: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  234 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/*  238 */       updateStatement_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  241 */       reportError(ex);
/*  242 */       recover(ex, _tokenSet_0);
/*      */     }
/*  244 */     this.returnAST = updateStatement_AST;
/*      */   }
/*      */   
/*      */   public final void deleteStatement() throws RecognitionException, TokenStreamException
/*      */   {
/*  249 */     this.returnAST = null;
/*  250 */     ASTPair currentAST = new ASTPair();
/*  251 */     AST deleteStatement_AST = null;
/*      */     try
/*      */     {
/*  254 */       AST tmp3_AST = null;
/*  255 */       tmp3_AST = this.astFactory.create(LT(1));
/*  256 */       this.astFactory.makeASTRoot(currentAST, tmp3_AST);
/*  257 */       match(13);
/*      */       
/*  259 */       optionalFromTokenFromClause();
/*  260 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*      */ 
/*  263 */       switch (LA(1))
/*      */       {
/*      */       case 53: 
/*  266 */         whereClause();
/*  267 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*  268 */         break;
/*      */       
/*      */ 
/*      */       case 1: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  276 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/*  280 */       deleteStatement_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  283 */       reportError(ex);
/*  284 */       recover(ex, _tokenSet_0);
/*      */     }
/*  286 */     this.returnAST = deleteStatement_AST;
/*      */   }
/*      */   
/*      */   public final void selectStatement() throws RecognitionException, TokenStreamException
/*      */   {
/*  291 */     this.returnAST = null;
/*  292 */     ASTPair currentAST = new ASTPair();
/*  293 */     AST selectStatement_AST = null;
/*      */     try
/*      */     {
/*  296 */       queryRule();
/*  297 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*  298 */       selectStatement_AST = currentAST.root;
/*      */       
/*  300 */       selectStatement_AST = this.astFactory.make(new ASTArray(2).add(this.astFactory.create(83, "query")).add(selectStatement_AST));
/*      */       
/*  302 */       currentAST.root = selectStatement_AST;
/*  303 */       currentAST.child = ((selectStatement_AST != null) && (selectStatement_AST.getFirstChild() != null) ? selectStatement_AST.getFirstChild() : selectStatement_AST);
/*      */       
/*  305 */       currentAST.advanceChildToEnd();
/*  306 */       selectStatement_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  309 */       reportError(ex);
/*  310 */       recover(ex, _tokenSet_0);
/*      */     }
/*  312 */     this.returnAST = selectStatement_AST;
/*      */   }
/*      */   
/*      */   public final void insertStatement() throws RecognitionException, TokenStreamException
/*      */   {
/*  317 */     this.returnAST = null;
/*  318 */     ASTPair currentAST = new ASTPair();
/*  319 */     AST insertStatement_AST = null;
/*      */     try
/*      */     {
/*  322 */       AST tmp4_AST = null;
/*  323 */       tmp4_AST = this.astFactory.create(LT(1));
/*  324 */       this.astFactory.makeASTRoot(currentAST, tmp4_AST);
/*  325 */       match(29);
/*  326 */       intoClause();
/*  327 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*  328 */       selectStatement();
/*  329 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*  330 */       insertStatement_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  333 */       reportError(ex);
/*  334 */       recover(ex, _tokenSet_0);
/*      */     }
/*  336 */     this.returnAST = insertStatement_AST;
/*      */   }
/*      */   
/*      */   public final void optionalFromTokenFromClause() throws RecognitionException, TokenStreamException
/*      */   {
/*  341 */     this.returnAST = null;
/*  342 */     ASTPair currentAST = new ASTPair();
/*  343 */     AST optionalFromTokenFromClause_AST = null;
/*  344 */     AST f_AST = null;
/*  345 */     AST a_AST = null;
/*      */     
/*      */     try
/*      */     {
/*  349 */       switch (LA(1))
/*      */       {
/*      */       case 22: 
/*  352 */         match(22);
/*  353 */         break;
/*      */       
/*      */ 
/*      */       case 119: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  361 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/*  365 */       path();
/*  366 */       f_AST = this.returnAST;
/*      */       
/*  368 */       switch (LA(1))
/*      */       {
/*      */       case 7: 
/*      */       case 119: 
/*  372 */         asAlias();
/*  373 */         a_AST = this.returnAST;
/*  374 */         break;
/*      */       
/*      */ 
/*      */       case 1: 
/*      */       case 46: 
/*      */       case 53: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  384 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/*  388 */       optionalFromTokenFromClause_AST = currentAST.root;
/*      */       
/*  390 */       AST range = this.astFactory.make(new ASTArray(3).add(this.astFactory.create(84, "RANGE")).add(f_AST).add(a_AST));
/*  391 */       optionalFromTokenFromClause_AST = this.astFactory.make(new ASTArray(2).add(this.astFactory.create(22, "FROM")).add(range));
/*      */       
/*  393 */       currentAST.root = optionalFromTokenFromClause_AST;
/*  394 */       currentAST.child = ((optionalFromTokenFromClause_AST != null) && (optionalFromTokenFromClause_AST.getFirstChild() != null) ? optionalFromTokenFromClause_AST.getFirstChild() : optionalFromTokenFromClause_AST);
/*      */       
/*  396 */       currentAST.advanceChildToEnd();
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  399 */       reportError(ex);
/*  400 */       recover(ex, _tokenSet_1);
/*      */     }
/*  402 */     this.returnAST = optionalFromTokenFromClause_AST;
/*      */   }
/*      */   
/*      */   public final void setClause() throws RecognitionException, TokenStreamException
/*      */   {
/*  407 */     this.returnAST = null;
/*  408 */     ASTPair currentAST = new ASTPair();
/*  409 */     AST setClause_AST = null;
/*      */     
/*      */     try
/*      */     {
/*  413 */       AST tmp6_AST = null;
/*  414 */       tmp6_AST = this.astFactory.create(LT(1));
/*  415 */       this.astFactory.makeASTRoot(currentAST, tmp6_AST);
/*  416 */       match(46);
/*  417 */       assignment();
/*  418 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*      */ 
/*      */ 
/*  422 */       while (LA(1) == 95) {
/*  423 */         match(95);
/*  424 */         assignment();
/*  425 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  434 */       setClause_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  437 */       reportError(ex);
/*  438 */       recover(ex, _tokenSet_2);
/*      */     }
/*  440 */     this.returnAST = setClause_AST;
/*      */   }
/*      */   
/*      */   public final void whereClause() throws RecognitionException, TokenStreamException
/*      */   {
/*  445 */     this.returnAST = null;
/*  446 */     ASTPair currentAST = new ASTPair();
/*  447 */     AST whereClause_AST = null;
/*      */     try
/*      */     {
/*  450 */       AST tmp8_AST = null;
/*  451 */       tmp8_AST = this.astFactory.create(LT(1));
/*  452 */       this.astFactory.makeASTRoot(currentAST, tmp8_AST);
/*  453 */       match(53);
/*  454 */       logicalExpression();
/*  455 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*  456 */       whereClause_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  459 */       reportError(ex);
/*  460 */       recover(ex, _tokenSet_3);
/*      */     }
/*  462 */     this.returnAST = whereClause_AST;
/*      */   }
/*      */   
/*      */   public final void assignment() throws RecognitionException, TokenStreamException
/*      */   {
/*  467 */     this.returnAST = null;
/*  468 */     ASTPair currentAST = new ASTPair();
/*  469 */     AST assignment_AST = null;
/*      */     try
/*      */     {
/*  472 */       stateField();
/*  473 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*  474 */       AST tmp9_AST = null;
/*  475 */       tmp9_AST = this.astFactory.create(LT(1));
/*  476 */       this.astFactory.makeASTRoot(currentAST, tmp9_AST);
/*  477 */       match(96);
/*  478 */       newValue();
/*  479 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*  480 */       assignment_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  483 */       reportError(ex);
/*  484 */       recover(ex, _tokenSet_4);
/*      */     }
/*  486 */     this.returnAST = assignment_AST;
/*      */   }
/*      */   
/*      */   public final void stateField() throws RecognitionException, TokenStreamException
/*      */   {
/*  491 */     this.returnAST = null;
/*  492 */     ASTPair currentAST = new ASTPair();
/*  493 */     AST stateField_AST = null;
/*      */     try
/*      */     {
/*  496 */       path();
/*  497 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*  498 */       stateField_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  501 */       reportError(ex);
/*  502 */       recover(ex, _tokenSet_5);
/*      */     }
/*  504 */     this.returnAST = stateField_AST;
/*      */   }
/*      */   
/*      */   public final void newValue() throws RecognitionException, TokenStreamException
/*      */   {
/*  509 */     this.returnAST = null;
/*  510 */     ASTPair currentAST = new ASTPair();
/*  511 */     AST newValue_AST = null;
/*      */     try
/*      */     {
/*  514 */       concatenation();
/*  515 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*  516 */       newValue_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  519 */       reportError(ex);
/*  520 */       recover(ex, _tokenSet_4);
/*      */     }
/*  522 */     this.returnAST = newValue_AST;
/*      */   }
/*      */   
/*      */   public final void path() throws RecognitionException, TokenStreamException
/*      */   {
/*  527 */     this.returnAST = null;
/*  528 */     ASTPair currentAST = new ASTPair();
/*  529 */     AST path_AST = null;
/*      */     try
/*      */     {
/*  532 */       identifier();
/*  533 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*      */ 
/*      */ 
/*  537 */       while (LA(1) == 15) {
/*  538 */         AST tmp10_AST = null;
/*  539 */         tmp10_AST = this.astFactory.create(LT(1));
/*  540 */         this.astFactory.makeASTRoot(currentAST, tmp10_AST);
/*  541 */         match(15);
/*  542 */         weakKeywords();
/*  543 */         identifier();
/*  544 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  552 */       path_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  555 */       reportError(ex);
/*  556 */       recover(ex, _tokenSet_6);
/*      */     }
/*  558 */     this.returnAST = path_AST;
/*      */   }
/*      */   
/*      */   public final void concatenation() throws RecognitionException, TokenStreamException
/*      */   {
/*  563 */     this.returnAST = null;
/*  564 */     ASTPair currentAST = new ASTPair();
/*  565 */     AST concatenation_AST = null;
/*  566 */     Token c = null;
/*  567 */     AST c_AST = null;
/*      */     try
/*      */     {
/*  570 */       additiveExpression();
/*  571 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*  573 */       switch (LA(1))
/*      */       {
/*      */       case 108: 
/*  576 */         c = LT(1);
/*  577 */         c_AST = this.astFactory.create(c);
/*  578 */         this.astFactory.makeASTRoot(currentAST, c_AST);
/*  579 */         match(108);
/*  580 */         c_AST.setType(72);c_AST.setText("concatList");
/*  581 */         additiveExpression();
/*  582 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */         
/*      */ 
/*      */ 
/*  586 */         while (LA(1) == 108) {
/*  587 */           match(108);
/*  588 */           additiveExpression();
/*  589 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  597 */         concatenation_AST = currentAST.root;
/*  598 */         concatenation_AST = this.astFactory.make(new ASTArray(3).add(this.astFactory.create(78, "||")).add(this.astFactory.make(new ASTArray(1).add(this.astFactory.create(119, "concat")))).add(c_AST));
/*  599 */         currentAST.root = concatenation_AST;
/*  600 */         currentAST.child = ((concatenation_AST != null) && (concatenation_AST.getFirstChild() != null) ? concatenation_AST.getFirstChild() : concatenation_AST);
/*      */         
/*  602 */         currentAST.advanceChildToEnd();
/*  603 */         break;
/*      */       case 1: case 6: case 7: case 8: case 10: case 14: case 18: case 22: case 23: case 24: case 25: case 26: case 28: case 31: case 32: case 33: case 34: case 38: case 40: case 41: case 44: case 50: case 53: case 57: case 64: case 95: case 96: case 98: case 100: case 101: case 102: case 103: case 104: case 105: case 106: case 107: case 114: 
/*      */         break;
/*      */       case 2: case 3: 
/*      */       case 4: case 5: 
/*      */       case 9: case 11: 
/*      */       case 12: case 13: 
/*      */       case 15: case 16: 
/*      */       case 17: case 19: 
/*      */       case 20: case 21: 
/*      */       case 27: case 29: 
/*      */       case 30: case 35: 
/*      */       case 36: case 37: 
/*      */       case 39: case 42: 
/*      */       case 43: case 45: 
/*      */       case 46: case 47: 
/*      */       case 48: case 49: 
/*      */       case 51: case 52: 
/*      */       case 54: case 55: 
/*      */       case 56: case 58: 
/*      */       case 59: case 60: 
/*      */       case 61: case 62: 
/*      */       case 63: case 65: 
/*      */       case 66: case 67: 
/*      */       case 68: case 69: 
/*      */       case 70: case 71: 
/*      */       case 72: case 73: 
/*      */       case 74: case 75: 
/*      */       case 76: case 77: 
/*      */       case 78: case 79: 
/*      */       case 80: case 81: 
/*      */       case 82: case 83: 
/*      */       case 84: case 85: 
/*      */       case 86: case 87: 
/*      */       case 88: case 89: 
/*      */       case 90: case 91: 
/*      */       case 92: case 93: 
/*      */       case 94: case 97: 
/*      */       case 99: case 109: 
/*      */       case 110: 
/*      */       case 111: 
/*      */       case 112: 
/*      */       case 113: 
/*      */       default: 
/*  647 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/*  651 */       concatenation_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  654 */       reportError(ex);
/*  655 */       recover(ex, _tokenSet_7);
/*      */     }
/*  657 */     this.returnAST = concatenation_AST;
/*      */   }
/*      */   
/*      */   public final void asAlias() throws RecognitionException, TokenStreamException
/*      */   {
/*  662 */     this.returnAST = null;
/*  663 */     ASTPair currentAST = new ASTPair();
/*  664 */     AST asAlias_AST = null;
/*      */     
/*      */     try
/*      */     {
/*  668 */       switch (LA(1))
/*      */       {
/*      */       case 7: 
/*  671 */         match(7);
/*  672 */         break;
/*      */       
/*      */ 
/*      */       case 119: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  680 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/*  684 */       alias();
/*  685 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*  686 */       asAlias_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  689 */       reportError(ex);
/*  690 */       recover(ex, _tokenSet_8);
/*      */     }
/*  692 */     this.returnAST = asAlias_AST;
/*      */   }
/*      */   
/*      */   public final void queryRule() throws RecognitionException, TokenStreamException
/*      */   {
/*  697 */     this.returnAST = null;
/*  698 */     ASTPair currentAST = new ASTPair();
/*  699 */     AST queryRule_AST = null;
/*      */     try
/*      */     {
/*  702 */       selectFrom();
/*  703 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*  705 */       switch (LA(1))
/*      */       {
/*      */       case 53: 
/*  708 */         whereClause();
/*  709 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*  710 */         break;
/*      */       
/*      */ 
/*      */       case 1: 
/*      */       case 24: 
/*      */       case 41: 
/*      */       case 50: 
/*      */       case 98: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  722 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/*      */ 
/*  727 */       switch (LA(1))
/*      */       {
/*      */       case 24: 
/*  730 */         groupByClause();
/*  731 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*  732 */         break;
/*      */       
/*      */ 
/*      */       case 1: 
/*      */       case 41: 
/*      */       case 50: 
/*      */       case 98: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  743 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/*      */ 
/*  748 */       switch (LA(1))
/*      */       {
/*      */       case 41: 
/*  751 */         orderByClause();
/*  752 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*  753 */         break;
/*      */       
/*      */ 
/*      */       case 1: 
/*      */       case 50: 
/*      */       case 98: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  763 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/*  767 */       queryRule_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  770 */       reportError(ex);
/*  771 */       recover(ex, _tokenSet_9);
/*      */     }
/*  773 */     this.returnAST = queryRule_AST;
/*      */   }
/*      */   
/*      */   public final void intoClause() throws RecognitionException, TokenStreamException
/*      */   {
/*  778 */     this.returnAST = null;
/*  779 */     ASTPair currentAST = new ASTPair();
/*  780 */     AST intoClause_AST = null;
/*      */     try
/*      */     {
/*  783 */       AST tmp13_AST = null;
/*  784 */       tmp13_AST = this.astFactory.create(LT(1));
/*  785 */       this.astFactory.makeASTRoot(currentAST, tmp13_AST);
/*  786 */       match(30);
/*  787 */       path();
/*  788 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*  789 */       weakKeywords();
/*  790 */       insertablePropertySpec();
/*  791 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*  792 */       intoClause_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  795 */       reportError(ex);
/*  796 */       recover(ex, _tokenSet_10);
/*      */     }
/*  798 */     this.returnAST = intoClause_AST;
/*      */   }
/*      */   
/*      */   public final void insertablePropertySpec() throws RecognitionException, TokenStreamException
/*      */   {
/*  803 */     this.returnAST = null;
/*  804 */     ASTPair currentAST = new ASTPair();
/*  805 */     AST insertablePropertySpec_AST = null;
/*      */     try
/*      */     {
/*  808 */       match(97);
/*  809 */       primaryExpression();
/*  810 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*      */ 
/*      */ 
/*  814 */       while (LA(1) == 95) {
/*  815 */         match(95);
/*  816 */         primaryExpression();
/*  817 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  825 */       match(98);
/*  826 */       insertablePropertySpec_AST = currentAST.root;
/*      */       
/*      */ 
/*  829 */       insertablePropertySpec_AST = this.astFactory.make(new ASTArray(2).add(this.astFactory.create(84, "column-spec")).add(insertablePropertySpec_AST));
/*      */       
/*  831 */       currentAST.root = insertablePropertySpec_AST;
/*  832 */       currentAST.child = ((insertablePropertySpec_AST != null) && (insertablePropertySpec_AST.getFirstChild() != null) ? insertablePropertySpec_AST.getFirstChild() : insertablePropertySpec_AST);
/*      */       
/*  834 */       currentAST.advanceChildToEnd();
/*  835 */       insertablePropertySpec_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  838 */       reportError(ex);
/*  839 */       recover(ex, _tokenSet_10);
/*      */     }
/*  841 */     this.returnAST = insertablePropertySpec_AST;
/*      */   }
/*      */   
/*      */   public final void primaryExpression() throws RecognitionException, TokenStreamException
/*      */   {
/*  846 */     this.returnAST = null;
/*  847 */     ASTPair currentAST = new ASTPair();
/*  848 */     AST primaryExpression_AST = null;
/*      */     try
/*      */     {
/*  851 */       switch (LA(1))
/*      */       {
/*      */       case 9: 
/*      */       case 12: 
/*      */       case 17: 
/*      */       case 27: 
/*      */       case 35: 
/*      */       case 36: 
/*      */       case 48: 
/*      */       case 119: 
/*  861 */         identPrimary();
/*  862 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */         
/*  864 */         if ((LA(1) == 15) && (LA(2) == 11)) {
/*  865 */           AST tmp17_AST = null;
/*  866 */           tmp17_AST = this.astFactory.create(LT(1));
/*  867 */           this.astFactory.makeASTRoot(currentAST, tmp17_AST);
/*  868 */           match(15);
/*  869 */           AST tmp18_AST = null;
/*  870 */           tmp18_AST = this.astFactory.create(LT(1));
/*  871 */           this.astFactory.addASTChild(currentAST, tmp18_AST);
/*  872 */           match(11);
/*      */         }
/*  874 */         else if ((!_tokenSet_11.member(LA(1))) || (!_tokenSet_12.member(LA(2))))
/*      */         {
/*      */ 
/*  877 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         }
/*      */         
/*      */ 
/*  881 */         primaryExpression_AST = currentAST.root;
/*  882 */         break;
/*      */       
/*      */ 
/*      */       case 20: 
/*      */       case 39: 
/*      */       case 49: 
/*      */       case 62: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 117: 
/*      */       case 118: 
/*  894 */         constant();
/*  895 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*  896 */         primaryExpression_AST = currentAST.root;
/*  897 */         break;
/*      */       
/*      */ 
/*      */       case 115: 
/*  901 */         AST tmp19_AST = null;
/*  902 */         tmp19_AST = this.astFactory.create(LT(1));
/*  903 */         this.astFactory.makeASTRoot(currentAST, tmp19_AST);
/*  904 */         match(115);
/*  905 */         identifier();
/*  906 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*  907 */         primaryExpression_AST = currentAST.root;
/*  908 */         break;
/*      */       
/*      */ 
/*      */       case 97: 
/*  912 */         match(97);
/*      */         
/*  914 */         switch (LA(1))
/*      */         {
/*      */         case 4: 
/*      */         case 5: 
/*      */         case 9: 
/*      */         case 12: 
/*      */         case 17: 
/*      */         case 19: 
/*      */         case 20: 
/*      */         case 27: 
/*      */         case 35: 
/*      */         case 36: 
/*      */         case 38: 
/*      */         case 39: 
/*      */         case 47: 
/*      */         case 48: 
/*      */         case 49: 
/*      */         case 54: 
/*      */         case 62: 
/*      */         case 92: 
/*      */         case 93: 
/*      */         case 94: 
/*      */         case 97: 
/*      */         case 109: 
/*      */         case 110: 
/*      */         case 115: 
/*      */         case 116: 
/*      */         case 117: 
/*      */         case 118: 
/*      */         case 119: 
/*  944 */           expressionOrVector();
/*  945 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/*  946 */           break;
/*      */         
/*      */ 
/*      */         case 22: 
/*      */         case 24: 
/*      */         case 41: 
/*      */         case 45: 
/*      */         case 50: 
/*      */         case 53: 
/*      */         case 98: 
/*  956 */           subQuery();
/*  957 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/*  958 */           break;
/*      */         case 6: case 7: case 8: case 10: case 11: case 13: case 14: case 15: case 16: case 18: case 21: case 23: case 25: case 26: case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 37: case 40: case 42: case 43: case 44: case 46: case 51: 
/*      */         case 52: case 55: case 56: case 57: case 58: case 59: case 60: case 61: case 63: case 64: case 65: case 66: case 67: case 68: case 69: case 70: case 71: case 72: case 73: case 74: case 75: case 76: case 77: case 78: case 79: case 80: case 81: 
/*      */         case 82: case 83: case 84: case 85: case 86: case 87: case 88: case 89: case 90: case 91: case 95: case 96: case 99: case 100: case 101: case 102: case 103: case 104: case 105: case 106: case 107: case 108: case 111: case 112: case 113: case 114: default: 
/*  962 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         }
/*      */         
/*      */         
/*  966 */         match(98);
/*  967 */         primaryExpression_AST = currentAST.root;
/*  968 */         break;
/*      */       
/*      */ 
/*      */       case 116: 
/*  972 */         AST tmp22_AST = null;
/*  973 */         tmp22_AST = this.astFactory.create(LT(1));
/*  974 */         this.astFactory.makeASTRoot(currentAST, tmp22_AST);
/*  975 */         match(116);
/*      */         
/*  977 */         switch (LA(1))
/*      */         {
/*      */         case 117: 
/*  980 */           AST tmp23_AST = null;
/*  981 */           tmp23_AST = this.astFactory.create(LT(1));
/*  982 */           this.astFactory.addASTChild(currentAST, tmp23_AST);
/*  983 */           match(117);
/*  984 */           break;
/*      */         case 1: case 6: case 7: case 8: 
/*      */         case 10: case 14: case 15: case 18: 
/*      */         case 22: case 23: case 24: 
/*      */         case 25: case 26: case 28: 
/*      */         case 31: case 32: case 33: 
/*      */         case 34: case 38: case 40: 
/*      */         case 41: case 44: case 50: 
/*      */         case 53: case 55: case 56: 
/*      */         case 57: case 58: case 64: 
/*      */         case 95: case 96: case 98: 
/*      */         case 100: case 101: case 102: 
/*      */         case 103: case 104: case 105: 
/*      */         case 106: case 107: case 108: 
/*      */         case 109: case 110: case 111: 
/*      */         case 112: case 113: case 114: 
/*      */           break;
/*      */         case 2: case 3: 
/*      */         case 4: case 5: 
/*      */         case 9: case 11: 
/*      */         case 12: case 13: 
/*      */         case 16: case 17: 
/*      */         case 19: case 20: 
/*      */         case 21: case 27: 
/*      */         case 29: case 30: 
/*      */         case 35: case 36: 
/*      */         case 37: case 39: 
/*      */         case 42: case 43: 
/*      */         case 45: case 46: 
/*      */         case 47: case 48: 
/*      */         case 49: case 51: 
/*      */         case 52: case 54: 
/*      */         case 59: case 60: 
/*      */         case 61: case 62: 
/*      */         case 63: case 65: 
/*      */         case 66: case 67: 
/*      */         case 68: case 69: 
/*      */         case 70: case 71: 
/*      */         case 72: case 73: 
/*      */         case 74: case 75: 
/*      */         case 76: case 77: 
/*      */         case 78: case 79: 
/*      */         case 80: case 81: 
/*      */         case 82: case 83: 
/*      */         case 84: case 85: 
/*      */         case 86: case 87: 
/*      */         case 88: case 89: 
/*      */         case 90: case 91: 
/*      */         case 92: case 93: 
/*      */         case 94: case 97: 
/*      */         case 99: 
/*      */         case 115: 
/*      */         case 116: 
/*      */         default: 
/* 1038 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         }
/*      */         
/*      */         
/* 1042 */         primaryExpression_AST = currentAST.root;
/* 1043 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 1047 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 1052 */       reportError(ex);
/* 1053 */       recover(ex, _tokenSet_11);
/*      */     }
/* 1055 */     this.returnAST = primaryExpression_AST;
/*      */   }
/*      */   
/*      */   public final void union() throws RecognitionException, TokenStreamException
/*      */   {
/* 1060 */     this.returnAST = null;
/* 1061 */     ASTPair currentAST = new ASTPair();
/* 1062 */     AST union_AST = null;
/*      */     try
/*      */     {
/* 1065 */       queryRule();
/* 1066 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*      */ 
/*      */ 
/* 1070 */       while (LA(1) == 50) {
/* 1071 */         AST tmp24_AST = null;
/* 1072 */         tmp24_AST = this.astFactory.create(LT(1));
/* 1073 */         this.astFactory.addASTChild(currentAST, tmp24_AST);
/* 1074 */         match(50);
/* 1075 */         queryRule();
/* 1076 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1084 */       union_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1087 */       reportError(ex);
/* 1088 */       recover(ex, _tokenSet_13);
/*      */     }
/* 1090 */     this.returnAST = union_AST;
/*      */   }
/*      */   
/*      */   public final void selectFrom() throws RecognitionException, TokenStreamException
/*      */   {
/* 1095 */     this.returnAST = null;
/* 1096 */     ASTPair currentAST = new ASTPair();
/* 1097 */     AST selectFrom_AST = null;
/* 1098 */     AST s_AST = null;
/* 1099 */     AST f_AST = null;
/*      */     
/*      */     try
/*      */     {
/* 1103 */       switch (LA(1))
/*      */       {
/*      */       case 45: 
/* 1106 */         selectClause();
/* 1107 */         s_AST = this.returnAST;
/* 1108 */         break;
/*      */       
/*      */ 
/*      */       case 1: 
/*      */       case 22: 
/*      */       case 24: 
/*      */       case 41: 
/*      */       case 50: 
/*      */       case 53: 
/*      */       case 98: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 1122 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/*      */ 
/* 1127 */       switch (LA(1))
/*      */       {
/*      */       case 22: 
/* 1130 */         fromClause();
/* 1131 */         f_AST = this.returnAST;
/* 1132 */         break;
/*      */       
/*      */ 
/*      */       case 1: 
/*      */       case 24: 
/*      */       case 41: 
/*      */       case 50: 
/*      */       case 53: 
/*      */       case 98: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 1145 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/* 1149 */       selectFrom_AST = currentAST.root;
/*      */       
/*      */ 
/*      */ 
/* 1153 */       if (f_AST == null) {
/* 1154 */         if (this.filter) {
/* 1155 */           f_AST = this.astFactory.make(new ASTArray(1).add(this.astFactory.create(22, "{filter-implied FROM}")));
/*      */         }
/*      */         else {
/* 1158 */           throw new SemanticException("FROM expected (non-filter queries must contain a FROM clause)");
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1164 */       selectFrom_AST = this.astFactory.make(new ASTArray(3).add(this.astFactory.create(86, "SELECT_FROM")).add(f_AST).add(s_AST));
/*      */       
/* 1166 */       currentAST.root = selectFrom_AST;
/* 1167 */       currentAST.child = ((selectFrom_AST != null) && (selectFrom_AST.getFirstChild() != null) ? selectFrom_AST.getFirstChild() : selectFrom_AST);
/*      */       
/* 1169 */       currentAST.advanceChildToEnd();
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1172 */       reportError(ex);
/* 1173 */       recover(ex, _tokenSet_14);
/*      */     }
/* 1175 */     this.returnAST = selectFrom_AST;
/*      */   }
/*      */   
/*      */   public final void groupByClause() throws RecognitionException, TokenStreamException
/*      */   {
/* 1180 */     this.returnAST = null;
/* 1181 */     ASTPair currentAST = new ASTPair();
/* 1182 */     AST groupByClause_AST = null;
/*      */     try
/*      */     {
/* 1185 */       AST tmp25_AST = null;
/* 1186 */       tmp25_AST = this.astFactory.create(LT(1));
/* 1187 */       this.astFactory.makeASTRoot(currentAST, tmp25_AST);
/* 1188 */       match(24);
/* 1189 */       match(99);
/* 1190 */       expression();
/* 1191 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*      */ 
/*      */ 
/* 1195 */       while (LA(1) == 95) {
/* 1196 */         match(95);
/* 1197 */         expression();
/* 1198 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1207 */       switch (LA(1))
/*      */       {
/*      */       case 25: 
/* 1210 */         havingClause();
/* 1211 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1212 */         break;
/*      */       
/*      */ 
/*      */       case 1: 
/*      */       case 41: 
/*      */       case 50: 
/*      */       case 98: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 1223 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/* 1227 */       groupByClause_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1230 */       reportError(ex);
/* 1231 */       recover(ex, _tokenSet_15);
/*      */     }
/* 1233 */     this.returnAST = groupByClause_AST;
/*      */   }
/*      */   
/*      */   public final void orderByClause() throws RecognitionException, TokenStreamException
/*      */   {
/* 1238 */     this.returnAST = null;
/* 1239 */     ASTPair currentAST = new ASTPair();
/* 1240 */     AST orderByClause_AST = null;
/*      */     try
/*      */     {
/* 1243 */       AST tmp28_AST = null;
/* 1244 */       tmp28_AST = this.astFactory.create(LT(1));
/* 1245 */       this.astFactory.makeASTRoot(currentAST, tmp28_AST);
/* 1246 */       match(41);
/* 1247 */       match(99);
/* 1248 */       orderElement();
/* 1249 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*      */ 
/*      */ 
/* 1253 */       while (LA(1) == 95) {
/* 1254 */         match(95);
/* 1255 */         orderElement();
/* 1256 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1264 */       orderByClause_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1267 */       reportError(ex);
/* 1268 */       recover(ex, _tokenSet_9);
/*      */     }
/* 1270 */     this.returnAST = orderByClause_AST;
/*      */   }
/*      */   
/*      */   public final void selectClause() throws RecognitionException, TokenStreamException
/*      */   {
/* 1275 */     this.returnAST = null;
/* 1276 */     ASTPair currentAST = new ASTPair();
/* 1277 */     AST selectClause_AST = null;
/*      */     try
/*      */     {
/* 1280 */       AST tmp31_AST = null;
/* 1281 */       tmp31_AST = this.astFactory.create(LT(1));
/* 1282 */       this.astFactory.makeASTRoot(currentAST, tmp31_AST);
/* 1283 */       match(45);
/* 1284 */       weakKeywords();
/*      */       
/* 1286 */       switch (LA(1))
/*      */       {
/*      */       case 16: 
/* 1289 */         AST tmp32_AST = null;
/* 1290 */         tmp32_AST = this.astFactory.create(LT(1));
/* 1291 */         this.astFactory.addASTChild(currentAST, tmp32_AST);
/* 1292 */         match(16);
/* 1293 */         break;
/*      */       case 4: case 5: case 9: case 12: case 17: case 19: case 20: case 27: case 35: case 36: case 37: case 38: case 39: case 47: case 48: case 49: case 54: case 62: case 65: case 92: case 93: case 94: case 97: case 109: case 110: case 115: case 116: case 117: case 118: case 119: 
/*      */         break;
/*      */       case 6: case 7: case 8: 
/*      */       case 10: case 11: case 13: 
/*      */       case 14: case 15: case 18: 
/*      */       case 21: case 22: case 23: 
/*      */       case 24: case 25: case 26: 
/*      */       case 28: case 29: case 30: 
/*      */       case 31: case 32: case 33: 
/*      */       case 34: case 40: case 41: 
/*      */       case 42: case 43: case 44: 
/*      */       case 45: case 46: case 50: 
/*      */       case 51: case 52: case 53: 
/*      */       case 55: case 56: case 57: 
/*      */       case 58: case 59: case 60: 
/*      */       case 61: case 63: case 64: 
/*      */       case 66: case 67: case 68: 
/*      */       case 69: case 70: case 71: 
/*      */       case 72: case 73: case 74: 
/*      */       case 75: case 76: case 77: 
/*      */       case 78: case 79: 
/*      */       case 80: case 81: 
/*      */       case 82: case 83: 
/*      */       case 84: case 85: 
/*      */       case 86: case 87: 
/*      */       case 88: case 89: 
/*      */       case 90: case 91: 
/*      */       case 95: case 96: 
/*      */       case 98: case 99: 
/*      */       case 100: case 101: 
/*      */       case 102: case 103: 
/*      */       case 104: case 105: 
/*      */       case 106: case 107: 
/*      */       case 108: case 111: 
/*      */       case 112: case 113: 
/*      */       case 114: default: 
/* 1330 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/*      */ 
/* 1335 */       switch (LA(1))
/*      */       {
/*      */       case 4: 
/*      */       case 5: 
/*      */       case 9: 
/*      */       case 12: 
/*      */       case 17: 
/*      */       case 19: 
/*      */       case 20: 
/*      */       case 27: 
/*      */       case 35: 
/*      */       case 36: 
/*      */       case 38: 
/*      */       case 39: 
/*      */       case 47: 
/*      */       case 48: 
/*      */       case 49: 
/*      */       case 54: 
/*      */       case 62: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 97: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 115: 
/*      */       case 116: 
/*      */       case 117: 
/*      */       case 118: 
/*      */       case 119: 
/* 1365 */         selectedPropertiesList();
/* 1366 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1367 */         break;
/*      */       
/*      */ 
/*      */       case 37: 
/* 1371 */         newExpression();
/* 1372 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1373 */         break;
/*      */       
/*      */ 
/*      */       case 65: 
/* 1377 */         selectObject();
/* 1378 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1379 */         break;
/*      */       case 6: case 7: case 8: case 10: case 11: case 13: case 14: case 15: case 16: case 18: case 21: case 22: case 23: case 24: case 25: case 26: case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 40: case 41: case 42: case 43: case 44: case 45: 
/*      */       case 46: case 50: case 51: case 52: case 53: case 55: case 56: case 57: case 58: case 59: case 60: case 61: case 63: case 64: case 66: case 67: case 68: case 69: case 70: case 71: case 72: case 73: case 74: case 75: case 76: case 77: case 78: case 79: case 80: 
/*      */       case 81: case 82: case 83: case 84: case 85: case 86: case 87: case 88: case 89: case 90: case 91: case 95: case 96: case 98: case 99: case 100: case 101: case 102: case 103: case 104: case 105: case 106: case 107: case 108: case 111: case 112: case 113: case 114: default: 
/* 1383 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/* 1387 */       selectClause_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1390 */       reportError(ex);
/* 1391 */       recover(ex, _tokenSet_16);
/*      */     }
/* 1393 */     this.returnAST = selectClause_AST;
/*      */   }
/*      */   
/*      */   public final void fromClause() throws RecognitionException, TokenStreamException
/*      */   {
/* 1398 */     this.returnAST = null;
/* 1399 */     ASTPair currentAST = new ASTPair();
/* 1400 */     AST fromClause_AST = null;
/*      */     try
/*      */     {
/* 1403 */       AST tmp33_AST = null;
/* 1404 */       tmp33_AST = this.astFactory.create(LT(1));
/* 1405 */       this.astFactory.makeASTRoot(currentAST, tmp33_AST);
/* 1406 */       match(22);
/* 1407 */       weakKeywords();
/* 1408 */       fromRange();
/* 1409 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*      */       for (;;)
/*      */       {
/* 1413 */         switch (LA(1))
/*      */         {
/*      */         case 23: 
/*      */         case 28: 
/*      */         case 32: 
/*      */         case 33: 
/*      */         case 44: 
/* 1420 */           fromJoin();
/* 1421 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1422 */           break;
/*      */         
/*      */ 
/*      */         case 95: 
/* 1426 */           match(95);
/* 1427 */           weakKeywords();
/* 1428 */           fromRange();
/* 1429 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1439 */       fromClause_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1442 */       reportError(ex);
/* 1443 */       recover(ex, _tokenSet_14);
/*      */     }
/* 1445 */     this.returnAST = fromClause_AST;
/*      */   }
/*      */   
/*      */   public final void selectedPropertiesList() throws RecognitionException, TokenStreamException
/*      */   {
/* 1450 */     this.returnAST = null;
/* 1451 */     ASTPair currentAST = new ASTPair();
/* 1452 */     AST selectedPropertiesList_AST = null;
/*      */     try
/*      */     {
/* 1455 */       aliasedExpression();
/* 1456 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*      */ 
/*      */ 
/* 1460 */       while (LA(1) == 95) {
/* 1461 */         match(95);
/* 1462 */         aliasedExpression();
/* 1463 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1471 */       selectedPropertiesList_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1474 */       reportError(ex);
/* 1475 */       recover(ex, _tokenSet_16);
/*      */     }
/* 1477 */     this.returnAST = selectedPropertiesList_AST;
/*      */   }
/*      */   
/*      */   public final void newExpression() throws RecognitionException, TokenStreamException
/*      */   {
/* 1482 */     this.returnAST = null;
/* 1483 */     ASTPair currentAST = new ASTPair();
/* 1484 */     AST newExpression_AST = null;
/* 1485 */     Token op = null;
/* 1486 */     AST op_AST = null;
/*      */     
/*      */     try
/*      */     {
/* 1490 */       match(37);
/* 1491 */       path();
/* 1492 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/* 1494 */       op = LT(1);
/* 1495 */       op_AST = this.astFactory.create(op);
/* 1496 */       this.astFactory.makeASTRoot(currentAST, op_AST);
/* 1497 */       match(97);
/* 1498 */       op_AST.setType(70);
/* 1499 */       selectedPropertiesList();
/* 1500 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1501 */       match(98);
/* 1502 */       newExpression_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1505 */       reportError(ex);
/* 1506 */       recover(ex, _tokenSet_16);
/*      */     }
/* 1508 */     this.returnAST = newExpression_AST;
/*      */   }
/*      */   
/*      */   public final void selectObject() throws RecognitionException, TokenStreamException
/*      */   {
/* 1513 */     this.returnAST = null;
/* 1514 */     ASTPair currentAST = new ASTPair();
/* 1515 */     AST selectObject_AST = null;
/*      */     try
/*      */     {
/* 1518 */       AST tmp38_AST = null;
/* 1519 */       tmp38_AST = this.astFactory.create(LT(1));
/* 1520 */       this.astFactory.makeASTRoot(currentAST, tmp38_AST);
/* 1521 */       match(65);
/* 1522 */       match(97);
/* 1523 */       identifier();
/* 1524 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1525 */       match(98);
/* 1526 */       selectObject_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1529 */       reportError(ex);
/* 1530 */       recover(ex, _tokenSet_16);
/*      */     }
/* 1532 */     this.returnAST = selectObject_AST;
/*      */   }
/*      */   
/*      */   public final void identifier() throws RecognitionException, TokenStreamException
/*      */   {
/* 1537 */     this.returnAST = null;
/* 1538 */     ASTPair currentAST = new ASTPair();
/* 1539 */     AST identifier_AST = null;
/*      */     try
/*      */     {
/* 1542 */       AST tmp41_AST = null;
/* 1543 */       tmp41_AST = this.astFactory.create(LT(1));
/* 1544 */       this.astFactory.addASTChild(currentAST, tmp41_AST);
/* 1545 */       match(119);
/* 1546 */       identifier_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 1550 */       identifier_AST = handleIdentifierError(LT(1), ex);
/*      */     }
/*      */     
/* 1553 */     this.returnAST = identifier_AST;
/*      */   }
/*      */   
/*      */   public final void fromRange() throws RecognitionException, TokenStreamException
/*      */   {
/* 1558 */     this.returnAST = null;
/* 1559 */     ASTPair currentAST = new ASTPair();
/* 1560 */     AST fromRange_AST = null;
/*      */     try
/*      */     {
/* 1563 */       if ((LA(1) == 119) && (_tokenSet_17.member(LA(2)))) {
/* 1564 */         fromClassOrOuterQueryPath();
/* 1565 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1566 */         fromRange_AST = currentAST.root;
/*      */       }
/* 1568 */       else if ((LA(1) == 119) && (LA(2) == 26) && (LA(3) == 11)) {
/* 1569 */         inClassDeclaration();
/* 1570 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1571 */         fromRange_AST = currentAST.root;
/*      */       }
/* 1573 */       else if (LA(1) == 26) {
/* 1574 */         inCollectionDeclaration();
/* 1575 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1576 */         fromRange_AST = currentAST.root;
/*      */       }
/* 1578 */       else if ((LA(1) == 119) && (LA(2) == 26) && (LA(3) == 17)) {
/* 1579 */         inCollectionElementsDeclaration();
/* 1580 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1581 */         fromRange_AST = currentAST.root;
/*      */       }
/*      */       else {
/* 1584 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 1589 */       reportError(ex);
/* 1590 */       recover(ex, _tokenSet_18);
/*      */     }
/* 1592 */     this.returnAST = fromRange_AST;
/*      */   }
/*      */   
/*      */   public final void fromJoin() throws RecognitionException, TokenStreamException
/*      */   {
/* 1597 */     this.returnAST = null;
/* 1598 */     ASTPair currentAST = new ASTPair();
/* 1599 */     AST fromJoin_AST = null;
/*      */     
/*      */     try
/*      */     {
/* 1603 */       switch (LA(1))
/*      */       {
/*      */ 
/*      */ 
/*      */       case 33: 
/*      */       case 44: 
/* 1609 */         switch (LA(1))
/*      */         {
/*      */         case 33: 
/* 1612 */           AST tmp42_AST = null;
/* 1613 */           tmp42_AST = this.astFactory.create(LT(1));
/* 1614 */           this.astFactory.addASTChild(currentAST, tmp42_AST);
/* 1615 */           match(33);
/* 1616 */           break;
/*      */         
/*      */ 
/*      */         case 44: 
/* 1620 */           AST tmp43_AST = null;
/* 1621 */           tmp43_AST = this.astFactory.create(LT(1));
/* 1622 */           this.astFactory.addASTChild(currentAST, tmp43_AST);
/* 1623 */           match(44);
/* 1624 */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 1628 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         }
/*      */         
/*      */         
/*      */ 
/* 1633 */         switch (LA(1))
/*      */         {
/*      */         case 42: 
/* 1636 */           AST tmp44_AST = null;
/* 1637 */           tmp44_AST = this.astFactory.create(LT(1));
/* 1638 */           this.astFactory.addASTChild(currentAST, tmp44_AST);
/* 1639 */           match(42);
/* 1640 */           break;
/*      */         
/*      */ 
/*      */         case 32: 
/*      */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 1648 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         }
/*      */         
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */         break;
/*      */       case 23: 
/* 1657 */         AST tmp45_AST = null;
/* 1658 */         tmp45_AST = this.astFactory.create(LT(1));
/* 1659 */         this.astFactory.addASTChild(currentAST, tmp45_AST);
/* 1660 */         match(23);
/* 1661 */         break;
/*      */       
/*      */ 
/*      */       case 28: 
/* 1665 */         AST tmp46_AST = null;
/* 1666 */         tmp46_AST = this.astFactory.create(LT(1));
/* 1667 */         this.astFactory.addASTChild(currentAST, tmp46_AST);
/* 1668 */         match(28);
/* 1669 */         break;
/*      */       
/*      */ 
/*      */       case 32: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 1677 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/* 1681 */       AST tmp47_AST = null;
/* 1682 */       tmp47_AST = this.astFactory.create(LT(1));
/* 1683 */       this.astFactory.makeASTRoot(currentAST, tmp47_AST);
/* 1684 */       match(32);
/*      */       
/* 1686 */       switch (LA(1))
/*      */       {
/*      */       case 21: 
/* 1689 */         AST tmp48_AST = null;
/* 1690 */         tmp48_AST = this.astFactory.create(LT(1));
/* 1691 */         this.astFactory.addASTChild(currentAST, tmp48_AST);
/* 1692 */         match(21);
/* 1693 */         break;
/*      */       
/*      */ 
/*      */       case 119: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 1701 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/* 1705 */       path();
/* 1706 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/* 1708 */       switch (LA(1))
/*      */       {
/*      */       case 7: 
/*      */       case 119: 
/* 1712 */         asAlias();
/* 1713 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1714 */         break;
/*      */       
/*      */ 
/*      */       case 1: 
/*      */       case 21: 
/*      */       case 23: 
/*      */       case 24: 
/*      */       case 28: 
/*      */       case 32: 
/*      */       case 33: 
/*      */       case 41: 
/*      */       case 44: 
/*      */       case 50: 
/*      */       case 53: 
/*      */       case 60: 
/*      */       case 95: 
/*      */       case 98: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 1735 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/*      */ 
/* 1740 */       switch (LA(1))
/*      */       {
/*      */       case 21: 
/* 1743 */         propertyFetch();
/* 1744 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1745 */         break;
/*      */       
/*      */ 
/*      */       case 1: 
/*      */       case 23: 
/*      */       case 24: 
/*      */       case 28: 
/*      */       case 32: 
/*      */       case 33: 
/*      */       case 41: 
/*      */       case 44: 
/*      */       case 50: 
/*      */       case 53: 
/*      */       case 60: 
/*      */       case 95: 
/*      */       case 98: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 1765 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/*      */ 
/* 1770 */       switch (LA(1))
/*      */       {
/*      */       case 60: 
/* 1773 */         withClause();
/* 1774 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1775 */         break;
/*      */       
/*      */ 
/*      */       case 1: 
/*      */       case 23: 
/*      */       case 24: 
/*      */       case 28: 
/*      */       case 32: 
/*      */       case 33: 
/*      */       case 41: 
/*      */       case 44: 
/*      */       case 50: 
/*      */       case 53: 
/*      */       case 95: 
/*      */       case 98: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 1794 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/* 1798 */       fromJoin_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1801 */       reportError(ex);
/* 1802 */       recover(ex, _tokenSet_18);
/*      */     }
/* 1804 */     this.returnAST = fromJoin_AST;
/*      */   }
/*      */   
/*      */   public final void propertyFetch() throws RecognitionException, TokenStreamException
/*      */   {
/* 1809 */     this.returnAST = null;
/* 1810 */     ASTPair currentAST = new ASTPair();
/* 1811 */     AST propertyFetch_AST = null;
/*      */     try
/*      */     {
/* 1814 */       AST tmp49_AST = null;
/* 1815 */       tmp49_AST = this.astFactory.create(LT(1));
/* 1816 */       this.astFactory.addASTChild(currentAST, tmp49_AST);
/* 1817 */       match(21);
/* 1818 */       match(4);
/* 1819 */       match(43);
/* 1820 */       propertyFetch_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1823 */       reportError(ex);
/* 1824 */       recover(ex, _tokenSet_19);
/*      */     }
/* 1826 */     this.returnAST = propertyFetch_AST;
/*      */   }
/*      */   
/*      */   public final void withClause() throws RecognitionException, TokenStreamException
/*      */   {
/* 1831 */     this.returnAST = null;
/* 1832 */     ASTPair currentAST = new ASTPair();
/* 1833 */     AST withClause_AST = null;
/*      */     try
/*      */     {
/* 1836 */       AST tmp52_AST = null;
/* 1837 */       tmp52_AST = this.astFactory.create(LT(1));
/* 1838 */       this.astFactory.makeASTRoot(currentAST, tmp52_AST);
/* 1839 */       match(60);
/* 1840 */       logicalExpression();
/* 1841 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1842 */       withClause_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1845 */       reportError(ex);
/* 1846 */       recover(ex, _tokenSet_18);
/*      */     }
/* 1848 */     this.returnAST = withClause_AST;
/*      */   }
/*      */   
/*      */   public final void logicalExpression() throws RecognitionException, TokenStreamException
/*      */   {
/* 1853 */     this.returnAST = null;
/* 1854 */     ASTPair currentAST = new ASTPair();
/* 1855 */     AST logicalExpression_AST = null;
/*      */     try
/*      */     {
/* 1858 */       expression();
/* 1859 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1860 */       logicalExpression_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1863 */       reportError(ex);
/* 1864 */       recover(ex, _tokenSet_20);
/*      */     }
/* 1866 */     this.returnAST = logicalExpression_AST;
/*      */   }
/*      */   
/*      */   public final void fromClassOrOuterQueryPath() throws RecognitionException, TokenStreamException
/*      */   {
/* 1871 */     this.returnAST = null;
/* 1872 */     ASTPair currentAST = new ASTPair();
/* 1873 */     AST fromClassOrOuterQueryPath_AST = null;
/* 1874 */     AST c_AST = null;
/* 1875 */     AST a_AST = null;
/* 1876 */     AST p_AST = null;
/*      */     try
/*      */     {
/* 1879 */       path();
/* 1880 */       c_AST = this.returnAST;
/* 1881 */       weakKeywords();
/*      */       
/* 1883 */       switch (LA(1))
/*      */       {
/*      */       case 7: 
/*      */       case 119: 
/* 1887 */         asAlias();
/* 1888 */         a_AST = this.returnAST;
/* 1889 */         break;
/*      */       
/*      */ 
/*      */       case 1: 
/*      */       case 21: 
/*      */       case 23: 
/*      */       case 24: 
/*      */       case 28: 
/*      */       case 32: 
/*      */       case 33: 
/*      */       case 41: 
/*      */       case 44: 
/*      */       case 50: 
/*      */       case 53: 
/*      */       case 95: 
/*      */       case 98: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 1909 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/*      */ 
/* 1914 */       switch (LA(1))
/*      */       {
/*      */       case 21: 
/* 1917 */         propertyFetch();
/* 1918 */         p_AST = this.returnAST;
/* 1919 */         break;
/*      */       
/*      */ 
/*      */       case 1: 
/*      */       case 23: 
/*      */       case 24: 
/*      */       case 28: 
/*      */       case 32: 
/*      */       case 33: 
/*      */       case 41: 
/*      */       case 44: 
/*      */       case 50: 
/*      */       case 53: 
/*      */       case 95: 
/*      */       case 98: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 1938 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/* 1942 */       fromClassOrOuterQueryPath_AST = currentAST.root;
/*      */       
/* 1944 */       fromClassOrOuterQueryPath_AST = this.astFactory.make(new ASTArray(4).add(this.astFactory.create(84, "RANGE")).add(c_AST).add(a_AST).add(p_AST));
/*      */       
/* 1946 */       currentAST.root = fromClassOrOuterQueryPath_AST;
/* 1947 */       currentAST.child = ((fromClassOrOuterQueryPath_AST != null) && (fromClassOrOuterQueryPath_AST.getFirstChild() != null) ? fromClassOrOuterQueryPath_AST.getFirstChild() : fromClassOrOuterQueryPath_AST);
/*      */       
/* 1949 */       currentAST.advanceChildToEnd();
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1952 */       reportError(ex);
/* 1953 */       recover(ex, _tokenSet_18);
/*      */     }
/* 1955 */     this.returnAST = fromClassOrOuterQueryPath_AST;
/*      */   }
/*      */   
/*      */   public final void inClassDeclaration() throws RecognitionException, TokenStreamException
/*      */   {
/* 1960 */     this.returnAST = null;
/* 1961 */     ASTPair currentAST = new ASTPair();
/* 1962 */     AST inClassDeclaration_AST = null;
/* 1963 */     AST a_AST = null;
/* 1964 */     AST c_AST = null;
/*      */     try
/*      */     {
/* 1967 */       alias();
/* 1968 */       a_AST = this.returnAST;
/* 1969 */       match(26);
/* 1970 */       match(11);
/* 1971 */       path();
/* 1972 */       c_AST = this.returnAST;
/* 1973 */       inClassDeclaration_AST = currentAST.root;
/*      */       
/* 1975 */       inClassDeclaration_AST = this.astFactory.make(new ASTArray(3).add(this.astFactory.create(84, "RANGE")).add(c_AST).add(a_AST));
/*      */       
/* 1977 */       currentAST.root = inClassDeclaration_AST;
/* 1978 */       currentAST.child = ((inClassDeclaration_AST != null) && (inClassDeclaration_AST.getFirstChild() != null) ? inClassDeclaration_AST.getFirstChild() : inClassDeclaration_AST);
/*      */       
/* 1980 */       currentAST.advanceChildToEnd();
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1983 */       reportError(ex);
/* 1984 */       recover(ex, _tokenSet_18);
/*      */     }
/* 1986 */     this.returnAST = inClassDeclaration_AST;
/*      */   }
/*      */   
/*      */   public final void inCollectionDeclaration() throws RecognitionException, TokenStreamException
/*      */   {
/* 1991 */     this.returnAST = null;
/* 1992 */     ASTPair currentAST = new ASTPair();
/* 1993 */     AST inCollectionDeclaration_AST = null;
/* 1994 */     AST p_AST = null;
/* 1995 */     AST a_AST = null;
/*      */     try
/*      */     {
/* 1998 */       match(26);
/* 1999 */       match(97);
/* 2000 */       path();
/* 2001 */       p_AST = this.returnAST;
/* 2002 */       match(98);
/* 2003 */       alias();
/* 2004 */       a_AST = this.returnAST;
/* 2005 */       inCollectionDeclaration_AST = currentAST.root;
/*      */       
/* 2007 */       inCollectionDeclaration_AST = this.astFactory.make(new ASTArray(4).add(this.astFactory.create(32, "join")).add(this.astFactory.create(28, "inner")).add(p_AST).add(a_AST));
/*      */       
/* 2009 */       currentAST.root = inCollectionDeclaration_AST;
/* 2010 */       currentAST.child = ((inCollectionDeclaration_AST != null) && (inCollectionDeclaration_AST.getFirstChild() != null) ? inCollectionDeclaration_AST.getFirstChild() : inCollectionDeclaration_AST);
/*      */       
/* 2012 */       currentAST.advanceChildToEnd();
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2015 */       reportError(ex);
/* 2016 */       recover(ex, _tokenSet_18);
/*      */     }
/* 2018 */     this.returnAST = inCollectionDeclaration_AST;
/*      */   }
/*      */   
/*      */   public final void inCollectionElementsDeclaration() throws RecognitionException, TokenStreamException
/*      */   {
/* 2023 */     this.returnAST = null;
/* 2024 */     ASTPair currentAST = new ASTPair();
/* 2025 */     AST inCollectionElementsDeclaration_AST = null;
/* 2026 */     AST a_AST = null;
/* 2027 */     AST p_AST = null;
/*      */     try
/*      */     {
/* 2030 */       alias();
/* 2031 */       a_AST = this.returnAST;
/* 2032 */       match(26);
/* 2033 */       match(17);
/* 2034 */       match(97);
/* 2035 */       path();
/* 2036 */       p_AST = this.returnAST;
/* 2037 */       match(98);
/* 2038 */       inCollectionElementsDeclaration_AST = currentAST.root;
/*      */       
/* 2040 */       inCollectionElementsDeclaration_AST = this.astFactory.make(new ASTArray(4).add(this.astFactory.create(32, "join")).add(this.astFactory.create(28, "inner")).add(p_AST).add(a_AST));
/*      */       
/* 2042 */       currentAST.root = inCollectionElementsDeclaration_AST;
/* 2043 */       currentAST.child = ((inCollectionElementsDeclaration_AST != null) && (inCollectionElementsDeclaration_AST.getFirstChild() != null) ? inCollectionElementsDeclaration_AST.getFirstChild() : inCollectionElementsDeclaration_AST);
/*      */       
/* 2045 */       currentAST.advanceChildToEnd();
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2048 */       reportError(ex);
/* 2049 */       recover(ex, _tokenSet_18);
/*      */     }
/* 2051 */     this.returnAST = inCollectionElementsDeclaration_AST;
/*      */   }
/*      */   
/*      */   public final void alias() throws RecognitionException, TokenStreamException
/*      */   {
/* 2056 */     this.returnAST = null;
/* 2057 */     ASTPair currentAST = new ASTPair();
/* 2058 */     AST alias_AST = null;
/* 2059 */     AST a_AST = null;
/*      */     try
/*      */     {
/* 2062 */       identifier();
/* 2063 */       a_AST = this.returnAST;
/* 2064 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2065 */       a_AST.setType(69);
/* 2066 */       alias_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2069 */       reportError(ex);
/* 2070 */       recover(ex, _tokenSet_21);
/*      */     }
/* 2072 */     this.returnAST = alias_AST;
/*      */   }
/*      */   
/*      */   public final void expression() throws RecognitionException, TokenStreamException
/*      */   {
/* 2077 */     this.returnAST = null;
/* 2078 */     ASTPair currentAST = new ASTPair();
/* 2079 */     AST expression_AST = null;
/*      */     try
/*      */     {
/* 2082 */       logicalOrExpression();
/* 2083 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2084 */       expression_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2087 */       reportError(ex);
/* 2088 */       recover(ex, _tokenSet_22);
/*      */     }
/* 2090 */     this.returnAST = expression_AST;
/*      */   }
/*      */   
/*      */   public final void havingClause() throws RecognitionException, TokenStreamException
/*      */   {
/* 2095 */     this.returnAST = null;
/* 2096 */     ASTPair currentAST = new ASTPair();
/* 2097 */     AST havingClause_AST = null;
/*      */     try
/*      */     {
/* 2100 */       AST tmp62_AST = null;
/* 2101 */       tmp62_AST = this.astFactory.create(LT(1));
/* 2102 */       this.astFactory.makeASTRoot(currentAST, tmp62_AST);
/* 2103 */       match(25);
/* 2104 */       logicalExpression();
/* 2105 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2106 */       havingClause_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2109 */       reportError(ex);
/* 2110 */       recover(ex, _tokenSet_15);
/*      */     }
/* 2112 */     this.returnAST = havingClause_AST;
/*      */   }
/*      */   
/*      */   public final void orderElement() throws RecognitionException, TokenStreamException
/*      */   {
/* 2117 */     this.returnAST = null;
/* 2118 */     ASTPair currentAST = new ASTPair();
/* 2119 */     AST orderElement_AST = null;
/*      */     try
/*      */     {
/* 2122 */       expression();
/* 2123 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/* 2125 */       switch (LA(1))
/*      */       {
/*      */       case 8: 
/*      */       case 14: 
/*      */       case 100: 
/*      */       case 101: 
/* 2131 */         ascendingOrDescending();
/* 2132 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2133 */         break;
/*      */       
/*      */ 
/*      */       case 1: 
/*      */       case 50: 
/*      */       case 95: 
/*      */       case 98: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 2144 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/* 2148 */       orderElement_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2151 */       reportError(ex);
/* 2152 */       recover(ex, _tokenSet_23);
/*      */     }
/* 2154 */     this.returnAST = orderElement_AST;
/*      */   }
/*      */   
/*      */   public final void ascendingOrDescending() throws RecognitionException, TokenStreamException
/*      */   {
/* 2159 */     this.returnAST = null;
/* 2160 */     ASTPair currentAST = new ASTPair();
/* 2161 */     AST ascendingOrDescending_AST = null;
/*      */     try
/*      */     {
/* 2164 */       switch (LA(1))
/*      */       {
/*      */ 
/*      */       case 8: 
/*      */       case 100: 
/* 2169 */         switch (LA(1))
/*      */         {
/*      */         case 8: 
/* 2172 */           AST tmp63_AST = null;
/* 2173 */           tmp63_AST = this.astFactory.create(LT(1));
/* 2174 */           this.astFactory.addASTChild(currentAST, tmp63_AST);
/* 2175 */           match(8);
/* 2176 */           break;
/*      */         
/*      */ 
/*      */         case 100: 
/* 2180 */           AST tmp64_AST = null;
/* 2181 */           tmp64_AST = this.astFactory.create(LT(1));
/* 2182 */           this.astFactory.addASTChild(currentAST, tmp64_AST);
/* 2183 */           match(100);
/* 2184 */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 2188 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         }
/*      */         
/*      */         
/* 2192 */         ascendingOrDescending_AST = currentAST.root;
/* 2193 */         ascendingOrDescending_AST.setType(8);
/* 2194 */         ascendingOrDescending_AST = currentAST.root;
/* 2195 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */       case 14: 
/*      */       case 101: 
/* 2201 */         switch (LA(1))
/*      */         {
/*      */         case 14: 
/* 2204 */           AST tmp65_AST = null;
/* 2205 */           tmp65_AST = this.astFactory.create(LT(1));
/* 2206 */           this.astFactory.addASTChild(currentAST, tmp65_AST);
/* 2207 */           match(14);
/* 2208 */           break;
/*      */         
/*      */ 
/*      */         case 101: 
/* 2212 */           AST tmp66_AST = null;
/* 2213 */           tmp66_AST = this.astFactory.create(LT(1));
/* 2214 */           this.astFactory.addASTChild(currentAST, tmp66_AST);
/* 2215 */           match(101);
/* 2216 */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 2220 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         }
/*      */         
/*      */         
/* 2224 */         ascendingOrDescending_AST = currentAST.root;
/* 2225 */         ascendingOrDescending_AST.setType(14);
/* 2226 */         ascendingOrDescending_AST = currentAST.root;
/* 2227 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 2231 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2236 */       reportError(ex);
/* 2237 */       recover(ex, _tokenSet_23);
/*      */     }
/* 2239 */     this.returnAST = ascendingOrDescending_AST;
/*      */   }
/*      */   
/*      */   public final void aliasedExpression() throws RecognitionException, TokenStreamException
/*      */   {
/* 2244 */     this.returnAST = null;
/* 2245 */     ASTPair currentAST = new ASTPair();
/* 2246 */     AST aliasedExpression_AST = null;
/*      */     try
/*      */     {
/* 2249 */       expression();
/* 2250 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/* 2252 */       switch (LA(1))
/*      */       {
/*      */       case 7: 
/* 2255 */         AST tmp67_AST = null;
/* 2256 */         tmp67_AST = this.astFactory.create(LT(1));
/* 2257 */         this.astFactory.makeASTRoot(currentAST, tmp67_AST);
/* 2258 */         match(7);
/* 2259 */         identifier();
/* 2260 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2261 */         break;
/*      */       
/*      */ 
/*      */       case 1: 
/*      */       case 22: 
/*      */       case 24: 
/*      */       case 41: 
/*      */       case 50: 
/*      */       case 53: 
/*      */       case 95: 
/*      */       case 98: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 2276 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/* 2280 */       aliasedExpression_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2283 */       reportError(ex);
/* 2284 */       recover(ex, _tokenSet_24);
/*      */     }
/* 2286 */     this.returnAST = aliasedExpression_AST;
/*      */   }
/*      */   
/*      */   public final void logicalOrExpression() throws RecognitionException, TokenStreamException
/*      */   {
/* 2291 */     this.returnAST = null;
/* 2292 */     ASTPair currentAST = new ASTPair();
/* 2293 */     AST logicalOrExpression_AST = null;
/*      */     try
/*      */     {
/* 2296 */       logicalAndExpression();
/* 2297 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*      */ 
/*      */ 
/* 2301 */       while (LA(1) == 40) {
/* 2302 */         AST tmp68_AST = null;
/* 2303 */         tmp68_AST = this.astFactory.create(LT(1));
/* 2304 */         this.astFactory.makeASTRoot(currentAST, tmp68_AST);
/* 2305 */         match(40);
/* 2306 */         logicalAndExpression();
/* 2307 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2315 */       logicalOrExpression_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2318 */       reportError(ex);
/* 2319 */       recover(ex, _tokenSet_22);
/*      */     }
/* 2321 */     this.returnAST = logicalOrExpression_AST;
/*      */   }
/*      */   
/*      */   public final void logicalAndExpression() throws RecognitionException, TokenStreamException
/*      */   {
/* 2326 */     this.returnAST = null;
/* 2327 */     ASTPair currentAST = new ASTPair();
/* 2328 */     AST logicalAndExpression_AST = null;
/*      */     try
/*      */     {
/* 2331 */       negatedExpression();
/* 2332 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*      */ 
/*      */ 
/* 2336 */       while (LA(1) == 6) {
/* 2337 */         AST tmp69_AST = null;
/* 2338 */         tmp69_AST = this.astFactory.create(LT(1));
/* 2339 */         this.astFactory.makeASTRoot(currentAST, tmp69_AST);
/* 2340 */         match(6);
/* 2341 */         negatedExpression();
/* 2342 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2350 */       logicalAndExpression_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2353 */       reportError(ex);
/* 2354 */       recover(ex, _tokenSet_25);
/*      */     }
/* 2356 */     this.returnAST = logicalAndExpression_AST;
/*      */   }
/*      */   
/*      */   public final void negatedExpression() throws RecognitionException, TokenStreamException
/*      */   {
/* 2361 */     this.returnAST = null;
/* 2362 */     ASTPair currentAST = new ASTPair();
/* 2363 */     AST negatedExpression_AST = null;
/* 2364 */     AST x_AST = null;
/* 2365 */     AST y_AST = null;
/* 2366 */     weakKeywords();
/*      */     try
/*      */     {
/* 2369 */       switch (LA(1))
/*      */       {
/*      */       case 38: 
/* 2372 */         AST tmp70_AST = null;
/* 2373 */         tmp70_AST = this.astFactory.create(LT(1));
/* 2374 */         match(38);
/* 2375 */         negatedExpression();
/* 2376 */         x_AST = this.returnAST;
/* 2377 */         negatedExpression_AST = currentAST.root;
/* 2378 */         negatedExpression_AST = negateNode(x_AST);
/* 2379 */         currentAST.root = negatedExpression_AST;
/* 2380 */         currentAST.child = ((negatedExpression_AST != null) && (negatedExpression_AST.getFirstChild() != null) ? negatedExpression_AST.getFirstChild() : negatedExpression_AST);
/*      */         
/* 2382 */         currentAST.advanceChildToEnd();
/* 2383 */         break;
/*      */       
/*      */ 
/*      */       case 4: 
/*      */       case 5: 
/*      */       case 9: 
/*      */       case 12: 
/*      */       case 17: 
/*      */       case 19: 
/*      */       case 20: 
/*      */       case 27: 
/*      */       case 35: 
/*      */       case 36: 
/*      */       case 39: 
/*      */       case 47: 
/*      */       case 48: 
/*      */       case 49: 
/*      */       case 54: 
/*      */       case 62: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 97: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 115: 
/*      */       case 116: 
/*      */       case 117: 
/*      */       case 118: 
/*      */       case 119: 
/* 2413 */         equalityExpression();
/* 2414 */         y_AST = this.returnAST;
/* 2415 */         negatedExpression_AST = currentAST.root;
/* 2416 */         negatedExpression_AST = y_AST;
/* 2417 */         currentAST.root = negatedExpression_AST;
/* 2418 */         currentAST.child = ((negatedExpression_AST != null) && (negatedExpression_AST.getFirstChild() != null) ? negatedExpression_AST.getFirstChild() : negatedExpression_AST);
/*      */         
/* 2420 */         currentAST.advanceChildToEnd();
/* 2421 */         break;
/*      */       case 6: case 7: case 8: case 10: case 11: case 13: case 14: case 15: case 16: case 18: case 21: case 22: case 23: case 24: case 25: case 26: case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 37: case 40: case 41: case 42: case 43: case 44: case 45: 
/*      */       case 46: case 50: case 51: case 52: case 53: case 55: case 56: case 57: case 58: case 59: case 60: case 61: case 63: case 64: case 65: case 66: case 67: case 68: case 69: case 70: case 71: case 72: case 73: case 74: case 75: case 76: case 77: case 78: case 79: case 80: 
/*      */       case 81: case 82: case 83: case 84: case 85: case 86: case 87: case 88: case 89: case 90: case 91: case 95: case 96: case 98: case 99: case 100: case 101: case 102: case 103: case 104: case 105: case 106: case 107: case 108: case 111: case 112: case 113: case 114: default: 
/* 2425 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 2430 */       reportError(ex);
/* 2431 */       recover(ex, _tokenSet_26);
/*      */     }
/* 2433 */     this.returnAST = negatedExpression_AST;
/*      */   }
/*      */   
/*      */   public final void equalityExpression() throws RecognitionException, TokenStreamException
/*      */   {
/* 2438 */     this.returnAST = null;
/* 2439 */     ASTPair currentAST = new ASTPair();
/* 2440 */     AST equalityExpression_AST = null;
/* 2441 */     AST x_AST = null;
/* 2442 */     Token is = null;
/* 2443 */     AST is_AST = null;
/* 2444 */     Token ne = null;
/* 2445 */     AST ne_AST = null;
/* 2446 */     AST y_AST = null;
/*      */     try
/*      */     {
/* 2449 */       relationalExpression();
/* 2450 */       x_AST = this.returnAST;
/* 2451 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*      */ 
/*      */ 
/* 2455 */       while (_tokenSet_27.member(LA(1)))
/*      */       {
/* 2457 */         switch (LA(1))
/*      */         {
/*      */         case 96: 
/* 2460 */           AST tmp71_AST = null;
/* 2461 */           tmp71_AST = this.astFactory.create(LT(1));
/* 2462 */           this.astFactory.makeASTRoot(currentAST, tmp71_AST);
/* 2463 */           match(96);
/* 2464 */           break;
/*      */         
/*      */ 
/*      */         case 31: 
/* 2468 */           is = LT(1);
/* 2469 */           is_AST = this.astFactory.create(is);
/* 2470 */           this.astFactory.makeASTRoot(currentAST, is_AST);
/* 2471 */           match(31);
/* 2472 */           is_AST.setType(96);
/*      */           
/* 2474 */           switch (LA(1))
/*      */           {
/*      */           case 38: 
/* 2477 */             match(38);
/* 2478 */             is_AST.setType(102);
/* 2479 */             break;
/*      */           case 4: case 5: case 9: case 12: case 17: case 19: case 20: case 27: case 35: case 36: case 39: case 47: case 48: case 49: case 54: case 62: case 92: case 93: case 94: case 97: case 109: case 110: case 115: case 116: case 117: case 118: case 119: 
/*      */             break;
/*      */           case 6: case 7: case 8: 
/*      */           case 10: case 11: case 13: 
/*      */           case 14: case 15: case 16: 
/*      */           case 18: case 21: case 22: 
/*      */           case 23: case 24: case 25: 
/*      */           case 26: case 28: case 29: 
/*      */           case 30: case 31: case 32: 
/*      */           case 33: case 34: case 37: 
/*      */           case 40: case 41: case 42: 
/*      */           case 43: case 44: case 45: 
/*      */           case 46: case 50: case 51: 
/*      */           case 52: case 53: case 55: 
/*      */           case 56: case 57: case 58: 
/*      */           case 59: case 60: case 61: 
/*      */           case 63: case 64: case 65: 
/*      */           case 66: case 67: case 68: 
/*      */           case 69: case 70: case 71: 
/*      */           case 72: case 73: case 74: 
/*      */           case 75: case 76: case 77: 
/*      */           case 78: case 79: case 80: 
/*      */           case 81: case 82: case 83: 
/*      */           case 84: case 85: case 86: 
/*      */           case 87: case 88: case 89: 
/*      */           case 90: case 91: case 95: 
/*      */           case 96: case 98: case 99: 
/*      */           case 100: case 101: case 102: 
/*      */           case 103: case 104: case 105: 
/*      */           case 106: case 107: 
/*      */           case 108: case 111: 
/*      */           case 112: case 113: 
/*      */           case 114: default: 
/* 2513 */             throw new NoViableAltException(LT(1), getFilename());
/*      */           }
/*      */           
/*      */           
/*      */ 
/*      */ 
/*      */           break;
/*      */         case 102: 
/* 2521 */           AST tmp73_AST = null;
/* 2522 */           tmp73_AST = this.astFactory.create(LT(1));
/* 2523 */           this.astFactory.makeASTRoot(currentAST, tmp73_AST);
/* 2524 */           match(102);
/* 2525 */           break;
/*      */         
/*      */ 
/*      */         case 103: 
/* 2529 */           ne = LT(1);
/* 2530 */           ne_AST = this.astFactory.create(ne);
/* 2531 */           this.astFactory.makeASTRoot(currentAST, ne_AST);
/* 2532 */           match(103);
/* 2533 */           ne_AST.setType(102);
/* 2534 */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 2538 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         }
/*      */         
/*      */         
/* 2542 */         relationalExpression();
/* 2543 */         y_AST = this.returnAST;
/* 2544 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2552 */       equalityExpression_AST = currentAST.root;
/*      */       
/*      */ 
/* 2555 */       equalityExpression_AST = processEqualityExpression(equalityExpression_AST);
/*      */       
/* 2557 */       currentAST.root = equalityExpression_AST;
/* 2558 */       currentAST.child = ((equalityExpression_AST != null) && (equalityExpression_AST.getFirstChild() != null) ? equalityExpression_AST.getFirstChild() : equalityExpression_AST);
/*      */       
/* 2560 */       currentAST.advanceChildToEnd();
/* 2561 */       equalityExpression_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2564 */       reportError(ex);
/* 2565 */       recover(ex, _tokenSet_26);
/*      */     }
/* 2567 */     this.returnAST = equalityExpression_AST;
/*      */   }
/*      */   
/*      */   public final void relationalExpression() throws RecognitionException, TokenStreamException
/*      */   {
/* 2572 */     this.returnAST = null;
/* 2573 */     ASTPair currentAST = new ASTPair();
/* 2574 */     AST relationalExpression_AST = null;
/* 2575 */     Token n = null;
/* 2576 */     AST n_AST = null;
/* 2577 */     Token i = null;
/* 2578 */     AST i_AST = null;
/* 2579 */     Token b = null;
/* 2580 */     AST b_AST = null;
/* 2581 */     Token l = null;
/* 2582 */     AST l_AST = null;
/* 2583 */     AST p_AST = null;
/*      */     try
/*      */     {
/* 2586 */       concatenation();
/* 2587 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/* 2589 */       switch (LA(1))
/*      */       {
/*      */       }
/*      */       
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2626 */       while ((LA(1) >= 104) && (LA(1) <= 107))
/*      */       {
/* 2628 */         switch (LA(1))
/*      */         {
/*      */         case 104: 
/* 2631 */           AST tmp74_AST = null;
/* 2632 */           tmp74_AST = this.astFactory.create(LT(1));
/* 2633 */           this.astFactory.makeASTRoot(currentAST, tmp74_AST);
/* 2634 */           match(104);
/* 2635 */           break;
/*      */         
/*      */ 
/*      */         case 105: 
/* 2639 */           AST tmp75_AST = null;
/* 2640 */           tmp75_AST = this.astFactory.create(LT(1));
/* 2641 */           this.astFactory.makeASTRoot(currentAST, tmp75_AST);
/* 2642 */           match(105);
/* 2643 */           break;
/*      */         
/*      */ 
/*      */         case 106: 
/* 2647 */           AST tmp76_AST = null;
/* 2648 */           tmp76_AST = this.astFactory.create(LT(1));
/* 2649 */           this.astFactory.makeASTRoot(currentAST, tmp76_AST);
/* 2650 */           match(106);
/* 2651 */           break;
/*      */         
/*      */ 
/*      */         case 107: 
/* 2655 */           AST tmp77_AST = null;
/* 2656 */           tmp77_AST = this.astFactory.create(LT(1));
/* 2657 */           this.astFactory.makeASTRoot(currentAST, tmp77_AST);
/* 2658 */           match(107);
/* 2659 */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 2663 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         }
/*      */         
/*      */         
/* 2667 */         additiveExpression();
/* 2668 */         this.astFactory.addASTChild(currentAST, this.returnAST); continue;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2686 */         switch (LA(1))
/*      */         {
/*      */         case 38: 
/* 2689 */           n = LT(1);
/* 2690 */           n_AST = this.astFactory.create(n);
/* 2691 */           match(38);
/* 2692 */           break;
/*      */         
/*      */ 
/*      */         case 10: 
/*      */         case 26: 
/*      */         case 34: 
/*      */         case 64: 
/*      */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 2703 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         }
/*      */         
/*      */         
/*      */ 
/* 2708 */         switch (LA(1))
/*      */         {
/*      */ 
/*      */         case 26: 
/* 2712 */           i = LT(1);
/* 2713 */           i_AST = this.astFactory.create(i);
/* 2714 */           this.astFactory.makeASTRoot(currentAST, i_AST);
/* 2715 */           match(26);
/*      */           
/* 2717 */           i_AST.setType(n == null ? 26 : 80);
/* 2718 */           i_AST.setText(n == null ? "in" : "not in");
/*      */           
/* 2720 */           inList();
/* 2721 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */           
/* 2723 */           break;
/*      */         
/*      */ 
/*      */ 
/*      */         case 10: 
/* 2728 */           b = LT(1);
/* 2729 */           b_AST = this.astFactory.create(b);
/* 2730 */           this.astFactory.makeASTRoot(currentAST, b_AST);
/* 2731 */           match(10);
/*      */           
/* 2733 */           b_AST.setType(n == null ? 10 : 79);
/* 2734 */           b_AST.setText(n == null ? "between" : "not between");
/*      */           
/* 2736 */           betweenList();
/* 2737 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */           
/* 2739 */           break;
/*      */         
/*      */ 
/*      */ 
/*      */         case 34: 
/* 2744 */           l = LT(1);
/* 2745 */           l_AST = this.astFactory.create(l);
/* 2746 */           this.astFactory.makeASTRoot(currentAST, l_AST);
/* 2747 */           match(34);
/*      */           
/* 2749 */           l_AST.setType(n == null ? 34 : 81);
/* 2750 */           l_AST.setText(n == null ? "like" : "not like");
/*      */           
/* 2752 */           concatenation();
/* 2753 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2754 */           likeEscape();
/* 2755 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */           
/* 2757 */           break;
/*      */         
/*      */ 
/*      */ 
/*      */         case 64: 
/* 2762 */           match(64);
/* 2763 */           match(66);
/* 2764 */           path();
/* 2765 */           p_AST = this.returnAST;
/*      */           
/* 2767 */           processMemberOf(n, p_AST, currentAST);
/*      */           
/*      */ 
/* 2770 */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 2774 */           throw new NoViableAltException(LT(1), getFilename());
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2782 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         }
/*      */         
/*      */       }
/* 2786 */       relationalExpression_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2789 */       reportError(ex);
/* 2790 */       recover(ex, _tokenSet_28);
/*      */     }
/* 2792 */     this.returnAST = relationalExpression_AST;
/*      */   }
/*      */   
/*      */   public final void additiveExpression() throws RecognitionException, TokenStreamException
/*      */   {
/* 2797 */     this.returnAST = null;
/* 2798 */     ASTPair currentAST = new ASTPair();
/* 2799 */     AST additiveExpression_AST = null;
/*      */     try
/*      */     {
/* 2802 */       multiplyExpression();
/* 2803 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*      */ 
/*      */ 
/* 2807 */       while ((LA(1) == 109) || (LA(1) == 110))
/*      */       {
/* 2809 */         switch (LA(1))
/*      */         {
/*      */         case 109: 
/* 2812 */           AST tmp80_AST = null;
/* 2813 */           tmp80_AST = this.astFactory.create(LT(1));
/* 2814 */           this.astFactory.makeASTRoot(currentAST, tmp80_AST);
/* 2815 */           match(109);
/* 2816 */           break;
/*      */         
/*      */ 
/*      */         case 110: 
/* 2820 */           AST tmp81_AST = null;
/* 2821 */           tmp81_AST = this.astFactory.create(LT(1));
/* 2822 */           this.astFactory.makeASTRoot(currentAST, tmp81_AST);
/* 2823 */           match(110);
/* 2824 */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 2828 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         }
/*      */         
/*      */         
/* 2832 */         multiplyExpression();
/* 2833 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2841 */       additiveExpression_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2844 */       reportError(ex);
/* 2845 */       recover(ex, _tokenSet_29);
/*      */     }
/* 2847 */     this.returnAST = additiveExpression_AST;
/*      */   }
/*      */   
/*      */   public final void inList() throws RecognitionException, TokenStreamException
/*      */   {
/* 2852 */     this.returnAST = null;
/* 2853 */     ASTPair currentAST = new ASTPair();
/* 2854 */     AST inList_AST = null;
/* 2855 */     AST x_AST = null;
/*      */     try
/*      */     {
/* 2858 */       compoundExpr();
/* 2859 */       x_AST = this.returnAST;
/* 2860 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2861 */       inList_AST = currentAST.root;
/* 2862 */       inList_AST = this.astFactory.make(new ASTArray(2).add(this.astFactory.create(74, "inList")).add(inList_AST));
/* 2863 */       currentAST.root = inList_AST;
/* 2864 */       currentAST.child = ((inList_AST != null) && (inList_AST.getFirstChild() != null) ? inList_AST.getFirstChild() : inList_AST);
/*      */       
/* 2866 */       currentAST.advanceChildToEnd();
/* 2867 */       inList_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2870 */       reportError(ex);
/* 2871 */       recover(ex, _tokenSet_28);
/*      */     }
/* 2873 */     this.returnAST = inList_AST;
/*      */   }
/*      */   
/*      */   public final void betweenList() throws RecognitionException, TokenStreamException
/*      */   {
/* 2878 */     this.returnAST = null;
/* 2879 */     ASTPair currentAST = new ASTPair();
/* 2880 */     AST betweenList_AST = null;
/*      */     try
/*      */     {
/* 2883 */       concatenation();
/* 2884 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2885 */       match(6);
/* 2886 */       concatenation();
/* 2887 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2888 */       betweenList_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2891 */       reportError(ex);
/* 2892 */       recover(ex, _tokenSet_28);
/*      */     }
/* 2894 */     this.returnAST = betweenList_AST;
/*      */   }
/*      */   
/*      */   public final void likeEscape() throws RecognitionException, TokenStreamException
/*      */   {
/* 2899 */     this.returnAST = null;
/* 2900 */     ASTPair currentAST = new ASTPair();
/* 2901 */     AST likeEscape_AST = null;
/*      */     
/*      */     try
/*      */     {
/* 2905 */       switch (LA(1))
/*      */       {
/*      */       case 18: 
/* 2908 */         AST tmp83_AST = null;
/* 2909 */         tmp83_AST = this.astFactory.create(LT(1));
/* 2910 */         this.astFactory.makeASTRoot(currentAST, tmp83_AST);
/* 2911 */         match(18);
/* 2912 */         concatenation();
/* 2913 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2914 */         break;
/*      */       case 1: case 6: case 7: case 8: case 14: case 22: case 23: case 24: case 25: case 28: case 31: case 32: case 33: case 40: case 41: case 44: case 50: case 53: case 57: case 95: case 96: case 98: case 100: case 101: case 102: case 103: case 114: 
/*      */         break;
/*      */       case 2: case 3: case 4: 
/*      */       case 5: case 9: case 10: 
/*      */       case 11: case 12: case 13: 
/*      */       case 15: case 16: case 17: 
/*      */       case 19: case 20: case 21: 
/*      */       case 26: case 27: case 29: 
/*      */       case 30: case 34: case 35: 
/*      */       case 36: case 37: case 38: 
/*      */       case 39: case 42: case 43: 
/*      */       case 45: case 46: case 47: 
/*      */       case 48: case 49: case 51: 
/*      */       case 52: case 54: case 55: 
/*      */       case 56: case 58: case 59: 
/*      */       case 60: case 61: case 62: 
/*      */       case 63: case 64: case 65: 
/*      */       case 66: case 67: case 68: 
/*      */       case 69: case 70: case 71: 
/*      */       case 72: case 73: case 74: 
/*      */       case 75: case 76: case 77: 
/*      */       case 78: case 79: case 80: 
/*      */       case 81: case 82: case 83: 
/*      */       case 84: case 85: case 86: 
/*      */       case 87: case 88: case 89: 
/*      */       case 90: case 91: case 92: 
/*      */       case 93: case 94: case 97: 
/*      */       case 99: case 104: 
/*      */       case 105: case 106: 
/*      */       case 107: case 108: 
/*      */       case 109: case 110: 
/*      */       case 111: case 112: 
/*      */       case 113: default: 
/* 2948 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/* 2952 */       likeEscape_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2955 */       reportError(ex);
/* 2956 */       recover(ex, _tokenSet_28);
/*      */     }
/* 2958 */     this.returnAST = likeEscape_AST;
/*      */   }
/*      */   
/*      */   public final void compoundExpr() throws RecognitionException, TokenStreamException
/*      */   {
/* 2963 */     this.returnAST = null;
/* 2964 */     ASTPair currentAST = new ASTPair();
/* 2965 */     AST compoundExpr_AST = null;
/*      */     try
/*      */     {
/* 2968 */       switch (LA(1))
/*      */       {
/*      */       case 17: 
/*      */       case 27: 
/* 2972 */         collectionExpr();
/* 2973 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2974 */         compoundExpr_AST = currentAST.root;
/* 2975 */         break;
/*      */       
/*      */ 
/*      */       case 119: 
/* 2979 */         path();
/* 2980 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2981 */         compoundExpr_AST = currentAST.root;
/* 2982 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */       case 97: 
/* 2987 */         match(97);
/*      */         
/* 2989 */         switch (LA(1))
/*      */         {
/*      */ 
/*      */         case 4: 
/*      */         case 5: 
/*      */         case 9: 
/*      */         case 12: 
/*      */         case 17: 
/*      */         case 19: 
/*      */         case 20: 
/*      */         case 27: 
/*      */         case 35: 
/*      */         case 36: 
/*      */         case 38: 
/*      */         case 39: 
/*      */         case 47: 
/*      */         case 48: 
/*      */         case 49: 
/*      */         case 54: 
/*      */         case 62: 
/*      */         case 92: 
/*      */         case 93: 
/*      */         case 94: 
/*      */         case 97: 
/*      */         case 109: 
/*      */         case 110: 
/*      */         case 115: 
/*      */         case 116: 
/*      */         case 117: 
/*      */         case 118: 
/*      */         case 119: 
/* 3020 */           expression();
/* 3021 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */         }
/*      */         
/*      */         
/* 3025 */         while (LA(1) == 95) {
/* 3026 */           match(95);
/* 3027 */           expression();
/* 3028 */           this.astFactory.addASTChild(currentAST, this.returnAST); continue;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3047 */           subQuery();
/* 3048 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3049 */           break;
/*      */           
/*      */ 
/*      */ 
/* 3053 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         }
/*      */         
/*      */ 
/* 3057 */         match(98);
/*      */         
/* 3059 */         compoundExpr_AST = currentAST.root;
/* 3060 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 3064 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 3069 */       reportError(ex);
/* 3070 */       recover(ex, _tokenSet_28);
/*      */     }
/* 3072 */     this.returnAST = compoundExpr_AST;
/*      */   }
/*      */   
/*      */   public final void multiplyExpression() throws RecognitionException, TokenStreamException
/*      */   {
/* 3077 */     this.returnAST = null;
/* 3078 */     ASTPair currentAST = new ASTPair();
/* 3079 */     AST multiplyExpression_AST = null;
/*      */     try
/*      */     {
/* 3082 */       unaryExpression();
/* 3083 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*      */ 
/*      */ 
/* 3087 */       while ((LA(1) == 111) || (LA(1) == 112))
/*      */       {
/* 3089 */         switch (LA(1))
/*      */         {
/*      */         case 111: 
/* 3092 */           AST tmp87_AST = null;
/* 3093 */           tmp87_AST = this.astFactory.create(LT(1));
/* 3094 */           this.astFactory.makeASTRoot(currentAST, tmp87_AST);
/* 3095 */           match(111);
/* 3096 */           break;
/*      */         
/*      */ 
/*      */         case 112: 
/* 3100 */           AST tmp88_AST = null;
/* 3101 */           tmp88_AST = this.astFactory.create(LT(1));
/* 3102 */           this.astFactory.makeASTRoot(currentAST, tmp88_AST);
/* 3103 */           match(112);
/* 3104 */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 3108 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         }
/*      */         
/*      */         
/* 3112 */         unaryExpression();
/* 3113 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3121 */       multiplyExpression_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 3124 */       reportError(ex);
/* 3125 */       recover(ex, _tokenSet_30);
/*      */     }
/* 3127 */     this.returnAST = multiplyExpression_AST;
/*      */   }
/*      */   
/*      */   public final void unaryExpression() throws RecognitionException, TokenStreamException
/*      */   {
/* 3132 */     this.returnAST = null;
/* 3133 */     ASTPair currentAST = new ASTPair();
/* 3134 */     AST unaryExpression_AST = null;
/*      */     try
/*      */     {
/* 3137 */       switch (LA(1))
/*      */       {
/*      */       case 110: 
/* 3140 */         AST tmp89_AST = null;
/* 3141 */         tmp89_AST = this.astFactory.create(LT(1));
/* 3142 */         this.astFactory.makeASTRoot(currentAST, tmp89_AST);
/* 3143 */         match(110);
/* 3144 */         tmp89_AST.setType(87);
/* 3145 */         unaryExpression();
/* 3146 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3147 */         unaryExpression_AST = currentAST.root;
/* 3148 */         break;
/*      */       
/*      */ 
/*      */       case 109: 
/* 3152 */         AST tmp90_AST = null;
/* 3153 */         tmp90_AST = this.astFactory.create(LT(1));
/* 3154 */         this.astFactory.makeASTRoot(currentAST, tmp90_AST);
/* 3155 */         match(109);
/* 3156 */         tmp90_AST.setType(88);
/* 3157 */         unaryExpression();
/* 3158 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3159 */         unaryExpression_AST = currentAST.root;
/* 3160 */         break;
/*      */       
/*      */ 
/*      */       case 54: 
/* 3164 */         caseExpression();
/* 3165 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3166 */         unaryExpression_AST = currentAST.root;
/* 3167 */         break;
/*      */       
/*      */ 
/*      */       case 4: 
/*      */       case 5: 
/*      */       case 19: 
/*      */       case 47: 
/* 3174 */         quantifiedExpression();
/* 3175 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3176 */         unaryExpression_AST = currentAST.root;
/* 3177 */         break;
/*      */       
/*      */ 
/*      */       case 9: 
/*      */       case 12: 
/*      */       case 17: 
/*      */       case 20: 
/*      */       case 27: 
/*      */       case 35: 
/*      */       case 36: 
/*      */       case 39: 
/*      */       case 48: 
/*      */       case 49: 
/*      */       case 62: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 97: 
/*      */       case 115: 
/*      */       case 116: 
/*      */       case 117: 
/*      */       case 118: 
/*      */       case 119: 
/* 3200 */         atom();
/* 3201 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3202 */         unaryExpression_AST = currentAST.root;
/* 3203 */         break;
/*      */       case 6: case 7: case 8: case 10: case 11: case 13: case 14: case 15: case 16: case 18: case 21: case 22: case 23: case 24: case 25: case 26: case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 37: case 38: case 40: case 41: case 42: case 43: case 44: 
/*      */       case 45: case 46: case 50: case 51: case 52: case 53: case 55: case 56: case 57: case 58: case 59: case 60: case 61: case 63: case 64: case 65: case 66: case 67: case 68: case 69: case 70: case 71: case 72: case 73: case 74: case 75: case 76: case 77: case 78: case 79: 
/*      */       case 80: case 81: case 82: case 83: case 84: case 85: case 86: case 87: case 88: case 89: case 90: case 91: case 95: case 96: case 98: case 99: case 100: case 101: case 102: case 103: case 104: case 105: case 106: case 107: case 108: case 111: case 112: case 113: case 114: default: 
/* 3207 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 3212 */       reportError(ex);
/* 3213 */       recover(ex, _tokenSet_31);
/*      */     }
/* 3215 */     this.returnAST = unaryExpression_AST;
/*      */   }
/*      */   
/*      */   public final void caseExpression() throws RecognitionException, TokenStreamException
/*      */   {
/* 3220 */     this.returnAST = null;
/* 3221 */     ASTPair currentAST = new ASTPair();
/* 3222 */     AST caseExpression_AST = null;
/*      */     try
/*      */     {
/* 3225 */       if ((LA(1) == 54) && (LA(2) == 58)) {
/* 3226 */         AST tmp91_AST = null;
/* 3227 */         tmp91_AST = this.astFactory.create(LT(1));
/* 3228 */         this.astFactory.makeASTRoot(currentAST, tmp91_AST);
/* 3229 */         match(54);
/*      */         
/* 3231 */         int _cnt129 = 0;
/*      */         for (;;)
/*      */         {
/* 3234 */           if (LA(1) == 58) {
/* 3235 */             whenClause();
/* 3236 */             this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */           }
/*      */           else {
/* 3239 */             if (_cnt129 >= 1) break; throw new NoViableAltException(LT(1), getFilename());
/*      */           }
/*      */           
/* 3242 */           _cnt129++;
/*      */         }
/*      */         
/*      */ 
/* 3246 */         switch (LA(1))
/*      */         {
/*      */         case 56: 
/* 3249 */           elseClause();
/* 3250 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3251 */           break;
/*      */         
/*      */ 
/*      */         case 55: 
/*      */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 3259 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         }
/*      */         
/*      */         
/* 3263 */         match(55);
/* 3264 */         caseExpression_AST = currentAST.root;
/*      */       }
/* 3266 */       else if ((LA(1) == 54) && (_tokenSet_32.member(LA(2)))) {
/* 3267 */         AST tmp93_AST = null;
/* 3268 */         tmp93_AST = this.astFactory.create(LT(1));
/* 3269 */         this.astFactory.makeASTRoot(currentAST, tmp93_AST);
/* 3270 */         match(54);
/* 3271 */         tmp93_AST.setType(71);
/* 3272 */         unaryExpression();
/* 3273 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */         
/* 3275 */         int _cnt132 = 0;
/*      */         for (;;)
/*      */         {
/* 3278 */           if (LA(1) == 58) {
/* 3279 */             altWhenClause();
/* 3280 */             this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */           }
/*      */           else {
/* 3283 */             if (_cnt132 >= 1) break; throw new NoViableAltException(LT(1), getFilename());
/*      */           }
/*      */           
/* 3286 */           _cnt132++;
/*      */         }
/*      */         
/*      */ 
/* 3290 */         switch (LA(1))
/*      */         {
/*      */         case 56: 
/* 3293 */           elseClause();
/* 3294 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3295 */           break;
/*      */         
/*      */ 
/*      */         case 55: 
/*      */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 3303 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         }
/*      */         
/*      */         
/* 3307 */         match(55);
/* 3308 */         caseExpression_AST = currentAST.root;
/*      */       }
/*      */       else {
/* 3311 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 3316 */       reportError(ex);
/* 3317 */       recover(ex, _tokenSet_31);
/*      */     }
/* 3319 */     this.returnAST = caseExpression_AST;
/*      */   }
/*      */   
/*      */   public final void quantifiedExpression() throws RecognitionException, TokenStreamException
/*      */   {
/* 3324 */     this.returnAST = null;
/* 3325 */     ASTPair currentAST = new ASTPair();
/* 3326 */     AST quantifiedExpression_AST = null;
/*      */     
/*      */     try
/*      */     {
/* 3330 */       switch (LA(1))
/*      */       {
/*      */       case 47: 
/* 3333 */         AST tmp95_AST = null;
/* 3334 */         tmp95_AST = this.astFactory.create(LT(1));
/* 3335 */         this.astFactory.makeASTRoot(currentAST, tmp95_AST);
/* 3336 */         match(47);
/* 3337 */         break;
/*      */       
/*      */ 
/*      */       case 19: 
/* 3341 */         AST tmp96_AST = null;
/* 3342 */         tmp96_AST = this.astFactory.create(LT(1));
/* 3343 */         this.astFactory.makeASTRoot(currentAST, tmp96_AST);
/* 3344 */         match(19);
/* 3345 */         break;
/*      */       
/*      */ 
/*      */       case 4: 
/* 3349 */         AST tmp97_AST = null;
/* 3350 */         tmp97_AST = this.astFactory.create(LT(1));
/* 3351 */         this.astFactory.makeASTRoot(currentAST, tmp97_AST);
/* 3352 */         match(4);
/* 3353 */         break;
/*      */       
/*      */ 
/*      */       case 5: 
/* 3357 */         AST tmp98_AST = null;
/* 3358 */         tmp98_AST = this.astFactory.create(LT(1));
/* 3359 */         this.astFactory.makeASTRoot(currentAST, tmp98_AST);
/* 3360 */         match(5);
/* 3361 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 3365 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/*      */ 
/* 3370 */       switch (LA(1))
/*      */       {
/*      */       case 119: 
/* 3373 */         identifier();
/* 3374 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3375 */         break;
/*      */       
/*      */ 
/*      */       case 17: 
/*      */       case 27: 
/* 3380 */         collectionExpr();
/* 3381 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3382 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */       case 97: 
/* 3387 */         match(97);
/*      */         
/* 3389 */         subQuery();
/* 3390 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */         
/* 3392 */         match(98);
/*      */         
/* 3394 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 3398 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/* 3402 */       quantifiedExpression_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 3405 */       reportError(ex);
/* 3406 */       recover(ex, _tokenSet_31);
/*      */     }
/* 3408 */     this.returnAST = quantifiedExpression_AST;
/*      */   }
/*      */   
/*      */   public final void atom() throws RecognitionException, TokenStreamException
/*      */   {
/* 3413 */     this.returnAST = null;
/* 3414 */     ASTPair currentAST = new ASTPair();
/* 3415 */     AST atom_AST = null;
/* 3416 */     Token op = null;
/* 3417 */     AST op_AST = null;
/* 3418 */     Token lb = null;
/* 3419 */     AST lb_AST = null;
/*      */     try
/*      */     {
/* 3422 */       primaryExpression();
/* 3423 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*      */       for (;;)
/*      */       {
/* 3427 */         switch (LA(1))
/*      */         {
/*      */         case 15: 
/* 3430 */           AST tmp101_AST = null;
/* 3431 */           tmp101_AST = this.astFactory.create(LT(1));
/* 3432 */           this.astFactory.makeASTRoot(currentAST, tmp101_AST);
/* 3433 */           match(15);
/* 3434 */           identifier();
/* 3435 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */           
/* 3437 */           switch (LA(1))
/*      */           {
/*      */ 
/*      */           case 97: 
/* 3441 */             op = LT(1);
/* 3442 */             op_AST = this.astFactory.create(op);
/* 3443 */             this.astFactory.makeASTRoot(currentAST, op_AST);
/* 3444 */             match(97);
/* 3445 */             op_AST.setType(78);
/* 3446 */             exprList();
/* 3447 */             this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3448 */             match(98);
/*      */             
/* 3450 */             break;
/*      */           case 1: case 6: case 7: 
/*      */           case 8: case 10: case 14: 
/*      */           case 15: case 18: case 22: 
/*      */           case 23: case 24: case 25: 
/*      */           case 26: case 28: case 31: 
/*      */           case 32: case 33: case 34: 
/*      */           case 38: case 40: case 41: 
/*      */           case 44: case 50: case 53: 
/*      */           case 55: case 56: case 57: 
/*      */           case 58: case 64: case 95: 
/*      */           case 96: case 98: case 100: 
/*      */           case 101: case 102: case 103: 
/*      */           case 104: case 105: case 106: 
/*      */           case 107: case 108: case 109: 
/*      */           case 110: case 111: case 112: 
/*      */           case 113: case 114: 
/*      */             break;
/*      */           case 2: case 3: 
/*      */           case 4: case 5: 
/*      */           case 9: case 11: 
/*      */           case 12: case 13: 
/*      */           case 16: case 17: 
/*      */           case 19: case 20: 
/*      */           case 21: case 27: 
/*      */           case 29: case 30: 
/*      */           case 35: case 36: 
/*      */           case 37: case 39: 
/*      */           case 42: case 43: 
/*      */           case 45: case 46: 
/*      */           case 47: case 48: 
/*      */           case 49: case 51: 
/*      */           case 52: case 54: 
/*      */           case 59: case 60: 
/*      */           case 61: case 62: 
/*      */           case 63: case 65: 
/*      */           case 66: case 67: 
/*      */           case 68: case 69: 
/*      */           case 70: case 71: 
/*      */           case 72: case 73: 
/*      */           case 74: case 75: 
/*      */           case 76: case 77: 
/*      */           case 78: case 79: 
/*      */           case 80: case 81: 
/*      */           case 82: case 83: 
/*      */           case 84: case 85: 
/*      */           case 86: case 87: 
/*      */           case 88: case 89: 
/*      */           case 90: case 91: 
/*      */           case 92: 
/*      */           case 93: 
/*      */           case 94: 
/*      */           case 99: 
/*      */           default: 
/* 3504 */             throw new NoViableAltException(LT(1), getFilename());
/*      */           }
/*      */           
/*      */           
/*      */ 
/*      */ 
/*      */           break;
/*      */         case 113: 
/* 3512 */           lb = LT(1);
/* 3513 */           lb_AST = this.astFactory.create(lb);
/* 3514 */           this.astFactory.makeASTRoot(currentAST, lb_AST);
/* 3515 */           match(113);
/* 3516 */           lb_AST.setType(75);
/* 3517 */           expression();
/* 3518 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3519 */           match(114);
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3529 */       atom_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 3532 */       reportError(ex);
/* 3533 */       recover(ex, _tokenSet_31);
/*      */     }
/* 3535 */     this.returnAST = atom_AST;
/*      */   }
/*      */   
/*      */   public final void whenClause() throws RecognitionException, TokenStreamException
/*      */   {
/* 3540 */     this.returnAST = null;
/* 3541 */     ASTPair currentAST = new ASTPair();
/* 3542 */     AST whenClause_AST = null;
/*      */     
/*      */     try
/*      */     {
/* 3546 */       AST tmp104_AST = null;
/* 3547 */       tmp104_AST = this.astFactory.create(LT(1));
/* 3548 */       this.astFactory.makeASTRoot(currentAST, tmp104_AST);
/* 3549 */       match(58);
/* 3550 */       logicalExpression();
/* 3551 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3552 */       match(57);
/* 3553 */       unaryExpression();
/* 3554 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/* 3556 */       whenClause_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 3559 */       reportError(ex);
/* 3560 */       recover(ex, _tokenSet_33);
/*      */     }
/* 3562 */     this.returnAST = whenClause_AST;
/*      */   }
/*      */   
/*      */   public final void elseClause() throws RecognitionException, TokenStreamException
/*      */   {
/* 3567 */     this.returnAST = null;
/* 3568 */     ASTPair currentAST = new ASTPair();
/* 3569 */     AST elseClause_AST = null;
/*      */     
/*      */     try
/*      */     {
/* 3573 */       AST tmp106_AST = null;
/* 3574 */       tmp106_AST = this.astFactory.create(LT(1));
/* 3575 */       this.astFactory.makeASTRoot(currentAST, tmp106_AST);
/* 3576 */       match(56);
/* 3577 */       unaryExpression();
/* 3578 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/* 3580 */       elseClause_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 3583 */       reportError(ex);
/* 3584 */       recover(ex, _tokenSet_34);
/*      */     }
/* 3586 */     this.returnAST = elseClause_AST;
/*      */   }
/*      */   
/*      */   public final void altWhenClause() throws RecognitionException, TokenStreamException
/*      */   {
/* 3591 */     this.returnAST = null;
/* 3592 */     ASTPair currentAST = new ASTPair();
/* 3593 */     AST altWhenClause_AST = null;
/*      */     
/*      */     try
/*      */     {
/* 3597 */       AST tmp107_AST = null;
/* 3598 */       tmp107_AST = this.astFactory.create(LT(1));
/* 3599 */       this.astFactory.makeASTRoot(currentAST, tmp107_AST);
/* 3600 */       match(58);
/* 3601 */       unaryExpression();
/* 3602 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3603 */       match(57);
/* 3604 */       unaryExpression();
/* 3605 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/* 3607 */       altWhenClause_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 3610 */       reportError(ex);
/* 3611 */       recover(ex, _tokenSet_33);
/*      */     }
/* 3613 */     this.returnAST = altWhenClause_AST;
/*      */   }
/*      */   
/*      */   public final void collectionExpr() throws RecognitionException, TokenStreamException
/*      */   {
/* 3618 */     this.returnAST = null;
/* 3619 */     ASTPair currentAST = new ASTPair();
/* 3620 */     AST collectionExpr_AST = null;
/*      */     
/*      */     try
/*      */     {
/* 3624 */       switch (LA(1))
/*      */       {
/*      */       case 17: 
/* 3627 */         AST tmp109_AST = null;
/* 3628 */         tmp109_AST = this.astFactory.create(LT(1));
/* 3629 */         this.astFactory.makeASTRoot(currentAST, tmp109_AST);
/* 3630 */         match(17);
/* 3631 */         break;
/*      */       
/*      */ 
/*      */       case 27: 
/* 3635 */         AST tmp110_AST = null;
/* 3636 */         tmp110_AST = this.astFactory.create(LT(1));
/* 3637 */         this.astFactory.makeASTRoot(currentAST, tmp110_AST);
/* 3638 */         match(27);
/* 3639 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 3643 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/* 3647 */       match(97);
/* 3648 */       path();
/* 3649 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3650 */       match(98);
/* 3651 */       collectionExpr_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 3654 */       reportError(ex);
/* 3655 */       recover(ex, _tokenSet_11);
/*      */     }
/* 3657 */     this.returnAST = collectionExpr_AST;
/*      */   }
/*      */   
/*      */   public final void subQuery() throws RecognitionException, TokenStreamException
/*      */   {
/* 3662 */     this.returnAST = null;
/* 3663 */     ASTPair currentAST = new ASTPair();
/* 3664 */     AST subQuery_AST = null;
/*      */     try
/*      */     {
/* 3667 */       union();
/* 3668 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3669 */       subQuery_AST = currentAST.root;
/* 3670 */       subQuery_AST = this.astFactory.make(new ASTArray(2).add(this.astFactory.create(83, "query")).add(subQuery_AST));
/* 3671 */       currentAST.root = subQuery_AST;
/* 3672 */       currentAST.child = ((subQuery_AST != null) && (subQuery_AST.getFirstChild() != null) ? subQuery_AST.getFirstChild() : subQuery_AST);
/*      */       
/* 3674 */       currentAST.advanceChildToEnd();
/* 3675 */       subQuery_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 3678 */       reportError(ex);
/* 3679 */       recover(ex, _tokenSet_13);
/*      */     }
/* 3681 */     this.returnAST = subQuery_AST;
/*      */   }
/*      */   
/*      */   public final void exprList() throws RecognitionException, TokenStreamException
/*      */   {
/* 3686 */     this.returnAST = null;
/* 3687 */     ASTPair currentAST = new ASTPair();
/* 3688 */     AST exprList_AST = null;
/* 3689 */     Token t = null;
/* 3690 */     AST t_AST = null;
/* 3691 */     Token l = null;
/* 3692 */     AST l_AST = null;
/* 3693 */     Token b = null;
/* 3694 */     AST b_AST = null;
/*      */     
/* 3696 */     AST trimSpec = null;
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 3701 */       switch (LA(1))
/*      */       {
/*      */       case 67: 
/* 3704 */         t = LT(1);
/* 3705 */         t_AST = this.astFactory.create(t);
/* 3706 */         this.astFactory.addASTChild(currentAST, t_AST);
/* 3707 */         match(67);
/* 3708 */         trimSpec = t_AST;
/* 3709 */         break;
/*      */       
/*      */ 
/*      */       case 63: 
/* 3713 */         l = LT(1);
/* 3714 */         l_AST = this.astFactory.create(l);
/* 3715 */         this.astFactory.addASTChild(currentAST, l_AST);
/* 3716 */         match(63);
/* 3717 */         trimSpec = l_AST;
/* 3718 */         break;
/*      */       
/*      */ 
/*      */       case 61: 
/* 3722 */         b = LT(1);
/* 3723 */         b_AST = this.astFactory.create(b);
/* 3724 */         this.astFactory.addASTChild(currentAST, b_AST);
/* 3725 */         match(61);
/* 3726 */         trimSpec = b_AST;
/* 3727 */         break;
/*      */       case 4: case 5: case 9: case 12: case 17: case 19: case 20: case 22: case 27: case 35: case 36: case 38: case 39: case 47: case 48: case 49: case 54: case 62: case 92: case 93: case 94: case 97: case 98: case 109: case 110: case 115: case 116: case 117: case 118: case 119: 
/*      */         break;
/*      */       case 6: case 7: case 8: 
/*      */       case 10: case 11: case 13: 
/*      */       case 14: case 15: case 16: 
/*      */       case 18: case 21: case 23: 
/*      */       case 24: case 25: case 26: 
/*      */       case 28: case 29: case 30: 
/*      */       case 31: case 32: case 33: 
/*      */       case 34: case 37: case 40: 
/*      */       case 41: case 42: case 43: 
/*      */       case 44: case 45: case 46: 
/*      */       case 50: case 51: case 52: 
/*      */       case 53: case 55: case 56: 
/*      */       case 57: case 58: case 59: 
/*      */       case 60: case 64: case 65: 
/*      */       case 66: case 68: case 69: 
/*      */       case 70: case 71: case 72: 
/*      */       case 73: case 74: 
/*      */       case 75: case 76: 
/*      */       case 77: case 78: 
/*      */       case 79: case 80: 
/*      */       case 81: case 82: 
/*      */       case 83: case 84: 
/*      */       case 85: case 86: 
/*      */       case 87: case 88: 
/*      */       case 89: case 90: 
/*      */       case 91: case 95: 
/*      */       case 96: case 99: 
/*      */       case 100: case 101: 
/*      */       case 102: case 103: 
/*      */       case 104: case 105: 
/*      */       case 106: case 107: 
/*      */       case 108: case 111: 
/*      */       case 112: case 113: 
/*      */       case 114: default: 
/* 3764 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/* 3768 */       if (trimSpec != null) { trimSpec.setType(119);
/*      */       }
/* 3770 */       switch (LA(1))
/*      */       {
/*      */       case 4: 
/*      */       case 5: 
/*      */       case 9: 
/*      */       case 12: 
/*      */       case 17: 
/*      */       case 19: 
/*      */       case 20: 
/*      */       case 27: 
/*      */       case 35: 
/*      */       case 36: 
/*      */       case 38: 
/*      */       case 39: 
/*      */       case 47: 
/*      */       case 48: 
/*      */       case 49: 
/*      */       case 54: 
/*      */       case 62: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 97: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 115: 
/*      */       case 116: 
/*      */       case 117: 
/*      */       case 118: 
/*      */       case 119: 
/* 3800 */         expression();
/* 3801 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */         
/* 3803 */         switch (LA(1))
/*      */         {
/*      */ 
/*      */         case 95: 
/* 3807 */           int _cnt185 = 0;
/*      */           for (;;)
/*      */           {
/* 3810 */             if (LA(1) == 95) {
/* 3811 */               match(95);
/* 3812 */               expression();
/* 3813 */               this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */             }
/*      */             else {
/* 3816 */               if (_cnt185 >= 1) break; throw new NoViableAltException(LT(1), getFilename());
/*      */             }
/*      */             
/* 3819 */             _cnt185++;
/*      */           }
/*      */           
/* 3822 */           break;
/*      */         
/*      */ 
/*      */         case 22: 
/* 3826 */           AST tmp114_AST = null;
/* 3827 */           tmp114_AST = this.astFactory.create(LT(1));
/* 3828 */           this.astFactory.addASTChild(currentAST, tmp114_AST);
/* 3829 */           match(22);
/* 3830 */           tmp114_AST.setType(119);
/* 3831 */           expression();
/* 3832 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3833 */           break;
/*      */         
/*      */ 
/*      */         case 7: 
/* 3837 */           match(7);
/* 3838 */           identifier();
/* 3839 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3840 */           break;
/*      */         
/*      */ 
/*      */         case 98: 
/*      */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 3848 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         }
/*      */         
/*      */         
/*      */ 
/*      */ 
/*      */         break;
/*      */       case 22: 
/* 3856 */         AST tmp116_AST = null;
/* 3857 */         tmp116_AST = this.astFactory.create(LT(1));
/* 3858 */         this.astFactory.addASTChild(currentAST, tmp116_AST);
/* 3859 */         match(22);
/* 3860 */         tmp116_AST.setType(119);
/* 3861 */         expression();
/* 3862 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3863 */         break;
/*      */       case 98: 
/*      */         break;
/*      */       case 6: case 7: case 8: case 10: case 11: case 13: case 14: case 15: case 16: case 18: case 21: case 23: case 24: case 25: case 26: case 28: case 29: case 30: 
/*      */       case 31: case 32: case 33: case 34: case 37: case 40: case 41: case 42: case 43: case 44: case 45: case 46: case 50: case 51: case 52: case 53: case 55: case 56: 
/*      */       case 57: case 58: case 59: case 60: case 61: case 63: case 64: case 65: case 66: case 67: case 68: case 69: case 70: case 71: case 72: case 73: case 74: 
/*      */       case 75: case 76: case 77: case 78: case 79: case 80: case 81: case 82: case 83: case 84: case 85: case 86: case 87: case 88: case 89: case 90: case 91: 
/*      */       case 95: case 96: case 99: case 100: case 101: case 102: case 103: case 104: case 105: case 106: case 107: case 108: case 111: case 112: case 113: case 114: default: 
/* 3871 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/* 3875 */       exprList_AST = currentAST.root;
/* 3876 */       exprList_AST = this.astFactory.make(new ASTArray(2).add(this.astFactory.create(72, "exprList")).add(exprList_AST));
/* 3877 */       currentAST.root = exprList_AST;
/* 3878 */       currentAST.child = ((exprList_AST != null) && (exprList_AST.getFirstChild() != null) ? exprList_AST.getFirstChild() : exprList_AST);
/*      */       
/* 3880 */       currentAST.advanceChildToEnd();
/* 3881 */       exprList_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 3884 */       reportError(ex);
/* 3885 */       recover(ex, _tokenSet_13);
/*      */     }
/* 3887 */     this.returnAST = exprList_AST;
/*      */   }
/*      */   
/*      */   public final void identPrimary() throws RecognitionException, TokenStreamException
/*      */   {
/* 3892 */     this.returnAST = null;
/* 3893 */     ASTPair currentAST = new ASTPair();
/* 3894 */     AST identPrimary_AST = null;
/* 3895 */     Token o = null;
/* 3896 */     AST o_AST = null;
/* 3897 */     Token op = null;
/* 3898 */     AST op_AST = null;
/*      */     try
/*      */     {
/* 3901 */       switch (LA(1))
/*      */       {
/*      */       case 119: 
/* 3904 */         identifier();
/* 3905 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3906 */         handleDotIdent();
/*      */         
/*      */ 
/*      */ 
/* 3910 */         while ((LA(1) == 15) && ((LA(2) == 17) || (LA(2) == 65) || (LA(2) == 119)) && (_tokenSet_35.member(LA(3)))) {
/* 3911 */           AST tmp117_AST = null;
/* 3912 */           tmp117_AST = this.astFactory.create(LT(1));
/* 3913 */           this.astFactory.makeASTRoot(currentAST, tmp117_AST);
/* 3914 */           match(15);
/*      */           
/* 3916 */           switch (LA(1))
/*      */           {
/*      */           case 119: 
/* 3919 */             identifier();
/* 3920 */             this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3921 */             break;
/*      */           
/*      */ 
/*      */           case 17: 
/* 3925 */             AST tmp118_AST = null;
/* 3926 */             tmp118_AST = this.astFactory.create(LT(1));
/* 3927 */             this.astFactory.addASTChild(currentAST, tmp118_AST);
/* 3928 */             match(17);
/* 3929 */             break;
/*      */           
/*      */ 
/*      */           case 65: 
/* 3933 */             o = LT(1);
/* 3934 */             o_AST = this.astFactory.create(o);
/* 3935 */             this.astFactory.addASTChild(currentAST, o_AST);
/* 3936 */             match(65);
/* 3937 */             o_AST.setType(119);
/* 3938 */             break;
/*      */           
/*      */ 
/*      */           default: 
/* 3942 */             throw new NoViableAltException(LT(1), getFilename());
/*      */           }
/*      */           
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3954 */         switch (LA(1))
/*      */         {
/*      */ 
/*      */         case 97: 
/* 3958 */           op = LT(1);
/* 3959 */           op_AST = this.astFactory.create(op);
/* 3960 */           this.astFactory.makeASTRoot(currentAST, op_AST);
/* 3961 */           match(97);
/* 3962 */           op_AST.setType(78);
/* 3963 */           exprList();
/* 3964 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3965 */           match(98);
/*      */           
/* 3967 */           break;
/*      */         case 1: case 6: case 7: 
/*      */         case 8: case 10: case 14: 
/*      */         case 15: case 18: case 22: 
/*      */         case 23: case 24: case 25: 
/*      */         case 26: case 28: case 31: 
/*      */         case 32: case 33: case 34: 
/*      */         case 38: case 40: case 41: 
/*      */         case 44: case 50: case 53: 
/*      */         case 55: case 56: case 57: 
/*      */         case 58: case 64: case 95: 
/*      */         case 96: case 98: case 100: 
/*      */         case 101: case 102: case 103: 
/*      */         case 104: case 105: case 106: 
/*      */         case 107: case 108: case 109: 
/*      */         case 110: case 111: case 112: 
/*      */         case 113: case 114: 
/*      */           break;
/*      */         case 2: case 3: 
/*      */         case 4: case 5: 
/*      */         case 9: case 11: 
/*      */         case 12: case 13: 
/*      */         case 16: case 17: 
/*      */         case 19: case 20: 
/*      */         case 21: case 27: 
/*      */         case 29: case 30: 
/*      */         case 35: case 36: 
/*      */         case 37: case 39: 
/*      */         case 42: case 43: 
/*      */         case 45: case 46: 
/*      */         case 47: case 48: 
/*      */         case 49: case 51: 
/*      */         case 52: case 54: 
/*      */         case 59: case 60: 
/*      */         case 61: case 62: 
/*      */         case 63: case 65: 
/*      */         case 66: case 67: 
/*      */         case 68: case 69: 
/*      */         case 70: case 71: 
/*      */         case 72: case 73: 
/*      */         case 74: case 75: 
/*      */         case 76: case 77: 
/*      */         case 78: case 79: 
/*      */         case 80: case 81: 
/*      */         case 82: case 83: 
/*      */         case 84: case 85: 
/*      */         case 86: case 87: 
/*      */         case 88: case 89: 
/*      */         case 90: case 91: 
/*      */         case 92: 
/*      */         case 93: 
/*      */         case 94: 
/*      */         case 99: 
/*      */         default: 
/* 4021 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         }
/*      */         
/*      */         
/* 4025 */         identPrimary_AST = currentAST.root;
/* 4026 */         break;
/*      */       
/*      */ 
/*      */       case 9: 
/*      */       case 12: 
/*      */       case 17: 
/*      */       case 27: 
/*      */       case 35: 
/*      */       case 36: 
/*      */       case 48: 
/* 4036 */         aggregate();
/* 4037 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4038 */         identPrimary_AST = currentAST.root;
/* 4039 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 4043 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 4048 */       reportError(ex);
/* 4049 */       recover(ex, _tokenSet_11);
/*      */     }
/* 4051 */     this.returnAST = identPrimary_AST;
/*      */   }
/*      */   
/*      */   public final void constant() throws RecognitionException, TokenStreamException
/*      */   {
/* 4056 */     this.returnAST = null;
/* 4057 */     ASTPair currentAST = new ASTPair();
/* 4058 */     AST constant_AST = null;
/*      */     try
/*      */     {
/* 4061 */       switch (LA(1))
/*      */       {
/*      */       case 117: 
/* 4064 */         AST tmp120_AST = null;
/* 4065 */         tmp120_AST = this.astFactory.create(LT(1));
/* 4066 */         this.astFactory.addASTChild(currentAST, tmp120_AST);
/* 4067 */         match(117);
/* 4068 */         constant_AST = currentAST.root;
/* 4069 */         break;
/*      */       
/*      */ 
/*      */       case 93: 
/* 4073 */         AST tmp121_AST = null;
/* 4074 */         tmp121_AST = this.astFactory.create(LT(1));
/* 4075 */         this.astFactory.addASTChild(currentAST, tmp121_AST);
/* 4076 */         match(93);
/* 4077 */         constant_AST = currentAST.root;
/* 4078 */         break;
/*      */       
/*      */ 
/*      */       case 94: 
/* 4082 */         AST tmp122_AST = null;
/* 4083 */         tmp122_AST = this.astFactory.create(LT(1));
/* 4084 */         this.astFactory.addASTChild(currentAST, tmp122_AST);
/* 4085 */         match(94);
/* 4086 */         constant_AST = currentAST.root;
/* 4087 */         break;
/*      */       
/*      */ 
/*      */       case 92: 
/* 4091 */         AST tmp123_AST = null;
/* 4092 */         tmp123_AST = this.astFactory.create(LT(1));
/* 4093 */         this.astFactory.addASTChild(currentAST, tmp123_AST);
/* 4094 */         match(92);
/* 4095 */         constant_AST = currentAST.root;
/* 4096 */         break;
/*      */       
/*      */ 
/*      */       case 118: 
/* 4100 */         AST tmp124_AST = null;
/* 4101 */         tmp124_AST = this.astFactory.create(LT(1));
/* 4102 */         this.astFactory.addASTChild(currentAST, tmp124_AST);
/* 4103 */         match(118);
/* 4104 */         constant_AST = currentAST.root;
/* 4105 */         break;
/*      */       
/*      */ 
/*      */       case 39: 
/* 4109 */         AST tmp125_AST = null;
/* 4110 */         tmp125_AST = this.astFactory.create(LT(1));
/* 4111 */         this.astFactory.addASTChild(currentAST, tmp125_AST);
/* 4112 */         match(39);
/* 4113 */         constant_AST = currentAST.root;
/* 4114 */         break;
/*      */       
/*      */ 
/*      */       case 49: 
/* 4118 */         AST tmp126_AST = null;
/* 4119 */         tmp126_AST = this.astFactory.create(LT(1));
/* 4120 */         this.astFactory.addASTChild(currentAST, tmp126_AST);
/* 4121 */         match(49);
/* 4122 */         constant_AST = currentAST.root;
/* 4123 */         break;
/*      */       
/*      */ 
/*      */       case 20: 
/* 4127 */         AST tmp127_AST = null;
/* 4128 */         tmp127_AST = this.astFactory.create(LT(1));
/* 4129 */         this.astFactory.addASTChild(currentAST, tmp127_AST);
/* 4130 */         match(20);
/* 4131 */         constant_AST = currentAST.root;
/* 4132 */         break;
/*      */       
/*      */ 
/*      */       case 62: 
/* 4136 */         AST tmp128_AST = null;
/* 4137 */         tmp128_AST = this.astFactory.create(LT(1));
/* 4138 */         this.astFactory.addASTChild(currentAST, tmp128_AST);
/* 4139 */         match(62);
/* 4140 */         constant_AST = currentAST.root;
/* 4141 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 4145 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 4150 */       reportError(ex);
/* 4151 */       recover(ex, _tokenSet_11);
/*      */     }
/* 4153 */     this.returnAST = constant_AST;
/*      */   }
/*      */   
/*      */   public final void expressionOrVector() throws RecognitionException, TokenStreamException
/*      */   {
/* 4158 */     this.returnAST = null;
/* 4159 */     ASTPair currentAST = new ASTPair();
/* 4160 */     AST expressionOrVector_AST = null;
/* 4161 */     AST e_AST = null;
/* 4162 */     AST v_AST = null;
/*      */     try
/*      */     {
/* 4165 */       expression();
/* 4166 */       e_AST = this.returnAST;
/*      */       
/* 4168 */       switch (LA(1))
/*      */       {
/*      */       case 95: 
/* 4171 */         vectorExpr();
/* 4172 */         v_AST = this.returnAST;
/* 4173 */         break;
/*      */       
/*      */ 
/*      */       case 98: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 4181 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */       
/* 4185 */       expressionOrVector_AST = currentAST.root;
/*      */       
/*      */ 
/* 4188 */       if (v_AST != null) {
/* 4189 */         expressionOrVector_AST = this.astFactory.make(new ASTArray(3).add(this.astFactory.create(89, "{vector}")).add(e_AST).add(v_AST));
/*      */       } else {
/* 4191 */         expressionOrVector_AST = e_AST;
/*      */       }
/* 4193 */       currentAST.root = expressionOrVector_AST;
/* 4194 */       currentAST.child = ((expressionOrVector_AST != null) && (expressionOrVector_AST.getFirstChild() != null) ? expressionOrVector_AST.getFirstChild() : expressionOrVector_AST);
/*      */       
/* 4196 */       currentAST.advanceChildToEnd();
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 4199 */       reportError(ex);
/* 4200 */       recover(ex, _tokenSet_13);
/*      */     }
/* 4202 */     this.returnAST = expressionOrVector_AST;
/*      */   }
/*      */   
/*      */   public final void vectorExpr() throws RecognitionException, TokenStreamException
/*      */   {
/* 4207 */     this.returnAST = null;
/* 4208 */     ASTPair currentAST = new ASTPair();
/* 4209 */     AST vectorExpr_AST = null;
/*      */     try
/*      */     {
/* 4212 */       match(95);
/* 4213 */       expression();
/* 4214 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*      */ 
/*      */ 
/* 4218 */       while (LA(1) == 95) {
/* 4219 */         match(95);
/* 4220 */         expression();
/* 4221 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4229 */       vectorExpr_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 4232 */       reportError(ex);
/* 4233 */       recover(ex, _tokenSet_13);
/*      */     }
/* 4235 */     this.returnAST = vectorExpr_AST;
/*      */   }
/*      */   
/*      */   public final void aggregate() throws RecognitionException, TokenStreamException
/*      */   {
/* 4240 */     this.returnAST = null;
/* 4241 */     ASTPair currentAST = new ASTPair();
/* 4242 */     AST aggregate_AST = null;
/*      */     try
/*      */     {
/* 4245 */       switch (LA(1))
/*      */       {
/*      */ 
/*      */       case 9: 
/*      */       case 35: 
/*      */       case 36: 
/*      */       case 48: 
/* 4252 */         switch (LA(1))
/*      */         {
/*      */         case 48: 
/* 4255 */           AST tmp131_AST = null;
/* 4256 */           tmp131_AST = this.astFactory.create(LT(1));
/* 4257 */           this.astFactory.makeASTRoot(currentAST, tmp131_AST);
/* 4258 */           match(48);
/* 4259 */           break;
/*      */         
/*      */ 
/*      */         case 9: 
/* 4263 */           AST tmp132_AST = null;
/* 4264 */           tmp132_AST = this.astFactory.create(LT(1));
/* 4265 */           this.astFactory.makeASTRoot(currentAST, tmp132_AST);
/* 4266 */           match(9);
/* 4267 */           break;
/*      */         
/*      */ 
/*      */         case 35: 
/* 4271 */           AST tmp133_AST = null;
/* 4272 */           tmp133_AST = this.astFactory.create(LT(1));
/* 4273 */           this.astFactory.makeASTRoot(currentAST, tmp133_AST);
/* 4274 */           match(35);
/* 4275 */           break;
/*      */         
/*      */ 
/*      */         case 36: 
/* 4279 */           AST tmp134_AST = null;
/* 4280 */           tmp134_AST = this.astFactory.create(LT(1));
/* 4281 */           this.astFactory.makeASTRoot(currentAST, tmp134_AST);
/* 4282 */           match(36);
/* 4283 */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 4287 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         }
/*      */         
/*      */         
/* 4291 */         match(97);
/* 4292 */         additiveExpression();
/* 4293 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4294 */         match(98);
/* 4295 */         aggregate_AST = currentAST.root;
/* 4296 */         aggregate_AST.setType(68);
/* 4297 */         aggregate_AST = currentAST.root;
/* 4298 */         break;
/*      */       
/*      */ 
/*      */       case 12: 
/* 4302 */         AST tmp137_AST = null;
/* 4303 */         tmp137_AST = this.astFactory.create(LT(1));
/* 4304 */         this.astFactory.makeASTRoot(currentAST, tmp137_AST);
/* 4305 */         match(12);
/* 4306 */         match(97);
/*      */         
/* 4308 */         switch (LA(1))
/*      */         {
/*      */         case 111: 
/* 4311 */           AST tmp139_AST = null;
/* 4312 */           tmp139_AST = this.astFactory.create(LT(1));
/* 4313 */           this.astFactory.addASTChild(currentAST, tmp139_AST);
/* 4314 */           match(111);
/* 4315 */           tmp139_AST.setType(85);
/* 4316 */           break;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */         case 4: 
/*      */         case 16: 
/*      */         case 17: 
/*      */         case 27: 
/*      */         case 119: 
/* 4326 */           switch (LA(1))
/*      */           {
/*      */           case 16: 
/* 4329 */             AST tmp140_AST = null;
/* 4330 */             tmp140_AST = this.astFactory.create(LT(1));
/* 4331 */             this.astFactory.addASTChild(currentAST, tmp140_AST);
/* 4332 */             match(16);
/* 4333 */             break;
/*      */           
/*      */ 
/*      */           case 4: 
/* 4337 */             AST tmp141_AST = null;
/* 4338 */             tmp141_AST = this.astFactory.create(LT(1));
/* 4339 */             this.astFactory.addASTChild(currentAST, tmp141_AST);
/* 4340 */             match(4);
/* 4341 */             break;
/*      */           
/*      */ 
/*      */           case 17: 
/*      */           case 27: 
/*      */           case 119: 
/*      */             break;
/*      */           
/*      */ 
/*      */           default: 
/* 4351 */             throw new NoViableAltException(LT(1), getFilename());
/*      */           }
/*      */           
/*      */           
/*      */ 
/* 4356 */           switch (LA(1))
/*      */           {
/*      */           case 119: 
/* 4359 */             path();
/* 4360 */             this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4361 */             break;
/*      */           
/*      */ 
/*      */           case 17: 
/*      */           case 27: 
/* 4366 */             collectionExpr();
/* 4367 */             this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4368 */             break;
/*      */           
/*      */ 
/*      */           default: 
/* 4372 */             throw new NoViableAltException(LT(1), getFilename());
/*      */           }
/*      */           
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */           break;
/*      */         default: 
/* 4381 */           throw new NoViableAltException(LT(1), getFilename());
/*      */         }
/*      */         
/*      */         
/* 4385 */         match(98);
/* 4386 */         aggregate_AST = currentAST.root;
/* 4387 */         break;
/*      */       
/*      */ 
/*      */       case 17: 
/*      */       case 27: 
/* 4392 */         collectionExpr();
/* 4393 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4394 */         aggregate_AST = currentAST.root;
/* 4395 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 4399 */         throw new NoViableAltException(LT(1), getFilename());
/*      */       }
/*      */       
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 4404 */       reportError(ex);
/* 4405 */       recover(ex, _tokenSet_11);
/*      */     }
/* 4407 */     this.returnAST = aggregate_AST;
/*      */   }
/*      */   
/*      */ 
/* 4411 */   public static final String[] _tokenNames = { "<0>", "EOF", "<2>", "NULL_TREE_LOOKAHEAD", "\"all\"", "\"any\"", "\"and\"", "\"as\"", "\"asc\"", "\"avg\"", "\"between\"", "\"class\"", "\"count\"", "\"delete\"", "\"desc\"", "DOT", "\"distinct\"", "\"elements\"", "\"escape\"", "\"exists\"", "\"false\"", "\"fetch\"", "\"from\"", "\"full\"", "\"group\"", "\"having\"", "\"in\"", "\"indices\"", "\"inner\"", "\"insert\"", "\"into\"", "\"is\"", "\"join\"", "\"left\"", "\"like\"", "\"max\"", "\"min\"", "\"new\"", "\"not\"", "\"null\"", "\"or\"", "\"order\"", "\"outer\"", "\"properties\"", "\"right\"", "\"select\"", "\"set\"", "\"some\"", "\"sum\"", "\"true\"", "\"union\"", "\"update\"", "\"versioned\"", "\"where\"", "\"case\"", "\"end\"", "\"else\"", "\"then\"", "\"when\"", "\"on\"", "\"with\"", "\"both\"", "\"empty\"", "\"leading\"", "\"member\"", "\"object\"", "\"of\"", "\"trailing\"", "AGGREGATE", "ALIAS", "CONSTRUCTOR", "CASE2", "EXPR_LIST", "FILTER_ENTITY", "IN_LIST", "INDEX_OP", "IS_NOT_NULL", "IS_NULL", "METHOD_CALL", "NOT_BETWEEN", "NOT_IN", "NOT_LIKE", "ORDER_ELEMENT", "QUERY", "RANGE", "ROW_STAR", "SELECT_FROM", "UNARY_MINUS", "UNARY_PLUS", "VECTOR_EXPR", "WEIRD_IDENT", "CONSTANT", "NUM_DOUBLE", "NUM_FLOAT", "NUM_LONG", "COMMA", "EQ", "OPEN", "CLOSE", "\"by\"", "\"ascending\"", "\"descending\"", "NE", "SQL_NE", "LT", "GT", "LE", "GE", "CONCAT", "PLUS", "MINUS", "STAR", "DIV", "OPEN_BRACKET", "CLOSE_BRACKET", "COLON", "PARAM", "NUM_INT", "QUOTED_STRING", "IDENT", "ID_START_LETTER", "ID_LETTER", "ESCqs", "WS", "HEX_DIGIT", "EXPONENT", "FLOAT_SUFFIX" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void buildTokenTypeASTClassMap()
/*      */   {
/* 4542 */     this.tokenTypeToASTClassMap = null;
/*      */   }
/*      */   
/*      */   private static final long[] mk_tokenSet_0() {
/* 4546 */     long[] data = { 2L, 0L };
/* 4547 */     return data; }
/*      */   
/* 4549 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*      */   
/* 4551 */   private static final long[] mk_tokenSet_1() { long[] data = { 9077567998918658L, 0L };
/* 4552 */     return data; }
/*      */   
/* 4554 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*      */   
/* 4556 */   private static final long[] mk_tokenSet_2() { long[] data = { 9007199254740994L, 0L };
/* 4557 */     return data; }
/*      */   
/* 4559 */   public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
/*      */   
/* 4561 */   private static final long[] mk_tokenSet_3() { long[] data = { 1128098946875394L, 17179869184L, 0L, 0L };
/* 4562 */     return data; }
/*      */   
/* 4564 */   public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
/*      */   
/* 4566 */   private static final long[] mk_tokenSet_4() { long[] data = { 9007199254740994L, 2147483648L, 0L, 0L };
/* 4567 */     return data; }
/*      */   
/* 4569 */   public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
/*      */   
/* 4571 */   private static final long[] mk_tokenSet_5() { long[] data = { 0L, 4294967296L, 0L, 0L };
/* 4572 */     return data; }
/*      */   
/* 4574 */   public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
/*      */   
/* 4576 */   private static final long[] mk_tokenSet_6() { long[] data = { 1307261066675241410L, 37155759930212352L, 0L, 0L };
/* 4577 */     return data; }
/*      */   
/* 4579 */   public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
/*      */   
/* 4581 */   private static final long[] mk_tokenSet_7() { long[] data = { 154269485447267778L, 1143446995730433L, 0L, 0L };
/* 4582 */     return data; }
/*      */   
/* 4584 */   public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
/*      */   
/* 4586 */   private static final long[] mk_tokenSet_8() { long[] data = { 1163144776902508546L, 19327352832L, 0L, 0L };
/* 4587 */     return data; }
/*      */   
/* 4589 */   public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
/*      */   
/* 4591 */   private static final long[] mk_tokenSet_9() { long[] data = { 1125899906842626L, 17179869184L, 0L, 0L };
/* 4592 */     return data; }
/*      */   
/* 4594 */   public static final BitSet _tokenSet_9 = new BitSet(mk_tokenSet_9());
/*      */   
/* 4596 */   private static final long[] mk_tokenSet_10() { long[] data = { 9044582671056898L, 0L };
/* 4597 */     return data; }
/*      */   
/* 4599 */   public static final BitSet _tokenSet_10 = new BitSet(mk_tokenSet_10());
/*      */   
/* 4601 */   private static final long[] mk_tokenSet_11() { long[] data = { 550586252655904194L, 2251754716528641L, 0L, 0L };
/* 4602 */     return data; }
/*      */   
/* 4604 */   public static final BitSet _tokenSet_11 = new BitSet(mk_tokenSet_11());
/*      */   
/* 4606 */   private static final long[] mk_tokenSet_12() { long[] data = { 5181312067402913778L, 72057593769492485L, 0L, 0L };
/* 4607 */     return data; }
/*      */   
/* 4609 */   public static final BitSet _tokenSet_12 = new BitSet(mk_tokenSet_12());
/*      */   
/* 4611 */   private static final long[] mk_tokenSet_13() { long[] data = { 0L, 17179869184L, 0L, 0L };
/* 4612 */     return data; }
/*      */   
/* 4614 */   public static final BitSet _tokenSet_13 = new BitSet(mk_tokenSet_13());
/*      */   
/* 4616 */   private static final long[] mk_tokenSet_14() { long[] data = { 10135298201616386L, 17179869184L, 0L, 0L };
/* 4617 */     return data; }
/*      */   
/* 4619 */   public static final BitSet _tokenSet_14 = new BitSet(mk_tokenSet_14());
/*      */   
/* 4621 */   private static final long[] mk_tokenSet_15() { long[] data = { 1128098930098178L, 17179869184L, 0L, 0L };
/* 4622 */     return data; }
/*      */   
/* 4624 */   public static final BitSet _tokenSet_15 = new BitSet(mk_tokenSet_15());
/*      */   
/* 4626 */   private static final long[] mk_tokenSet_16() { long[] data = { 10135298205810690L, 17179869184L, 0L, 0L };
/* 4627 */     return data; }
/*      */   
/* 4629 */   public static final BitSet _tokenSet_16 = new BitSet(mk_tokenSet_16());
/*      */   
/* 4631 */   private static final long[] mk_tokenSet_17() { long[] data = { 10152903551516802L, 36028816346316800L, 0L, 0L };
/* 4632 */     return data; }
/*      */   
/* 4634 */   public static final BitSet _tokenSet_17 = new BitSet(mk_tokenSet_17());
/*      */   
/* 4636 */   private static final long[] mk_tokenSet_18() { long[] data = { 10152903549386754L, 19327352832L, 0L, 0L };
/* 4637 */     return data; }
/*      */   
/* 4639 */   public static final BitSet _tokenSet_18 = new BitSet(mk_tokenSet_18());
/*      */   
/* 4641 */   private static final long[] mk_tokenSet_19() { long[] data = { 1163074408156233730L, 19327352832L, 0L, 0L };
/* 4642 */     return data; }
/*      */   
/* 4644 */   public static final BitSet _tokenSet_19 = new BitSet(mk_tokenSet_19());
/*      */   
/* 4646 */   private static final long[] mk_tokenSet_20() { long[] data = { 154268091625242626L, 19327352832L, 0L, 0L };
/* 4647 */     return data; }
/*      */   
/* 4649 */   public static final BitSet _tokenSet_20 = new BitSet(mk_tokenSet_20());
/*      */   
/* 4651 */   private static final long[] mk_tokenSet_21() { long[] data = { 1163144776969617410L, 19327352832L, 0L, 0L };
/* 4652 */     return data; }
/*      */   
/* 4654 */   public static final BitSet _tokenSet_21 = new BitSet(mk_tokenSet_21());
/*      */   
/* 4656 */   private static final long[] mk_tokenSet_22() { long[] data = { 154268091663008130L, 1126125392625664L, 0L, 0L };
/* 4657 */     return data; }
/*      */   
/* 4659 */   public static final BitSet _tokenSet_22 = new BitSet(mk_tokenSet_22());
/*      */   
/* 4661 */   private static final long[] mk_tokenSet_23() { long[] data = { 1125899906842626L, 19327352832L, 0L, 0L };
/* 4662 */     return data; }
/*      */   
/* 4664 */   public static final BitSet _tokenSet_23 = new BitSet(mk_tokenSet_23());
/*      */   
/* 4666 */   private static final long[] mk_tokenSet_24() { long[] data = { 10135298205810690L, 19327352832L, 0L, 0L };
/* 4667 */     return data; }
/*      */   
/* 4669 */   public static final BitSet _tokenSet_24 = new BitSet(mk_tokenSet_24());
/*      */   
/* 4671 */   private static final long[] mk_tokenSet_25() { long[] data = { 154269191174635906L, 1126125392625664L, 0L, 0L };
/* 4672 */     return data; }
/*      */   
/* 4674 */   public static final BitSet _tokenSet_25 = new BitSet(mk_tokenSet_25());
/*      */   
/* 4676 */   private static final long[] mk_tokenSet_26() { long[] data = { 154269191174635970L, 1126125392625664L, 0L, 0L };
/* 4677 */     return data; }
/*      */   
/* 4679 */   public static final BitSet _tokenSet_26 = new BitSet(mk_tokenSet_26());
/*      */   
/* 4681 */   private static final long[] mk_tokenSet_27() { long[] data = { 2147483648L, 828928688128L, 0L, 0L };
/* 4682 */     return data; }
/*      */   
/* 4684 */   public static final BitSet _tokenSet_27 = new BitSet(mk_tokenSet_27());
/*      */   
/* 4686 */   private static final long[] mk_tokenSet_28() { long[] data = { 154269193322119618L, 1126954321313792L, 0L, 0L };
/* 4687 */     return data; }
/*      */   
/* 4689 */   public static final BitSet _tokenSet_28 = new BitSet(mk_tokenSet_28());
/*      */   
/* 4691 */   private static final long[] mk_tokenSet_29() { long[] data = { 154269485447267778L, 1161039181774849L, 0L, 0L };
/* 4692 */     return data; }
/*      */   
/* 4694 */   public static final BitSet _tokenSet_29 = new BitSet(mk_tokenSet_29());
/*      */   
/* 4696 */   private static final long[] mk_tokenSet_30() { long[] data = { 154269485447267778L, 1266592298041345L, 0L, 0L };
/* 4697 */     return data; }
/*      */   
/* 4699 */   public static final BitSet _tokenSet_30 = new BitSet(mk_tokenSet_30());
/*      */   
/* 4701 */   private static final long[] mk_tokenSet_31() { long[] data = { 550586252655871426L, 1688804763107329L, 0L, 0L };
/* 4702 */     return data; }
/*      */   
/* 4704 */   public static final BitSet _tokenSet_31 = new BitSet(mk_tokenSet_31());
/*      */   
/* 4706 */   private static final long[] mk_tokenSet_32() { long[] data = { 4630686232326312496L, 69911357809491968L, 0L, 0L };
/* 4707 */     return data; }
/*      */   
/* 4709 */   public static final BitSet _tokenSet_32 = new BitSet(mk_tokenSet_32());
/*      */   
/* 4711 */   private static final long[] mk_tokenSet_33() { long[] data = { 396316767208603648L, 0L };
/* 4712 */     return data; }
/*      */   
/* 4714 */   public static final BitSet _tokenSet_33 = new BitSet(mk_tokenSet_33());
/*      */   
/* 4716 */   private static final long[] mk_tokenSet_34() { long[] data = { 36028797018963968L, 0L };
/* 4717 */     return data; }
/*      */   
/* 4719 */   public static final BitSet _tokenSet_34 = new BitSet(mk_tokenSet_34());
/*      */   
/* 4721 */   private static final long[] mk_tokenSet_35() { long[] data = { 550586252655904194L, 2251763306463233L, 0L, 0L };
/* 4722 */     return data; }
/*      */   
/* 4724 */   public static final BitSet _tokenSet_35 = new BitSet(mk_tokenSet_35());
/*      */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\antlr\HqlBaseParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */