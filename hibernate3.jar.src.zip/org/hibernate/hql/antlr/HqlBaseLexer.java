/*      */ package org.hibernate.hql.antlr;
/*      */ 
/*      */ import antlr.ANTLRHashString;
/*      */ import antlr.ANTLRStringBuffer;
/*      */ import antlr.ByteBuffer;
/*      */ import antlr.CharBuffer;
/*      */ import antlr.CharScanner;
/*      */ import antlr.CharStreamException;
/*      */ import antlr.CharStreamIOException;
/*      */ import antlr.InputBuffer;
/*      */ import antlr.LexerSharedInputState;
/*      */ import antlr.NoViableAltForCharException;
/*      */ import antlr.RecognitionException;
/*      */ import antlr.Token;
/*      */ import antlr.TokenStream;
/*      */ import antlr.TokenStreamException;
/*      */ import antlr.TokenStreamIOException;
/*      */ import antlr.TokenStreamRecognitionException;
/*      */ import antlr.collections.impl.BitSet;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HqlBaseLexer
/*      */   extends CharScanner
/*      */   implements HqlTokenTypes, TokenStream
/*      */ {
/*      */   protected void setPossibleID(boolean possibleID) {}
/*      */   
/*      */   public HqlBaseLexer(InputStream in)
/*      */   {
/*   47 */     this(new ByteBuffer(in));
/*      */   }
/*      */   
/*   50 */   public HqlBaseLexer(Reader in) { this(new CharBuffer(in)); }
/*      */   
/*      */ 
/*   53 */   public HqlBaseLexer(InputBuffer ib) { this(new LexerSharedInputState(ib)); }
/*      */   
/*      */   public HqlBaseLexer(LexerSharedInputState state) {
/*   56 */     super(state);
/*   57 */     this.caseSensitiveLiterals = false;
/*   58 */     setCaseSensitive(false);
/*   59 */     this.literals = new Hashtable();
/*   60 */     this.literals.put(new ANTLRHashString("between", this), new Integer(10));
/*   61 */     this.literals.put(new ANTLRHashString("case", this), new Integer(54));
/*   62 */     this.literals.put(new ANTLRHashString("delete", this), new Integer(13));
/*   63 */     this.literals.put(new ANTLRHashString("new", this), new Integer(37));
/*   64 */     this.literals.put(new ANTLRHashString("end", this), new Integer(55));
/*   65 */     this.literals.put(new ANTLRHashString("object", this), new Integer(65));
/*   66 */     this.literals.put(new ANTLRHashString("insert", this), new Integer(29));
/*   67 */     this.literals.put(new ANTLRHashString("distinct", this), new Integer(16));
/*   68 */     this.literals.put(new ANTLRHashString("where", this), new Integer(53));
/*   69 */     this.literals.put(new ANTLRHashString("trailing", this), new Integer(67));
/*   70 */     this.literals.put(new ANTLRHashString("then", this), new Integer(57));
/*   71 */     this.literals.put(new ANTLRHashString("select", this), new Integer(45));
/*   72 */     this.literals.put(new ANTLRHashString("and", this), new Integer(6));
/*   73 */     this.literals.put(new ANTLRHashString("outer", this), new Integer(42));
/*   74 */     this.literals.put(new ANTLRHashString("not", this), new Integer(38));
/*   75 */     this.literals.put(new ANTLRHashString("fetch", this), new Integer(21));
/*   76 */     this.literals.put(new ANTLRHashString("from", this), new Integer(22));
/*   77 */     this.literals.put(new ANTLRHashString("null", this), new Integer(39));
/*   78 */     this.literals.put(new ANTLRHashString("count", this), new Integer(12));
/*   79 */     this.literals.put(new ANTLRHashString("like", this), new Integer(34));
/*   80 */     this.literals.put(new ANTLRHashString("when", this), new Integer(58));
/*   81 */     this.literals.put(new ANTLRHashString("class", this), new Integer(11));
/*   82 */     this.literals.put(new ANTLRHashString("inner", this), new Integer(28));
/*   83 */     this.literals.put(new ANTLRHashString("leading", this), new Integer(63));
/*   84 */     this.literals.put(new ANTLRHashString("with", this), new Integer(60));
/*   85 */     this.literals.put(new ANTLRHashString("set", this), new Integer(46));
/*   86 */     this.literals.put(new ANTLRHashString("escape", this), new Integer(18));
/*   87 */     this.literals.put(new ANTLRHashString("join", this), new Integer(32));
/*   88 */     this.literals.put(new ANTLRHashString("elements", this), new Integer(17));
/*   89 */     this.literals.put(new ANTLRHashString("of", this), new Integer(66));
/*   90 */     this.literals.put(new ANTLRHashString("is", this), new Integer(31));
/*   91 */     this.literals.put(new ANTLRHashString("member", this), new Integer(64));
/*   92 */     this.literals.put(new ANTLRHashString("or", this), new Integer(40));
/*   93 */     this.literals.put(new ANTLRHashString("any", this), new Integer(5));
/*   94 */     this.literals.put(new ANTLRHashString("full", this), new Integer(23));
/*   95 */     this.literals.put(new ANTLRHashString("min", this), new Integer(36));
/*   96 */     this.literals.put(new ANTLRHashString("as", this), new Integer(7));
/*   97 */     this.literals.put(new ANTLRHashString("by", this), new Integer(99));
/*   98 */     this.literals.put(new ANTLRHashString("all", this), new Integer(4));
/*   99 */     this.literals.put(new ANTLRHashString("union", this), new Integer(50));
/*  100 */     this.literals.put(new ANTLRHashString("order", this), new Integer(41));
/*  101 */     this.literals.put(new ANTLRHashString("both", this), new Integer(61));
/*  102 */     this.literals.put(new ANTLRHashString("some", this), new Integer(47));
/*  103 */     this.literals.put(new ANTLRHashString("properties", this), new Integer(43));
/*  104 */     this.literals.put(new ANTLRHashString("ascending", this), new Integer(100));
/*  105 */     this.literals.put(new ANTLRHashString("descending", this), new Integer(101));
/*  106 */     this.literals.put(new ANTLRHashString("false", this), new Integer(20));
/*  107 */     this.literals.put(new ANTLRHashString("exists", this), new Integer(19));
/*  108 */     this.literals.put(new ANTLRHashString("asc", this), new Integer(8));
/*  109 */     this.literals.put(new ANTLRHashString("left", this), new Integer(33));
/*  110 */     this.literals.put(new ANTLRHashString("desc", this), new Integer(14));
/*  111 */     this.literals.put(new ANTLRHashString("max", this), new Integer(35));
/*  112 */     this.literals.put(new ANTLRHashString("empty", this), new Integer(62));
/*  113 */     this.literals.put(new ANTLRHashString("sum", this), new Integer(48));
/*  114 */     this.literals.put(new ANTLRHashString("on", this), new Integer(59));
/*  115 */     this.literals.put(new ANTLRHashString("into", this), new Integer(30));
/*  116 */     this.literals.put(new ANTLRHashString("else", this), new Integer(56));
/*  117 */     this.literals.put(new ANTLRHashString("right", this), new Integer(44));
/*  118 */     this.literals.put(new ANTLRHashString("versioned", this), new Integer(52));
/*  119 */     this.literals.put(new ANTLRHashString("in", this), new Integer(26));
/*  120 */     this.literals.put(new ANTLRHashString("avg", this), new Integer(9));
/*  121 */     this.literals.put(new ANTLRHashString("update", this), new Integer(51));
/*  122 */     this.literals.put(new ANTLRHashString("true", this), new Integer(49));
/*  123 */     this.literals.put(new ANTLRHashString("group", this), new Integer(24));
/*  124 */     this.literals.put(new ANTLRHashString("having", this), new Integer(25));
/*  125 */     this.literals.put(new ANTLRHashString("indices", this), new Integer(27));
/*      */   }
/*      */   
/*      */   public Token nextToken() throws TokenStreamException {
/*  129 */     Token theRetToken = null;
/*      */     for (;;)
/*      */     {
/*  132 */       Token _token = null;
/*  133 */       int _ttype = 0;
/*  134 */       resetText();
/*      */       try
/*      */       {
/*  137 */         switch (LA(1))
/*      */         {
/*      */         case '=': 
/*  140 */           mEQ(true);
/*  141 */           theRetToken = this._returnToken;
/*  142 */           break;
/*      */         
/*      */         case '!': 
/*      */         case '^': 
/*  146 */           mNE(true);
/*  147 */           theRetToken = this._returnToken;
/*  148 */           break;
/*      */         
/*      */ 
/*      */         case ',': 
/*  152 */           mCOMMA(true);
/*  153 */           theRetToken = this._returnToken;
/*  154 */           break;
/*      */         
/*      */ 
/*      */         case '(': 
/*  158 */           mOPEN(true);
/*  159 */           theRetToken = this._returnToken;
/*  160 */           break;
/*      */         
/*      */ 
/*      */         case ')': 
/*  164 */           mCLOSE(true);
/*  165 */           theRetToken = this._returnToken;
/*  166 */           break;
/*      */         
/*      */ 
/*      */         case '[': 
/*  170 */           mOPEN_BRACKET(true);
/*  171 */           theRetToken = this._returnToken;
/*  172 */           break;
/*      */         
/*      */ 
/*      */         case ']': 
/*  176 */           mCLOSE_BRACKET(true);
/*  177 */           theRetToken = this._returnToken;
/*  178 */           break;
/*      */         
/*      */ 
/*      */         case '|': 
/*  182 */           mCONCAT(true);
/*  183 */           theRetToken = this._returnToken;
/*  184 */           break;
/*      */         
/*      */ 
/*      */         case '+': 
/*  188 */           mPLUS(true);
/*  189 */           theRetToken = this._returnToken;
/*  190 */           break;
/*      */         
/*      */ 
/*      */         case '-': 
/*  194 */           mMINUS(true);
/*  195 */           theRetToken = this._returnToken;
/*  196 */           break;
/*      */         
/*      */ 
/*      */         case '*': 
/*  200 */           mSTAR(true);
/*  201 */           theRetToken = this._returnToken;
/*  202 */           break;
/*      */         
/*      */ 
/*      */         case '/': 
/*  206 */           mDIV(true);
/*  207 */           theRetToken = this._returnToken;
/*  208 */           break;
/*      */         
/*      */ 
/*      */         case ':': 
/*  212 */           mCOLON(true);
/*  213 */           theRetToken = this._returnToken;
/*  214 */           break;
/*      */         
/*      */ 
/*      */         case '?': 
/*  218 */           mPARAM(true);
/*  219 */           theRetToken = this._returnToken;
/*  220 */           break;
/*      */         
/*      */ 
/*      */         case '\'': 
/*  224 */           mQUOTED_STRING(true);
/*  225 */           theRetToken = this._returnToken;
/*  226 */           break;
/*      */         case '\t': case '\n': 
/*      */         case '\r': 
/*      */         case ' ': 
/*  230 */           mWS(true);
/*  231 */           theRetToken = this._returnToken;
/*  232 */           break;
/*      */         case '.': case '0': case '1': 
/*      */         case '2': case '3': 
/*      */         case '4': case '5': 
/*      */         case '6': case '7': 
/*      */         case '8': case '9': 
/*  238 */           mNUM_INT(true);
/*  239 */           theRetToken = this._returnToken;
/*  240 */           break;
/*      */         case '\013': case '\f': case '\016': case '\017': case '\020': case '\021': case '\022': case '\023': case '\024': case '\025': case '\026': case '\027': case '\030': case '\031': case '\032': case '\033': case '\034': case '\035': case '\036': case '\037': case '"': case '#': case '$': case '%': case '&': case ';': case '<': case '>': case '@': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': 
/*      */         case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '\\': case '_': case '`': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q': case 'r': case 's': case 't': case 'u': case 'v': case 'w': case 'x': case 'y': case 'z': case '{': default: 
/*  243 */           if ((LA(1) == '<') && (LA(2) == '>')) {
/*  244 */             mSQL_NE(true);
/*  245 */             theRetToken = this._returnToken;
/*      */           }
/*  247 */           else if ((LA(1) == '<') && (LA(2) == '=')) {
/*  248 */             mLE(true);
/*  249 */             theRetToken = this._returnToken;
/*      */           }
/*  251 */           else if ((LA(1) == '>') && (LA(2) == '=')) {
/*  252 */             mGE(true);
/*  253 */             theRetToken = this._returnToken;
/*      */           }
/*  255 */           else if (LA(1) == '<') {
/*  256 */             mLT(true);
/*  257 */             theRetToken = this._returnToken;
/*      */           }
/*  259 */           else if (LA(1) == '>') {
/*  260 */             mGT(true);
/*  261 */             theRetToken = this._returnToken;
/*      */           }
/*  263 */           else if (_tokenSet_0.member(LA(1))) {
/*  264 */             mIDENT(true);
/*  265 */             theRetToken = this._returnToken;
/*      */ 
/*      */           }
/*  268 */           else if (LA(1) == 65535) { uponEOF();this._returnToken = makeToken(1);
/*  269 */           } else { throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           }
/*      */           break; }
/*  272 */         if (this._returnToken == null) continue;
/*  273 */         _ttype = this._returnToken.getType();
/*  274 */         this._returnToken.setType(_ttype);
/*  275 */         return this._returnToken;
/*      */       }
/*      */       catch (RecognitionException e) {
/*  278 */         throw new TokenStreamRecognitionException(e);
/*      */       }
/*      */       catch (CharStreamException cse)
/*      */       {
/*  282 */         if ((cse instanceof CharStreamIOException)) {
/*  283 */           throw new TokenStreamIOException(((CharStreamIOException)cse).io);
/*      */         }
/*      */         
/*  286 */         throw new TokenStreamException(cse.getMessage());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public final void mEQ(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException
/*      */   {
/*  293 */     Token _token = null;int _begin = this.text.length();
/*  294 */     int _ttype = 96;
/*      */     
/*      */ 
/*  297 */     match('=');
/*  298 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  299 */       _token = makeToken(_ttype);
/*  300 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  302 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mLT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  306 */     Token _token = null;int _begin = this.text.length();
/*  307 */     int _ttype = 104;
/*      */     
/*      */ 
/*  310 */     match('<');
/*  311 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  312 */       _token = makeToken(_ttype);
/*  313 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  315 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mGT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  319 */     Token _token = null;int _begin = this.text.length();
/*  320 */     int _ttype = 105;
/*      */     
/*      */ 
/*  323 */     match('>');
/*  324 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  325 */       _token = makeToken(_ttype);
/*  326 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  328 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mSQL_NE(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  332 */     Token _token = null;int _begin = this.text.length();
/*  333 */     int _ttype = 103;
/*      */     
/*      */ 
/*  336 */     match("<>");
/*  337 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  338 */       _token = makeToken(_ttype);
/*  339 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  341 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mNE(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  345 */     Token _token = null;int _begin = this.text.length();
/*  346 */     int _ttype = 102;
/*      */     
/*      */ 
/*  349 */     switch (LA(1))
/*      */     {
/*      */     case '!': 
/*  352 */       match("!=");
/*  353 */       break;
/*      */     
/*      */ 
/*      */     case '^': 
/*  357 */       match("^=");
/*  358 */       break;
/*      */     
/*      */ 
/*      */     default: 
/*  362 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     }
/*      */     
/*  365 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  366 */       _token = makeToken(_ttype);
/*  367 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  369 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mLE(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  373 */     Token _token = null;int _begin = this.text.length();
/*  374 */     int _ttype = 106;
/*      */     
/*      */ 
/*  377 */     match("<=");
/*  378 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  379 */       _token = makeToken(_ttype);
/*  380 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  382 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mGE(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  386 */     Token _token = null;int _begin = this.text.length();
/*  387 */     int _ttype = 107;
/*      */     
/*      */ 
/*  390 */     match(">=");
/*  391 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  392 */       _token = makeToken(_ttype);
/*  393 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  395 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mCOMMA(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  399 */     Token _token = null;int _begin = this.text.length();
/*  400 */     int _ttype = 95;
/*      */     
/*      */ 
/*  403 */     match(',');
/*  404 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  405 */       _token = makeToken(_ttype);
/*  406 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  408 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mOPEN(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  412 */     Token _token = null;int _begin = this.text.length();
/*  413 */     int _ttype = 97;
/*      */     
/*      */ 
/*  416 */     match('(');
/*  417 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  418 */       _token = makeToken(_ttype);
/*  419 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  421 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mCLOSE(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  425 */     Token _token = null;int _begin = this.text.length();
/*  426 */     int _ttype = 98;
/*      */     
/*      */ 
/*  429 */     match(')');
/*  430 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  431 */       _token = makeToken(_ttype);
/*  432 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  434 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mOPEN_BRACKET(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  438 */     Token _token = null;int _begin = this.text.length();
/*  439 */     int _ttype = 113;
/*      */     
/*      */ 
/*  442 */     match('[');
/*  443 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  444 */       _token = makeToken(_ttype);
/*  445 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  447 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mCLOSE_BRACKET(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  451 */     Token _token = null;int _begin = this.text.length();
/*  452 */     int _ttype = 114;
/*      */     
/*      */ 
/*  455 */     match(']');
/*  456 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  457 */       _token = makeToken(_ttype);
/*  458 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  460 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mCONCAT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  464 */     Token _token = null;int _begin = this.text.length();
/*  465 */     int _ttype = 108;
/*      */     
/*      */ 
/*  468 */     match("||");
/*  469 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  470 */       _token = makeToken(_ttype);
/*  471 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  473 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mPLUS(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  477 */     Token _token = null;int _begin = this.text.length();
/*  478 */     int _ttype = 109;
/*      */     
/*      */ 
/*  481 */     match('+');
/*  482 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  483 */       _token = makeToken(_ttype);
/*  484 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  486 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mMINUS(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  490 */     Token _token = null;int _begin = this.text.length();
/*  491 */     int _ttype = 110;
/*      */     
/*      */ 
/*  494 */     match('-');
/*  495 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  496 */       _token = makeToken(_ttype);
/*  497 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  499 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mSTAR(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  503 */     Token _token = null;int _begin = this.text.length();
/*  504 */     int _ttype = 111;
/*      */     
/*      */ 
/*  507 */     match('*');
/*  508 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  509 */       _token = makeToken(_ttype);
/*  510 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  512 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mDIV(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  516 */     Token _token = null;int _begin = this.text.length();
/*  517 */     int _ttype = 112;
/*      */     
/*      */ 
/*  520 */     match('/');
/*  521 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  522 */       _token = makeToken(_ttype);
/*  523 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  525 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mCOLON(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  529 */     Token _token = null;int _begin = this.text.length();
/*  530 */     int _ttype = 115;
/*      */     
/*      */ 
/*  533 */     match(':');
/*  534 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  535 */       _token = makeToken(_ttype);
/*  536 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  538 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mPARAM(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  542 */     Token _token = null;int _begin = this.text.length();
/*  543 */     int _ttype = 116;
/*      */     
/*      */ 
/*  546 */     match('?');
/*  547 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  548 */       _token = makeToken(_ttype);
/*  549 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  551 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mIDENT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  555 */     Token _token = null;int _begin = this.text.length();
/*  556 */     int _ttype = 119;
/*      */     
/*      */ 
/*  559 */     mID_START_LETTER(false);
/*      */     
/*      */ 
/*      */ 
/*  563 */     while (_tokenSet_1.member(LA(1))) {
/*  564 */       mID_LETTER(false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  572 */     if (this.inputState.guessing == 0)
/*      */     {
/*      */ 
/*  575 */       setPossibleID(true);
/*      */     }
/*      */     
/*  578 */     _ttype = testLiteralsTable(_ttype);
/*  579 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  580 */       _token = makeToken(_ttype);
/*  581 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  583 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   protected final void mID_START_LETTER(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  587 */     Token _token = null;int _begin = this.text.length();
/*  588 */     int _ttype = 120;
/*      */     
/*      */ 
/*  591 */     switch (LA(1))
/*      */     {
/*      */     case '_': 
/*  594 */       match('_');
/*  595 */       break;
/*      */     
/*      */ 
/*      */     case '$': 
/*  599 */       match('$');
/*  600 */       break;
/*      */     case 'a': case 'b': case 'c': 
/*      */     case 'd': case 'e': case 'f': 
/*      */     case 'g': case 'h': case 'i': 
/*      */     case 'j': case 'k': case 'l': 
/*      */     case 'm': case 'n': case 'o': 
/*      */     case 'p': case 'q': case 'r': 
/*      */     case 's': case 't': case 'u': 
/*      */     case 'v': case 'w': case 'x': 
/*      */     case 'y': case 'z': 
/*  610 */       matchRange('a', 'z');
/*  611 */       break;
/*      */     case '%': case '&': case '\'': case '(': case ')': case '*': case '+': case ',': case '-': case '.': case '/': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case ':': case ';': case '<': case '=': case '>': case '?': case '@': case 'A': case 'B': 
/*      */     case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '\\': case ']': case '^': case '`': default: 
/*  614 */       if ((LA(1) >= '') && (LA(1) <= 65534)) {
/*  615 */         matchRange('', 65534);
/*      */       }
/*      */       else
/*  618 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       break;
/*      */     }
/*  621 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  622 */       _token = makeToken(_ttype);
/*  623 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  625 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   protected final void mID_LETTER(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  629 */     Token _token = null;int _begin = this.text.length();
/*  630 */     int _ttype = 121;
/*      */     
/*      */ 
/*  633 */     if (_tokenSet_0.member(LA(1))) {
/*  634 */       mID_START_LETTER(false);
/*      */     }
/*  636 */     else if ((LA(1) >= '0') && (LA(1) <= '9')) {
/*  637 */       matchRange('0', '9');
/*      */     }
/*      */     else {
/*  640 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     }
/*      */     
/*  643 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  644 */       _token = makeToken(_ttype);
/*  645 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  647 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mQUOTED_STRING(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  651 */     Token _token = null;int _begin = this.text.length();
/*  652 */     int _ttype = 118;
/*      */     
/*      */ 
/*  655 */     match('\'');
/*      */     
/*      */     for (;;)
/*      */     {
/*  659 */       boolean synPredMatched218 = false;
/*  660 */       if ((LA(1) == '\'') && (LA(2) == '\'')) {
/*  661 */         int _m218 = mark();
/*  662 */         synPredMatched218 = true;
/*  663 */         this.inputState.guessing += 1;
/*      */         try
/*      */         {
/*  666 */           mESCqs(false);
/*      */         }
/*      */         catch (RecognitionException pe)
/*      */         {
/*  670 */           synPredMatched218 = false;
/*      */         }
/*  672 */         rewind(_m218);
/*  673 */         this.inputState.guessing -= 1;
/*      */       }
/*  675 */       if (synPredMatched218) {
/*  676 */         mESCqs(false);
/*      */       } else {
/*  678 */         if (!_tokenSet_2.member(LA(1))) break;
/*  679 */         matchNot('\'');
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  687 */     match('\'');
/*  688 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  689 */       _token = makeToken(_ttype);
/*  690 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  692 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   protected final void mESCqs(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  696 */     Token _token = null;int _begin = this.text.length();
/*  697 */     int _ttype = 122;
/*      */     
/*      */ 
/*  700 */     match('\'');
/*  701 */     match('\'');
/*  702 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  703 */       _token = makeToken(_ttype);
/*  704 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  706 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mWS(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  710 */     Token _token = null;int _begin = this.text.length();
/*  711 */     int _ttype = 123;
/*      */     
/*      */ 
/*      */ 
/*  715 */     switch (LA(1))
/*      */     {
/*      */     case ' ': 
/*  718 */       match(' ');
/*  719 */       break;
/*      */     
/*      */ 
/*      */     case '\t': 
/*  723 */       match('\t');
/*  724 */       break;
/*      */     
/*      */ 
/*      */     case '\n': 
/*  728 */       match('\n');
/*  729 */       if (this.inputState.guessing == 0) {
/*  730 */         newline();
/*      */       }
/*      */       
/*      */       break;
/*      */     default: 
/*  735 */       if ((LA(1) == '\r') && (LA(2) == '\n')) {
/*  736 */         match('\r');
/*  737 */         match('\n');
/*  738 */         if (this.inputState.guessing == 0) {
/*  739 */           newline();
/*      */         }
/*      */       }
/*  742 */       else if (LA(1) == '\r') {
/*  743 */         match('\r');
/*  744 */         if (this.inputState.guessing == 0) {
/*  745 */           newline();
/*      */         }
/*      */       }
/*      */       else {
/*  749 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       }
/*      */       break;
/*      */     }
/*  753 */     if (this.inputState.guessing == 0) {
/*  754 */       _ttype = -1;
/*      */     }
/*  756 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/*  757 */       _token = makeToken(_ttype);
/*  758 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/*  760 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   public final void mNUM_INT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/*  764 */     Token _token = null;int _begin = this.text.length();
/*  765 */     int _ttype = 117;
/*      */     
/*  767 */     Token f1 = null;
/*  768 */     Token f2 = null;
/*  769 */     Token f3 = null;
/*  770 */     Token f4 = null;
/*  771 */     boolean isDecimal = false;Token t = null;
/*      */     
/*  773 */     switch (LA(1))
/*      */     {
/*      */     case '.': 
/*  776 */       match('.');
/*  777 */       if (this.inputState.guessing == 0) {
/*  778 */         _ttype = 15;
/*      */       }
/*      */       
/*  781 */       if ((LA(1) >= '0') && (LA(1) <= '9'))
/*      */       {
/*  783 */         int _cnt226 = 0;
/*      */         for (;;)
/*      */         {
/*  786 */           if ((LA(1) >= '0') && (LA(1) <= '9')) {
/*  787 */             matchRange('0', '9');
/*      */           }
/*      */           else {
/*  790 */             if (_cnt226 >= 1) break; throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           }
/*      */           
/*  793 */           _cnt226++;
/*      */         }
/*      */         
/*      */ 
/*  797 */         if (LA(1) == 'e') {
/*  798 */           mEXPONENT(false);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  805 */         if ((LA(1) == 'd') || (LA(1) == 'f')) {
/*  806 */           mFLOAT_SUFFIX(true);
/*  807 */           f1 = this._returnToken;
/*  808 */           if (this.inputState.guessing == 0) {
/*  809 */             t = f1;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  816 */         if (this.inputState.guessing == 0)
/*      */         {
/*  818 */           if ((t != null) && (t.getText().toUpperCase().indexOf('F') >= 0))
/*      */           {
/*  820 */             _ttype = 93;
/*      */           }
/*      */           else
/*      */           {
/*  824 */             _ttype = 92;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */       break;
/*      */     case '0': 
/*      */     case '1': 
/*      */     case '2': 
/*      */     case '3': 
/*      */     case '4': 
/*      */     case '5': 
/*      */     case '6': 
/*      */     case '7': 
/*      */     case '8': 
/*      */     case '9': 
/*  840 */       switch (LA(1))
/*      */       {
/*      */       case '0': 
/*  843 */         match('0');
/*  844 */         if (this.inputState.guessing == 0) {
/*  845 */           isDecimal = true;
/*      */         }
/*      */         
/*  848 */         switch (LA(1))
/*      */         {
/*      */ 
/*      */         case 'x': 
/*  852 */           match('x');
/*      */           
/*      */ 
/*  855 */           int _cnt233 = 0;
/*      */           for (;;)
/*      */           {
/*  858 */             if (_tokenSet_3.member(LA(1))) {
/*  859 */               mHEX_DIGIT(false);
/*      */             }
/*      */             else {
/*  862 */               if (_cnt233 >= 1) break; throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */             }
/*      */             
/*  865 */             _cnt233++;
/*      */           }
/*      */           
/*  868 */           break;
/*      */         case '0': case '1': 
/*      */         case '2': case '3': 
/*      */         case '4': case '5': 
/*      */         case '6': 
/*      */         case '7': 
/*  874 */           int _cnt235 = 0;
/*      */           for (;;)
/*      */           {
/*  877 */             if ((LA(1) >= '0') && (LA(1) <= '7')) {
/*  878 */               matchRange('0', '7');
/*      */             }
/*      */             else {
/*  881 */               if (_cnt235 >= 1) break; throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */             }
/*      */             
/*  884 */             _cnt235++;
/*      */           }
/*      */         }
/*      */         
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  894 */         break;
/*      */       case '1': case '2': 
/*      */       case '3': case '4': 
/*      */       case '5': case '6': 
/*      */       case '7': 
/*      */       case '8': 
/*      */       case '9': 
/*  901 */         matchRange('1', '9');
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  906 */         while ((LA(1) >= '0') && (LA(1) <= '9')) {
/*  907 */           matchRange('0', '9');
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  915 */         if (this.inputState.guessing == 0) {
/*  916 */           isDecimal = true;
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       default: 
/*  922 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       }
/*      */       
/*      */       
/*      */ 
/*  927 */       if (LA(1) == 'l')
/*      */       {
/*  929 */         match('l');
/*      */         
/*  931 */         if (this.inputState.guessing == 0) {
/*  932 */           _ttype = 94;
/*      */         }
/*      */       }
/*  935 */       else if ((_tokenSet_4.member(LA(1))) && (isDecimal))
/*      */       {
/*  937 */         switch (LA(1))
/*      */         {
/*      */         case '.': 
/*  940 */           match('.');
/*      */           
/*      */ 
/*      */ 
/*  944 */           while ((LA(1) >= '0') && (LA(1) <= '9')) {
/*  945 */             matchRange('0', '9');
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  954 */           if (LA(1) == 'e') {
/*  955 */             mEXPONENT(false);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  962 */           if ((LA(1) == 'd') || (LA(1) == 'f')) {
/*  963 */             mFLOAT_SUFFIX(true);
/*  964 */             f2 = this._returnToken;
/*  965 */             if (this.inputState.guessing == 0) {
/*  966 */               t = f2;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           break;
/*      */         case 'e': 
/*  977 */           mEXPONENT(false);
/*      */           
/*  979 */           if ((LA(1) == 'd') || (LA(1) == 'f')) {
/*  980 */             mFLOAT_SUFFIX(true);
/*  981 */             f3 = this._returnToken;
/*  982 */             if (this.inputState.guessing == 0) {
/*  983 */               t = f3;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           break;
/*      */         case 'd': 
/*      */         case 'f': 
/*  994 */           mFLOAT_SUFFIX(true);
/*  995 */           f4 = this._returnToken;
/*  996 */           if (this.inputState.guessing == 0) {
/*  997 */             t = f4;
/*      */           }
/*      */           
/*      */ 
/*      */           break;
/*      */         default: 
/* 1003 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         }
/*      */         
/*      */         
/* 1007 */         if (this.inputState.guessing == 0)
/*      */         {
/* 1009 */           if ((t != null) && (t.getText().toUpperCase().indexOf('F') >= 0))
/*      */           {
/* 1011 */             _ttype = 93;
/*      */           }
/*      */           else
/*      */           {
/* 1015 */             _ttype = 92;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       break;
/*      */     case '/': 
/*      */     default: 
/* 1028 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     }
/*      */     
/* 1031 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/* 1032 */       _token = makeToken(_ttype);
/* 1033 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/* 1035 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   protected final void mEXPONENT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1039 */     Token _token = null;int _begin = this.text.length();
/* 1040 */     int _ttype = 125;
/*      */     
/*      */ 
/*      */ 
/* 1044 */     match('e');
/*      */     
/*      */ 
/* 1047 */     switch (LA(1))
/*      */     {
/*      */     case '+': 
/* 1050 */       match('+');
/* 1051 */       break;
/*      */     
/*      */ 
/*      */     case '-': 
/* 1055 */       match('-');
/* 1056 */       break;
/*      */     case '0': case '1': 
/*      */     case '2': case '3': 
/*      */     case '4': case '5': 
/*      */     case '6': 
/*      */     case '7': 
/*      */     case '8': 
/*      */     case '9': 
/*      */       break;
/*      */     case ',': case '.': case '/': default: 
/* 1066 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     }
/*      */     
/*      */     
/*      */ 
/* 1071 */     int _cnt253 = 0;
/*      */     for (;;)
/*      */     {
/* 1074 */       if ((LA(1) >= '0') && (LA(1) <= '9')) {
/* 1075 */         matchRange('0', '9');
/*      */       }
/*      */       else {
/* 1078 */         if (_cnt253 >= 1) break; throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       }
/*      */       
/* 1081 */       _cnt253++;
/*      */     }
/*      */     
/* 1084 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/* 1085 */       _token = makeToken(_ttype);
/* 1086 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/* 1088 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   protected final void mFLOAT_SUFFIX(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1092 */     Token _token = null;int _begin = this.text.length();
/* 1093 */     int _ttype = 126;
/*      */     
/*      */ 
/* 1096 */     switch (LA(1))
/*      */     {
/*      */     case 'f': 
/* 1099 */       match('f');
/* 1100 */       break;
/*      */     
/*      */ 
/*      */     case 'd': 
/* 1104 */       match('d');
/* 1105 */       break;
/*      */     
/*      */ 
/*      */     default: 
/* 1109 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     }
/*      */     
/* 1112 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/* 1113 */       _token = makeToken(_ttype);
/* 1114 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/* 1116 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   protected final void mHEX_DIGIT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1120 */     Token _token = null;int _begin = this.text.length();
/* 1121 */     int _ttype = 124;
/*      */     
/*      */ 
/*      */ 
/* 1125 */     switch (LA(1)) {
/*      */     case '0': case '1': case '2': 
/*      */     case '3': case '4': case '5': 
/*      */     case '6': case '7': 
/*      */     case '8': case '9': 
/* 1130 */       matchRange('0', '9');
/* 1131 */       break;
/*      */     case 'a': case 'b': 
/*      */     case 'c': case 'd': 
/*      */     case 'e': 
/*      */     case 'f': 
/* 1136 */       matchRange('a', 'f');
/* 1137 */       break;
/*      */     case ':': case ';': case '<': case '=': case '>': case '?': case '@': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': 
/*      */     case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': 
/*      */     case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '\\': case ']': case '^': case '_': case '`': default: 
/* 1141 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     }
/*      */     
/*      */     
/* 1145 */     if ((_createToken) && (_token == null) && (_ttype != -1)) {
/* 1146 */       _token = makeToken(_ttype);
/* 1147 */       _token.setText(new String(this.text.getBuffer(), _begin, this.text.length() - _begin));
/*      */     }
/* 1149 */     this._returnToken = _token;
/*      */   }
/*      */   
/*      */   private static final long[] mk_tokenSet_0()
/*      */   {
/* 1154 */     long[] data = new long['ఀ'];
/* 1155 */     data[0] = 68719476736L;
/* 1156 */     data[1] = 576460745860972544L;
/* 1157 */     for (int i = 2; i <= 1022; i++) data[i] = -1L;
/* 1158 */     data['Ͽ'] = Long.MAX_VALUE;
/* 1159 */     return data; }
/*      */   
/* 1161 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*      */   
/* 1163 */   private static final long[] mk_tokenSet_1() { long[] data = new long['ఀ'];
/* 1164 */     data[0] = 287948969894477824L;
/* 1165 */     data[1] = 576460745860972544L;
/* 1166 */     for (int i = 2; i <= 1022; i++) data[i] = -1L;
/* 1167 */     data['Ͽ'] = Long.MAX_VALUE;
/* 1168 */     return data; }
/*      */   
/* 1170 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*      */   
/* 1172 */   private static final long[] mk_tokenSet_2() { long[] data = new long['ࠀ'];
/* 1173 */     data[0] = -549755813889L;
/* 1174 */     for (int i = 1; i <= 1022; i++) data[i] = -1L;
/* 1175 */     data['Ͽ'] = Long.MAX_VALUE;
/* 1176 */     return data; }
/*      */   
/* 1178 */   public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
/*      */   
/* 1180 */   private static final long[] mk_tokenSet_3() { long[] data = new long['Ё'];
/* 1181 */     data[0] = 287948901175001088L;
/* 1182 */     data[1] = 541165879296L;
/* 1183 */     return data; }
/*      */   
/* 1185 */   public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
/*      */   
/* 1187 */   private static final long[] mk_tokenSet_4() { long[] data = new long['Ё'];
/* 1188 */     data[0] = 70368744177664L;
/* 1189 */     data[1] = 481036337152L;
/* 1190 */     return data; }
/*      */   
/* 1192 */   public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
/*      */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\antlr\HqlBaseLexer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */