/*      */ package org.hibernate.hql.antlr;
/*      */ 
/*      */ import antlr.MismatchedTokenException;
/*      */ import antlr.NoViableAltException;
/*      */ import antlr.RecognitionException;
/*      */ import antlr.TreeParser;
/*      */ import antlr.TreeParserSharedInputState;
/*      */ import antlr.collections.AST;
/*      */ import antlr.collections.impl.BitSet;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SqlGeneratorBase
/*      */   extends TreeParser
/*      */   implements SqlTokenTypes
/*      */ {
/*   34 */   private static Log log = LogFactory.getLog(SqlGeneratorBase.class);
/*      */   
/*      */ 
/*   37 */   private StringBuffer buf = new StringBuffer();
/*      */   
/*      */   protected void out(String s) {
/*   40 */     this.buf.append(s);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected int getLastChar()
/*      */   {
/*   47 */     int len = this.buf.length();
/*   48 */     if (len == 0) {
/*   49 */       return -1;
/*      */     }
/*   51 */     return this.buf.charAt(len - 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void optionalSpace() {}
/*      */   
/*      */ 
/*      */ 
/*      */   protected void out(AST n)
/*      */   {
/*   62 */     out(n.getText());
/*      */   }
/*      */   
/*      */   protected void separator(AST n, String sep) {
/*   66 */     if (n.getNextSibling() != null)
/*   67 */       out(sep);
/*      */   }
/*      */   
/*      */   protected boolean hasText(AST a) {
/*   71 */     String t = a.getText();
/*   72 */     return (t != null) && (t.length() > 0);
/*      */   }
/*      */   
/*      */ 
/*      */   protected void fromFragmentSeparator(AST a) {}
/*      */   
/*      */ 
/*      */   protected void nestedFromFragment(AST d, AST parent) {}
/*      */   
/*      */ 
/*      */   protected StringBuffer getStringBuffer()
/*      */   {
/*   84 */     return this.buf;
/*      */   }
/*      */   
/*      */   protected void nyi(AST n) {
/*   88 */     throw new UnsupportedOperationException("Unsupported node: " + n);
/*      */   }
/*      */   
/*      */   protected void beginFunctionTemplate(AST m, AST i)
/*      */   {
/*   93 */     out(i);
/*   94 */     out("(");
/*      */   }
/*      */   
/*      */   protected void endFunctionTemplate(AST m) {
/*   98 */     out(")");
/*      */   }
/*      */   
/*      */   protected void commaBetweenParameters(String comma) {
/*  102 */     out(comma);
/*      */   }
/*      */   
/*  105 */   public SqlGeneratorBase() { this.tokenNames = _tokenNames; }
/*      */   
/*      */   public final void statement(AST _t)
/*      */     throws RecognitionException
/*      */   {
/*  110 */     AST statement_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/*  113 */       if (_t == null) _t = ASTNULL;
/*  114 */       switch (_t.getType())
/*      */       {
/*      */       case 45: 
/*  117 */         selectStatement(_t);
/*  118 */         _t = this._retTree;
/*  119 */         break;
/*      */       
/*      */ 
/*      */       case 51: 
/*  123 */         updateStatement(_t);
/*  124 */         _t = this._retTree;
/*  125 */         break;
/*      */       
/*      */ 
/*      */       case 13: 
/*  129 */         deleteStatement(_t);
/*  130 */         _t = this._retTree;
/*  131 */         break;
/*      */       
/*      */ 
/*      */       case 29: 
/*  135 */         insertStatement(_t);
/*  136 */         _t = this._retTree;
/*  137 */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  141 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/*  146 */       if (this.inputState.guessing == 0) {
/*  147 */         reportError(ex);
/*  148 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/*  150 */         throw ex;
/*      */       }
/*      */     }
/*  153 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void selectStatement(AST _t) throws RecognitionException
/*      */   {
/*  158 */     AST selectStatement_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/*  161 */       AST __t3 = _t;
/*  162 */       AST tmp1_AST_in = _t;
/*  163 */       match(_t, 45);
/*  164 */       _t = _t.getFirstChild();
/*  165 */       if (this.inputState.guessing == 0) {
/*  166 */         out("select ");
/*      */       }
/*  168 */       selectClause(_t);
/*  169 */       _t = this._retTree;
/*  170 */       from(_t);
/*  171 */       _t = this._retTree;
/*      */       
/*  173 */       if (_t == null) _t = ASTNULL;
/*  174 */       switch (_t.getType())
/*      */       {
/*      */       case 53: 
/*  177 */         AST __t5 = _t;
/*  178 */         AST tmp2_AST_in = _t;
/*  179 */         match(_t, 53);
/*  180 */         _t = _t.getFirstChild();
/*  181 */         if (this.inputState.guessing == 0) {
/*  182 */           out(" where ");
/*      */         }
/*  184 */         whereExpr(_t);
/*  185 */         _t = this._retTree;
/*  186 */         _t = __t5;
/*  187 */         _t = _t.getNextSibling();
/*  188 */         break;
/*      */       
/*      */ 
/*      */       case 3: 
/*      */       case 24: 
/*      */       case 41: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  198 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/*      */ 
/*  203 */       if (_t == null) _t = ASTNULL;
/*  204 */       switch (_t.getType())
/*      */       {
/*      */       case 24: 
/*  207 */         AST __t7 = _t;
/*  208 */         AST tmp3_AST_in = _t;
/*  209 */         match(_t, 24);
/*  210 */         _t = _t.getFirstChild();
/*  211 */         if (this.inputState.guessing == 0) {
/*  212 */           out(" group by ");
/*      */         }
/*  214 */         groupExprs(_t);
/*  215 */         _t = this._retTree;
/*      */         
/*  217 */         if (_t == null) _t = ASTNULL;
/*  218 */         switch (_t.getType())
/*      */         {
/*      */         case 25: 
/*  221 */           AST __t9 = _t;
/*  222 */           AST tmp4_AST_in = _t;
/*  223 */           match(_t, 25);
/*  224 */           _t = _t.getFirstChild();
/*  225 */           if (this.inputState.guessing == 0) {
/*  226 */             out(" having ");
/*      */           }
/*  228 */           booleanExpr(_t, false);
/*  229 */           _t = this._retTree;
/*  230 */           _t = __t9;
/*  231 */           _t = _t.getNextSibling();
/*  232 */           break;
/*      */         
/*      */ 
/*      */         case 3: 
/*      */           break;
/*      */         
/*      */ 
/*      */         default: 
/*  240 */           throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*      */         
/*  244 */         _t = __t7;
/*  245 */         _t = _t.getNextSibling();
/*  246 */         break;
/*      */       
/*      */ 
/*      */       case 3: 
/*      */       case 41: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  255 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/*      */ 
/*  260 */       if (_t == null) _t = ASTNULL;
/*  261 */       switch (_t.getType())
/*      */       {
/*      */       case 41: 
/*  264 */         AST __t11 = _t;
/*  265 */         AST tmp5_AST_in = _t;
/*  266 */         match(_t, 41);
/*  267 */         _t = _t.getFirstChild();
/*  268 */         if (this.inputState.guessing == 0) {
/*  269 */           out(" order by ");
/*      */         }
/*  271 */         orderExprs(_t);
/*  272 */         _t = this._retTree;
/*  273 */         _t = __t11;
/*  274 */         _t = _t.getNextSibling();
/*  275 */         break;
/*      */       
/*      */ 
/*      */       case 3: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  283 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/*  287 */       _t = __t3;
/*  288 */       _t = _t.getNextSibling();
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  291 */       if (this.inputState.guessing == 0) {
/*  292 */         reportError(ex);
/*  293 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/*  295 */         throw ex;
/*      */       }
/*      */     }
/*  298 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void updateStatement(AST _t) throws RecognitionException
/*      */   {
/*  303 */     AST updateStatement_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/*  306 */       AST __t13 = _t;
/*  307 */       AST tmp6_AST_in = _t;
/*  308 */       match(_t, 51);
/*  309 */       _t = _t.getFirstChild();
/*  310 */       if (this.inputState.guessing == 0) {
/*  311 */         out("update ");
/*      */       }
/*  313 */       AST __t14 = _t;
/*  314 */       AST tmp7_AST_in = _t;
/*  315 */       match(_t, 22);
/*  316 */       _t = _t.getFirstChild();
/*  317 */       fromTable(_t);
/*  318 */       _t = this._retTree;
/*  319 */       _t = __t14;
/*  320 */       _t = _t.getNextSibling();
/*  321 */       setClause(_t);
/*  322 */       _t = this._retTree;
/*      */       
/*  324 */       if (_t == null) _t = ASTNULL;
/*  325 */       switch (_t.getType())
/*      */       {
/*      */       case 53: 
/*  328 */         whereClause(_t);
/*  329 */         _t = this._retTree;
/*  330 */         break;
/*      */       
/*      */ 
/*      */       case 3: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  338 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/*  342 */       _t = __t13;
/*  343 */       _t = _t.getNextSibling();
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  346 */       if (this.inputState.guessing == 0) {
/*  347 */         reportError(ex);
/*  348 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/*  350 */         throw ex;
/*      */       }
/*      */     }
/*  353 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void deleteStatement(AST _t) throws RecognitionException
/*      */   {
/*  358 */     AST deleteStatement_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/*  361 */       AST __t17 = _t;
/*  362 */       AST tmp8_AST_in = _t;
/*  363 */       match(_t, 13);
/*  364 */       _t = _t.getFirstChild();
/*  365 */       if (this.inputState.guessing == 0) {
/*  366 */         out("delete");
/*      */       }
/*  368 */       from(_t);
/*  369 */       _t = this._retTree;
/*      */       
/*  371 */       if (_t == null) _t = ASTNULL;
/*  372 */       switch (_t.getType())
/*      */       {
/*      */       case 53: 
/*  375 */         whereClause(_t);
/*  376 */         _t = this._retTree;
/*  377 */         break;
/*      */       
/*      */ 
/*      */       case 3: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  385 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/*  389 */       _t = __t17;
/*  390 */       _t = _t.getNextSibling();
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  393 */       if (this.inputState.guessing == 0) {
/*  394 */         reportError(ex);
/*  395 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/*  397 */         throw ex;
/*      */       }
/*      */     }
/*  400 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void insertStatement(AST _t) throws RecognitionException
/*      */   {
/*  405 */     AST insertStatement_AST_in = _t == ASTNULL ? null : _t;
/*  406 */     AST i = null;
/*      */     try
/*      */     {
/*  409 */       AST __t20 = _t;
/*  410 */       AST tmp9_AST_in = _t;
/*  411 */       match(_t, 29);
/*  412 */       _t = _t.getFirstChild();
/*  413 */       if (this.inputState.guessing == 0) {
/*  414 */         out("insert ");
/*      */       }
/*  416 */       i = _t;
/*  417 */       match(_t, 30);
/*  418 */       _t = _t.getNextSibling();
/*  419 */       if (this.inputState.guessing == 0) {
/*  420 */         out(i);out(" ");
/*      */       }
/*  422 */       selectStatement(_t);
/*  423 */       _t = this._retTree;
/*  424 */       _t = __t20;
/*  425 */       _t = _t.getNextSibling();
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  428 */       if (this.inputState.guessing == 0) {
/*  429 */         reportError(ex);
/*  430 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/*  432 */         throw ex;
/*      */       }
/*      */     }
/*  435 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void selectClause(AST _t) throws RecognitionException
/*      */   {
/*  440 */     AST selectClause_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/*  443 */       AST __t48 = _t;
/*  444 */       AST tmp10_AST_in = _t;
/*  445 */       match(_t, 130);
/*  446 */       _t = _t.getFirstChild();
/*      */       
/*  448 */       if (_t == null) _t = ASTNULL;
/*  449 */       switch (_t.getType())
/*      */       {
/*      */       case 4: 
/*      */       case 16: 
/*  453 */         distinctOrAll(_t);
/*  454 */         _t = this._retTree;
/*  455 */         break;
/*      */       
/*      */ 
/*      */       case 12: 
/*      */       case 15: 
/*      */       case 20: 
/*      */       case 45: 
/*      */       case 49: 
/*      */       case 54: 
/*      */       case 68: 
/*      */       case 70: 
/*      */       case 71: 
/*      */       case 78: 
/*      */       case 87: 
/*      */       case 91: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 111: 
/*      */       case 112: 
/*      */       case 116: 
/*      */       case 117: 
/*      */       case 118: 
/*      */       case 119: 
/*      */       case 133: 
/*      */       case 135: 
/*      */       case 137: 
/*      */       case 143: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  489 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/*      */ 
/*  494 */       int _cnt51 = 0;
/*      */       for (;;)
/*      */       {
/*  497 */         if (_t == null) _t = ASTNULL;
/*  498 */         if (_tokenSet_0.member(_t.getType())) {
/*  499 */           selectColumn(_t);
/*  500 */           _t = this._retTree;
/*      */         }
/*      */         else {
/*  503 */           if (_cnt51 >= 1) break; throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*  506 */         _cnt51++;
/*      */       }
/*      */       
/*  509 */       _t = __t48;
/*  510 */       _t = _t.getNextSibling();
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  513 */       if (this.inputState.guessing == 0) {
/*  514 */         reportError(ex);
/*  515 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/*  517 */         throw ex;
/*      */       }
/*      */     }
/*  520 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void from(AST _t) throws RecognitionException
/*      */   {
/*  525 */     AST from_AST_in = _t == ASTNULL ? null : _t;
/*  526 */     AST f = null;
/*      */     try
/*      */     {
/*  529 */       AST __t66 = _t;
/*  530 */       f = _t == ASTNULL ? null : _t;
/*  531 */       match(_t, 22);
/*  532 */       _t = _t.getFirstChild();
/*  533 */       if (this.inputState.guessing == 0) {
/*  534 */         out(" from ");
/*      */       }
/*      */       
/*      */       for (;;)
/*      */       {
/*  539 */         if (_t == null) _t = ASTNULL;
/*  540 */         if ((_t.getType() != 127) && (_t.getType() != 129)) break;
/*  541 */         fromTable(_t);
/*  542 */         _t = this._retTree;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  550 */       _t = __t66;
/*  551 */       _t = _t.getNextSibling();
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  554 */       if (this.inputState.guessing == 0) {
/*  555 */         reportError(ex);
/*  556 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/*  558 */         throw ex;
/*      */       }
/*      */     }
/*  561 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void whereExpr(AST _t) throws RecognitionException
/*      */   {
/*  566 */     AST whereExpr_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/*  569 */       if (_t == null) _t = ASTNULL;
/*  570 */       switch (_t.getType())
/*      */       {
/*      */       case 139: 
/*  573 */         filters(_t);
/*  574 */         _t = this._retTree;
/*      */         
/*  576 */         if (_t == null) _t = ASTNULL;
/*  577 */         switch (_t.getType())
/*      */         {
/*      */         case 138: 
/*  580 */           if (this.inputState.guessing == 0) {
/*  581 */             out(" and ");
/*      */           }
/*  583 */           thetaJoins(_t);
/*  584 */           _t = this._retTree;
/*  585 */           break;
/*      */         
/*      */ 
/*      */         case 3: 
/*      */         case 6: 
/*      */         case 10: 
/*      */         case 19: 
/*      */         case 26: 
/*      */         case 34: 
/*      */         case 38: 
/*      */         case 40: 
/*      */         case 76: 
/*      */         case 77: 
/*      */         case 79: 
/*      */         case 80: 
/*      */         case 81: 
/*      */         case 96: 
/*      */         case 102: 
/*      */         case 104: 
/*      */         case 105: 
/*      */         case 106: 
/*      */         case 107: 
/*      */         case 135: 
/*      */           break;
/*      */         
/*      */ 
/*      */         default: 
/*  612 */           throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*      */         
/*      */ 
/*  617 */         if (_t == null) _t = ASTNULL;
/*  618 */         switch (_t.getType())
/*      */         {
/*      */         case 6: 
/*      */         case 10: 
/*      */         case 19: 
/*      */         case 26: 
/*      */         case 34: 
/*      */         case 38: 
/*      */         case 40: 
/*      */         case 76: 
/*      */         case 77: 
/*      */         case 79: 
/*      */         case 80: 
/*      */         case 81: 
/*      */         case 96: 
/*      */         case 102: 
/*      */         case 104: 
/*      */         case 105: 
/*      */         case 106: 
/*      */         case 107: 
/*      */         case 135: 
/*  639 */           if (this.inputState.guessing == 0) {
/*  640 */             out(" and ");
/*      */           }
/*  642 */           booleanExpr(_t, true);
/*  643 */           _t = this._retTree;
/*  644 */           break;
/*      */         
/*      */ 
/*      */         case 3: 
/*      */           break;
/*      */         
/*      */ 
/*      */         default: 
/*  652 */           throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*      */         
/*      */ 
/*      */ 
/*      */         break;
/*      */       case 138: 
/*  660 */         thetaJoins(_t);
/*  661 */         _t = this._retTree;
/*      */         
/*  663 */         if (_t == null) _t = ASTNULL;
/*  664 */         switch (_t.getType())
/*      */         {
/*      */         case 6: 
/*      */         case 10: 
/*      */         case 19: 
/*      */         case 26: 
/*      */         case 34: 
/*      */         case 38: 
/*      */         case 40: 
/*      */         case 76: 
/*      */         case 77: 
/*      */         case 79: 
/*      */         case 80: 
/*      */         case 81: 
/*      */         case 96: 
/*      */         case 102: 
/*      */         case 104: 
/*      */         case 105: 
/*      */         case 106: 
/*      */         case 107: 
/*      */         case 135: 
/*  685 */           if (this.inputState.guessing == 0) {
/*  686 */             out(" and ");
/*      */           }
/*  688 */           booleanExpr(_t, true);
/*  689 */           _t = this._retTree;
/*  690 */           break;
/*      */         
/*      */ 
/*      */         case 3: 
/*      */           break;
/*      */         
/*      */ 
/*      */         default: 
/*  698 */           throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*      */         
/*      */ 
/*      */ 
/*      */         break;
/*      */       case 6: 
/*      */       case 10: 
/*      */       case 19: 
/*      */       case 26: 
/*      */       case 34: 
/*      */       case 38: 
/*      */       case 40: 
/*      */       case 76: 
/*      */       case 77: 
/*      */       case 79: 
/*      */       case 80: 
/*      */       case 81: 
/*      */       case 96: 
/*      */       case 102: 
/*      */       case 104: 
/*      */       case 105: 
/*      */       case 106: 
/*      */       case 107: 
/*      */       case 135: 
/*  724 */         booleanExpr(_t, false);
/*  725 */         _t = this._retTree;
/*  726 */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  730 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/*  735 */       if (this.inputState.guessing == 0) {
/*  736 */         reportError(ex);
/*  737 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/*  739 */         throw ex;
/*      */       }
/*      */     }
/*  742 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void groupExprs(AST _t) throws RecognitionException
/*      */   {
/*  747 */     AST groupExprs_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/*  750 */       expr(_t);
/*  751 */       _t = this._retTree;
/*      */       
/*  753 */       if (_t == null) _t = ASTNULL;
/*  754 */       switch (_t.getType())
/*      */       {
/*      */       case 4: 
/*      */       case 5: 
/*      */       case 12: 
/*      */       case 15: 
/*      */       case 20: 
/*      */       case 39: 
/*      */       case 45: 
/*      */       case 47: 
/*      */       case 49: 
/*      */       case 54: 
/*      */       case 68: 
/*      */       case 71: 
/*      */       case 75: 
/*      */       case 78: 
/*      */       case 87: 
/*      */       case 89: 
/*      */       case 91: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 111: 
/*      */       case 112: 
/*      */       case 116: 
/*      */       case 117: 
/*      */       case 118: 
/*      */       case 119: 
/*      */       case 133: 
/*      */       case 135: 
/*      */       case 141: 
/*  787 */         if (this.inputState.guessing == 0) {
/*  788 */           out(" , ");
/*      */         }
/*  790 */         groupExprs(_t);
/*  791 */         _t = this._retTree;
/*  792 */         break;
/*      */       case 3: case 25: 
/*      */         break;
/*      */       case 6: case 7: case 8: case 9: case 10: case 11: case 13: case 14: case 16: case 17: case 18: case 19: case 21: case 22: case 23: case 24: case 26: case 27: 
/*      */       case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 40: case 41: case 42: case 43: case 44: case 46: case 48: 
/*      */       case 50: case 51: case 52: case 53: case 55: case 56: case 57: case 58: case 59: case 60: case 61: case 62: case 63: case 64: case 65: case 66: case 67: case 69: 
/*      */       case 70: case 72: case 73: case 74: case 76: case 77: case 79: case 80: case 81: case 82: case 83: case 84: case 85: case 86: case 88: case 90: case 95: case 96: 
/*      */       case 97: case 98: case 99: case 100: case 101: case 102: case 103: case 104: case 105: case 106: case 107: case 108: case 113: case 114: case 115: case 120: case 121: case 122: 
/*      */       case 123: case 124: case 125: case 126: case 127: case 128: case 129: case 130: case 131: case 132: case 134: case 136: case 137: case 138: case 139: case 140: default: 
/*  801 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/*  807 */       if (this.inputState.guessing == 0) {
/*  808 */         reportError(ex);
/*  809 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/*  811 */         throw ex;
/*      */       }
/*      */     }
/*  814 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */ 
/*      */   public final void booleanExpr(AST _t, boolean parens)
/*      */     throws RecognitionException
/*      */   {
/*  821 */     AST booleanExpr_AST_in = _t == ASTNULL ? null : _t;
/*  822 */     AST st = null;
/*      */     try
/*      */     {
/*  825 */       if (_t == null) _t = ASTNULL;
/*  826 */       switch (_t.getType())
/*      */       {
/*      */       case 6: 
/*      */       case 38: 
/*      */       case 40: 
/*  831 */         booleanOp(_t, parens);
/*  832 */         _t = this._retTree;
/*  833 */         break;
/*      */       
/*      */ 
/*      */       case 10: 
/*      */       case 19: 
/*      */       case 26: 
/*      */       case 34: 
/*      */       case 76: 
/*      */       case 77: 
/*      */       case 79: 
/*      */       case 80: 
/*      */       case 81: 
/*      */       case 96: 
/*      */       case 102: 
/*      */       case 104: 
/*      */       case 105: 
/*      */       case 106: 
/*      */       case 107: 
/*  851 */         comparisonExpr(_t, parens);
/*  852 */         _t = this._retTree;
/*  853 */         break;
/*      */       
/*      */ 
/*      */       case 135: 
/*  857 */         st = _t;
/*  858 */         match(_t, 135);
/*  859 */         _t = _t.getNextSibling();
/*  860 */         if (this.inputState.guessing == 0) {
/*  861 */           out(st);
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       default: 
/*  867 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/*  872 */       if (this.inputState.guessing == 0) {
/*  873 */         reportError(ex);
/*  874 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/*  876 */         throw ex;
/*      */       }
/*      */     }
/*  879 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void orderExprs(AST _t) throws RecognitionException
/*      */   {
/*  884 */     AST orderExprs_AST_in = _t == ASTNULL ? null : _t;
/*  885 */     AST dir = null;
/*      */     
/*      */     try
/*      */     {
/*  889 */       expr(_t);
/*  890 */       _t = this._retTree;
/*      */       
/*      */ 
/*  893 */       if (_t == null) _t = ASTNULL;
/*  894 */       switch (_t.getType())
/*      */       {
/*      */       case 8: 
/*      */       case 14: 
/*  898 */         dir = _t == ASTNULL ? null : _t;
/*  899 */         orderDirection(_t);
/*  900 */         _t = this._retTree;
/*  901 */         if (this.inputState.guessing == 0) {
/*  902 */           out(" ");out(dir);
/*      */         }
/*      */         break;
/*      */       case 3: case 4: case 5: case 12: case 15: case 20: case 39: case 45: case 47: case 49: case 54: case 68: case 71: case 75: case 78: case 87: case 89: case 91: case 92: case 93: case 94: case 109: case 110: case 111: case 112: case 116: case 117: case 118: case 119: case 133: case 135: case 141: 
/*      */         break;
/*      */       case 6: case 7: case 9: 
/*      */       case 10: case 11: case 13: 
/*      */       case 16: case 17: case 18: 
/*      */       case 19: case 21: case 22: 
/*      */       case 23: case 24: case 25: 
/*      */       case 26: case 27: case 28: 
/*      */       case 29: case 30: case 31: 
/*      */       case 32: case 33: case 34: 
/*      */       case 35: case 36: case 37: 
/*      */       case 38: case 40: case 41: 
/*      */       case 42: case 43: case 44: 
/*      */       case 46: case 48: case 50: 
/*      */       case 51: case 52: case 53: 
/*      */       case 55: case 56: case 57: 
/*      */       case 58: case 59: case 60: 
/*      */       case 61: case 62: case 63: 
/*      */       case 64: case 65: case 66: 
/*      */       case 67: case 69: case 70: 
/*      */       case 72: case 73: case 74: 
/*      */       case 76: case 77: case 79: 
/*      */       case 80: case 81: case 82: 
/*      */       case 83: case 84: case 85: 
/*      */       case 86: case 88: case 90: 
/*      */       case 95: case 96: case 97: 
/*      */       case 98: case 99: case 100: 
/*      */       case 101: case 102: case 103: 
/*      */       case 104: case 105: case 106: 
/*      */       case 107: case 108: case 113: 
/*      */       case 114: case 115: case 120: 
/*      */       case 121: case 122: case 123: 
/*      */       case 124: case 125: case 126: 
/*      */       case 127: case 128: case 129: 
/*      */       case 130: case 131: case 132: 
/*      */       case 134: case 136: case 137: 
/*      */       case 138: case 139: 
/*      */       case 140: default: 
/*  943 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/*      */ 
/*  948 */       if (_t == null) _t = ASTNULL;
/*  949 */       switch (_t.getType())
/*      */       {
/*      */       case 4: 
/*      */       case 5: 
/*      */       case 12: 
/*      */       case 15: 
/*      */       case 20: 
/*      */       case 39: 
/*      */       case 45: 
/*      */       case 47: 
/*      */       case 49: 
/*      */       case 54: 
/*      */       case 68: 
/*      */       case 71: 
/*      */       case 75: 
/*      */       case 78: 
/*      */       case 87: 
/*      */       case 89: 
/*      */       case 91: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 111: 
/*      */       case 112: 
/*      */       case 116: 
/*      */       case 117: 
/*      */       case 118: 
/*      */       case 119: 
/*      */       case 133: 
/*      */       case 135: 
/*      */       case 141: 
/*  982 */         if (this.inputState.guessing == 0) {
/*  983 */           out(", ");
/*      */         }
/*  985 */         orderExprs(_t);
/*  986 */         _t = this._retTree;
/*  987 */         break;
/*      */       case 3: 
/*      */         break;
/*      */       case 6: case 7: case 8: case 9: case 10: case 11: case 13: case 14: case 16: case 17: case 18: case 19: case 21: case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29: case 30: 
/*      */       case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 40: case 41: case 42: case 43: case 44: case 46: case 48: case 50: case 51: case 52: case 53: case 55: case 56: case 57: 
/*      */       case 58: case 59: case 60: case 61: case 62: case 63: case 64: case 65: case 66: case 67: case 69: case 70: case 72: case 73: case 74: case 76: case 77: case 79: case 80: case 81: case 82: case 83: 
/*      */       case 84: case 85: case 86: case 88: case 90: case 95: case 96: case 97: case 98: case 99: case 100: case 101: case 102: case 103: case 104: case 105: case 106: case 107: case 108: case 113: case 114: 
/*      */       case 115: case 120: case 121: case 122: case 123: case 124: case 125: case 126: case 127: case 128: case 129: case 130: case 131: case 132: case 134: case 136: case 137: case 138: case 139: case 140: default: 
/*  995 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 1001 */       if (this.inputState.guessing == 0) {
/* 1002 */         reportError(ex);
/* 1003 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 1005 */         throw ex;
/*      */       }
/*      */     }
/* 1008 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void fromTable(AST _t) throws RecognitionException
/*      */   {
/* 1013 */     AST fromTable_AST_in = _t == ASTNULL ? null : _t;
/* 1014 */     AST a = null;
/* 1015 */     AST b = null;
/*      */     try
/*      */     {
/* 1018 */       if (_t == null) _t = ASTNULL;
/* 1019 */       switch (_t.getType())
/*      */       {
/*      */       case 127: 
/* 1022 */         AST __t70 = _t;
/* 1023 */         a = _t == ASTNULL ? null : _t;
/* 1024 */         match(_t, 127);
/* 1025 */         _t = _t.getFirstChild();
/* 1026 */         if (this.inputState.guessing == 0) {
/* 1027 */           out(a);
/*      */         }
/*      */         
/*      */         for (;;)
/*      */         {
/* 1032 */           if (_t == null) _t = ASTNULL;
/* 1033 */           if ((_t.getType() != 127) && (_t.getType() != 129)) break;
/* 1034 */           tableJoin(_t, a);
/* 1035 */           _t = this._retTree;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1043 */         if (this.inputState.guessing == 0) {
/* 1044 */           fromFragmentSeparator(a);
/*      */         }
/* 1046 */         _t = __t70;
/* 1047 */         _t = _t.getNextSibling();
/* 1048 */         break;
/*      */       
/*      */ 
/*      */       case 129: 
/* 1052 */         AST __t73 = _t;
/* 1053 */         b = _t == ASTNULL ? null : _t;
/* 1054 */         match(_t, 129);
/* 1055 */         _t = _t.getFirstChild();
/* 1056 */         if (this.inputState.guessing == 0) {
/* 1057 */           out(b);
/*      */         }
/*      */         
/*      */         for (;;)
/*      */         {
/* 1062 */           if (_t == null) _t = ASTNULL;
/* 1063 */           if ((_t.getType() != 127) && (_t.getType() != 129)) break;
/* 1064 */           tableJoin(_t, b);
/* 1065 */           _t = this._retTree;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1073 */         if (this.inputState.guessing == 0) {
/* 1074 */           fromFragmentSeparator(b);
/*      */         }
/* 1076 */         _t = __t73;
/* 1077 */         _t = _t.getNextSibling();
/* 1078 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 1082 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 1087 */       if (this.inputState.guessing == 0) {
/* 1088 */         reportError(ex);
/* 1089 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 1091 */         throw ex;
/*      */       }
/*      */     }
/* 1094 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void setClause(AST _t) throws RecognitionException
/*      */   {
/* 1099 */     AST setClause_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 1102 */       AST __t22 = _t;
/* 1103 */       AST tmp11_AST_in = _t;
/* 1104 */       match(_t, 46);
/* 1105 */       _t = _t.getFirstChild();
/* 1106 */       if (this.inputState.guessing == 0) {
/* 1107 */         out(" set ");
/*      */       }
/* 1109 */       comparisonExpr(_t, false);
/* 1110 */       _t = this._retTree;
/*      */       
/*      */       for (;;)
/*      */       {
/* 1114 */         if (_t == null) _t = ASTNULL;
/* 1115 */         if (!_tokenSet_1.member(_t.getType())) break;
/* 1116 */         if (this.inputState.guessing == 0) {
/* 1117 */           out(", ");
/*      */         }
/* 1119 */         comparisonExpr(_t, false);
/* 1120 */         _t = this._retTree;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1128 */       _t = __t22;
/* 1129 */       _t = _t.getNextSibling();
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1132 */       if (this.inputState.guessing == 0) {
/* 1133 */         reportError(ex);
/* 1134 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 1136 */         throw ex;
/*      */       }
/*      */     }
/* 1139 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void whereClause(AST _t) throws RecognitionException
/*      */   {
/* 1144 */     AST whereClause_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 1147 */       AST __t26 = _t;
/* 1148 */       AST tmp12_AST_in = _t;
/* 1149 */       match(_t, 53);
/* 1150 */       _t = _t.getFirstChild();
/* 1151 */       if (this.inputState.guessing == 0) {
/* 1152 */         out(" where ");
/*      */       }
/* 1154 */       whereClauseExpr(_t);
/* 1155 */       _t = this._retTree;
/* 1156 */       _t = __t26;
/* 1157 */       _t = _t.getNextSibling();
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1160 */       if (this.inputState.guessing == 0) {
/* 1161 */         reportError(ex);
/* 1162 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 1164 */         throw ex;
/*      */       }
/*      */     }
/* 1167 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */ 
/*      */   public final void comparisonExpr(AST _t, boolean parens)
/*      */     throws RecognitionException
/*      */   {
/* 1174 */     AST comparisonExpr_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 1177 */       if (_t == null) _t = ASTNULL;
/* 1178 */       switch (_t.getType())
/*      */       {
/*      */       case 96: 
/*      */       case 102: 
/*      */       case 104: 
/*      */       case 105: 
/*      */       case 106: 
/*      */       case 107: 
/* 1186 */         binaryComparisonExpression(_t);
/* 1187 */         _t = this._retTree;
/* 1188 */         break;
/*      */       
/*      */ 
/*      */       case 10: 
/*      */       case 19: 
/*      */       case 26: 
/*      */       case 34: 
/*      */       case 76: 
/*      */       case 77: 
/*      */       case 79: 
/*      */       case 80: 
/*      */       case 81: 
/* 1200 */         if ((this.inputState.guessing == 0) && 
/* 1201 */           (parens)) { out("(");
/*      */         }
/* 1203 */         exoticComparisonExpression(_t);
/* 1204 */         _t = this._retTree;
/* 1205 */         if ((this.inputState.guessing == 0) && 
/* 1206 */           (parens)) { out(")");
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       default: 
/* 1212 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 1217 */       if (this.inputState.guessing == 0) {
/* 1218 */         reportError(ex);
/* 1219 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 1221 */         throw ex;
/*      */       }
/*      */     }
/* 1224 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void whereClauseExpr(AST _t) throws RecognitionException
/*      */   {
/* 1229 */     AST whereClauseExpr_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 1232 */       boolean synPredMatched29 = false;
/* 1233 */       if (_t.getType() == 135) {
/* 1234 */         AST __t29 = _t;
/* 1235 */         synPredMatched29 = true;
/* 1236 */         this.inputState.guessing += 1;
/*      */         try
/*      */         {
/* 1239 */           AST tmp13_AST_in = _t;
/* 1240 */           match(_t, 135);
/* 1241 */           _t = _t.getNextSibling();
/*      */         }
/*      */         catch (RecognitionException pe)
/*      */         {
/* 1245 */           synPredMatched29 = false;
/*      */         }
/* 1247 */         _t = __t29;
/* 1248 */         this.inputState.guessing -= 1;
/*      */       }
/* 1250 */       if (synPredMatched29) {
/* 1251 */         conditionList(_t);
/* 1252 */         _t = this._retTree;
/*      */       }
/* 1254 */       else if (_tokenSet_2.member(_t.getType())) {
/* 1255 */         booleanExpr(_t, false);
/* 1256 */         _t = this._retTree;
/*      */       }
/*      */       else {
/* 1259 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 1264 */       if (this.inputState.guessing == 0) {
/* 1265 */         reportError(ex);
/* 1266 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 1268 */         throw ex;
/*      */       }
/*      */     }
/* 1271 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void conditionList(AST _t) throws RecognitionException
/*      */   {
/* 1276 */     AST conditionList_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 1279 */       sqlToken(_t);
/* 1280 */       _t = this._retTree;
/*      */       
/* 1282 */       if (_t == null) _t = ASTNULL;
/* 1283 */       switch (_t.getType())
/*      */       {
/*      */       case 135: 
/* 1286 */         if (this.inputState.guessing == 0) {
/* 1287 */           out(" and ");
/*      */         }
/* 1289 */         conditionList(_t);
/* 1290 */         _t = this._retTree;
/* 1291 */         break;
/*      */       
/*      */ 
/*      */       case 3: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 1299 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 1305 */       if (this.inputState.guessing == 0) {
/* 1306 */         reportError(ex);
/* 1307 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 1309 */         throw ex;
/*      */       }
/*      */     }
/* 1312 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void expr(AST _t) throws RecognitionException
/*      */   {
/* 1317 */     AST expr_AST_in = _t == ASTNULL ? null : _t;
/* 1318 */     AST e = null;
/*      */     try
/*      */     {
/* 1321 */       if (_t == null) _t = ASTNULL;
/* 1322 */       switch (_t.getType())
/*      */       {
/*      */       case 12: 
/*      */       case 15: 
/*      */       case 20: 
/*      */       case 39: 
/*      */       case 49: 
/*      */       case 54: 
/*      */       case 68: 
/*      */       case 71: 
/*      */       case 75: 
/*      */       case 78: 
/*      */       case 87: 
/*      */       case 91: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 111: 
/*      */       case 112: 
/*      */       case 116: 
/*      */       case 117: 
/*      */       case 118: 
/*      */       case 119: 
/*      */       case 133: 
/*      */       case 135: 
/*      */       case 141: 
/* 1350 */         simpleExpr(_t);
/* 1351 */         _t = this._retTree;
/* 1352 */         break;
/*      */       
/*      */ 
/*      */       case 89: 
/* 1356 */         AST __t116 = _t;
/* 1357 */         AST tmp14_AST_in = _t;
/* 1358 */         match(_t, 89);
/* 1359 */         _t = _t.getFirstChild();
/* 1360 */         if (this.inputState.guessing == 0) {
/* 1361 */           out("(");
/*      */         }
/*      */         
/*      */         for (;;)
/*      */         {
/* 1366 */           if (_t == null) _t = ASTNULL;
/* 1367 */           if (!_tokenSet_3.member(_t.getType())) break;
/* 1368 */           e = _t == ASTNULL ? null : _t;
/* 1369 */           expr(_t);
/* 1370 */           _t = this._retTree;
/* 1371 */           if (this.inputState.guessing == 0) {
/* 1372 */             separator(e, " , ");
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1381 */         if (this.inputState.guessing == 0) {
/* 1382 */           out(")");
/*      */         }
/* 1384 */         _t = __t116;
/* 1385 */         _t = _t.getNextSibling();
/* 1386 */         break;
/*      */       
/*      */ 
/*      */       case 45: 
/* 1390 */         parenSelect(_t);
/* 1391 */         _t = this._retTree;
/* 1392 */         break;
/*      */       
/*      */ 
/*      */       case 5: 
/* 1396 */         AST __t119 = _t;
/* 1397 */         AST tmp15_AST_in = _t;
/* 1398 */         match(_t, 5);
/* 1399 */         _t = _t.getFirstChild();
/* 1400 */         if (this.inputState.guessing == 0) {
/* 1401 */           out("any ");
/*      */         }
/* 1403 */         quantified(_t);
/* 1404 */         _t = this._retTree;
/* 1405 */         _t = __t119;
/* 1406 */         _t = _t.getNextSibling();
/* 1407 */         break;
/*      */       
/*      */ 
/*      */       case 4: 
/* 1411 */         AST __t120 = _t;
/* 1412 */         AST tmp16_AST_in = _t;
/* 1413 */         match(_t, 4);
/* 1414 */         _t = _t.getFirstChild();
/* 1415 */         if (this.inputState.guessing == 0) {
/* 1416 */           out("all ");
/*      */         }
/* 1418 */         quantified(_t);
/* 1419 */         _t = this._retTree;
/* 1420 */         _t = __t120;
/* 1421 */         _t = _t.getNextSibling();
/* 1422 */         break;
/*      */       
/*      */ 
/*      */       case 47: 
/* 1426 */         AST __t121 = _t;
/* 1427 */         AST tmp17_AST_in = _t;
/* 1428 */         match(_t, 47);
/* 1429 */         _t = _t.getFirstChild();
/* 1430 */         if (this.inputState.guessing == 0) {
/* 1431 */           out("some ");
/*      */         }
/* 1433 */         quantified(_t);
/* 1434 */         _t = this._retTree;
/* 1435 */         _t = __t121;
/* 1436 */         _t = _t.getNextSibling();
/* 1437 */         break;
/*      */       case 6: case 7: case 8: case 9: case 10: case 11: case 13: case 14: case 16: case 17: case 18: case 19: case 21: case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 40: case 41: case 42: case 43: case 44: case 46: 
/*      */       case 48: case 50: case 51: case 52: case 53: case 55: case 56: case 57: case 58: case 59: case 60: case 61: case 62: case 63: case 64: case 65: case 66: case 67: case 69: case 70: case 72: case 73: case 74: case 76: case 77: case 79: case 80: case 81: case 82: case 83: case 84: case 85: case 86: case 88: case 90: case 95: 
/*      */       case 96: case 97: case 98: case 99: case 100: case 101: case 102: case 103: case 104: case 105: case 106: case 107: case 108: case 113: case 114: case 115: case 120: case 121: case 122: case 123: case 124: case 125: case 126: case 127: case 128: case 129: case 130: case 131: case 132: case 134: case 136: case 137: case 138: case 139: case 140: default: 
/* 1441 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 1446 */       if (this.inputState.guessing == 0) {
/* 1447 */         reportError(ex);
/* 1448 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 1450 */         throw ex;
/*      */       }
/*      */     }
/* 1453 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void orderDirection(AST _t) throws RecognitionException
/*      */   {
/* 1458 */     AST orderDirection_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 1461 */       if (_t == null) _t = ASTNULL;
/* 1462 */       switch (_t.getType())
/*      */       {
/*      */       case 8: 
/* 1465 */         AST tmp18_AST_in = _t;
/* 1466 */         match(_t, 8);
/* 1467 */         _t = _t.getNextSibling();
/* 1468 */         break;
/*      */       
/*      */ 
/*      */       case 14: 
/* 1472 */         AST tmp19_AST_in = _t;
/* 1473 */         match(_t, 14);
/* 1474 */         _t = _t.getNextSibling();
/* 1475 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 1479 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 1484 */       if (this.inputState.guessing == 0) {
/* 1485 */         reportError(ex);
/* 1486 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 1488 */         throw ex;
/*      */       }
/*      */     }
/* 1491 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void filters(AST _t) throws RecognitionException
/*      */   {
/* 1496 */     AST filters_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 1499 */       AST __t42 = _t;
/* 1500 */       AST tmp20_AST_in = _t;
/* 1501 */       match(_t, 139);
/* 1502 */       _t = _t.getFirstChild();
/* 1503 */       conditionList(_t);
/* 1504 */       _t = this._retTree;
/* 1505 */       _t = __t42;
/* 1506 */       _t = _t.getNextSibling();
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1509 */       if (this.inputState.guessing == 0) {
/* 1510 */         reportError(ex);
/* 1511 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 1513 */         throw ex;
/*      */       }
/*      */     }
/* 1516 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void thetaJoins(AST _t) throws RecognitionException
/*      */   {
/* 1521 */     AST thetaJoins_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 1524 */       AST __t44 = _t;
/* 1525 */       AST tmp21_AST_in = _t;
/* 1526 */       match(_t, 138);
/* 1527 */       _t = _t.getFirstChild();
/* 1528 */       conditionList(_t);
/* 1529 */       _t = this._retTree;
/* 1530 */       _t = __t44;
/* 1531 */       _t = _t.getNextSibling();
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1534 */       if (this.inputState.guessing == 0) {
/* 1535 */         reportError(ex);
/* 1536 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 1538 */         throw ex;
/*      */       }
/*      */     }
/* 1541 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void sqlToken(AST _t) throws RecognitionException
/*      */   {
/* 1546 */     AST sqlToken_AST_in = _t == ASTNULL ? null : _t;
/* 1547 */     AST t = null;
/*      */     try
/*      */     {
/* 1550 */       t = _t;
/* 1551 */       match(_t, 135);
/* 1552 */       _t = _t.getNextSibling();
/* 1553 */       if (this.inputState.guessing == 0) {
/* 1554 */         out(t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1558 */       if (this.inputState.guessing == 0) {
/* 1559 */         reportError(ex);
/* 1560 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 1562 */         throw ex;
/*      */       }
/*      */     }
/* 1565 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void distinctOrAll(AST _t) throws RecognitionException
/*      */   {
/* 1570 */     AST distinctOrAll_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 1573 */       if (_t == null) _t = ASTNULL;
/* 1574 */       switch (_t.getType())
/*      */       {
/*      */       case 16: 
/* 1577 */         AST tmp22_AST_in = _t;
/* 1578 */         match(_t, 16);
/* 1579 */         _t = _t.getNextSibling();
/* 1580 */         if (this.inputState.guessing == 0) {
/* 1581 */           out("distinct ");
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       case 4: 
/* 1587 */         AST tmp23_AST_in = _t;
/* 1588 */         match(_t, 4);
/* 1589 */         _t = _t.getNextSibling();
/* 1590 */         if (this.inputState.guessing == 0) {
/* 1591 */           out("all ");
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       default: 
/* 1597 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 1602 */       if (this.inputState.guessing == 0) {
/* 1603 */         reportError(ex);
/* 1604 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 1606 */         throw ex;
/*      */       }
/*      */     }
/* 1609 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void selectColumn(AST _t) throws RecognitionException
/*      */   {
/* 1614 */     AST selectColumn_AST_in = _t == ASTNULL ? null : _t;
/* 1615 */     AST p = null;
/* 1616 */     AST sc = null;
/*      */     try
/*      */     {
/* 1619 */       p = _t == ASTNULL ? null : _t;
/* 1620 */       selectExpr(_t);
/* 1621 */       _t = this._retTree;
/*      */       
/* 1623 */       if (_t == null) _t = ASTNULL;
/* 1624 */       switch (_t.getType())
/*      */       {
/*      */       case 136: 
/* 1627 */         sc = _t;
/* 1628 */         match(_t, 136);
/* 1629 */         _t = _t.getNextSibling();
/* 1630 */         if (this.inputState.guessing == 0) {
/* 1631 */           out(sc);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */         break;
/*      */       case 3: 
/*      */       case 12: 
/*      */       case 15: 
/*      */       case 20: 
/*      */       case 45: 
/*      */       case 49: 
/*      */       case 54: 
/*      */       case 68: 
/*      */       case 70: 
/*      */       case 71: 
/*      */       case 78: 
/*      */       case 87: 
/*      */       case 91: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 111: 
/*      */       case 112: 
/*      */       case 116: 
/*      */       case 117: 
/*      */       case 118: 
/*      */       case 119: 
/*      */       case 133: 
/*      */       case 135: 
/*      */       case 137: 
/*      */       case 143: 
/*      */         break;
/*      */       default: 
/* 1668 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/* 1672 */       if (this.inputState.guessing == 0) {
/* 1673 */         separator(sc != null ? sc : p, ", ");
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1677 */       if (this.inputState.guessing == 0) {
/* 1678 */         reportError(ex);
/* 1679 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 1681 */         throw ex;
/*      */       }
/*      */     }
/* 1684 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void selectExpr(AST _t) throws RecognitionException
/*      */   {
/* 1689 */     AST selectExpr_AST_in = _t == ASTNULL ? null : _t;
/* 1690 */     AST e = null;
/* 1691 */     AST c = null;
/* 1692 */     AST sn = null;
/*      */     try
/*      */     {
/* 1695 */       if (_t == null) _t = ASTNULL;
/* 1696 */       switch (_t.getType())
/*      */       {
/*      */       case 15: 
/*      */       case 133: 
/*      */       case 135: 
/*      */       case 137: 
/* 1702 */         e = _t == ASTNULL ? null : _t;
/* 1703 */         selectAtom(_t);
/* 1704 */         _t = this._retTree;
/* 1705 */         if (this.inputState.guessing == 0) {
/* 1706 */           out(e);
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       case 12: 
/* 1712 */         count(_t);
/* 1713 */         _t = this._retTree;
/* 1714 */         break;
/*      */       
/*      */ 
/*      */       case 70: 
/* 1718 */         AST __t55 = _t;
/* 1719 */         AST tmp24_AST_in = _t;
/* 1720 */         match(_t, 70);
/* 1721 */         _t = _t.getFirstChild();
/*      */         
/* 1723 */         if (_t == null) _t = ASTNULL;
/* 1724 */         switch (_t.getType())
/*      */         {
/*      */         case 15: 
/* 1727 */           AST tmp25_AST_in = _t;
/* 1728 */           match(_t, 15);
/* 1729 */           _t = _t.getNextSibling();
/* 1730 */           break;
/*      */         
/*      */ 
/*      */         case 119: 
/* 1734 */           AST tmp26_AST_in = _t;
/* 1735 */           match(_t, 119);
/* 1736 */           _t = _t.getNextSibling();
/* 1737 */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 1741 */           throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*      */         
/*      */ 
/* 1746 */         int _cnt58 = 0;
/*      */         for (;;)
/*      */         {
/* 1749 */           if (_t == null) _t = ASTNULL;
/* 1750 */           if (_tokenSet_0.member(_t.getType())) {
/* 1751 */             selectColumn(_t);
/* 1752 */             _t = this._retTree;
/*      */           }
/*      */           else {
/* 1755 */             if (_cnt58 >= 1) break; throw new NoViableAltException(_t);
/*      */           }
/*      */           
/* 1758 */           _cnt58++;
/*      */         }
/*      */         
/* 1761 */         _t = __t55;
/* 1762 */         _t = _t.getNextSibling();
/* 1763 */         break;
/*      */       
/*      */ 
/*      */       case 78: 
/* 1767 */         methodCall(_t);
/* 1768 */         _t = this._retTree;
/* 1769 */         break;
/*      */       
/*      */ 
/*      */       case 68: 
/* 1773 */         aggregate(_t);
/* 1774 */         _t = this._retTree;
/* 1775 */         break;
/*      */       
/*      */ 
/*      */       case 20: 
/*      */       case 49: 
/*      */       case 91: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 117: 
/*      */       case 118: 
/*      */       case 119: 
/* 1787 */         c = _t == ASTNULL ? null : _t;
/* 1788 */         constant(_t);
/* 1789 */         _t = this._retTree;
/* 1790 */         if (this.inputState.guessing == 0) {
/* 1791 */           out(c);
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       case 54: 
/*      */       case 71: 
/*      */       case 87: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 111: 
/*      */       case 112: 
/* 1803 */         arithmeticExpr(_t);
/* 1804 */         _t = this._retTree;
/* 1805 */         break;
/*      */       
/*      */ 
/*      */       case 116: 
/* 1809 */         AST tmp27_AST_in = _t;
/* 1810 */         match(_t, 116);
/* 1811 */         _t = _t.getNextSibling();
/* 1812 */         if (this.inputState.guessing == 0) {
/* 1813 */           out("?");
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       case 143: 
/* 1819 */         sn = _t;
/* 1820 */         match(_t, 143);
/* 1821 */         _t = _t.getNextSibling();
/* 1822 */         if (this.inputState.guessing == 0) {
/* 1823 */           out(sn);
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       case 45: 
/* 1829 */         if (this.inputState.guessing == 0) {
/* 1830 */           out("(");
/*      */         }
/* 1832 */         selectStatement(_t);
/* 1833 */         _t = this._retTree;
/* 1834 */         if (this.inputState.guessing == 0) {
/* 1835 */           out(")");
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       default: 
/* 1841 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 1846 */       if (this.inputState.guessing == 0) {
/* 1847 */         reportError(ex);
/* 1848 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 1850 */         throw ex;
/*      */       }
/*      */     }
/* 1853 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void selectAtom(AST _t) throws RecognitionException
/*      */   {
/* 1858 */     AST selectAtom_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 1861 */       if (_t == null) _t = ASTNULL;
/* 1862 */       switch (_t.getType())
/*      */       {
/*      */       case 15: 
/* 1865 */         AST tmp28_AST_in = _t;
/* 1866 */         match(_t, 15);
/* 1867 */         _t = _t.getNextSibling();
/* 1868 */         break;
/*      */       
/*      */ 
/*      */       case 135: 
/* 1872 */         AST tmp29_AST_in = _t;
/* 1873 */         match(_t, 135);
/* 1874 */         _t = _t.getNextSibling();
/* 1875 */         break;
/*      */       
/*      */ 
/*      */       case 133: 
/* 1879 */         AST tmp30_AST_in = _t;
/* 1880 */         match(_t, 133);
/* 1881 */         _t = _t.getNextSibling();
/* 1882 */         break;
/*      */       
/*      */ 
/*      */       case 137: 
/* 1886 */         AST tmp31_AST_in = _t;
/* 1887 */         match(_t, 137);
/* 1888 */         _t = _t.getNextSibling();
/* 1889 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 1893 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 1898 */       if (this.inputState.guessing == 0) {
/* 1899 */         reportError(ex);
/* 1900 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 1902 */         throw ex;
/*      */       }
/*      */     }
/* 1905 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void count(AST _t) throws RecognitionException
/*      */   {
/* 1910 */     AST count_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 1913 */       AST __t60 = _t;
/* 1914 */       AST tmp32_AST_in = _t;
/* 1915 */       match(_t, 12);
/* 1916 */       _t = _t.getFirstChild();
/* 1917 */       if (this.inputState.guessing == 0) {
/* 1918 */         out("count(");
/*      */       }
/*      */       
/* 1921 */       if (_t == null) _t = ASTNULL;
/* 1922 */       switch (_t.getType())
/*      */       {
/*      */       case 4: 
/*      */       case 16: 
/* 1926 */         distinctOrAll(_t);
/* 1927 */         _t = this._retTree;
/* 1928 */         break;
/*      */       
/*      */ 
/*      */       case 12: 
/*      */       case 15: 
/*      */       case 20: 
/*      */       case 39: 
/*      */       case 49: 
/*      */       case 54: 
/*      */       case 68: 
/*      */       case 71: 
/*      */       case 75: 
/*      */       case 78: 
/*      */       case 85: 
/*      */       case 87: 
/*      */       case 91: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 111: 
/*      */       case 112: 
/*      */       case 116: 
/*      */       case 117: 
/*      */       case 118: 
/*      */       case 119: 
/*      */       case 133: 
/*      */       case 135: 
/*      */       case 141: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 1962 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/* 1966 */       countExpr(_t);
/* 1967 */       _t = this._retTree;
/* 1968 */       if (this.inputState.guessing == 0) {
/* 1969 */         out(")");
/*      */       }
/* 1971 */       _t = __t60;
/* 1972 */       _t = _t.getNextSibling();
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1975 */       if (this.inputState.guessing == 0) {
/* 1976 */         reportError(ex);
/* 1977 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 1979 */         throw ex;
/*      */       }
/*      */     }
/* 1982 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void methodCall(AST _t) throws RecognitionException
/*      */   {
/* 1987 */     AST methodCall_AST_in = _t == ASTNULL ? null : _t;
/* 1988 */     AST m = null;
/* 1989 */     AST i = null;
/*      */     try
/*      */     {
/* 1992 */       AST __t157 = _t;
/* 1993 */       m = _t == ASTNULL ? null : _t;
/* 1994 */       match(_t, 78);
/* 1995 */       _t = _t.getFirstChild();
/* 1996 */       i = _t;
/* 1997 */       match(_t, 140);
/* 1998 */       _t = _t.getNextSibling();
/* 1999 */       if (this.inputState.guessing == 0) {
/* 2000 */         beginFunctionTemplate(m, i);
/*      */       }
/*      */       
/* 2003 */       if (_t == null) _t = ASTNULL;
/* 2004 */       switch (_t.getType())
/*      */       {
/*      */       case 72: 
/* 2007 */         AST __t159 = _t;
/* 2008 */         AST tmp33_AST_in = _t;
/* 2009 */         match(_t, 72);
/* 2010 */         _t = _t.getFirstChild();
/*      */         
/* 2012 */         if (_t == null) _t = ASTNULL;
/* 2013 */         switch (_t.getType())
/*      */         {
/*      */         case 4: 
/*      */         case 5: 
/*      */         case 12: 
/*      */         case 15: 
/*      */         case 20: 
/*      */         case 39: 
/*      */         case 45: 
/*      */         case 47: 
/*      */         case 49: 
/*      */         case 54: 
/*      */         case 68: 
/*      */         case 71: 
/*      */         case 75: 
/*      */         case 78: 
/*      */         case 87: 
/*      */         case 89: 
/*      */         case 91: 
/*      */         case 92: 
/*      */         case 93: 
/*      */         case 94: 
/*      */         case 109: 
/*      */         case 110: 
/*      */         case 111: 
/*      */         case 112: 
/*      */         case 116: 
/*      */         case 117: 
/*      */         case 118: 
/*      */         case 119: 
/*      */         case 133: 
/*      */         case 135: 
/*      */         case 141: 
/* 2046 */           arguments(_t);
/* 2047 */           _t = this._retTree;
/* 2048 */           break;
/*      */         case 3: 
/*      */           break;
/*      */         case 6: case 7: case 8: case 9: case 10: case 11: case 13: case 14: case 16: case 17: case 18: case 19: case 21: case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29: case 30: 
/*      */         case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 40: case 41: case 42: case 43: case 44: case 46: case 48: case 50: case 51: case 52: case 53: case 55: case 56: case 57: 
/*      */         case 58: case 59: case 60: case 61: case 62: case 63: case 64: case 65: case 66: case 67: case 69: case 70: case 72: case 73: case 74: case 76: case 77: case 79: case 80: case 81: case 82: case 83: 
/*      */         case 84: case 85: case 86: case 88: case 90: case 95: case 96: case 97: case 98: case 99: case 100: case 101: case 102: case 103: case 104: case 105: case 106: case 107: case 108: case 113: case 114: 
/*      */         case 115: case 120: case 121: case 122: case 123: case 124: case 125: case 126: case 127: case 128: case 129: case 130: case 131: case 132: case 134: case 136: case 137: case 138: case 139: case 140: default: 
/* 2056 */           throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*      */         
/* 2060 */         _t = __t159;
/* 2061 */         _t = _t.getNextSibling();
/* 2062 */         break;
/*      */       
/*      */ 
/*      */       case 3: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 2070 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/* 2074 */       if (this.inputState.guessing == 0) {
/* 2075 */         endFunctionTemplate(m);
/*      */       }
/* 2077 */       _t = __t157;
/* 2078 */       _t = _t.getNextSibling();
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2081 */       if (this.inputState.guessing == 0) {
/* 2082 */         reportError(ex);
/* 2083 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 2085 */         throw ex;
/*      */       }
/*      */     }
/* 2088 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void aggregate(AST _t) throws RecognitionException
/*      */   {
/* 2093 */     AST aggregate_AST_in = _t == ASTNULL ? null : _t;
/* 2094 */     AST a = null;
/*      */     try
/*      */     {
/* 2097 */       AST __t155 = _t;
/* 2098 */       a = _t == ASTNULL ? null : _t;
/* 2099 */       match(_t, 68);
/* 2100 */       _t = _t.getFirstChild();
/* 2101 */       if (this.inputState.guessing == 0) {
/* 2102 */         out(a);out("(");
/*      */       }
/* 2104 */       expr(_t);
/* 2105 */       _t = this._retTree;
/* 2106 */       if (this.inputState.guessing == 0) {
/* 2107 */         out(")");
/*      */       }
/* 2109 */       _t = __t155;
/* 2110 */       _t = _t.getNextSibling();
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2113 */       if (this.inputState.guessing == 0) {
/* 2114 */         reportError(ex);
/* 2115 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 2117 */         throw ex;
/*      */       }
/*      */     }
/* 2120 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void constant(AST _t) throws RecognitionException
/*      */   {
/* 2125 */     AST constant_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 2128 */       if (_t == null) _t = ASTNULL;
/* 2129 */       switch (_t.getType())
/*      */       {
/*      */       case 92: 
/* 2132 */         AST tmp34_AST_in = _t;
/* 2133 */         match(_t, 92);
/* 2134 */         _t = _t.getNextSibling();
/* 2135 */         break;
/*      */       
/*      */ 
/*      */       case 93: 
/* 2139 */         AST tmp35_AST_in = _t;
/* 2140 */         match(_t, 93);
/* 2141 */         _t = _t.getNextSibling();
/* 2142 */         break;
/*      */       
/*      */ 
/*      */       case 117: 
/* 2146 */         AST tmp36_AST_in = _t;
/* 2147 */         match(_t, 117);
/* 2148 */         _t = _t.getNextSibling();
/* 2149 */         break;
/*      */       
/*      */ 
/*      */       case 94: 
/* 2153 */         AST tmp37_AST_in = _t;
/* 2154 */         match(_t, 94);
/* 2155 */         _t = _t.getNextSibling();
/* 2156 */         break;
/*      */       
/*      */ 
/*      */       case 118: 
/* 2160 */         AST tmp38_AST_in = _t;
/* 2161 */         match(_t, 118);
/* 2162 */         _t = _t.getNextSibling();
/* 2163 */         break;
/*      */       
/*      */ 
/*      */       case 91: 
/* 2167 */         AST tmp39_AST_in = _t;
/* 2168 */         match(_t, 91);
/* 2169 */         _t = _t.getNextSibling();
/* 2170 */         break;
/*      */       
/*      */ 
/*      */       case 49: 
/* 2174 */         AST tmp40_AST_in = _t;
/* 2175 */         match(_t, 49);
/* 2176 */         _t = _t.getNextSibling();
/* 2177 */         break;
/*      */       
/*      */ 
/*      */       case 20: 
/* 2181 */         AST tmp41_AST_in = _t;
/* 2182 */         match(_t, 20);
/* 2183 */         _t = _t.getNextSibling();
/* 2184 */         break;
/*      */       
/*      */ 
/*      */       case 119: 
/* 2188 */         AST tmp42_AST_in = _t;
/* 2189 */         match(_t, 119);
/* 2190 */         _t = _t.getNextSibling();
/* 2191 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 2195 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 2200 */       if (this.inputState.guessing == 0) {
/* 2201 */         reportError(ex);
/* 2202 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 2204 */         throw ex;
/*      */       }
/*      */     }
/* 2207 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void arithmeticExpr(AST _t) throws RecognitionException
/*      */   {
/* 2212 */     AST arithmeticExpr_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 2215 */       if (_t == null) _t = ASTNULL;
/* 2216 */       switch (_t.getType())
/*      */       {
/*      */       case 109: 
/*      */       case 110: 
/* 2220 */         additiveExpr(_t);
/* 2221 */         _t = this._retTree;
/* 2222 */         break;
/*      */       
/*      */ 
/*      */       case 111: 
/*      */       case 112: 
/* 2227 */         multiplicativeExpr(_t);
/* 2228 */         _t = this._retTree;
/* 2229 */         break;
/*      */       
/*      */ 
/*      */       case 87: 
/* 2233 */         AST __t128 = _t;
/* 2234 */         AST tmp43_AST_in = _t;
/* 2235 */         match(_t, 87);
/* 2236 */         _t = _t.getFirstChild();
/* 2237 */         if (this.inputState.guessing == 0) {
/* 2238 */           out("-");
/*      */         }
/* 2240 */         expr(_t);
/* 2241 */         _t = this._retTree;
/* 2242 */         _t = __t128;
/* 2243 */         _t = _t.getNextSibling();
/* 2244 */         break;
/*      */       
/*      */ 
/*      */       case 54: 
/*      */       case 71: 
/* 2249 */         caseExpr(_t);
/* 2250 */         _t = this._retTree;
/* 2251 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 2255 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 2260 */       if (this.inputState.guessing == 0) {
/* 2261 */         reportError(ex);
/* 2262 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 2264 */         throw ex;
/*      */       }
/*      */     }
/* 2267 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void countExpr(AST _t) throws RecognitionException
/*      */   {
/* 2272 */     AST countExpr_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 2275 */       if (_t == null) _t = ASTNULL;
/* 2276 */       switch (_t.getType())
/*      */       {
/*      */       case 85: 
/* 2279 */         AST tmp44_AST_in = _t;
/* 2280 */         match(_t, 85);
/* 2281 */         _t = _t.getNextSibling();
/* 2282 */         if (this.inputState.guessing == 0) {
/* 2283 */           out("*");
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       case 12: 
/*      */       case 15: 
/*      */       case 20: 
/*      */       case 39: 
/*      */       case 49: 
/*      */       case 54: 
/*      */       case 68: 
/*      */       case 71: 
/*      */       case 75: 
/*      */       case 78: 
/*      */       case 87: 
/*      */       case 91: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 111: 
/*      */       case 112: 
/*      */       case 116: 
/*      */       case 117: 
/*      */       case 118: 
/*      */       case 119: 
/*      */       case 133: 
/*      */       case 135: 
/*      */       case 141: 
/* 2314 */         simpleExpr(_t);
/* 2315 */         _t = this._retTree;
/* 2316 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 2320 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 2325 */       if (this.inputState.guessing == 0) {
/* 2326 */         reportError(ex);
/* 2327 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 2329 */         throw ex;
/*      */       }
/*      */     }
/* 2332 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void simpleExpr(AST _t) throws RecognitionException
/*      */   {
/* 2337 */     AST simpleExpr_AST_in = _t == ASTNULL ? null : _t;
/* 2338 */     AST c = null;
/*      */     try
/*      */     {
/* 2341 */       if (_t == null) _t = ASTNULL;
/* 2342 */       switch (_t.getType())
/*      */       {
/*      */       case 20: 
/*      */       case 49: 
/*      */       case 91: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 117: 
/*      */       case 118: 
/*      */       case 119: 
/* 2353 */         c = _t == ASTNULL ? null : _t;
/* 2354 */         constant(_t);
/* 2355 */         _t = this._retTree;
/* 2356 */         if (this.inputState.guessing == 0) {
/* 2357 */           out(c);
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       case 39: 
/* 2363 */         AST tmp45_AST_in = _t;
/* 2364 */         match(_t, 39);
/* 2365 */         _t = _t.getNextSibling();
/* 2366 */         if (this.inputState.guessing == 0) {
/* 2367 */           out("null");
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       case 15: 
/*      */       case 75: 
/*      */       case 133: 
/* 2375 */         addrExpr(_t);
/* 2376 */         _t = this._retTree;
/* 2377 */         break;
/*      */       
/*      */ 
/*      */       case 135: 
/* 2381 */         sqlToken(_t);
/* 2382 */         _t = this._retTree;
/* 2383 */         break;
/*      */       
/*      */ 
/*      */       case 68: 
/* 2387 */         aggregate(_t);
/* 2388 */         _t = this._retTree;
/* 2389 */         break;
/*      */       
/*      */ 
/*      */       case 78: 
/* 2393 */         methodCall(_t);
/* 2394 */         _t = this._retTree;
/* 2395 */         break;
/*      */       
/*      */ 
/*      */       case 12: 
/* 2399 */         count(_t);
/* 2400 */         _t = this._retTree;
/* 2401 */         break;
/*      */       
/*      */ 
/*      */       case 116: 
/*      */       case 141: 
/* 2406 */         parameter(_t);
/* 2407 */         _t = this._retTree;
/* 2408 */         break;
/*      */       
/*      */ 
/*      */       case 54: 
/*      */       case 71: 
/*      */       case 87: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 111: 
/*      */       case 112: 
/* 2418 */         arithmeticExpr(_t);
/* 2419 */         _t = this._retTree;
/* 2420 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 2424 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 2429 */       if (this.inputState.guessing == 0) {
/* 2430 */         reportError(ex);
/* 2431 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 2433 */         throw ex;
/*      */       }
/*      */     }
/* 2436 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */ 
/*      */   public final void tableJoin(AST _t, AST parent)
/*      */     throws RecognitionException
/*      */   {
/* 2443 */     AST tableJoin_AST_in = _t == ASTNULL ? null : _t;
/* 2444 */     AST c = null;
/* 2445 */     AST d = null;
/*      */     try
/*      */     {
/* 2448 */       if (_t == null) _t = ASTNULL;
/* 2449 */       switch (_t.getType())
/*      */       {
/*      */       case 129: 
/* 2452 */         AST __t77 = _t;
/* 2453 */         c = _t == ASTNULL ? null : _t;
/* 2454 */         match(_t, 129);
/* 2455 */         _t = _t.getFirstChild();
/* 2456 */         if (this.inputState.guessing == 0) {
/* 2457 */           out(" ");out(c);
/*      */         }
/*      */         
/*      */         for (;;)
/*      */         {
/* 2462 */           if (_t == null) _t = ASTNULL;
/* 2463 */           if ((_t.getType() != 127) && (_t.getType() != 129)) break;
/* 2464 */           tableJoin(_t, c);
/* 2465 */           _t = this._retTree;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2473 */         _t = __t77;
/* 2474 */         _t = _t.getNextSibling();
/* 2475 */         break;
/*      */       
/*      */ 
/*      */       case 127: 
/* 2479 */         AST __t80 = _t;
/* 2480 */         d = _t == ASTNULL ? null : _t;
/* 2481 */         match(_t, 127);
/* 2482 */         _t = _t.getFirstChild();
/* 2483 */         if (this.inputState.guessing == 0) {
/* 2484 */           nestedFromFragment(d, parent);
/*      */         }
/*      */         
/*      */         for (;;)
/*      */         {
/* 2489 */           if (_t == null) _t = ASTNULL;
/* 2490 */           if ((_t.getType() != 127) && (_t.getType() != 129)) break;
/* 2491 */           tableJoin(_t, d);
/* 2492 */           _t = this._retTree;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2500 */         _t = __t80;
/* 2501 */         _t = _t.getNextSibling();
/* 2502 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 2506 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 2511 */       if (this.inputState.guessing == 0) {
/* 2512 */         reportError(ex);
/* 2513 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 2515 */         throw ex;
/*      */       }
/*      */     }
/* 2518 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */ 
/*      */   public final void booleanOp(AST _t, boolean parens)
/*      */     throws RecognitionException
/*      */   {
/* 2525 */     AST booleanOp_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 2528 */       if (_t == null) _t = ASTNULL;
/* 2529 */       switch (_t.getType())
/*      */       {
/*      */       case 6: 
/* 2532 */         AST __t84 = _t;
/* 2533 */         AST tmp46_AST_in = _t;
/* 2534 */         match(_t, 6);
/* 2535 */         _t = _t.getFirstChild();
/* 2536 */         booleanExpr(_t, true);
/* 2537 */         _t = this._retTree;
/* 2538 */         if (this.inputState.guessing == 0) {
/* 2539 */           out(" and ");
/*      */         }
/* 2541 */         booleanExpr(_t, true);
/* 2542 */         _t = this._retTree;
/* 2543 */         _t = __t84;
/* 2544 */         _t = _t.getNextSibling();
/* 2545 */         break;
/*      */       
/*      */ 
/*      */       case 40: 
/* 2549 */         AST __t85 = _t;
/* 2550 */         AST tmp47_AST_in = _t;
/* 2551 */         match(_t, 40);
/* 2552 */         _t = _t.getFirstChild();
/* 2553 */         if ((this.inputState.guessing == 0) && 
/* 2554 */           (parens)) { out("(");
/*      */         }
/* 2556 */         booleanExpr(_t, false);
/* 2557 */         _t = this._retTree;
/* 2558 */         if (this.inputState.guessing == 0) {
/* 2559 */           out(" or ");
/*      */         }
/* 2561 */         booleanExpr(_t, false);
/* 2562 */         _t = this._retTree;
/* 2563 */         if ((this.inputState.guessing == 0) && 
/* 2564 */           (parens)) { out(")");
/*      */         }
/* 2566 */         _t = __t85;
/* 2567 */         _t = _t.getNextSibling();
/* 2568 */         break;
/*      */       
/*      */ 
/*      */       case 38: 
/* 2572 */         AST __t86 = _t;
/* 2573 */         AST tmp48_AST_in = _t;
/* 2574 */         match(_t, 38);
/* 2575 */         _t = _t.getFirstChild();
/* 2576 */         if (this.inputState.guessing == 0) {
/* 2577 */           out(" not (");
/*      */         }
/* 2579 */         booleanExpr(_t, false);
/* 2580 */         _t = this._retTree;
/* 2581 */         if (this.inputState.guessing == 0) {
/* 2582 */           out(")");
/*      */         }
/* 2584 */         _t = __t86;
/* 2585 */         _t = _t.getNextSibling();
/* 2586 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 2590 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 2595 */       if (this.inputState.guessing == 0) {
/* 2596 */         reportError(ex);
/* 2597 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 2599 */         throw ex;
/*      */       }
/*      */     }
/* 2602 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void binaryComparisonExpression(AST _t) throws RecognitionException
/*      */   {
/* 2607 */     AST binaryComparisonExpression_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 2610 */       if (_t == null) _t = ASTNULL;
/* 2611 */       switch (_t.getType())
/*      */       {
/*      */       case 96: 
/* 2614 */         AST __t90 = _t;
/* 2615 */         AST tmp49_AST_in = _t;
/* 2616 */         match(_t, 96);
/* 2617 */         _t = _t.getFirstChild();
/* 2618 */         expr(_t);
/* 2619 */         _t = this._retTree;
/* 2620 */         if (this.inputState.guessing == 0) {
/* 2621 */           out("=");
/*      */         }
/* 2623 */         expr(_t);
/* 2624 */         _t = this._retTree;
/* 2625 */         _t = __t90;
/* 2626 */         _t = _t.getNextSibling();
/* 2627 */         break;
/*      */       
/*      */ 
/*      */       case 102: 
/* 2631 */         AST __t91 = _t;
/* 2632 */         AST tmp50_AST_in = _t;
/* 2633 */         match(_t, 102);
/* 2634 */         _t = _t.getFirstChild();
/* 2635 */         expr(_t);
/* 2636 */         _t = this._retTree;
/* 2637 */         if (this.inputState.guessing == 0) {
/* 2638 */           out("<>");
/*      */         }
/* 2640 */         expr(_t);
/* 2641 */         _t = this._retTree;
/* 2642 */         _t = __t91;
/* 2643 */         _t = _t.getNextSibling();
/* 2644 */         break;
/*      */       
/*      */ 
/*      */       case 105: 
/* 2648 */         AST __t92 = _t;
/* 2649 */         AST tmp51_AST_in = _t;
/* 2650 */         match(_t, 105);
/* 2651 */         _t = _t.getFirstChild();
/* 2652 */         expr(_t);
/* 2653 */         _t = this._retTree;
/* 2654 */         if (this.inputState.guessing == 0) {
/* 2655 */           out(">");
/*      */         }
/* 2657 */         expr(_t);
/* 2658 */         _t = this._retTree;
/* 2659 */         _t = __t92;
/* 2660 */         _t = _t.getNextSibling();
/* 2661 */         break;
/*      */       
/*      */ 
/*      */       case 107: 
/* 2665 */         AST __t93 = _t;
/* 2666 */         AST tmp52_AST_in = _t;
/* 2667 */         match(_t, 107);
/* 2668 */         _t = _t.getFirstChild();
/* 2669 */         expr(_t);
/* 2670 */         _t = this._retTree;
/* 2671 */         if (this.inputState.guessing == 0) {
/* 2672 */           out(">=");
/*      */         }
/* 2674 */         expr(_t);
/* 2675 */         _t = this._retTree;
/* 2676 */         _t = __t93;
/* 2677 */         _t = _t.getNextSibling();
/* 2678 */         break;
/*      */       
/*      */ 
/*      */       case 104: 
/* 2682 */         AST __t94 = _t;
/* 2683 */         AST tmp53_AST_in = _t;
/* 2684 */         match(_t, 104);
/* 2685 */         _t = _t.getFirstChild();
/* 2686 */         expr(_t);
/* 2687 */         _t = this._retTree;
/* 2688 */         if (this.inputState.guessing == 0) {
/* 2689 */           out("<");
/*      */         }
/* 2691 */         expr(_t);
/* 2692 */         _t = this._retTree;
/* 2693 */         _t = __t94;
/* 2694 */         _t = _t.getNextSibling();
/* 2695 */         break;
/*      */       
/*      */ 
/*      */       case 106: 
/* 2699 */         AST __t95 = _t;
/* 2700 */         AST tmp54_AST_in = _t;
/* 2701 */         match(_t, 106);
/* 2702 */         _t = _t.getFirstChild();
/* 2703 */         expr(_t);
/* 2704 */         _t = this._retTree;
/* 2705 */         if (this.inputState.guessing == 0) {
/* 2706 */           out("<=");
/*      */         }
/* 2708 */         expr(_t);
/* 2709 */         _t = this._retTree;
/* 2710 */         _t = __t95;
/* 2711 */         _t = _t.getNextSibling();
/* 2712 */         break;
/*      */       case 97: case 98: case 99: 
/*      */       case 100: case 101: 
/*      */       case 103: default: 
/* 2716 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 2721 */       if (this.inputState.guessing == 0) {
/* 2722 */         reportError(ex);
/* 2723 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 2725 */         throw ex;
/*      */       }
/*      */     }
/* 2728 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void exoticComparisonExpression(AST _t) throws RecognitionException
/*      */   {
/* 2733 */     AST exoticComparisonExpression_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 2736 */       if (_t == null) _t = ASTNULL;
/* 2737 */       switch (_t.getType())
/*      */       {
/*      */       case 34: 
/* 2740 */         AST __t97 = _t;
/* 2741 */         AST tmp55_AST_in = _t;
/* 2742 */         match(_t, 34);
/* 2743 */         _t = _t.getFirstChild();
/* 2744 */         expr(_t);
/* 2745 */         _t = this._retTree;
/* 2746 */         if (this.inputState.guessing == 0) {
/* 2747 */           out(" like ");
/*      */         }
/* 2749 */         expr(_t);
/* 2750 */         _t = this._retTree;
/* 2751 */         likeEscape(_t);
/* 2752 */         _t = this._retTree;
/* 2753 */         _t = __t97;
/* 2754 */         _t = _t.getNextSibling();
/* 2755 */         break;
/*      */       
/*      */ 
/*      */       case 81: 
/* 2759 */         AST __t98 = _t;
/* 2760 */         AST tmp56_AST_in = _t;
/* 2761 */         match(_t, 81);
/* 2762 */         _t = _t.getFirstChild();
/* 2763 */         expr(_t);
/* 2764 */         _t = this._retTree;
/* 2765 */         if (this.inputState.guessing == 0) {
/* 2766 */           out(" not like ");
/*      */         }
/* 2768 */         expr(_t);
/* 2769 */         _t = this._retTree;
/* 2770 */         likeEscape(_t);
/* 2771 */         _t = this._retTree;
/* 2772 */         _t = __t98;
/* 2773 */         _t = _t.getNextSibling();
/* 2774 */         break;
/*      */       
/*      */ 
/*      */       case 10: 
/* 2778 */         AST __t99 = _t;
/* 2779 */         AST tmp57_AST_in = _t;
/* 2780 */         match(_t, 10);
/* 2781 */         _t = _t.getFirstChild();
/* 2782 */         expr(_t);
/* 2783 */         _t = this._retTree;
/* 2784 */         if (this.inputState.guessing == 0) {
/* 2785 */           out(" between ");
/*      */         }
/* 2787 */         expr(_t);
/* 2788 */         _t = this._retTree;
/* 2789 */         if (this.inputState.guessing == 0) {
/* 2790 */           out(" and ");
/*      */         }
/* 2792 */         expr(_t);
/* 2793 */         _t = this._retTree;
/* 2794 */         _t = __t99;
/* 2795 */         _t = _t.getNextSibling();
/* 2796 */         break;
/*      */       
/*      */ 
/*      */       case 79: 
/* 2800 */         AST __t100 = _t;
/* 2801 */         AST tmp58_AST_in = _t;
/* 2802 */         match(_t, 79);
/* 2803 */         _t = _t.getFirstChild();
/* 2804 */         expr(_t);
/* 2805 */         _t = this._retTree;
/* 2806 */         if (this.inputState.guessing == 0) {
/* 2807 */           out(" not between ");
/*      */         }
/* 2809 */         expr(_t);
/* 2810 */         _t = this._retTree;
/* 2811 */         if (this.inputState.guessing == 0) {
/* 2812 */           out(" and ");
/*      */         }
/* 2814 */         expr(_t);
/* 2815 */         _t = this._retTree;
/* 2816 */         _t = __t100;
/* 2817 */         _t = _t.getNextSibling();
/* 2818 */         break;
/*      */       
/*      */ 
/*      */       case 26: 
/* 2822 */         AST __t101 = _t;
/* 2823 */         AST tmp59_AST_in = _t;
/* 2824 */         match(_t, 26);
/* 2825 */         _t = _t.getFirstChild();
/* 2826 */         expr(_t);
/* 2827 */         _t = this._retTree;
/* 2828 */         if (this.inputState.guessing == 0) {
/* 2829 */           out(" in");
/*      */         }
/* 2831 */         inList(_t);
/* 2832 */         _t = this._retTree;
/* 2833 */         _t = __t101;
/* 2834 */         _t = _t.getNextSibling();
/* 2835 */         break;
/*      */       
/*      */ 
/*      */       case 80: 
/* 2839 */         AST __t102 = _t;
/* 2840 */         AST tmp60_AST_in = _t;
/* 2841 */         match(_t, 80);
/* 2842 */         _t = _t.getFirstChild();
/* 2843 */         expr(_t);
/* 2844 */         _t = this._retTree;
/* 2845 */         if (this.inputState.guessing == 0) {
/* 2846 */           out(" not in ");
/*      */         }
/* 2848 */         inList(_t);
/* 2849 */         _t = this._retTree;
/* 2850 */         _t = __t102;
/* 2851 */         _t = _t.getNextSibling();
/* 2852 */         break;
/*      */       
/*      */ 
/*      */       case 19: 
/* 2856 */         AST __t103 = _t;
/* 2857 */         AST tmp61_AST_in = _t;
/* 2858 */         match(_t, 19);
/* 2859 */         _t = _t.getFirstChild();
/* 2860 */         if (this.inputState.guessing == 0) {
/* 2861 */           optionalSpace();out("exists ");
/*      */         }
/* 2863 */         quantified(_t);
/* 2864 */         _t = this._retTree;
/* 2865 */         _t = __t103;
/* 2866 */         _t = _t.getNextSibling();
/* 2867 */         break;
/*      */       
/*      */ 
/*      */       case 77: 
/* 2871 */         AST __t104 = _t;
/* 2872 */         AST tmp62_AST_in = _t;
/* 2873 */         match(_t, 77);
/* 2874 */         _t = _t.getFirstChild();
/* 2875 */         expr(_t);
/* 2876 */         _t = this._retTree;
/* 2877 */         _t = __t104;
/* 2878 */         _t = _t.getNextSibling();
/* 2879 */         if (this.inputState.guessing == 0) {
/* 2880 */           out(" is null");
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       case 76: 
/* 2886 */         AST __t105 = _t;
/* 2887 */         AST tmp63_AST_in = _t;
/* 2888 */         match(_t, 76);
/* 2889 */         _t = _t.getFirstChild();
/* 2890 */         expr(_t);
/* 2891 */         _t = this._retTree;
/* 2892 */         _t = __t105;
/* 2893 */         _t = _t.getNextSibling();
/* 2894 */         if (this.inputState.guessing == 0) {
/* 2895 */           out(" is not null");
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       default: 
/* 2901 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 2906 */       if (this.inputState.guessing == 0) {
/* 2907 */         reportError(ex);
/* 2908 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 2910 */         throw ex;
/*      */       }
/*      */     }
/* 2913 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void likeEscape(AST _t) throws RecognitionException
/*      */   {
/* 2918 */     AST likeEscape_AST_in = _t == ASTNULL ? null : _t;
/*      */     
/*      */     try
/*      */     {
/* 2922 */       if (_t == null) _t = ASTNULL;
/* 2923 */       switch (_t.getType())
/*      */       {
/*      */       case 18: 
/* 2926 */         AST __t108 = _t;
/* 2927 */         AST tmp64_AST_in = _t;
/* 2928 */         match(_t, 18);
/* 2929 */         _t = _t.getFirstChild();
/* 2930 */         if (this.inputState.guessing == 0) {
/* 2931 */           out(" escape ");
/*      */         }
/* 2933 */         expr(_t);
/* 2934 */         _t = this._retTree;
/* 2935 */         _t = __t108;
/* 2936 */         _t = _t.getNextSibling();
/* 2937 */         break;
/*      */       
/*      */ 
/*      */       case 3: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 2945 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 2951 */       if (this.inputState.guessing == 0) {
/* 2952 */         reportError(ex);
/* 2953 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 2955 */         throw ex;
/*      */       }
/*      */     }
/* 2958 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void inList(AST _t) throws RecognitionException
/*      */   {
/* 2963 */     AST inList_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 2966 */       AST __t110 = _t;
/* 2967 */       AST tmp65_AST_in = _t;
/* 2968 */       match(_t, 74);
/* 2969 */       _t = _t.getFirstChild();
/* 2970 */       if (this.inputState.guessing == 0) {
/* 2971 */         out(" ");
/*      */       }
/*      */       
/* 2974 */       if (_t == null) _t = ASTNULL;
/* 2975 */       switch (_t.getType())
/*      */       {
/*      */       case 45: 
/* 2978 */         parenSelect(_t);
/* 2979 */         _t = this._retTree;
/* 2980 */         break;
/*      */       
/*      */ 
/*      */       case 3: 
/*      */       case 12: 
/*      */       case 15: 
/*      */       case 20: 
/*      */       case 39: 
/*      */       case 49: 
/*      */       case 54: 
/*      */       case 68: 
/*      */       case 71: 
/*      */       case 75: 
/*      */       case 78: 
/*      */       case 87: 
/*      */       case 91: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 111: 
/*      */       case 112: 
/*      */       case 116: 
/*      */       case 117: 
/*      */       case 118: 
/*      */       case 119: 
/*      */       case 133: 
/*      */       case 135: 
/*      */       case 141: 
/* 3010 */         simpleExprList(_t);
/* 3011 */         _t = this._retTree;
/* 3012 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 3016 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/* 3020 */       _t = __t110;
/* 3021 */       _t = _t.getNextSibling();
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 3024 */       if (this.inputState.guessing == 0) {
/* 3025 */         reportError(ex);
/* 3026 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 3028 */         throw ex;
/*      */       }
/*      */     }
/* 3031 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void quantified(AST _t) throws RecognitionException
/*      */   {
/* 3036 */     AST quantified_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 3039 */       if (this.inputState.guessing == 0) {
/* 3040 */         out("(");
/*      */       }
/*      */       
/* 3043 */       if (_t == null) _t = ASTNULL;
/* 3044 */       switch (_t.getType())
/*      */       {
/*      */       case 135: 
/* 3047 */         sqlToken(_t);
/* 3048 */         _t = this._retTree;
/* 3049 */         break;
/*      */       
/*      */ 
/*      */       case 45: 
/* 3053 */         selectStatement(_t);
/* 3054 */         _t = this._retTree;
/* 3055 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 3059 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/* 3063 */       if (this.inputState.guessing == 0) {
/* 3064 */         out(")");
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 3068 */       if (this.inputState.guessing == 0) {
/* 3069 */         reportError(ex);
/* 3070 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 3072 */         throw ex;
/*      */       }
/*      */     }
/* 3075 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void parenSelect(AST _t) throws RecognitionException
/*      */   {
/* 3080 */     AST parenSelect_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 3083 */       if (this.inputState.guessing == 0) {
/* 3084 */         out("(");
/*      */       }
/* 3086 */       selectStatement(_t);
/* 3087 */       _t = this._retTree;
/* 3088 */       if (this.inputState.guessing == 0) {
/* 3089 */         out(")");
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 3093 */       if (this.inputState.guessing == 0) {
/* 3094 */         reportError(ex);
/* 3095 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 3097 */         throw ex;
/*      */       }
/*      */     }
/* 3100 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void simpleExprList(AST _t) throws RecognitionException
/*      */   {
/* 3105 */     AST simpleExprList_AST_in = _t == ASTNULL ? null : _t;
/* 3106 */     AST e = null;
/*      */     try
/*      */     {
/* 3109 */       if (this.inputState.guessing == 0) {
/* 3110 */         out("(");
/*      */       }
/*      */       
/*      */       for (;;)
/*      */       {
/* 3115 */         if (_t == null) _t = ASTNULL;
/* 3116 */         if (!_tokenSet_4.member(_t.getType())) break;
/* 3117 */         e = _t == ASTNULL ? null : _t;
/* 3118 */         simpleExpr(_t);
/* 3119 */         _t = this._retTree;
/* 3120 */         if (this.inputState.guessing == 0) {
/* 3121 */           separator(e, " , ");
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3130 */       if (this.inputState.guessing == 0) {
/* 3131 */         out(")");
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 3135 */       if (this.inputState.guessing == 0) {
/* 3136 */         reportError(ex);
/* 3137 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 3139 */         throw ex;
/*      */       }
/*      */     }
/* 3142 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void addrExpr(AST _t) throws RecognitionException
/*      */   {
/* 3147 */     AST addrExpr_AST_in = _t == ASTNULL ? null : _t;
/* 3148 */     AST r = null;
/* 3149 */     AST i = null;
/* 3150 */     AST j = null;
/*      */     try
/*      */     {
/* 3153 */       if (_t == null) _t = ASTNULL;
/* 3154 */       switch (_t.getType())
/*      */       {
/*      */       case 15: 
/* 3157 */         AST __t166 = _t;
/* 3158 */         r = _t == ASTNULL ? null : _t;
/* 3159 */         match(_t, 15);
/* 3160 */         _t = _t.getFirstChild();
/* 3161 */         AST tmp66_AST_in = _t;
/* 3162 */         if (_t == null) throw new MismatchedTokenException();
/* 3163 */         _t = _t.getNextSibling();
/* 3164 */         AST tmp67_AST_in = _t;
/* 3165 */         if (_t == null) throw new MismatchedTokenException();
/* 3166 */         _t = _t.getNextSibling();
/* 3167 */         _t = __t166;
/* 3168 */         _t = _t.getNextSibling();
/* 3169 */         if (this.inputState.guessing == 0) {
/* 3170 */           out(r);
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       case 133: 
/* 3176 */         i = _t;
/* 3177 */         match(_t, 133);
/* 3178 */         _t = _t.getNextSibling();
/* 3179 */         if (this.inputState.guessing == 0) {
/* 3180 */           out(i);
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       case 75: 
/* 3186 */         j = _t;
/* 3187 */         match(_t, 75);
/* 3188 */         _t = _t.getNextSibling();
/* 3189 */         if (this.inputState.guessing == 0) {
/* 3190 */           out(j);
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       default: 
/* 3196 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 3201 */       if (this.inputState.guessing == 0) {
/* 3202 */         reportError(ex);
/* 3203 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 3205 */         throw ex;
/*      */       }
/*      */     }
/* 3208 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void parameter(AST _t) throws RecognitionException
/*      */   {
/* 3213 */     AST parameter_AST_in = _t == ASTNULL ? null : _t;
/* 3214 */     AST n = null;
/* 3215 */     AST p = null;
/*      */     try
/*      */     {
/* 3218 */       if (_t == null) _t = ASTNULL;
/* 3219 */       switch (_t.getType())
/*      */       {
/*      */       case 141: 
/* 3222 */         n = _t;
/* 3223 */         match(_t, 141);
/* 3224 */         _t = _t.getNextSibling();
/* 3225 */         if (this.inputState.guessing == 0) {
/* 3226 */           out(n);
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       case 116: 
/* 3232 */         p = _t;
/* 3233 */         match(_t, 116);
/* 3234 */         _t = _t.getNextSibling();
/* 3235 */         if (this.inputState.guessing == 0) {
/* 3236 */           out(p);
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       default: 
/* 3242 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 3247 */       if (this.inputState.guessing == 0) {
/* 3248 */         reportError(ex);
/* 3249 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 3251 */         throw ex;
/*      */       }
/*      */     }
/* 3254 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void additiveExpr(AST _t) throws RecognitionException
/*      */   {
/* 3259 */     AST additiveExpr_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 3262 */       if (_t == null) _t = ASTNULL;
/* 3263 */       switch (_t.getType())
/*      */       {
/*      */       case 109: 
/* 3266 */         AST __t130 = _t;
/* 3267 */         AST tmp68_AST_in = _t;
/* 3268 */         match(_t, 109);
/* 3269 */         _t = _t.getFirstChild();
/* 3270 */         expr(_t);
/* 3271 */         _t = this._retTree;
/* 3272 */         if (this.inputState.guessing == 0) {
/* 3273 */           out("+");
/*      */         }
/* 3275 */         expr(_t);
/* 3276 */         _t = this._retTree;
/* 3277 */         _t = __t130;
/* 3278 */         _t = _t.getNextSibling();
/* 3279 */         break;
/*      */       
/*      */ 
/*      */       case 110: 
/* 3283 */         AST __t131 = _t;
/* 3284 */         AST tmp69_AST_in = _t;
/* 3285 */         match(_t, 110);
/* 3286 */         _t = _t.getFirstChild();
/* 3287 */         expr(_t);
/* 3288 */         _t = this._retTree;
/* 3289 */         if (this.inputState.guessing == 0) {
/* 3290 */           out("-");
/*      */         }
/* 3292 */         nestedExprAfterMinusDiv(_t);
/* 3293 */         _t = this._retTree;
/* 3294 */         _t = __t131;
/* 3295 */         _t = _t.getNextSibling();
/* 3296 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 3300 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 3305 */       if (this.inputState.guessing == 0) {
/* 3306 */         reportError(ex);
/* 3307 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 3309 */         throw ex;
/*      */       }
/*      */     }
/* 3312 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void multiplicativeExpr(AST _t) throws RecognitionException
/*      */   {
/* 3317 */     AST multiplicativeExpr_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 3320 */       if (_t == null) _t = ASTNULL;
/* 3321 */       switch (_t.getType())
/*      */       {
/*      */       case 111: 
/* 3324 */         AST __t133 = _t;
/* 3325 */         AST tmp70_AST_in = _t;
/* 3326 */         match(_t, 111);
/* 3327 */         _t = _t.getFirstChild();
/* 3328 */         nestedExpr(_t);
/* 3329 */         _t = this._retTree;
/* 3330 */         if (this.inputState.guessing == 0) {
/* 3331 */           out("*");
/*      */         }
/* 3333 */         nestedExpr(_t);
/* 3334 */         _t = this._retTree;
/* 3335 */         _t = __t133;
/* 3336 */         _t = _t.getNextSibling();
/* 3337 */         break;
/*      */       
/*      */ 
/*      */       case 112: 
/* 3341 */         AST __t134 = _t;
/* 3342 */         AST tmp71_AST_in = _t;
/* 3343 */         match(_t, 112);
/* 3344 */         _t = _t.getFirstChild();
/* 3345 */         nestedExpr(_t);
/* 3346 */         _t = this._retTree;
/* 3347 */         if (this.inputState.guessing == 0) {
/* 3348 */           out("/");
/*      */         }
/* 3350 */         nestedExprAfterMinusDiv(_t);
/* 3351 */         _t = this._retTree;
/* 3352 */         _t = __t134;
/* 3353 */         _t = _t.getNextSibling();
/* 3354 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 3358 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 3363 */       if (this.inputState.guessing == 0) {
/* 3364 */         reportError(ex);
/* 3365 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 3367 */         throw ex;
/*      */       }
/*      */     }
/* 3370 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void caseExpr(AST _t) throws RecognitionException
/*      */   {
/* 3375 */     AST caseExpr_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 3378 */       if (_t == null) _t = ASTNULL;
/* 3379 */       switch (_t.getType())
/*      */       {
/*      */       case 54: 
/* 3382 */         AST __t142 = _t;
/* 3383 */         AST tmp72_AST_in = _t;
/* 3384 */         match(_t, 54);
/* 3385 */         _t = _t.getFirstChild();
/* 3386 */         if (this.inputState.guessing == 0) {
/* 3387 */           out("case");
/*      */         }
/*      */         
/* 3390 */         int _cnt145 = 0;
/*      */         for (;;)
/*      */         {
/* 3393 */           if (_t == null) _t = ASTNULL;
/* 3394 */           if (_t.getType() == 58) {
/* 3395 */             AST __t144 = _t;
/* 3396 */             AST tmp73_AST_in = _t;
/* 3397 */             match(_t, 58);
/* 3398 */             _t = _t.getFirstChild();
/* 3399 */             if (this.inputState.guessing == 0) {
/* 3400 */               out(" when ");
/*      */             }
/* 3402 */             booleanExpr(_t, false);
/* 3403 */             _t = this._retTree;
/* 3404 */             if (this.inputState.guessing == 0) {
/* 3405 */               out(" then ");
/*      */             }
/* 3407 */             expr(_t);
/* 3408 */             _t = this._retTree;
/* 3409 */             _t = __t144;
/* 3410 */             _t = _t.getNextSibling();
/*      */           }
/*      */           else {
/* 3413 */             if (_cnt145 >= 1) break; throw new NoViableAltException(_t);
/*      */           }
/*      */           
/* 3416 */           _cnt145++;
/*      */         }
/*      */         
/*      */ 
/* 3420 */         if (_t == null) _t = ASTNULL;
/* 3421 */         switch (_t.getType())
/*      */         {
/*      */         case 56: 
/* 3424 */           AST __t147 = _t;
/* 3425 */           AST tmp74_AST_in = _t;
/* 3426 */           match(_t, 56);
/* 3427 */           _t = _t.getFirstChild();
/* 3428 */           if (this.inputState.guessing == 0) {
/* 3429 */             out(" else ");
/*      */           }
/* 3431 */           expr(_t);
/* 3432 */           _t = this._retTree;
/* 3433 */           _t = __t147;
/* 3434 */           _t = _t.getNextSibling();
/* 3435 */           break;
/*      */         
/*      */ 
/*      */         case 3: 
/*      */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 3443 */           throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*      */         
/* 3447 */         if (this.inputState.guessing == 0) {
/* 3448 */           out(" end");
/*      */         }
/* 3450 */         _t = __t142;
/* 3451 */         _t = _t.getNextSibling();
/* 3452 */         break;
/*      */       
/*      */ 
/*      */       case 71: 
/* 3456 */         AST __t148 = _t;
/* 3457 */         AST tmp75_AST_in = _t;
/* 3458 */         match(_t, 71);
/* 3459 */         _t = _t.getFirstChild();
/* 3460 */         if (this.inputState.guessing == 0) {
/* 3461 */           out("case ");
/*      */         }
/* 3463 */         expr(_t);
/* 3464 */         _t = this._retTree;
/*      */         
/* 3466 */         int _cnt151 = 0;
/*      */         for (;;)
/*      */         {
/* 3469 */           if (_t == null) _t = ASTNULL;
/* 3470 */           if (_t.getType() == 58) {
/* 3471 */             AST __t150 = _t;
/* 3472 */             AST tmp76_AST_in = _t;
/* 3473 */             match(_t, 58);
/* 3474 */             _t = _t.getFirstChild();
/* 3475 */             if (this.inputState.guessing == 0) {
/* 3476 */               out(" when ");
/*      */             }
/* 3478 */             expr(_t);
/* 3479 */             _t = this._retTree;
/* 3480 */             if (this.inputState.guessing == 0) {
/* 3481 */               out(" then ");
/*      */             }
/* 3483 */             expr(_t);
/* 3484 */             _t = this._retTree;
/* 3485 */             _t = __t150;
/* 3486 */             _t = _t.getNextSibling();
/*      */           }
/*      */           else {
/* 3489 */             if (_cnt151 >= 1) break; throw new NoViableAltException(_t);
/*      */           }
/*      */           
/* 3492 */           _cnt151++;
/*      */         }
/*      */         
/*      */ 
/* 3496 */         if (_t == null) _t = ASTNULL;
/* 3497 */         switch (_t.getType())
/*      */         {
/*      */         case 56: 
/* 3500 */           AST __t153 = _t;
/* 3501 */           AST tmp77_AST_in = _t;
/* 3502 */           match(_t, 56);
/* 3503 */           _t = _t.getFirstChild();
/* 3504 */           if (this.inputState.guessing == 0) {
/* 3505 */             out(" else ");
/*      */           }
/* 3507 */           expr(_t);
/* 3508 */           _t = this._retTree;
/* 3509 */           _t = __t153;
/* 3510 */           _t = _t.getNextSibling();
/* 3511 */           break;
/*      */         
/*      */ 
/*      */         case 3: 
/*      */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 3519 */           throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*      */         
/* 3523 */         if (this.inputState.guessing == 0) {
/* 3524 */           out(" end");
/*      */         }
/* 3526 */         _t = __t148;
/* 3527 */         _t = _t.getNextSibling();
/* 3528 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 3532 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 3537 */       if (this.inputState.guessing == 0) {
/* 3538 */         reportError(ex);
/* 3539 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 3541 */         throw ex;
/*      */       }
/*      */     }
/* 3544 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void nestedExprAfterMinusDiv(AST _t) throws RecognitionException
/*      */   {
/* 3549 */     AST nestedExprAfterMinusDiv_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 3552 */       boolean synPredMatched140 = false;
/* 3553 */       if (_tokenSet_5.member(_t.getType())) {
/* 3554 */         AST __t140 = _t;
/* 3555 */         synPredMatched140 = true;
/* 3556 */         this.inputState.guessing += 1;
/*      */         try
/*      */         {
/* 3559 */           arithmeticExpr(_t);
/* 3560 */           _t = this._retTree;
/*      */         }
/*      */         catch (RecognitionException pe)
/*      */         {
/* 3564 */           synPredMatched140 = false;
/*      */         }
/* 3566 */         _t = __t140;
/* 3567 */         this.inputState.guessing -= 1;
/*      */       }
/* 3569 */       if (synPredMatched140) {
/* 3570 */         if (this.inputState.guessing == 0) {
/* 3571 */           out("(");
/*      */         }
/* 3573 */         arithmeticExpr(_t);
/* 3574 */         _t = this._retTree;
/* 3575 */         if (this.inputState.guessing == 0) {
/* 3576 */           out(")");
/*      */         }
/*      */       }
/* 3579 */       else if (_tokenSet_3.member(_t.getType())) {
/* 3580 */         expr(_t);
/* 3581 */         _t = this._retTree;
/*      */       }
/*      */       else {
/* 3584 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 3589 */       if (this.inputState.guessing == 0) {
/* 3590 */         reportError(ex);
/* 3591 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 3593 */         throw ex;
/*      */       }
/*      */     }
/* 3596 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void nestedExpr(AST _t) throws RecognitionException
/*      */   {
/* 3601 */     AST nestedExpr_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 3604 */       boolean synPredMatched137 = false;
/* 3605 */       if ((_t.getType() == 109) || (_t.getType() == 110)) {
/* 3606 */         AST __t137 = _t;
/* 3607 */         synPredMatched137 = true;
/* 3608 */         this.inputState.guessing += 1;
/*      */         try
/*      */         {
/* 3611 */           additiveExpr(_t);
/* 3612 */           _t = this._retTree;
/*      */         }
/*      */         catch (RecognitionException pe)
/*      */         {
/* 3616 */           synPredMatched137 = false;
/*      */         }
/* 3618 */         _t = __t137;
/* 3619 */         this.inputState.guessing -= 1;
/*      */       }
/* 3621 */       if (synPredMatched137) {
/* 3622 */         if (this.inputState.guessing == 0) {
/* 3623 */           out("(");
/*      */         }
/* 3625 */         additiveExpr(_t);
/* 3626 */         _t = this._retTree;
/* 3627 */         if (this.inputState.guessing == 0) {
/* 3628 */           out(")");
/*      */         }
/*      */       }
/* 3631 */       else if (_tokenSet_3.member(_t.getType())) {
/* 3632 */         expr(_t);
/* 3633 */         _t = this._retTree;
/*      */       }
/*      */       else {
/* 3636 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 3641 */       if (this.inputState.guessing == 0) {
/* 3642 */         reportError(ex);
/* 3643 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 3645 */         throw ex;
/*      */       }
/*      */     }
/* 3648 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void arguments(AST _t) throws RecognitionException
/*      */   {
/* 3653 */     AST arguments_AST_in = _t == ASTNULL ? null : _t;
/*      */     try
/*      */     {
/* 3656 */       expr(_t);
/* 3657 */       _t = this._retTree;
/*      */       
/*      */       for (;;)
/*      */       {
/* 3661 */         if (_t == null) _t = ASTNULL;
/* 3662 */         if (!_tokenSet_3.member(_t.getType())) break;
/* 3663 */         if (this.inputState.guessing == 0) {
/* 3664 */           commaBetweenParameters(", ");
/*      */         }
/* 3666 */         expr(_t);
/* 3667 */         _t = this._retTree;
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/*      */ 
/* 3677 */       if (this.inputState.guessing == 0) {
/* 3678 */         reportError(ex);
/* 3679 */         if (_t != null) _t = _t.getNextSibling();
/*      */       } else {
/* 3681 */         throw ex;
/*      */       }
/*      */     }
/* 3684 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */ 
/* 3688 */   public static final String[] _tokenNames = { "<0>", "EOF", "<2>", "NULL_TREE_LOOKAHEAD", "\"all\"", "\"any\"", "\"and\"", "\"as\"", "\"asc\"", "\"avg\"", "\"between\"", "\"class\"", "\"count\"", "\"delete\"", "\"desc\"", "DOT", "\"distinct\"", "\"elements\"", "\"escape\"", "\"exists\"", "\"false\"", "\"fetch\"", "\"from\"", "\"full\"", "\"group\"", "\"having\"", "\"in\"", "\"indices\"", "\"inner\"", "\"insert\"", "\"into\"", "\"is\"", "\"join\"", "\"left\"", "\"like\"", "\"max\"", "\"min\"", "\"new\"", "\"not\"", "\"null\"", "\"or\"", "\"order\"", "\"outer\"", "\"properties\"", "\"right\"", "\"select\"", "\"set\"", "\"some\"", "\"sum\"", "\"true\"", "\"union\"", "\"update\"", "\"versioned\"", "\"where\"", "\"case\"", "\"end\"", "\"else\"", "\"then\"", "\"when\"", "\"on\"", "\"with\"", "\"both\"", "\"empty\"", "\"leading\"", "\"member\"", "\"object\"", "\"of\"", "\"trailing\"", "AGGREGATE", "ALIAS", "CONSTRUCTOR", "CASE2", "EXPR_LIST", "FILTER_ENTITY", "IN_LIST", "INDEX_OP", "IS_NOT_NULL", "IS_NULL", "METHOD_CALL", "NOT_BETWEEN", "NOT_IN", "NOT_LIKE", "ORDER_ELEMENT", "QUERY", "RANGE", "ROW_STAR", "SELECT_FROM", "UNARY_MINUS", "UNARY_PLUS", "VECTOR_EXPR", "WEIRD_IDENT", "CONSTANT", "NUM_DOUBLE", "NUM_FLOAT", "NUM_LONG", "COMMA", "EQ", "OPEN", "CLOSE", "\"by\"", "\"ascending\"", "\"descending\"", "NE", "SQL_NE", "LT", "GT", "LE", "GE", "CONCAT", "PLUS", "MINUS", "STAR", "DIV", "OPEN_BRACKET", "CLOSE_BRACKET", "COLON", "PARAM", "NUM_INT", "QUOTED_STRING", "IDENT", "ID_START_LETTER", "ID_LETTER", "ESCqs", "WS", "HEX_DIGIT", "EXPONENT", "FLOAT_SUFFIX", "FROM_FRAGMENT", "IMPLIED_FROM", "JOIN_FRAGMENT", "SELECT_CLAUSE", "LEFT_OUTER", "RIGHT_OUTER", "ALIAS_REF", "PROPERTY_REF", "SQL_TOKEN", "SELECT_COLUMNS", "SELECT_EXPR", "THETA_JOINS", "FILTERS", "METHOD_NAME", "NAMED_PARAM", "BOGUS", "SQL_NODE" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final long[] mk_tokenSet_0()
/*      */   {
/* 3836 */     long[] data = { 18612532836077568L, 68081762013561040L, 33440L, 0L, 0L, 0L };
/* 3837 */     return data; }
/*      */   
/* 3839 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*      */   
/* 3841 */   private static final long[] mk_tokenSet_1() { long[] data = { 17247503360L, 16771847532544L, 0L, 0L };
/* 3842 */     return data; }
/*      */   
/* 3844 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*      */   
/* 3846 */   private static final long[] mk_tokenSet_2() { long[] data = { 1391637038144L, 16771847532544L, 128L, 0L, 0L, 0L };
/* 3847 */     return data; }
/*      */   
/* 3849 */   public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
/*      */   
/* 3851 */   private static final long[] mk_tokenSet_3() { long[] data = { 18753820080246832L, 68081762047117456L, 8352L, 0L, 0L, 0L };
/* 3852 */     return data; }
/*      */   
/* 3854 */   public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
/*      */   
/* 3856 */   private static final long[] mk_tokenSet_4() { long[] data = { 18577898219802624L, 68081762013563024L, 8352L, 0L, 0L, 0L };
/* 3857 */     return data; }
/*      */   
/* 3859 */   public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
/*      */   
/* 3861 */   private static final long[] mk_tokenSet_5() { long[] data = { 18014398509481984L, 527765589721216L, 0L, 0L };
/* 3862 */     return data; }
/*      */   
/* 3864 */   public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
/*      */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\antlr\SqlGeneratorBase.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */