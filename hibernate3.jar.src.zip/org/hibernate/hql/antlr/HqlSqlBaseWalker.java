/*      */ package org.hibernate.hql.antlr;
/*      */ 
/*      */ import antlr.ASTFactory;
/*      */ import antlr.ASTPair;
/*      */ import antlr.NoViableAltException;
/*      */ import antlr.RecognitionException;
/*      */ import antlr.SemanticException;
/*      */ import antlr.TreeParser;
/*      */ import antlr.collections.AST;
/*      */ import antlr.collections.impl.ASTArray;
/*      */ import antlr.collections.impl.BitSet;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HqlSqlBaseWalker
/*      */   extends TreeParser
/*      */   implements HqlSqlTokenTypes
/*      */ {
/*   37 */   private static Log log = LogFactory.getLog(HqlSqlBaseWalker.class);
/*      */   
/*   39 */   private int level = 0;
/*   40 */   private boolean inSelect = false;
/*   41 */   private boolean inFunctionCall = false;
/*   42 */   private boolean inCase = false;
/*   43 */   private boolean inFrom = false;
/*      */   
/*      */   private int statementType;
/*      */   
/*      */   private String statementTypeName;
/*      */   
/*      */   private int currentClauseType;
/*      */   private int currentTopLevelClauseType;
/*      */   private int currentStatementType;
/*      */   
/*      */   public final boolean isSubQuery()
/*      */   {
/*   55 */     return this.level > 1;
/*      */   }
/*      */   
/*      */   public final boolean isInFrom() {
/*   59 */     return this.inFrom;
/*      */   }
/*      */   
/*      */   public final boolean isInFunctionCall() {
/*   63 */     return this.inFunctionCall;
/*      */   }
/*      */   
/*      */   public final boolean isInSelect() {
/*   67 */     return this.inSelect;
/*      */   }
/*      */   
/*      */   public final boolean isInCase() {
/*   71 */     return this.inCase;
/*      */   }
/*      */   
/*      */   public final int getStatementType() {
/*   75 */     return this.statementType;
/*      */   }
/*      */   
/*      */   public final int getCurrentClauseType() {
/*   79 */     return this.currentClauseType;
/*      */   }
/*      */   
/*      */   public final int getCurrentTopLevelClauseType() {
/*   83 */     return this.currentTopLevelClauseType;
/*      */   }
/*      */   
/*      */   public final int getCurrentStatementType() {
/*   87 */     return this.currentStatementType;
/*      */   }
/*      */   
/*      */ 
/*      */   public final boolean isComparativeExpressionClause()
/*      */   {
/*   93 */     return (getCurrentClauseType() == 53) || (getCurrentClauseType() == 60) || (isInCase());
/*      */   }
/*      */   
/*      */ 
/*      */   public final boolean isSelectStatement()
/*      */   {
/*   99 */     return this.statementType == 45;
/*      */   }
/*      */   
/*      */   private void beforeStatement(String statementName, int statementType) {
/*  103 */     this.inFunctionCall = false;
/*  104 */     this.level += 1;
/*  105 */     if (this.level == 1) {
/*  106 */       this.statementTypeName = statementName;
/*  107 */       this.statementType = statementType;
/*      */     }
/*  109 */     this.currentStatementType = statementType;
/*  110 */     if (log.isDebugEnabled()) {
/*  111 */       log.debug(statementName + " << begin [level=" + this.level + ", statement=" + this.statementTypeName + "]");
/*      */     }
/*      */   }
/*      */   
/*      */   private void beforeStatementCompletion(String statementName) {
/*  116 */     if (log.isDebugEnabled()) {
/*  117 */       log.debug(statementName + " : finishing up [level=" + this.level + ", statement=" + this.statementTypeName + "]");
/*      */     }
/*      */   }
/*      */   
/*      */   private void afterStatementCompletion(String statementName) {
/*  122 */     if (log.isDebugEnabled()) {
/*  123 */       log.debug(statementName + " >> end [level=" + this.level + ", statement=" + this.statementTypeName + "]");
/*      */     }
/*  125 */     this.level -= 1;
/*      */   }
/*      */   
/*      */   private void handleClauseStart(int clauseType) {
/*  129 */     this.currentClauseType = clauseType;
/*  130 */     if (this.level == 1) {
/*  131 */       this.currentTopLevelClauseType = clauseType;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected void evaluateAssignment(AST eq)
/*      */     throws SemanticException
/*      */   {}
/*      */   
/*      */   protected void prepareFromClauseInputTree(AST fromClauseInput) {}
/*      */   
/*      */   protected void pushFromClause(AST fromClause, AST inputFromNode) {}
/*      */   
/*      */   protected AST createFromElement(String path, AST alias, AST propertyFetch)
/*      */     throws SemanticException
/*      */   {
/*  147 */     return null;
/*      */   }
/*      */   
/*      */   protected void createFromJoinElement(AST path, AST alias, int joinType, AST fetch, AST propertyFetch, AST with) throws SemanticException
/*      */   {}
/*      */   
/*  153 */   protected AST createFromFilterElement(AST filterEntity, AST alias) throws SemanticException { return null; }
/*      */   
/*      */   protected void processQuery(AST select, AST query) throws SemanticException
/*      */   {}
/*      */   
/*      */   protected void postProcessUpdate(AST update) throws SemanticException
/*      */   {}
/*      */   
/*      */   protected void postProcessDelete(AST delete) throws SemanticException
/*      */   {}
/*      */   protected void postProcessInsert(AST insert) throws SemanticException
/*      */   {}
/*      */   protected void beforeSelectClause() throws SemanticException
/*      */   {}
/*      */   protected void processIndex(AST indexOp) throws SemanticException
/*      */   {}
/*      */   protected void processConstant(AST constant) throws SemanticException
/*      */   {}
/*      */   protected void processBoolean(AST constant) throws SemanticException
/*      */   {}
/*      */   protected void processNumericLiteral(AST literal) throws SemanticException
/*      */   {}
/*      */   protected void resolve(AST node) throws SemanticException
/*      */   {}
/*      */   protected void resolveSelectExpression(AST dotNode) throws SemanticException
/*      */   {}
/*      */   protected void processFunction(AST functionCall, boolean inSelect) throws SemanticException
/*      */   {}
/*      */   protected void processConstructor(AST constructor) throws SemanticException
/*      */   {}
/*  183 */   protected AST generateNamedParameter(AST delimiterNode, AST nameNode) throws SemanticException { return this.astFactory.make(new ASTArray(1).add(this.astFactory.create(141, nameNode.getText()))); }
/*      */   
/*      */   protected AST generatePositionalParameter(AST inputNode) throws SemanticException
/*      */   {
/*  187 */     return this.astFactory.make(new ASTArray(1).add(this.astFactory.create(116, "?")));
/*      */   }
/*      */   
/*      */   protected void lookupAlias(AST ident) throws SemanticException
/*      */   {}
/*      */   
/*      */   protected void setAlias(AST selectExpr, AST ident) {}
/*      */   
/*  195 */   protected AST lookupProperty(AST dot, boolean root, boolean inSelect) throws SemanticException { return dot; }
/*      */   
/*      */ 
/*  198 */   protected boolean isNonQualifiedPropertyRef(AST ident) { return false; }
/*      */   
/*  200 */   protected AST lookupNonQualifiedProperty(AST property) throws SemanticException { return property; }
/*      */   
/*      */ 
/*      */   protected void setImpliedJoinType(int joinType) {}
/*      */   
/*  205 */   protected AST createIntoClause(String path, AST propertySpec) throws SemanticException { return null; }
/*      */   
/*      */   protected void prepareVersioned(AST updateNode, AST versionedNode) throws SemanticException
/*      */   {}
/*      */   
/*      */   protected void prepareLogicOperator(AST operator) throws SemanticException
/*      */   {}
/*      */   protected void prepareArithmeticOperator(AST operator) throws SemanticException
/*      */   {}
/*  214 */   public HqlSqlBaseWalker() { this.tokenNames = _tokenNames; }
/*      */   
/*      */   public final void statement(AST _t)
/*      */     throws RecognitionException
/*      */   {
/*  219 */     AST statement_AST_in = _t == ASTNULL ? null : _t;
/*  220 */     this.returnAST = null;
/*  221 */     ASTPair currentAST = new ASTPair();
/*  222 */     AST statement_AST = null;
/*      */     try
/*      */     {
/*  225 */       if (_t == null) _t = ASTNULL;
/*  226 */       switch (_t.getType())
/*      */       {
/*      */       case 83: 
/*  229 */         selectStatement(_t);
/*  230 */         _t = this._retTree;
/*  231 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*  232 */         statement_AST = currentAST.root;
/*  233 */         break;
/*      */       
/*      */ 
/*      */       case 51: 
/*  237 */         updateStatement(_t);
/*  238 */         _t = this._retTree;
/*  239 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*  240 */         statement_AST = currentAST.root;
/*  241 */         break;
/*      */       
/*      */ 
/*      */       case 13: 
/*  245 */         deleteStatement(_t);
/*  246 */         _t = this._retTree;
/*  247 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*  248 */         statement_AST = currentAST.root;
/*  249 */         break;
/*      */       
/*      */ 
/*      */       case 29: 
/*  253 */         insertStatement(_t);
/*  254 */         _t = this._retTree;
/*  255 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*  256 */         statement_AST = currentAST.root;
/*  257 */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  261 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/*  266 */       reportError(ex);
/*  267 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/*  269 */     this.returnAST = statement_AST;
/*  270 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void selectStatement(AST _t) throws RecognitionException
/*      */   {
/*  275 */     AST selectStatement_AST_in = _t == ASTNULL ? null : _t;
/*  276 */     this.returnAST = null;
/*  277 */     ASTPair currentAST = new ASTPair();
/*  278 */     AST selectStatement_AST = null;
/*      */     try
/*      */     {
/*  281 */       query(_t);
/*  282 */       _t = this._retTree;
/*  283 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*  284 */       selectStatement_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  287 */       reportError(ex);
/*  288 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/*  290 */     this.returnAST = selectStatement_AST;
/*  291 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void updateStatement(AST _t) throws RecognitionException
/*      */   {
/*  296 */     AST updateStatement_AST_in = _t == ASTNULL ? null : _t;
/*  297 */     this.returnAST = null;
/*  298 */     ASTPair currentAST = new ASTPair();
/*  299 */     AST updateStatement_AST = null;
/*  300 */     AST u = null;
/*  301 */     AST u_AST = null;
/*  302 */     AST v = null;
/*  303 */     AST v_AST = null;
/*  304 */     AST f_AST = null;
/*  305 */     AST f = null;
/*  306 */     AST s_AST = null;
/*  307 */     AST s = null;
/*  308 */     AST w_AST = null;
/*  309 */     AST w = null;
/*      */     try
/*      */     {
/*  312 */       AST __t4 = _t;
/*  313 */       u = _t == ASTNULL ? null : _t;
/*  314 */       AST u_AST_in = null;
/*  315 */       u_AST = this.astFactory.create(u);
/*  316 */       ASTPair __currentAST4 = currentAST.copy();
/*  317 */       currentAST.root = currentAST.child;
/*  318 */       currentAST.child = null;
/*  319 */       match(_t, 51);
/*  320 */       _t = _t.getFirstChild();
/*  321 */       beforeStatement("update", 51);
/*      */       
/*  323 */       if (_t == null) _t = ASTNULL;
/*  324 */       switch (_t.getType())
/*      */       {
/*      */       case 52: 
/*  327 */         v = _t;
/*  328 */         AST v_AST_in = null;
/*  329 */         v_AST = this.astFactory.create(v);
/*  330 */         match(_t, 52);
/*  331 */         _t = _t.getNextSibling();
/*  332 */         break;
/*      */       
/*      */ 
/*      */       case 22: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  340 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/*  344 */       f = _t == ASTNULL ? null : _t;
/*  345 */       fromClause(_t);
/*  346 */       _t = this._retTree;
/*  347 */       f_AST = this.returnAST;
/*  348 */       s = _t == ASTNULL ? null : _t;
/*  349 */       setClause(_t);
/*  350 */       _t = this._retTree;
/*  351 */       s_AST = this.returnAST;
/*      */       
/*  353 */       if (_t == null) _t = ASTNULL;
/*  354 */       switch (_t.getType())
/*      */       {
/*      */       case 53: 
/*  357 */         w = _t == ASTNULL ? null : _t;
/*  358 */         whereClause(_t);
/*  359 */         _t = this._retTree;
/*  360 */         w_AST = this.returnAST;
/*  361 */         break;
/*      */       
/*      */ 
/*      */       case 3: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  369 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/*  373 */       currentAST = __currentAST4;
/*  374 */       _t = __t4;
/*  375 */       _t = _t.getNextSibling();
/*  376 */       updateStatement_AST = currentAST.root;
/*      */       
/*  378 */       updateStatement_AST = this.astFactory.make(new ASTArray(4).add(u_AST).add(f_AST).add(s_AST).add(w_AST));
/*  379 */       beforeStatementCompletion("update");
/*  380 */       prepareVersioned(updateStatement_AST, v_AST);
/*  381 */       postProcessUpdate(updateStatement_AST);
/*  382 */       afterStatementCompletion("update");
/*      */       
/*  384 */       currentAST.root = updateStatement_AST;
/*  385 */       currentAST.child = ((updateStatement_AST != null) && (updateStatement_AST.getFirstChild() != null) ? updateStatement_AST.getFirstChild() : updateStatement_AST);
/*      */       
/*  387 */       currentAST.advanceChildToEnd();
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  390 */       reportError(ex);
/*  391 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/*  393 */     this.returnAST = updateStatement_AST;
/*  394 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void deleteStatement(AST _t) throws RecognitionException
/*      */   {
/*  399 */     AST deleteStatement_AST_in = _t == ASTNULL ? null : _t;
/*  400 */     this.returnAST = null;
/*  401 */     ASTPair currentAST = new ASTPair();
/*  402 */     AST deleteStatement_AST = null;
/*      */     try
/*      */     {
/*  405 */       AST __t8 = _t;
/*  406 */       AST tmp1_AST = null;
/*  407 */       AST tmp1_AST_in = null;
/*  408 */       tmp1_AST = this.astFactory.create(_t);
/*  409 */       tmp1_AST_in = _t;
/*  410 */       this.astFactory.addASTChild(currentAST, tmp1_AST);
/*  411 */       ASTPair __currentAST8 = currentAST.copy();
/*  412 */       currentAST.root = currentAST.child;
/*  413 */       currentAST.child = null;
/*  414 */       match(_t, 13);
/*  415 */       _t = _t.getFirstChild();
/*  416 */       beforeStatement("delete", 13);
/*  417 */       fromClause(_t);
/*  418 */       _t = this._retTree;
/*  419 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*  421 */       if (_t == null) _t = ASTNULL;
/*  422 */       switch (_t.getType())
/*      */       {
/*      */       case 53: 
/*  425 */         whereClause(_t);
/*  426 */         _t = this._retTree;
/*  427 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*  428 */         break;
/*      */       
/*      */ 
/*      */       case 3: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  436 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/*  440 */       currentAST = __currentAST8;
/*  441 */       _t = __t8;
/*  442 */       _t = _t.getNextSibling();
/*  443 */       deleteStatement_AST = currentAST.root;
/*      */       
/*  445 */       beforeStatementCompletion("delete");
/*  446 */       postProcessDelete(deleteStatement_AST);
/*  447 */       afterStatementCompletion("delete");
/*      */       
/*  449 */       deleteStatement_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  452 */       reportError(ex);
/*  453 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/*  455 */     this.returnAST = deleteStatement_AST;
/*  456 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void insertStatement(AST _t) throws RecognitionException
/*      */   {
/*  461 */     AST insertStatement_AST_in = _t == ASTNULL ? null : _t;
/*  462 */     this.returnAST = null;
/*  463 */     ASTPair currentAST = new ASTPair();
/*  464 */     AST insertStatement_AST = null;
/*      */     try
/*      */     {
/*  467 */       AST __t11 = _t;
/*  468 */       AST tmp2_AST = null;
/*  469 */       AST tmp2_AST_in = null;
/*  470 */       tmp2_AST = this.astFactory.create(_t);
/*  471 */       tmp2_AST_in = _t;
/*  472 */       this.astFactory.addASTChild(currentAST, tmp2_AST);
/*  473 */       ASTPair __currentAST11 = currentAST.copy();
/*  474 */       currentAST.root = currentAST.child;
/*  475 */       currentAST.child = null;
/*  476 */       match(_t, 29);
/*  477 */       _t = _t.getFirstChild();
/*  478 */       beforeStatement("insert", 29);
/*  479 */       intoClause(_t);
/*  480 */       _t = this._retTree;
/*  481 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*  482 */       query(_t);
/*  483 */       _t = this._retTree;
/*  484 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*  485 */       currentAST = __currentAST11;
/*  486 */       _t = __t11;
/*  487 */       _t = _t.getNextSibling();
/*  488 */       insertStatement_AST = currentAST.root;
/*      */       
/*  490 */       beforeStatementCompletion("insert");
/*  491 */       postProcessInsert(insertStatement_AST);
/*  492 */       afterStatementCompletion("insert");
/*      */       
/*  494 */       insertStatement_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  497 */       reportError(ex);
/*  498 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/*  500 */     this.returnAST = insertStatement_AST;
/*  501 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void query(AST _t) throws RecognitionException
/*      */   {
/*  506 */     AST query_AST_in = _t == ASTNULL ? null : _t;
/*  507 */     this.returnAST = null;
/*  508 */     ASTPair currentAST = new ASTPair();
/*  509 */     AST query_AST = null;
/*  510 */     AST f_AST = null;
/*  511 */     AST f = null;
/*  512 */     AST s_AST = null;
/*  513 */     AST s = null;
/*  514 */     AST w_AST = null;
/*  515 */     AST w = null;
/*  516 */     AST g_AST = null;
/*  517 */     AST g = null;
/*  518 */     AST o_AST = null;
/*  519 */     AST o = null;
/*      */     try
/*      */     {
/*  522 */       AST __t29 = _t;
/*  523 */       AST tmp3_AST = null;
/*  524 */       AST tmp3_AST_in = null;
/*  525 */       tmp3_AST = this.astFactory.create(_t);
/*  526 */       tmp3_AST_in = _t;
/*  527 */       ASTPair __currentAST29 = currentAST.copy();
/*  528 */       currentAST.root = currentAST.child;
/*  529 */       currentAST.child = null;
/*  530 */       match(_t, 83);
/*  531 */       _t = _t.getFirstChild();
/*  532 */       beforeStatement("select", 45);
/*  533 */       AST __t30 = _t;
/*  534 */       AST tmp4_AST = null;
/*  535 */       AST tmp4_AST_in = null;
/*  536 */       tmp4_AST = this.astFactory.create(_t);
/*  537 */       tmp4_AST_in = _t;
/*  538 */       ASTPair __currentAST30 = currentAST.copy();
/*  539 */       currentAST.root = currentAST.child;
/*  540 */       currentAST.child = null;
/*  541 */       match(_t, 86);
/*  542 */       _t = _t.getFirstChild();
/*  543 */       f = _t == ASTNULL ? null : _t;
/*  544 */       fromClause(_t);
/*  545 */       _t = this._retTree;
/*  546 */       f_AST = this.returnAST;
/*      */       
/*  548 */       if (_t == null) _t = ASTNULL;
/*  549 */       switch (_t.getType())
/*      */       {
/*      */       case 45: 
/*  552 */         s = _t == ASTNULL ? null : _t;
/*  553 */         selectClause(_t);
/*  554 */         _t = this._retTree;
/*  555 */         s_AST = this.returnAST;
/*  556 */         break;
/*      */       
/*      */ 
/*      */       case 3: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  564 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/*  568 */       currentAST = __currentAST30;
/*  569 */       _t = __t30;
/*  570 */       _t = _t.getNextSibling();
/*      */       
/*  572 */       if (_t == null) _t = ASTNULL;
/*  573 */       switch (_t.getType())
/*      */       {
/*      */       case 53: 
/*  576 */         w = _t == ASTNULL ? null : _t;
/*  577 */         whereClause(_t);
/*  578 */         _t = this._retTree;
/*  579 */         w_AST = this.returnAST;
/*  580 */         break;
/*      */       
/*      */ 
/*      */       case 3: 
/*      */       case 24: 
/*      */       case 41: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  590 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/*      */ 
/*  595 */       if (_t == null) _t = ASTNULL;
/*  596 */       switch (_t.getType())
/*      */       {
/*      */       case 24: 
/*  599 */         g = _t == ASTNULL ? null : _t;
/*  600 */         groupClause(_t);
/*  601 */         _t = this._retTree;
/*  602 */         g_AST = this.returnAST;
/*  603 */         break;
/*      */       
/*      */ 
/*      */       case 3: 
/*      */       case 41: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  612 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/*      */ 
/*  617 */       if (_t == null) _t = ASTNULL;
/*  618 */       switch (_t.getType())
/*      */       {
/*      */       case 41: 
/*  621 */         o = _t == ASTNULL ? null : _t;
/*  622 */         orderClause(_t);
/*  623 */         _t = this._retTree;
/*  624 */         o_AST = this.returnAST;
/*  625 */         break;
/*      */       
/*      */ 
/*      */       case 3: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  633 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/*  637 */       currentAST = __currentAST29;
/*  638 */       _t = __t29;
/*  639 */       _t = _t.getNextSibling();
/*  640 */       query_AST = currentAST.root;
/*      */       
/*      */ 
/*  643 */       query_AST = this.astFactory.make(new ASTArray(6).add(this.astFactory.create(45, "SELECT")).add(s_AST).add(f_AST).add(w_AST).add(g_AST).add(o_AST));
/*  644 */       beforeStatementCompletion("select");
/*  645 */       processQuery(s_AST, query_AST);
/*  646 */       afterStatementCompletion("select");
/*      */       
/*  648 */       currentAST.root = query_AST;
/*  649 */       currentAST.child = ((query_AST != null) && (query_AST.getFirstChild() != null) ? query_AST.getFirstChild() : query_AST);
/*      */       
/*  651 */       currentAST.advanceChildToEnd();
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  654 */       reportError(ex);
/*  655 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/*  657 */     this.returnAST = query_AST;
/*  658 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void fromClause(AST _t) throws RecognitionException
/*      */   {
/*  663 */     AST fromClause_AST_in = _t == ASTNULL ? null : _t;
/*  664 */     this.returnAST = null;
/*  665 */     ASTPair currentAST = new ASTPair();
/*  666 */     AST fromClause_AST = null;
/*  667 */     AST f = null;
/*  668 */     AST f_AST = null;
/*      */     
/*      */ 
/*      */ 
/*  672 */     prepareFromClauseInputTree(fromClause_AST_in);
/*      */     
/*      */     try
/*      */     {
/*  676 */       AST __t67 = _t;
/*  677 */       f = _t == ASTNULL ? null : _t;
/*  678 */       AST f_AST_in = null;
/*  679 */       f_AST = this.astFactory.create(f);
/*  680 */       this.astFactory.addASTChild(currentAST, f_AST);
/*  681 */       ASTPair __currentAST67 = currentAST.copy();
/*  682 */       currentAST.root = currentAST.child;
/*  683 */       currentAST.child = null;
/*  684 */       match(_t, 22);
/*  685 */       _t = _t.getFirstChild();
/*  686 */       fromClause_AST = currentAST.root;
/*  687 */       pushFromClause(fromClause_AST, f);handleClauseStart(22);
/*  688 */       fromElementList(_t);
/*  689 */       _t = this._retTree;
/*  690 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*  691 */       currentAST = __currentAST67;
/*  692 */       _t = __t67;
/*  693 */       _t = _t.getNextSibling();
/*  694 */       fromClause_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  697 */       reportError(ex);
/*  698 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/*  700 */     this.returnAST = fromClause_AST;
/*  701 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void setClause(AST _t) throws RecognitionException
/*      */   {
/*  706 */     AST setClause_AST_in = _t == ASTNULL ? null : _t;
/*  707 */     this.returnAST = null;
/*  708 */     ASTPair currentAST = new ASTPair();
/*  709 */     AST setClause_AST = null;
/*      */     try
/*      */     {
/*  712 */       AST __t20 = _t;
/*  713 */       AST tmp5_AST = null;
/*  714 */       AST tmp5_AST_in = null;
/*  715 */       tmp5_AST = this.astFactory.create(_t);
/*  716 */       tmp5_AST_in = _t;
/*  717 */       this.astFactory.addASTChild(currentAST, tmp5_AST);
/*  718 */       ASTPair __currentAST20 = currentAST.copy();
/*  719 */       currentAST.root = currentAST.child;
/*  720 */       currentAST.child = null;
/*  721 */       match(_t, 46);
/*  722 */       _t = _t.getFirstChild();
/*  723 */       handleClauseStart(46);
/*      */       
/*      */       for (;;)
/*      */       {
/*  727 */         if (_t == null) _t = ASTNULL;
/*  728 */         if (_t.getType() != 96) break;
/*  729 */         assignment(_t);
/*  730 */         _t = this._retTree;
/*  731 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  739 */       currentAST = __currentAST20;
/*  740 */       _t = __t20;
/*  741 */       _t = _t.getNextSibling();
/*  742 */       setClause_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  745 */       reportError(ex);
/*  746 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/*  748 */     this.returnAST = setClause_AST;
/*  749 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void whereClause(AST _t) throws RecognitionException
/*      */   {
/*  754 */     AST whereClause_AST_in = _t == ASTNULL ? null : _t;
/*  755 */     this.returnAST = null;
/*  756 */     ASTPair currentAST = new ASTPair();
/*  757 */     AST whereClause_AST = null;
/*  758 */     AST w = null;
/*  759 */     AST w_AST = null;
/*  760 */     AST b_AST = null;
/*  761 */     AST b = null;
/*      */     try
/*      */     {
/*  764 */       AST __t92 = _t;
/*  765 */       w = _t == ASTNULL ? null : _t;
/*  766 */       AST w_AST_in = null;
/*  767 */       w_AST = this.astFactory.create(w);
/*  768 */       this.astFactory.addASTChild(currentAST, w_AST);
/*  769 */       ASTPair __currentAST92 = currentAST.copy();
/*  770 */       currentAST.root = currentAST.child;
/*  771 */       currentAST.child = null;
/*  772 */       match(_t, 53);
/*  773 */       _t = _t.getFirstChild();
/*  774 */       handleClauseStart(53);
/*  775 */       b = _t == ASTNULL ? null : _t;
/*  776 */       logicalExpr(_t);
/*  777 */       _t = this._retTree;
/*  778 */       b_AST = this.returnAST;
/*  779 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*  780 */       currentAST = __currentAST92;
/*  781 */       _t = __t92;
/*  782 */       _t = _t.getNextSibling();
/*  783 */       whereClause_AST = currentAST.root;
/*      */       
/*      */ 
/*  786 */       whereClause_AST = this.astFactory.make(new ASTArray(2).add(w_AST).add(b_AST));
/*      */       
/*  788 */       currentAST.root = whereClause_AST;
/*  789 */       currentAST.child = ((whereClause_AST != null) && (whereClause_AST.getFirstChild() != null) ? whereClause_AST.getFirstChild() : whereClause_AST);
/*      */       
/*  791 */       currentAST.advanceChildToEnd();
/*  792 */       whereClause_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  795 */       reportError(ex);
/*  796 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/*  798 */     this.returnAST = whereClause_AST;
/*  799 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void intoClause(AST _t) throws RecognitionException
/*      */   {
/*  804 */     AST intoClause_AST_in = _t == ASTNULL ? null : _t;
/*  805 */     this.returnAST = null;
/*  806 */     ASTPair currentAST = new ASTPair();
/*  807 */     AST intoClause_AST = null;
/*  808 */     AST ps_AST = null;
/*  809 */     AST ps = null;
/*      */     
/*  811 */     String p = null;
/*      */     
/*      */     try
/*      */     {
/*  815 */       AST __t13 = _t;
/*  816 */       AST tmp6_AST = null;
/*  817 */       AST tmp6_AST_in = null;
/*  818 */       tmp6_AST = this.astFactory.create(_t);
/*  819 */       tmp6_AST_in = _t;
/*  820 */       ASTPair __currentAST13 = currentAST.copy();
/*  821 */       currentAST.root = currentAST.child;
/*  822 */       currentAST.child = null;
/*  823 */       match(_t, 30);
/*  824 */       _t = _t.getFirstChild();
/*  825 */       handleClauseStart(30);
/*      */       
/*  827 */       p = path(_t);
/*  828 */       _t = this._retTree;
/*      */       
/*  830 */       ps = _t == ASTNULL ? null : _t;
/*  831 */       insertablePropertySpec(_t);
/*  832 */       _t = this._retTree;
/*  833 */       ps_AST = this.returnAST;
/*  834 */       currentAST = __currentAST13;
/*  835 */       _t = __t13;
/*  836 */       _t = _t.getNextSibling();
/*  837 */       intoClause_AST = currentAST.root;
/*      */       
/*  839 */       intoClause_AST = createIntoClause(p, ps);
/*      */       
/*  841 */       currentAST.root = intoClause_AST;
/*  842 */       currentAST.child = ((intoClause_AST != null) && (intoClause_AST.getFirstChild() != null) ? intoClause_AST.getFirstChild() : intoClause_AST);
/*      */       
/*  844 */       currentAST.advanceChildToEnd();
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  847 */       reportError(ex);
/*  848 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/*  850 */     this.returnAST = intoClause_AST;
/*  851 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final String path(AST _t)
/*      */     throws RecognitionException
/*      */   {
/*  857 */     AST path_AST_in = _t == ASTNULL ? null : _t;
/*  858 */     this.returnAST = null;
/*  859 */     ASTPair currentAST = new ASTPair();
/*  860 */     AST path_AST = null;
/*  861 */     AST a_AST = null;
/*  862 */     AST a = null;
/*  863 */     AST y_AST = null;
/*  864 */     AST y = null;
/*      */     
/*  866 */     String p = "???";
/*  867 */     String x = "?x?";
/*      */     
/*      */     try
/*      */     {
/*  871 */       if (_t == null) _t = ASTNULL;
/*  872 */       switch (_t.getType())
/*      */       {
/*      */       case 90: 
/*      */       case 119: 
/*  876 */         a = _t == ASTNULL ? null : _t;
/*  877 */         identifier(_t);
/*  878 */         _t = this._retTree;
/*  879 */         a_AST = this.returnAST;
/*  880 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*  881 */         p = a.getText();
/*  882 */         path_AST = currentAST.root;
/*  883 */         break;
/*      */       
/*      */ 
/*      */       case 15: 
/*  887 */         AST __t87 = _t;
/*  888 */         AST tmp7_AST = null;
/*  889 */         AST tmp7_AST_in = null;
/*  890 */         tmp7_AST = this.astFactory.create(_t);
/*  891 */         tmp7_AST_in = _t;
/*  892 */         this.astFactory.addASTChild(currentAST, tmp7_AST);
/*  893 */         ASTPair __currentAST87 = currentAST.copy();
/*  894 */         currentAST.root = currentAST.child;
/*  895 */         currentAST.child = null;
/*  896 */         match(_t, 15);
/*  897 */         _t = _t.getFirstChild();
/*  898 */         x = path(_t);
/*  899 */         _t = this._retTree;
/*  900 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*  901 */         y = _t == ASTNULL ? null : _t;
/*  902 */         identifier(_t);
/*  903 */         _t = this._retTree;
/*  904 */         y_AST = this.returnAST;
/*  905 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*  906 */         currentAST = __currentAST87;
/*  907 */         _t = __t87;
/*  908 */         _t = _t.getNextSibling();
/*      */         
/*  910 */         StringBuffer buf = new StringBuffer();
/*  911 */         buf.append(x).append(".").append(y.getText());
/*  912 */         p = buf.toString();
/*      */         
/*  914 */         path_AST = currentAST.root;
/*  915 */         break;
/*      */       
/*      */ 
/*      */       default: 
/*  919 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/*  924 */       reportError(ex);
/*  925 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/*  927 */     this.returnAST = path_AST;
/*  928 */     this._retTree = _t;
/*  929 */     return p;
/*      */   }
/*      */   
/*      */   public final void insertablePropertySpec(AST _t) throws RecognitionException
/*      */   {
/*  934 */     AST insertablePropertySpec_AST_in = _t == ASTNULL ? null : _t;
/*  935 */     this.returnAST = null;
/*  936 */     ASTPair currentAST = new ASTPair();
/*  937 */     AST insertablePropertySpec_AST = null;
/*      */     try
/*      */     {
/*  940 */       AST __t16 = _t;
/*  941 */       AST tmp8_AST = null;
/*  942 */       AST tmp8_AST_in = null;
/*  943 */       tmp8_AST = this.astFactory.create(_t);
/*  944 */       tmp8_AST_in = _t;
/*  945 */       this.astFactory.addASTChild(currentAST, tmp8_AST);
/*  946 */       ASTPair __currentAST16 = currentAST.copy();
/*  947 */       currentAST.root = currentAST.child;
/*  948 */       currentAST.child = null;
/*  949 */       match(_t, 84);
/*  950 */       _t = _t.getFirstChild();
/*      */       
/*  952 */       int _cnt18 = 0;
/*      */       for (;;)
/*      */       {
/*  955 */         if (_t == null) _t = ASTNULL;
/*  956 */         if (_t.getType() == 119) {
/*  957 */           AST tmp9_AST = null;
/*  958 */           AST tmp9_AST_in = null;
/*  959 */           tmp9_AST = this.astFactory.create(_t);
/*  960 */           tmp9_AST_in = _t;
/*  961 */           this.astFactory.addASTChild(currentAST, tmp9_AST);
/*  962 */           match(_t, 119);
/*  963 */           _t = _t.getNextSibling();
/*      */         }
/*      */         else {
/*  966 */           if (_cnt18 >= 1) break; throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*  969 */         _cnt18++;
/*      */       }
/*      */       
/*  972 */       currentAST = __currentAST16;
/*  973 */       _t = __t16;
/*  974 */       _t = _t.getNextSibling();
/*  975 */       insertablePropertySpec_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/*  978 */       reportError(ex);
/*  979 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/*  981 */     this.returnAST = insertablePropertySpec_AST;
/*  982 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void assignment(AST _t) throws RecognitionException
/*      */   {
/*  987 */     AST assignment_AST_in = _t == ASTNULL ? null : _t;
/*  988 */     this.returnAST = null;
/*  989 */     ASTPair currentAST = new ASTPair();
/*  990 */     AST assignment_AST = null;
/*  991 */     AST p_AST = null;
/*  992 */     AST p = null;
/*      */     try
/*      */     {
/*  995 */       AST __t24 = _t;
/*  996 */       AST tmp10_AST = null;
/*  997 */       AST tmp10_AST_in = null;
/*  998 */       tmp10_AST = this.astFactory.create(_t);
/*  999 */       tmp10_AST_in = _t;
/* 1000 */       this.astFactory.addASTChild(currentAST, tmp10_AST);
/* 1001 */       ASTPair __currentAST24 = currentAST.copy();
/* 1002 */       currentAST.root = currentAST.child;
/* 1003 */       currentAST.child = null;
/* 1004 */       match(_t, 96);
/* 1005 */       _t = _t.getFirstChild();
/*      */       
/* 1007 */       p = _t == ASTNULL ? null : _t;
/* 1008 */       propertyRef(_t);
/* 1009 */       _t = this._retTree;
/* 1010 */       p_AST = this.returnAST;
/* 1011 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/* 1013 */       resolve(p_AST);
/*      */       
/* 1015 */       newValue(_t);
/* 1016 */       _t = this._retTree;
/* 1017 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/* 1019 */       currentAST = __currentAST24;
/* 1020 */       _t = __t24;
/* 1021 */       _t = _t.getNextSibling();
/* 1022 */       assignment_AST = currentAST.root;
/*      */       
/* 1024 */       evaluateAssignment(assignment_AST);
/*      */       
/* 1026 */       assignment_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1029 */       reportError(ex);
/* 1030 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 1032 */     this.returnAST = assignment_AST;
/* 1033 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void propertyRef(AST _t) throws RecognitionException
/*      */   {
/* 1038 */     AST propertyRef_AST_in = _t == ASTNULL ? null : _t;
/* 1039 */     this.returnAST = null;
/* 1040 */     ASTPair currentAST = new ASTPair();
/* 1041 */     AST propertyRef_AST = null;
/* 1042 */     AST d = null;
/* 1043 */     AST d_AST = null;
/* 1044 */     AST lhs_AST = null;
/* 1045 */     AST lhs = null;
/* 1046 */     AST rhs_AST = null;
/* 1047 */     AST rhs = null;
/* 1048 */     AST p_AST = null;
/* 1049 */     AST p = null;
/*      */     try
/*      */     {
/* 1052 */       if (_t == null) _t = ASTNULL;
/* 1053 */       switch (_t.getType())
/*      */       {
/*      */       case 15: 
/* 1056 */         AST __t173 = _t;
/* 1057 */         d = _t == ASTNULL ? null : _t;
/* 1058 */         AST d_AST_in = null;
/* 1059 */         d_AST = this.astFactory.create(d);
/* 1060 */         ASTPair __currentAST173 = currentAST.copy();
/* 1061 */         currentAST.root = currentAST.child;
/* 1062 */         currentAST.child = null;
/* 1063 */         match(_t, 15);
/* 1064 */         _t = _t.getFirstChild();
/* 1065 */         lhs = _t == ASTNULL ? null : _t;
/* 1066 */         propertyRefLhs(_t);
/* 1067 */         _t = this._retTree;
/* 1068 */         lhs_AST = this.returnAST;
/* 1069 */         rhs = _t == ASTNULL ? null : _t;
/* 1070 */         propertyName(_t);
/* 1071 */         _t = this._retTree;
/* 1072 */         rhs_AST = this.returnAST;
/* 1073 */         currentAST = __currentAST173;
/* 1074 */         _t = __t173;
/* 1075 */         _t = _t.getNextSibling();
/* 1076 */         propertyRef_AST = currentAST.root;
/*      */         
/*      */ 
/* 1079 */         propertyRef_AST = this.astFactory.make(new ASTArray(3).add(d_AST).add(lhs_AST).add(rhs_AST));
/* 1080 */         propertyRef_AST = lookupProperty(propertyRef_AST, false, true);
/*      */         
/* 1082 */         currentAST.root = propertyRef_AST;
/* 1083 */         currentAST.child = ((propertyRef_AST != null) && (propertyRef_AST.getFirstChild() != null) ? propertyRef_AST.getFirstChild() : propertyRef_AST);
/*      */         
/* 1085 */         currentAST.advanceChildToEnd();
/* 1086 */         break;
/*      */       
/*      */ 
/*      */       case 90: 
/*      */       case 119: 
/* 1091 */         p = _t == ASTNULL ? null : _t;
/* 1092 */         identifier(_t);
/* 1093 */         _t = this._retTree;
/* 1094 */         p_AST = this.returnAST;
/* 1095 */         propertyRef_AST = currentAST.root;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1101 */         if (isNonQualifiedPropertyRef(p_AST)) {
/* 1102 */           propertyRef_AST = lookupNonQualifiedProperty(p_AST);
/*      */         }
/*      */         else {
/* 1105 */           resolve(p_AST);
/* 1106 */           propertyRef_AST = p_AST;
/*      */         }
/*      */         
/* 1109 */         currentAST.root = propertyRef_AST;
/* 1110 */         currentAST.child = ((propertyRef_AST != null) && (propertyRef_AST.getFirstChild() != null) ? propertyRef_AST.getFirstChild() : propertyRef_AST);
/*      */         
/* 1112 */         currentAST.advanceChildToEnd();
/* 1113 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 1117 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 1122 */       reportError(ex);
/* 1123 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 1125 */     this.returnAST = propertyRef_AST;
/* 1126 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void newValue(AST _t) throws RecognitionException
/*      */   {
/* 1131 */     AST newValue_AST_in = _t == ASTNULL ? null : _t;
/* 1132 */     this.returnAST = null;
/* 1133 */     ASTPair currentAST = new ASTPair();
/* 1134 */     AST newValue_AST = null;
/*      */     try
/*      */     {
/* 1137 */       if (_t == null) _t = ASTNULL;
/* 1138 */       switch (_t.getType())
/*      */       {
/*      */       case 12: 
/*      */       case 15: 
/*      */       case 20: 
/*      */       case 39: 
/*      */       case 49: 
/*      */       case 54: 
/*      */       case 68: 
/*      */       case 71: 
/*      */       case 75: 
/*      */       case 78: 
/*      */       case 87: 
/*      */       case 89: 
/*      */       case 90: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 111: 
/*      */       case 112: 
/*      */       case 115: 
/*      */       case 116: 
/*      */       case 117: 
/*      */       case 118: 
/*      */       case 119: 
/* 1165 */         expr(_t);
/* 1166 */         _t = this._retTree;
/* 1167 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1168 */         newValue_AST = currentAST.root;
/* 1169 */         break;
/*      */       
/*      */ 
/*      */       case 83: 
/* 1173 */         query(_t);
/* 1174 */         _t = this._retTree;
/* 1175 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1176 */         newValue_AST = currentAST.root;
/* 1177 */         break;
/*      */       case 13: case 14: case 16: case 17: case 18: case 19: case 21: case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 40: case 41: case 42: case 43: 
/*      */       case 44: case 45: case 46: case 47: case 48: case 50: case 51: case 52: case 53: case 55: case 56: case 57: case 58: case 59: case 60: case 61: case 62: case 63: case 64: case 65: case 66: case 67: case 69: case 70: case 72: case 73: case 74: case 76: 
/*      */       case 77: case 79: case 80: case 81: case 82: case 84: case 85: case 86: case 88: case 91: case 95: case 96: case 97: case 98: case 99: case 100: case 101: case 102: case 103: case 104: case 105: case 106: case 107: case 108: case 113: case 114: default: 
/* 1181 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 1186 */       reportError(ex);
/* 1187 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 1189 */     this.returnAST = newValue_AST;
/* 1190 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void expr(AST _t) throws RecognitionException
/*      */   {
/* 1195 */     AST expr_AST_in = _t == ASTNULL ? null : _t;
/* 1196 */     this.returnAST = null;
/* 1197 */     ASTPair currentAST = new ASTPair();
/* 1198 */     AST expr_AST = null;
/* 1199 */     AST ae_AST = null;
/* 1200 */     AST ae = null;
/*      */     try
/*      */     {
/* 1203 */       if (_t == null) _t = ASTNULL;
/* 1204 */       switch (_t.getType())
/*      */       {
/*      */       case 15: 
/*      */       case 75: 
/*      */       case 90: 
/*      */       case 119: 
/* 1210 */         ae = _t == ASTNULL ? null : _t;
/* 1211 */         addrExpr(_t, true);
/* 1212 */         _t = this._retTree;
/* 1213 */         ae_AST = this.returnAST;
/* 1214 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1215 */         resolve(ae_AST);
/* 1216 */         expr_AST = currentAST.root;
/* 1217 */         break;
/*      */       
/*      */ 
/*      */       case 89: 
/* 1221 */         AST __t131 = _t;
/* 1222 */         AST tmp11_AST = null;
/* 1223 */         AST tmp11_AST_in = null;
/* 1224 */         tmp11_AST = this.astFactory.create(_t);
/* 1225 */         tmp11_AST_in = _t;
/* 1226 */         this.astFactory.addASTChild(currentAST, tmp11_AST);
/* 1227 */         ASTPair __currentAST131 = currentAST.copy();
/* 1228 */         currentAST.root = currentAST.child;
/* 1229 */         currentAST.child = null;
/* 1230 */         match(_t, 89);
/* 1231 */         _t = _t.getFirstChild();
/*      */         
/*      */         for (;;)
/*      */         {
/* 1235 */           if (_t == null) _t = ASTNULL;
/* 1236 */           if (!_tokenSet_0.member(_t.getType())) break;
/* 1237 */           expr(_t);
/* 1238 */           _t = this._retTree;
/* 1239 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1247 */         currentAST = __currentAST131;
/* 1248 */         _t = __t131;
/* 1249 */         _t = _t.getNextSibling();
/* 1250 */         expr_AST = currentAST.root;
/* 1251 */         break;
/*      */       
/*      */ 
/*      */       case 20: 
/*      */       case 39: 
/*      */       case 49: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 117: 
/*      */       case 118: 
/* 1262 */         constant(_t);
/* 1263 */         _t = this._retTree;
/* 1264 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1265 */         expr_AST = currentAST.root;
/* 1266 */         break;
/*      */       
/*      */ 
/*      */       case 54: 
/*      */       case 71: 
/*      */       case 87: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 111: 
/*      */       case 112: 
/* 1276 */         arithmeticExpr(_t);
/* 1277 */         _t = this._retTree;
/* 1278 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1279 */         expr_AST = currentAST.root;
/* 1280 */         break;
/*      */       
/*      */ 
/*      */       case 68: 
/*      */       case 78: 
/* 1285 */         functionCall(_t);
/* 1286 */         _t = this._retTree;
/* 1287 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1288 */         expr_AST = currentAST.root;
/* 1289 */         break;
/*      */       
/*      */ 
/*      */       case 115: 
/*      */       case 116: 
/* 1294 */         parameter(_t);
/* 1295 */         _t = this._retTree;
/* 1296 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1297 */         expr_AST = currentAST.root;
/* 1298 */         break;
/*      */       
/*      */ 
/*      */       case 12: 
/* 1302 */         count(_t);
/* 1303 */         _t = this._retTree;
/* 1304 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1305 */         expr_AST = currentAST.root;
/* 1306 */         break;
/*      */       case 13: case 14: case 16: case 17: case 18: case 19: case 21: case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 40: case 41: case 42: case 43: 
/*      */       case 44: case 45: case 46: case 47: case 48: case 50: case 51: case 52: case 53: case 55: case 56: case 57: case 58: case 59: case 60: case 61: case 62: case 63: case 64: case 65: case 66: case 67: case 69: case 70: case 72: case 73: case 74: case 76: 
/*      */       case 77: case 79: case 80: case 81: case 82: case 83: case 84: case 85: case 86: case 88: case 91: case 95: case 96: case 97: case 98: case 99: case 100: case 101: case 102: case 103: case 104: case 105: case 106: case 107: case 108: case 113: case 114: default: 
/* 1310 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 1315 */       reportError(ex);
/* 1316 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 1318 */     this.returnAST = expr_AST;
/* 1319 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void selectClause(AST _t) throws RecognitionException
/*      */   {
/* 1324 */     AST selectClause_AST_in = _t == ASTNULL ? null : _t;
/* 1325 */     this.returnAST = null;
/* 1326 */     ASTPair currentAST = new ASTPair();
/* 1327 */     AST selectClause_AST = null;
/* 1328 */     AST d = null;
/* 1329 */     AST d_AST = null;
/* 1330 */     AST x_AST = null;
/* 1331 */     AST x = null;
/*      */     try
/*      */     {
/* 1334 */       AST __t47 = _t;
/* 1335 */       AST tmp12_AST = null;
/* 1336 */       AST tmp12_AST_in = null;
/* 1337 */       tmp12_AST = this.astFactory.create(_t);
/* 1338 */       tmp12_AST_in = _t;
/* 1339 */       ASTPair __currentAST47 = currentAST.copy();
/* 1340 */       currentAST.root = currentAST.child;
/* 1341 */       currentAST.child = null;
/* 1342 */       match(_t, 45);
/* 1343 */       _t = _t.getFirstChild();
/* 1344 */       handleClauseStart(45);beforeSelectClause();
/*      */       
/* 1346 */       if (_t == null) _t = ASTNULL;
/* 1347 */       switch (_t.getType())
/*      */       {
/*      */       case 16: 
/* 1350 */         d = _t;
/* 1351 */         AST d_AST_in = null;
/* 1352 */         d_AST = this.astFactory.create(d);
/* 1353 */         match(_t, 16);
/* 1354 */         _t = _t.getNextSibling();
/* 1355 */         break;
/*      */       case 4: case 7: case 12: case 15: case 17: case 27: case 54: case 65: case 68: case 70: case 71: case 78: case 83: case 87: case 90: case 92: case 93: case 94: case 109: case 110: case 111: case 112: case 117: case 118: case 119: 
/*      */         break;
/*      */       case 5: case 6: case 8: case 9: 
/*      */       case 10: case 11: case 13: case 14: 
/*      */       case 18: case 19: case 20: case 21: 
/*      */       case 22: case 23: case 24: case 25: 
/*      */       case 26: case 28: case 29: 
/*      */       case 30: case 31: case 32: 
/*      */       case 33: case 34: case 35: 
/*      */       case 36: case 37: case 38: 
/*      */       case 39: case 40: case 41: 
/*      */       case 42: case 43: case 44: 
/*      */       case 45: case 46: case 47: 
/*      */       case 48: case 49: case 50: 
/*      */       case 51: case 52: case 53: 
/*      */       case 55: case 56: case 57: 
/*      */       case 58: case 59: case 60: 
/*      */       case 61: case 62: case 63: 
/*      */       case 64: case 66: case 67: 
/*      */       case 69: case 72: case 73: 
/*      */       case 74: case 75: case 76: 
/*      */       case 77: case 79: case 80: 
/*      */       case 81: case 82: case 84: 
/*      */       case 85: case 86: case 88: 
/*      */       case 89: case 91: case 95: 
/*      */       case 96: case 97: case 98: 
/*      */       case 99: case 100: case 101: 
/*      */       case 102: case 103: case 104: 
/*      */       case 105: case 106: case 107: 
/*      */       case 108: case 113: case 114: 
/*      */       case 115: case 116: default: 
/* 1387 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/* 1391 */       x = _t == ASTNULL ? null : _t;
/* 1392 */       selectExprList(_t);
/* 1393 */       _t = this._retTree;
/* 1394 */       x_AST = this.returnAST;
/* 1395 */       currentAST = __currentAST47;
/* 1396 */       _t = __t47;
/* 1397 */       _t = _t.getNextSibling();
/* 1398 */       selectClause_AST = currentAST.root;
/*      */       
/* 1400 */       selectClause_AST = this.astFactory.make(new ASTArray(3).add(this.astFactory.create(130, "{select clause}")).add(d_AST).add(x_AST));
/*      */       
/* 1402 */       currentAST.root = selectClause_AST;
/* 1403 */       currentAST.child = ((selectClause_AST != null) && (selectClause_AST.getFirstChild() != null) ? selectClause_AST.getFirstChild() : selectClause_AST);
/*      */       
/* 1405 */       currentAST.advanceChildToEnd();
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1408 */       reportError(ex);
/* 1409 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 1411 */     this.returnAST = selectClause_AST;
/* 1412 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void groupClause(AST _t) throws RecognitionException
/*      */   {
/* 1417 */     AST groupClause_AST_in = _t == ASTNULL ? null : _t;
/* 1418 */     this.returnAST = null;
/* 1419 */     ASTPair currentAST = new ASTPair();
/* 1420 */     AST groupClause_AST = null;
/*      */     try
/*      */     {
/* 1423 */       AST __t41 = _t;
/* 1424 */       AST tmp13_AST = null;
/* 1425 */       AST tmp13_AST_in = null;
/* 1426 */       tmp13_AST = this.astFactory.create(_t);
/* 1427 */       tmp13_AST_in = _t;
/* 1428 */       this.astFactory.addASTChild(currentAST, tmp13_AST);
/* 1429 */       ASTPair __currentAST41 = currentAST.copy();
/* 1430 */       currentAST.root = currentAST.child;
/* 1431 */       currentAST.child = null;
/* 1432 */       match(_t, 24);
/* 1433 */       _t = _t.getFirstChild();
/* 1434 */       handleClauseStart(24);
/*      */       
/* 1436 */       int _cnt43 = 0;
/*      */       for (;;)
/*      */       {
/* 1439 */         if (_t == null) _t = ASTNULL;
/* 1440 */         if (_tokenSet_0.member(_t.getType())) {
/* 1441 */           expr(_t);
/* 1442 */           _t = this._retTree;
/* 1443 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */         }
/*      */         else {
/* 1446 */           if (_cnt43 >= 1) break; throw new NoViableAltException(_t);
/*      */         }
/*      */         
/* 1449 */         _cnt43++;
/*      */       }
/*      */       
/*      */ 
/* 1453 */       if (_t == null) _t = ASTNULL;
/* 1454 */       switch (_t.getType())
/*      */       {
/*      */       case 25: 
/* 1457 */         AST __t45 = _t;
/* 1458 */         AST tmp14_AST = null;
/* 1459 */         AST tmp14_AST_in = null;
/* 1460 */         tmp14_AST = this.astFactory.create(_t);
/* 1461 */         tmp14_AST_in = _t;
/* 1462 */         this.astFactory.addASTChild(currentAST, tmp14_AST);
/* 1463 */         ASTPair __currentAST45 = currentAST.copy();
/* 1464 */         currentAST.root = currentAST.child;
/* 1465 */         currentAST.child = null;
/* 1466 */         match(_t, 25);
/* 1467 */         _t = _t.getFirstChild();
/* 1468 */         logicalExpr(_t);
/* 1469 */         _t = this._retTree;
/* 1470 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1471 */         currentAST = __currentAST45;
/* 1472 */         _t = __t45;
/* 1473 */         _t = _t.getNextSibling();
/* 1474 */         break;
/*      */       
/*      */ 
/*      */       case 3: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 1482 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/* 1486 */       currentAST = __currentAST41;
/* 1487 */       _t = __t41;
/* 1488 */       _t = _t.getNextSibling();
/* 1489 */       groupClause_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1492 */       reportError(ex);
/* 1493 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 1495 */     this.returnAST = groupClause_AST;
/* 1496 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void orderClause(AST _t) throws RecognitionException
/*      */   {
/* 1501 */     AST orderClause_AST_in = _t == ASTNULL ? null : _t;
/* 1502 */     this.returnAST = null;
/* 1503 */     ASTPair currentAST = new ASTPair();
/* 1504 */     AST orderClause_AST = null;
/*      */     try
/*      */     {
/* 1507 */       AST __t36 = _t;
/* 1508 */       AST tmp15_AST = null;
/* 1509 */       AST tmp15_AST_in = null;
/* 1510 */       tmp15_AST = this.astFactory.create(_t);
/* 1511 */       tmp15_AST_in = _t;
/* 1512 */       this.astFactory.addASTChild(currentAST, tmp15_AST);
/* 1513 */       ASTPair __currentAST36 = currentAST.copy();
/* 1514 */       currentAST.root = currentAST.child;
/* 1515 */       currentAST.child = null;
/* 1516 */       match(_t, 41);
/* 1517 */       _t = _t.getFirstChild();
/* 1518 */       handleClauseStart(41);
/* 1519 */       orderExprs(_t);
/* 1520 */       _t = this._retTree;
/* 1521 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1522 */       currentAST = __currentAST36;
/* 1523 */       _t = __t36;
/* 1524 */       _t = _t.getNextSibling();
/* 1525 */       orderClause_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1528 */       reportError(ex);
/* 1529 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 1531 */     this.returnAST = orderClause_AST;
/* 1532 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void orderExprs(AST _t) throws RecognitionException
/*      */   {
/* 1537 */     AST orderExprs_AST_in = _t == ASTNULL ? null : _t;
/* 1538 */     this.returnAST = null;
/* 1539 */     ASTPair currentAST = new ASTPair();
/* 1540 */     AST orderExprs_AST = null;
/*      */     try
/*      */     {
/* 1543 */       expr(_t);
/* 1544 */       _t = this._retTree;
/* 1545 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/* 1547 */       if (_t == null) _t = ASTNULL;
/* 1548 */       switch (_t.getType())
/*      */       {
/*      */       case 8: 
/* 1551 */         AST tmp16_AST = null;
/* 1552 */         AST tmp16_AST_in = null;
/* 1553 */         tmp16_AST = this.astFactory.create(_t);
/* 1554 */         tmp16_AST_in = _t;
/* 1555 */         this.astFactory.addASTChild(currentAST, tmp16_AST);
/* 1556 */         match(_t, 8);
/* 1557 */         _t = _t.getNextSibling();
/* 1558 */         break;
/*      */       
/*      */ 
/*      */       case 14: 
/* 1562 */         AST tmp17_AST = null;
/* 1563 */         AST tmp17_AST_in = null;
/* 1564 */         tmp17_AST = this.astFactory.create(_t);
/* 1565 */         tmp17_AST_in = _t;
/* 1566 */         this.astFactory.addASTChild(currentAST, tmp17_AST);
/* 1567 */         match(_t, 14);
/* 1568 */         _t = _t.getNextSibling();
/* 1569 */         break;
/*      */       case 3: case 12: case 15: case 20: case 39: case 49: case 54: case 68: case 71: case 75: case 78: case 87: case 89: case 90: case 92: case 93: case 94: case 109: case 110: case 111: case 112: case 115: case 116: case 117: case 118: case 119: 
/*      */         break;
/*      */       case 4: case 5: case 6: 
/*      */       case 7: case 9: case 10: 
/*      */       case 11: case 13: case 16: 
/*      */       case 17: case 18: case 19: 
/*      */       case 21: case 22: case 23: 
/*      */       case 24: case 25: case 26: 
/*      */       case 27: case 28: case 29: 
/*      */       case 30: case 31: case 32: 
/*      */       case 33: case 34: case 35: 
/*      */       case 36: case 37: case 38: 
/*      */       case 40: case 41: case 42: 
/*      */       case 43: case 44: case 45: 
/*      */       case 46: case 47: case 48: 
/*      */       case 50: case 51: case 52: 
/*      */       case 53: case 55: case 56: 
/*      */       case 57: case 58: case 59: 
/*      */       case 60: case 61: case 62: 
/*      */       case 63: case 64: case 65: 
/*      */       case 66: case 67: case 69: 
/*      */       case 70: case 72: case 73: 
/*      */       case 74: case 76: case 77: 
/*      */       case 79: case 80: case 81: 
/*      */       case 82: case 83: case 84: 
/*      */       case 85: case 86: case 88: 
/*      */       case 91: case 95: case 96: 
/*      */       case 97: case 98: case 99: 
/*      */       case 100: case 101: case 102: 
/*      */       case 103: case 104: case 105: 
/*      */       case 106: case 107: case 108: 
/*      */       case 113: case 114: default: 
/* 1602 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/*      */ 
/* 1607 */       if (_t == null) _t = ASTNULL;
/* 1608 */       switch (_t.getType())
/*      */       {
/*      */       case 12: 
/*      */       case 15: 
/*      */       case 20: 
/*      */       case 39: 
/*      */       case 49: 
/*      */       case 54: 
/*      */       case 68: 
/*      */       case 71: 
/*      */       case 75: 
/*      */       case 78: 
/*      */       case 87: 
/*      */       case 89: 
/*      */       case 90: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 111: 
/*      */       case 112: 
/*      */       case 115: 
/*      */       case 116: 
/*      */       case 117: 
/*      */       case 118: 
/*      */       case 119: 
/* 1635 */         orderExprs(_t);
/* 1636 */         _t = this._retTree;
/* 1637 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1638 */         break;
/*      */       case 3: 
/*      */         break;
/*      */       case 4: case 5: case 6: case 7: case 8: case 9: case 10: case 11: case 13: case 14: case 16: case 17: case 18: case 19: case 21: case 22: case 23: case 24: case 25: 
/*      */       case 26: case 27: case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 40: case 41: case 42: case 43: case 44: case 45: 
/*      */       case 46: case 47: case 48: case 50: case 51: case 52: case 53: case 55: case 56: case 57: case 58: case 59: case 60: case 61: case 62: case 63: case 64: case 65: 
/*      */       case 66: case 67: case 69: case 70: case 72: case 73: case 74: case 76: case 77: case 79: case 80: case 81: case 82: case 83: case 84: case 85: case 86: case 88: 
/*      */       case 91: case 95: case 96: case 97: case 98: case 99: case 100: case 101: case 102: case 103: case 104: case 105: case 106: case 107: case 108: case 113: case 114: default: 
/* 1646 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/* 1650 */       orderExprs_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1653 */       reportError(ex);
/* 1654 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 1656 */     this.returnAST = orderExprs_AST;
/* 1657 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void logicalExpr(AST _t) throws RecognitionException
/*      */   {
/* 1662 */     AST logicalExpr_AST_in = _t == ASTNULL ? null : _t;
/* 1663 */     this.returnAST = null;
/* 1664 */     ASTPair currentAST = new ASTPair();
/* 1665 */     AST logicalExpr_AST = null;
/*      */     try
/*      */     {
/* 1668 */       if (_t == null) _t = ASTNULL;
/* 1669 */       switch (_t.getType())
/*      */       {
/*      */       case 6: 
/* 1672 */         AST __t94 = _t;
/* 1673 */         AST tmp18_AST = null;
/* 1674 */         AST tmp18_AST_in = null;
/* 1675 */         tmp18_AST = this.astFactory.create(_t);
/* 1676 */         tmp18_AST_in = _t;
/* 1677 */         this.astFactory.addASTChild(currentAST, tmp18_AST);
/* 1678 */         ASTPair __currentAST94 = currentAST.copy();
/* 1679 */         currentAST.root = currentAST.child;
/* 1680 */         currentAST.child = null;
/* 1681 */         match(_t, 6);
/* 1682 */         _t = _t.getFirstChild();
/* 1683 */         logicalExpr(_t);
/* 1684 */         _t = this._retTree;
/* 1685 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1686 */         logicalExpr(_t);
/* 1687 */         _t = this._retTree;
/* 1688 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1689 */         currentAST = __currentAST94;
/* 1690 */         _t = __t94;
/* 1691 */         _t = _t.getNextSibling();
/* 1692 */         logicalExpr_AST = currentAST.root;
/* 1693 */         break;
/*      */       
/*      */ 
/*      */       case 40: 
/* 1697 */         AST __t95 = _t;
/* 1698 */         AST tmp19_AST = null;
/* 1699 */         AST tmp19_AST_in = null;
/* 1700 */         tmp19_AST = this.astFactory.create(_t);
/* 1701 */         tmp19_AST_in = _t;
/* 1702 */         this.astFactory.addASTChild(currentAST, tmp19_AST);
/* 1703 */         ASTPair __currentAST95 = currentAST.copy();
/* 1704 */         currentAST.root = currentAST.child;
/* 1705 */         currentAST.child = null;
/* 1706 */         match(_t, 40);
/* 1707 */         _t = _t.getFirstChild();
/* 1708 */         logicalExpr(_t);
/* 1709 */         _t = this._retTree;
/* 1710 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1711 */         logicalExpr(_t);
/* 1712 */         _t = this._retTree;
/* 1713 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1714 */         currentAST = __currentAST95;
/* 1715 */         _t = __t95;
/* 1716 */         _t = _t.getNextSibling();
/* 1717 */         logicalExpr_AST = currentAST.root;
/* 1718 */         break;
/*      */       
/*      */ 
/*      */       case 38: 
/* 1722 */         AST __t96 = _t;
/* 1723 */         AST tmp20_AST = null;
/* 1724 */         AST tmp20_AST_in = null;
/* 1725 */         tmp20_AST = this.astFactory.create(_t);
/* 1726 */         tmp20_AST_in = _t;
/* 1727 */         this.astFactory.addASTChild(currentAST, tmp20_AST);
/* 1728 */         ASTPair __currentAST96 = currentAST.copy();
/* 1729 */         currentAST.root = currentAST.child;
/* 1730 */         currentAST.child = null;
/* 1731 */         match(_t, 38);
/* 1732 */         _t = _t.getFirstChild();
/* 1733 */         logicalExpr(_t);
/* 1734 */         _t = this._retTree;
/* 1735 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1736 */         currentAST = __currentAST96;
/* 1737 */         _t = __t96;
/* 1738 */         _t = _t.getNextSibling();
/* 1739 */         logicalExpr_AST = currentAST.root;
/* 1740 */         break;
/*      */       
/*      */ 
/*      */       case 10: 
/*      */       case 19: 
/*      */       case 26: 
/*      */       case 34: 
/*      */       case 76: 
/*      */       case 77: 
/*      */       case 79: 
/*      */       case 80: 
/*      */       case 81: 
/*      */       case 96: 
/*      */       case 102: 
/*      */       case 104: 
/*      */       case 105: 
/*      */       case 106: 
/*      */       case 107: 
/* 1758 */         comparisonExpr(_t);
/* 1759 */         _t = this._retTree;
/* 1760 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1761 */         logicalExpr_AST = currentAST.root;
/* 1762 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 1766 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 1771 */       reportError(ex);
/* 1772 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 1774 */     this.returnAST = logicalExpr_AST;
/* 1775 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void selectExprList(AST _t) throws RecognitionException
/*      */   {
/* 1780 */     AST selectExprList_AST_in = _t == ASTNULL ? null : _t;
/* 1781 */     this.returnAST = null;
/* 1782 */     ASTPair currentAST = new ASTPair();
/* 1783 */     AST selectExprList_AST = null;
/*      */     
/* 1785 */     boolean oldInSelect = this.inSelect;
/* 1786 */     this.inSelect = true;
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1791 */       int _cnt51 = 0;
/*      */       for (;;)
/*      */       {
/* 1794 */         if (_t == null) _t = ASTNULL;
/* 1795 */         switch (_t.getType())
/*      */         {
/*      */         case 4: 
/*      */         case 12: 
/*      */         case 15: 
/*      */         case 17: 
/*      */         case 27: 
/*      */         case 54: 
/*      */         case 65: 
/*      */         case 68: 
/*      */         case 70: 
/*      */         case 71: 
/*      */         case 78: 
/*      */         case 83: 
/*      */         case 87: 
/*      */         case 90: 
/*      */         case 92: 
/*      */         case 93: 
/*      */         case 94: 
/*      */         case 109: 
/*      */         case 110: 
/*      */         case 111: 
/*      */         case 112: 
/*      */         case 117: 
/*      */         case 118: 
/*      */         case 119: 
/* 1821 */           selectExpr(_t);
/* 1822 */           _t = this._retTree;
/* 1823 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1824 */           break;
/*      */         
/*      */ 
/*      */         case 7: 
/* 1828 */           aliasedSelectExpr(_t);
/* 1829 */           _t = this._retTree;
/* 1830 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1831 */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 1835 */           if (_cnt51 >= 1) break label342; throw new NoViableAltException(_t);
/*      */         }
/*      */         
/* 1838 */         _cnt51++;
/*      */       }
/*      */       
/*      */       label342:
/* 1842 */       this.inSelect = oldInSelect;
/*      */       
/* 1844 */       selectExprList_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 1847 */       reportError(ex);
/* 1848 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 1850 */     this.returnAST = selectExprList_AST;
/* 1851 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void selectExpr(AST _t) throws RecognitionException
/*      */   {
/* 1856 */     AST selectExpr_AST_in = _t == ASTNULL ? null : _t;
/* 1857 */     this.returnAST = null;
/* 1858 */     ASTPair currentAST = new ASTPair();
/* 1859 */     AST selectExpr_AST = null;
/* 1860 */     AST p_AST = null;
/* 1861 */     AST p = null;
/* 1862 */     AST ar2_AST = null;
/* 1863 */     AST ar2 = null;
/* 1864 */     AST ar3_AST = null;
/* 1865 */     AST ar3 = null;
/* 1866 */     AST con_AST = null;
/* 1867 */     AST con = null;
/*      */     try
/*      */     {
/* 1870 */       if (_t == null) _t = ASTNULL;
/* 1871 */       switch (_t.getType())
/*      */       {
/*      */       case 15: 
/*      */       case 90: 
/*      */       case 119: 
/* 1876 */         p = _t == ASTNULL ? null : _t;
/* 1877 */         propertyRef(_t);
/* 1878 */         _t = this._retTree;
/* 1879 */         p_AST = this.returnAST;
/* 1880 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1881 */         resolveSelectExpression(p_AST);
/* 1882 */         selectExpr_AST = currentAST.root;
/* 1883 */         break;
/*      */       
/*      */ 
/*      */       case 4: 
/* 1887 */         AST __t55 = _t;
/* 1888 */         AST tmp21_AST = null;
/* 1889 */         AST tmp21_AST_in = null;
/* 1890 */         tmp21_AST = this.astFactory.create(_t);
/* 1891 */         tmp21_AST_in = _t;
/* 1892 */         this.astFactory.addASTChild(currentAST, tmp21_AST);
/* 1893 */         ASTPair __currentAST55 = currentAST.copy();
/* 1894 */         currentAST.root = currentAST.child;
/* 1895 */         currentAST.child = null;
/* 1896 */         match(_t, 4);
/* 1897 */         _t = _t.getFirstChild();
/* 1898 */         ar2 = _t == ASTNULL ? null : _t;
/* 1899 */         aliasRef(_t);
/* 1900 */         _t = this._retTree;
/* 1901 */         ar2_AST = this.returnAST;
/* 1902 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1903 */         currentAST = __currentAST55;
/* 1904 */         _t = __t55;
/* 1905 */         _t = _t.getNextSibling();
/* 1906 */         selectExpr_AST = currentAST.root;
/* 1907 */         resolveSelectExpression(ar2_AST);selectExpr_AST = ar2_AST;
/* 1908 */         currentAST.root = selectExpr_AST;
/* 1909 */         currentAST.child = ((selectExpr_AST != null) && (selectExpr_AST.getFirstChild() != null) ? selectExpr_AST.getFirstChild() : selectExpr_AST);
/*      */         
/* 1911 */         currentAST.advanceChildToEnd();
/* 1912 */         selectExpr_AST = currentAST.root;
/* 1913 */         break;
/*      */       
/*      */ 
/*      */       case 65: 
/* 1917 */         AST __t56 = _t;
/* 1918 */         AST tmp22_AST = null;
/* 1919 */         AST tmp22_AST_in = null;
/* 1920 */         tmp22_AST = this.astFactory.create(_t);
/* 1921 */         tmp22_AST_in = _t;
/* 1922 */         this.astFactory.addASTChild(currentAST, tmp22_AST);
/* 1923 */         ASTPair __currentAST56 = currentAST.copy();
/* 1924 */         currentAST.root = currentAST.child;
/* 1925 */         currentAST.child = null;
/* 1926 */         match(_t, 65);
/* 1927 */         _t = _t.getFirstChild();
/* 1928 */         ar3 = _t == ASTNULL ? null : _t;
/* 1929 */         aliasRef(_t);
/* 1930 */         _t = this._retTree;
/* 1931 */         ar3_AST = this.returnAST;
/* 1932 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1933 */         currentAST = __currentAST56;
/* 1934 */         _t = __t56;
/* 1935 */         _t = _t.getNextSibling();
/* 1936 */         selectExpr_AST = currentAST.root;
/* 1937 */         resolveSelectExpression(ar3_AST);selectExpr_AST = ar3_AST;
/* 1938 */         currentAST.root = selectExpr_AST;
/* 1939 */         currentAST.child = ((selectExpr_AST != null) && (selectExpr_AST.getFirstChild() != null) ? selectExpr_AST.getFirstChild() : selectExpr_AST);
/*      */         
/* 1941 */         currentAST.advanceChildToEnd();
/* 1942 */         selectExpr_AST = currentAST.root;
/* 1943 */         break;
/*      */       
/*      */ 
/*      */       case 70: 
/* 1947 */         con = _t == ASTNULL ? null : _t;
/* 1948 */         constructor(_t);
/* 1949 */         _t = this._retTree;
/* 1950 */         con_AST = this.returnAST;
/* 1951 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1952 */         processConstructor(con_AST);
/* 1953 */         selectExpr_AST = currentAST.root;
/* 1954 */         break;
/*      */       
/*      */ 
/*      */       case 68: 
/*      */       case 78: 
/* 1959 */         functionCall(_t);
/* 1960 */         _t = this._retTree;
/* 1961 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1962 */         selectExpr_AST = currentAST.root;
/* 1963 */         break;
/*      */       
/*      */ 
/*      */       case 12: 
/* 1967 */         count(_t);
/* 1968 */         _t = this._retTree;
/* 1969 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1970 */         selectExpr_AST = currentAST.root;
/* 1971 */         break;
/*      */       
/*      */ 
/*      */       case 17: 
/*      */       case 27: 
/* 1976 */         collectionFunction(_t);
/* 1977 */         _t = this._retTree;
/* 1978 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1979 */         selectExpr_AST = currentAST.root;
/* 1980 */         break;
/*      */       
/*      */ 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 117: 
/*      */       case 118: 
/* 1988 */         literal(_t);
/* 1989 */         _t = this._retTree;
/* 1990 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 1991 */         selectExpr_AST = currentAST.root;
/* 1992 */         break;
/*      */       
/*      */ 
/*      */       case 54: 
/*      */       case 71: 
/*      */       case 87: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 111: 
/*      */       case 112: 
/* 2002 */         arithmeticExpr(_t);
/* 2003 */         _t = this._retTree;
/* 2004 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2005 */         selectExpr_AST = currentAST.root;
/* 2006 */         break;
/*      */       
/*      */ 
/*      */       case 83: 
/* 2010 */         query(_t);
/* 2011 */         _t = this._retTree;
/* 2012 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2013 */         selectExpr_AST = currentAST.root;
/* 2014 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 2018 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 2023 */       reportError(ex);
/* 2024 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 2026 */     this.returnAST = selectExpr_AST;
/* 2027 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void aliasedSelectExpr(AST _t) throws RecognitionException
/*      */   {
/* 2032 */     AST aliasedSelectExpr_AST_in = _t == ASTNULL ? null : _t;
/* 2033 */     this.returnAST = null;
/* 2034 */     ASTPair currentAST = new ASTPair();
/* 2035 */     AST aliasedSelectExpr_AST = null;
/* 2036 */     AST se_AST = null;
/* 2037 */     AST se = null;
/* 2038 */     AST i_AST = null;
/* 2039 */     AST i = null;
/*      */     try
/*      */     {
/* 2042 */       AST __t53 = _t;
/* 2043 */       AST tmp23_AST = null;
/* 2044 */       AST tmp23_AST_in = null;
/* 2045 */       tmp23_AST = this.astFactory.create(_t);
/* 2046 */       tmp23_AST_in = _t;
/* 2047 */       ASTPair __currentAST53 = currentAST.copy();
/* 2048 */       currentAST.root = currentAST.child;
/* 2049 */       currentAST.child = null;
/* 2050 */       match(_t, 7);
/* 2051 */       _t = _t.getFirstChild();
/* 2052 */       se = _t == ASTNULL ? null : _t;
/* 2053 */       selectExpr(_t);
/* 2054 */       _t = this._retTree;
/* 2055 */       se_AST = this.returnAST;
/* 2056 */       i = _t == ASTNULL ? null : _t;
/* 2057 */       identifier(_t);
/* 2058 */       _t = this._retTree;
/* 2059 */       i_AST = this.returnAST;
/* 2060 */       currentAST = __currentAST53;
/* 2061 */       _t = __t53;
/* 2062 */       _t = _t.getNextSibling();
/* 2063 */       aliasedSelectExpr_AST = currentAST.root;
/*      */       
/* 2065 */       setAlias(se_AST, i_AST);
/* 2066 */       aliasedSelectExpr_AST = se_AST;
/*      */       
/* 2068 */       currentAST.root = aliasedSelectExpr_AST;
/* 2069 */       currentAST.child = ((aliasedSelectExpr_AST != null) && (aliasedSelectExpr_AST.getFirstChild() != null) ? aliasedSelectExpr_AST.getFirstChild() : aliasedSelectExpr_AST);
/*      */       
/* 2071 */       currentAST.advanceChildToEnd();
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2074 */       reportError(ex);
/* 2075 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 2077 */     this.returnAST = aliasedSelectExpr_AST;
/* 2078 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void identifier(AST _t) throws RecognitionException
/*      */   {
/* 2083 */     AST identifier_AST_in = _t == ASTNULL ? null : _t;
/* 2084 */     this.returnAST = null;
/* 2085 */     ASTPair currentAST = new ASTPair();
/* 2086 */     AST identifier_AST = null;
/*      */     
/*      */     try
/*      */     {
/* 2090 */       if (_t == null) _t = ASTNULL;
/* 2091 */       switch (_t.getType())
/*      */       {
/*      */       case 119: 
/* 2094 */         AST tmp24_AST = null;
/* 2095 */         AST tmp24_AST_in = null;
/* 2096 */         tmp24_AST = this.astFactory.create(_t);
/* 2097 */         tmp24_AST_in = _t;
/* 2098 */         this.astFactory.addASTChild(currentAST, tmp24_AST);
/* 2099 */         match(_t, 119);
/* 2100 */         _t = _t.getNextSibling();
/* 2101 */         break;
/*      */       
/*      */ 
/*      */       case 90: 
/* 2105 */         AST tmp25_AST = null;
/* 2106 */         AST tmp25_AST_in = null;
/* 2107 */         tmp25_AST = this.astFactory.create(_t);
/* 2108 */         tmp25_AST_in = _t;
/* 2109 */         this.astFactory.addASTChild(currentAST, tmp25_AST);
/* 2110 */         match(_t, 90);
/* 2111 */         _t = _t.getNextSibling();
/* 2112 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 2116 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/* 2120 */       identifier_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2123 */       reportError(ex);
/* 2124 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 2126 */     this.returnAST = identifier_AST;
/* 2127 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void aliasRef(AST _t) throws RecognitionException
/*      */   {
/* 2132 */     AST aliasRef_AST_in = _t == ASTNULL ? null : _t;
/* 2133 */     this.returnAST = null;
/* 2134 */     ASTPair currentAST = new ASTPair();
/* 2135 */     AST aliasRef_AST = null;
/* 2136 */     AST i_AST = null;
/* 2137 */     AST i = null;
/*      */     try
/*      */     {
/* 2140 */       i = _t == ASTNULL ? null : _t;
/* 2141 */       identifier(_t);
/* 2142 */       _t = this._retTree;
/* 2143 */       i_AST = this.returnAST;
/* 2144 */       aliasRef_AST = currentAST.root;
/*      */       
/* 2146 */       aliasRef_AST = this.astFactory.make(new ASTArray(1).add(this.astFactory.create(133, i.getText())));
/* 2147 */       lookupAlias(aliasRef_AST);
/*      */       
/* 2149 */       currentAST.root = aliasRef_AST;
/* 2150 */       currentAST.child = ((aliasRef_AST != null) && (aliasRef_AST.getFirstChild() != null) ? aliasRef_AST.getFirstChild() : aliasRef_AST);
/*      */       
/* 2152 */       currentAST.advanceChildToEnd();
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2155 */       reportError(ex);
/* 2156 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 2158 */     this.returnAST = aliasRef_AST;
/* 2159 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void constructor(AST _t) throws RecognitionException
/*      */   {
/* 2164 */     AST constructor_AST_in = _t == ASTNULL ? null : _t;
/* 2165 */     this.returnAST = null;
/* 2166 */     ASTPair currentAST = new ASTPair();
/* 2167 */     AST constructor_AST = null;
/* 2168 */     String className = null;
/*      */     try
/*      */     {
/* 2171 */       AST __t62 = _t;
/* 2172 */       AST tmp26_AST = null;
/* 2173 */       AST tmp26_AST_in = null;
/* 2174 */       tmp26_AST = this.astFactory.create(_t);
/* 2175 */       tmp26_AST_in = _t;
/* 2176 */       this.astFactory.addASTChild(currentAST, tmp26_AST);
/* 2177 */       ASTPair __currentAST62 = currentAST.copy();
/* 2178 */       currentAST.root = currentAST.child;
/* 2179 */       currentAST.child = null;
/* 2180 */       match(_t, 70);
/* 2181 */       _t = _t.getFirstChild();
/* 2182 */       className = path(_t);
/* 2183 */       _t = this._retTree;
/* 2184 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */       
/*      */       for (;;)
/*      */       {
/* 2188 */         if (_t == null) _t = ASTNULL;
/* 2189 */         switch (_t.getType())
/*      */         {
/*      */         case 4: 
/*      */         case 12: 
/*      */         case 15: 
/*      */         case 17: 
/*      */         case 27: 
/*      */         case 54: 
/*      */         case 65: 
/*      */         case 68: 
/*      */         case 70: 
/*      */         case 71: 
/*      */         case 78: 
/*      */         case 83: 
/*      */         case 87: 
/*      */         case 90: 
/*      */         case 92: 
/*      */         case 93: 
/*      */         case 94: 
/*      */         case 109: 
/*      */         case 110: 
/*      */         case 111: 
/*      */         case 112: 
/*      */         case 117: 
/*      */         case 118: 
/*      */         case 119: 
/* 2215 */           selectExpr(_t);
/* 2216 */           _t = this._retTree;
/* 2217 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2218 */           break;
/*      */         
/*      */ 
/*      */         case 7: 
/* 2222 */           aliasedSelectExpr(_t);
/* 2223 */           _t = this._retTree;
/* 2224 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2234 */       currentAST = __currentAST62;
/* 2235 */       _t = __t62;
/* 2236 */       _t = _t.getNextSibling();
/* 2237 */       constructor_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2240 */       reportError(ex);
/* 2241 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 2243 */     this.returnAST = constructor_AST;
/* 2244 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void functionCall(AST _t) throws RecognitionException
/*      */   {
/* 2249 */     AST functionCall_AST_in = _t == ASTNULL ? null : _t;
/* 2250 */     this.returnAST = null;
/* 2251 */     ASTPair currentAST = new ASTPair();
/* 2252 */     AST functionCall_AST = null;
/*      */     try
/*      */     {
/* 2255 */       if (_t == null) _t = ASTNULL;
/* 2256 */       switch (_t.getType())
/*      */       {
/*      */       case 78: 
/* 2259 */         AST __t157 = _t;
/* 2260 */         AST tmp27_AST = null;
/* 2261 */         AST tmp27_AST_in = null;
/* 2262 */         tmp27_AST = this.astFactory.create(_t);
/* 2263 */         tmp27_AST_in = _t;
/* 2264 */         this.astFactory.addASTChild(currentAST, tmp27_AST);
/* 2265 */         ASTPair __currentAST157 = currentAST.copy();
/* 2266 */         currentAST.root = currentAST.child;
/* 2267 */         currentAST.child = null;
/* 2268 */         match(_t, 78);
/* 2269 */         _t = _t.getFirstChild();
/* 2270 */         this.inFunctionCall = true;
/* 2271 */         pathAsIdent(_t);
/* 2272 */         _t = this._retTree;
/* 2273 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */         
/* 2275 */         if (_t == null) _t = ASTNULL;
/* 2276 */         switch (_t.getType())
/*      */         {
/*      */         case 72: 
/* 2279 */           AST __t159 = _t;
/* 2280 */           AST tmp28_AST = null;
/* 2281 */           AST tmp28_AST_in = null;
/* 2282 */           tmp28_AST = this.astFactory.create(_t);
/* 2283 */           tmp28_AST_in = _t;
/* 2284 */           this.astFactory.addASTChild(currentAST, tmp28_AST);
/* 2285 */           ASTPair __currentAST159 = currentAST.copy();
/* 2286 */           currentAST.root = currentAST.child;
/* 2287 */           currentAST.child = null;
/* 2288 */           match(_t, 72);
/* 2289 */           _t = _t.getFirstChild();
/*      */           
/*      */           for (;;)
/*      */           {
/* 2293 */             if (_t == null) _t = ASTNULL;
/* 2294 */             if (!_tokenSet_0.member(_t.getType())) break;
/* 2295 */             expr(_t);
/* 2296 */             _t = this._retTree;
/* 2297 */             this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2305 */           currentAST = __currentAST159;
/* 2306 */           _t = __t159;
/* 2307 */           _t = _t.getNextSibling();
/* 2308 */           break;
/*      */         
/*      */ 
/*      */         case 3: 
/*      */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 2316 */           throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*      */         
/* 2320 */         currentAST = __currentAST157;
/* 2321 */         _t = __t157;
/* 2322 */         _t = _t.getNextSibling();
/* 2323 */         functionCall_AST = currentAST.root;
/* 2324 */         processFunction(functionCall_AST, this.inSelect);
/* 2325 */         this.inFunctionCall = false;
/* 2326 */         functionCall_AST = currentAST.root;
/* 2327 */         break;
/*      */       
/*      */ 
/*      */       case 68: 
/* 2331 */         AST __t162 = _t;
/* 2332 */         AST tmp29_AST = null;
/* 2333 */         AST tmp29_AST_in = null;
/* 2334 */         tmp29_AST = this.astFactory.create(_t);
/* 2335 */         tmp29_AST_in = _t;
/* 2336 */         this.astFactory.addASTChild(currentAST, tmp29_AST);
/* 2337 */         ASTPair __currentAST162 = currentAST.copy();
/* 2338 */         currentAST.root = currentAST.child;
/* 2339 */         currentAST.child = null;
/* 2340 */         match(_t, 68);
/* 2341 */         _t = _t.getFirstChild();
/* 2342 */         aggregateExpr(_t);
/* 2343 */         _t = this._retTree;
/* 2344 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2345 */         currentAST = __currentAST162;
/* 2346 */         _t = __t162;
/* 2347 */         _t = _t.getNextSibling();
/* 2348 */         functionCall_AST = currentAST.root;
/* 2349 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 2353 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 2358 */       reportError(ex);
/* 2359 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 2361 */     this.returnAST = functionCall_AST;
/* 2362 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void count(AST _t) throws RecognitionException
/*      */   {
/* 2367 */     AST count_AST_in = _t == ASTNULL ? null : _t;
/* 2368 */     this.returnAST = null;
/* 2369 */     ASTPair currentAST = new ASTPair();
/* 2370 */     AST count_AST = null;
/*      */     try
/*      */     {
/* 2373 */       AST __t58 = _t;
/* 2374 */       AST tmp30_AST = null;
/* 2375 */       AST tmp30_AST_in = null;
/* 2376 */       tmp30_AST = this.astFactory.create(_t);
/* 2377 */       tmp30_AST_in = _t;
/* 2378 */       this.astFactory.addASTChild(currentAST, tmp30_AST);
/* 2379 */       ASTPair __currentAST58 = currentAST.copy();
/* 2380 */       currentAST.root = currentAST.child;
/* 2381 */       currentAST.child = null;
/* 2382 */       match(_t, 12);
/* 2383 */       _t = _t.getFirstChild();
/*      */       
/* 2385 */       if (_t == null) _t = ASTNULL;
/* 2386 */       switch (_t.getType())
/*      */       {
/*      */       case 16: 
/* 2389 */         AST tmp31_AST = null;
/* 2390 */         AST tmp31_AST_in = null;
/* 2391 */         tmp31_AST = this.astFactory.create(_t);
/* 2392 */         tmp31_AST_in = _t;
/* 2393 */         this.astFactory.addASTChild(currentAST, tmp31_AST);
/* 2394 */         match(_t, 16);
/* 2395 */         _t = _t.getNextSibling();
/* 2396 */         break;
/*      */       
/*      */ 
/*      */       case 4: 
/* 2400 */         AST tmp32_AST = null;
/* 2401 */         AST tmp32_AST_in = null;
/* 2402 */         tmp32_AST = this.astFactory.create(_t);
/* 2403 */         tmp32_AST_in = _t;
/* 2404 */         this.astFactory.addASTChild(currentAST, tmp32_AST);
/* 2405 */         match(_t, 4);
/* 2406 */         _t = _t.getNextSibling();
/* 2407 */         break;
/*      */       case 12: case 15: case 17: case 20: case 27: case 39: case 49: case 54: case 68: case 71: case 75: case 78: case 85: case 87: case 89: case 90: case 92: case 93: case 94: case 109: case 110: case 111: case 112: case 115: case 116: case 117: case 118: case 119: 
/*      */         break;
/*      */       case 5: case 6: case 7: 
/*      */       case 8: case 9: case 10: 
/*      */       case 11: case 13: case 14: 
/*      */       case 18: case 19: case 21: 
/*      */       case 22: case 23: case 24: 
/*      */       case 25: case 26: case 28: 
/*      */       case 29: case 30: case 31: 
/*      */       case 32: case 33: case 34: 
/*      */       case 35: case 36: case 37: 
/*      */       case 38: case 40: case 41: 
/*      */       case 42: case 43: case 44: 
/*      */       case 45: case 46: case 47: 
/*      */       case 48: case 50: case 51: 
/*      */       case 52: case 53: case 55: 
/*      */       case 56: case 57: case 58: 
/*      */       case 59: case 60: case 61: 
/*      */       case 62: case 63: case 64: 
/*      */       case 65: case 66: case 67: 
/*      */       case 69: case 70: case 72: 
/*      */       case 73: case 74: case 76: 
/*      */       case 77: case 79: case 80: 
/*      */       case 81: case 82: case 83: 
/*      */       case 84: case 86: case 88: 
/*      */       case 91: case 95: 
/*      */       case 96: case 97: 
/*      */       case 98: case 99: 
/*      */       case 100: case 101: 
/*      */       case 102: case 103: 
/*      */       case 104: case 105: 
/*      */       case 106: case 107: 
/*      */       case 108: case 113: 
/*      */       case 114: default: 
/* 2442 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/*      */ 
/* 2447 */       if (_t == null) _t = ASTNULL;
/* 2448 */       switch (_t.getType())
/*      */       {
/*      */       case 12: 
/*      */       case 15: 
/*      */       case 17: 
/*      */       case 20: 
/*      */       case 27: 
/*      */       case 39: 
/*      */       case 49: 
/*      */       case 54: 
/*      */       case 68: 
/*      */       case 71: 
/*      */       case 75: 
/*      */       case 78: 
/*      */       case 87: 
/*      */       case 89: 
/*      */       case 90: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 111: 
/*      */       case 112: 
/*      */       case 115: 
/*      */       case 116: 
/*      */       case 117: 
/*      */       case 118: 
/*      */       case 119: 
/* 2477 */         aggregateExpr(_t);
/* 2478 */         _t = this._retTree;
/* 2479 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2480 */         break;
/*      */       
/*      */ 
/*      */       case 85: 
/* 2484 */         AST tmp33_AST = null;
/* 2485 */         AST tmp33_AST_in = null;
/* 2486 */         tmp33_AST = this.astFactory.create(_t);
/* 2487 */         tmp33_AST_in = _t;
/* 2488 */         this.astFactory.addASTChild(currentAST, tmp33_AST);
/* 2489 */         match(_t, 85);
/* 2490 */         _t = _t.getNextSibling();
/* 2491 */         break;
/*      */       case 13: case 14: case 16: case 18: case 19: case 21: case 22: case 23: case 24: case 25: case 26: case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 40: case 41: case 42: case 43: case 44: 
/*      */       case 45: case 46: case 47: case 48: case 50: case 51: case 52: case 53: case 55: case 56: case 57: case 58: case 59: case 60: case 61: case 62: case 63: case 64: case 65: case 66: case 67: case 69: case 70: case 72: case 73: case 74: case 76: 
/*      */       case 77: case 79: case 80: case 81: case 82: case 83: case 84: case 86: case 88: case 91: case 95: case 96: case 97: case 98: case 99: case 100: case 101: case 102: case 103: case 104: case 105: case 106: case 107: case 108: case 113: case 114: default: 
/* 2495 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/* 2499 */       currentAST = __currentAST58;
/* 2500 */       _t = __t58;
/* 2501 */       _t = _t.getNextSibling();
/* 2502 */       count_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2505 */       reportError(ex);
/* 2506 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 2508 */     this.returnAST = count_AST;
/* 2509 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void collectionFunction(AST _t) throws RecognitionException
/*      */   {
/* 2514 */     AST collectionFunction_AST_in = _t == ASTNULL ? null : _t;
/* 2515 */     this.returnAST = null;
/* 2516 */     ASTPair currentAST = new ASTPair();
/* 2517 */     AST collectionFunction_AST = null;
/* 2518 */     AST e = null;
/* 2519 */     AST e_AST = null;
/* 2520 */     AST p1_AST = null;
/* 2521 */     AST p1 = null;
/* 2522 */     AST i = null;
/* 2523 */     AST i_AST = null;
/* 2524 */     AST p2_AST = null;
/* 2525 */     AST p2 = null;
/*      */     try
/*      */     {
/* 2528 */       if (_t == null) _t = ASTNULL;
/* 2529 */       switch (_t.getType())
/*      */       {
/*      */       case 17: 
/* 2532 */         AST __t154 = _t;
/* 2533 */         e = _t == ASTNULL ? null : _t;
/* 2534 */         AST e_AST_in = null;
/* 2535 */         e_AST = this.astFactory.create(e);
/* 2536 */         this.astFactory.addASTChild(currentAST, e_AST);
/* 2537 */         ASTPair __currentAST154 = currentAST.copy();
/* 2538 */         currentAST.root = currentAST.child;
/* 2539 */         currentAST.child = null;
/* 2540 */         match(_t, 17);
/* 2541 */         _t = _t.getFirstChild();
/* 2542 */         this.inFunctionCall = true;
/* 2543 */         p1 = _t == ASTNULL ? null : _t;
/* 2544 */         propertyRef(_t);
/* 2545 */         _t = this._retTree;
/* 2546 */         p1_AST = this.returnAST;
/* 2547 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2548 */         resolve(p1_AST);
/* 2549 */         currentAST = __currentAST154;
/* 2550 */         _t = __t154;
/* 2551 */         _t = _t.getNextSibling();
/* 2552 */         processFunction(e_AST, this.inSelect);
/* 2553 */         this.inFunctionCall = false;
/* 2554 */         collectionFunction_AST = currentAST.root;
/* 2555 */         break;
/*      */       
/*      */ 
/*      */       case 27: 
/* 2559 */         AST __t155 = _t;
/* 2560 */         i = _t == ASTNULL ? null : _t;
/* 2561 */         AST i_AST_in = null;
/* 2562 */         i_AST = this.astFactory.create(i);
/* 2563 */         this.astFactory.addASTChild(currentAST, i_AST);
/* 2564 */         ASTPair __currentAST155 = currentAST.copy();
/* 2565 */         currentAST.root = currentAST.child;
/* 2566 */         currentAST.child = null;
/* 2567 */         match(_t, 27);
/* 2568 */         _t = _t.getFirstChild();
/* 2569 */         this.inFunctionCall = true;
/* 2570 */         p2 = _t == ASTNULL ? null : _t;
/* 2571 */         propertyRef(_t);
/* 2572 */         _t = this._retTree;
/* 2573 */         p2_AST = this.returnAST;
/* 2574 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2575 */         resolve(p2_AST);
/* 2576 */         currentAST = __currentAST155;
/* 2577 */         _t = __t155;
/* 2578 */         _t = _t.getNextSibling();
/* 2579 */         processFunction(i_AST, this.inSelect);
/* 2580 */         this.inFunctionCall = false;
/* 2581 */         collectionFunction_AST = currentAST.root;
/* 2582 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 2586 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 2591 */       reportError(ex);
/* 2592 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 2594 */     this.returnAST = collectionFunction_AST;
/* 2595 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void literal(AST _t) throws RecognitionException
/*      */   {
/* 2600 */     AST literal_AST_in = _t == ASTNULL ? null : _t;
/* 2601 */     this.returnAST = null;
/* 2602 */     ASTPair currentAST = new ASTPair();
/* 2603 */     AST literal_AST = null;
/*      */     try
/*      */     {
/* 2606 */       if (_t == null) _t = ASTNULL;
/* 2607 */       switch (_t.getType())
/*      */       {
/*      */       case 117: 
/* 2610 */         AST tmp34_AST = null;
/* 2611 */         AST tmp34_AST_in = null;
/* 2612 */         tmp34_AST = this.astFactory.create(_t);
/* 2613 */         tmp34_AST_in = _t;
/* 2614 */         this.astFactory.addASTChild(currentAST, tmp34_AST);
/* 2615 */         match(_t, 117);
/* 2616 */         _t = _t.getNextSibling();
/* 2617 */         literal_AST = currentAST.root;
/* 2618 */         processNumericLiteral(literal_AST);
/* 2619 */         literal_AST = currentAST.root;
/* 2620 */         break;
/*      */       
/*      */ 
/*      */       case 94: 
/* 2624 */         AST tmp35_AST = null;
/* 2625 */         AST tmp35_AST_in = null;
/* 2626 */         tmp35_AST = this.astFactory.create(_t);
/* 2627 */         tmp35_AST_in = _t;
/* 2628 */         this.astFactory.addASTChild(currentAST, tmp35_AST);
/* 2629 */         match(_t, 94);
/* 2630 */         _t = _t.getNextSibling();
/* 2631 */         literal_AST = currentAST.root;
/* 2632 */         processNumericLiteral(literal_AST);
/* 2633 */         literal_AST = currentAST.root;
/* 2634 */         break;
/*      */       
/*      */ 
/*      */       case 93: 
/* 2638 */         AST tmp36_AST = null;
/* 2639 */         AST tmp36_AST_in = null;
/* 2640 */         tmp36_AST = this.astFactory.create(_t);
/* 2641 */         tmp36_AST_in = _t;
/* 2642 */         this.astFactory.addASTChild(currentAST, tmp36_AST);
/* 2643 */         match(_t, 93);
/* 2644 */         _t = _t.getNextSibling();
/* 2645 */         literal_AST = currentAST.root;
/* 2646 */         processNumericLiteral(literal_AST);
/* 2647 */         literal_AST = currentAST.root;
/* 2648 */         break;
/*      */       
/*      */ 
/*      */       case 92: 
/* 2652 */         AST tmp37_AST = null;
/* 2653 */         AST tmp37_AST_in = null;
/* 2654 */         tmp37_AST = this.astFactory.create(_t);
/* 2655 */         tmp37_AST_in = _t;
/* 2656 */         this.astFactory.addASTChild(currentAST, tmp37_AST);
/* 2657 */         match(_t, 92);
/* 2658 */         _t = _t.getNextSibling();
/* 2659 */         literal_AST = currentAST.root;
/* 2660 */         processNumericLiteral(literal_AST);
/* 2661 */         literal_AST = currentAST.root;
/* 2662 */         break;
/*      */       
/*      */ 
/*      */       case 118: 
/* 2666 */         AST tmp38_AST = null;
/* 2667 */         AST tmp38_AST_in = null;
/* 2668 */         tmp38_AST = this.astFactory.create(_t);
/* 2669 */         tmp38_AST_in = _t;
/* 2670 */         this.astFactory.addASTChild(currentAST, tmp38_AST);
/* 2671 */         match(_t, 118);
/* 2672 */         _t = _t.getNextSibling();
/* 2673 */         literal_AST = currentAST.root;
/* 2674 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 2678 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 2683 */       reportError(ex);
/* 2684 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 2686 */     this.returnAST = literal_AST;
/* 2687 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void arithmeticExpr(AST _t) throws RecognitionException
/*      */   {
/* 2692 */     AST arithmeticExpr_AST_in = _t == ASTNULL ? null : _t;
/* 2693 */     this.returnAST = null;
/* 2694 */     ASTPair currentAST = new ASTPair();
/* 2695 */     AST arithmeticExpr_AST = null;
/*      */     try
/*      */     {
/* 2698 */       if (_t == null) _t = ASTNULL;
/* 2699 */       switch (_t.getType())
/*      */       {
/*      */       case 109: 
/* 2702 */         AST __t135 = _t;
/* 2703 */         AST tmp39_AST = null;
/* 2704 */         AST tmp39_AST_in = null;
/* 2705 */         tmp39_AST = this.astFactory.create(_t);
/* 2706 */         tmp39_AST_in = _t;
/* 2707 */         this.astFactory.addASTChild(currentAST, tmp39_AST);
/* 2708 */         ASTPair __currentAST135 = currentAST.copy();
/* 2709 */         currentAST.root = currentAST.child;
/* 2710 */         currentAST.child = null;
/* 2711 */         match(_t, 109);
/* 2712 */         _t = _t.getFirstChild();
/* 2713 */         expr(_t);
/* 2714 */         _t = this._retTree;
/* 2715 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2716 */         expr(_t);
/* 2717 */         _t = this._retTree;
/* 2718 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2719 */         currentAST = __currentAST135;
/* 2720 */         _t = __t135;
/* 2721 */         _t = _t.getNextSibling();
/* 2722 */         arithmeticExpr_AST = currentAST.root;
/* 2723 */         prepareArithmeticOperator(arithmeticExpr_AST);
/* 2724 */         arithmeticExpr_AST = currentAST.root;
/* 2725 */         break;
/*      */       
/*      */ 
/*      */       case 110: 
/* 2729 */         AST __t136 = _t;
/* 2730 */         AST tmp40_AST = null;
/* 2731 */         AST tmp40_AST_in = null;
/* 2732 */         tmp40_AST = this.astFactory.create(_t);
/* 2733 */         tmp40_AST_in = _t;
/* 2734 */         this.astFactory.addASTChild(currentAST, tmp40_AST);
/* 2735 */         ASTPair __currentAST136 = currentAST.copy();
/* 2736 */         currentAST.root = currentAST.child;
/* 2737 */         currentAST.child = null;
/* 2738 */         match(_t, 110);
/* 2739 */         _t = _t.getFirstChild();
/* 2740 */         expr(_t);
/* 2741 */         _t = this._retTree;
/* 2742 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2743 */         expr(_t);
/* 2744 */         _t = this._retTree;
/* 2745 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2746 */         currentAST = __currentAST136;
/* 2747 */         _t = __t136;
/* 2748 */         _t = _t.getNextSibling();
/* 2749 */         arithmeticExpr_AST = currentAST.root;
/* 2750 */         prepareArithmeticOperator(arithmeticExpr_AST);
/* 2751 */         arithmeticExpr_AST = currentAST.root;
/* 2752 */         break;
/*      */       
/*      */ 
/*      */       case 112: 
/* 2756 */         AST __t137 = _t;
/* 2757 */         AST tmp41_AST = null;
/* 2758 */         AST tmp41_AST_in = null;
/* 2759 */         tmp41_AST = this.astFactory.create(_t);
/* 2760 */         tmp41_AST_in = _t;
/* 2761 */         this.astFactory.addASTChild(currentAST, tmp41_AST);
/* 2762 */         ASTPair __currentAST137 = currentAST.copy();
/* 2763 */         currentAST.root = currentAST.child;
/* 2764 */         currentAST.child = null;
/* 2765 */         match(_t, 112);
/* 2766 */         _t = _t.getFirstChild();
/* 2767 */         expr(_t);
/* 2768 */         _t = this._retTree;
/* 2769 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2770 */         expr(_t);
/* 2771 */         _t = this._retTree;
/* 2772 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2773 */         currentAST = __currentAST137;
/* 2774 */         _t = __t137;
/* 2775 */         _t = _t.getNextSibling();
/* 2776 */         arithmeticExpr_AST = currentAST.root;
/* 2777 */         prepareArithmeticOperator(arithmeticExpr_AST);
/* 2778 */         arithmeticExpr_AST = currentAST.root;
/* 2779 */         break;
/*      */       
/*      */ 
/*      */       case 111: 
/* 2783 */         AST __t138 = _t;
/* 2784 */         AST tmp42_AST = null;
/* 2785 */         AST tmp42_AST_in = null;
/* 2786 */         tmp42_AST = this.astFactory.create(_t);
/* 2787 */         tmp42_AST_in = _t;
/* 2788 */         this.astFactory.addASTChild(currentAST, tmp42_AST);
/* 2789 */         ASTPair __currentAST138 = currentAST.copy();
/* 2790 */         currentAST.root = currentAST.child;
/* 2791 */         currentAST.child = null;
/* 2792 */         match(_t, 111);
/* 2793 */         _t = _t.getFirstChild();
/* 2794 */         expr(_t);
/* 2795 */         _t = this._retTree;
/* 2796 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2797 */         expr(_t);
/* 2798 */         _t = this._retTree;
/* 2799 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2800 */         currentAST = __currentAST138;
/* 2801 */         _t = __t138;
/* 2802 */         _t = _t.getNextSibling();
/* 2803 */         arithmeticExpr_AST = currentAST.root;
/* 2804 */         prepareArithmeticOperator(arithmeticExpr_AST);
/* 2805 */         arithmeticExpr_AST = currentAST.root;
/* 2806 */         break;
/*      */       
/*      */ 
/*      */       case 87: 
/* 2810 */         AST __t139 = _t;
/* 2811 */         AST tmp43_AST = null;
/* 2812 */         AST tmp43_AST_in = null;
/* 2813 */         tmp43_AST = this.astFactory.create(_t);
/* 2814 */         tmp43_AST_in = _t;
/* 2815 */         this.astFactory.addASTChild(currentAST, tmp43_AST);
/* 2816 */         ASTPair __currentAST139 = currentAST.copy();
/* 2817 */         currentAST.root = currentAST.child;
/* 2818 */         currentAST.child = null;
/* 2819 */         match(_t, 87);
/* 2820 */         _t = _t.getFirstChild();
/* 2821 */         expr(_t);
/* 2822 */         _t = this._retTree;
/* 2823 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2824 */         currentAST = __currentAST139;
/* 2825 */         _t = __t139;
/* 2826 */         _t = _t.getNextSibling();
/* 2827 */         arithmeticExpr_AST = currentAST.root;
/* 2828 */         prepareArithmeticOperator(arithmeticExpr_AST);
/* 2829 */         arithmeticExpr_AST = currentAST.root;
/* 2830 */         break;
/*      */       
/*      */ 
/*      */       case 54: 
/*      */       case 71: 
/* 2835 */         caseExpr(_t);
/* 2836 */         _t = this._retTree;
/* 2837 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2838 */         arithmeticExpr_AST = currentAST.root;
/* 2839 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 2843 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 2848 */       reportError(ex);
/* 2849 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 2851 */     this.returnAST = arithmeticExpr_AST;
/* 2852 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void aggregateExpr(AST _t) throws RecognitionException
/*      */   {
/* 2857 */     AST aggregateExpr_AST_in = _t == ASTNULL ? null : _t;
/* 2858 */     this.returnAST = null;
/* 2859 */     ASTPair currentAST = new ASTPair();
/* 2860 */     AST aggregateExpr_AST = null;
/*      */     try
/*      */     {
/* 2863 */       if (_t == null) _t = ASTNULL;
/* 2864 */       switch (_t.getType())
/*      */       {
/*      */       case 12: 
/*      */       case 15: 
/*      */       case 20: 
/*      */       case 39: 
/*      */       case 49: 
/*      */       case 54: 
/*      */       case 68: 
/*      */       case 71: 
/*      */       case 75: 
/*      */       case 78: 
/*      */       case 87: 
/*      */       case 89: 
/*      */       case 90: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 111: 
/*      */       case 112: 
/*      */       case 115: 
/*      */       case 116: 
/*      */       case 117: 
/*      */       case 118: 
/*      */       case 119: 
/* 2891 */         expr(_t);
/* 2892 */         _t = this._retTree;
/* 2893 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2894 */         aggregateExpr_AST = currentAST.root;
/* 2895 */         break;
/*      */       
/*      */ 
/*      */       case 17: 
/*      */       case 27: 
/* 2900 */         collectionFunction(_t);
/* 2901 */         _t = this._retTree;
/* 2902 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 2903 */         aggregateExpr_AST = currentAST.root;
/* 2904 */         break;
/*      */       case 13: case 14: case 16: case 18: case 19: case 21: case 22: case 23: case 24: case 25: case 26: case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 40: case 41: case 42: case 43: case 44: case 45: 
/*      */       case 46: case 47: case 48: case 50: case 51: case 52: case 53: case 55: case 56: case 57: case 58: case 59: case 60: case 61: case 62: case 63: case 64: case 65: case 66: case 67: case 69: case 70: case 72: case 73: case 74: case 76: case 77: 
/*      */       case 79: case 80: case 81: case 82: case 83: case 84: case 85: case 86: case 88: case 91: case 95: case 96: case 97: case 98: case 99: case 100: case 101: case 102: case 103: case 104: case 105: case 106: case 107: case 108: case 113: case 114: default: 
/* 2908 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 2913 */       reportError(ex);
/* 2914 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 2916 */     this.returnAST = aggregateExpr_AST;
/* 2917 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void fromElementList(AST _t) throws RecognitionException
/*      */   {
/* 2922 */     AST fromElementList_AST_in = _t == ASTNULL ? null : _t;
/* 2923 */     this.returnAST = null;
/* 2924 */     ASTPair currentAST = new ASTPair();
/* 2925 */     AST fromElementList_AST = null;
/*      */     
/* 2927 */     boolean oldInFrom = this.inFrom;
/* 2928 */     this.inFrom = true;
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 2933 */       int _cnt70 = 0;
/*      */       for (;;)
/*      */       {
/* 2936 */         if (_t == null) _t = ASTNULL;
/* 2937 */         if ((_t.getType() == 32) || (_t.getType() == 73) || (_t.getType() == 84)) {
/* 2938 */           fromElement(_t);
/* 2939 */           _t = this._retTree;
/* 2940 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */         }
/*      */         else {
/* 2943 */           if (_cnt70 >= 1) break; throw new NoViableAltException(_t);
/*      */         }
/*      */         
/* 2946 */         _cnt70++;
/*      */       }
/*      */       
/*      */ 
/* 2950 */       this.inFrom = oldInFrom;
/*      */       
/* 2952 */       fromElementList_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 2955 */       reportError(ex);
/* 2956 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 2958 */     this.returnAST = fromElementList_AST;
/* 2959 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void fromElement(AST _t) throws RecognitionException
/*      */   {
/* 2964 */     AST fromElement_AST_in = _t == ASTNULL ? null : _t;
/* 2965 */     this.returnAST = null;
/* 2966 */     ASTPair currentAST = new ASTPair();
/* 2967 */     AST fromElement_AST = null;
/* 2968 */     AST a = null;
/* 2969 */     AST a_AST = null;
/* 2970 */     AST pf = null;
/* 2971 */     AST pf_AST = null;
/* 2972 */     AST je_AST = null;
/* 2973 */     AST je = null;
/* 2974 */     AST fe = null;
/* 2975 */     AST fe_AST = null;
/* 2976 */     AST a3 = null;
/* 2977 */     AST a3_AST = null;
/*      */     
/* 2979 */     String p = null;
/*      */     
/*      */     try
/*      */     {
/* 2983 */       if (_t == null) _t = ASTNULL;
/* 2984 */       switch (_t.getType())
/*      */       {
/*      */       case 84: 
/* 2987 */         AST __t72 = _t;
/* 2988 */         AST tmp44_AST = null;
/* 2989 */         AST tmp44_AST_in = null;
/* 2990 */         tmp44_AST = this.astFactory.create(_t);
/* 2991 */         tmp44_AST_in = _t;
/* 2992 */         ASTPair __currentAST72 = currentAST.copy();
/* 2993 */         currentAST.root = currentAST.child;
/* 2994 */         currentAST.child = null;
/* 2995 */         match(_t, 84);
/* 2996 */         _t = _t.getFirstChild();
/* 2997 */         p = path(_t);
/* 2998 */         _t = this._retTree;
/*      */         
/* 3000 */         if (_t == null) _t = ASTNULL;
/* 3001 */         switch (_t.getType())
/*      */         {
/*      */         case 69: 
/* 3004 */           a = _t;
/* 3005 */           AST a_AST_in = null;
/* 3006 */           a_AST = this.astFactory.create(a);
/* 3007 */           match(_t, 69);
/* 3008 */           _t = _t.getNextSibling();
/* 3009 */           break;
/*      */         
/*      */ 
/*      */         case 3: 
/*      */         case 21: 
/*      */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 3018 */           throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*      */         
/*      */ 
/* 3023 */         if (_t == null) _t = ASTNULL;
/* 3024 */         switch (_t.getType())
/*      */         {
/*      */         case 21: 
/* 3027 */           pf = _t;
/* 3028 */           AST pf_AST_in = null;
/* 3029 */           pf_AST = this.astFactory.create(pf);
/* 3030 */           match(_t, 21);
/* 3031 */           _t = _t.getNextSibling();
/* 3032 */           break;
/*      */         
/*      */ 
/*      */         case 3: 
/*      */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 3040 */           throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*      */         
/* 3044 */         currentAST = __currentAST72;
/* 3045 */         _t = __t72;
/* 3046 */         _t = _t.getNextSibling();
/* 3047 */         fromElement_AST = currentAST.root;
/*      */         
/* 3049 */         fromElement_AST = createFromElement(p, a, pf);
/*      */         
/* 3051 */         currentAST.root = fromElement_AST;
/* 3052 */         currentAST.child = ((fromElement_AST != null) && (fromElement_AST.getFirstChild() != null) ? fromElement_AST.getFirstChild() : fromElement_AST);
/*      */         
/* 3054 */         currentAST.advanceChildToEnd();
/* 3055 */         break;
/*      */       
/*      */ 
/*      */       case 32: 
/* 3059 */         je = _t == ASTNULL ? null : _t;
/* 3060 */         joinElement(_t);
/* 3061 */         _t = this._retTree;
/* 3062 */         je_AST = this.returnAST;
/* 3063 */         fromElement_AST = currentAST.root;
/*      */         
/* 3065 */         fromElement_AST = je_AST;
/*      */         
/* 3067 */         currentAST.root = fromElement_AST;
/* 3068 */         currentAST.child = ((fromElement_AST != null) && (fromElement_AST.getFirstChild() != null) ? fromElement_AST.getFirstChild() : fromElement_AST);
/*      */         
/* 3070 */         currentAST.advanceChildToEnd();
/* 3071 */         break;
/*      */       
/*      */ 
/*      */       case 73: 
/* 3075 */         fe = _t;
/* 3076 */         AST fe_AST_in = null;
/* 3077 */         fe_AST = this.astFactory.create(fe);
/* 3078 */         match(_t, 73);
/* 3079 */         _t = _t.getNextSibling();
/* 3080 */         a3 = _t;
/* 3081 */         AST a3_AST_in = null;
/* 3082 */         a3_AST = this.astFactory.create(a3);
/* 3083 */         match(_t, 69);
/* 3084 */         _t = _t.getNextSibling();
/* 3085 */         fromElement_AST = currentAST.root;
/*      */         
/* 3087 */         fromElement_AST = createFromFilterElement(fe, a3);
/*      */         
/* 3089 */         currentAST.root = fromElement_AST;
/* 3090 */         currentAST.child = ((fromElement_AST != null) && (fromElement_AST.getFirstChild() != null) ? fromElement_AST.getFirstChild() : fromElement_AST);
/*      */         
/* 3092 */         currentAST.advanceChildToEnd();
/* 3093 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 3097 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 3102 */       reportError(ex);
/* 3103 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 3105 */     this.returnAST = fromElement_AST;
/* 3106 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void joinElement(AST _t) throws RecognitionException
/*      */   {
/* 3111 */     AST joinElement_AST_in = _t == ASTNULL ? null : _t;
/* 3112 */     this.returnAST = null;
/* 3113 */     ASTPair currentAST = new ASTPair();
/* 3114 */     AST joinElement_AST = null;
/* 3115 */     AST f = null;
/* 3116 */     AST f_AST = null;
/* 3117 */     AST ref_AST = null;
/* 3118 */     AST ref = null;
/* 3119 */     AST a = null;
/* 3120 */     AST a_AST = null;
/* 3121 */     AST pf = null;
/* 3122 */     AST pf_AST = null;
/* 3123 */     AST with = null;
/* 3124 */     AST with_AST = null;
/*      */     
/* 3126 */     int j = 28;
/*      */     
/*      */     try
/*      */     {
/* 3130 */       AST __t76 = _t;
/* 3131 */       AST tmp45_AST = null;
/* 3132 */       AST tmp45_AST_in = null;
/* 3133 */       tmp45_AST = this.astFactory.create(_t);
/* 3134 */       tmp45_AST_in = _t;
/* 3135 */       ASTPair __currentAST76 = currentAST.copy();
/* 3136 */       currentAST.root = currentAST.child;
/* 3137 */       currentAST.child = null;
/* 3138 */       match(_t, 32);
/* 3139 */       _t = _t.getFirstChild();
/*      */       
/* 3141 */       if (_t == null) _t = ASTNULL;
/* 3142 */       switch (_t.getType())
/*      */       {
/*      */       case 23: 
/*      */       case 28: 
/*      */       case 33: 
/*      */       case 44: 
/* 3148 */         j = joinType(_t);
/* 3149 */         _t = this._retTree;
/* 3150 */         setImpliedJoinType(j);
/* 3151 */         break;
/*      */       
/*      */ 
/*      */       case 15: 
/*      */       case 21: 
/*      */       case 90: 
/*      */       case 119: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 3162 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/*      */ 
/* 3167 */       if (_t == null) _t = ASTNULL;
/* 3168 */       switch (_t.getType())
/*      */       {
/*      */       case 21: 
/* 3171 */         f = _t;
/* 3172 */         AST f_AST_in = null;
/* 3173 */         f_AST = this.astFactory.create(f);
/* 3174 */         match(_t, 21);
/* 3175 */         _t = _t.getNextSibling();
/* 3176 */         break;
/*      */       
/*      */ 
/*      */       case 15: 
/*      */       case 90: 
/*      */       case 119: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 3186 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/* 3190 */       ref = _t == ASTNULL ? null : _t;
/* 3191 */       propertyRef(_t);
/* 3192 */       _t = this._retTree;
/* 3193 */       ref_AST = this.returnAST;
/*      */       
/* 3195 */       if (_t == null) _t = ASTNULL;
/* 3196 */       switch (_t.getType())
/*      */       {
/*      */       case 69: 
/* 3199 */         a = _t;
/* 3200 */         AST a_AST_in = null;
/* 3201 */         a_AST = this.astFactory.create(a);
/* 3202 */         match(_t, 69);
/* 3203 */         _t = _t.getNextSibling();
/* 3204 */         break;
/*      */       
/*      */ 
/*      */       case 3: 
/*      */       case 21: 
/*      */       case 60: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 3214 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/*      */ 
/* 3219 */       if (_t == null) _t = ASTNULL;
/* 3220 */       switch (_t.getType())
/*      */       {
/*      */       case 21: 
/* 3223 */         pf = _t;
/* 3224 */         AST pf_AST_in = null;
/* 3225 */         pf_AST = this.astFactory.create(pf);
/* 3226 */         match(_t, 21);
/* 3227 */         _t = _t.getNextSibling();
/* 3228 */         break;
/*      */       
/*      */ 
/*      */       case 3: 
/*      */       case 60: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 3237 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/*      */ 
/* 3242 */       if (_t == null) _t = ASTNULL;
/* 3243 */       switch (_t.getType())
/*      */       {
/*      */       case 60: 
/* 3246 */         with = _t;
/* 3247 */         AST with_AST_in = null;
/* 3248 */         with_AST = this.astFactory.create(with);
/* 3249 */         match(_t, 60);
/* 3250 */         _t = _t.getNextSibling();
/* 3251 */         break;
/*      */       
/*      */ 
/*      */       case 3: 
/*      */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 3259 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/* 3263 */       currentAST = __currentAST76;
/* 3264 */       _t = __t76;
/* 3265 */       _t = _t.getNextSibling();
/*      */       
/*      */ 
/* 3268 */       createFromJoinElement(ref_AST, a, j, f, pf, with);
/* 3269 */       setImpliedJoinType(28);
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 3273 */       reportError(ex);
/* 3274 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 3276 */     this.returnAST = joinElement_AST;
/* 3277 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final int joinType(AST _t)
/*      */     throws RecognitionException
/*      */   {
/* 3283 */     AST joinType_AST_in = _t == ASTNULL ? null : _t;
/* 3284 */     this.returnAST = null;
/* 3285 */     ASTPair currentAST = new ASTPair();
/* 3286 */     AST joinType_AST = null;
/* 3287 */     AST left = null;
/* 3288 */     AST left_AST = null;
/* 3289 */     AST right = null;
/* 3290 */     AST right_AST = null;
/* 3291 */     AST outer = null;
/* 3292 */     AST outer_AST = null;
/*      */     
/* 3294 */     int j = 28;
/*      */     
/*      */     try
/*      */     {
/* 3298 */       if (_t == null) _t = ASTNULL;
/* 3299 */       switch (_t.getType())
/*      */       {
/*      */ 
/*      */ 
/*      */       case 33: 
/*      */       case 44: 
/* 3305 */         if (_t == null) _t = ASTNULL;
/* 3306 */         switch (_t.getType())
/*      */         {
/*      */         case 33: 
/* 3309 */           left = _t;
/* 3310 */           AST left_AST_in = null;
/* 3311 */           left_AST = this.astFactory.create(left);
/* 3312 */           this.astFactory.addASTChild(currentAST, left_AST);
/* 3313 */           match(_t, 33);
/* 3314 */           _t = _t.getNextSibling();
/* 3315 */           break;
/*      */         
/*      */ 
/*      */         case 44: 
/* 3319 */           right = _t;
/* 3320 */           AST right_AST_in = null;
/* 3321 */           right_AST = this.astFactory.create(right);
/* 3322 */           this.astFactory.addASTChild(currentAST, right_AST);
/* 3323 */           match(_t, 44);
/* 3324 */           _t = _t.getNextSibling();
/* 3325 */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 3329 */           throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*      */         
/*      */ 
/* 3334 */         if (_t == null) _t = ASTNULL;
/* 3335 */         switch (_t.getType())
/*      */         {
/*      */         case 42: 
/* 3338 */           outer = _t;
/* 3339 */           AST outer_AST_in = null;
/* 3340 */           outer_AST = this.astFactory.create(outer);
/* 3341 */           this.astFactory.addASTChild(currentAST, outer_AST);
/* 3342 */           match(_t, 42);
/* 3343 */           _t = _t.getNextSibling();
/* 3344 */           break;
/*      */         
/*      */ 
/*      */         case 15: 
/*      */         case 21: 
/*      */         case 90: 
/*      */         case 119: 
/*      */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 3355 */           throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*      */         
/*      */ 
/*      */ 
/* 3361 */         if (left != null) { j = 131;
/* 3362 */         } else if (right != null) { j = 132;
/* 3363 */         } else if (outer != null) { j = 132;
/*      */         }
/* 3365 */         joinType_AST = currentAST.root;
/* 3366 */         break;
/*      */       
/*      */ 
/*      */       case 23: 
/* 3370 */         AST tmp46_AST = null;
/* 3371 */         AST tmp46_AST_in = null;
/* 3372 */         tmp46_AST = this.astFactory.create(_t);
/* 3373 */         tmp46_AST_in = _t;
/* 3374 */         this.astFactory.addASTChild(currentAST, tmp46_AST);
/* 3375 */         match(_t, 23);
/* 3376 */         _t = _t.getNextSibling();
/*      */         
/* 3378 */         j = 23;
/*      */         
/* 3380 */         joinType_AST = currentAST.root;
/* 3381 */         break;
/*      */       
/*      */ 
/*      */       case 28: 
/* 3385 */         AST tmp47_AST = null;
/* 3386 */         AST tmp47_AST_in = null;
/* 3387 */         tmp47_AST = this.astFactory.create(_t);
/* 3388 */         tmp47_AST_in = _t;
/* 3389 */         this.astFactory.addASTChild(currentAST, tmp47_AST);
/* 3390 */         match(_t, 28);
/* 3391 */         _t = _t.getNextSibling();
/*      */         
/* 3393 */         j = 28;
/*      */         
/* 3395 */         joinType_AST = currentAST.root;
/* 3396 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 3400 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 3405 */       reportError(ex);
/* 3406 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 3408 */     this.returnAST = joinType_AST;
/* 3409 */     this._retTree = _t;
/* 3410 */     return j;
/*      */   }
/*      */   
/*      */   public final void pathAsIdent(AST _t) throws RecognitionException
/*      */   {
/* 3415 */     AST pathAsIdent_AST_in = _t == ASTNULL ? null : _t;
/* 3416 */     this.returnAST = null;
/* 3417 */     ASTPair currentAST = new ASTPair();
/* 3418 */     AST pathAsIdent_AST = null;
/*      */     
/* 3420 */     String text = "?text?";
/*      */     
/*      */     try
/*      */     {
/* 3424 */       text = path(_t);
/* 3425 */       _t = this._retTree;
/* 3426 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3427 */       pathAsIdent_AST = currentAST.root;
/*      */       
/* 3429 */       pathAsIdent_AST = this.astFactory.make(new ASTArray(1).add(this.astFactory.create(119, text)));
/*      */       
/* 3431 */       currentAST.root = pathAsIdent_AST;
/* 3432 */       currentAST.child = ((pathAsIdent_AST != null) && (pathAsIdent_AST.getFirstChild() != null) ? pathAsIdent_AST.getFirstChild() : pathAsIdent_AST);
/*      */       
/* 3434 */       currentAST.advanceChildToEnd();
/* 3435 */       pathAsIdent_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 3438 */       reportError(ex);
/* 3439 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 3441 */     this.returnAST = pathAsIdent_AST;
/* 3442 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void withClause(AST _t) throws RecognitionException
/*      */   {
/* 3447 */     AST withClause_AST_in = _t == ASTNULL ? null : _t;
/* 3448 */     this.returnAST = null;
/* 3449 */     ASTPair currentAST = new ASTPair();
/* 3450 */     AST withClause_AST = null;
/* 3451 */     AST w = null;
/* 3452 */     AST w_AST = null;
/* 3453 */     AST b_AST = null;
/* 3454 */     AST b = null;
/*      */     try
/*      */     {
/* 3457 */       AST __t90 = _t;
/* 3458 */       w = _t == ASTNULL ? null : _t;
/* 3459 */       AST w_AST_in = null;
/* 3460 */       w_AST = this.astFactory.create(w);
/* 3461 */       this.astFactory.addASTChild(currentAST, w_AST);
/* 3462 */       ASTPair __currentAST90 = currentAST.copy();
/* 3463 */       currentAST.root = currentAST.child;
/* 3464 */       currentAST.child = null;
/* 3465 */       match(_t, 60);
/* 3466 */       _t = _t.getFirstChild();
/* 3467 */       handleClauseStart(60);
/* 3468 */       b = _t == ASTNULL ? null : _t;
/* 3469 */       logicalExpr(_t);
/* 3470 */       _t = this._retTree;
/* 3471 */       b_AST = this.returnAST;
/* 3472 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3473 */       currentAST = __currentAST90;
/* 3474 */       _t = __t90;
/* 3475 */       _t = _t.getNextSibling();
/* 3476 */       withClause_AST = currentAST.root;
/*      */       
/* 3478 */       withClause_AST = this.astFactory.make(new ASTArray(2).add(w_AST).add(b_AST));
/*      */       
/* 3480 */       currentAST.root = withClause_AST;
/* 3481 */       currentAST.child = ((withClause_AST != null) && (withClause_AST.getFirstChild() != null) ? withClause_AST.getFirstChild() : withClause_AST);
/*      */       
/* 3483 */       currentAST.advanceChildToEnd();
/* 3484 */       withClause_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 3487 */       reportError(ex);
/* 3488 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 3490 */     this.returnAST = withClause_AST;
/* 3491 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void comparisonExpr(AST _t) throws RecognitionException
/*      */   {
/* 3496 */     AST comparisonExpr_AST_in = _t == ASTNULL ? null : _t;
/* 3497 */     this.returnAST = null;
/* 3498 */     ASTPair currentAST = new ASTPair();
/* 3499 */     AST comparisonExpr_AST = null;
/*      */     
/*      */     try
/*      */     {
/* 3503 */       if (_t == null) _t = ASTNULL;
/* 3504 */       switch (_t.getType())
/*      */       {
/*      */       case 96: 
/* 3507 */         AST __t99 = _t;
/* 3508 */         AST tmp48_AST = null;
/* 3509 */         AST tmp48_AST_in = null;
/* 3510 */         tmp48_AST = this.astFactory.create(_t);
/* 3511 */         tmp48_AST_in = _t;
/* 3512 */         this.astFactory.addASTChild(currentAST, tmp48_AST);
/* 3513 */         ASTPair __currentAST99 = currentAST.copy();
/* 3514 */         currentAST.root = currentAST.child;
/* 3515 */         currentAST.child = null;
/* 3516 */         match(_t, 96);
/* 3517 */         _t = _t.getFirstChild();
/* 3518 */         exprOrSubquery(_t);
/* 3519 */         _t = this._retTree;
/* 3520 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3521 */         exprOrSubquery(_t);
/* 3522 */         _t = this._retTree;
/* 3523 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3524 */         currentAST = __currentAST99;
/* 3525 */         _t = __t99;
/* 3526 */         _t = _t.getNextSibling();
/* 3527 */         break;
/*      */       
/*      */ 
/*      */       case 102: 
/* 3531 */         AST __t100 = _t;
/* 3532 */         AST tmp49_AST = null;
/* 3533 */         AST tmp49_AST_in = null;
/* 3534 */         tmp49_AST = this.astFactory.create(_t);
/* 3535 */         tmp49_AST_in = _t;
/* 3536 */         this.astFactory.addASTChild(currentAST, tmp49_AST);
/* 3537 */         ASTPair __currentAST100 = currentAST.copy();
/* 3538 */         currentAST.root = currentAST.child;
/* 3539 */         currentAST.child = null;
/* 3540 */         match(_t, 102);
/* 3541 */         _t = _t.getFirstChild();
/* 3542 */         exprOrSubquery(_t);
/* 3543 */         _t = this._retTree;
/* 3544 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3545 */         exprOrSubquery(_t);
/* 3546 */         _t = this._retTree;
/* 3547 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3548 */         currentAST = __currentAST100;
/* 3549 */         _t = __t100;
/* 3550 */         _t = _t.getNextSibling();
/* 3551 */         break;
/*      */       
/*      */ 
/*      */       case 104: 
/* 3555 */         AST __t101 = _t;
/* 3556 */         AST tmp50_AST = null;
/* 3557 */         AST tmp50_AST_in = null;
/* 3558 */         tmp50_AST = this.astFactory.create(_t);
/* 3559 */         tmp50_AST_in = _t;
/* 3560 */         this.astFactory.addASTChild(currentAST, tmp50_AST);
/* 3561 */         ASTPair __currentAST101 = currentAST.copy();
/* 3562 */         currentAST.root = currentAST.child;
/* 3563 */         currentAST.child = null;
/* 3564 */         match(_t, 104);
/* 3565 */         _t = _t.getFirstChild();
/* 3566 */         exprOrSubquery(_t);
/* 3567 */         _t = this._retTree;
/* 3568 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3569 */         exprOrSubquery(_t);
/* 3570 */         _t = this._retTree;
/* 3571 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3572 */         currentAST = __currentAST101;
/* 3573 */         _t = __t101;
/* 3574 */         _t = _t.getNextSibling();
/* 3575 */         break;
/*      */       
/*      */ 
/*      */       case 105: 
/* 3579 */         AST __t102 = _t;
/* 3580 */         AST tmp51_AST = null;
/* 3581 */         AST tmp51_AST_in = null;
/* 3582 */         tmp51_AST = this.astFactory.create(_t);
/* 3583 */         tmp51_AST_in = _t;
/* 3584 */         this.astFactory.addASTChild(currentAST, tmp51_AST);
/* 3585 */         ASTPair __currentAST102 = currentAST.copy();
/* 3586 */         currentAST.root = currentAST.child;
/* 3587 */         currentAST.child = null;
/* 3588 */         match(_t, 105);
/* 3589 */         _t = _t.getFirstChild();
/* 3590 */         exprOrSubquery(_t);
/* 3591 */         _t = this._retTree;
/* 3592 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3593 */         exprOrSubquery(_t);
/* 3594 */         _t = this._retTree;
/* 3595 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3596 */         currentAST = __currentAST102;
/* 3597 */         _t = __t102;
/* 3598 */         _t = _t.getNextSibling();
/* 3599 */         break;
/*      */       
/*      */ 
/*      */       case 106: 
/* 3603 */         AST __t103 = _t;
/* 3604 */         AST tmp52_AST = null;
/* 3605 */         AST tmp52_AST_in = null;
/* 3606 */         tmp52_AST = this.astFactory.create(_t);
/* 3607 */         tmp52_AST_in = _t;
/* 3608 */         this.astFactory.addASTChild(currentAST, tmp52_AST);
/* 3609 */         ASTPair __currentAST103 = currentAST.copy();
/* 3610 */         currentAST.root = currentAST.child;
/* 3611 */         currentAST.child = null;
/* 3612 */         match(_t, 106);
/* 3613 */         _t = _t.getFirstChild();
/* 3614 */         exprOrSubquery(_t);
/* 3615 */         _t = this._retTree;
/* 3616 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3617 */         exprOrSubquery(_t);
/* 3618 */         _t = this._retTree;
/* 3619 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3620 */         currentAST = __currentAST103;
/* 3621 */         _t = __t103;
/* 3622 */         _t = _t.getNextSibling();
/* 3623 */         break;
/*      */       
/*      */ 
/*      */       case 107: 
/* 3627 */         AST __t104 = _t;
/* 3628 */         AST tmp53_AST = null;
/* 3629 */         AST tmp53_AST_in = null;
/* 3630 */         tmp53_AST = this.astFactory.create(_t);
/* 3631 */         tmp53_AST_in = _t;
/* 3632 */         this.astFactory.addASTChild(currentAST, tmp53_AST);
/* 3633 */         ASTPair __currentAST104 = currentAST.copy();
/* 3634 */         currentAST.root = currentAST.child;
/* 3635 */         currentAST.child = null;
/* 3636 */         match(_t, 107);
/* 3637 */         _t = _t.getFirstChild();
/* 3638 */         exprOrSubquery(_t);
/* 3639 */         _t = this._retTree;
/* 3640 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3641 */         exprOrSubquery(_t);
/* 3642 */         _t = this._retTree;
/* 3643 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3644 */         currentAST = __currentAST104;
/* 3645 */         _t = __t104;
/* 3646 */         _t = _t.getNextSibling();
/* 3647 */         break;
/*      */       
/*      */ 
/*      */       case 34: 
/* 3651 */         AST __t105 = _t;
/* 3652 */         AST tmp54_AST = null;
/* 3653 */         AST tmp54_AST_in = null;
/* 3654 */         tmp54_AST = this.astFactory.create(_t);
/* 3655 */         tmp54_AST_in = _t;
/* 3656 */         this.astFactory.addASTChild(currentAST, tmp54_AST);
/* 3657 */         ASTPair __currentAST105 = currentAST.copy();
/* 3658 */         currentAST.root = currentAST.child;
/* 3659 */         currentAST.child = null;
/* 3660 */         match(_t, 34);
/* 3661 */         _t = _t.getFirstChild();
/* 3662 */         exprOrSubquery(_t);
/* 3663 */         _t = this._retTree;
/* 3664 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3665 */         expr(_t);
/* 3666 */         _t = this._retTree;
/* 3667 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */         
/* 3669 */         if (_t == null) _t = ASTNULL;
/* 3670 */         switch (_t.getType())
/*      */         {
/*      */         case 18: 
/* 3673 */           AST __t107 = _t;
/* 3674 */           AST tmp55_AST = null;
/* 3675 */           AST tmp55_AST_in = null;
/* 3676 */           tmp55_AST = this.astFactory.create(_t);
/* 3677 */           tmp55_AST_in = _t;
/* 3678 */           this.astFactory.addASTChild(currentAST, tmp55_AST);
/* 3679 */           ASTPair __currentAST107 = currentAST.copy();
/* 3680 */           currentAST.root = currentAST.child;
/* 3681 */           currentAST.child = null;
/* 3682 */           match(_t, 18);
/* 3683 */           _t = _t.getFirstChild();
/* 3684 */           expr(_t);
/* 3685 */           _t = this._retTree;
/* 3686 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3687 */           currentAST = __currentAST107;
/* 3688 */           _t = __t107;
/* 3689 */           _t = _t.getNextSibling();
/* 3690 */           break;
/*      */         
/*      */ 
/*      */         case 3: 
/*      */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 3698 */           throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*      */         
/* 3702 */         currentAST = __currentAST105;
/* 3703 */         _t = __t105;
/* 3704 */         _t = _t.getNextSibling();
/* 3705 */         break;
/*      */       
/*      */ 
/*      */       case 81: 
/* 3709 */         AST __t108 = _t;
/* 3710 */         AST tmp56_AST = null;
/* 3711 */         AST tmp56_AST_in = null;
/* 3712 */         tmp56_AST = this.astFactory.create(_t);
/* 3713 */         tmp56_AST_in = _t;
/* 3714 */         this.astFactory.addASTChild(currentAST, tmp56_AST);
/* 3715 */         ASTPair __currentAST108 = currentAST.copy();
/* 3716 */         currentAST.root = currentAST.child;
/* 3717 */         currentAST.child = null;
/* 3718 */         match(_t, 81);
/* 3719 */         _t = _t.getFirstChild();
/* 3720 */         exprOrSubquery(_t);
/* 3721 */         _t = this._retTree;
/* 3722 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3723 */         expr(_t);
/* 3724 */         _t = this._retTree;
/* 3725 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */         
/* 3727 */         if (_t == null) _t = ASTNULL;
/* 3728 */         switch (_t.getType())
/*      */         {
/*      */         case 18: 
/* 3731 */           AST __t110 = _t;
/* 3732 */           AST tmp57_AST = null;
/* 3733 */           AST tmp57_AST_in = null;
/* 3734 */           tmp57_AST = this.astFactory.create(_t);
/* 3735 */           tmp57_AST_in = _t;
/* 3736 */           this.astFactory.addASTChild(currentAST, tmp57_AST);
/* 3737 */           ASTPair __currentAST110 = currentAST.copy();
/* 3738 */           currentAST.root = currentAST.child;
/* 3739 */           currentAST.child = null;
/* 3740 */           match(_t, 18);
/* 3741 */           _t = _t.getFirstChild();
/* 3742 */           expr(_t);
/* 3743 */           _t = this._retTree;
/* 3744 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3745 */           currentAST = __currentAST110;
/* 3746 */           _t = __t110;
/* 3747 */           _t = _t.getNextSibling();
/* 3748 */           break;
/*      */         
/*      */ 
/*      */         case 3: 
/*      */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 3756 */           throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*      */         
/* 3760 */         currentAST = __currentAST108;
/* 3761 */         _t = __t108;
/* 3762 */         _t = _t.getNextSibling();
/* 3763 */         break;
/*      */       
/*      */ 
/*      */       case 10: 
/* 3767 */         AST __t111 = _t;
/* 3768 */         AST tmp58_AST = null;
/* 3769 */         AST tmp58_AST_in = null;
/* 3770 */         tmp58_AST = this.astFactory.create(_t);
/* 3771 */         tmp58_AST_in = _t;
/* 3772 */         this.astFactory.addASTChild(currentAST, tmp58_AST);
/* 3773 */         ASTPair __currentAST111 = currentAST.copy();
/* 3774 */         currentAST.root = currentAST.child;
/* 3775 */         currentAST.child = null;
/* 3776 */         match(_t, 10);
/* 3777 */         _t = _t.getFirstChild();
/* 3778 */         exprOrSubquery(_t);
/* 3779 */         _t = this._retTree;
/* 3780 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3781 */         exprOrSubquery(_t);
/* 3782 */         _t = this._retTree;
/* 3783 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3784 */         exprOrSubquery(_t);
/* 3785 */         _t = this._retTree;
/* 3786 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3787 */         currentAST = __currentAST111;
/* 3788 */         _t = __t111;
/* 3789 */         _t = _t.getNextSibling();
/* 3790 */         break;
/*      */       
/*      */ 
/*      */       case 79: 
/* 3794 */         AST __t112 = _t;
/* 3795 */         AST tmp59_AST = null;
/* 3796 */         AST tmp59_AST_in = null;
/* 3797 */         tmp59_AST = this.astFactory.create(_t);
/* 3798 */         tmp59_AST_in = _t;
/* 3799 */         this.astFactory.addASTChild(currentAST, tmp59_AST);
/* 3800 */         ASTPair __currentAST112 = currentAST.copy();
/* 3801 */         currentAST.root = currentAST.child;
/* 3802 */         currentAST.child = null;
/* 3803 */         match(_t, 79);
/* 3804 */         _t = _t.getFirstChild();
/* 3805 */         exprOrSubquery(_t);
/* 3806 */         _t = this._retTree;
/* 3807 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3808 */         exprOrSubquery(_t);
/* 3809 */         _t = this._retTree;
/* 3810 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3811 */         exprOrSubquery(_t);
/* 3812 */         _t = this._retTree;
/* 3813 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3814 */         currentAST = __currentAST112;
/* 3815 */         _t = __t112;
/* 3816 */         _t = _t.getNextSibling();
/* 3817 */         break;
/*      */       
/*      */ 
/*      */       case 26: 
/* 3821 */         AST __t113 = _t;
/* 3822 */         AST tmp60_AST = null;
/* 3823 */         AST tmp60_AST_in = null;
/* 3824 */         tmp60_AST = this.astFactory.create(_t);
/* 3825 */         tmp60_AST_in = _t;
/* 3826 */         this.astFactory.addASTChild(currentAST, tmp60_AST);
/* 3827 */         ASTPair __currentAST113 = currentAST.copy();
/* 3828 */         currentAST.root = currentAST.child;
/* 3829 */         currentAST.child = null;
/* 3830 */         match(_t, 26);
/* 3831 */         _t = _t.getFirstChild();
/* 3832 */         exprOrSubquery(_t);
/* 3833 */         _t = this._retTree;
/* 3834 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3835 */         inRhs(_t);
/* 3836 */         _t = this._retTree;
/* 3837 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3838 */         currentAST = __currentAST113;
/* 3839 */         _t = __t113;
/* 3840 */         _t = _t.getNextSibling();
/* 3841 */         break;
/*      */       
/*      */ 
/*      */       case 80: 
/* 3845 */         AST __t114 = _t;
/* 3846 */         AST tmp61_AST = null;
/* 3847 */         AST tmp61_AST_in = null;
/* 3848 */         tmp61_AST = this.astFactory.create(_t);
/* 3849 */         tmp61_AST_in = _t;
/* 3850 */         this.astFactory.addASTChild(currentAST, tmp61_AST);
/* 3851 */         ASTPair __currentAST114 = currentAST.copy();
/* 3852 */         currentAST.root = currentAST.child;
/* 3853 */         currentAST.child = null;
/* 3854 */         match(_t, 80);
/* 3855 */         _t = _t.getFirstChild();
/* 3856 */         exprOrSubquery(_t);
/* 3857 */         _t = this._retTree;
/* 3858 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3859 */         inRhs(_t);
/* 3860 */         _t = this._retTree;
/* 3861 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3862 */         currentAST = __currentAST114;
/* 3863 */         _t = __t114;
/* 3864 */         _t = _t.getNextSibling();
/* 3865 */         break;
/*      */       
/*      */ 
/*      */       case 77: 
/* 3869 */         AST __t115 = _t;
/* 3870 */         AST tmp62_AST = null;
/* 3871 */         AST tmp62_AST_in = null;
/* 3872 */         tmp62_AST = this.astFactory.create(_t);
/* 3873 */         tmp62_AST_in = _t;
/* 3874 */         this.astFactory.addASTChild(currentAST, tmp62_AST);
/* 3875 */         ASTPair __currentAST115 = currentAST.copy();
/* 3876 */         currentAST.root = currentAST.child;
/* 3877 */         currentAST.child = null;
/* 3878 */         match(_t, 77);
/* 3879 */         _t = _t.getFirstChild();
/* 3880 */         exprOrSubquery(_t);
/* 3881 */         _t = this._retTree;
/* 3882 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3883 */         currentAST = __currentAST115;
/* 3884 */         _t = __t115;
/* 3885 */         _t = _t.getNextSibling();
/* 3886 */         break;
/*      */       
/*      */ 
/*      */       case 76: 
/* 3890 */         AST __t116 = _t;
/* 3891 */         AST tmp63_AST = null;
/* 3892 */         AST tmp63_AST_in = null;
/* 3893 */         tmp63_AST = this.astFactory.create(_t);
/* 3894 */         tmp63_AST_in = _t;
/* 3895 */         this.astFactory.addASTChild(currentAST, tmp63_AST);
/* 3896 */         ASTPair __currentAST116 = currentAST.copy();
/* 3897 */         currentAST.root = currentAST.child;
/* 3898 */         currentAST.child = null;
/* 3899 */         match(_t, 76);
/* 3900 */         _t = _t.getFirstChild();
/* 3901 */         exprOrSubquery(_t);
/* 3902 */         _t = this._retTree;
/* 3903 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3904 */         currentAST = __currentAST116;
/* 3905 */         _t = __t116;
/* 3906 */         _t = _t.getNextSibling();
/* 3907 */         break;
/*      */       
/*      */ 
/*      */       case 19: 
/* 3911 */         AST __t117 = _t;
/* 3912 */         AST tmp64_AST = null;
/* 3913 */         AST tmp64_AST_in = null;
/* 3914 */         tmp64_AST = this.astFactory.create(_t);
/* 3915 */         tmp64_AST_in = _t;
/* 3916 */         this.astFactory.addASTChild(currentAST, tmp64_AST);
/* 3917 */         ASTPair __currentAST117 = currentAST.copy();
/* 3918 */         currentAST.root = currentAST.child;
/* 3919 */         currentAST.child = null;
/* 3920 */         match(_t, 19);
/* 3921 */         _t = _t.getFirstChild();
/*      */         
/* 3923 */         if (_t == null) _t = ASTNULL;
/* 3924 */         switch (_t.getType())
/*      */         {
/*      */         case 12: 
/*      */         case 15: 
/*      */         case 20: 
/*      */         case 39: 
/*      */         case 49: 
/*      */         case 54: 
/*      */         case 68: 
/*      */         case 71: 
/*      */         case 75: 
/*      */         case 78: 
/*      */         case 87: 
/*      */         case 89: 
/*      */         case 90: 
/*      */         case 92: 
/*      */         case 93: 
/*      */         case 94: 
/*      */         case 109: 
/*      */         case 110: 
/*      */         case 111: 
/*      */         case 112: 
/*      */         case 115: 
/*      */         case 116: 
/*      */         case 117: 
/*      */         case 118: 
/*      */         case 119: 
/* 3951 */           expr(_t);
/* 3952 */           _t = this._retTree;
/* 3953 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3954 */           break;
/*      */         
/*      */ 
/*      */         case 17: 
/*      */         case 27: 
/*      */         case 83: 
/* 3960 */           collectionFunctionOrSubselect(_t);
/* 3961 */           _t = this._retTree;
/* 3962 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/* 3963 */           break;
/*      */         case 13: case 14: case 16: case 18: case 19: case 21: case 22: case 23: case 24: case 25: case 26: case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 40: case 41: case 42: case 43: case 44: 
/*      */         case 45: case 46: case 47: case 48: case 50: case 51: case 52: case 53: case 55: case 56: case 57: case 58: case 59: case 60: case 61: case 62: case 63: case 64: case 65: case 66: case 67: case 69: case 70: case 72: case 73: case 74: case 76: 
/*      */         case 77: case 79: case 80: case 81: case 82: case 84: case 85: case 86: case 88: case 91: case 95: case 96: case 97: case 98: case 99: case 100: case 101: case 102: case 103: case 104: case 105: case 106: case 107: case 108: case 113: case 114: default: 
/* 3967 */           throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*      */         
/* 3971 */         currentAST = __currentAST117;
/* 3972 */         _t = __t117;
/* 3973 */         _t = _t.getNextSibling();
/* 3974 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 3978 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/* 3982 */       comparisonExpr_AST = currentAST.root;
/*      */       
/* 3984 */       prepareLogicOperator(comparisonExpr_AST);
/*      */       
/* 3986 */       comparisonExpr_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 3989 */       reportError(ex);
/* 3990 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 3992 */     this.returnAST = comparisonExpr_AST;
/* 3993 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void exprOrSubquery(AST _t) throws RecognitionException
/*      */   {
/* 3998 */     AST exprOrSubquery_AST_in = _t == ASTNULL ? null : _t;
/* 3999 */     this.returnAST = null;
/* 4000 */     ASTPair currentAST = new ASTPair();
/* 4001 */     AST exprOrSubquery_AST = null;
/*      */     try
/*      */     {
/* 4004 */       if (_t == null) _t = ASTNULL;
/* 4005 */       switch (_t.getType())
/*      */       {
/*      */       case 12: 
/*      */       case 15: 
/*      */       case 20: 
/*      */       case 39: 
/*      */       case 49: 
/*      */       case 54: 
/*      */       case 68: 
/*      */       case 71: 
/*      */       case 75: 
/*      */       case 78: 
/*      */       case 87: 
/*      */       case 89: 
/*      */       case 90: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 111: 
/*      */       case 112: 
/*      */       case 115: 
/*      */       case 116: 
/*      */       case 117: 
/*      */       case 118: 
/*      */       case 119: 
/* 4032 */         expr(_t);
/* 4033 */         _t = this._retTree;
/* 4034 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4035 */         exprOrSubquery_AST = currentAST.root;
/* 4036 */         break;
/*      */       
/*      */ 
/*      */       case 83: 
/* 4040 */         query(_t);
/* 4041 */         _t = this._retTree;
/* 4042 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4043 */         exprOrSubquery_AST = currentAST.root;
/* 4044 */         break;
/*      */       
/*      */ 
/*      */       case 5: 
/* 4048 */         AST __t126 = _t;
/* 4049 */         AST tmp65_AST = null;
/* 4050 */         AST tmp65_AST_in = null;
/* 4051 */         tmp65_AST = this.astFactory.create(_t);
/* 4052 */         tmp65_AST_in = _t;
/* 4053 */         this.astFactory.addASTChild(currentAST, tmp65_AST);
/* 4054 */         ASTPair __currentAST126 = currentAST.copy();
/* 4055 */         currentAST.root = currentAST.child;
/* 4056 */         currentAST.child = null;
/* 4057 */         match(_t, 5);
/* 4058 */         _t = _t.getFirstChild();
/* 4059 */         collectionFunctionOrSubselect(_t);
/* 4060 */         _t = this._retTree;
/* 4061 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4062 */         currentAST = __currentAST126;
/* 4063 */         _t = __t126;
/* 4064 */         _t = _t.getNextSibling();
/* 4065 */         exprOrSubquery_AST = currentAST.root;
/* 4066 */         break;
/*      */       
/*      */ 
/*      */       case 4: 
/* 4070 */         AST __t127 = _t;
/* 4071 */         AST tmp66_AST = null;
/* 4072 */         AST tmp66_AST_in = null;
/* 4073 */         tmp66_AST = this.astFactory.create(_t);
/* 4074 */         tmp66_AST_in = _t;
/* 4075 */         this.astFactory.addASTChild(currentAST, tmp66_AST);
/* 4076 */         ASTPair __currentAST127 = currentAST.copy();
/* 4077 */         currentAST.root = currentAST.child;
/* 4078 */         currentAST.child = null;
/* 4079 */         match(_t, 4);
/* 4080 */         _t = _t.getFirstChild();
/* 4081 */         collectionFunctionOrSubselect(_t);
/* 4082 */         _t = this._retTree;
/* 4083 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4084 */         currentAST = __currentAST127;
/* 4085 */         _t = __t127;
/* 4086 */         _t = _t.getNextSibling();
/* 4087 */         exprOrSubquery_AST = currentAST.root;
/* 4088 */         break;
/*      */       
/*      */ 
/*      */       case 47: 
/* 4092 */         AST __t128 = _t;
/* 4093 */         AST tmp67_AST = null;
/* 4094 */         AST tmp67_AST_in = null;
/* 4095 */         tmp67_AST = this.astFactory.create(_t);
/* 4096 */         tmp67_AST_in = _t;
/* 4097 */         this.astFactory.addASTChild(currentAST, tmp67_AST);
/* 4098 */         ASTPair __currentAST128 = currentAST.copy();
/* 4099 */         currentAST.root = currentAST.child;
/* 4100 */         currentAST.child = null;
/* 4101 */         match(_t, 47);
/* 4102 */         _t = _t.getFirstChild();
/* 4103 */         collectionFunctionOrSubselect(_t);
/* 4104 */         _t = this._retTree;
/* 4105 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4106 */         currentAST = __currentAST128;
/* 4107 */         _t = __t128;
/* 4108 */         _t = _t.getNextSibling();
/* 4109 */         exprOrSubquery_AST = currentAST.root;
/* 4110 */         break;
/*      */       case 6: case 7: case 8: case 9: case 10: case 11: case 13: case 14: case 16: case 17: case 18: case 19: case 21: case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: 
/*      */       case 40: case 41: case 42: case 43: case 44: case 45: case 46: case 48: case 50: case 51: case 52: case 53: case 55: case 56: case 57: case 58: case 59: case 60: case 61: case 62: case 63: case 64: case 65: case 66: case 67: case 69: case 70: case 72: case 73: 
/*      */       case 74: case 76: case 77: case 79: case 80: case 81: case 82: case 84: case 85: case 86: case 88: case 91: case 95: case 96: case 97: case 98: case 99: case 100: case 101: case 102: case 103: case 104: case 105: case 106: case 107: case 108: case 113: case 114: default: 
/* 4114 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 4119 */       reportError(ex);
/* 4120 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 4122 */     this.returnAST = exprOrSubquery_AST;
/* 4123 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void inRhs(AST _t) throws RecognitionException
/*      */   {
/* 4128 */     AST inRhs_AST_in = _t == ASTNULL ? null : _t;
/* 4129 */     this.returnAST = null;
/* 4130 */     ASTPair currentAST = new ASTPair();
/* 4131 */     AST inRhs_AST = null;
/*      */     try
/*      */     {
/* 4134 */       AST __t120 = _t;
/* 4135 */       AST tmp68_AST = null;
/* 4136 */       AST tmp68_AST_in = null;
/* 4137 */       tmp68_AST = this.astFactory.create(_t);
/* 4138 */       tmp68_AST_in = _t;
/* 4139 */       this.astFactory.addASTChild(currentAST, tmp68_AST);
/* 4140 */       ASTPair __currentAST120 = currentAST.copy();
/* 4141 */       currentAST.root = currentAST.child;
/* 4142 */       currentAST.child = null;
/* 4143 */       match(_t, 74);
/* 4144 */       _t = _t.getFirstChild();
/*      */       
/* 4146 */       if (_t == null) _t = ASTNULL;
/* 4147 */       switch (_t.getType())
/*      */       {
/*      */       case 17: 
/*      */       case 27: 
/*      */       case 83: 
/* 4152 */         collectionFunctionOrSubselect(_t);
/* 4153 */         _t = this._retTree;
/* 4154 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4155 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       case 3: 
/*      */       case 12: 
/*      */       case 15: 
/*      */       case 20: 
/*      */       case 39: 
/*      */       case 49: 
/*      */       case 54: 
/*      */       case 68: 
/*      */       case 71: 
/*      */       case 75: 
/*      */       case 78: 
/*      */       case 87: 
/*      */       case 89: 
/*      */       case 90: 
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 109: 
/*      */       case 110: 
/*      */       case 111: 
/*      */       case 112: 
/*      */       case 115: 
/*      */       case 116: 
/*      */       case 117: 
/*      */       case 118: 
/*      */       case 119: 
/*      */         for (;;)
/*      */         {
/* 4188 */           if (_t == null) _t = ASTNULL;
/* 4189 */           if (!_tokenSet_0.member(_t.getType())) break;
/* 4190 */           expr(_t);
/* 4191 */           _t = this._retTree;
/* 4192 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */         }
/*      */       case 4: case 5: case 6: case 7: case 8: case 9: case 10: case 11: case 13: 
/*      */       case 14: case 16: case 18: case 19: case 21: case 22: case 23: case 24: 
/*      */       case 25: case 26: case 28: case 29: case 30: case 31: case 32: case 33: 
/*      */       case 34: case 35: case 36: case 37: case 38: case 40: case 41: case 42: 
/*      */       case 43: case 44: case 45: case 46: case 47: case 48: case 50: case 51: 
/*      */       case 52: case 53: case 55: case 56: case 57: case 58: case 59: case 60: 
/*      */       case 61: case 62: case 63: case 64: case 65: case 66: case 67: case 69: 
/*      */       case 70: case 72: case 73: case 74: case 76: case 77: case 79: case 80: 
/*      */       case 81: case 82: case 84: case 85: case 86: case 88: case 91: case 95: 
/*      */       case 96: case 97: case 98: case 99: case 100: case 101: case 102: case 103: 
/*      */       case 104: case 105: case 106: case 107: case 108: case 113: case 114: default: 
/* 4205 */         throw new NoViableAltException(_t);
/*      */       }
/*      */       
/*      */       
/* 4209 */       currentAST = __currentAST120;
/* 4210 */       _t = __t120;
/* 4211 */       _t = _t.getNextSibling();
/* 4212 */       inRhs_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 4215 */       reportError(ex);
/* 4216 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 4218 */     this.returnAST = inRhs_AST;
/* 4219 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void collectionFunctionOrSubselect(AST _t) throws RecognitionException
/*      */   {
/* 4224 */     AST collectionFunctionOrSubselect_AST_in = _t == ASTNULL ? null : _t;
/* 4225 */     this.returnAST = null;
/* 4226 */     ASTPair currentAST = new ASTPair();
/* 4227 */     AST collectionFunctionOrSubselect_AST = null;
/*      */     try
/*      */     {
/* 4230 */       if (_t == null) _t = ASTNULL;
/* 4231 */       switch (_t.getType())
/*      */       {
/*      */       case 17: 
/*      */       case 27: 
/* 4235 */         collectionFunction(_t);
/* 4236 */         _t = this._retTree;
/* 4237 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4238 */         collectionFunctionOrSubselect_AST = currentAST.root;
/* 4239 */         break;
/*      */       
/*      */ 
/*      */       case 83: 
/* 4243 */         query(_t);
/* 4244 */         _t = this._retTree;
/* 4245 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4246 */         collectionFunctionOrSubselect_AST = currentAST.root;
/* 4247 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 4251 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 4256 */       reportError(ex);
/* 4257 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 4259 */     this.returnAST = collectionFunctionOrSubselect_AST;
/* 4260 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */ 
/*      */   public final void addrExpr(AST _t, boolean root)
/*      */     throws RecognitionException
/*      */   {
/* 4267 */     AST addrExpr_AST_in = _t == ASTNULL ? null : _t;
/* 4268 */     this.returnAST = null;
/* 4269 */     ASTPair currentAST = new ASTPair();
/* 4270 */     AST addrExpr_AST = null;
/* 4271 */     AST d = null;
/* 4272 */     AST d_AST = null;
/* 4273 */     AST lhs_AST = null;
/* 4274 */     AST lhs = null;
/* 4275 */     AST rhs_AST = null;
/* 4276 */     AST rhs = null;
/* 4277 */     AST i = null;
/* 4278 */     AST i_AST = null;
/* 4279 */     AST lhs2_AST = null;
/* 4280 */     AST lhs2 = null;
/* 4281 */     AST rhs2_AST = null;
/* 4282 */     AST rhs2 = null;
/* 4283 */     AST p_AST = null;
/* 4284 */     AST p = null;
/*      */     try
/*      */     {
/* 4287 */       if (_t == null) _t = ASTNULL;
/* 4288 */       switch (_t.getType())
/*      */       {
/*      */       case 15: 
/* 4291 */         AST __t168 = _t;
/* 4292 */         d = _t == ASTNULL ? null : _t;
/* 4293 */         AST d_AST_in = null;
/* 4294 */         d_AST = this.astFactory.create(d);
/* 4295 */         ASTPair __currentAST168 = currentAST.copy();
/* 4296 */         currentAST.root = currentAST.child;
/* 4297 */         currentAST.child = null;
/* 4298 */         match(_t, 15);
/* 4299 */         _t = _t.getFirstChild();
/* 4300 */         lhs = _t == ASTNULL ? null : _t;
/* 4301 */         addrExprLhs(_t);
/* 4302 */         _t = this._retTree;
/* 4303 */         lhs_AST = this.returnAST;
/* 4304 */         rhs = _t == ASTNULL ? null : _t;
/* 4305 */         propertyName(_t);
/* 4306 */         _t = this._retTree;
/* 4307 */         rhs_AST = this.returnAST;
/* 4308 */         currentAST = __currentAST168;
/* 4309 */         _t = __t168;
/* 4310 */         _t = _t.getNextSibling();
/* 4311 */         addrExpr_AST = currentAST.root;
/*      */         
/*      */ 
/*      */ 
/* 4315 */         addrExpr_AST = this.astFactory.make(new ASTArray(3).add(d_AST).add(lhs_AST).add(rhs_AST));
/* 4316 */         addrExpr_AST = lookupProperty(addrExpr_AST, root, false);
/*      */         
/* 4318 */         currentAST.root = addrExpr_AST;
/* 4319 */         currentAST.child = ((addrExpr_AST != null) && (addrExpr_AST.getFirstChild() != null) ? addrExpr_AST.getFirstChild() : addrExpr_AST);
/*      */         
/* 4321 */         currentAST.advanceChildToEnd();
/* 4322 */         break;
/*      */       
/*      */ 
/*      */       case 75: 
/* 4326 */         AST __t169 = _t;
/* 4327 */         i = _t == ASTNULL ? null : _t;
/* 4328 */         AST i_AST_in = null;
/* 4329 */         i_AST = this.astFactory.create(i);
/* 4330 */         ASTPair __currentAST169 = currentAST.copy();
/* 4331 */         currentAST.root = currentAST.child;
/* 4332 */         currentAST.child = null;
/* 4333 */         match(_t, 75);
/* 4334 */         _t = _t.getFirstChild();
/* 4335 */         lhs2 = _t == ASTNULL ? null : _t;
/* 4336 */         addrExprLhs(_t);
/* 4337 */         _t = this._retTree;
/* 4338 */         lhs2_AST = this.returnAST;
/* 4339 */         rhs2 = _t == ASTNULL ? null : _t;
/* 4340 */         expr(_t);
/* 4341 */         _t = this._retTree;
/* 4342 */         rhs2_AST = this.returnAST;
/* 4343 */         currentAST = __currentAST169;
/* 4344 */         _t = __t169;
/* 4345 */         _t = _t.getNextSibling();
/* 4346 */         addrExpr_AST = currentAST.root;
/*      */         
/* 4348 */         addrExpr_AST = this.astFactory.make(new ASTArray(3).add(i_AST).add(lhs2_AST).add(rhs2_AST));
/* 4349 */         processIndex(addrExpr_AST);
/*      */         
/* 4351 */         currentAST.root = addrExpr_AST;
/* 4352 */         currentAST.child = ((addrExpr_AST != null) && (addrExpr_AST.getFirstChild() != null) ? addrExpr_AST.getFirstChild() : addrExpr_AST);
/*      */         
/* 4354 */         currentAST.advanceChildToEnd();
/* 4355 */         break;
/*      */       
/*      */ 
/*      */       case 90: 
/*      */       case 119: 
/* 4360 */         p = _t == ASTNULL ? null : _t;
/* 4361 */         identifier(_t);
/* 4362 */         _t = this._retTree;
/* 4363 */         p_AST = this.returnAST;
/* 4364 */         addrExpr_AST = currentAST.root;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4372 */         if (isNonQualifiedPropertyRef(p_AST)) {
/* 4373 */           addrExpr_AST = lookupNonQualifiedProperty(p_AST);
/*      */         }
/*      */         else {
/* 4376 */           resolve(p_AST);
/* 4377 */           addrExpr_AST = p_AST;
/*      */         }
/*      */         
/* 4380 */         currentAST.root = addrExpr_AST;
/* 4381 */         currentAST.child = ((addrExpr_AST != null) && (addrExpr_AST.getFirstChild() != null) ? addrExpr_AST.getFirstChild() : addrExpr_AST);
/*      */         
/* 4383 */         currentAST.advanceChildToEnd();
/* 4384 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 4388 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 4393 */       reportError(ex);
/* 4394 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 4396 */     this.returnAST = addrExpr_AST;
/* 4397 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void constant(AST _t) throws RecognitionException
/*      */   {
/* 4402 */     AST constant_AST_in = _t == ASTNULL ? null : _t;
/* 4403 */     this.returnAST = null;
/* 4404 */     ASTPair currentAST = new ASTPair();
/* 4405 */     AST constant_AST = null;
/*      */     try
/*      */     {
/* 4408 */       if (_t == null) _t = ASTNULL;
/* 4409 */       switch (_t.getType())
/*      */       {
/*      */       case 92: 
/*      */       case 93: 
/*      */       case 94: 
/*      */       case 117: 
/*      */       case 118: 
/* 4416 */         literal(_t);
/* 4417 */         _t = this._retTree;
/* 4418 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4419 */         constant_AST = currentAST.root;
/* 4420 */         break;
/*      */       
/*      */ 
/*      */       case 39: 
/* 4424 */         AST tmp69_AST = null;
/* 4425 */         AST tmp69_AST_in = null;
/* 4426 */         tmp69_AST = this.astFactory.create(_t);
/* 4427 */         tmp69_AST_in = _t;
/* 4428 */         this.astFactory.addASTChild(currentAST, tmp69_AST);
/* 4429 */         match(_t, 39);
/* 4430 */         _t = _t.getNextSibling();
/* 4431 */         constant_AST = currentAST.root;
/* 4432 */         break;
/*      */       
/*      */ 
/*      */       case 49: 
/* 4436 */         AST tmp70_AST = null;
/* 4437 */         AST tmp70_AST_in = null;
/* 4438 */         tmp70_AST = this.astFactory.create(_t);
/* 4439 */         tmp70_AST_in = _t;
/* 4440 */         this.astFactory.addASTChild(currentAST, tmp70_AST);
/* 4441 */         match(_t, 49);
/* 4442 */         _t = _t.getNextSibling();
/* 4443 */         constant_AST = currentAST.root;
/* 4444 */         processBoolean(constant_AST);
/* 4445 */         constant_AST = currentAST.root;
/* 4446 */         break;
/*      */       
/*      */ 
/*      */       case 20: 
/* 4450 */         AST tmp71_AST = null;
/* 4451 */         AST tmp71_AST_in = null;
/* 4452 */         tmp71_AST = this.astFactory.create(_t);
/* 4453 */         tmp71_AST_in = _t;
/* 4454 */         this.astFactory.addASTChild(currentAST, tmp71_AST);
/* 4455 */         match(_t, 20);
/* 4456 */         _t = _t.getNextSibling();
/* 4457 */         constant_AST = currentAST.root;
/* 4458 */         processBoolean(constant_AST);
/* 4459 */         constant_AST = currentAST.root;
/* 4460 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 4464 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 4469 */       reportError(ex);
/* 4470 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 4472 */     this.returnAST = constant_AST;
/* 4473 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void parameter(AST _t) throws RecognitionException
/*      */   {
/* 4478 */     AST parameter_AST_in = _t == ASTNULL ? null : _t;
/* 4479 */     this.returnAST = null;
/* 4480 */     ASTPair currentAST = new ASTPair();
/* 4481 */     AST parameter_AST = null;
/* 4482 */     AST c = null;
/* 4483 */     AST c_AST = null;
/* 4484 */     AST a_AST = null;
/* 4485 */     AST a = null;
/* 4486 */     AST p = null;
/* 4487 */     AST p_AST = null;
/* 4488 */     AST n = null;
/* 4489 */     AST n_AST = null;
/*      */     try
/*      */     {
/* 4492 */       if (_t == null) _t = ASTNULL;
/* 4493 */       switch (_t.getType())
/*      */       {
/*      */       case 115: 
/* 4496 */         AST __t177 = _t;
/* 4497 */         c = _t == ASTNULL ? null : _t;
/* 4498 */         AST c_AST_in = null;
/* 4499 */         c_AST = this.astFactory.create(c);
/* 4500 */         ASTPair __currentAST177 = currentAST.copy();
/* 4501 */         currentAST.root = currentAST.child;
/* 4502 */         currentAST.child = null;
/* 4503 */         match(_t, 115);
/* 4504 */         _t = _t.getFirstChild();
/* 4505 */         a = _t == ASTNULL ? null : _t;
/* 4506 */         identifier(_t);
/* 4507 */         _t = this._retTree;
/* 4508 */         a_AST = this.returnAST;
/* 4509 */         currentAST = __currentAST177;
/* 4510 */         _t = __t177;
/* 4511 */         _t = _t.getNextSibling();
/* 4512 */         parameter_AST = currentAST.root;
/*      */         
/*      */ 
/* 4515 */         parameter_AST = generateNamedParameter(c, a);
/*      */         
/*      */ 
/*      */ 
/* 4519 */         currentAST.root = parameter_AST;
/* 4520 */         currentAST.child = ((parameter_AST != null) && (parameter_AST.getFirstChild() != null) ? parameter_AST.getFirstChild() : parameter_AST);
/*      */         
/* 4522 */         currentAST.advanceChildToEnd();
/* 4523 */         break;
/*      */       
/*      */ 
/*      */       case 116: 
/* 4527 */         AST __t178 = _t;
/* 4528 */         p = _t == ASTNULL ? null : _t;
/* 4529 */         AST p_AST_in = null;
/* 4530 */         p_AST = this.astFactory.create(p);
/* 4531 */         ASTPair __currentAST178 = currentAST.copy();
/* 4532 */         currentAST.root = currentAST.child;
/* 4533 */         currentAST.child = null;
/* 4534 */         match(_t, 116);
/* 4535 */         _t = _t.getFirstChild();
/*      */         
/* 4537 */         if (_t == null) _t = ASTNULL;
/* 4538 */         switch (_t.getType())
/*      */         {
/*      */         case 117: 
/* 4541 */           n = _t;
/* 4542 */           AST n_AST_in = null;
/* 4543 */           n_AST = this.astFactory.create(n);
/* 4544 */           match(_t, 117);
/* 4545 */           _t = _t.getNextSibling();
/* 4546 */           break;
/*      */         
/*      */ 
/*      */         case 3: 
/*      */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 4554 */           throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*      */         
/* 4558 */         currentAST = __currentAST178;
/* 4559 */         _t = __t178;
/* 4560 */         _t = _t.getNextSibling();
/* 4561 */         parameter_AST = currentAST.root;
/*      */         
/* 4563 */         if (n != null)
/*      */         {
/* 4565 */           parameter_AST = generateNamedParameter(p, n);
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 4570 */           parameter_AST = generatePositionalParameter(p);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 4575 */         currentAST.root = parameter_AST;
/* 4576 */         currentAST.child = ((parameter_AST != null) && (parameter_AST.getFirstChild() != null) ? parameter_AST.getFirstChild() : parameter_AST);
/*      */         
/* 4578 */         currentAST.advanceChildToEnd();
/* 4579 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 4583 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 4588 */       reportError(ex);
/* 4589 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 4591 */     this.returnAST = parameter_AST;
/* 4592 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void caseExpr(AST _t) throws RecognitionException
/*      */   {
/* 4597 */     AST caseExpr_AST_in = _t == ASTNULL ? null : _t;
/* 4598 */     this.returnAST = null;
/* 4599 */     ASTPair currentAST = new ASTPair();
/* 4600 */     AST caseExpr_AST = null;
/*      */     try
/*      */     {
/* 4603 */       if (_t == null) _t = ASTNULL;
/* 4604 */       switch (_t.getType())
/*      */       {
/*      */       case 54: 
/* 4607 */         AST __t141 = _t;
/* 4608 */         AST tmp72_AST = null;
/* 4609 */         AST tmp72_AST_in = null;
/* 4610 */         tmp72_AST = this.astFactory.create(_t);
/* 4611 */         tmp72_AST_in = _t;
/* 4612 */         this.astFactory.addASTChild(currentAST, tmp72_AST);
/* 4613 */         ASTPair __currentAST141 = currentAST.copy();
/* 4614 */         currentAST.root = currentAST.child;
/* 4615 */         currentAST.child = null;
/* 4616 */         match(_t, 54);
/* 4617 */         _t = _t.getFirstChild();
/* 4618 */         this.inCase = true;
/*      */         
/* 4620 */         int _cnt144 = 0;
/*      */         for (;;)
/*      */         {
/* 4623 */           if (_t == null) _t = ASTNULL;
/* 4624 */           if (_t.getType() == 58) {
/* 4625 */             AST __t143 = _t;
/* 4626 */             AST tmp73_AST = null;
/* 4627 */             AST tmp73_AST_in = null;
/* 4628 */             tmp73_AST = this.astFactory.create(_t);
/* 4629 */             tmp73_AST_in = _t;
/* 4630 */             this.astFactory.addASTChild(currentAST, tmp73_AST);
/* 4631 */             ASTPair __currentAST143 = currentAST.copy();
/* 4632 */             currentAST.root = currentAST.child;
/* 4633 */             currentAST.child = null;
/* 4634 */             match(_t, 58);
/* 4635 */             _t = _t.getFirstChild();
/* 4636 */             logicalExpr(_t);
/* 4637 */             _t = this._retTree;
/* 4638 */             this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4639 */             expr(_t);
/* 4640 */             _t = this._retTree;
/* 4641 */             this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4642 */             currentAST = __currentAST143;
/* 4643 */             _t = __t143;
/* 4644 */             _t = _t.getNextSibling();
/*      */           }
/*      */           else {
/* 4647 */             if (_cnt144 >= 1) break; throw new NoViableAltException(_t);
/*      */           }
/*      */           
/* 4650 */           _cnt144++;
/*      */         }
/*      */         
/*      */ 
/* 4654 */         if (_t == null) _t = ASTNULL;
/* 4655 */         switch (_t.getType())
/*      */         {
/*      */         case 56: 
/* 4658 */           AST __t146 = _t;
/* 4659 */           AST tmp74_AST = null;
/* 4660 */           AST tmp74_AST_in = null;
/* 4661 */           tmp74_AST = this.astFactory.create(_t);
/* 4662 */           tmp74_AST_in = _t;
/* 4663 */           this.astFactory.addASTChild(currentAST, tmp74_AST);
/* 4664 */           ASTPair __currentAST146 = currentAST.copy();
/* 4665 */           currentAST.root = currentAST.child;
/* 4666 */           currentAST.child = null;
/* 4667 */           match(_t, 56);
/* 4668 */           _t = _t.getFirstChild();
/* 4669 */           expr(_t);
/* 4670 */           _t = this._retTree;
/* 4671 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4672 */           currentAST = __currentAST146;
/* 4673 */           _t = __t146;
/* 4674 */           _t = _t.getNextSibling();
/* 4675 */           break;
/*      */         
/*      */ 
/*      */         case 3: 
/*      */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 4683 */           throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*      */         
/* 4687 */         currentAST = __currentAST141;
/* 4688 */         _t = __t141;
/* 4689 */         _t = _t.getNextSibling();
/* 4690 */         this.inCase = false;
/* 4691 */         caseExpr_AST = currentAST.root;
/* 4692 */         break;
/*      */       
/*      */ 
/*      */       case 71: 
/* 4696 */         AST __t147 = _t;
/* 4697 */         AST tmp75_AST = null;
/* 4698 */         AST tmp75_AST_in = null;
/* 4699 */         tmp75_AST = this.astFactory.create(_t);
/* 4700 */         tmp75_AST_in = _t;
/* 4701 */         this.astFactory.addASTChild(currentAST, tmp75_AST);
/* 4702 */         ASTPair __currentAST147 = currentAST.copy();
/* 4703 */         currentAST.root = currentAST.child;
/* 4704 */         currentAST.child = null;
/* 4705 */         match(_t, 71);
/* 4706 */         _t = _t.getFirstChild();
/* 4707 */         this.inCase = true;
/* 4708 */         expr(_t);
/* 4709 */         _t = this._retTree;
/* 4710 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/*      */         
/* 4712 */         int _cnt150 = 0;
/*      */         for (;;)
/*      */         {
/* 4715 */           if (_t == null) _t = ASTNULL;
/* 4716 */           if (_t.getType() == 58) {
/* 4717 */             AST __t149 = _t;
/* 4718 */             AST tmp76_AST = null;
/* 4719 */             AST tmp76_AST_in = null;
/* 4720 */             tmp76_AST = this.astFactory.create(_t);
/* 4721 */             tmp76_AST_in = _t;
/* 4722 */             this.astFactory.addASTChild(currentAST, tmp76_AST);
/* 4723 */             ASTPair __currentAST149 = currentAST.copy();
/* 4724 */             currentAST.root = currentAST.child;
/* 4725 */             currentAST.child = null;
/* 4726 */             match(_t, 58);
/* 4727 */             _t = _t.getFirstChild();
/* 4728 */             expr(_t);
/* 4729 */             _t = this._retTree;
/* 4730 */             this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4731 */             expr(_t);
/* 4732 */             _t = this._retTree;
/* 4733 */             this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4734 */             currentAST = __currentAST149;
/* 4735 */             _t = __t149;
/* 4736 */             _t = _t.getNextSibling();
/*      */           }
/*      */           else {
/* 4739 */             if (_cnt150 >= 1) break; throw new NoViableAltException(_t);
/*      */           }
/*      */           
/* 4742 */           _cnt150++;
/*      */         }
/*      */         
/*      */ 
/* 4746 */         if (_t == null) _t = ASTNULL;
/* 4747 */         switch (_t.getType())
/*      */         {
/*      */         case 56: 
/* 4750 */           AST __t152 = _t;
/* 4751 */           AST tmp77_AST = null;
/* 4752 */           AST tmp77_AST_in = null;
/* 4753 */           tmp77_AST = this.astFactory.create(_t);
/* 4754 */           tmp77_AST_in = _t;
/* 4755 */           this.astFactory.addASTChild(currentAST, tmp77_AST);
/* 4756 */           ASTPair __currentAST152 = currentAST.copy();
/* 4757 */           currentAST.root = currentAST.child;
/* 4758 */           currentAST.child = null;
/* 4759 */           match(_t, 56);
/* 4760 */           _t = _t.getFirstChild();
/* 4761 */           expr(_t);
/* 4762 */           _t = this._retTree;
/* 4763 */           this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4764 */           currentAST = __currentAST152;
/* 4765 */           _t = __t152;
/* 4766 */           _t = _t.getNextSibling();
/* 4767 */           break;
/*      */         
/*      */ 
/*      */         case 3: 
/*      */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 4775 */           throw new NoViableAltException(_t);
/*      */         }
/*      */         
/*      */         
/* 4779 */         currentAST = __currentAST147;
/* 4780 */         _t = __t147;
/* 4781 */         _t = _t.getNextSibling();
/* 4782 */         this.inCase = false;
/* 4783 */         caseExpr_AST = currentAST.root;
/* 4784 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 4788 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 4793 */       reportError(ex);
/* 4794 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 4796 */     this.returnAST = caseExpr_AST;
/* 4797 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void addrExprLhs(AST _t) throws RecognitionException
/*      */   {
/* 4802 */     AST addrExprLhs_AST_in = _t == ASTNULL ? null : _t;
/* 4803 */     this.returnAST = null;
/* 4804 */     ASTPair currentAST = new ASTPair();
/* 4805 */     AST addrExprLhs_AST = null;
/*      */     try
/*      */     {
/* 4808 */       addrExpr(_t, false);
/* 4809 */       _t = this._retTree;
/* 4810 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4811 */       addrExprLhs_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 4814 */       reportError(ex);
/* 4815 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 4817 */     this.returnAST = addrExprLhs_AST;
/* 4818 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void propertyName(AST _t) throws RecognitionException
/*      */   {
/* 4823 */     AST propertyName_AST_in = _t == ASTNULL ? null : _t;
/* 4824 */     this.returnAST = null;
/* 4825 */     ASTPair currentAST = new ASTPair();
/* 4826 */     AST propertyName_AST = null;
/*      */     try
/*      */     {
/* 4829 */       if (_t == null) _t = ASTNULL;
/* 4830 */       switch (_t.getType())
/*      */       {
/*      */       case 90: 
/*      */       case 119: 
/* 4834 */         identifier(_t);
/* 4835 */         _t = this._retTree;
/* 4836 */         this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4837 */         propertyName_AST = currentAST.root;
/* 4838 */         break;
/*      */       
/*      */ 
/*      */       case 11: 
/* 4842 */         AST tmp78_AST = null;
/* 4843 */         AST tmp78_AST_in = null;
/* 4844 */         tmp78_AST = this.astFactory.create(_t);
/* 4845 */         tmp78_AST_in = _t;
/* 4846 */         this.astFactory.addASTChild(currentAST, tmp78_AST);
/* 4847 */         match(_t, 11);
/* 4848 */         _t = _t.getNextSibling();
/* 4849 */         propertyName_AST = currentAST.root;
/* 4850 */         break;
/*      */       
/*      */ 
/*      */       case 17: 
/* 4854 */         AST tmp79_AST = null;
/* 4855 */         AST tmp79_AST_in = null;
/* 4856 */         tmp79_AST = this.astFactory.create(_t);
/* 4857 */         tmp79_AST_in = _t;
/* 4858 */         this.astFactory.addASTChild(currentAST, tmp79_AST);
/* 4859 */         match(_t, 17);
/* 4860 */         _t = _t.getNextSibling();
/* 4861 */         propertyName_AST = currentAST.root;
/* 4862 */         break;
/*      */       
/*      */ 
/*      */       case 27: 
/* 4866 */         AST tmp80_AST = null;
/* 4867 */         AST tmp80_AST_in = null;
/* 4868 */         tmp80_AST = this.astFactory.create(_t);
/* 4869 */         tmp80_AST_in = _t;
/* 4870 */         this.astFactory.addASTChild(currentAST, tmp80_AST);
/* 4871 */         match(_t, 27);
/* 4872 */         _t = _t.getNextSibling();
/* 4873 */         propertyName_AST = currentAST.root;
/* 4874 */         break;
/*      */       
/*      */ 
/*      */       default: 
/* 4878 */         throw new NoViableAltException(_t);
/*      */       }
/*      */     }
/*      */     catch (RecognitionException ex)
/*      */     {
/* 4883 */       reportError(ex);
/* 4884 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 4886 */     this.returnAST = propertyName_AST;
/* 4887 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void propertyRefLhs(AST _t) throws RecognitionException
/*      */   {
/* 4892 */     AST propertyRefLhs_AST_in = _t == ASTNULL ? null : _t;
/* 4893 */     this.returnAST = null;
/* 4894 */     ASTPair currentAST = new ASTPair();
/* 4895 */     AST propertyRefLhs_AST = null;
/*      */     try
/*      */     {
/* 4898 */       propertyRef(_t);
/* 4899 */       _t = this._retTree;
/* 4900 */       this.astFactory.addASTChild(currentAST, this.returnAST);
/* 4901 */       propertyRefLhs_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 4904 */       reportError(ex);
/* 4905 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 4907 */     this.returnAST = propertyRefLhs_AST;
/* 4908 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */   public final void numericInteger(AST _t) throws RecognitionException
/*      */   {
/* 4913 */     AST numericInteger_AST_in = _t == ASTNULL ? null : _t;
/* 4914 */     this.returnAST = null;
/* 4915 */     ASTPair currentAST = new ASTPair();
/* 4916 */     AST numericInteger_AST = null;
/*      */     try
/*      */     {
/* 4919 */       AST tmp81_AST = null;
/* 4920 */       AST tmp81_AST_in = null;
/* 4921 */       tmp81_AST = this.astFactory.create(_t);
/* 4922 */       tmp81_AST_in = _t;
/* 4923 */       this.astFactory.addASTChild(currentAST, tmp81_AST);
/* 4924 */       match(_t, 117);
/* 4925 */       _t = _t.getNextSibling();
/* 4926 */       numericInteger_AST = currentAST.root;
/*      */     }
/*      */     catch (RecognitionException ex) {
/* 4929 */       reportError(ex);
/* 4930 */       if (_t != null) _t = _t.getNextSibling();
/*      */     }
/* 4932 */     this.returnAST = numericInteger_AST;
/* 4933 */     this._retTree = _t;
/*      */   }
/*      */   
/*      */ 
/* 4937 */   public static final String[] _tokenNames = { "<0>", "EOF", "<2>", "NULL_TREE_LOOKAHEAD", "\"all\"", "\"any\"", "\"and\"", "\"as\"", "\"asc\"", "\"avg\"", "\"between\"", "\"class\"", "\"count\"", "\"delete\"", "\"desc\"", "DOT", "\"distinct\"", "\"elements\"", "\"escape\"", "\"exists\"", "\"false\"", "\"fetch\"", "\"from\"", "\"full\"", "\"group\"", "\"having\"", "\"in\"", "\"indices\"", "\"inner\"", "\"insert\"", "\"into\"", "\"is\"", "\"join\"", "\"left\"", "\"like\"", "\"max\"", "\"min\"", "\"new\"", "\"not\"", "\"null\"", "\"or\"", "\"order\"", "\"outer\"", "\"properties\"", "\"right\"", "\"select\"", "\"set\"", "\"some\"", "\"sum\"", "\"true\"", "\"union\"", "\"update\"", "\"versioned\"", "\"where\"", "\"case\"", "\"end\"", "\"else\"", "\"then\"", "\"when\"", "\"on\"", "\"with\"", "\"both\"", "\"empty\"", "\"leading\"", "\"member\"", "\"object\"", "\"of\"", "\"trailing\"", "AGGREGATE", "ALIAS", "CONSTRUCTOR", "CASE2", "EXPR_LIST", "FILTER_ENTITY", "IN_LIST", "INDEX_OP", "IS_NOT_NULL", "IS_NULL", "METHOD_CALL", "NOT_BETWEEN", "NOT_IN", "NOT_LIKE", "ORDER_ELEMENT", "QUERY", "RANGE", "ROW_STAR", "SELECT_FROM", "UNARY_MINUS", "UNARY_PLUS", "VECTOR_EXPR", "WEIRD_IDENT", "CONSTANT", "NUM_DOUBLE", "NUM_FLOAT", "NUM_LONG", "COMMA", "EQ", "OPEN", "CLOSE", "\"by\"", "\"ascending\"", "\"descending\"", "NE", "SQL_NE", "LT", "GT", "LE", "GE", "CONCAT", "PLUS", "MINUS", "STAR", "DIV", "OPEN_BRACKET", "CLOSE_BRACKET", "COLON", "PARAM", "NUM_INT", "QUOTED_STRING", "IDENT", "ID_START_LETTER", "ID_LETTER", "ESCqs", "WS", "HEX_DIGIT", "EXPONENT", "FLOAT_SUFFIX", "FROM_FRAGMENT", "IMPLIED_FROM", "JOIN_FRAGMENT", "SELECT_CLAUSE", "LEFT_OUTER", "RIGHT_OUTER", "ALIAS_REF", "PROPERTY_REF", "SQL_TOKEN", "SELECT_COLUMNS", "SELECT_EXPR", "THETA_JOINS", "FILTERS", "METHOD_NAME", "NAMED_PARAM", "BOGUS" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final long[] mk_tokenSet_0()
/*      */   {
/* 5084 */     long[] data = { 18577898219802624L, 70333561793693840L, 0L, 0L };
/* 5085 */     return data; }
/*      */   
/* 5087 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*      */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\antlr\HqlSqlBaseWalker.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */