/*    */ package org.hibernate.hql;
/*    */ 
/*    */ import org.hibernate.MappingException;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NameGenerator
/*    */ {
/*    */   public static String[][] generateColumnNames(Type[] types, SessionFactoryImplementor f)
/*    */     throws MappingException
/*    */   {
/* 21 */     String[][] columnNames = new String[types.length][];
/* 22 */     for (int i = 0; i < types.length; i++) {
/* 23 */       int span = types[i].getColumnSpan(f);
/* 24 */       columnNames[i] = new String[span];
/* 25 */       for (int j = 0; j < span; j++) {
/* 26 */         columnNames[i][j] = scalarName(i, j);
/*    */       }
/*    */     }
/* 29 */     return columnNames;
/*    */   }
/*    */   
/*    */   public static String scalarName(int x, int y) {
/* 33 */     return "col_" + x + '_' + y + '_';
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\NameGenerator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */