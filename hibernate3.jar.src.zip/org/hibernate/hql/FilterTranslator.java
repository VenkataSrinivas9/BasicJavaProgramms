package org.hibernate.hql;

import java.util.Map;
import org.hibernate.MappingException;
import org.hibernate.QueryException;

public abstract interface FilterTranslator
  extends QueryTranslator
{
  public abstract void compile(String paramString, Map paramMap, boolean paramBoolean)
    throws QueryException, MappingException;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\FilterTranslator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */