/*    */ package org.hibernate.hql;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CollectionProperties
/*    */ {
/*    */   public static final Map HQL_COLLECTION_PROPERTIES;
/* 17 */   private static final String COLLECTION_INDEX_LOWER = "index".toLowerCase();
/*    */   
/*    */   static {
/* 20 */     HQL_COLLECTION_PROPERTIES = new HashMap();
/* 21 */     HQL_COLLECTION_PROPERTIES.put("elements".toLowerCase(), "elements");
/* 22 */     HQL_COLLECTION_PROPERTIES.put("indices".toLowerCase(), "indices");
/* 23 */     HQL_COLLECTION_PROPERTIES.put("size".toLowerCase(), "size");
/* 24 */     HQL_COLLECTION_PROPERTIES.put("maxIndex".toLowerCase(), "maxIndex");
/* 25 */     HQL_COLLECTION_PROPERTIES.put("minIndex".toLowerCase(), "minIndex");
/* 26 */     HQL_COLLECTION_PROPERTIES.put("maxElement".toLowerCase(), "maxElement");
/* 27 */     HQL_COLLECTION_PROPERTIES.put("minElement".toLowerCase(), "minElement");
/* 28 */     HQL_COLLECTION_PROPERTIES.put(COLLECTION_INDEX_LOWER, "index");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static boolean isCollectionProperty(String name)
/*    */   {
/* 35 */     String key = name.toLowerCase();
/*    */     
/* 37 */     if (COLLECTION_INDEX_LOWER.equals(key)) {
/* 38 */       return false;
/*    */     }
/*    */     
/* 41 */     return HQL_COLLECTION_PROPERTIES.containsKey(key);
/*    */   }
/*    */   
/*    */   public static String getNormalizedPropertyName(String name)
/*    */   {
/* 46 */     return (String)HQL_COLLECTION_PROPERTIES.get(name);
/*    */   }
/*    */   
/*    */   public static boolean isAnyCollectionProperty(String name) {
/* 50 */     String key = name.toLowerCase();
/* 51 */     return HQL_COLLECTION_PROPERTIES.containsKey(key);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\CollectionProperties.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */