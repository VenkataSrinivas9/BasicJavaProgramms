/*     */ package org.hibernate.hql;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.hql.classic.ParserHelper;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class QuerySplitter
/*     */ {
/*  24 */   private static final Log log = LogFactory.getLog(QuerySplitter.class);
/*     */   
/*  26 */   private static final Set BEFORE_CLASS_TOKENS = new HashSet();
/*  27 */   private static final Set NOT_AFTER_CLASS_TOKENS = new HashSet();
/*     */   
/*     */   static {
/*  30 */     BEFORE_CLASS_TOKENS.add("from");
/*  31 */     BEFORE_CLASS_TOKENS.add("delete");
/*  32 */     BEFORE_CLASS_TOKENS.add("update");
/*     */     
/*  34 */     BEFORE_CLASS_TOKENS.add(",");
/*  35 */     NOT_AFTER_CLASS_TOKENS.add("in");
/*     */     
/*  37 */     NOT_AFTER_CLASS_TOKENS.add("from");
/*  38 */     NOT_AFTER_CLASS_TOKENS.add(")");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] concreteQueries(String query, SessionFactoryImplementor factory)
/*     */     throws MappingException
/*     */   {
/*  60 */     String[] tokens = StringHelper.split(" \n\r\f\t(),", query, true);
/*  61 */     if (tokens.length == 0) return new String[] { query };
/*  62 */     ArrayList placeholders = new ArrayList();
/*  63 */     ArrayList replacements = new ArrayList();
/*  64 */     StringBuffer templateQuery = new StringBuffer(40);
/*  65 */     int count = 0;
/*  66 */     String last = null;
/*  67 */     int nextIndex = 0;
/*  68 */     String next = null;
/*  69 */     boolean isSelectClause = false;
/*     */     
/*  71 */     templateQuery.append(tokens[0]);
/*  72 */     if ("select".equals(tokens[0].toLowerCase())) { isSelectClause = true;
/*     */     }
/*  74 */     for (int i = 1; i < tokens.length; i++)
/*     */     {
/*     */ 
/*  77 */       if (!ParserHelper.isWhitespace(tokens[(i - 1)])) { last = tokens[(i - 1)].toLowerCase();
/*     */       }
/*     */       
/*  80 */       if ("from".equals(tokens[i].toLowerCase())) { isSelectClause = false;
/*     */       }
/*  82 */       String token = tokens[i];
/*  83 */       if ((!ParserHelper.isWhitespace(token)) || (last == null))
/*     */       {
/*     */ 
/*  86 */         if (nextIndex <= i) {
/*  87 */           for (nextIndex = i + 1; nextIndex < tokens.length; nextIndex++) {
/*  88 */             next = tokens[nextIndex].toLowerCase();
/*  89 */             if (!ParserHelper.isWhitespace(next))
/*     */               break;
/*     */           }
/*     */         }
/*  93 */         boolean process = (!isSelectClause) && (isJavaIdentifier(token)) && (isPossiblyClassName(last, next));
/*     */         
/*     */ 
/*     */ 
/*  97 */         if (process) {
/*  98 */           String importedClassName = getImportedClass(token, factory);
/*  99 */           if (importedClassName != null) {
/* 100 */             String[] implementors = factory.getImplementors(importedClassName);
/* 101 */             String placeholder = "$clazz" + count++ + "$";
/* 102 */             if (implementors != null) {
/* 103 */               placeholders.add(placeholder);
/* 104 */               replacements.add(implementors);
/*     */             }
/* 106 */             token = placeholder;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 112 */       templateQuery.append(token);
/*     */     }
/*     */     
/* 115 */     String[] results = StringHelper.multiply(templateQuery.toString(), placeholders.iterator(), replacements.iterator());
/* 116 */     if (results.length == 0) log.warn("no persistent classes found for query class: " + query);
/* 117 */     return results;
/*     */   }
/*     */   
/*     */   private static boolean isPossiblyClassName(String last, String next) {
/* 121 */     return ("class".equals(last)) || ((BEFORE_CLASS_TOKENS.contains(last)) && (!NOT_AFTER_CLASS_TOKENS.contains(next)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static boolean isJavaIdentifier(String token)
/*     */   {
/* 128 */     return Character.isJavaIdentifierStart(token.charAt(0));
/*     */   }
/*     */   
/*     */   public static String getImportedClass(String name, SessionFactoryImplementor factory) {
/* 132 */     return factory.getImportedClassName(name);
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\hql\QuerySplitter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */