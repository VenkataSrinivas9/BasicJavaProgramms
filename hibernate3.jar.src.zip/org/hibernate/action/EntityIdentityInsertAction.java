/*     */ package org.hibernate.action;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.event.EventListeners;
/*     */ import org.hibernate.event.PostInsertEvent;
/*     */ import org.hibernate.event.PostInsertEventListener;
/*     */ import org.hibernate.event.PreInsertEvent;
/*     */ import org.hibernate.event.PreInsertEventListener;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ 
/*     */ public final class EntityIdentityInsertAction extends EntityAction
/*     */ {
/*     */   private final Object[] state;
/*     */   private Serializable generatedId;
/*     */   
/*     */   public EntityIdentityInsertAction(Object[] state, Object instance, EntityPersister persister, SessionImplementor session) throws HibernateException
/*     */   {
/*  21 */     super(session, null, instance, persister);
/*  22 */     this.state = state;
/*     */   }
/*     */   
/*     */   public void execute() throws HibernateException
/*     */   {
/*  27 */     EntityPersister persister = getPersister();
/*  28 */     SessionImplementor session = getSession();
/*  29 */     Object instance = getInstance();
/*     */     
/*  31 */     boolean veto = preInsert();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  36 */     if (!veto) {
/*  37 */       this.generatedId = persister.insert(this.state, instance, session);
/*  38 */       if (persister.hasInsertGeneratedProperties()) {
/*  39 */         persister.processInsertGeneratedProperties(this.generatedId, instance, this.state, session);
/*     */       }
/*     */       
/*     */ 
/*  43 */       persister.setIdentifier(instance, this.generatedId, session.getEntityMode());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  55 */     postInsert();
/*     */     
/*  57 */     if ((session.getFactory().getStatistics().isStatisticsEnabled()) && (!veto)) {
/*  58 */       session.getFactory().getStatisticsImplementor().insertEntity(getPersister().getEntityName());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void postInsert()
/*     */   {
/*  65 */     PostInsertEventListener[] postListeners = getSession().getListeners().getPostInsertEventListeners();
/*     */     
/*  67 */     if (postListeners.length > 0) {
/*  68 */       PostInsertEvent postEvent = new PostInsertEvent(getInstance(), this.generatedId, this.state, getPersister());
/*  69 */       for (int i = 0; i < postListeners.length; i++) {
/*  70 */         postListeners[i].onPostInsert(postEvent);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void postCommitInsert() {
/*  76 */     PostInsertEventListener[] postListeners = getSession().getListeners().getPostCommitInsertEventListeners();
/*     */     
/*  78 */     if (postListeners.length > 0) {
/*  79 */       PostInsertEvent postEvent = new PostInsertEvent(getInstance(), this.generatedId, this.state, getPersister());
/*  80 */       for (int i = 0; i < postListeners.length; i++) {
/*  81 */         postListeners[i].onPostInsert(postEvent);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean preInsert() {
/*  87 */     PreInsertEventListener[] preListeners = getSession().getListeners().getPreInsertEventListeners();
/*     */     
/*  89 */     boolean veto = false;
/*  90 */     if (preListeners.length > 0) {
/*  91 */       PreInsertEvent preEvent = new PreInsertEvent(getInstance(), null, this.state, getPersister(), getSession());
/*  92 */       for (int i = 0; i < preListeners.length; i++) {
/*  93 */         veto = (preListeners[i].onPreInsert(preEvent)) || (veto);
/*     */       }
/*     */     }
/*  96 */     return veto;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterTransactionCompletion(boolean success)
/*     */     throws HibernateException
/*     */   {
/* 106 */     postCommitInsert();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean hasAfterTransactionCompletion()
/*     */   {
/* 112 */     return hasPostCommitEventListeners();
/*     */   }
/*     */   
/*     */   protected boolean hasPostCommitEventListeners() {
/* 116 */     return getSession().getListeners().getPostCommitInsertEventListeners().length > 0;
/*     */   }
/*     */   
/*     */   public final Serializable getGeneratedId() {
/* 120 */     return this.generatedId;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\action\EntityIdentityInsertAction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */