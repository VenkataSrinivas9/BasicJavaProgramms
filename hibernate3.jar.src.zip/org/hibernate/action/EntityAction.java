/*    */ package org.hibernate.action;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.AssertionFailure;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ import org.hibernate.pretty.MessageHelper;
/*    */ import org.hibernate.type.Type;
/*    */ import org.hibernate.util.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class EntityAction
/*    */   implements Executable, Serializable, Comparable
/*    */ {
/*    */   private final SessionImplementor session;
/*    */   private final Serializable id;
/*    */   private final Object instance;
/*    */   private final String entityName;
/*    */   private transient EntityPersister persister;
/*    */   
/*    */   protected EntityAction(SessionImplementor session, Serializable id, Object instance, EntityPersister persister)
/*    */   {
/* 28 */     this.session = session;
/* 29 */     this.id = id;
/* 30 */     this.persister = persister;
/* 31 */     this.instance = instance;
/* 32 */     this.entityName = persister.getEntityName();
/*    */   }
/*    */   
/*    */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 36 */     ois.defaultReadObject();
/* 37 */     this.persister = this.session.getFactory().getEntityPersister(this.entityName);
/*    */   }
/*    */   
/*    */   public final Serializable[] getPropertySpaces()
/*    */   {
/* 42 */     return this.persister.getPropertySpaces();
/*    */   }
/*    */   
/*    */   protected final SessionImplementor getSession() {
/* 46 */     return this.session;
/*    */   }
/*    */   
/*    */   protected final Serializable getId() {
/* 50 */     return this.id;
/*    */   }
/*    */   
/*    */   protected final EntityPersister getPersister() {
/* 54 */     return this.persister;
/*    */   }
/*    */   
/*    */   protected final Object getInstance() {
/* 58 */     return this.instance;
/*    */   }
/*    */   
/*    */   public void beforeExecutions() {
/* 62 */     throw new AssertionFailure("beforeExecutions() called for non-collection action");
/*    */   }
/*    */   
/*    */   public boolean hasAfterTransactionCompletion() {
/* 66 */     return (this.persister.hasCache()) || (hasPostCommitEventListeners());
/*    */   }
/*    */   
/*    */   protected abstract boolean hasPostCommitEventListeners();
/*    */   
/*    */   public String toString() {
/* 72 */     return StringHelper.unqualify(getClass().getName()) + MessageHelper.infoString(this.entityName, this.id);
/*    */   }
/*    */   
/*    */   public int compareTo(Object other) {
/* 76 */     EntityAction action = (EntityAction)other;
/*    */     
/* 78 */     int roleComparison = this.entityName.compareTo(action.entityName);
/* 79 */     if (roleComparison != 0) {
/* 80 */       return roleComparison;
/*    */     }
/*    */     
/*    */ 
/* 84 */     return this.persister.getIdentifierType().compare(this.id, action.id, this.session.getEntityMode());
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\action\EntityAction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */