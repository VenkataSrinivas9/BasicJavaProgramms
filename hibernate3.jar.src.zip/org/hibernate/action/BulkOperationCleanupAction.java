/*    */ package org.hibernate.action;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.persister.entity.Queryable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BulkOperationCleanupAction
/*    */   implements Executable, Serializable
/*    */ {
/*    */   private final SessionImplementor session;
/* 23 */   private final Set affectedEntityNames = new HashSet();
/* 24 */   private final Set affectedCollectionRoles = new HashSet();
/*    */   private final Serializable[] spaces;
/*    */   
/*    */   public BulkOperationCleanupAction(SessionImplementor session, Queryable[] affectedQueryables) {
/* 28 */     this.session = session;
/*    */     
/* 30 */     ArrayList tmpSpaces = new ArrayList();
/* 31 */     for (int i = 0; i < affectedQueryables.length; i++) {
/* 32 */       if (affectedQueryables[i].hasCache()) {
/* 33 */         this.affectedEntityNames.add(affectedQueryables[i].getEntityName());
/*    */       }
/* 35 */       Set roles = session.getFactory().getCollectionRolesByEntityParticipant(affectedQueryables[i].getEntityName());
/* 36 */       if (roles != null) {
/* 37 */         this.affectedCollectionRoles.addAll(roles);
/*    */       }
/* 39 */       for (int y = 0; y < affectedQueryables[i].getQuerySpaces().length; y++) {
/* 40 */         tmpSpaces.add(affectedQueryables[i].getQuerySpaces()[y]);
/*    */       }
/*    */     }
/* 43 */     this.spaces = new Serializable[tmpSpaces.size()];
/* 44 */     for (int i = 0; i < tmpSpaces.size(); i++) {
/* 45 */       this.spaces[i] = ((Serializable)tmpSpaces.get(i));
/*    */     }
/*    */   }
/*    */   
/*    */   public void init() {
/* 50 */     evictEntityRegions();
/* 51 */     evictCollectionRegions();
/*    */   }
/*    */   
/*    */   public boolean hasAfterTransactionCompletion() {
/* 55 */     return true;
/*    */   }
/*    */   
/*    */   public void afterTransactionCompletion(boolean success) throws HibernateException {
/* 59 */     evictEntityRegions();
/* 60 */     evictCollectionRegions();
/*    */   }
/*    */   
/*    */   public Serializable[] getPropertySpaces() {
/* 64 */     return this.spaces;
/*    */   }
/*    */   
/*    */   public void beforeExecutions()
/*    */     throws HibernateException
/*    */   {}
/*    */   
/*    */   public void execute() throws HibernateException
/*    */   {}
/*    */   
/*    */   private void evictEntityRegions()
/*    */   {
/* 76 */     if (this.affectedEntityNames != null) {
/* 77 */       Iterator itr = this.affectedEntityNames.iterator();
/* 78 */       while (itr.hasNext()) {
/* 79 */         String entityName = (String)itr.next();
/* 80 */         this.session.getFactory().evictEntity(entityName);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   private void evictCollectionRegions() {
/* 86 */     if (this.affectedCollectionRoles != null) {
/* 87 */       Iterator itr = this.affectedCollectionRoles.iterator();
/* 88 */       while (itr.hasNext()) {
/* 89 */         String roleName = (String)itr.next();
/* 90 */         this.session.getFactory().evictCollection(roleName);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\action\BulkOperationCleanupAction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */