/*     */ package org.hibernate.action;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.cache.CacheConcurrencyStrategy;
/*     */ import org.hibernate.cache.CacheConcurrencyStrategy.SoftLock;
/*     */ import org.hibernate.cache.CacheKey;
/*     */ import org.hibernate.engine.EntityEntry;
/*     */ import org.hibernate.engine.EntityKey;
/*     */ import org.hibernate.engine.PersistenceContext;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.event.EventListeners;
/*     */ import org.hibernate.event.PostDeleteEvent;
/*     */ import org.hibernate.event.PostDeleteEventListener;
/*     */ import org.hibernate.event.PreDeleteEvent;
/*     */ import org.hibernate.event.PreDeleteEventListener;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.stat.Statistics;
/*     */ import org.hibernate.stat.StatisticsImplementor;
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EntityDeleteAction
/*     */   extends EntityAction
/*     */ {
/*     */   private final Object version;
/*     */   private CacheConcurrencyStrategy.SoftLock lock;
/*     */   private final boolean isCascadeDeleteEnabled;
/*     */   private final Object[] state;
/*     */   
/*     */   public EntityDeleteAction(Serializable id, Object[] state, Object version, Object instance, EntityPersister persister, boolean isCascadeDeleteEnabled, SessionImplementor session)
/*     */   {
/*  35 */     super(session, id, instance, persister);
/*  36 */     this.version = version;
/*  37 */     this.isCascadeDeleteEnabled = isCascadeDeleteEnabled;
/*  38 */     this.state = state;
/*     */   }
/*     */   
/*     */   public void execute() throws HibernateException {
/*  42 */     Serializable id = getId();
/*  43 */     EntityPersister persister = getPersister();
/*  44 */     SessionImplementor session = getSession();
/*  45 */     Object instance = getInstance();
/*     */     
/*  47 */     boolean veto = preDelete();
/*     */     
/*     */     CacheKey ck;
/*  50 */     if (persister.hasCache()) {
/*  51 */       CacheKey ck = new CacheKey(id, persister.getIdentifierType(), persister.getRootEntityName(), session.getEntityMode(), session.getFactory());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  58 */       this.lock = persister.getCache().lock(ck, this.version);
/*     */     }
/*     */     else {
/*  61 */       ck = null;
/*     */     }
/*     */     
/*  64 */     if ((!this.isCascadeDeleteEnabled) && (!veto)) {
/*  65 */       persister.delete(id, this.version, instance, session);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */     PersistenceContext persistenceContext = session.getPersistenceContext();
/*  73 */     EntityEntry entry = persistenceContext.removeEntry(instance);
/*  74 */     if (entry == null) {
/*  75 */       throw new AssertionFailure("possible nonthreadsafe access to session");
/*     */     }
/*  77 */     entry.postDelete();
/*     */     
/*  79 */     EntityKey key = new EntityKey(entry.getId(), entry.getPersister(), session.getEntityMode());
/*  80 */     persistenceContext.removeEntity(key);
/*  81 */     persistenceContext.removeProxy(key);
/*     */     
/*  83 */     if (persister.hasCache()) { persister.getCache().evict(ck);
/*     */     }
/*  85 */     postDelete();
/*     */     
/*  87 */     if ((getSession().getFactory().getStatistics().isStatisticsEnabled()) && (!veto)) {
/*  88 */       getSession().getFactory().getStatisticsImplementor().deleteEntity(getPersister().getEntityName());
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean preDelete()
/*     */   {
/*  94 */     PreDeleteEventListener[] preListeners = getSession().getListeners().getPreDeleteEventListeners();
/*     */     
/*  96 */     boolean veto = false;
/*  97 */     if (preListeners.length > 0) {
/*  98 */       PreDeleteEvent preEvent = new PreDeleteEvent(getInstance(), getId(), this.state, getPersister());
/*  99 */       for (int i = 0; i < preListeners.length; i++) {
/* 100 */         veto = (preListeners[i].onPreDelete(preEvent)) || (veto);
/*     */       }
/*     */     }
/* 103 */     return veto;
/*     */   }
/*     */   
/*     */   private void postDelete() {
/* 107 */     PostDeleteEventListener[] postListeners = getSession().getListeners().getPostDeleteEventListeners();
/*     */     
/* 109 */     if (postListeners.length > 0) {
/* 110 */       PostDeleteEvent postEvent = new PostDeleteEvent(getInstance(), getId(), this.state, getPersister());
/* 111 */       for (int i = 0; i < postListeners.length; i++) {
/* 112 */         postListeners[i].onPostDelete(postEvent);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void postCommitDelete() {
/* 118 */     PostDeleteEventListener[] postListeners = getSession().getListeners().getPostCommitDeleteEventListeners();
/*     */     
/* 120 */     if (postListeners.length > 0) {
/* 121 */       PostDeleteEvent postEvent = new PostDeleteEvent(getInstance(), getId(), this.state, getPersister());
/* 122 */       for (int i = 0; i < postListeners.length; i++) {
/* 123 */         postListeners[i].onPostDelete(postEvent);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void afterTransactionCompletion(boolean success) throws HibernateException {
/* 129 */     if (getPersister().hasCache()) {
/* 130 */       CacheKey ck = new CacheKey(getId(), getPersister().getIdentifierType(), getPersister().getRootEntityName(), getSession().getEntityMode(), getSession().getFactory());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 137 */       getPersister().getCache().release(ck, this.lock);
/*     */     }
/* 139 */     postCommitDelete();
/*     */   }
/*     */   
/*     */   protected boolean hasPostCommitEventListeners() {
/* 143 */     return getSession().getListeners().getPostCommitDeleteEventListeners().length > 0;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\action\EntityDeleteAction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */