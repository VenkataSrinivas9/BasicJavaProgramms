/*    */ package org.hibernate.action;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.cache.CacheException;
/*    */ import org.hibernate.collection.PersistentCollection;
/*    */ import org.hibernate.engine.CollectionEntry;
/*    */ import org.hibernate.engine.PersistenceContext;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.persister.collection.CollectionPersister;
/*    */ import org.hibernate.stat.Statistics;
/*    */ import org.hibernate.stat.StatisticsImplementor;
/*    */ 
/*    */ public final class CollectionRecreateAction
/*    */   extends CollectionAction
/*    */ {
/*    */   public CollectionRecreateAction(PersistentCollection collection, CollectionPersister persister, Serializable id, SessionImplementor session) throws CacheException
/*    */   {
/* 20 */     super(persister, collection, id, session);
/*    */   }
/*    */   
/*    */   public void execute() throws HibernateException {
/* 24 */     PersistentCollection collection = getCollection();
/*    */     
/* 26 */     getPersister().recreate(collection, getKey(), getSession());
/*    */     
/* 28 */     getSession().getPersistenceContext().getCollectionEntry(collection).afterAction(collection);
/*    */     
/*    */ 
/*    */ 
/* 32 */     evict();
/*    */     
/* 34 */     if (getSession().getFactory().getStatistics().isStatisticsEnabled()) {
/* 35 */       getSession().getFactory().getStatisticsImplementor().recreateCollection(getPersister().getRole());
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\action\CollectionRecreateAction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */