/*     */ package org.hibernate.action;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.cache.CacheConcurrencyStrategy;
/*     */ import org.hibernate.cache.CacheConcurrencyStrategy.SoftLock;
/*     */ import org.hibernate.cache.CacheException;
/*     */ import org.hibernate.cache.CacheKey;
/*     */ import org.hibernate.cache.entry.CacheEntry;
/*     */ import org.hibernate.cache.entry.CacheEntryStructure;
/*     */ import org.hibernate.engine.EntityEntry;
/*     */ import org.hibernate.engine.PersistenceContext;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.engine.Status;
/*     */ import org.hibernate.engine.Versioning;
/*     */ import org.hibernate.event.EventListeners;
/*     */ import org.hibernate.event.PostUpdateEvent;
/*     */ import org.hibernate.event.PostUpdateEventListener;
/*     */ import org.hibernate.event.PreUpdateEvent;
/*     */ import org.hibernate.event.PreUpdateEventListener;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.stat.Statistics;
/*     */ import org.hibernate.stat.StatisticsImplementor;
/*     */ import org.hibernate.type.TypeFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EntityUpdateAction
/*     */   extends EntityAction
/*     */ {
/*     */   private final Object[] state;
/*     */   private final Object[] previousState;
/*     */   private final Object previousVersion;
/*     */   private Object nextVersion;
/*     */   private final int[] dirtyFields;
/*     */   private final boolean hasDirtyCollection;
/*     */   private final Object rowId;
/*     */   private Object cacheEntry;
/*     */   private CacheConcurrencyStrategy.SoftLock lock;
/*     */   
/*     */   public EntityUpdateAction(Serializable id, Object[] state, int[] dirtyProperties, boolean hasDirtyCollection, Object[] previousState, Object previousVersion, Object nextVersion, Object instance, Object rowId, EntityPersister persister, SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/*  48 */     super(session, id, instance, persister);
/*  49 */     this.state = state;
/*  50 */     this.previousState = previousState;
/*  51 */     this.previousVersion = previousVersion;
/*  52 */     this.nextVersion = nextVersion;
/*  53 */     this.dirtyFields = dirtyProperties;
/*  54 */     this.hasDirtyCollection = hasDirtyCollection;
/*  55 */     this.rowId = rowId;
/*     */   }
/*     */   
/*     */   public void execute() throws HibernateException {
/*  59 */     Serializable id = getId();
/*  60 */     EntityPersister persister = getPersister();
/*  61 */     SessionImplementor session = getSession();
/*  62 */     Object instance = getInstance();
/*     */     
/*  64 */     boolean veto = preUpdate();
/*     */     
/*  66 */     SessionFactoryImplementor factory = getSession().getFactory();
/*     */     
/*     */     CacheKey ck;
/*  69 */     if (persister.hasCache()) {
/*  70 */       CacheKey ck = new CacheKey(id, persister.getIdentifierType(), persister.getRootEntityName(), session.getEntityMode(), session.getFactory());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  77 */       this.lock = persister.getCache().lock(ck, this.previousVersion);
/*     */     }
/*     */     else {
/*  80 */       ck = null;
/*     */     }
/*     */     
/*  83 */     if (!veto) {
/*  84 */       persister.update(id, this.state, this.dirtyFields, this.hasDirtyCollection, this.previousState, this.previousVersion, instance, this.rowId, session);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  98 */     EntityEntry entry = getSession().getPersistenceContext().getEntry(instance);
/*  99 */     if (entry == null) {
/* 100 */       throw new AssertionFailure("possible nonthreadsafe access to session");
/*     */     }
/*     */     
/* 103 */     if (entry.getStatus() == Status.MANAGED)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 108 */       TypeFactory.deepCopy(this.state, persister.getPropertyTypes(), persister.getPropertyCheckability(), this.state, session);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 116 */       if (persister.hasUpdateGeneratedProperties()) {
/* 117 */         persister.processUpdateGeneratedProperties(id, instance, this.state, session);
/* 118 */         if (persister.isVersionPropertyGenerated()) {
/* 119 */           this.nextVersion = Versioning.getVersion(this.state, persister);
/*     */         }
/*     */       }
/*     */       
/* 123 */       entry.postUpdate(instance, this.state, this.nextVersion);
/*     */     }
/*     */     
/*     */ 
/* 127 */     if (persister.hasCache())
/*     */     {
/* 129 */       if ((persister.isCacheInvalidationRequired()) || (entry.getStatus() != Status.MANAGED)) {
/* 130 */         persister.getCache().evict(ck);
/*     */       }
/*     */       else
/*     */       {
/* 134 */         CacheEntry ce = new CacheEntry(this.state, persister, persister.hasUninitializedLazyProperties(instance, session.getEntityMode()), this.nextVersion, getSession(), instance);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 142 */         this.cacheEntry = persister.getCacheEntryStructure().structure(ce);
/* 143 */         boolean put = persister.getCache().update(ck, this.cacheEntry);
/*     */         
/* 145 */         if ((put) && (factory.getStatistics().isStatisticsEnabled())) {
/* 146 */           factory.getStatisticsImplementor().secondLevelCachePut(getPersister().getCache().getRegionName());
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 153 */     postUpdate();
/*     */     
/* 155 */     if ((factory.getStatistics().isStatisticsEnabled()) && (!veto)) {
/* 156 */       factory.getStatisticsImplementor().updateEntity(getPersister().getEntityName());
/*     */     }
/*     */   }
/*     */   
/*     */   private void postUpdate()
/*     */   {
/* 162 */     PostUpdateEventListener[] postListeners = getSession().getListeners().getPostUpdateEventListeners();
/*     */     
/* 164 */     if (postListeners.length > 0) {
/* 165 */       PostUpdateEvent postEvent = new PostUpdateEvent(getInstance(), getId(), this.state, this.previousState, getPersister());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 172 */       for (int i = 0; i < postListeners.length; i++) {
/* 173 */         postListeners[i].onPostUpdate(postEvent);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void postCommitUpdate() {
/* 179 */     PostUpdateEventListener[] postListeners = getSession().getListeners().getPostCommitUpdateEventListeners();
/*     */     
/* 181 */     if (postListeners.length > 0) {
/* 182 */       PostUpdateEvent postEvent = new PostUpdateEvent(getInstance(), getId(), this.state, this.previousState, getPersister());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 189 */       for (int i = 0; i < postListeners.length; i++) {
/* 190 */         postListeners[i].onPostUpdate(postEvent);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean preUpdate() {
/* 196 */     PreUpdateEventListener[] preListeners = getSession().getListeners().getPreUpdateEventListeners();
/*     */     
/* 198 */     boolean veto = false;
/* 199 */     if (preListeners.length > 0) {
/* 200 */       PreUpdateEvent preEvent = new PreUpdateEvent(getInstance(), getId(), this.state, this.previousState, getPersister(), getSession());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 208 */       for (int i = 0; i < preListeners.length; i++) {
/* 209 */         veto = (preListeners[i].onPreUpdate(preEvent)) || (veto);
/*     */       }
/*     */     }
/* 212 */     return veto;
/*     */   }
/*     */   
/*     */   public void afterTransactionCompletion(boolean success) throws CacheException {
/* 216 */     EntityPersister persister = getPersister();
/* 217 */     if (persister.hasCache())
/*     */     {
/* 219 */       CacheKey ck = new CacheKey(getId(), persister.getIdentifierType(), persister.getRootEntityName(), getSession().getEntityMode(), getSession().getFactory());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 227 */       if ((success) && (this.cacheEntry != null)) {
/* 228 */         boolean put = persister.getCache().afterUpdate(ck, this.cacheEntry, this.nextVersion, this.lock);
/*     */         
/* 230 */         if ((put) && (getSession().getFactory().getStatistics().isStatisticsEnabled())) {
/* 231 */           getSession().getFactory().getStatisticsImplementor().secondLevelCachePut(getPersister().getCache().getRegionName());
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 236 */         persister.getCache().release(ck, this.lock);
/*     */       }
/*     */     }
/* 239 */     postCommitUpdate();
/*     */   }
/*     */   
/*     */   protected boolean hasPostCommitEventListeners() {
/* 243 */     return getSession().getListeners().getPostCommitUpdateEventListeners().length > 0;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\action\EntityUpdateAction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */