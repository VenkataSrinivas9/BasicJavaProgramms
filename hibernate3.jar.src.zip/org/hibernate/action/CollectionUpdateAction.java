/*    */ package org.hibernate.action;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.AssertionFailure;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.cache.CacheException;
/*    */ import org.hibernate.collection.PersistentCollection;
/*    */ import org.hibernate.engine.CollectionEntry;
/*    */ import org.hibernate.engine.PersistenceContext;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.persister.collection.CollectionPersister;
/*    */ import org.hibernate.pretty.MessageHelper;
/*    */ import org.hibernate.stat.Statistics;
/*    */ import org.hibernate.stat.StatisticsImplementor;
/*    */ 
/*    */ public final class CollectionUpdateAction
/*    */   extends CollectionAction
/*    */ {
/*    */   private final boolean emptySnapshot;
/*    */   
/*    */   public CollectionUpdateAction(PersistentCollection collection, CollectionPersister persister, Serializable id, boolean emptySnapshot, SessionImplementor session)
/*    */     throws CacheException
/*    */   {
/* 25 */     super(persister, collection, id, session);
/* 26 */     this.emptySnapshot = emptySnapshot;
/*    */   }
/*    */   
/*    */   public void execute() throws HibernateException {
/* 30 */     Serializable id = getKey();
/* 31 */     SessionImplementor session = getSession();
/* 32 */     CollectionPersister persister = getPersister();
/* 33 */     PersistentCollection collection = getCollection();
/* 34 */     boolean affectedByFilters = persister.isAffectedByEnabledFilters(session);
/*    */     
/* 36 */     if (!collection.wasInitialized()) {
/* 37 */       if (!collection.hasQueuedOperations()) { throw new AssertionFailure("no queued adds");
/*    */       }
/*    */     }
/* 40 */     else if ((!affectedByFilters) && (collection.empty())) {
/* 41 */       if (!this.emptySnapshot) persister.remove(id, session);
/*    */     }
/* 43 */     else if (collection.needsRecreate(persister)) {
/* 44 */       if (affectedByFilters) {
/* 45 */         throw new HibernateException("cannot recreate collection while filter is enabled: " + MessageHelper.collectionInfoString(persister, id, persister.getFactory()));
/*    */       }
/*    */       
/*    */ 
/*    */ 
/* 50 */       if (!this.emptySnapshot) persister.remove(id, session);
/* 51 */       persister.recreate(collection, id, session);
/*    */     }
/*    */     else {
/* 54 */       persister.deleteRows(collection, id, session);
/* 55 */       persister.updateRows(collection, id, session);
/* 56 */       persister.insertRows(collection, id, session);
/*    */     }
/*    */     
/* 59 */     getSession().getPersistenceContext().getCollectionEntry(collection).afterAction(collection);
/*    */     
/*    */ 
/*    */ 
/* 63 */     evict();
/*    */     
/* 65 */     if (getSession().getFactory().getStatistics().isStatisticsEnabled()) {
/* 66 */       getSession().getFactory().getStatisticsImplementor().updateCollection(getPersister().getRole());
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\action\CollectionUpdateAction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */