package org.hibernate.action;

import java.io.Serializable;
import org.hibernate.HibernateException;

public abstract interface Executable
{
  public abstract void beforeExecutions()
    throws HibernateException;
  
  public abstract void execute()
    throws HibernateException;
  
  public abstract boolean hasAfterTransactionCompletion();
  
  public abstract void afterTransactionCompletion(boolean paramBoolean)
    throws HibernateException;
  
  public abstract Serializable[] getPropertySpaces();
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\action\Executable.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */