/*    */ package org.hibernate.action;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.cache.CacheException;
/*    */ import org.hibernate.collection.PersistentCollection;
/*    */ import org.hibernate.engine.CollectionEntry;
/*    */ import org.hibernate.engine.PersistenceContext;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.persister.collection.CollectionPersister;
/*    */ import org.hibernate.stat.Statistics;
/*    */ import org.hibernate.stat.StatisticsImplementor;
/*    */ 
/*    */ public final class CollectionRemoveAction
/*    */   extends CollectionAction
/*    */ {
/*    */   private boolean emptySnapshot;
/*    */   
/*    */   public CollectionRemoveAction(PersistentCollection collection, CollectionPersister persister, Serializable id, boolean emptySnapshot, SessionImplementor session)
/*    */     throws CacheException
/*    */   {
/* 23 */     super(persister, collection, id, session);
/* 24 */     this.emptySnapshot = emptySnapshot;
/*    */   }
/*    */   
/*    */   public void execute() throws HibernateException {
/* 28 */     if (!this.emptySnapshot) { getPersister().remove(getKey(), getSession());
/*    */     }
/* 30 */     PersistentCollection collection = getCollection();
/* 31 */     if (collection != null) {
/* 32 */       getSession().getPersistenceContext().getCollectionEntry(collection).afterAction(collection);
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 37 */     evict();
/*    */     
/* 39 */     if (getSession().getFactory().getStatistics().isStatisticsEnabled()) {
/* 40 */       getSession().getFactory().getStatisticsImplementor().removeCollection(getPersister().getRole());
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\action\CollectionRemoveAction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */