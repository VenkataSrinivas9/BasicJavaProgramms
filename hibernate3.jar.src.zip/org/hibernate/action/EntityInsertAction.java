/*     */ package org.hibernate.action;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.CacheMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.cache.CacheConcurrencyStrategy;
/*     */ import org.hibernate.cache.CacheKey;
/*     */ import org.hibernate.cache.entry.CacheEntry;
/*     */ import org.hibernate.cache.entry.CacheEntryStructure;
/*     */ import org.hibernate.engine.EntityEntry;
/*     */ import org.hibernate.engine.PersistenceContext;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.engine.Versioning;
/*     */ import org.hibernate.event.EventListeners;
/*     */ import org.hibernate.event.PostInsertEvent;
/*     */ import org.hibernate.event.PostInsertEventListener;
/*     */ import org.hibernate.event.PreInsertEvent;
/*     */ import org.hibernate.event.PreInsertEventListener;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.stat.Statistics;
/*     */ import org.hibernate.stat.StatisticsImplementor;
/*     */ 
/*     */ public final class EntityInsertAction extends EntityAction
/*     */ {
/*     */   private Object[] state;
/*     */   private Object version;
/*     */   private Object cacheEntry;
/*     */   
/*     */   public EntityInsertAction(Serializable id, Object[] state, Object instance, Object version, EntityPersister persister, SessionImplementor session) throws HibernateException
/*     */   {
/*  33 */     super(session, id, instance, persister);
/*  34 */     this.state = state;
/*  35 */     this.version = version;
/*     */   }
/*     */   
/*     */   public void execute() throws HibernateException {
/*  39 */     EntityPersister persister = getPersister();
/*  40 */     SessionImplementor session = getSession();
/*  41 */     Object instance = getInstance();
/*  42 */     Serializable id = getId();
/*     */     
/*  44 */     boolean veto = preInsert();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  49 */     if (!veto)
/*     */     {
/*  51 */       persister.insert(id, this.state, instance, session);
/*     */       
/*  53 */       EntityEntry entry = session.getPersistenceContext().getEntry(instance);
/*  54 */       if (entry == null) {
/*  55 */         throw new AssertionFailure("possible nonthreadsafe access to session");
/*     */       }
/*     */       
/*  58 */       entry.postInsert();
/*     */       
/*  60 */       if (persister.hasInsertGeneratedProperties()) {
/*  61 */         persister.processInsertGeneratedProperties(id, instance, this.state, session);
/*  62 */         if (persister.isVersionPropertyGenerated()) {
/*  63 */           this.version = Versioning.getVersion(this.state, persister);
/*     */         }
/*  65 */         entry.postUpdate(instance, this.state, this.version);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  70 */     SessionFactoryImplementor factory = getSession().getFactory();
/*     */     
/*  72 */     if (isCachePutEnabled(persister, session))
/*     */     {
/*  74 */       CacheEntry ce = new CacheEntry(this.state, persister, persister.hasUninitializedLazyProperties(instance, session.getEntityMode()), this.version, session, instance);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */       this.cacheEntry = persister.getCacheEntryStructure().structure(ce);
/*  84 */       CacheKey ck = new CacheKey(id, persister.getIdentifierType(), persister.getRootEntityName(), session.getEntityMode(), session.getFactory());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  91 */       boolean put = persister.getCache().insert(ck, this.cacheEntry);
/*     */       
/*  93 */       if ((put) && (factory.getStatistics().isStatisticsEnabled())) {
/*  94 */         factory.getStatisticsImplementor().secondLevelCachePut(getPersister().getCache().getRegionName());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 100 */     postInsert();
/*     */     
/* 102 */     if ((factory.getStatistics().isStatisticsEnabled()) && (!veto)) {
/* 103 */       factory.getStatisticsImplementor().insertEntity(getPersister().getEntityName());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void postInsert()
/*     */   {
/* 110 */     PostInsertEventListener[] postListeners = getSession().getListeners().getPostInsertEventListeners();
/*     */     
/* 112 */     if (postListeners.length > 0) {
/* 113 */       PostInsertEvent postEvent = new PostInsertEvent(getInstance(), getId(), this.state, getPersister());
/* 114 */       for (int i = 0; i < postListeners.length; i++) {
/* 115 */         postListeners[i].onPostInsert(postEvent);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void postCommitInsert() {
/* 121 */     PostInsertEventListener[] postListeners = getSession().getListeners().getPostCommitInsertEventListeners();
/*     */     
/* 123 */     if (postListeners.length > 0) {
/* 124 */       PostInsertEvent postEvent = new PostInsertEvent(getInstance(), getId(), this.state, getPersister());
/* 125 */       for (int i = 0; i < postListeners.length; i++) {
/* 126 */         postListeners[i].onPostInsert(postEvent);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean preInsert() {
/* 132 */     PreInsertEventListener[] preListeners = getSession().getListeners().getPreInsertEventListeners();
/*     */     
/* 134 */     boolean veto = false;
/* 135 */     if (preListeners.length > 0) {
/* 136 */       PreInsertEvent preEvent = new PreInsertEvent(getInstance(), getId(), this.state, getPersister(), getSession());
/* 137 */       for (int i = 0; i < preListeners.length; i++) {
/* 138 */         veto = (preListeners[i].onPreInsert(preEvent)) || (veto);
/*     */       }
/*     */     }
/* 141 */     return veto;
/*     */   }
/*     */   
/*     */   public void afterTransactionCompletion(boolean success) throws HibernateException
/*     */   {
/* 146 */     EntityPersister persister = getPersister();
/* 147 */     if ((success) && (isCachePutEnabled(persister, getSession()))) {
/* 148 */       CacheKey ck = new CacheKey(getId(), persister.getIdentifierType(), persister.getRootEntityName(), getSession().getEntityMode(), getSession().getFactory());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 155 */       boolean put = persister.getCache().afterInsert(ck, this.cacheEntry, this.version);
/*     */       
/* 157 */       if ((put) && (getSession().getFactory().getStatistics().isStatisticsEnabled())) {
/* 158 */         getSession().getFactory().getStatisticsImplementor().secondLevelCachePut(getPersister().getCache().getRegionName());
/*     */       }
/*     */     }
/*     */     
/* 162 */     postCommitInsert();
/*     */   }
/*     */   
/*     */   protected boolean hasPostCommitEventListeners() {
/* 166 */     return getSession().getListeners().getPostCommitInsertEventListeners().length > 0;
/*     */   }
/*     */   
/*     */   private boolean isCachePutEnabled(EntityPersister persister, SessionImplementor session) {
/* 170 */     return (persister.hasCache()) && (!persister.isCacheInvalidationRequired()) && (session.getCacheMode().isPutEnabled());
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\action\EntityInsertAction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */