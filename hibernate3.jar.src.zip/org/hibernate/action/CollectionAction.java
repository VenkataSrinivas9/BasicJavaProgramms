/*     */ package org.hibernate.action;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import org.hibernate.cache.CacheConcurrencyStrategy;
/*     */ import org.hibernate.cache.CacheConcurrencyStrategy.SoftLock;
/*     */ import org.hibernate.cache.CacheException;
/*     */ import org.hibernate.cache.CacheKey;
/*     */ import org.hibernate.collection.PersistentCollection;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.pretty.MessageHelper;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CollectionAction
/*     */   implements Executable, Serializable, Comparable
/*     */ {
/*     */   private transient CollectionPersister persister;
/*     */   private final Serializable key;
/*     */   private final SessionImplementor session;
/*     */   private CacheConcurrencyStrategy.SoftLock lock;
/*     */   private final String collectionRole;
/*     */   private final PersistentCollection collection;
/*     */   
/*     */   public CollectionAction(CollectionPersister persister, PersistentCollection collection, Serializable key, SessionImplementor session)
/*     */     throws CacheException
/*     */   {
/*  36 */     this.persister = persister;
/*  37 */     this.session = session;
/*  38 */     this.key = key;
/*  39 */     this.collectionRole = persister.getRole();
/*  40 */     this.collection = collection;
/*     */   }
/*     */   
/*     */   protected PersistentCollection getCollection() {
/*  44 */     return this.collection;
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/*  48 */     ois.defaultReadObject();
/*  49 */     this.persister = this.session.getFactory().getCollectionPersister(this.collectionRole);
/*     */   }
/*     */   
/*     */   public void afterTransactionCompletion(boolean success) throws CacheException {
/*  53 */     if (this.persister.hasCache()) {
/*  54 */       CacheKey ck = new CacheKey(this.key, this.persister.getKeyType(), this.persister.getRole(), this.session.getEntityMode(), this.session.getFactory());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  61 */       this.persister.getCache().release(ck, this.lock);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean hasAfterTransactionCompletion() {
/*  66 */     return this.persister.hasCache();
/*     */   }
/*     */   
/*     */   public Serializable[] getPropertySpaces() {
/*  70 */     return this.persister.getCollectionSpaces();
/*     */   }
/*     */   
/*     */   protected final CollectionPersister getPersister() {
/*  74 */     return this.persister;
/*     */   }
/*     */   
/*     */   protected final Serializable getKey() {
/*  78 */     return this.key;
/*     */   }
/*     */   
/*     */   protected final SessionImplementor getSession() {
/*  82 */     return this.session;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void beforeExecutions()
/*     */     throws CacheException
/*     */   {
/*  92 */     if (this.persister.hasCache()) {
/*  93 */       CacheKey ck = new CacheKey(this.key, this.persister.getKeyType(), this.persister.getRole(), this.session.getEntityMode(), this.session.getFactory());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */       this.lock = this.persister.getCache().lock(ck, null);
/*     */     }
/*     */   }
/*     */   
/*     */   protected final void evict() throws CacheException {
/* 105 */     if (this.persister.hasCache()) {
/* 106 */       CacheKey ck = new CacheKey(this.key, this.persister.getKeyType(), this.persister.getRole(), this.session.getEntityMode(), this.session.getFactory());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 113 */       this.persister.getCache().evict(ck);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() {
/* 118 */     return StringHelper.unqualify(getClass().getName()) + MessageHelper.infoString(this.collectionRole, this.key);
/*     */   }
/*     */   
/*     */   public int compareTo(Object other)
/*     */   {
/* 123 */     CollectionAction action = (CollectionAction)other;
/*     */     
/* 125 */     int roleComparison = this.collectionRole.compareTo(action.collectionRole);
/* 126 */     if (roleComparison != 0) {
/* 127 */       return roleComparison;
/*     */     }
/*     */     
/*     */ 
/* 131 */     return this.persister.getKeyType().compare(this.key, action.key, this.session.getEntityMode());
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\action\CollectionAction.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */