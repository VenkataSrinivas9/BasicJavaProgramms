/*     */ package org.hibernate.connection;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.cfg.Environment;
/*     */ import org.hibernate.util.ConfigHelper;
/*     */ import org.hibernate.util.PropertiesHelper;
/*     */ import org.hibernate.util.StringHelper;
/*     */ import org.logicalcobwebs.proxool.ProxoolException;
/*     */ import org.logicalcobwebs.proxool.ProxoolFacade;
/*     */ import org.logicalcobwebs.proxool.configuration.JAXPConfigurator;
/*     */ import org.logicalcobwebs.proxool.configuration.PropertyConfigurator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxoolConnectionProvider
/*     */   implements ConnectionProvider
/*     */ {
/*     */   private static final String PROXOOL_JDBC_STEM = "proxool.";
/*  33 */   private static final Log log = LogFactory.getLog(ProxoolConnectionProvider.class);
/*     */   
/*     */ 
/*     */ 
/*     */   private String proxoolAlias;
/*     */   
/*     */ 
/*     */   private boolean existingPool;
/*     */   
/*     */ 
/*     */   private Integer isolation;
/*     */   
/*     */ 
/*     */   private boolean autocommit;
/*     */   
/*     */ 
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/*  53 */     Connection c = DriverManager.getConnection(this.proxoolAlias);
/*     */     
/*     */ 
/*  56 */     if (this.isolation != null) { c.setTransactionIsolation(this.isolation.intValue());
/*     */     }
/*     */     
/*  59 */     if (c.getAutoCommit() != this.autocommit) { c.setAutoCommit(this.autocommit);
/*     */     }
/*     */     
/*  62 */     return c;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void closeConnection(Connection conn)
/*     */     throws SQLException
/*     */   {
/*  71 */     conn.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void configure(Properties props)
/*     */     throws HibernateException
/*     */   {
/*  81 */     String jaxpFile = props.getProperty("hibernate.proxool.xml");
/*  82 */     String propFile = props.getProperty("hibernate.proxool.properties");
/*  83 */     String externalConfig = props.getProperty("hibernate.proxool.existing_pool");
/*     */     
/*     */ 
/*  86 */     this.proxoolAlias = props.getProperty("hibernate.proxool.pool_alias");
/*     */     
/*     */ 
/*     */ 
/*  90 */     if ("true".equals(externalConfig))
/*     */     {
/*     */ 
/*  93 */       if (!StringHelper.isNotEmpty(this.proxoolAlias)) {
/*  94 */         String msg = "Cannot configure Proxool Provider to use an existing in memory pool without the hibernate.proxool.pool_alias property set.";
/*  95 */         log.fatal(msg);
/*  96 */         throw new HibernateException(msg);
/*     */       }
/*     */       
/*  99 */       this.proxoolAlias = ("proxool." + this.proxoolAlias);
/*     */       
/*     */ 
/* 102 */       this.existingPool = true;
/*     */       
/* 104 */       log.info("Configuring Proxool Provider using existing pool in memory: " + this.proxoolAlias);
/*     */ 
/*     */ 
/*     */     }
/* 108 */     else if (StringHelper.isNotEmpty(jaxpFile))
/*     */     {
/* 110 */       log.info("Configuring Proxool Provider using JAXPConfigurator: " + jaxpFile);
/*     */       
/*     */ 
/* 113 */       if (!StringHelper.isNotEmpty(this.proxoolAlias)) {
/* 114 */         String msg = "Cannot configure Proxool Provider to use JAXP without the hibernate.proxool.pool_alias property set.";
/* 115 */         log.fatal(msg);
/* 116 */         throw new HibernateException(msg);
/*     */       }
/*     */       try
/*     */       {
/* 120 */         JAXPConfigurator.configure(ConfigHelper.getConfigStreamReader(jaxpFile), false);
/*     */       }
/*     */       catch (ProxoolException e) {
/* 123 */         String msg = "Proxool Provider unable to load JAXP configurator file: " + jaxpFile;
/* 124 */         log.fatal(msg, e);
/* 125 */         throw new HibernateException(msg, e);
/*     */       }
/*     */       
/*     */ 
/* 129 */       this.proxoolAlias = ("proxool." + this.proxoolAlias);
/* 130 */       log.info("Configuring Proxool Provider to use pool alias: " + this.proxoolAlias);
/*     */ 
/*     */ 
/*     */     }
/* 134 */     else if (StringHelper.isNotEmpty(propFile))
/*     */     {
/* 136 */       log.info("Configuring Proxool Provider using Properties File: " + propFile);
/*     */       
/*     */ 
/* 139 */       if (!StringHelper.isNotEmpty(this.proxoolAlias)) {
/* 140 */         String msg = "Cannot configure Proxool Provider to use Properties File without the hibernate.proxool.pool_alias property set.";
/* 141 */         log.fatal(msg);
/* 142 */         throw new HibernateException(msg);
/*     */       }
/*     */       try
/*     */       {
/* 146 */         PropertyConfigurator.configure(ConfigHelper.getConfigProperties(propFile));
/*     */       }
/*     */       catch (ProxoolException e) {
/* 149 */         String msg = "Proxool Provider unable to load load Property configurator file: " + propFile;
/* 150 */         log.fatal(msg, e);
/* 151 */         throw new HibernateException(msg, e);
/*     */       }
/*     */       
/*     */ 
/* 155 */       this.proxoolAlias = ("proxool." + this.proxoolAlias);
/* 156 */       log.info("Configuring Proxool Provider to use pool alias: " + this.proxoolAlias);
/*     */     }
/*     */     
/*     */ 
/* 160 */     this.isolation = PropertiesHelper.getInteger("hibernate.connection.isolation", props);
/* 161 */     if (this.isolation != null) {
/* 162 */       log.info("JDBC isolation level: " + Environment.isolationLevelToString(this.isolation.intValue()));
/*     */     }
/*     */     
/* 165 */     this.autocommit = PropertiesHelper.getBoolean("hibernate.connection.autocommit", props);
/* 166 */     log.info("autocommit mode: " + this.autocommit);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws HibernateException
/*     */   {
/* 176 */     if (this.existingPool) {
/* 177 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 182 */       ProxoolFacade.shutdown(0);
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 187 */       log.warn("Exception occured when closing the Proxool pool", e);
/* 188 */       throw new HibernateException("Exception occured when closing the Proxool pool", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean supportsAggressiveRelease()
/*     */   {
/* 196 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\connection\ProxoolConnectionProvider.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */