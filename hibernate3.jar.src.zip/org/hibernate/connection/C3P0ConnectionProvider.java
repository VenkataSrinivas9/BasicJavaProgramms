/*     */ package org.hibernate.connection;
/*     */ 
/*     */ import com.mchange.v2.c3p0.DataSources;
/*     */ import com.mchange.v2.c3p0.PoolConfig;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.cfg.Environment;
/*     */ import org.hibernate.util.PropertiesHelper;
/*     */ import org.hibernate.util.ReflectHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class C3P0ConnectionProvider
/*     */   implements ConnectionProvider
/*     */ {
/*     */   private DataSource ds;
/*     */   private Integer isolation;
/*     */   private boolean autocommit;
/*  32 */   private static final Log log = LogFactory.getLog(C3P0ConnectionProvider.class);
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/*  35 */     Connection c = this.ds.getConnection();
/*  36 */     if (this.isolation != null) c.setTransactionIsolation(this.isolation.intValue());
/*  37 */     if (c.getAutoCommit() != this.autocommit) c.setAutoCommit(this.autocommit);
/*  38 */     return c;
/*     */   }
/*     */   
/*     */   public void closeConnection(Connection conn) throws SQLException {
/*  42 */     conn.close();
/*     */   }
/*     */   
/*     */   public void configure(Properties props) throws HibernateException {
/*  46 */     String jdbcDriverClass = props.getProperty("hibernate.connection.driver_class");
/*  47 */     String jdbcUrl = props.getProperty("hibernate.connection.url");
/*  48 */     Properties connectionProps = ConnectionProviderFactory.getConnectionProperties(props);
/*     */     
/*  50 */     log.info("C3P0 using driver: " + jdbcDriverClass + " at URL: " + jdbcUrl);
/*  51 */     log.info("Connection properties: " + PropertiesHelper.maskOut(connectionProps, "password"));
/*     */     
/*  53 */     this.autocommit = PropertiesHelper.getBoolean("hibernate.connection.autocommit", props);
/*  54 */     log.info("autocommit mode: " + this.autocommit);
/*     */     
/*  56 */     if (jdbcDriverClass == null) {
/*  57 */       log.warn("No JDBC Driver class was specified by property hibernate.connection.driver_class");
/*     */     } else {
/*     */       try
/*     */       {
/*  61 */         Class.forName(jdbcDriverClass);
/*     */       }
/*     */       catch (ClassNotFoundException cnfe) {
/*     */         try {
/*  65 */           ReflectHelper.classForName(jdbcDriverClass);
/*     */         }
/*     */         catch (ClassNotFoundException e) {
/*  68 */           String msg = "JDBC Driver class not found: " + jdbcDriverClass;
/*  69 */           log.fatal(msg, e);
/*  70 */           throw new HibernateException(msg, e);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*  77 */       int minPoolSize = PropertiesHelper.getInt("hibernate.c3p0.min_size", props, 1);
/*  78 */       int maxPoolSize = PropertiesHelper.getInt("hibernate.c3p0.max_size", props, 100);
/*  79 */       int maxIdleTime = PropertiesHelper.getInt("hibernate.c3p0.timeout", props, 0);
/*  80 */       int maxStatements = PropertiesHelper.getInt("hibernate.c3p0.max_statements", props, 0);
/*  81 */       int acquireIncrement = PropertiesHelper.getInt("hibernate.c3p0.acquire_increment", props, 1);
/*  82 */       int idleTestPeriod = PropertiesHelper.getInt("hibernate.c3p0.idle_test_period", props, 0);
/*     */       
/*  84 */       PoolConfig pcfg = new PoolConfig();
/*  85 */       pcfg.setInitialPoolSize(minPoolSize);
/*  86 */       pcfg.setMinPoolSize(minPoolSize);
/*  87 */       pcfg.setMaxPoolSize(maxPoolSize);
/*  88 */       pcfg.setAcquireIncrement(acquireIncrement);
/*  89 */       pcfg.setMaxIdleTime(maxIdleTime);
/*  90 */       pcfg.setMaxStatements(maxStatements);
/*  91 */       pcfg.setIdleConnectionTestPeriod(idleTestPeriod);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  96 */       DataSource unpooled = DataSources.unpooledDataSource(jdbcUrl, connectionProps);
/*  97 */       this.ds = DataSources.pooledDataSource(unpooled, pcfg);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 101 */       log.fatal("could not instantiate C3P0 connection pool", e);
/* 102 */       throw new HibernateException("Could not instantiate C3P0 connection pool", e);
/*     */     }
/*     */     
/* 105 */     String i = props.getProperty("hibernate.connection.isolation");
/* 106 */     if (i == null) {
/* 107 */       this.isolation = null;
/*     */     }
/*     */     else {
/* 110 */       this.isolation = new Integer(i);
/* 111 */       log.info("JDBC isolation level: " + Environment.isolationLevelToString(this.isolation.intValue()));
/*     */     }
/*     */   }
/*     */   
/*     */   public void close()
/*     */   {
/*     */     try {
/* 118 */       DataSources.destroy(this.ds);
/*     */     }
/*     */     catch (SQLException sqle) {
/* 121 */       log.warn("could not destroy C3P0 connection pool", sqle);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean supportsAggressiveRelease()
/*     */   {
/* 129 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\connection\C3P0ConnectionProvider.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */