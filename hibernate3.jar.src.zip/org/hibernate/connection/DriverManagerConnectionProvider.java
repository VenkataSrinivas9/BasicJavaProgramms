/*     */ package org.hibernate.connection;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.cfg.Environment;
/*     */ import org.hibernate.util.PropertiesHelper;
/*     */ import org.hibernate.util.ReflectHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DriverManagerConnectionProvider
/*     */   implements ConnectionProvider
/*     */ {
/*     */   private String url;
/*     */   private Properties connectionProps;
/*     */   private Integer isolation;
/*  29 */   private final ArrayList pool = new ArrayList();
/*     */   private int poolSize;
/*  31 */   private int checkedOut = 0;
/*     */   
/*     */   private boolean autocommit;
/*  34 */   private static final Log log = LogFactory.getLog(DriverManagerConnectionProvider.class);
/*     */   
/*     */   public void configure(Properties props) throws HibernateException
/*     */   {
/*  38 */     String driverClass = props.getProperty("hibernate.connection.driver_class");
/*     */     
/*  40 */     this.poolSize = PropertiesHelper.getInt("hibernate.connection.pool_size", props, 20);
/*  41 */     log.info("Using Hibernate built-in connection pool (not for production use!)");
/*  42 */     log.info("Hibernate connection pool size: " + this.poolSize);
/*     */     
/*  44 */     this.autocommit = PropertiesHelper.getBoolean("hibernate.connection.autocommit", props);
/*  45 */     log.info("autocommit mode: " + this.autocommit);
/*     */     
/*  47 */     this.isolation = PropertiesHelper.getInteger("hibernate.connection.isolation", props);
/*  48 */     if (this.isolation != null) {
/*  49 */       log.info("JDBC isolation level: " + Environment.isolationLevelToString(this.isolation.intValue()));
/*     */     }
/*  51 */     if (driverClass == null) {
/*  52 */       log.warn("no JDBC Driver class was specified by property hibernate.connection.driver_class");
/*     */     }
/*     */     else {
/*     */       try
/*     */       {
/*  57 */         Class.forName(driverClass);
/*     */       }
/*     */       catch (ClassNotFoundException cnfe) {
/*     */         try {
/*  61 */           ReflectHelper.classForName(driverClass);
/*     */         }
/*     */         catch (ClassNotFoundException e) {
/*  64 */           String msg = "JDBC Driver class not found: " + driverClass;
/*  65 */           log.fatal(msg, e);
/*  66 */           throw new HibernateException(msg, e);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  71 */     this.url = props.getProperty("hibernate.connection.url");
/*  72 */     if (this.url == null) {
/*  73 */       String msg = "JDBC URL was not specified by property hibernate.connection.url";
/*  74 */       log.fatal(msg);
/*  75 */       throw new HibernateException(msg);
/*     */     }
/*     */     
/*  78 */     this.connectionProps = ConnectionProviderFactory.getConnectionProperties(props);
/*     */     
/*  80 */     log.info("using driver: " + driverClass + " at URL: " + this.url);
/*     */     
/*  82 */     if (log.isDebugEnabled()) {
/*  83 */       log.info("connection properties: " + this.connectionProps);
/*     */     }
/*  85 */     else if (log.isInfoEnabled()) {
/*  86 */       log.info("connection properties: " + PropertiesHelper.maskOut(this.connectionProps, "password"));
/*     */     }
/*     */   }
/*     */   
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/*  93 */     if (log.isTraceEnabled()) { log.trace("total checked-out connections: " + this.checkedOut);
/*     */     }
/*  95 */     synchronized (this.pool) {
/*  96 */       if (!this.pool.isEmpty()) {
/*  97 */         int last = this.pool.size() - 1;
/*  98 */         if (log.isTraceEnabled()) {
/*  99 */           log.trace("using pooled JDBC connection, pool size: " + last);
/* 100 */           this.checkedOut += 1;
/*     */         }
/* 102 */         Connection pooled = (Connection)this.pool.remove(last);
/* 103 */         if (this.isolation != null) pooled.setTransactionIsolation(this.isolation.intValue());
/* 104 */         if (pooled.getAutoCommit() != this.autocommit) pooled.setAutoCommit(this.autocommit);
/* 105 */         return pooled;
/*     */       }
/*     */     }
/*     */     
/* 109 */     log.debug("opening new JDBC connection");
/* 110 */     Connection conn = DriverManager.getConnection(this.url, this.connectionProps);
/* 111 */     if (this.isolation != null) conn.setTransactionIsolation(this.isolation.intValue());
/* 112 */     if (conn.getAutoCommit() != this.autocommit) { conn.setAutoCommit(this.autocommit);
/*     */     }
/* 114 */     if (log.isDebugEnabled()) {
/* 115 */       log.debug("created connection to: " + this.url + ", Isolation Level: " + conn.getTransactionIsolation());
/*     */     }
/* 117 */     if (log.isTraceEnabled()) { this.checkedOut += 1;
/*     */     }
/* 119 */     return conn;
/*     */   }
/*     */   
/*     */   public void closeConnection(Connection conn) throws SQLException
/*     */   {
/* 124 */     if (log.isDebugEnabled()) { this.checkedOut -= 1;
/*     */     }
/* 126 */     synchronized (this.pool) {
/* 127 */       int currentSize = this.pool.size();
/* 128 */       if (currentSize < this.poolSize) {
/* 129 */         if (log.isTraceEnabled()) log.trace("returning connection to pool, pool size: " + (currentSize + 1));
/* 130 */         this.pool.add(conn);
/* 131 */         return;
/*     */       }
/*     */     }
/*     */     
/* 135 */     log.debug("closing JDBC connection");
/*     */     
/* 137 */     conn.close();
/*     */   }
/*     */   
/*     */   protected void finalize()
/*     */   {
/* 142 */     close();
/*     */   }
/*     */   
/*     */   public void close()
/*     */   {
/* 147 */     log.info("cleaning up connection pool: " + this.url);
/*     */     
/* 149 */     Iterator iter = this.pool.iterator();
/* 150 */     while (iter.hasNext()) {
/*     */       try {
/* 152 */         ((Connection)iter.next()).close();
/*     */       }
/*     */       catch (SQLException sqle) {
/* 155 */         log.warn("problem closing pooled connection", sqle);
/*     */       }
/*     */     }
/* 158 */     this.pool.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsAggressiveRelease()
/*     */   {
/* 166 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\connection\DriverManagerConnectionProvider.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */