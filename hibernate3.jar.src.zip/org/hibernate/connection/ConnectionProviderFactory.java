/*     */ package org.hibernate.connection;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.cfg.Environment;
/*     */ import org.hibernate.util.ReflectHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConnectionProviderFactory
/*     */ {
/*  37 */   private static final Log log = LogFactory.getLog(ConnectionProviderFactory.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ConnectionProvider newConnectionProvider()
/*     */     throws HibernateException
/*     */   {
/*  45 */     return newConnectionProvider(Environment.getProperties());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ConnectionProvider newConnectionProvider(Properties properties)
/*     */     throws HibernateException
/*     */   {
/*  56 */     return newConnectionProvider(properties, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ConnectionProvider newConnectionProvider(Properties properties, Map connectionProviderInjectionData)
/*     */     throws HibernateException
/*     */   {
/*  69 */     String providerClass = properties.getProperty("hibernate.connection.provider_class");
/*  70 */     ConnectionProvider connections; if (providerClass != null) {
/*     */       try {
/*  72 */         log.info("Initializing connection provider: " + providerClass);
/*  73 */         connections = (ConnectionProvider)ReflectHelper.classForName(providerClass).newInstance();
/*     */       } catch (Exception e) {
/*     */         ConnectionProvider connections;
/*  76 */         log.fatal("Could not instantiate connection provider", e);
/*  77 */         throw new HibernateException("Could not instantiate connection provider: " + providerClass);
/*     */       }
/*     */     } else { ConnectionProvider connections;
/*  80 */       if (properties.getProperty("hibernate.connection.datasource") != null) {
/*  81 */         connections = new DatasourceConnectionProvider();
/*     */       } else { ConnectionProvider connections;
/*  83 */         if (properties.getProperty("hibernate.c3p0.max_size") != null) {
/*  84 */           connections = new C3P0ConnectionProvider();
/*     */         } else { ConnectionProvider connections;
/*  86 */           if ((properties.getProperty("hibernate.proxool.xml") != null) || (properties.getProperty("hibernate.proxool.properties") != null) || (properties.getProperty("hibernate.proxool.existing_pool") != null))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*  91 */             connections = new ProxoolConnectionProvider();
/*     */           } else { ConnectionProvider connections;
/*  93 */             if (properties.getProperty("hibernate.connection.url") != null) {
/*  94 */               connections = new DriverManagerConnectionProvider();
/*     */             }
/*     */             else
/*  97 */               connections = new UserSuppliedConnectionProvider();
/*     */           }
/*     */         } } }
/* 100 */     if ((connectionProviderInjectionData != null) && (connectionProviderInjectionData.size() != 0)) {
/*     */       try
/*     */       {
/* 103 */         BeanInfo info = Introspector.getBeanInfo(connections.getClass());
/* 104 */         PropertyDescriptor[] descritors = info.getPropertyDescriptors();
/* 105 */         int size = descritors.length;
/* 106 */         for (int index = 0; index < size; index++) {
/* 107 */           String propertyName = descritors[index].getName();
/* 108 */           if (connectionProviderInjectionData.containsKey(propertyName)) {
/* 109 */             Method method = descritors[index].getWriteMethod();
/* 110 */             method.invoke(connections, new Object[] { connectionProviderInjectionData.get(propertyName) });
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (IntrospectionException e) {
/* 115 */         throw new HibernateException("Unable to inject objects into the conenction provider", e);
/*     */       }
/*     */       catch (IllegalAccessException e) {
/* 118 */         throw new HibernateException("Unable to inject objects into the conenction provider", e);
/*     */       }
/*     */       catch (InvocationTargetException e) {
/* 121 */         throw new HibernateException("Unable to inject objects into the conenction provider", e);
/*     */       }
/*     */     }
/* 124 */     connections.configure(properties);
/* 125 */     return connections;
/*     */   }
/*     */   
/*     */   private ConnectionProviderFactory() {
/* 129 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Properties getConnectionProperties(Properties properties)
/*     */   {
/* 139 */     Iterator iter = properties.keySet().iterator();
/* 140 */     Properties result = new Properties();
/* 141 */     while (iter.hasNext()) {
/* 142 */       String prop = (String)iter.next();
/* 143 */       if ((prop.indexOf("hibernate.connection") > -1) && (!SPECIAL_PROPERTIES.contains(prop))) {
/* 144 */         result.setProperty(prop.substring("hibernate.connection".length() + 1), properties.getProperty(prop));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 150 */     String userName = properties.getProperty("hibernate.connection.username");
/* 151 */     if (userName != null) result.setProperty("user", userName);
/* 152 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 157 */   private static final Set SPECIAL_PROPERTIES = new HashSet();
/* 158 */   static { SPECIAL_PROPERTIES.add("hibernate.connection.datasource");
/* 159 */     SPECIAL_PROPERTIES.add("hibernate.connection.url");
/* 160 */     SPECIAL_PROPERTIES.add("hibernate.connection.provider_class");
/* 161 */     SPECIAL_PROPERTIES.add("hibernate.connection.pool_size");
/* 162 */     SPECIAL_PROPERTIES.add("hibernate.connection.isolation");
/* 163 */     SPECIAL_PROPERTIES.add("hibernate.connection.driver_class");
/* 164 */     SPECIAL_PROPERTIES.add("hibernate.connection.username");
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\connection\ConnectionProviderFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */