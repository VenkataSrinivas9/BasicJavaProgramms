/*    */ package org.hibernate.connection;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.util.Properties;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.util.NamingHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DatasourceConnectionProvider
/*    */   implements ConnectionProvider
/*    */ {
/*    */   private DataSource ds;
/*    */   private String user;
/*    */   private String pass;
/* 29 */   private static final Log log = LogFactory.getLog(DatasourceConnectionProvider.class);
/*    */   
/*    */   protected DataSource getDataSource() {
/* 32 */     return this.ds;
/*    */   }
/*    */   
/*    */   protected void setDataSource(DataSource ds) {
/* 36 */     this.ds = ds;
/*    */   }
/*    */   
/*    */   public void configure(Properties props) throws HibernateException
/*    */   {
/* 41 */     String jndiName = props.getProperty("hibernate.connection.datasource");
/* 42 */     if (jndiName == null) {
/* 43 */       String msg = "datasource JNDI name was not specified by property hibernate.connection.datasource";
/* 44 */       log.fatal(msg);
/* 45 */       throw new HibernateException(msg);
/*    */     }
/*    */     
/* 48 */     this.user = props.getProperty("hibernate.connection.username");
/* 49 */     this.pass = props.getProperty("hibernate.connection.password");
/*    */     try
/*    */     {
/* 52 */       this.ds = ((DataSource)NamingHelper.getInitialContext(props).lookup(jndiName));
/*    */     }
/*    */     catch (Exception e) {
/* 55 */       log.fatal("Could not find datasource: " + jndiName, e);
/* 56 */       throw new HibernateException("Could not find datasource", e);
/*    */     }
/* 58 */     if (this.ds == null) {
/* 59 */       throw new HibernateException("Could not find datasource: " + jndiName);
/*    */     }
/* 61 */     log.info("Using datasource: " + jndiName);
/*    */   }
/*    */   
/*    */   public Connection getConnection() throws SQLException {
/* 65 */     if ((this.user != null) || (this.pass != null)) {
/* 66 */       return this.ds.getConnection(this.user, this.pass);
/*    */     }
/*    */     
/* 69 */     return this.ds.getConnection();
/*    */   }
/*    */   
/*    */   public void closeConnection(Connection conn) throws SQLException
/*    */   {
/* 74 */     conn.close();
/*    */   }
/*    */   
/*    */ 
/*    */   public void close() {}
/*    */   
/*    */ 
/*    */   public boolean supportsAggressiveRelease()
/*    */   {
/* 83 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\connection\DatasourceConnectionProvider.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */