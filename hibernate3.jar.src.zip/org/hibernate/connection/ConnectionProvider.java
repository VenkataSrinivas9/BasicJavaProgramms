package org.hibernate.connection;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import org.hibernate.HibernateException;

public abstract interface ConnectionProvider
{
  public abstract void configure(Properties paramProperties)
    throws HibernateException;
  
  public abstract Connection getConnection()
    throws SQLException;
  
  public abstract void closeConnection(Connection paramConnection)
    throws SQLException;
  
  public abstract void close()
    throws HibernateException;
  
  public abstract boolean supportsAggressiveRelease();
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\connection\ConnectionProvider.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */