/*    */ package org.hibernate.connection;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.util.Properties;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.HibernateException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserSuppliedConnectionProvider
/*    */   implements ConnectionProvider
/*    */ {
/*    */   public void configure(Properties props)
/*    */     throws HibernateException
/*    */   {
/* 23 */     LogFactory.getLog(UserSuppliedConnectionProvider.class).warn("No connection properties specified - the user must supply JDBC connections");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Connection getConnection()
/*    */   {
/* 30 */     throw new UnsupportedOperationException("The user must supply a JDBC connection");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void closeConnection(Connection conn)
/*    */   {
/* 37 */     throw new UnsupportedOperationException("The user must supply a JDBC connection");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void close() {}
/*    */   
/*    */ 
/*    */   public boolean supportsAggressiveRelease()
/*    */   {
/* 47 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\connection\UserSuppliedConnectionProvider.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */