/*     */ package org.hibernate.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.hibernate.FlushMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.LockMode;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.SQLQuery;
/*     */ import org.hibernate.ScrollMode;
/*     */ import org.hibernate.ScrollableResults;
/*     */ import org.hibernate.engine.NamedSQLQueryDefinition;
/*     */ import org.hibernate.engine.QueryParameters;
/*     */ import org.hibernate.engine.ResultSetMappingDefinition;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.engine.query.NativeSQLQuerySpecification;
/*     */ import org.hibernate.engine.query.ParameterMetadata;
/*     */ import org.hibernate.loader.custom.SQLQueryJoinReturn;
/*     */ import org.hibernate.loader.custom.SQLQueryReturn;
/*     */ import org.hibernate.loader.custom.SQLQueryRootReturn;
/*     */ import org.hibernate.loader.custom.SQLQueryScalarReturn;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.CollectionHelper;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLQueryImpl
/*     */   extends AbstractQueryImpl
/*     */   implements SQLQuery
/*     */ {
/*     */   private final List queryReturns;
/*     */   private final List scalarQueryReturns;
/*     */   private final Collection querySpaces;
/*     */   private final boolean callable;
/*     */   private boolean autodiscovertypes;
/*     */   
/*     */   SQLQueryImpl(NamedSQLQueryDefinition queryDef, SessionImplementor session, ParameterMetadata parameterMetadata)
/*     */   {
/*  62 */     super(queryDef.getQueryString(), queryDef.getFlushMode(), session, parameterMetadata);
/*  63 */     if (queryDef.getResultSetRef() != null) {
/*  64 */       ResultSetMappingDefinition definition = session.getFactory().getResultSetMapping(queryDef.getResultSetRef());
/*     */       
/*  66 */       if (definition == null) {
/*  67 */         throw new MappingException("Unable to find resultset-ref definition: " + queryDef.getResultSetRef());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*  72 */       this.scalarQueryReturns = Arrays.asList(definition.getScalarQueryReturns());
/*  73 */       this.queryReturns = Arrays.asList(definition.getEntityQueryReturns());
/*     */     }
/*     */     else {
/*  76 */       this.scalarQueryReturns = Arrays.asList(queryDef.getScalarQueryReturns());
/*  77 */       this.queryReturns = Arrays.asList(queryDef.getQueryReturns());
/*     */     }
/*     */     
/*  80 */     this.querySpaces = queryDef.getQuerySpaces();
/*  81 */     this.callable = queryDef.isCallable();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   SQLQueryImpl(String sql, List queryReturns, List scalarQueryReturns, Collection querySpaces, FlushMode flushMode, boolean callable, SessionImplementor session, ParameterMetadata parameterMetadata)
/*     */   {
/*  94 */     super(sql, flushMode, session, parameterMetadata);
/*  95 */     this.queryReturns = queryReturns;
/*  96 */     this.scalarQueryReturns = scalarQueryReturns;
/*  97 */     this.querySpaces = querySpaces;
/*  98 */     this.callable = callable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   SQLQueryImpl(String sql, String[] returnAliases, Class[] returnClasses, LockMode[] lockModes, SessionImplementor session, Collection querySpaces, FlushMode flushMode, ParameterMetadata parameterMetadata)
/*     */   {
/* 111 */     super(sql, flushMode, session, parameterMetadata);
/* 112 */     this.scalarQueryReturns = null;
/* 113 */     this.queryReturns = new ArrayList(returnAliases.length);
/* 114 */     for (int i = 0; i < returnAliases.length; i++) {
/* 115 */       SQLQueryRootReturn ret = new SQLQueryRootReturn(returnAliases[i], returnClasses[i].getName(), lockModes == null ? LockMode.NONE : lockModes[i]);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 120 */       this.queryReturns.add(ret);
/*     */     }
/* 122 */     this.querySpaces = querySpaces;
/* 123 */     this.callable = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   SQLQueryImpl(String sql, String[] returnAliases, Class[] returnClasses, SessionImplementor session, ParameterMetadata parameterMetadata)
/*     */   {
/* 132 */     this(sql, returnAliases, returnClasses, null, session, null, null, parameterMetadata);
/*     */   }
/*     */   
/*     */   SQLQueryImpl(String sql, SessionImplementor session, ParameterMetadata parameterMetadata) {
/* 136 */     super(sql, null, session, parameterMetadata);
/* 137 */     this.queryReturns = new ArrayList();
/* 138 */     this.scalarQueryReturns = new ArrayList();
/* 139 */     this.querySpaces = null;
/* 140 */     this.callable = false;
/*     */   }
/*     */   
/* 143 */   private static final SQLQueryReturn[] NO_SQL_RETURNS = new SQLQueryReturn[0];
/* 144 */   private static final SQLQueryScalarReturn[] NO_SQL_SCALAR_RETURNS = new SQLQueryScalarReturn[0];
/*     */   
/*     */   private SQLQueryReturn[] getQueryReturns() {
/* 147 */     return (SQLQueryReturn[])this.queryReturns.toArray(NO_SQL_RETURNS);
/*     */   }
/*     */   
/*     */   private SQLQueryScalarReturn[] getQueryScalarReturns() {
/* 151 */     return this.scalarQueryReturns == null ? null : (SQLQueryScalarReturn[])this.scalarQueryReturns.toArray(NO_SQL_SCALAR_RETURNS);
/*     */   }
/*     */   
/*     */   public List list()
/*     */     throws HibernateException
/*     */   {
/* 157 */     verifyParameters();
/* 158 */     before();
/*     */     
/* 160 */     Map namedParams = getNamedParams();
/* 161 */     NativeSQLQuerySpecification spec = generateQuerySpecification(namedParams);
/*     */     try
/*     */     {
/* 164 */       return getSession().list(spec, getQueryParameters(namedParams));
/*     */     }
/*     */     finally {
/* 167 */       after();
/*     */     }
/*     */   }
/*     */   
/*     */   private NativeSQLQuerySpecification generateQuerySpecification(Map namedParams) {
/* 172 */     return new NativeSQLQuerySpecification(expandParameterLists(namedParams), getQueryReturns(), getQueryScalarReturns(), this.querySpaces);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ScrollableResults scroll(ScrollMode scrollMode)
/*     */     throws HibernateException
/*     */   {
/* 181 */     verifyParameters();
/* 182 */     before();
/*     */     
/* 184 */     Map namedParams = getNamedParams();
/* 185 */     NativeSQLQuerySpecification spec = generateQuerySpecification(namedParams);
/*     */     
/* 187 */     QueryParameters qp = getQueryParameters(namedParams);
/* 188 */     qp.setScrollMode(scrollMode);
/*     */     try
/*     */     {
/* 191 */       return getSession().scroll(spec, qp);
/*     */     }
/*     */     finally {
/* 194 */       after();
/*     */     }
/*     */   }
/*     */   
/*     */   public ScrollableResults scroll() throws HibernateException {
/* 199 */     return scroll(ScrollMode.SCROLL_INSENSITIVE);
/*     */   }
/*     */   
/*     */   public Iterator iterate() throws HibernateException {
/* 203 */     throw new UnsupportedOperationException("SQL queries do not currently support iteration");
/*     */   }
/*     */   
/*     */   public QueryParameters getQueryParameters(Map namedParams) {
/* 207 */     QueryParameters qp = super.getQueryParameters(namedParams);
/* 208 */     qp.setCallable(this.callable);
/* 209 */     qp.setAutoDiscoverScalarTypes(this.autodiscovertypes);
/* 210 */     return qp;
/*     */   }
/*     */   
/*     */   protected void verifyParameters() {
/* 214 */     verifyParameters(this.callable);
/* 215 */     boolean noReturns = ((this.queryReturns == null) || (this.queryReturns.isEmpty())) && ((this.scalarQueryReturns == null) || (this.scalarQueryReturns.isEmpty()));
/*     */     
/* 217 */     if (noReturns) {
/* 218 */       this.autodiscovertypes = noReturns;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 225 */     else if (this.scalarQueryReturns != null) {
/* 226 */       Iterator iter = this.scalarQueryReturns.iterator();
/* 227 */       while (iter.hasNext()) {
/* 228 */         SQLQueryScalarReturn scalar = (SQLQueryScalarReturn)iter.next();
/* 229 */         if (scalar.getType() == null) this.autodiscovertypes = true;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String[] getReturnAliases() throws HibernateException
/*     */   {
/* 236 */     throw new UnsupportedOperationException("SQL queries do not currently support returning aliases");
/*     */   }
/*     */   
/*     */   public Type[] getReturnTypes() throws HibernateException {
/* 240 */     throw new UnsupportedOperationException("not yet implemented for SQL queries");
/*     */   }
/*     */   
/*     */   public Query setLockMode(String alias, LockMode lockMode) {
/* 244 */     throw new UnsupportedOperationException("cannot set the lock mode for a native SQL query");
/*     */   }
/*     */   
/*     */   protected Map getLockModes()
/*     */   {
/* 249 */     return CollectionHelper.EMPTY_MAP;
/*     */   }
/*     */   
/*     */   public SQLQuery addScalar(String columnAlias, Type type) {
/* 253 */     this.scalarQueryReturns.add(new SQLQueryScalarReturn(columnAlias, type));
/* 254 */     return this;
/*     */   }
/*     */   
/*     */   public SQLQuery addScalar(String columnAlias) {
/* 258 */     this.autodiscovertypes = true;
/* 259 */     this.scalarQueryReturns.add(new SQLQueryScalarReturn(columnAlias, null));
/* 260 */     return this;
/*     */   }
/*     */   
/*     */   public SQLQuery addJoin(String alias, String path) {
/* 264 */     return addJoin(alias, path, LockMode.READ);
/*     */   }
/*     */   
/*     */   public SQLQuery addEntity(Class entityClass) {
/* 268 */     return addEntity(StringHelper.unqualify(entityClass.getName()), entityClass);
/*     */   }
/*     */   
/*     */   public SQLQuery addEntity(String entityName) {
/* 272 */     return addEntity(StringHelper.unqualify(entityName), entityName);
/*     */   }
/*     */   
/*     */   public SQLQuery addEntity(String alias, String entityName) {
/* 276 */     return addEntity(alias, entityName, LockMode.READ);
/*     */   }
/*     */   
/*     */   public SQLQuery addEntity(String alias, Class entityClass) {
/* 280 */     return addEntity(alias, entityClass.getName());
/*     */   }
/*     */   
/*     */   public SQLQuery addJoin(String alias, String path, LockMode lockMode) {
/* 284 */     int loc = path.indexOf('.');
/* 285 */     if (loc < 0) {
/* 286 */       throw new QueryException("not a property path: " + path);
/*     */     }
/* 288 */     String ownerAlias = path.substring(0, loc);
/* 289 */     String role = path.substring(loc + 1);
/* 290 */     this.queryReturns.add(new SQLQueryJoinReturn(alias, ownerAlias, role, CollectionHelper.EMPTY_MAP, lockMode));
/* 291 */     return this;
/*     */   }
/*     */   
/*     */   public SQLQuery addEntity(String alias, String entityName, LockMode lockMode) {
/* 295 */     this.queryReturns.add(new SQLQueryRootReturn(alias, entityName, lockMode));
/* 296 */     return this;
/*     */   }
/*     */   
/*     */   public SQLQuery addEntity(String alias, Class entityClass, LockMode lockMode) {
/* 300 */     return addEntity(alias, entityClass.getName(), lockMode);
/*     */   }
/*     */   
/*     */   public SQLQuery setResultSetMapping(String name) {
/* 304 */     ResultSetMappingDefinition mapping = this.session.getFactory().getResultSetMapping(name);
/* 305 */     if (mapping == null) {
/* 306 */       throw new MappingException("Unknown SqlResultSetMapping named:" + name);
/*     */     }
/* 308 */     SQLQueryReturn[] returns = mapping.getEntityQueryReturns();
/* 309 */     int length = returns.length;
/* 310 */     for (int index = 0; index < length; index++) {
/* 311 */       this.queryReturns.add(returns[index]);
/*     */     }
/* 313 */     SQLQueryScalarReturn[] scalarReturns = mapping.getScalarQueryReturns();
/* 314 */     length = scalarReturns.length;
/* 315 */     for (int index = 0; index < length; index++) {
/* 316 */       this.scalarQueryReturns.add(scalarReturns[index]);
/*     */     }
/* 318 */     return this;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\impl\SQLQueryImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */