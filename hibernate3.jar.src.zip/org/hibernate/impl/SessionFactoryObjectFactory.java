/*     */ package org.hibernate.impl;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.Properties;
/*     */ import javax.naming.Binding;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.InvalidNameException;
/*     */ import javax.naming.Name;
/*     */ import javax.naming.NamingException;
/*     */ import javax.naming.RefAddr;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.event.EventContext;
/*     */ import javax.naming.event.NamespaceChangeListener;
/*     */ import javax.naming.event.NamingEvent;
/*     */ import javax.naming.event.NamingExceptionEvent;
/*     */ import javax.naming.event.NamingListener;
/*     */ import javax.naming.spi.ObjectFactory;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.hibernate.util.FastHashMap;
/*     */ import org.hibernate.util.NamingHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionFactoryObjectFactory
/*     */   implements ObjectFactory
/*     */ {
/*     */   private static final SessionFactoryObjectFactory INSTANCE;
/*  37 */   private static final Log log = LogFactory.getLog(SessionFactoryObjectFactory.class);
/*  38 */   static { INSTANCE = new SessionFactoryObjectFactory();
/*  39 */     log.debug("initializing class SessionFactoryObjectFactory");
/*     */   }
/*     */   
/*  42 */   private static final FastHashMap INSTANCES = new FastHashMap();
/*  43 */   private static final FastHashMap NAMED_INSTANCES = new FastHashMap();
/*     */   
/*  45 */   private static final NamingListener LISTENER = new NamespaceChangeListener()
/*     */   {
/*  47 */     public void objectAdded(NamingEvent evt) { SessionFactoryObjectFactory.log.debug("A factory was successfully bound to name: " + evt.getNewBinding().getName()); }
/*     */     
/*     */     public void objectRemoved(NamingEvent evt) {
/*  50 */       String name = evt.getOldBinding().getName();
/*  51 */       SessionFactoryObjectFactory.log.info("A factory was unbound from name: " + name);
/*  52 */       Object instance = SessionFactoryObjectFactory.NAMED_INSTANCES.remove(name);
/*  53 */       Iterator iter = SessionFactoryObjectFactory.INSTANCES.values().iterator();
/*  54 */       while (iter.hasNext())
/*  55 */         if (iter.next() == instance) iter.remove();
/*     */     }
/*     */     
/*     */     public void objectRenamed(NamingEvent evt) {
/*  59 */       String name = evt.getOldBinding().getName();
/*  60 */       SessionFactoryObjectFactory.log.info("A factory was renamed from name: " + name);
/*  61 */       SessionFactoryObjectFactory.NAMED_INSTANCES.put(evt.getNewBinding().getName(), SessionFactoryObjectFactory.NAMED_INSTANCES.remove(name));
/*     */     }
/*     */     
/*  64 */     public void namingExceptionThrown(NamingExceptionEvent evt) { SessionFactoryObjectFactory.log.warn("Naming exception occurred accessing factory: " + evt.getException()); }
/*     */   };
/*     */   
/*     */   public Object getObjectInstance(Object reference, Name name, Context ctx, Hashtable env) throws Exception
/*     */   {
/*  69 */     log.debug("JNDI lookup: " + name);
/*  70 */     String uid = (String)((Reference)reference).get(0).getContent();
/*  71 */     return getInstance(uid);
/*     */   }
/*     */   
/*     */   public static void addInstance(String uid, String name, SessionFactory instance, Properties properties)
/*     */   {
/*  76 */     log.debug("registered: " + uid + " (" + (name == null ? "unnamed" : name) + ')');
/*  77 */     INSTANCES.put(uid, instance);
/*  78 */     if (name != null) { NAMED_INSTANCES.put(name, instance);
/*     */     }
/*     */     
/*  81 */     if (name == null) {
/*  82 */       log.info("Not binding factory to JNDI, no JNDI name configured");
/*     */     }
/*     */     else
/*     */     {
/*  86 */       log.info("Factory name: " + name);
/*     */       try
/*     */       {
/*  89 */         Context ctx = NamingHelper.getInitialContext(properties);
/*  90 */         NamingHelper.bind(ctx, name, instance);
/*  91 */         log.info("Bound factory to JNDI name: " + name);
/*  92 */         ((EventContext)ctx).addNamingListener(name, 0, LISTENER);
/*     */       }
/*     */       catch (InvalidNameException ine) {
/*  95 */         log.error("Invalid JNDI name: " + name, ine);
/*     */       }
/*     */       catch (NamingException ne) {
/*  98 */         log.warn("Could not bind factory to JNDI", ne);
/*     */       }
/*     */       catch (ClassCastException cce) {
/* 101 */         log.warn("InitialContext did not implement EventContext");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void removeInstance(String uid, String name, Properties properties)
/*     */   {
/* 111 */     if (name != null) {
/* 112 */       log.info("Unbinding factory from JNDI name: " + name);
/*     */       try
/*     */       {
/* 115 */         Context ctx = NamingHelper.getInitialContext(properties);
/* 116 */         ctx.unbind(name);
/* 117 */         log.info("Unbound factory from JNDI name: " + name);
/*     */       }
/*     */       catch (InvalidNameException ine) {
/* 120 */         log.error("Invalid JNDI name: " + name, ine);
/*     */       }
/*     */       catch (NamingException ne) {
/* 123 */         log.warn("Could not unbind factory from JNDI", ne);
/*     */       }
/*     */       
/* 126 */       NAMED_INSTANCES.remove(name);
/*     */     }
/*     */     
/*     */ 
/* 130 */     INSTANCES.remove(uid);
/*     */   }
/*     */   
/*     */   public static Object getNamedInstance(String name)
/*     */   {
/* 135 */     log.debug("lookup: name=" + name);
/* 136 */     Object result = NAMED_INSTANCES.get(name);
/* 137 */     if (result == null) {
/* 138 */       log.warn("Not found: " + name);
/* 139 */       log.debug(NAMED_INSTANCES);
/*     */     }
/* 141 */     return result;
/*     */   }
/*     */   
/*     */   public static Object getInstance(String uid) {
/* 145 */     log.debug("lookup: uid=" + uid);
/* 146 */     Object result = INSTANCES.get(uid);
/* 147 */     if (result == null) {
/* 148 */       log.warn("Not found: " + uid);
/* 149 */       log.debug(INSTANCES);
/*     */     }
/* 151 */     return result;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\impl\SessionFactoryObjectFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */