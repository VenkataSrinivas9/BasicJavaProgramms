/*     */ package org.hibernate.impl;
/*     */ 
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.engine.QueryParameters;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.exception.JDBCExceptionHelper;
/*     */ import org.hibernate.hql.HolderInstantiator;
/*     */ import org.hibernate.loader.Loader;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FetchingScrollableResultsImpl
/*     */   extends AbstractScrollableResults
/*     */ {
/*     */   public FetchingScrollableResultsImpl(ResultSet rs, PreparedStatement ps, SessionImplementor sess, Loader loader, QueryParameters queryParameters, Type[] types, HolderInstantiator holderInstantiator)
/*     */     throws MappingException
/*     */   {
/*  32 */     super(rs, ps, sess, loader, queryParameters, types, holderInstantiator);
/*     */   }
/*     */   
/*  35 */   private Object[] currentRow = null;
/*  36 */   private int currentPosition = 0;
/*  37 */   private Integer maxPosition = null;
/*     */   
/*     */   protected Object[] getCurrentRow() {
/*  40 */     return this.currentRow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean next()
/*     */     throws HibernateException
/*     */   {
/*  49 */     if ((this.maxPosition != null) && (this.maxPosition.intValue() <= this.currentPosition)) {
/*  50 */       this.currentRow = null;
/*  51 */       this.currentPosition = (this.maxPosition.intValue() + 1);
/*  52 */       return false;
/*     */     }
/*     */     
/*  55 */     Object row = getLoader().loadSequentialRowsForward(getResultSet(), getSession(), getQueryParameters(), false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/*  65 */       afterLast = getResultSet().isAfterLast();
/*     */     } catch (SQLException e) {
/*     */       boolean afterLast;
/*  68 */       throw JDBCExceptionHelper.convert(getSession().getFactory().getSQLExceptionConverter(), e, "exception calling isAfterLast()");
/*     */     }
/*     */     
/*     */ 
/*     */     boolean afterLast;
/*     */     
/*     */ 
/*  75 */     this.currentPosition += 1;
/*  76 */     this.currentRow = new Object[] { row };
/*     */     
/*  78 */     if ((afterLast) && 
/*  79 */       (this.maxPosition == null))
/*     */     {
/*  81 */       this.maxPosition = new Integer(this.currentPosition);
/*     */     }
/*     */     
/*     */ 
/*  85 */     afterScrollOperation();
/*     */     
/*  87 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean previous()
/*     */     throws HibernateException
/*     */   {
/*  96 */     if (this.currentPosition <= 1) {
/*  97 */       this.currentPosition = 0;
/*  98 */       this.currentRow = null;
/*  99 */       return false;
/*     */     }
/*     */     
/* 102 */     Object loadResult = getLoader().loadSequentialRowsReverse(getResultSet(), getSession(), getQueryParameters(), false, (this.maxPosition != null) && (this.currentPosition > this.maxPosition.intValue()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 110 */     this.currentRow = new Object[] { loadResult };
/* 111 */     this.currentPosition -= 1;
/*     */     
/* 113 */     afterScrollOperation();
/*     */     
/* 115 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean scroll(int positions)
/*     */     throws HibernateException
/*     */   {
/* 127 */     boolean more = false;
/* 128 */     if (positions > 0)
/*     */     {
/* 130 */       for (int i = 0; i < positions; i++) {
/* 131 */         more = next();
/* 132 */         if (!more) {
/*     */           break;
/*     */         }
/*     */         
/*     */       }
/* 137 */     } else if (positions < 0)
/*     */     {
/* 139 */       for (int i = 0; i < 0 - positions; i++) {
/* 140 */         more = previous();
/* 141 */         if (!more) {
/*     */           break;
/*     */         }
/*     */         
/*     */       }
/*     */     } else {
/* 147 */       throw new HibernateException("scroll(0) not valid");
/*     */     }
/*     */     
/* 150 */     afterScrollOperation();
/*     */     
/* 152 */     return more;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean last()
/*     */     throws HibernateException
/*     */   {
/* 161 */     boolean more = false;
/* 162 */     if (this.maxPosition != null) {
/* 163 */       for (int i = this.currentPosition; i < this.maxPosition.intValue(); i++) {
/* 164 */         more = next();
/*     */       }
/*     */     } else {
/*     */       try
/*     */       {
/* 169 */         if (getResultSet().isAfterLast())
/*     */         {
/*     */ 
/* 172 */           return false;
/*     */         }
/*     */         
/* 175 */         while (!getResultSet().isAfterLast()) {
/* 176 */           more = next();
/*     */         }
/*     */       }
/*     */       catch (SQLException e) {
/* 180 */         throw JDBCExceptionHelper.convert(getSession().getFactory().getSQLExceptionConverter(), e, "exception calling isAfterLast()");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 188 */     afterScrollOperation();
/*     */     
/* 190 */     return more;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean first()
/*     */     throws HibernateException
/*     */   {
/* 199 */     beforeFirst();
/* 200 */     boolean more = next();
/*     */     
/* 202 */     afterScrollOperation();
/*     */     
/* 204 */     return more;
/*     */   }
/*     */   
/*     */   public void beforeFirst()
/*     */     throws HibernateException
/*     */   {
/*     */     try
/*     */     {
/* 212 */       getResultSet().beforeFirst();
/*     */     }
/*     */     catch (SQLException e) {
/* 215 */       throw JDBCExceptionHelper.convert(getSession().getFactory().getSQLExceptionConverter(), e, "exception calling beforeFirst()");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 221 */     this.currentRow = null;
/* 222 */     this.currentPosition = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterLast()
/*     */     throws HibernateException
/*     */   {
/* 231 */     last();
/* 232 */     next();
/* 233 */     afterScrollOperation();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFirst()
/*     */     throws HibernateException
/*     */   {
/* 244 */     return this.currentPosition == 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLast()
/*     */     throws HibernateException
/*     */   {
/* 255 */     if (this.maxPosition == null)
/*     */     {
/* 257 */       return false;
/*     */     }
/*     */     
/* 260 */     return this.currentPosition == this.maxPosition.intValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRowNumber()
/*     */     throws HibernateException
/*     */   {
/* 270 */     return this.currentPosition;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean setRowNumber(int rowNumber)
/*     */     throws HibernateException
/*     */   {
/* 282 */     if (rowNumber == 1) {
/* 283 */       return first();
/*     */     }
/* 285 */     if (rowNumber == -1) {
/* 286 */       return last();
/*     */     }
/* 288 */     if ((this.maxPosition != null) && (rowNumber == this.maxPosition.intValue())) {
/* 289 */       return last();
/*     */     }
/* 291 */     return scroll(rowNumber - this.currentPosition);
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\impl\FetchingScrollableResultsImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */