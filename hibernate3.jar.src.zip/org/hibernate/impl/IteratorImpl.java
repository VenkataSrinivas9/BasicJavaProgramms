/*     */ package org.hibernate.impl;
/*     */ 
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.NoSuchElementException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.JDBCException;
/*     */ import org.hibernate.engine.HibernateIterator;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.event.EventSource;
/*     */ import org.hibernate.exception.JDBCExceptionHelper;
/*     */ import org.hibernate.hql.HolderInstantiator;
/*     */ import org.hibernate.jdbc.Batcher;
/*     */ import org.hibernate.type.EntityType;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class IteratorImpl
/*     */   implements HibernateIterator
/*     */ {
/*  27 */   private static final Log log = LogFactory.getLog(IteratorImpl.class);
/*     */   
/*     */   private ResultSet rs;
/*     */   
/*     */   private final EventSource session;
/*     */   
/*     */   private final Type[] types;
/*     */   
/*     */   private final boolean single;
/*     */   
/*     */   private Object currentResult;
/*     */   
/*     */   private boolean hasNext;
/*     */   
/*     */   private final String[][] names;
/*     */   private PreparedStatement ps;
/*     */   private Object nextResult;
/*     */   private HolderInstantiator holderInstantiator;
/*     */   
/*     */   public IteratorImpl(ResultSet rs, PreparedStatement ps, EventSource sess, Type[] types, String[][] columnNames, HolderInstantiator holderInstantiator)
/*     */     throws HibernateException, SQLException
/*     */   {
/*  49 */     this.rs = rs;
/*  50 */     this.ps = ps;
/*  51 */     this.session = sess;
/*  52 */     this.types = types;
/*  53 */     this.names = columnNames;
/*  54 */     this.holderInstantiator = holderInstantiator;
/*     */     
/*  56 */     this.single = (types.length == 1);
/*     */     
/*  58 */     postNext();
/*     */   }
/*     */   
/*     */   public void close() throws JDBCException {
/*  62 */     if (this.ps != null) {
/*     */       try {
/*  64 */         log.debug("closing iterator");
/*  65 */         this.nextResult = null;
/*  66 */         this.session.getBatcher().closeQueryStatement(this.ps, this.rs);
/*  67 */         this.ps = null;
/*  68 */         this.rs = null;
/*  69 */         this.hasNext = false;
/*     */       }
/*     */       catch (SQLException e) {
/*  72 */         log.info("Unable to close iterator", e);
/*  73 */         throw JDBCExceptionHelper.convert(this.session.getFactory().getSQLExceptionConverter(), e, "Unable to close iterator");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void postNext()
/*     */     throws HibernateException, SQLException
/*     */   {
/*  83 */     this.hasNext = this.rs.next();
/*  84 */     if (!this.hasNext) {
/*  85 */       log.debug("exhausted results");
/*  86 */       close();
/*     */     }
/*     */     else {
/*  89 */       log.debug("retrieving next results");
/*  90 */       boolean isHolder = this.holderInstantiator.isRequired();
/*     */       
/*  92 */       if ((this.single) && (!isHolder)) {
/*  93 */         this.nextResult = this.types[0].nullSafeGet(this.rs, this.names[0], this.session, null);
/*     */       }
/*     */       else {
/*  96 */         Object[] nextResults = new Object[this.types.length];
/*  97 */         for (int i = 0; i < this.types.length; i++) {
/*  98 */           nextResults[i] = this.types[i].nullSafeGet(this.rs, this.names[i], this.session, null);
/*     */         }
/*     */         
/* 101 */         if (isHolder) {
/* 102 */           this.nextResult = this.holderInstantiator.instantiate(nextResults);
/*     */         }
/*     */         else {
/* 105 */           this.nextResult = nextResults;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean hasNext()
/*     */   {
/* 113 */     return this.hasNext;
/*     */   }
/*     */   
/*     */   public Object next() {
/* 117 */     if (!this.hasNext) throw new NoSuchElementException("No more results");
/*     */     try {
/* 119 */       this.currentResult = this.nextResult;
/* 120 */       postNext();
/* 121 */       log.debug("returning current results");
/* 122 */       return this.currentResult;
/*     */     }
/*     */     catch (SQLException sqle) {
/* 125 */       throw JDBCExceptionHelper.convert(this.session.getFactory().getSQLExceptionConverter(), sqle, "could not get next iterator result");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void remove()
/*     */   {
/* 134 */     if (!this.single) {
/* 135 */       throw new UnsupportedOperationException("Not a single column hibernate query result set");
/*     */     }
/* 137 */     if (this.currentResult == null) {
/* 138 */       throw new IllegalStateException("Called Iterator.remove() before next()");
/*     */     }
/* 140 */     if (!(this.types[0] instanceof EntityType)) {
/* 141 */       throw new UnsupportedOperationException("Not an entity");
/*     */     }
/*     */     
/* 144 */     this.session.delete(((EntityType)this.types[0]).getAssociatedEntityName(), this.currentResult, false);
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\impl\IteratorImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */