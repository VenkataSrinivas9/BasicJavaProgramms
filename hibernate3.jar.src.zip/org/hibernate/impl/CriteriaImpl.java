/*     */ package org.hibernate.impl;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.hibernate.CacheMode;
/*     */ import org.hibernate.Criteria;
/*     */ import org.hibernate.FetchMode;
/*     */ import org.hibernate.FlushMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.LockMode;
/*     */ import org.hibernate.ScrollMode;
/*     */ import org.hibernate.ScrollableResults;
/*     */ import org.hibernate.criterion.Criterion;
/*     */ import org.hibernate.criterion.NaturalIdentifier;
/*     */ import org.hibernate.criterion.Order;
/*     */ import org.hibernate.criterion.Projection;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.transform.ResultTransformer;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CriteriaImpl
/*     */   implements Criteria, Serializable
/*     */ {
/*     */   private final String entityOrClassName;
/*     */   private transient SessionImplementor session;
/*     */   private final String rootAlias;
/*  37 */   private List criterionEntries = new ArrayList();
/*  38 */   private List orderEntries = new ArrayList();
/*     */   
/*     */   private Projection projection;
/*     */   private Criteria projectionCriteria;
/*  42 */   private List subcriteriaList = new ArrayList();
/*     */   
/*  44 */   private Map fetchModes = new HashMap();
/*  45 */   private Map lockModes = new HashMap();
/*     */   
/*     */   private Integer maxResults;
/*     */   
/*     */   private Integer firstResult;
/*     */   
/*     */   private Integer timeout;
/*     */   
/*     */   private Integer fetchSize;
/*     */   private boolean cacheable;
/*     */   private String cacheRegion;
/*     */   private String comment;
/*     */   private FlushMode flushMode;
/*     */   private CacheMode cacheMode;
/*     */   private FlushMode sessionFlushMode;
/*     */   private CacheMode sessionCacheMode;
/*  61 */   private ResultTransformer resultTransformer = Criteria.ROOT_ENTITY;
/*     */   
/*     */ 
/*     */ 
/*     */   public CriteriaImpl(String entityOrClassName, SessionImplementor session)
/*     */   {
/*  67 */     this(entityOrClassName, "this", session);
/*     */   }
/*     */   
/*     */   public CriteriaImpl(String entityOrClassName, String alias, SessionImplementor session) {
/*  71 */     this.session = session;
/*  72 */     this.entityOrClassName = entityOrClassName;
/*  73 */     this.cacheable = false;
/*  74 */     this.rootAlias = alias;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  78 */     return "CriteriaImpl(" + this.entityOrClassName + ":" + (this.rootAlias == null ? "" : this.rootAlias) + this.subcriteriaList.toString() + this.criterionEntries.toString() + (this.projection == null ? "" : this.projection.toString()) + ')';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SessionImplementor getSession()
/*     */   {
/*  91 */     return this.session;
/*     */   }
/*     */   
/*     */   public void setSession(SessionImplementor session) {
/*  95 */     this.session = session;
/*     */   }
/*     */   
/*     */   public String getEntityOrClassName() {
/*  99 */     return this.entityOrClassName;
/*     */   }
/*     */   
/*     */   public Map getLockModes() {
/* 103 */     return this.lockModes;
/*     */   }
/*     */   
/*     */   public Criteria getProjectionCriteria() {
/* 107 */     return this.projectionCriteria;
/*     */   }
/*     */   
/*     */   public Iterator iterateSubcriteria() {
/* 111 */     return this.subcriteriaList.iterator();
/*     */   }
/*     */   
/*     */   public Iterator iterateExpressionEntries() {
/* 115 */     return this.criterionEntries.iterator();
/*     */   }
/*     */   
/*     */   public Iterator iterateOrderings() {
/* 119 */     return this.orderEntries.iterator();
/*     */   }
/*     */   
/*     */   public Criteria add(Criteria criteriaInst, Criterion expression) {
/* 123 */     this.criterionEntries.add(new CriterionEntry(expression, criteriaInst, null));
/* 124 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getAlias()
/*     */   {
/* 131 */     return this.rootAlias;
/*     */   }
/*     */   
/*     */   public Projection getProjection() {
/* 135 */     return this.projection;
/*     */   }
/*     */   
/*     */   public Criteria setProjection(Projection projection) {
/* 139 */     this.projection = projection;
/* 140 */     this.projectionCriteria = this;
/* 141 */     setResultTransformer(PROJECTION);
/* 142 */     return this;
/*     */   }
/*     */   
/*     */   public Criteria add(Criterion expression) {
/* 146 */     add(this, expression);
/* 147 */     return this;
/*     */   }
/*     */   
/*     */   public Criteria addOrder(Order ordering) {
/* 151 */     this.orderEntries.add(new OrderEntry(ordering, this, null));
/* 152 */     return this;
/*     */   }
/*     */   
/*     */   public FetchMode getFetchMode(String path) {
/* 156 */     return (FetchMode)this.fetchModes.get(path);
/*     */   }
/*     */   
/*     */   public Criteria setFetchMode(String associationPath, FetchMode mode) {
/* 160 */     this.fetchModes.put(associationPath, mode);
/* 161 */     return this;
/*     */   }
/*     */   
/*     */   public Criteria setLockMode(LockMode lockMode) {
/* 165 */     return setLockMode(getAlias(), lockMode);
/*     */   }
/*     */   
/*     */   public Criteria setLockMode(String alias, LockMode lockMode) {
/* 169 */     this.lockModes.put(alias, lockMode);
/* 170 */     return this;
/*     */   }
/*     */   
/*     */   public Criteria createAlias(String associationPath, String alias) {
/* 174 */     return createAlias(associationPath, alias, 0);
/*     */   }
/*     */   
/*     */   public Criteria createAlias(String associationPath, String alias, int joinType) {
/* 178 */     new Subcriteria(this, associationPath, alias, joinType, null);
/* 179 */     return this;
/*     */   }
/*     */   
/*     */   public Criteria createCriteria(String associationPath) {
/* 183 */     return createCriteria(associationPath, 0);
/*     */   }
/*     */   
/*     */   public Criteria createCriteria(String associationPath, int joinType) {
/* 187 */     return new Subcriteria(this, associationPath, joinType, null);
/*     */   }
/*     */   
/*     */   public Criteria createCriteria(String associationPath, String alias) {
/* 191 */     return createCriteria(associationPath, alias, 0);
/*     */   }
/*     */   
/*     */   public Criteria createCriteria(String associationPath, String alias, int joinType) {
/* 195 */     return new Subcriteria(this, associationPath, alias, joinType, null);
/*     */   }
/*     */   
/*     */   public ResultTransformer getResultTransformer() {
/* 199 */     return this.resultTransformer;
/*     */   }
/*     */   
/*     */   public Criteria setResultTransformer(ResultTransformer tupleMapper) {
/* 203 */     this.resultTransformer = tupleMapper;
/* 204 */     return this;
/*     */   }
/*     */   
/*     */   public Integer getMaxResults() {
/* 208 */     return this.maxResults;
/*     */   }
/*     */   
/*     */   public Criteria setMaxResults(int maxResults) {
/* 212 */     this.maxResults = new Integer(maxResults);
/* 213 */     return this;
/*     */   }
/*     */   
/*     */   public Integer getFirstResult() {
/* 217 */     return this.firstResult;
/*     */   }
/*     */   
/*     */   public Criteria setFirstResult(int firstResult) {
/* 221 */     this.firstResult = new Integer(firstResult);
/* 222 */     return this;
/*     */   }
/*     */   
/*     */   public Integer getFetchSize() {
/* 226 */     return this.fetchSize;
/*     */   }
/*     */   
/*     */   public Criteria setFetchSize(int fetchSize) {
/* 230 */     this.fetchSize = new Integer(fetchSize);
/* 231 */     return this;
/*     */   }
/*     */   
/*     */   public Integer getTimeout() {
/* 235 */     return this.timeout;
/*     */   }
/*     */   
/*     */   public Criteria setTimeout(int timeout) {
/* 239 */     this.timeout = new Integer(timeout);
/* 240 */     return this;
/*     */   }
/*     */   
/*     */   public boolean getCacheable() {
/* 244 */     return this.cacheable;
/*     */   }
/*     */   
/*     */   public Criteria setCacheable(boolean cacheable) {
/* 248 */     this.cacheable = cacheable;
/* 249 */     return this;
/*     */   }
/*     */   
/*     */   public String getCacheRegion() {
/* 253 */     return this.cacheRegion;
/*     */   }
/*     */   
/*     */   public Criteria setCacheRegion(String cacheRegion) {
/* 257 */     this.cacheRegion = cacheRegion.trim();
/* 258 */     return this;
/*     */   }
/*     */   
/*     */   public String getComment() {
/* 262 */     return this.comment;
/*     */   }
/*     */   
/*     */   public Criteria setComment(String comment) {
/* 266 */     this.comment = comment;
/* 267 */     return this;
/*     */   }
/*     */   
/*     */   public Criteria setFlushMode(FlushMode flushMode) {
/* 271 */     this.flushMode = flushMode;
/* 272 */     return this;
/*     */   }
/*     */   
/*     */   public Criteria setCacheMode(CacheMode cacheMode) {
/* 276 */     this.cacheMode = cacheMode;
/* 277 */     return this;
/*     */   }
/*     */   
/*     */   public List list() throws HibernateException {
/* 281 */     before();
/*     */     try {
/* 283 */       return this.session.list(this);
/*     */     }
/*     */     finally {
/* 286 */       after();
/*     */     }
/*     */   }
/*     */   
/*     */   public ScrollableResults scroll() {
/* 291 */     return scroll(ScrollMode.SCROLL_INSENSITIVE);
/*     */   }
/*     */   
/*     */   public ScrollableResults scroll(ScrollMode scrollMode) {
/* 295 */     before();
/*     */     try {
/* 297 */       return this.session.scroll(this, scrollMode);
/*     */     }
/*     */     finally {
/* 300 */       after();
/*     */     }
/*     */   }
/*     */   
/*     */   public Object uniqueResult() throws HibernateException {
/* 305 */     return AbstractQueryImpl.uniqueElement(list());
/*     */   }
/*     */   
/*     */   protected void before() {
/* 309 */     if (this.flushMode != null) {
/* 310 */       this.sessionFlushMode = getSession().getFlushMode();
/* 311 */       getSession().setFlushMode(this.flushMode);
/*     */     }
/* 313 */     if (this.cacheMode != null) {
/* 314 */       this.sessionCacheMode = getSession().getCacheMode();
/* 315 */       getSession().setCacheMode(this.cacheMode);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void after() {
/* 320 */     if (this.sessionFlushMode != null) {
/* 321 */       getSession().setFlushMode(this.sessionFlushMode);
/* 322 */       this.sessionFlushMode = null;
/*     */     }
/* 324 */     if (this.sessionCacheMode != null) {
/* 325 */       getSession().setCacheMode(this.sessionCacheMode);
/* 326 */       this.sessionCacheMode = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isLookupByNaturalKey() {
/* 331 */     if (this.projection != null) {
/* 332 */       return false;
/*     */     }
/* 334 */     if (this.subcriteriaList.size() > 0) {
/* 335 */       return false;
/*     */     }
/* 337 */     if (this.criterionEntries.size() != 1) {
/* 338 */       return false;
/*     */     }
/* 340 */     CriterionEntry ce = (CriterionEntry)this.criterionEntries.get(0);
/* 341 */     return ce.getCriterion() instanceof NaturalIdentifier;
/*     */   }
/*     */   
/*     */   public final class Subcriteria implements Criteria, Serializable { private String alias;
/*     */     private String path;
/*     */     
/* 347 */     Subcriteria(Criteria x1, String x2, String x3, int x4, CriteriaImpl.1 x5) { this(x1, x2, x3, x4); } Subcriteria(Criteria x1, String x2, int x3, CriteriaImpl.1 x4) { this(x1, x2, x3); }
/*     */     
/*     */ 
/*     */ 
/*     */     private Criteria parent;
/*     */     
/*     */     private LockMode lockMode;
/*     */     
/*     */     private int joinType;
/*     */     
/*     */     private Subcriteria(Criteria parent, String path, String alias, int joinType)
/*     */     {
/* 359 */       this.alias = alias;
/* 360 */       this.path = path;
/* 361 */       this.parent = parent;
/* 362 */       this.joinType = joinType;
/* 363 */       CriteriaImpl.this.subcriteriaList.add(this);
/*     */     }
/*     */     
/*     */     private Subcriteria(Criteria parent, String path, int joinType) {
/* 367 */       this(parent, path, null, joinType);
/*     */     }
/*     */     
/*     */     public String toString() {
/* 371 */       return "Subcriteria(" + this.path + ":" + (this.alias == null ? "" : this.alias) + ')';
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getAlias()
/*     */     {
/* 381 */       return this.alias;
/*     */     }
/*     */     
/*     */     public void setAlias(String alias) {
/* 385 */       this.alias = alias;
/*     */     }
/*     */     
/*     */     public String getPath() {
/* 389 */       return this.path;
/*     */     }
/*     */     
/*     */     public Criteria getParent() {
/* 393 */       return this.parent;
/*     */     }
/*     */     
/*     */     public LockMode getLockMode() {
/* 397 */       return this.lockMode;
/*     */     }
/*     */     
/*     */     public Criteria setLockMode(LockMode lockMode) {
/* 401 */       this.lockMode = lockMode;
/* 402 */       return this;
/*     */     }
/*     */     
/*     */     public int getJoinType() {
/* 406 */       return this.joinType;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Criteria add(Criterion expression)
/*     */     {
/* 413 */       CriteriaImpl.this.add(this, expression);
/* 414 */       return this;
/*     */     }
/*     */     
/*     */     public Criteria addOrder(Order order) {
/* 418 */       CriteriaImpl.this.orderEntries.add(new CriteriaImpl.OrderEntry(order, this, null));
/* 419 */       return this;
/*     */     }
/*     */     
/*     */     public Criteria createAlias(String associationPath, String alias) {
/* 423 */       return createAlias(associationPath, alias, 0);
/*     */     }
/*     */     
/*     */     public Criteria createAlias(String associationPath, String alias, int joinType) throws HibernateException {
/* 427 */       new Subcriteria(CriteriaImpl.this, this, associationPath, alias, joinType);
/* 428 */       return this;
/*     */     }
/*     */     
/*     */     public Criteria createCriteria(String associationPath) {
/* 432 */       return createCriteria(associationPath, 0);
/*     */     }
/*     */     
/*     */     public Criteria createCriteria(String associationPath, int joinType) throws HibernateException {
/* 436 */       return new Subcriteria(CriteriaImpl.this, this, associationPath, joinType);
/*     */     }
/*     */     
/*     */     public Criteria createCriteria(String associationPath, String alias) {
/* 440 */       return createCriteria(associationPath, alias, 0);
/*     */     }
/*     */     
/*     */     public Criteria createCriteria(String associationPath, String alias, int joinType) throws HibernateException {
/* 444 */       return new Subcriteria(CriteriaImpl.this, this, associationPath, alias, joinType);
/*     */     }
/*     */     
/*     */     public Criteria setCacheable(boolean cacheable) {
/* 448 */       CriteriaImpl.this.setCacheable(cacheable);
/* 449 */       return this;
/*     */     }
/*     */     
/*     */     public Criteria setCacheRegion(String cacheRegion) {
/* 453 */       CriteriaImpl.this.setCacheRegion(cacheRegion);
/* 454 */       return this;
/*     */     }
/*     */     
/*     */     public List list() throws HibernateException {
/* 458 */       return CriteriaImpl.this.list();
/*     */     }
/*     */     
/*     */     public ScrollableResults scroll() throws HibernateException {
/* 462 */       return CriteriaImpl.this.scroll();
/*     */     }
/*     */     
/*     */     public ScrollableResults scroll(ScrollMode scrollMode) throws HibernateException {
/* 466 */       return CriteriaImpl.this.scroll(scrollMode);
/*     */     }
/*     */     
/*     */     public Object uniqueResult() throws HibernateException {
/* 470 */       return CriteriaImpl.this.uniqueResult();
/*     */     }
/*     */     
/*     */     public Criteria setFetchMode(String associationPath, FetchMode mode) throws HibernateException
/*     */     {
/* 475 */       CriteriaImpl.this.setFetchMode(StringHelper.qualify(this.path, associationPath), mode);
/* 476 */       return this;
/*     */     }
/*     */     
/*     */     public Criteria setFlushMode(FlushMode flushMode) {
/* 480 */       CriteriaImpl.this.setFlushMode(flushMode);
/* 481 */       return this;
/*     */     }
/*     */     
/*     */     public Criteria setCacheMode(CacheMode cacheMode) {
/* 485 */       CriteriaImpl.this.setCacheMode(cacheMode);
/* 486 */       return this;
/*     */     }
/*     */     
/*     */     public Criteria setFirstResult(int firstResult) {
/* 490 */       CriteriaImpl.this.setFirstResult(firstResult);
/* 491 */       return this;
/*     */     }
/*     */     
/*     */     public Criteria setMaxResults(int maxResults) {
/* 495 */       CriteriaImpl.this.setMaxResults(maxResults);
/* 496 */       return this;
/*     */     }
/*     */     
/*     */     public Criteria setTimeout(int timeout) {
/* 500 */       CriteriaImpl.this.setTimeout(timeout);
/* 501 */       return this;
/*     */     }
/*     */     
/*     */     public Criteria setFetchSize(int fetchSize) {
/* 505 */       CriteriaImpl.this.setFetchSize(fetchSize);
/* 506 */       return this;
/*     */     }
/*     */     
/*     */     public Criteria setLockMode(String alias, LockMode lockMode) {
/* 510 */       CriteriaImpl.this.setLockMode(alias, lockMode);
/* 511 */       return this;
/*     */     }
/*     */     
/*     */     public Criteria setResultTransformer(ResultTransformer resultProcessor) {
/* 515 */       CriteriaImpl.this.setResultTransformer(resultProcessor);
/* 516 */       return this;
/*     */     }
/*     */     
/*     */     public Criteria setComment(String comment) {
/* 520 */       CriteriaImpl.this.setComment(comment);
/* 521 */       return this;
/*     */     }
/*     */     
/*     */     public Criteria setProjection(Projection projection) {
/* 525 */       CriteriaImpl.this.projection = projection;
/* 526 */       CriteriaImpl.this.projectionCriteria = this;
/* 527 */       setResultTransformer(PROJECTION);
/* 528 */       return this; } }
/*     */   
/*     */   public static final class CriterionEntry implements Serializable { private final Criterion criterion;
/*     */     
/* 532 */     CriterionEntry(Criterion x0, Criteria x1, CriteriaImpl.1 x2) { this(x0, x1); }
/*     */     
/*     */     private final Criteria criteria;
/*     */     private CriterionEntry(Criterion criterion, Criteria criteria)
/*     */     {
/* 537 */       this.criteria = criteria;
/* 538 */       this.criterion = criterion;
/*     */     }
/*     */     
/*     */     public Criterion getCriterion() {
/* 542 */       return this.criterion;
/*     */     }
/*     */     
/*     */     public Criteria getCriteria() {
/* 546 */       return this.criteria;
/*     */     }
/*     */     
/*     */ 
/* 550 */     public String toString() { return this.criterion.toString(); } }
/*     */   
/*     */   public static final class OrderEntry implements Serializable { private final Order order;
/*     */     
/* 554 */     OrderEntry(Order x0, Criteria x1, CriteriaImpl.1 x2) { this(x0, x1); }
/*     */     
/*     */     private final Criteria criteria;
/*     */     private OrderEntry(Order order, Criteria criteria)
/*     */     {
/* 559 */       this.criteria = criteria;
/* 560 */       this.order = order;
/*     */     }
/*     */     
/*     */     public Order getOrder() {
/* 564 */       return this.order;
/*     */     }
/*     */     
/*     */     public Criteria getCriteria() {
/* 568 */       return this.criteria;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 572 */       return this.order.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\impl\CriteriaImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */