/*     */ package org.hibernate.impl;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.hibernate.CacheMode;
/*     */ import org.hibernate.FlushMode;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.NonUniqueResultException;
/*     */ import org.hibernate.PropertyNotFoundException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.engine.QueryParameters;
/*     */ import org.hibernate.engine.RowSelection;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.engine.TypedValue;
/*     */ import org.hibernate.engine.query.ParameterMetadata;
/*     */ import org.hibernate.property.Getter;
/*     */ import org.hibernate.proxy.HibernateProxyHelper;
/*     */ import org.hibernate.type.SerializableType;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.type.TypeFactory;
/*     */ import org.hibernate.util.ArrayHelper;
/*     */ import org.hibernate.util.MarkerObject;
/*     */ import org.hibernate.util.ReflectHelper;
/*     */ import org.hibernate.util.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractQueryImpl
/*     */   implements Query
/*     */ {
/*  52 */   private static final Object UNSET_PARAMETER = new MarkerObject("<unset parameter>");
/*  53 */   private static final Object UNSET_TYPE = new MarkerObject("<unset type>");
/*     */   
/*     */   private final String queryString;
/*     */   
/*     */   protected final SessionImplementor session;
/*     */   
/*     */   protected final ParameterMetadata parameterMetadata;
/*  60 */   private List values = new ArrayList(4);
/*  61 */   private List types = new ArrayList(4);
/*  62 */   private Map namedParameters = new HashMap(4);
/*  63 */   private Map namedParameterLists = new HashMap(4);
/*     */   
/*     */   private Object optionalObject;
/*     */   
/*     */   private Serializable optionalId;
/*     */   
/*     */   private String optionalEntityName;
/*     */   
/*     */   private RowSelection selection;
/*     */   
/*     */   private boolean cacheable;
/*     */   private String cacheRegion;
/*     */   private String comment;
/*     */   private FlushMode flushMode;
/*     */   private CacheMode cacheMode;
/*     */   private FlushMode sessionFlushMode;
/*     */   private CacheMode sessionCacheMode;
/*     */   private Serializable collectionKey;
/*     */   private boolean readOnly;
/*     */   
/*     */   public AbstractQueryImpl(String queryString, FlushMode flushMode, SessionImplementor session, ParameterMetadata parameterMetadata)
/*     */   {
/*  85 */     this.session = session;
/*  86 */     this.queryString = queryString;
/*  87 */     this.selection = new RowSelection();
/*  88 */     this.flushMode = flushMode;
/*  89 */     this.cacheMode = null;
/*  90 */     this.parameterMetadata = parameterMetadata;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  94 */     return StringHelper.unqualify(getClass().getName()) + '(' + this.queryString + ')';
/*     */   }
/*     */   
/*     */   public final String getQueryString() {
/*  98 */     return this.queryString;
/*     */   }
/*     */   
/*     */   public RowSelection getSelection()
/*     */   {
/* 103 */     return this.selection;
/*     */   }
/*     */   
/*     */   public Query setFlushMode(FlushMode flushMode) {
/* 107 */     this.flushMode = flushMode;
/* 108 */     return this;
/*     */   }
/*     */   
/*     */   public Query setCacheMode(CacheMode cacheMode) {
/* 112 */     this.cacheMode = cacheMode;
/* 113 */     return this;
/*     */   }
/*     */   
/*     */   public Query setCacheable(boolean cacheable) {
/* 117 */     this.cacheable = cacheable;
/* 118 */     return this;
/*     */   }
/*     */   
/*     */   public Query setCacheRegion(String cacheRegion) {
/* 122 */     if (cacheRegion != null)
/* 123 */       this.cacheRegion = cacheRegion.trim();
/* 124 */     return this;
/*     */   }
/*     */   
/*     */   public Query setComment(String comment) {
/* 128 */     this.comment = comment;
/* 129 */     return this;
/*     */   }
/*     */   
/*     */   public Query setFirstResult(int firstResult) {
/* 133 */     this.selection.setFirstRow(new Integer(firstResult));
/* 134 */     return this;
/*     */   }
/*     */   
/*     */   public Query setMaxResults(int maxResults) {
/* 138 */     this.selection.setMaxRows(new Integer(maxResults));
/* 139 */     return this;
/*     */   }
/*     */   
/*     */   public Query setTimeout(int timeout) {
/* 143 */     this.selection.setTimeout(new Integer(timeout));
/* 144 */     return this;
/*     */   }
/*     */   
/* 147 */   public Query setFetchSize(int fetchSize) { this.selection.setFetchSize(new Integer(fetchSize));
/* 148 */     return this;
/*     */   }
/*     */   
/*     */   public Type[] getReturnTypes() throws HibernateException {
/* 152 */     return this.session.getFactory().getReturnTypes(this.queryString);
/*     */   }
/*     */   
/*     */   public String[] getReturnAliases() throws HibernateException {
/* 156 */     return this.session.getFactory().getReturnAliases(this.queryString);
/*     */   }
/*     */   
/*     */   public Query setCollectionKey(Serializable collectionKey) {
/* 160 */     this.collectionKey = collectionKey;
/* 161 */     return this;
/*     */   }
/*     */   
/*     */   public boolean isReadOnly() {
/* 165 */     return this.readOnly;
/*     */   }
/*     */   
/*     */   public Query setReadOnly(boolean readOnly) {
/* 169 */     this.readOnly = readOnly;
/* 170 */     return this;
/*     */   }
/*     */   
/*     */   public void setOptionalEntityName(String optionalEntityName) {
/* 174 */     this.optionalEntityName = optionalEntityName;
/*     */   }
/*     */   
/*     */   public void setOptionalId(Serializable optionalId) {
/* 178 */     this.optionalId = optionalId;
/*     */   }
/*     */   
/*     */   public void setOptionalObject(Object optionalObject) {
/* 182 */     this.optionalObject = optionalObject;
/*     */   }
/*     */   
/*     */   SessionImplementor getSession() {
/* 186 */     return this.session;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract Map getLockModes();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Map getNamedParams()
/*     */   {
/* 200 */     return new HashMap(this.namedParameters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getNamedParameters()
/*     */     throws HibernateException
/*     */   {
/* 218 */     return ArrayHelper.toStringArray(this.parameterMetadata.getNamedParameterNames());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasNamedParameters()
/*     */   {
/* 228 */     return this.parameterMetadata.getNamedParameterNames().size() > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Map getNamedParameterLists()
/*     */   {
/* 238 */     return this.namedParameterLists;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List getValues()
/*     */   {
/* 248 */     return this.values;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List getTypes()
/*     */   {
/* 258 */     return this.types;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void verifyParameters()
/*     */     throws QueryException
/*     */   {
/* 268 */     verifyParameters(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void verifyParameters(boolean reserveFirstParameter)
/*     */     throws HibernateException
/*     */   {
/* 280 */     if (this.parameterMetadata.getNamedParameterNames().size() != this.namedParameters.size() + this.namedParameterLists.size()) {
/* 281 */       Set missingParams = new HashSet(this.parameterMetadata.getNamedParameterNames());
/* 282 */       missingParams.removeAll(this.namedParameterLists.keySet());
/* 283 */       missingParams.removeAll(this.namedParameters.keySet());
/* 284 */       throw new QueryException("Not all named parameters have been set: " + missingParams, getQueryString());
/*     */     }
/*     */     
/* 287 */     int positionalValueSpan = 0;
/* 288 */     for (int i = 0; i < this.values.size(); i++) {
/* 289 */       Object object = this.types.get(i);
/* 290 */       if ((this.values.get(i) == UNSET_PARAMETER) || (object == UNSET_TYPE)) {
/* 291 */         if ((!reserveFirstParameter) || (i != 0))
/*     */         {
/*     */ 
/*     */ 
/* 295 */           throw new QueryException("Unset positional parameter at position: " + i, getQueryString());
/*     */         }
/*     */       } else {
/* 298 */         positionalValueSpan += ((Type)object).getColumnSpan(this.session.getFactory());
/*     */       }
/*     */     }
/* 301 */     if (this.parameterMetadata.getOrdinalParameterCount() != positionalValueSpan) {
/* 302 */       if ((reserveFirstParameter) && (this.parameterMetadata.getOrdinalParameterCount() - 1 != positionalValueSpan)) {
/* 303 */         throw new QueryException("Expected positional parameter count: " + (this.parameterMetadata.getOrdinalParameterCount() - 1) + ", actual parameters: " + this.values, getQueryString());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 311 */       if (!reserveFirstParameter) {
/* 312 */         throw new QueryException("Expected positional parameter count: " + this.parameterMetadata.getOrdinalParameterCount() + ", actual parameters: " + this.values, getQueryString());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Query setParameter(int position, Object val, Type type)
/*     */   {
/* 324 */     if (this.parameterMetadata.getOrdinalParameterCount() == 0) {
/* 325 */       throw new IllegalArgumentException("No positional parameters in query: " + getQueryString());
/*     */     }
/* 327 */     if ((position < 0) || (position > this.parameterMetadata.getOrdinalParameterCount() - 1)) {
/* 328 */       throw new IllegalArgumentException("Positional parameter does not exist: " + position + " in query: " + getQueryString());
/*     */     }
/* 330 */     int size = this.values.size();
/* 331 */     if (position < size) {
/* 332 */       this.values.set(position, val);
/* 333 */       this.types.set(position, type);
/*     */     }
/*     */     else
/*     */     {
/* 337 */       for (int i = 0; i < position - size; i++) {
/* 338 */         this.values.add(UNSET_PARAMETER);
/* 339 */         this.types.add(UNSET_TYPE);
/*     */       }
/* 341 */       this.values.add(val);
/* 342 */       this.types.add(type);
/*     */     }
/* 344 */     return this;
/*     */   }
/*     */   
/*     */   public Query setParameter(String name, Object val, Type type) {
/* 348 */     if (!this.parameterMetadata.getNamedParameterNames().contains(name)) {
/* 349 */       throw new IllegalArgumentException("Parameter " + name + " does not exist as a named parameter in [" + getQueryString() + "]");
/*     */     }
/*     */     
/* 352 */     this.namedParameters.put(name, new TypedValue(type, val, this.session.getEntityMode()));
/* 353 */     return this;
/*     */   }
/*     */   
/*     */   public Query setParameter(int position, Object val) throws HibernateException
/*     */   {
/* 358 */     if (val == null) {
/* 359 */       setParameter(position, val, Hibernate.SERIALIZABLE);
/*     */     }
/*     */     else {
/* 362 */       setParameter(position, val, determineType(position, val));
/*     */     }
/* 364 */     return this;
/*     */   }
/*     */   
/*     */   public Query setParameter(String name, Object val) throws HibernateException {
/* 368 */     if (val == null) {
/* 369 */       Type type = this.parameterMetadata.getNamedParameterExpectedType(name);
/* 370 */       if (type == null) {
/* 371 */         type = Hibernate.SERIALIZABLE;
/*     */       }
/* 373 */       setParameter(name, val, type);
/*     */     }
/*     */     else {
/* 376 */       setParameter(name, val, determineType(name, val));
/*     */     }
/* 378 */     return this;
/*     */   }
/*     */   
/*     */   protected Type determineType(int paramPosition, Object paramValue) throws HibernateException {
/* 382 */     Type type = this.parameterMetadata.getOrdinalParameterExpectedType(paramPosition + 1);
/* 383 */     if (type == null) {
/* 384 */       type = guessType(paramValue);
/*     */     }
/* 386 */     return type;
/*     */   }
/*     */   
/*     */   protected Type determineType(String paramName, Object paramValue) throws HibernateException {
/* 390 */     Type type = this.parameterMetadata.getNamedParameterExpectedType(paramName);
/* 391 */     if (type == null) {
/* 392 */       type = guessType(paramValue);
/*     */     }
/* 394 */     return type;
/*     */   }
/*     */   
/*     */   protected Type determineType(String paramName, Class clazz) throws HibernateException {
/* 398 */     Type type = this.parameterMetadata.getNamedParameterExpectedType(paramName);
/* 399 */     if (type == null) {
/* 400 */       type = guessType(clazz);
/*     */     }
/* 402 */     return type;
/*     */   }
/*     */   
/*     */   private Type guessType(Object param) throws HibernateException {
/* 406 */     Class clazz = HibernateProxyHelper.getClassWithoutInitializingProxy(param);
/* 407 */     return guessType(clazz);
/*     */   }
/*     */   
/*     */   private Type guessType(Class clazz) throws HibernateException {
/* 411 */     String typename = clazz.getName();
/* 412 */     Type type = TypeFactory.heuristicType(typename);
/* 413 */     boolean serializable = (type != null) && ((type instanceof SerializableType));
/* 414 */     if ((type == null) || (serializable)) {
/*     */       try {
/* 416 */         this.session.getFactory().getEntityPersister(clazz.getName());
/*     */       }
/*     */       catch (MappingException me) {
/* 419 */         if (serializable) {
/* 420 */           return type;
/*     */         }
/*     */         
/* 423 */         throw new HibernateException("Could not determine a type for class: " + typename);
/*     */       }
/*     */       
/* 426 */       return Hibernate.entity(clazz);
/*     */     }
/*     */     
/* 429 */     return type;
/*     */   }
/*     */   
/*     */   public Query setString(int position, String val)
/*     */   {
/* 434 */     setParameter(position, val, Hibernate.STRING);
/* 435 */     return this;
/*     */   }
/*     */   
/*     */   public Query setCharacter(int position, char val) {
/* 439 */     setParameter(position, new Character(val), Hibernate.CHARACTER);
/* 440 */     return this;
/*     */   }
/*     */   
/*     */   public Query setBoolean(int position, boolean val) {
/* 444 */     setParameter(position, val ? Boolean.TRUE : Boolean.FALSE, Hibernate.BOOLEAN);
/* 445 */     return this;
/*     */   }
/*     */   
/*     */   public Query setByte(int position, byte val) {
/* 449 */     setParameter(position, new Byte(val), Hibernate.BYTE);
/* 450 */     return this;
/*     */   }
/*     */   
/*     */   public Query setShort(int position, short val) {
/* 454 */     setParameter(position, new Short(val), Hibernate.SHORT);
/* 455 */     return this;
/*     */   }
/*     */   
/*     */   public Query setInteger(int position, int val) {
/* 459 */     setParameter(position, new Integer(val), Hibernate.INTEGER);
/* 460 */     return this;
/*     */   }
/*     */   
/*     */   public Query setLong(int position, long val) {
/* 464 */     setParameter(position, new Long(val), Hibernate.LONG);
/* 465 */     return this;
/*     */   }
/*     */   
/*     */   public Query setFloat(int position, float val) {
/* 469 */     setParameter(position, new Float(val), Hibernate.FLOAT);
/* 470 */     return this;
/*     */   }
/*     */   
/*     */   public Query setDouble(int position, double val) {
/* 474 */     setParameter(position, new Double(val), Hibernate.DOUBLE);
/* 475 */     return this;
/*     */   }
/*     */   
/*     */   public Query setBinary(int position, byte[] val) {
/* 479 */     setParameter(position, val, Hibernate.BINARY);
/* 480 */     return this;
/*     */   }
/*     */   
/*     */   public Query setText(int position, String val) {
/* 484 */     setParameter(position, val, Hibernate.TEXT);
/* 485 */     return this;
/*     */   }
/*     */   
/*     */   public Query setSerializable(int position, Serializable val) {
/* 489 */     setParameter(position, val, Hibernate.SERIALIZABLE);
/* 490 */     return this;
/*     */   }
/*     */   
/*     */   public Query setDate(int position, Date date) {
/* 494 */     setParameter(position, date, Hibernate.DATE);
/* 495 */     return this;
/*     */   }
/*     */   
/*     */   public Query setTime(int position, Date date) {
/* 499 */     setParameter(position, date, Hibernate.TIME);
/* 500 */     return this;
/*     */   }
/*     */   
/*     */   public Query setTimestamp(int position, Date date) {
/* 504 */     setParameter(position, date, Hibernate.TIMESTAMP);
/* 505 */     return this;
/*     */   }
/*     */   
/*     */   public Query setEntity(int position, Object val) {
/* 509 */     setParameter(position, val, Hibernate.entity(this.session.bestGuessEntityName(val)));
/* 510 */     return this;
/*     */   }
/*     */   
/*     */   public Query setLocale(int position, Locale locale) {
/* 514 */     setParameter(position, locale, Hibernate.LOCALE);
/* 515 */     return this;
/*     */   }
/*     */   
/*     */   public Query setCalendar(int position, Calendar calendar) {
/* 519 */     setParameter(position, calendar, Hibernate.CALENDAR);
/* 520 */     return this;
/*     */   }
/*     */   
/*     */   public Query setCalendarDate(int position, Calendar calendar) {
/* 524 */     setParameter(position, calendar, Hibernate.CALENDAR_DATE);
/* 525 */     return this;
/*     */   }
/*     */   
/*     */   public Query setBinary(String name, byte[] val) {
/* 529 */     setParameter(name, val, Hibernate.BINARY);
/* 530 */     return this;
/*     */   }
/*     */   
/*     */   public Query setText(String name, String val) {
/* 534 */     setParameter(name, val, Hibernate.TEXT);
/* 535 */     return this;
/*     */   }
/*     */   
/*     */   public Query setBoolean(String name, boolean val) {
/* 539 */     setParameter(name, val ? Boolean.TRUE : Boolean.FALSE, Hibernate.BOOLEAN);
/* 540 */     return this;
/*     */   }
/*     */   
/*     */   public Query setByte(String name, byte val) {
/* 544 */     setParameter(name, new Byte(val), Hibernate.BYTE);
/* 545 */     return this;
/*     */   }
/*     */   
/*     */   public Query setCharacter(String name, char val) {
/* 549 */     setParameter(name, new Character(val), Hibernate.CHARACTER);
/* 550 */     return this;
/*     */   }
/*     */   
/*     */   public Query setDate(String name, Date date) {
/* 554 */     setParameter(name, date, Hibernate.DATE);
/* 555 */     return this;
/*     */   }
/*     */   
/*     */   public Query setDouble(String name, double val) {
/* 559 */     setParameter(name, new Double(val), Hibernate.DOUBLE);
/* 560 */     return this;
/*     */   }
/*     */   
/*     */   public Query setEntity(String name, Object val) {
/* 564 */     setParameter(name, val, Hibernate.entity(this.session.bestGuessEntityName(val)));
/* 565 */     return this;
/*     */   }
/*     */   
/*     */   public Query setFloat(String name, float val) {
/* 569 */     setParameter(name, new Float(val), Hibernate.FLOAT);
/* 570 */     return this;
/*     */   }
/*     */   
/*     */   public Query setInteger(String name, int val) {
/* 574 */     setParameter(name, new Integer(val), Hibernate.INTEGER);
/* 575 */     return this;
/*     */   }
/*     */   
/*     */   public Query setLocale(String name, Locale locale) {
/* 579 */     setParameter(name, locale, Hibernate.LOCALE);
/* 580 */     return this;
/*     */   }
/*     */   
/*     */   public Query setCalendar(String name, Calendar calendar) {
/* 584 */     setParameter(name, calendar, Hibernate.CALENDAR);
/* 585 */     return this;
/*     */   }
/*     */   
/*     */   public Query setCalendarDate(String name, Calendar calendar) {
/* 589 */     setParameter(name, calendar, Hibernate.CALENDAR_DATE);
/* 590 */     return this;
/*     */   }
/*     */   
/*     */   public Query setLong(String name, long val) {
/* 594 */     setParameter(name, new Long(val), Hibernate.LONG);
/* 595 */     return this;
/*     */   }
/*     */   
/*     */   public Query setSerializable(String name, Serializable val) {
/* 599 */     setParameter(name, val, Hibernate.SERIALIZABLE);
/* 600 */     return this;
/*     */   }
/*     */   
/*     */   public Query setShort(String name, short val) {
/* 604 */     setParameter(name, new Short(val), Hibernate.SHORT);
/* 605 */     return this;
/*     */   }
/*     */   
/*     */   public Query setString(String name, String val) {
/* 609 */     setParameter(name, val, Hibernate.STRING);
/* 610 */     return this;
/*     */   }
/*     */   
/*     */   public Query setTime(String name, Date date) {
/* 614 */     setParameter(name, date, Hibernate.TIME);
/* 615 */     return this;
/*     */   }
/*     */   
/*     */   public Query setTimestamp(String name, Date date) {
/* 619 */     setParameter(name, date, Hibernate.TIMESTAMP);
/* 620 */     return this;
/*     */   }
/*     */   
/*     */   public Query setBigDecimal(int position, BigDecimal number) {
/* 624 */     setParameter(position, number, Hibernate.BIG_DECIMAL);
/* 625 */     return this;
/*     */   }
/*     */   
/*     */   public Query setBigDecimal(String name, BigDecimal number) {
/* 629 */     setParameter(name, number, Hibernate.BIG_DECIMAL);
/* 630 */     return this;
/*     */   }
/*     */   
/*     */   public Query setBigInteger(int position, BigInteger number) {
/* 634 */     setParameter(position, number, Hibernate.BIG_INTEGER);
/* 635 */     return this;
/*     */   }
/*     */   
/*     */   public Query setBigInteger(String name, BigInteger number) {
/* 639 */     setParameter(name, number, Hibernate.BIG_INTEGER);
/* 640 */     return this;
/*     */   }
/*     */   
/*     */   public Query setParameterList(String name, Collection vals, Type type) throws HibernateException {
/* 644 */     if (!this.parameterMetadata.getNamedParameterNames().contains(name)) {
/* 645 */       throw new IllegalArgumentException("Parameter " + name + " does not exist as a named parameter in [" + getQueryString() + "]");
/*     */     }
/* 647 */     this.namedParameterLists.put(name, new TypedValue(type, vals, this.session.getEntityMode()));
/* 648 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String expandParameterLists(Map namedParamsCopy)
/*     */   {
/* 656 */     String query = this.queryString;
/* 657 */     Iterator iter = this.namedParameterLists.entrySet().iterator();
/* 658 */     while (iter.hasNext()) {
/* 659 */       Map.Entry me = (Map.Entry)iter.next();
/* 660 */       query = expandParameterList(query, (String)me.getKey(), (TypedValue)me.getValue(), namedParamsCopy);
/*     */     }
/* 662 */     return query;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String expandParameterList(String query, String name, TypedValue typedList, Map namedParamsCopy)
/*     */   {
/* 670 */     Collection vals = (Collection)typedList.getValue();
/* 671 */     Type type = typedList.getType();
/* 672 */     if (vals.size() == 1)
/*     */     {
/* 674 */       namedParamsCopy.put(name, new TypedValue(type, vals.iterator().next(), this.session.getEntityMode()));
/* 675 */       return query;
/*     */     }
/*     */     
/* 678 */     StringBuffer list = new StringBuffer(16);
/* 679 */     Iterator iter = vals.iterator();
/* 680 */     int i = 0;
/* 681 */     while (iter.hasNext()) {
/* 682 */       String alias = name + i++ + '_';
/* 683 */       namedParamsCopy.put(alias, new TypedValue(type, iter.next(), this.session.getEntityMode()));
/* 684 */       list.append(":").append(alias);
/* 685 */       if (iter.hasNext()) list.append(", ");
/*     */     }
/* 687 */     return StringHelper.replace(query, ":" + name, list.toString(), true);
/*     */   }
/*     */   
/*     */   public Query setParameterList(String name, Collection vals) throws HibernateException {
/* 691 */     if (vals == null) {
/* 692 */       throw new QueryException("Collection must be not null!");
/*     */     }
/*     */     
/* 695 */     if (vals.size() == 0) {
/* 696 */       setParameterList(name, vals, null);
/*     */     }
/*     */     else {
/* 699 */       setParameterList(name, vals, determineType(name, vals.iterator().next()));
/*     */     }
/*     */     
/* 702 */     return this;
/*     */   }
/*     */   
/*     */   public Query setParameterList(String name, Object[] vals, Type type) throws HibernateException {
/* 706 */     return setParameterList(name, Arrays.asList(vals), type);
/*     */   }
/*     */   
/*     */   public Query setParameterList(String name, Object[] vals) throws HibernateException {
/* 710 */     return setParameterList(name, Arrays.asList(vals));
/*     */   }
/*     */   
/*     */   public Query setProperties(Object bean) throws HibernateException {
/* 714 */     Class clazz = bean.getClass();
/* 715 */     String[] params = getNamedParameters();
/* 716 */     for (int i = 0; i < params.length; i++) {
/* 717 */       String namedParam = params[i];
/*     */       try {
/* 719 */         Getter getter = ReflectHelper.getGetter(clazz, namedParam);
/* 720 */         Class retType = getter.getReturnType();
/* 721 */         Object object = getter.get(bean);
/* 722 */         if (Collection.class.isAssignableFrom(retType)) {
/* 723 */           setParameterList(namedParam, (Collection)object);
/*     */         }
/* 725 */         else if (retType.isArray()) {
/* 726 */           setParameterList(namedParam, (Object[])object);
/*     */         }
/*     */         else {
/* 729 */           setParameter(namedParam, object, determineType(namedParam, retType));
/*     */         }
/*     */       }
/*     */       catch (PropertyNotFoundException pnfe) {}
/*     */     }
/*     */     
/*     */ 
/* 736 */     return this;
/*     */   }
/*     */   
/*     */   public Query setParameters(Object[] values, Type[] types) {
/* 740 */     this.values = Arrays.asList(values);
/* 741 */     this.types = Arrays.asList(types);
/* 742 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public Object uniqueResult()
/*     */     throws HibernateException
/*     */   {
/* 749 */     return uniqueElement(list());
/*     */   }
/*     */   
/*     */   public int executeUpdate() throws HibernateException {
/* 753 */     throw new UnsupportedOperationException("Update queries only supported through HQL");
/*     */   }
/*     */   
/*     */   static Object uniqueElement(List list) throws NonUniqueResultException {
/* 757 */     int size = list.size();
/* 758 */     if (size == 0) return null;
/* 759 */     Object first = list.get(0);
/* 760 */     for (int i = 1; i < size; i++) {
/* 761 */       if (list.get(i) != first) {
/* 762 */         throw new NonUniqueResultException(list.size());
/*     */       }
/*     */     }
/* 765 */     return first;
/*     */   }
/*     */   
/*     */   protected RowSelection getRowSelection() {
/* 769 */     return this.selection;
/*     */   }
/*     */   
/*     */   public Type[] typeArray() {
/* 773 */     return ArrayHelper.toTypeArray(getTypes());
/*     */   }
/*     */   
/*     */   public Object[] valueArray() {
/* 777 */     return getValues().toArray();
/*     */   }
/*     */   
/*     */   public QueryParameters getQueryParameters(Map namedParams) {
/* 781 */     return new QueryParameters(typeArray(), valueArray(), namedParams, getLockModes(), getSelection(), this.readOnly, this.cacheable, this.cacheRegion, this.comment, new Serializable[] { this.collectionKey == null ? null : this.collectionKey }, this.optionalObject, this.optionalEntityName, this.optionalId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void before()
/*     */   {
/* 799 */     if (this.flushMode != null) {
/* 800 */       this.sessionFlushMode = getSession().getFlushMode();
/* 801 */       getSession().setFlushMode(this.flushMode);
/*     */     }
/* 803 */     if (this.cacheMode != null) {
/* 804 */       this.sessionCacheMode = getSession().getCacheMode();
/* 805 */       getSession().setCacheMode(this.cacheMode);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void after() {
/* 810 */     if (this.sessionFlushMode != null) {
/* 811 */       getSession().setFlushMode(this.sessionFlushMode);
/* 812 */       this.sessionFlushMode = null;
/*     */     }
/* 814 */     if (this.sessionCacheMode != null) {
/* 815 */       getSession().setCacheMode(this.sessionCacheMode);
/* 816 */       this.sessionCacheMode = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\impl\AbstractQueryImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */