/*     */ package org.hibernate.impl;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.hibernate.FlushMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.LockMode;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.ScrollMode;
/*     */ import org.hibernate.ScrollableResults;
/*     */ import org.hibernate.engine.QueryParameters;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.engine.query.ParameterMetadata;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueryImpl
/*     */   extends AbstractQueryImpl
/*     */ {
/*  27 */   private Map lockModes = new HashMap(2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public QueryImpl(String queryString, FlushMode flushMode, SessionImplementor session, ParameterMetadata parameterMetadata)
/*     */   {
/*  34 */     super(queryString, flushMode, session, parameterMetadata);
/*     */   }
/*     */   
/*     */   public QueryImpl(String queryString, SessionImplementor session, ParameterMetadata parameterMetadata) {
/*  38 */     this(queryString, null, session, parameterMetadata);
/*     */   }
/*     */   
/*     */   public Iterator iterate() throws HibernateException {
/*  42 */     verifyParameters();
/*  43 */     Map namedParams = getNamedParams();
/*  44 */     before();
/*     */     try {
/*  46 */       return getSession().iterate(expandParameterLists(namedParams), getQueryParameters(namedParams));
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/*  52 */       after();
/*     */     }
/*     */   }
/*     */   
/*     */   public ScrollableResults scroll() throws HibernateException {
/*  57 */     return scroll(ScrollMode.SCROLL_INSENSITIVE);
/*     */   }
/*     */   
/*     */   public ScrollableResults scroll(ScrollMode scrollMode) throws HibernateException {
/*  61 */     verifyParameters();
/*  62 */     Map namedParams = getNamedParams();
/*  63 */     before();
/*  64 */     QueryParameters qp = getQueryParameters(namedParams);
/*  65 */     qp.setScrollMode(scrollMode);
/*     */     try {
/*  67 */       return getSession().scroll(expandParameterLists(namedParams), qp);
/*     */     }
/*     */     finally {
/*  70 */       after();
/*     */     }
/*     */   }
/*     */   
/*     */   public List list() throws HibernateException {
/*  75 */     verifyParameters();
/*  76 */     Map namedParams = getNamedParams();
/*  77 */     before();
/*     */     try {
/*  79 */       return getSession().list(expandParameterLists(namedParams), getQueryParameters(namedParams));
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/*  85 */       after();
/*     */     }
/*     */   }
/*     */   
/*     */   public int executeUpdate() throws HibernateException {
/*  90 */     verifyParameters();
/*  91 */     Map namedParams = getNamedParams();
/*  92 */     before();
/*     */     try {
/*  94 */       return getSession().executeUpdate(expandParameterLists(namedParams), getQueryParameters(namedParams));
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/* 100 */       after();
/*     */     }
/*     */   }
/*     */   
/*     */   public Query setLockMode(String alias, LockMode lockMode) {
/* 105 */     this.lockModes.put(alias, lockMode);
/* 106 */     return this;
/*     */   }
/*     */   
/*     */   protected Map getLockModes() {
/* 110 */     return this.lockModes;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\impl\QueryImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */