/*     */ package org.hibernate.impl;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.hibernate.Filter;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.engine.FilterDefinition;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilterImpl
/*     */   implements Filter, Serializable
/*     */ {
/*     */   public static final String MARKER = "$FILTER_PLACEHOLDER$";
/*     */   private transient FilterDefinition definition;
/*     */   private String filterName;
/*  27 */   private Map parameters = new HashMap();
/*     */   
/*     */   void afterDeserialize(SessionFactoryImpl factory) {
/*  30 */     this.definition = factory.getFilterDefinition(this.filterName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilterImpl(FilterDefinition configuration)
/*     */   {
/*  39 */     this.definition = configuration;
/*  40 */     this.filterName = this.definition.getFilterName();
/*     */   }
/*     */   
/*     */   public FilterDefinition getFilterDefinition() {
/*  44 */     return this.definition;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/*  53 */     return this.definition.getFilterName();
/*     */   }
/*     */   
/*     */   public Map getParameters() {
/*  57 */     return this.parameters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Filter setParameter(String name, Object value)
/*     */     throws IllegalArgumentException
/*     */   {
/*  72 */     Type type = this.definition.getParameterType(name);
/*  73 */     if (type == null) {
/*  74 */       throw new IllegalArgumentException("Undefined filter parameter [" + name + "]");
/*     */     }
/*  76 */     if ((value != null) && (!type.getReturnedClass().isAssignableFrom(value.getClass()))) {
/*  77 */       throw new IllegalArgumentException("Incorrect type for parameter [" + name + "]");
/*     */     }
/*  79 */     this.parameters.put(name, value);
/*  80 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Filter setParameterList(String name, Collection values)
/*     */     throws HibernateException
/*     */   {
/*  93 */     if (values == null) {
/*  94 */       throw new IllegalArgumentException("Collection must be not null!");
/*     */     }
/*  96 */     Type type = this.definition.getParameterType(name);
/*  97 */     if (type == null) {
/*  98 */       throw new HibernateException("Undefined filter parameter [" + name + "]");
/*     */     }
/* 100 */     if (values.size() > 0) {
/* 101 */       Class elementClass = values.iterator().next().getClass();
/* 102 */       if (!type.getReturnedClass().isAssignableFrom(elementClass)) {
/* 103 */         throw new HibernateException("Incorrect type for parameter [" + name + "]");
/*     */       }
/*     */     }
/* 106 */     this.parameters.put(name, values);
/* 107 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Filter setParameterList(String name, Object[] values)
/*     */     throws IllegalArgumentException
/*     */   {
/* 119 */     return setParameterList(name, Arrays.asList(values));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getParameter(String name)
/*     */   {
/* 129 */     return this.parameters.get(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validate()
/*     */     throws HibernateException
/*     */   {
/* 141 */     Iterator itr = this.definition.getParameterNames().iterator();
/* 142 */     while (itr.hasNext()) {
/* 143 */       String parameterName = (String)itr.next();
/* 144 */       if (this.parameters.get(parameterName) == null) {
/* 145 */         throw new HibernateException("Filter [" + getName() + "] parameter [" + parameterName + "] value not set");
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\impl\FilterImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */