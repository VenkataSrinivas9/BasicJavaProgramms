/*     */ package org.hibernate.impl;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.ScrollableResults;
/*     */ import org.hibernate.engine.QueryParameters;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.exception.JDBCExceptionHelper;
/*     */ import org.hibernate.hql.HolderInstantiator;
/*     */ import org.hibernate.jdbc.Batcher;
/*     */ import org.hibernate.loader.Loader;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractScrollableResults
/*     */   implements ScrollableResults
/*     */ {
/*     */   private final ResultSet resultSet;
/*     */   private final PreparedStatement ps;
/*     */   private final SessionImplementor session;
/*     */   private final Loader loader;
/*     */   private final QueryParameters queryParameters;
/*     */   private final Type[] types;
/*     */   private HolderInstantiator holderInstantiator;
/*     */   
/*     */   public AbstractScrollableResults(ResultSet rs, PreparedStatement ps, SessionImplementor sess, Loader loader, QueryParameters queryParameters, Type[] types, HolderInstantiator holderInstantiator)
/*     */     throws MappingException
/*     */   {
/*  50 */     this.resultSet = rs;
/*  51 */     this.ps = ps;
/*  52 */     this.session = sess;
/*  53 */     this.loader = loader;
/*  54 */     this.queryParameters = queryParameters;
/*  55 */     this.types = types;
/*  56 */     this.holderInstantiator = ((holderInstantiator != null) && (holderInstantiator.isRequired()) ? holderInstantiator : null);
/*     */   }
/*     */   
/*     */ 
/*     */   protected abstract Object[] getCurrentRow();
/*     */   
/*     */   protected ResultSet getResultSet()
/*     */   {
/*  64 */     return this.resultSet;
/*     */   }
/*     */   
/*     */   protected PreparedStatement getPs() {
/*  68 */     return this.ps;
/*     */   }
/*     */   
/*     */   protected SessionImplementor getSession() {
/*  72 */     return this.session;
/*     */   }
/*     */   
/*     */   protected Loader getLoader() {
/*  76 */     return this.loader;
/*     */   }
/*     */   
/*     */   protected QueryParameters getQueryParameters() {
/*  80 */     return this.queryParameters;
/*     */   }
/*     */   
/*     */   protected Type[] getTypes() {
/*  84 */     return this.types;
/*     */   }
/*     */   
/*     */   protected HolderInstantiator getHolderInstantiator() {
/*  88 */     return this.holderInstantiator;
/*     */   }
/*     */   
/*     */   public final void close() throws HibernateException
/*     */   {
/*     */     try {
/*  94 */       this.session.getBatcher().closeQueryStatement(this.ps, this.resultSet);
/*     */     }
/*     */     catch (SQLException sqle) {
/*  97 */       throw JDBCExceptionHelper.convert(this.session.getFactory().getSQLExceptionConverter(), sqle, "could not close results");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final Object[] get()
/*     */     throws HibernateException
/*     */   {
/* 106 */     return getCurrentRow();
/*     */   }
/*     */   
/*     */   public final Object get(int col) throws HibernateException {
/* 110 */     return getCurrentRow()[col];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final Object getFinal(int col, Type returnType)
/*     */     throws HibernateException
/*     */   {
/* 122 */     if (this.holderInstantiator != null) {
/* 123 */       throw new HibernateException("query specifies a holder class");
/*     */     }
/*     */     
/* 126 */     if (returnType.getReturnedClass() == this.types[col].getReturnedClass()) {
/* 127 */       return get(col);
/*     */     }
/*     */     
/* 130 */     return throwInvalidColumnTypeException(col, this.types[col], returnType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final Object getNonFinal(int col, Type returnType)
/*     */     throws HibernateException
/*     */   {
/* 143 */     if (this.holderInstantiator != null) {
/* 144 */       throw new HibernateException("query specifies a holder class");
/*     */     }
/*     */     
/* 147 */     if (returnType.getReturnedClass().isAssignableFrom(this.types[col].getReturnedClass())) {
/* 148 */       return get(col);
/*     */     }
/*     */     
/* 151 */     return throwInvalidColumnTypeException(col, this.types[col], returnType);
/*     */   }
/*     */   
/*     */   public final BigDecimal getBigDecimal(int col) throws HibernateException
/*     */   {
/* 156 */     return (BigDecimal)getFinal(col, Hibernate.BIG_DECIMAL);
/*     */   }
/*     */   
/*     */   public final BigInteger getBigInteger(int col) throws HibernateException {
/* 160 */     return (BigInteger)getFinal(col, Hibernate.BIG_INTEGER);
/*     */   }
/*     */   
/*     */   public final byte[] getBinary(int col) throws HibernateException {
/* 164 */     return (byte[])getFinal(col, Hibernate.BINARY);
/*     */   }
/*     */   
/*     */   public final String getText(int col) throws HibernateException {
/* 168 */     return (String)getFinal(col, Hibernate.TEXT);
/*     */   }
/*     */   
/*     */   public final Blob getBlob(int col) throws HibernateException {
/* 172 */     return (Blob)getNonFinal(col, Hibernate.BLOB);
/*     */   }
/*     */   
/*     */   public final Clob getClob(int col) throws HibernateException {
/* 176 */     return (Clob)getNonFinal(col, Hibernate.CLOB);
/*     */   }
/*     */   
/*     */   public final Boolean getBoolean(int col) throws HibernateException {
/* 180 */     return (Boolean)getFinal(col, Hibernate.BOOLEAN);
/*     */   }
/*     */   
/*     */   public final Byte getByte(int col) throws HibernateException {
/* 184 */     return (Byte)getFinal(col, Hibernate.BYTE);
/*     */   }
/*     */   
/*     */   public final Character getCharacter(int col) throws HibernateException {
/* 188 */     return (Character)getFinal(col, Hibernate.CHARACTER);
/*     */   }
/*     */   
/*     */   public final Date getDate(int col) throws HibernateException {
/* 192 */     return (Date)getNonFinal(col, Hibernate.TIMESTAMP);
/*     */   }
/*     */   
/*     */   public final Calendar getCalendar(int col) throws HibernateException {
/* 196 */     return (Calendar)getNonFinal(col, Hibernate.CALENDAR);
/*     */   }
/*     */   
/*     */   public final Double getDouble(int col) throws HibernateException {
/* 200 */     return (Double)getFinal(col, Hibernate.DOUBLE);
/*     */   }
/*     */   
/*     */   public final Float getFloat(int col) throws HibernateException {
/* 204 */     return (Float)getFinal(col, Hibernate.FLOAT);
/*     */   }
/*     */   
/*     */   public final Integer getInteger(int col) throws HibernateException {
/* 208 */     return (Integer)getFinal(col, Hibernate.INTEGER);
/*     */   }
/*     */   
/*     */   public final Long getLong(int col) throws HibernateException {
/* 212 */     return (Long)getFinal(col, Hibernate.LONG);
/*     */   }
/*     */   
/*     */   public final Short getShort(int col) throws HibernateException {
/* 216 */     return (Short)getFinal(col, Hibernate.SHORT);
/*     */   }
/*     */   
/*     */   public final String getString(int col) throws HibernateException {
/* 220 */     return (String)getFinal(col, Hibernate.STRING);
/*     */   }
/*     */   
/*     */   public final Locale getLocale(int col) throws HibernateException {
/* 224 */     return (Locale)getFinal(col, Hibernate.LOCALE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final TimeZone getTimeZone(int col)
/*     */     throws HibernateException
/*     */   {
/* 232 */     return (TimeZone)getNonFinal(col, Hibernate.TIMEZONE);
/*     */   }
/*     */   
/*     */   public final Type getType(int i) {
/* 236 */     return this.types[i];
/*     */   }
/*     */   
/*     */ 
/*     */   private Object throwInvalidColumnTypeException(int i, Type type, Type returnType)
/*     */     throws HibernateException
/*     */   {
/* 243 */     throw new HibernateException("incompatible column types: " + type.getName() + ", " + returnType.getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void afterScrollOperation()
/*     */   {
/* 252 */     this.session.afterScrollOperation();
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\impl\AbstractScrollableResults.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */