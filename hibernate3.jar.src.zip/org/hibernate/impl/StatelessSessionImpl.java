/*     */ package org.hibernate.impl;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.Connection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.hibernate.CacheMode;
/*     */ import org.hibernate.ConnectionReleaseMode;
/*     */ import org.hibernate.Criteria;
/*     */ import org.hibernate.EmptyInterceptor;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.FlushMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Interceptor;
/*     */ import org.hibernate.LockMode;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.ScrollMode;
/*     */ import org.hibernate.ScrollableResults;
/*     */ import org.hibernate.SessionException;
/*     */ import org.hibernate.StatelessSession;
/*     */ import org.hibernate.Transaction;
/*     */ import org.hibernate.cfg.Settings;
/*     */ import org.hibernate.collection.PersistentCollection;
/*     */ import org.hibernate.engine.EntityKey;
/*     */ import org.hibernate.engine.PersistenceContext;
/*     */ import org.hibernate.engine.QueryParameters;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.StatefulPersistenceContext;
/*     */ import org.hibernate.engine.Versioning;
/*     */ import org.hibernate.engine.query.HQLQueryPlan;
/*     */ import org.hibernate.event.EventListeners;
/*     */ import org.hibernate.id.IdentifierGenerator;
/*     */ import org.hibernate.id.IdentifierGeneratorFactory;
/*     */ import org.hibernate.jdbc.Batcher;
/*     */ import org.hibernate.jdbc.ConnectionManager;
/*     */ import org.hibernate.jdbc.JDBCContext;
/*     */ import org.hibernate.jdbc.JDBCContext.Context;
/*     */ import org.hibernate.loader.criteria.CriteriaLoader;
/*     */ import org.hibernate.loader.custom.CustomLoader;
/*     */ import org.hibernate.loader.custom.CustomQuery;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.persister.entity.OuterJoinLoadable;
/*     */ import org.hibernate.proxy.HibernateProxy;
/*     */ import org.hibernate.proxy.LazyInitializer;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.CollectionHelper;
/*     */ 
/*     */ public class StatelessSessionImpl
/*     */   extends AbstractSessionImpl
/*     */   implements JDBCContext.Context, StatelessSession
/*     */ {
/*     */   private JDBCContext jdbcContext;
/*     */   
/*     */   StatelessSessionImpl(Connection connection, SessionFactoryImpl factory)
/*     */   {
/*  60 */     super(factory);
/*  61 */     this.jdbcContext = new JDBCContext(this, connection, EmptyInterceptor.INSTANCE);
/*     */   }
/*     */   
/*     */   public boolean isOpen() {
/*  65 */     return !isClosed();
/*     */   }
/*     */   
/*     */   public void close() {
/*  69 */     managedClose();
/*     */   }
/*     */   
/*     */   public void delete(Object entity) {
/*  73 */     errorIfClosed();
/*  74 */     delete(null, entity);
/*     */   }
/*     */   
/*     */   public Serializable insert(Object entity) {
/*  78 */     errorIfClosed();
/*  79 */     return insert(null, entity);
/*     */   }
/*     */   
/*     */   public void update(Object entity) {
/*  83 */     errorIfClosed();
/*  84 */     update(null, entity);
/*     */   }
/*     */   
/*     */   public Serializable insert(String entityName, Object entity) {
/*  88 */     errorIfClosed();
/*  89 */     EntityPersister persister = getEntityPersister(entityName, entity);
/*  90 */     Serializable id = persister.getIdentifierGenerator().generate(this, entity);
/*  91 */     Object[] state = persister.getPropertyValues(entity, EntityMode.POJO);
/*  92 */     if (persister.isVersioned()) {
/*  93 */       boolean substitute = Versioning.seedVersion(state, persister.getVersionProperty(), persister.getVersionType(), this);
/*  94 */       if (substitute) persister.setPropertyValues(entity, state, EntityMode.POJO);
/*     */     }
/*  96 */     if (id == IdentifierGeneratorFactory.POST_INSERT_INDICATOR) {
/*  97 */       id = persister.insert(state, entity, this);
/*     */     }
/*     */     else {
/* 100 */       persister.insert(id, state, entity, this);
/*     */     }
/* 102 */     persister.setIdentifier(entity, id, EntityMode.POJO);
/* 103 */     return id;
/*     */   }
/*     */   
/*     */   public void update(String entityName, Object entity) {
/* 107 */     errorIfClosed();
/* 108 */     EntityPersister persister = getEntityPersister(entityName, entity);
/* 109 */     Serializable id = persister.getIdentifier(entity, EntityMode.POJO);
/* 110 */     Object[] state = persister.getPropertyValues(entity, EntityMode.POJO);
/*     */     Object oldVersion;
/* 112 */     if (persister.isVersioned()) {
/* 113 */       Object oldVersion = persister.getVersion(entity, EntityMode.POJO);
/* 114 */       Object newVersion = Versioning.increment(oldVersion, persister.getVersionType(), this);
/* 115 */       Versioning.setVersion(state, newVersion, persister);
/* 116 */       persister.setPropertyValues(entity, state, EntityMode.POJO);
/*     */     }
/*     */     else {
/* 119 */       oldVersion = null;
/*     */     }
/* 121 */     persister.update(id, state, null, false, null, oldVersion, entity, null, this);
/*     */   }
/*     */   
/*     */   public void delete(String entityName, Object entity) {
/* 125 */     errorIfClosed();
/* 126 */     EntityPersister persister = getEntityPersister(entityName, entity);
/* 127 */     Serializable id = persister.getIdentifier(entity, EntityMode.POJO);
/* 128 */     Object version = persister.getVersion(entity, EntityMode.POJO);
/* 129 */     persister.delete(id, version, entity, this);
/*     */   }
/*     */   
/*     */   public ConnectionReleaseMode getConnectionReleaseMode() {
/* 133 */     return this.factory.getSettings().getConnectionReleaseMode();
/*     */   }
/*     */   
/*     */   public boolean isAutoCloseSessionEnabled() {
/* 137 */     return this.factory.getSettings().isAutoCloseSessionEnabled();
/*     */   }
/*     */   
/*     */   public boolean isFlushBeforeCompletionEnabled() {
/* 141 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isFlushModeNever() {
/* 145 */     return false;
/*     */   }
/*     */   
/*     */   public void managedClose() {
/* 149 */     if (!isOpen()) {
/* 150 */       throw new SessionException("Session was already closed!");
/*     */     }
/* 152 */     this.jdbcContext.getConnectionManager().close();
/* 153 */     setClosed();
/*     */   }
/*     */   
/*     */   public void managedFlush() {
/* 157 */     errorIfClosed();
/* 158 */     getBatcher().executeBatch();
/*     */   }
/*     */   
/*     */   public boolean shouldAutoClose() {
/* 162 */     return (isAutoCloseSessionEnabled()) && (isOpen());
/*     */   }
/*     */   
/*     */   public void afterTransactionCompletion(boolean successful, Transaction tx) {}
/*     */   
/*     */   public void beforeTransactionCompletion(Transaction tx) {}
/*     */   
/*     */   public String bestGuessEntityName(Object object) {
/* 170 */     if ((object instanceof HibernateProxy)) {
/* 171 */       object = ((HibernateProxy)object).getHibernateLazyInitializer().getImplementation();
/*     */     }
/* 173 */     return guessEntityName(object);
/*     */   }
/*     */   
/*     */   public Connection connection() {
/* 177 */     errorIfClosed();
/* 178 */     return this.jdbcContext.borrowConnection();
/*     */   }
/*     */   
/*     */   public int executeUpdate(String query, QueryParameters queryParameters) throws HibernateException
/*     */   {
/* 183 */     errorIfClosed();
/* 184 */     queryParameters.validateParameters();
/* 185 */     HQLQueryPlan plan = getHQLQueryPlan(query, false);
/* 186 */     boolean success = false;
/* 187 */     int result = 0;
/*     */     try {
/* 189 */       result = plan.performExecuteUpdate(queryParameters, this);
/* 190 */       success = true;
/*     */     }
/*     */     finally {
/* 193 */       afterOperation(success);
/*     */     }
/* 195 */     this.temporaryPersistenceContext.clear();
/* 196 */     return result;
/*     */   }
/*     */   
/*     */   public Batcher getBatcher() {
/* 200 */     errorIfClosed();
/* 201 */     return this.jdbcContext.getConnectionManager().getBatcher();
/*     */   }
/*     */   
/*     */   public CacheMode getCacheMode()
/*     */   {
/* 206 */     return CacheMode.IGNORE;
/*     */   }
/*     */   
/*     */   public int getDontFlushFromFind() {
/* 210 */     return 0;
/*     */   }
/*     */   
/*     */   public Map getEnabledFilters() {
/* 214 */     return CollectionHelper.EMPTY_MAP;
/*     */   }
/*     */   
/*     */   public Serializable getContextEntityIdentifier(Object object) {
/* 218 */     errorIfClosed();
/* 219 */     return null;
/*     */   }
/*     */   
/*     */   public EntityMode getEntityMode() {
/* 223 */     return EntityMode.POJO;
/*     */   }
/*     */   
/*     */   public EntityPersister getEntityPersister(String entityName, Object object) throws HibernateException
/*     */   {
/* 228 */     errorIfClosed();
/* 229 */     if (entityName == null) {
/* 230 */       return this.factory.getEntityPersister(guessEntityName(object));
/*     */     }
/*     */     
/* 233 */     return this.factory.getEntityPersister(entityName).getSubclassEntityPersister(object, getFactory(), EntityMode.POJO);
/*     */   }
/*     */   
/*     */   public Object getEntityUsingInterceptor(EntityKey key)
/*     */     throws HibernateException
/*     */   {
/* 239 */     errorIfClosed();
/* 240 */     return null;
/*     */   }
/*     */   
/*     */   public Type getFilterParameterType(String filterParameterName) {
/* 244 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Object getFilterParameterValue(String filterParameterName) {
/* 248 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public FlushMode getFlushMode() {
/* 252 */     return FlushMode.COMMIT;
/*     */   }
/*     */   
/*     */   public Interceptor getInterceptor() {
/* 256 */     return EmptyInterceptor.INSTANCE;
/*     */   }
/*     */   
/*     */   public EventListeners getListeners() {
/* 260 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public PersistenceContext getPersistenceContext() {
/* 264 */     return this.temporaryPersistenceContext;
/*     */   }
/*     */   
/*     */   public long getTimestamp() {
/* 268 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/* 271 */   private PersistenceContext temporaryPersistenceContext = new StatefulPersistenceContext(this);
/*     */   
/*     */   public Object get(Class entityClass, Serializable id) {
/* 274 */     return get(entityClass.getName(), id);
/*     */   }
/*     */   
/*     */   public Object get(Class entityClass, Serializable id, LockMode lockMode) {
/* 278 */     return get(entityClass.getName(), id, lockMode);
/*     */   }
/*     */   
/*     */   public Object get(String entityName, Serializable id) {
/* 282 */     return get(entityName, id, LockMode.NONE);
/*     */   }
/*     */   
/*     */   public Object get(String entityName, Serializable id, LockMode lockMode) {
/* 286 */     errorIfClosed();
/* 287 */     Object result = getFactory().getEntityPersister(entityName).load(id, null, lockMode, this);
/*     */     
/* 289 */     this.temporaryPersistenceContext.clear();
/* 290 */     return result;
/*     */   }
/*     */   
/*     */   public String guessEntityName(Object entity) throws HibernateException {
/* 294 */     errorIfClosed();
/* 295 */     return entity.getClass().getName();
/*     */   }
/*     */   
/*     */   public Object immediateLoad(String entityName, Serializable id) throws HibernateException {
/* 299 */     throw new SessionException("proxies cannot be fetched by a stateless session");
/*     */   }
/*     */   
/*     */   public void initializeCollection(PersistentCollection collection, boolean writing) throws HibernateException
/*     */   {
/* 304 */     throw new SessionException("collections cannot be fetched by a stateless session");
/*     */   }
/*     */   
/*     */   public Object instantiate(String entityName, Serializable id) throws HibernateException {
/* 308 */     errorIfClosed();
/* 309 */     return getFactory().getEntityPersister(entityName).instantiate(id, EntityMode.POJO);
/*     */   }
/*     */   
/*     */   public Object internalLoad(String entityName, Serializable id, boolean eager, boolean nullable) throws HibernateException
/*     */   {
/* 314 */     errorIfClosed();
/* 315 */     EntityPersister persister = getFactory().getEntityPersister(entityName);
/* 316 */     if ((!eager) && (persister.hasProxy())) {
/* 317 */       return persister.createProxy(id, this);
/*     */     }
/* 319 */     Object loaded = this.temporaryPersistenceContext.getEntity(new EntityKey(id, persister, EntityMode.POJO));
/*     */     
/* 321 */     return loaded == null ? get(entityName, id) : loaded;
/*     */   }
/*     */   
/*     */   public boolean isConnected() {
/* 325 */     return this.jdbcContext.getConnectionManager().isCurrentlyConnected();
/*     */   }
/*     */   
/*     */   public boolean isTransactionInProgress() {
/* 329 */     return this.jdbcContext.isTransactionInProgress();
/*     */   }
/*     */   
/*     */   public Iterator iterate(String query, QueryParameters queryParameters) throws HibernateException {
/* 333 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Iterator iterateFilter(Object collection, String filter, QueryParameters queryParameters) throws HibernateException
/*     */   {
/* 338 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public List listFilter(Object collection, String filter, QueryParameters queryParameters) throws HibernateException
/*     */   {
/* 343 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setAutoClear(boolean enabled) {
/* 347 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setCacheMode(CacheMode cm) {
/* 351 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void setFlushMode(FlushMode fm) {
/* 355 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Transaction getTransaction() throws HibernateException {
/* 359 */     errorIfClosed();
/* 360 */     return this.jdbcContext.getTransaction();
/*     */   }
/*     */   
/*     */   public Transaction beginTransaction() throws HibernateException {
/* 364 */     errorIfClosed();
/* 365 */     Transaction result = getTransaction();
/* 366 */     result.begin();
/* 367 */     return result;
/*     */   }
/*     */   
/*     */   public boolean isEventSource() {
/* 371 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List list(String query, QueryParameters queryParameters)
/*     */     throws HibernateException
/*     */   {
/* 379 */     errorIfClosed();
/* 380 */     queryParameters.validateParameters();
/* 381 */     HQLQueryPlan plan = getHQLQueryPlan(query, false);
/* 382 */     boolean success = false;
/* 383 */     List results = CollectionHelper.EMPTY_LIST;
/*     */     try {
/* 385 */       results = plan.performList(queryParameters, this);
/* 386 */       success = true;
/*     */     }
/*     */     finally {
/* 389 */       afterOperation(success);
/*     */     }
/* 391 */     this.temporaryPersistenceContext.clear();
/* 392 */     return results;
/*     */   }
/*     */   
/*     */   public void afterOperation(boolean success) {
/* 396 */     if (!this.jdbcContext.isTransactionInProgress()) {
/* 397 */       this.jdbcContext.afterNontransactionalQuery(success);
/*     */     }
/*     */   }
/*     */   
/*     */   public Criteria createCriteria(Class persistentClass, String alias) {
/* 402 */     errorIfClosed();
/* 403 */     return new CriteriaImpl(persistentClass.getName(), alias, this);
/*     */   }
/*     */   
/*     */   public Criteria createCriteria(String entityName, String alias) {
/* 407 */     errorIfClosed();
/* 408 */     return new CriteriaImpl(entityName, alias, this);
/*     */   }
/*     */   
/*     */   public Criteria createCriteria(Class persistentClass) {
/* 412 */     errorIfClosed();
/* 413 */     return new CriteriaImpl(persistentClass.getName(), this);
/*     */   }
/*     */   
/*     */   public Criteria createCriteria(String entityName) {
/* 417 */     errorIfClosed();
/* 418 */     return new CriteriaImpl(entityName, this);
/*     */   }
/*     */   
/*     */   public ScrollableResults scroll(CriteriaImpl criteria, ScrollMode scrollMode) {
/* 422 */     errorIfClosed();
/* 423 */     String entityName = criteria.getEntityOrClassName();
/* 424 */     CriteriaLoader loader = new CriteriaLoader(getOuterJoinLoadable(entityName), this.factory, criteria, entityName, getEnabledFilters());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 431 */     return loader.scroll(this, scrollMode);
/*     */   }
/*     */   
/*     */   public List list(CriteriaImpl criteria) throws HibernateException {
/* 435 */     errorIfClosed();
/* 436 */     String[] implementors = this.factory.getImplementors(criteria.getEntityOrClassName());
/* 437 */     int size = implementors.length;
/*     */     
/* 439 */     CriteriaLoader[] loaders = new CriteriaLoader[size];
/* 440 */     Set spaces = new HashSet();
/* 441 */     for (int i = 0; i < size; i++)
/*     */     {
/* 443 */       loaders[i] = new CriteriaLoader(getOuterJoinLoadable(implementors[i]), this.factory, criteria, implementors[i], getEnabledFilters());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 451 */       spaces.addAll(loaders[i].getQuerySpaces());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 456 */     List results = Collections.EMPTY_LIST;
/* 457 */     boolean success = false;
/*     */     try {
/* 459 */       for (int i = 0; i < size; i++) {
/* 460 */         List currentResults = loaders[i].list(this);
/* 461 */         currentResults.addAll(results);
/* 462 */         results = currentResults;
/*     */       }
/* 464 */       success = true;
/*     */     }
/*     */     finally {
/* 467 */       afterOperation(success);
/*     */     }
/* 469 */     this.temporaryPersistenceContext.clear();
/* 470 */     return results;
/*     */   }
/*     */   
/*     */   private OuterJoinLoadable getOuterJoinLoadable(String entityName) throws MappingException {
/* 474 */     EntityPersister persister = this.factory.getEntityPersister(entityName);
/* 475 */     if (!(persister instanceof OuterJoinLoadable)) {
/* 476 */       throw new MappingException("class persister is not OuterJoinLoadable: " + entityName);
/*     */     }
/* 478 */     return (OuterJoinLoadable)persister;
/*     */   }
/*     */   
/*     */   public List listCustomQuery(CustomQuery customQuery, QueryParameters queryParameters) throws HibernateException
/*     */   {
/* 483 */     errorIfClosed();
/* 484 */     CustomLoader loader = new CustomLoader(customQuery, getFactory());
/*     */     
/* 486 */     boolean success = false;
/*     */     try
/*     */     {
/* 489 */       List results = loader.list(this, queryParameters);
/* 490 */       success = true;
/*     */     }
/*     */     finally {
/* 493 */       afterOperation(success); }
/*     */     List results;
/* 495 */     this.temporaryPersistenceContext.clear();
/* 496 */     return results;
/*     */   }
/*     */   
/*     */   public ScrollableResults scrollCustomQuery(CustomQuery customQuery, QueryParameters queryParameters) throws HibernateException
/*     */   {
/* 501 */     errorIfClosed();
/* 502 */     CustomLoader loader = new CustomLoader(customQuery, getFactory());
/* 503 */     return loader.scroll(queryParameters, this);
/*     */   }
/*     */   
/*     */   public ScrollableResults scroll(String query, QueryParameters queryParameters) throws HibernateException {
/* 507 */     errorIfClosed();
/* 508 */     HQLQueryPlan plan = getHQLQueryPlan(query, false);
/* 509 */     return plan.performScroll(queryParameters, this);
/*     */   }
/*     */   
/*     */   public void afterScrollOperation() {
/* 513 */     this.temporaryPersistenceContext.clear();
/*     */   }
/*     */   
/*     */   public void flush() {}
/*     */   
/*     */   public String getFetchProfile() {
/* 519 */     return null;
/*     */   }
/*     */   
/*     */   public JDBCContext getJDBCContext() {
/* 523 */     return this.jdbcContext;
/*     */   }
/*     */   
/*     */   public void setFetchProfile(String name) {}
/*     */   
/*     */   public void afterTransactionBegin(Transaction tx) {}
/*     */   
/*     */   protected boolean autoFlushIfRequired(Set querySpaces) throws HibernateException
/*     */   {
/* 532 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\impl\StatelessSessionImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */