/*     */ package org.hibernate.impl;
/*     */ 
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.ScrollableResults;
/*     */ import org.hibernate.engine.QueryParameters;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.exception.JDBCExceptionHelper;
/*     */ import org.hibernate.hql.HolderInstantiator;
/*     */ import org.hibernate.loader.Loader;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScrollableResultsImpl
/*     */   extends AbstractScrollableResults
/*     */   implements ScrollableResults
/*     */ {
/*     */   private Object[] currentRow;
/*     */   
/*     */   public ScrollableResultsImpl(ResultSet rs, PreparedStatement ps, SessionImplementor sess, Loader loader, QueryParameters queryParameters, Type[] types, HolderInstantiator holderInstantiator)
/*     */     throws MappingException
/*     */   {
/*  33 */     super(rs, ps, sess, loader, queryParameters, types, holderInstantiator);
/*     */   }
/*     */   
/*     */   protected Object[] getCurrentRow() {
/*  37 */     return this.currentRow;
/*     */   }
/*     */   
/*     */   public boolean scroll(int i)
/*     */     throws HibernateException
/*     */   {
/*     */     try
/*     */     {
/*  45 */       boolean result = getResultSet().relative(i);
/*  46 */       prepareCurrentRow(result);
/*  47 */       return result;
/*     */     }
/*     */     catch (SQLException sqle) {
/*  50 */       throw JDBCExceptionHelper.convert(getSession().getFactory().getSQLExceptionConverter(), sqle, "could not advance using scroll()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean first()
/*     */     throws HibernateException
/*     */   {
/*     */     try
/*     */     {
/*  63 */       boolean result = getResultSet().first();
/*  64 */       prepareCurrentRow(result);
/*  65 */       return result;
/*     */     }
/*     */     catch (SQLException sqle) {
/*  68 */       throw JDBCExceptionHelper.convert(getSession().getFactory().getSQLExceptionConverter(), sqle, "could not advance using first()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean last()
/*     */     throws HibernateException
/*     */   {
/*     */     try
/*     */     {
/*  81 */       boolean result = getResultSet().last();
/*  82 */       prepareCurrentRow(result);
/*  83 */       return result;
/*     */     }
/*     */     catch (SQLException sqle) {
/*  86 */       throw JDBCExceptionHelper.convert(getSession().getFactory().getSQLExceptionConverter(), sqle, "could not advance using last()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean next()
/*     */     throws HibernateException
/*     */   {
/*     */     try
/*     */     {
/*  99 */       boolean result = getResultSet().next();
/* 100 */       prepareCurrentRow(result);
/* 101 */       return result;
/*     */     }
/*     */     catch (SQLException sqle) {
/* 104 */       throw JDBCExceptionHelper.convert(getSession().getFactory().getSQLExceptionConverter(), sqle, "could not advance using next()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean previous()
/*     */     throws HibernateException
/*     */   {
/*     */     try
/*     */     {
/* 117 */       boolean result = getResultSet().previous();
/* 118 */       prepareCurrentRow(result);
/* 119 */       return result;
/*     */     }
/*     */     catch (SQLException sqle) {
/* 122 */       throw JDBCExceptionHelper.convert(getSession().getFactory().getSQLExceptionConverter(), sqle, "could not advance using previous()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterLast()
/*     */     throws HibernateException
/*     */   {
/*     */     try
/*     */     {
/* 135 */       getResultSet().afterLast();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 138 */       throw JDBCExceptionHelper.convert(getSession().getFactory().getSQLExceptionConverter(), sqle, "exception calling afterLast()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void beforeFirst()
/*     */     throws HibernateException
/*     */   {
/*     */     try
/*     */     {
/* 151 */       getResultSet().beforeFirst();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 154 */       throw JDBCExceptionHelper.convert(getSession().getFactory().getSQLExceptionConverter(), sqle, "exception calling beforeFirst()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFirst()
/*     */     throws HibernateException
/*     */   {
/*     */     try
/*     */     {
/* 167 */       return getResultSet().isFirst();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 170 */       throw JDBCExceptionHelper.convert(getSession().getFactory().getSQLExceptionConverter(), sqle, "exception calling isFirst()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLast()
/*     */     throws HibernateException
/*     */   {
/*     */     try
/*     */     {
/* 183 */       return getResultSet().isLast();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 186 */       throw JDBCExceptionHelper.convert(getSession().getFactory().getSQLExceptionConverter(), sqle, "exception calling isLast()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public int getRowNumber()
/*     */     throws HibernateException
/*     */   {
/*     */     try
/*     */     {
/* 196 */       return getResultSet().getRow() - 1;
/*     */     }
/*     */     catch (SQLException sqle) {
/* 199 */       throw JDBCExceptionHelper.convert(getSession().getFactory().getSQLExceptionConverter(), sqle, "exception calling getRow()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean setRowNumber(int rowNumber)
/*     */     throws HibernateException
/*     */   {
/* 208 */     if (rowNumber >= 0) rowNumber++;
/*     */     try {
/* 210 */       boolean result = getResultSet().absolute(rowNumber);
/* 211 */       prepareCurrentRow(result);
/* 212 */       return result;
/*     */     }
/*     */     catch (SQLException sqle) {
/* 215 */       throw JDBCExceptionHelper.convert(getSession().getFactory().getSQLExceptionConverter(), sqle, "could not advance using absolute()");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void prepareCurrentRow(boolean underlyingScrollSuccessful)
/*     */     throws HibernateException
/*     */   {
/* 226 */     if (!underlyingScrollSuccessful) {
/* 227 */       this.currentRow = null;
/* 228 */       return;
/*     */     }
/*     */     
/* 231 */     Object result = getLoader().loadSingleRow(getResultSet(), getSession(), getQueryParameters(), false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 237 */     if ((result != null) && (result.getClass().isArray())) {
/* 238 */       this.currentRow = ((Object[])result);
/*     */     }
/*     */     else {
/* 241 */       this.currentRow = new Object[] { result };
/*     */     }
/*     */     
/* 244 */     if (getHolderInstantiator() != null) {
/* 245 */       this.currentRow = new Object[] { getHolderInstantiator().instantiate(this.currentRow) };
/*     */     }
/*     */     
/* 248 */     afterScrollOperation();
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\impl\ScrollableResultsImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */