/*    */ package org.hibernate.impl;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.ScrollableResults;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.engine.query.ParameterMetadata;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CollectionFilterImpl
/*    */   extends QueryImpl
/*    */ {
/*    */   private Object collection;
/*    */   
/*    */   public CollectionFilterImpl(String queryString, Object collection, SessionImplementor session, ParameterMetadata parameterMetadata)
/*    */   {
/* 27 */     super(queryString, session, parameterMetadata);
/* 28 */     this.collection = collection;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Iterator iterate()
/*    */     throws HibernateException
/*    */   {
/* 36 */     verifyParameters();
/* 37 */     Map namedParams = getNamedParams();
/* 38 */     return getSession().iterateFilter(this.collection, expandParameterLists(namedParams), getQueryParameters(namedParams));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public List list()
/*    */     throws HibernateException
/*    */   {
/* 49 */     verifyParameters();
/* 50 */     Map namedParams = getNamedParams();
/* 51 */     return getSession().listFilter(this.collection, expandParameterLists(namedParams), getQueryParameters(namedParams));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ScrollableResults scroll()
/*    */     throws HibernateException
/*    */   {
/* 62 */     throw new UnsupportedOperationException("Can't scroll filters");
/*    */   }
/*    */   
/*    */   public Type[] typeArray() {
/* 66 */     List typeList = getTypes();
/* 67 */     int size = typeList.size();
/* 68 */     Type[] result = new Type[size + 1];
/* 69 */     for (int i = 0; i < size; i++) result[(i + 1)] = ((Type)typeList.get(i));
/* 70 */     return result;
/*    */   }
/*    */   
/*    */   public Object[] valueArray() {
/* 74 */     List valueList = getValues();
/* 75 */     int size = valueList.size();
/* 76 */     Object[] result = new Object[size + 1];
/* 77 */     for (int i = 0; i < size; i++) result[(i + 1)] = valueList.get(i);
/* 78 */     return result;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\impl\CollectionFilterImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */