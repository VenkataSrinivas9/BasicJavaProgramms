/*     */ package org.hibernate.impl;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.SQLQuery;
/*     */ import org.hibernate.ScrollableResults;
/*     */ import org.hibernate.SessionException;
/*     */ import org.hibernate.engine.NamedQueryDefinition;
/*     */ import org.hibernate.engine.NamedSQLQueryDefinition;
/*     */ import org.hibernate.engine.QueryParameters;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.engine.query.HQLQueryPlan;
/*     */ import org.hibernate.engine.query.NativeSQLQueryPlan;
/*     */ import org.hibernate.engine.query.NativeSQLQuerySpecification;
/*     */ import org.hibernate.engine.query.QueryPlanCache;
/*     */ import org.hibernate.loader.custom.SQLCustomQuery;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSessionImpl
/*     */   implements SessionImplementor
/*     */ {
/*     */   protected transient SessionFactoryImpl factory;
/*  30 */   private boolean closed = false;
/*     */   
/*     */   protected AbstractSessionImpl(SessionFactoryImpl factory) {
/*  33 */     this.factory = factory;
/*     */   }
/*     */   
/*     */   public SessionFactoryImplementor getFactory() {
/*  37 */     return this.factory;
/*     */   }
/*     */   
/*     */   protected boolean isClosed() {
/*  41 */     return this.closed;
/*     */   }
/*     */   
/*     */   protected void setClosed() {
/*  45 */     this.closed = true;
/*     */   }
/*     */   
/*     */   protected void errorIfClosed() {
/*  49 */     if (this.closed) {
/*  50 */       throw new SessionException("Session is closed!");
/*     */     }
/*     */   }
/*     */   
/*     */   public Query getNamedQuery(String queryName) throws MappingException {
/*  55 */     errorIfClosed();
/*  56 */     NamedQueryDefinition nqd = this.factory.getNamedQuery(queryName);
/*     */     Query query;
/*  58 */     if (nqd != null) {
/*  59 */       String queryString = nqd.getQueryString();
/*  60 */       Query query = new QueryImpl(queryString, nqd.getFlushMode(), this, getHQLQueryPlan(queryString, false).getParameterMetadata());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */       query.setComment("named HQL query " + queryName);
/*     */     }
/*     */     else {
/*  69 */       NamedSQLQueryDefinition nsqlqd = this.factory.getNamedSQLQuery(queryName);
/*  70 */       if (nsqlqd == null) {
/*  71 */         throw new MappingException("Named query not known: " + queryName);
/*     */       }
/*  73 */       query = new SQLQueryImpl(nsqlqd, this, this.factory.getQueryPlanCache().getSQLParameterMetadata(nsqlqd.getQueryString()));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  78 */       query.setComment("named native SQL query " + queryName);
/*  79 */       nqd = nsqlqd;
/*     */     }
/*  81 */     initQuery(query, nqd);
/*  82 */     return query;
/*     */   }
/*     */   
/*     */   public Query getNamedSQLQuery(String queryName) throws MappingException {
/*  86 */     errorIfClosed();
/*  87 */     NamedSQLQueryDefinition nsqlqd = this.factory.getNamedSQLQuery(queryName);
/*  88 */     if (nsqlqd == null) {
/*  89 */       throw new MappingException("Named SQL query not known: " + queryName);
/*     */     }
/*  91 */     Query query = new SQLQueryImpl(nsqlqd, this, this.factory.getQueryPlanCache().getSQLParameterMetadata(nsqlqd.getQueryString()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  96 */     query.setComment("named native SQL query " + queryName);
/*  97 */     initQuery(query, nsqlqd);
/*  98 */     return query;
/*     */   }
/*     */   
/*     */   private void initQuery(Query query, NamedQueryDefinition nqd) {
/* 102 */     query.setCacheable(nqd.isCacheable());
/* 103 */     query.setCacheRegion(nqd.getCacheRegion());
/* 104 */     if (nqd.getTimeout() != null) query.setTimeout(nqd.getTimeout().intValue());
/* 105 */     if (nqd.getFetchSize() != null) query.setFetchSize(nqd.getFetchSize().intValue());
/* 106 */     if (nqd.getCacheMode() != null) query.setCacheMode(nqd.getCacheMode());
/* 107 */     query.setReadOnly(nqd.isReadOnly());
/* 108 */     if (nqd.getComment() != null) query.setComment(nqd.getComment());
/*     */   }
/*     */   
/*     */   public Query createQuery(String queryString) {
/* 112 */     errorIfClosed();
/* 113 */     QueryImpl query = new QueryImpl(queryString, this, getHQLQueryPlan(queryString, false).getParameterMetadata());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 118 */     query.setComment(queryString);
/* 119 */     return query;
/*     */   }
/*     */   
/*     */   public SQLQuery createSQLQuery(String sql) {
/* 123 */     errorIfClosed();
/* 124 */     SQLQueryImpl query = new SQLQueryImpl(sql, this, this.factory.getQueryPlanCache().getSQLParameterMetadata(sql));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 129 */     query.setComment("dynamic native SQL query");
/* 130 */     return query;
/*     */   }
/*     */   
/*     */   protected HQLQueryPlan getHQLQueryPlan(String query, boolean shallow) throws HibernateException {
/* 134 */     HQLQueryPlan plan = this.factory.getQueryPlanCache().getHQLQueryPlan(query, shallow, getEnabledFilters());
/* 135 */     autoFlushIfRequired(plan.getQuerySpaces());
/* 136 */     return plan;
/*     */   }
/*     */   
/*     */   protected NativeSQLQueryPlan getNativeSQLQueryPlan(NativeSQLQuerySpecification spec) throws HibernateException {
/* 140 */     NativeSQLQueryPlan plan = this.factory.getQueryPlanCache().getNativeSQLQueryPlan(spec);
/* 141 */     autoFlushIfRequired(plan.getCustomQuery().getQuerySpaces());
/* 142 */     return plan;
/*     */   }
/*     */   
/*     */   public List list(NativeSQLQuerySpecification spec, QueryParameters queryParameters) throws HibernateException
/*     */   {
/* 147 */     return listCustomQuery(getNativeSQLQueryPlan(spec).getCustomQuery(), queryParameters);
/*     */   }
/*     */   
/*     */   public ScrollableResults scroll(NativeSQLQuerySpecification spec, QueryParameters queryParameters) throws HibernateException
/*     */   {
/* 152 */     return scrollCustomQuery(getNativeSQLQueryPlan(spec).getCustomQuery(), queryParameters);
/*     */   }
/*     */   
/*     */   protected abstract boolean autoFlushIfRequired(Set paramSet)
/*     */     throws HibernateException;
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\impl\AbstractSessionImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */