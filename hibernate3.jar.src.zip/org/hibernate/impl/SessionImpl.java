/*      */ package org.hibernate.impl;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.sql.Connection;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.dom4j.Element;
/*      */ import org.hibernate.CacheMode;
/*      */ import org.hibernate.ConnectionReleaseMode;
/*      */ import org.hibernate.Criteria;
/*      */ import org.hibernate.EntityMode;
/*      */ import org.hibernate.Filter;
/*      */ import org.hibernate.FlushMode;
/*      */ import org.hibernate.HibernateException;
/*      */ import org.hibernate.Interceptor;
/*      */ import org.hibernate.LockMode;
/*      */ import org.hibernate.MappingException;
/*      */ import org.hibernate.ObjectDeletedException;
/*      */ import org.hibernate.ObjectNotFoundException;
/*      */ import org.hibernate.Query;
/*      */ import org.hibernate.QueryException;
/*      */ import org.hibernate.ReplicationMode;
/*      */ import org.hibernate.SQLQuery;
/*      */ import org.hibernate.ScrollMode;
/*      */ import org.hibernate.ScrollableResults;
/*      */ import org.hibernate.SessionException;
/*      */ import org.hibernate.SessionFactory;
/*      */ import org.hibernate.Transaction;
/*      */ import org.hibernate.TransientObjectException;
/*      */ import org.hibernate.UnresolvableObjectException;
/*      */ import org.hibernate.collection.PersistentCollection;
/*      */ import org.hibernate.engine.ActionQueue;
/*      */ import org.hibernate.engine.CollectionEntry;
/*      */ import org.hibernate.engine.EntityEntry;
/*      */ import org.hibernate.engine.EntityKey;
/*      */ import org.hibernate.engine.FilterDefinition;
/*      */ import org.hibernate.engine.PersistenceContext;
/*      */ import org.hibernate.engine.QueryParameters;
/*      */ import org.hibernate.engine.SessionFactoryImplementor;
/*      */ import org.hibernate.engine.StatefulPersistenceContext;
/*      */ import org.hibernate.engine.Status;
/*      */ import org.hibernate.engine.query.FilterQueryPlan;
/*      */ import org.hibernate.engine.query.HQLQueryPlan;
/*      */ import org.hibernate.engine.query.QueryPlanCache;
/*      */ import org.hibernate.event.AutoFlushEvent;
/*      */ import org.hibernate.event.AutoFlushEventListener;
/*      */ import org.hibernate.event.DeleteEvent;
/*      */ import org.hibernate.event.DeleteEventListener;
/*      */ import org.hibernate.event.DirtyCheckEvent;
/*      */ import org.hibernate.event.DirtyCheckEventListener;
/*      */ import org.hibernate.event.EventListeners;
/*      */ import org.hibernate.event.EventSource;
/*      */ import org.hibernate.event.EvictEvent;
/*      */ import org.hibernate.event.EvictEventListener;
/*      */ import org.hibernate.event.FlushEvent;
/*      */ import org.hibernate.event.FlushEventListener;
/*      */ import org.hibernate.event.InitializeCollectionEvent;
/*      */ import org.hibernate.event.InitializeCollectionEventListener;
/*      */ import org.hibernate.event.LoadEvent;
/*      */ import org.hibernate.event.LoadEventListener;
/*      */ import org.hibernate.event.LoadEventListener.LoadType;
/*      */ import org.hibernate.event.LockEvent;
/*      */ import org.hibernate.event.LockEventListener;
/*      */ import org.hibernate.event.MergeEvent;
/*      */ import org.hibernate.event.MergeEventListener;
/*      */ import org.hibernate.event.PersistEvent;
/*      */ import org.hibernate.event.PersistEventListener;
/*      */ import org.hibernate.event.RefreshEvent;
/*      */ import org.hibernate.event.RefreshEventListener;
/*      */ import org.hibernate.event.ReplicateEvent;
/*      */ import org.hibernate.event.ReplicateEventListener;
/*      */ import org.hibernate.event.SaveOrUpdateEvent;
/*      */ import org.hibernate.event.SaveOrUpdateEventListener;
/*      */ import org.hibernate.jdbc.Batcher;
/*      */ import org.hibernate.jdbc.ConnectionManager;
/*      */ import org.hibernate.jdbc.JDBCContext;
/*      */ import org.hibernate.jdbc.JDBCContext.Context;
/*      */ import org.hibernate.loader.criteria.CriteriaLoader;
/*      */ import org.hibernate.loader.custom.CustomLoader;
/*      */ import org.hibernate.loader.custom.CustomQuery;
/*      */ import org.hibernate.persister.collection.CollectionPersister;
/*      */ import org.hibernate.persister.entity.EntityPersister;
/*      */ import org.hibernate.persister.entity.OuterJoinLoadable;
/*      */ import org.hibernate.pretty.MessageHelper;
/*      */ import org.hibernate.proxy.HibernateProxy;
/*      */ import org.hibernate.proxy.LazyInitializer;
/*      */ import org.hibernate.stat.SessionStatistics;
/*      */ import org.hibernate.stat.SessionStatisticsImpl;
/*      */ import org.hibernate.stat.Statistics;
/*      */ import org.hibernate.stat.StatisticsImplementor;
/*      */ import org.hibernate.type.Type;
/*      */ import org.hibernate.util.ArrayHelper;
/*      */ import org.hibernate.util.CollectionHelper;
/*      */ import org.hibernate.util.StringHelper;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class SessionImpl
/*      */   extends AbstractSessionImpl
/*      */   implements EventSource, org.hibernate.classic.Session, JDBCContext.Context
/*      */ {
/*  121 */   private static final Log log = LogFactory.getLog(SessionImpl.class);
/*      */   
/*  123 */   private EntityMode entityMode = EntityMode.POJO;
/*      */   
/*      */   private boolean autoClear;
/*      */   private final long timestamp;
/*  127 */   private FlushMode flushMode = FlushMode.AUTO;
/*  128 */   private CacheMode cacheMode = CacheMode.NORMAL;
/*      */   
/*      */   private transient Interceptor interceptor;
/*      */   
/*  132 */   private transient int dontFlushFromFind = 0;
/*      */   
/*      */   private ActionQueue actionQueue;
/*      */   
/*      */   private StatefulPersistenceContext persistenceContext;
/*      */   
/*      */   private transient JDBCContext jdbcContext;
/*      */   
/*      */   private transient EventListeners listeners;
/*      */   private final boolean flushBeforeCompletionEnabled;
/*      */   private final boolean autoCloseSessionEnabled;
/*      */   private final ConnectionReleaseMode connectionReleaseMode;
/*      */   private String fetchProfile;
/*  145 */   private Map enabledFilters = new HashMap();
/*      */   
/*  147 */   private boolean isRootSession = true;
/*      */   private Map childSessionsByEntityMode;
/*      */   
/*      */   public org.hibernate.Session getSession(EntityMode entityMode)
/*      */   {
/*  152 */     errorIfClosed();
/*  153 */     checkTransactionSynchStatus();
/*      */     
/*  155 */     if (this.entityMode == entityMode) {
/*  156 */       return this;
/*      */     }
/*      */     
/*  159 */     if (this.childSessionsByEntityMode == null) {
/*  160 */       this.childSessionsByEntityMode = new HashMap();
/*      */     }
/*      */     
/*  163 */     SessionImpl rtn = (SessionImpl)this.childSessionsByEntityMode.get(entityMode);
/*  164 */     if (rtn == null) {
/*  165 */       rtn = new SessionImpl(this, entityMode);
/*  166 */       this.childSessionsByEntityMode.put(entityMode, rtn);
/*      */     }
/*      */     
/*  169 */     return rtn;
/*      */   }
/*      */   
/*      */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException
/*      */   {
/*  174 */     log.trace("deserializing session");
/*      */     
/*  176 */     this.interceptor = ((Interceptor)ois.readObject());
/*  177 */     this.factory = ((SessionFactoryImpl)ois.readObject());
/*      */     
/*  179 */     this.listeners = this.factory.getEventListeners();
/*  180 */     this.jdbcContext = ((JDBCContext)ois.readObject());
/*  181 */     ois.defaultReadObject();
/*      */     
/*  183 */     Iterator iter = this.enabledFilters.values().iterator();
/*  184 */     while (iter.hasNext()) {
/*  185 */       ((FilterImpl)iter.next()).afterDeserialize(this.factory);
/*      */     }
/*      */   }
/*      */   
/*      */   private void writeObject(ObjectOutputStream oos) throws IOException {
/*  190 */     if (!this.jdbcContext.getConnectionManager().isReadyForSerialization()) {
/*  191 */       throw new IllegalStateException("Cannot serialize a session while connected");
/*      */     }
/*      */     
/*  194 */     log.trace("serializing session");
/*      */     
/*  196 */     oos.writeObject(this.interceptor);
/*  197 */     oos.writeObject(this.factory);
/*  198 */     oos.writeObject(this.jdbcContext);
/*  199 */     oos.defaultWriteObject();
/*      */   }
/*      */   
/*      */   public void clear()
/*      */   {
/*  204 */     errorIfClosed();
/*  205 */     checkTransactionSynchStatus();
/*  206 */     this.persistenceContext.clear();
/*  207 */     this.actionQueue.clear();
/*      */   }
/*      */   
/*      */   private SessionImpl(SessionImpl parent, EntityMode entityMode) {
/*  211 */     super(parent.factory);
/*      */     
/*  213 */     this.timestamp = parent.timestamp;
/*      */     
/*  215 */     this.jdbcContext = parent.jdbcContext;
/*      */     
/*  217 */     this.interceptor = parent.interceptor;
/*  218 */     this.listeners = parent.listeners;
/*      */     
/*  220 */     this.actionQueue = new ActionQueue(this);
/*      */     
/*  222 */     this.entityMode = entityMode;
/*  223 */     this.persistenceContext = new StatefulPersistenceContext(this);
/*      */     
/*  225 */     this.flushBeforeCompletionEnabled = false;
/*  226 */     this.autoCloseSessionEnabled = false;
/*  227 */     this.connectionReleaseMode = null;
/*      */     
/*  229 */     this.isRootSession = false;
/*      */     
/*  231 */     if (this.factory.getStatistics().isStatisticsEnabled()) {
/*  232 */       this.factory.getStatisticsImplementor().openSession();
/*      */     }
/*      */     
/*  235 */     log.debug("opened session [" + entityMode + "]");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   SessionImpl(Connection connection, SessionFactoryImpl factory, boolean autoclose, long timestamp, Interceptor interceptor, EntityMode entityMode, boolean flushBeforeCompletionEnabled, boolean autoCloseSessionEnabled, ConnectionReleaseMode connectionReleaseMode)
/*      */   {
/*  248 */     super(factory);
/*      */     
/*  250 */     this.timestamp = timestamp;
/*      */     
/*  252 */     this.entityMode = entityMode;
/*      */     
/*  254 */     this.interceptor = interceptor;
/*  255 */     this.listeners = factory.getEventListeners();
/*      */     
/*  257 */     this.actionQueue = new ActionQueue(this);
/*  258 */     this.persistenceContext = new StatefulPersistenceContext(this);
/*      */     
/*  260 */     this.isRootSession = true;
/*      */     
/*  262 */     this.flushBeforeCompletionEnabled = flushBeforeCompletionEnabled;
/*  263 */     this.autoCloseSessionEnabled = autoCloseSessionEnabled;
/*  264 */     this.connectionReleaseMode = connectionReleaseMode;
/*      */     
/*  266 */     this.jdbcContext = new JDBCContext(this, connection, interceptor);
/*      */     
/*  268 */     if (factory.getStatistics().isStatisticsEnabled()) {
/*  269 */       factory.getStatisticsImplementor().openSession();
/*      */     }
/*      */     
/*  272 */     if (log.isDebugEnabled()) {
/*  273 */       log.debug("opened session at timestamp: " + timestamp);
/*      */     }
/*      */   }
/*      */   
/*      */   public Batcher getBatcher() {
/*  278 */     errorIfClosed();
/*  279 */     checkTransactionSynchStatus();
/*      */     
/*      */ 
/*  282 */     return this.jdbcContext.getConnectionManager().getBatcher();
/*      */   }
/*      */   
/*      */   public long getTimestamp() {
/*  286 */     checkTransactionSynchStatus();
/*  287 */     return this.timestamp;
/*      */   }
/*      */   
/*      */   public Connection close() throws HibernateException {
/*  291 */     log.trace("closing session");
/*  292 */     if (isClosed()) {
/*  293 */       throw new SessionException("Session was already closed");
/*      */     }
/*      */     
/*      */ 
/*  297 */     if (this.factory.getStatistics().isStatisticsEnabled()) {
/*  298 */       this.factory.getStatisticsImplementor().closeSession();
/*      */     }
/*      */     try
/*      */     {
/*      */       try {
/*  303 */         if (this.childSessionsByEntityMode != null) {
/*  304 */           Iterator childSessions = this.childSessionsByEntityMode.values().iterator();
/*  305 */           while (childSessions.hasNext()) {
/*  306 */             SessionImpl child = (SessionImpl)childSessions.next();
/*  307 */             child.close();
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (Throwable t) {}
/*      */       
/*      */ 
/*      */ 
/*  315 */       if (this.isRootSession) {
/*  316 */         return this.jdbcContext.getConnectionManager().close();
/*      */       }
/*      */       
/*  319 */       return null;
/*      */     }
/*      */     finally
/*      */     {
/*  323 */       setClosed();
/*  324 */       cleanup();
/*      */     }
/*      */   }
/*      */   
/*      */   public ConnectionReleaseMode getConnectionReleaseMode() {
/*  329 */     checkTransactionSynchStatus();
/*  330 */     return this.connectionReleaseMode;
/*      */   }
/*      */   
/*      */   public boolean isAutoCloseSessionEnabled() {
/*  334 */     return this.autoCloseSessionEnabled;
/*      */   }
/*      */   
/*      */   public boolean isOpen() {
/*  338 */     checkTransactionSynchStatus();
/*  339 */     return !isClosed();
/*      */   }
/*      */   
/*      */   public boolean isFlushModeNever() {
/*  343 */     return getFlushMode() == FlushMode.NEVER;
/*      */   }
/*      */   
/*      */   public boolean isFlushBeforeCompletionEnabled() {
/*  347 */     return this.flushBeforeCompletionEnabled;
/*      */   }
/*      */   
/*      */   public void managedFlush() {
/*  351 */     if (isClosed()) {
/*  352 */       log.trace("skipping auto-flush due to session closed");
/*  353 */       return;
/*      */     }
/*  355 */     log.trace("automatically flushing session");
/*  356 */     flush();
/*      */     
/*  358 */     if (this.childSessionsByEntityMode != null) {
/*  359 */       Iterator iter = this.childSessionsByEntityMode.values().iterator();
/*  360 */       while (iter.hasNext()) {
/*  361 */         ((org.hibernate.Session)iter.next()).flush();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean shouldAutoClose() {
/*  367 */     return (isAutoCloseSessionEnabled()) && (isOpen());
/*      */   }
/*      */   
/*      */   public void managedClose() {
/*  371 */     log.trace("automatically closing session");
/*  372 */     close();
/*      */   }
/*      */   
/*      */   public Connection connection() throws HibernateException {
/*  376 */     errorIfClosed();
/*  377 */     return this.jdbcContext.borrowConnection();
/*      */   }
/*      */   
/*      */   public boolean isConnected() {
/*  381 */     checkTransactionSynchStatus();
/*  382 */     return (!isClosed()) && (this.jdbcContext.getConnectionManager().isCurrentlyConnected());
/*      */   }
/*      */   
/*      */   public boolean isTransactionInProgress() {
/*  386 */     checkTransactionSynchStatus();
/*  387 */     return (!isClosed()) && (this.jdbcContext.isTransactionInProgress());
/*      */   }
/*      */   
/*      */   public Connection disconnect() throws HibernateException {
/*  391 */     errorIfClosed();
/*  392 */     log.debug("disconnecting session");
/*  393 */     return this.jdbcContext.getConnectionManager().manualDisconnect();
/*      */   }
/*      */   
/*      */   public void reconnect() throws HibernateException {
/*  397 */     errorIfClosed();
/*  398 */     log.debug("reconnecting session");
/*  399 */     checkTransactionSynchStatus();
/*  400 */     this.jdbcContext.getConnectionManager().manualReconnect();
/*      */   }
/*      */   
/*      */   public void reconnect(Connection conn) throws HibernateException {
/*  404 */     errorIfClosed();
/*  405 */     log.debug("reconnecting session");
/*  406 */     checkTransactionSynchStatus();
/*  407 */     this.jdbcContext.getConnectionManager().manualReconnect(conn);
/*      */   }
/*      */   
/*      */   public void beforeTransactionCompletion(Transaction tx) {
/*  411 */     log.trace("before transaction completion");
/*      */     
/*  413 */     if (this.isRootSession) {
/*      */       try
/*      */       {
/*  416 */         this.interceptor.beforeTransactionCompletion(tx);
/*      */       }
/*      */       catch (Throwable t) {
/*  419 */         log.error("exception in interceptor beforeTransactionCompletion()", t);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void setAutoClear(boolean enabled) {
/*  425 */     errorIfClosed();
/*  426 */     this.autoClear = enabled;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void afterOperation(boolean success)
/*      */   {
/*  436 */     if (!this.jdbcContext.isTransactionInProgress()) {
/*  437 */       this.jdbcContext.afterNontransactionalQuery(success);
/*      */     }
/*      */   }
/*      */   
/*      */   public void afterTransactionCompletion(boolean success, Transaction tx) {
/*  442 */     log.trace("after transaction completion");
/*      */     
/*  444 */     this.persistenceContext.afterTransactionCompletion();
/*  445 */     this.actionQueue.afterTransactionCompletion(success);
/*      */     
/*  447 */     if ((this.isRootSession) && (tx != null)) {
/*      */       try
/*      */       {
/*  450 */         this.interceptor.afterTransactionCompletion(tx);
/*      */       }
/*      */       catch (Throwable t) {
/*  453 */         log.error("exception in interceptor beforeTransactionCompletion()", t);
/*      */       }
/*      */     }
/*      */     
/*  457 */     if (this.autoClear) {
/*  458 */       clear();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void cleanup()
/*      */   {
/*  469 */     this.persistenceContext.clear();
/*      */   }
/*      */   
/*      */   public LockMode getCurrentLockMode(Object object) throws HibernateException {
/*  473 */     errorIfClosed();
/*  474 */     checkTransactionSynchStatus();
/*  475 */     if (object == null) {
/*  476 */       throw new NullPointerException("null object passed to getCurrentLockMode()");
/*      */     }
/*  478 */     if ((object instanceof HibernateProxy)) {
/*  479 */       object = ((HibernateProxy)object).getHibernateLazyInitializer().getImplementation(this);
/*  480 */       if (object == null) {
/*  481 */         return LockMode.NONE;
/*      */       }
/*      */     }
/*  484 */     EntityEntry e = this.persistenceContext.getEntry(object);
/*  485 */     if (e == null) {
/*  486 */       throw new TransientObjectException("Given object not associated with the session");
/*      */     }
/*  488 */     if (e.getStatus() != Status.MANAGED) {
/*  489 */       throw new ObjectDeletedException("The given object was deleted", e.getId(), e.getPersister().getEntityName());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  495 */     return e.getLockMode();
/*      */   }
/*      */   
/*      */   public Object getEntityUsingInterceptor(EntityKey key) throws HibernateException {
/*  499 */     errorIfClosed();
/*      */     
/*      */ 
/*  502 */     Object result = this.persistenceContext.getEntity(key);
/*  503 */     if (result == null) {
/*  504 */       Object newObject = this.interceptor.getEntity(key.getEntityName(), key.getIdentifier());
/*  505 */       if (newObject != null) {
/*  506 */         lock(newObject, LockMode.NONE);
/*      */       }
/*  508 */       return newObject;
/*      */     }
/*      */     
/*  511 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void saveOrUpdate(Object object)
/*      */     throws HibernateException
/*      */   {
/*  519 */     saveOrUpdate(null, object);
/*      */   }
/*      */   
/*      */   public void saveOrUpdate(String entityName, Object obj) throws HibernateException {
/*  523 */     fireSaveOrUpdate(new SaveOrUpdateEvent(entityName, obj, this));
/*      */   }
/*      */   
/*      */   private void fireSaveOrUpdate(SaveOrUpdateEvent event) {
/*  527 */     errorIfClosed();
/*  528 */     checkTransactionSynchStatus();
/*  529 */     SaveOrUpdateEventListener[] saveOrUpdateEventListener = this.listeners.getSaveOrUpdateEventListeners();
/*  530 */     for (int i = 0; i < saveOrUpdateEventListener.length; i++) {
/*  531 */       saveOrUpdateEventListener[i].onSaveOrUpdate(event);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void save(Object obj, Serializable id)
/*      */     throws HibernateException
/*      */   {
/*  539 */     save(null, obj, id);
/*      */   }
/*      */   
/*      */   public Serializable save(Object obj) throws HibernateException {
/*  543 */     return save(null, obj);
/*      */   }
/*      */   
/*      */   public Serializable save(String entityName, Object object) throws HibernateException {
/*  547 */     return fireSave(new SaveOrUpdateEvent(entityName, object, this));
/*      */   }
/*      */   
/*      */   public void save(String entityName, Object object, Serializable id) throws HibernateException {
/*  551 */     fireSave(new SaveOrUpdateEvent(entityName, object, id, this));
/*      */   }
/*      */   
/*      */   private Serializable fireSave(SaveOrUpdateEvent event) {
/*  555 */     errorIfClosed();
/*  556 */     checkTransactionSynchStatus();
/*  557 */     SaveOrUpdateEventListener[] saveEventListener = this.listeners.getSaveEventListeners();
/*  558 */     for (int i = 0; i < saveEventListener.length; i++) {
/*  559 */       saveEventListener[i].onSaveOrUpdate(event);
/*      */     }
/*  561 */     return event.getResultId();
/*      */   }
/*      */   
/*      */ 
/*      */   public void update(Object obj)
/*      */     throws HibernateException
/*      */   {
/*  568 */     update(null, obj);
/*      */   }
/*      */   
/*      */   public void update(Object obj, Serializable id) throws HibernateException {
/*  572 */     update(null, obj, id);
/*      */   }
/*      */   
/*      */   public void update(String entityName, Object object) throws HibernateException {
/*  576 */     fireUpdate(new SaveOrUpdateEvent(entityName, object, this));
/*      */   }
/*      */   
/*      */   public void update(String entityName, Object object, Serializable id) throws HibernateException {
/*  580 */     fireUpdate(new SaveOrUpdateEvent(entityName, object, id, this));
/*      */   }
/*      */   
/*      */   private void fireUpdate(SaveOrUpdateEvent event) {
/*  584 */     errorIfClosed();
/*  585 */     checkTransactionSynchStatus();
/*  586 */     SaveOrUpdateEventListener[] updateEventListener = this.listeners.getUpdateEventListeners();
/*  587 */     for (int i = 0; i < updateEventListener.length; i++) {
/*  588 */       updateEventListener[i].onSaveOrUpdate(event);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void lock(String entityName, Object object, LockMode lockMode)
/*      */     throws HibernateException
/*      */   {
/*  596 */     fireLock(new LockEvent(entityName, object, lockMode, this));
/*      */   }
/*      */   
/*      */   public void lock(Object object, LockMode lockMode) throws HibernateException {
/*  600 */     fireLock(new LockEvent(object, lockMode, this));
/*      */   }
/*      */   
/*      */   private void fireLock(LockEvent lockEvent) {
/*  604 */     errorIfClosed();
/*  605 */     checkTransactionSynchStatus();
/*  606 */     LockEventListener[] lockEventListener = this.listeners.getLockEventListeners();
/*  607 */     for (int i = 0; i < lockEventListener.length; i++) {
/*  608 */       lockEventListener[i].onLock(lockEvent);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void persist(String entityName, Object object)
/*      */     throws HibernateException
/*      */   {
/*  616 */     firePersist(new PersistEvent(entityName, object, this));
/*      */   }
/*      */   
/*      */   public void persist(Object object) throws HibernateException {
/*  620 */     persist(null, object);
/*      */   }
/*      */   
/*      */   public void persist(String entityName, Object object, Map copiedAlready) throws HibernateException
/*      */   {
/*  625 */     firePersist(copiedAlready, new PersistEvent(entityName, object, this));
/*      */   }
/*      */   
/*      */   private void firePersist(Map copiedAlready, PersistEvent event) {
/*  629 */     errorIfClosed();
/*  630 */     checkTransactionSynchStatus();
/*  631 */     PersistEventListener[] persistEventListener = this.listeners.getPersistEventListeners();
/*  632 */     for (int i = 0; i < persistEventListener.length; i++) {
/*  633 */       persistEventListener[i].onPersist(event, copiedAlready);
/*      */     }
/*      */   }
/*      */   
/*      */   private void firePersist(PersistEvent event) {
/*  638 */     errorIfClosed();
/*  639 */     checkTransactionSynchStatus();
/*  640 */     PersistEventListener[] createEventListener = this.listeners.getPersistEventListeners();
/*  641 */     for (int i = 0; i < createEventListener.length; i++) {
/*  642 */       createEventListener[i].onPersist(event);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void persistOnFlush(String entityName, Object object)
/*      */     throws HibernateException
/*      */   {
/*  651 */     firePersistOnFlush(new PersistEvent(entityName, object, this));
/*      */   }
/*      */   
/*      */   public void persistOnFlush(Object object) throws HibernateException {
/*  655 */     persist(null, object);
/*      */   }
/*      */   
/*      */   public void persistOnFlush(String entityName, Object object, Map copiedAlready) throws HibernateException
/*      */   {
/*  660 */     firePersistOnFlush(copiedAlready, new PersistEvent(entityName, object, this));
/*      */   }
/*      */   
/*      */   private void firePersistOnFlush(Map copiedAlready, PersistEvent event) {
/*  664 */     errorIfClosed();
/*  665 */     checkTransactionSynchStatus();
/*  666 */     PersistEventListener[] persistEventListener = this.listeners.getPersistOnFlushEventListeners();
/*  667 */     for (int i = 0; i < persistEventListener.length; i++) {
/*  668 */       persistEventListener[i].onPersist(event, copiedAlready);
/*      */     }
/*      */   }
/*      */   
/*      */   private void firePersistOnFlush(PersistEvent event) {
/*  673 */     errorIfClosed();
/*  674 */     checkTransactionSynchStatus();
/*  675 */     PersistEventListener[] createEventListener = this.listeners.getPersistOnFlushEventListeners();
/*  676 */     for (int i = 0; i < createEventListener.length; i++) {
/*  677 */       createEventListener[i].onPersist(event);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Object merge(String entityName, Object object)
/*      */     throws HibernateException
/*      */   {
/*  685 */     return fireMerge(new MergeEvent(entityName, object, this));
/*      */   }
/*      */   
/*      */   public Object merge(Object object) throws HibernateException {
/*  689 */     return merge(null, object);
/*      */   }
/*      */   
/*      */   public void merge(String entityName, Object object, Map copiedAlready) throws HibernateException {
/*  693 */     fireMerge(copiedAlready, new MergeEvent(entityName, object, this));
/*      */   }
/*      */   
/*      */   private Object fireMerge(MergeEvent event) {
/*  697 */     errorIfClosed();
/*  698 */     checkTransactionSynchStatus();
/*  699 */     MergeEventListener[] mergeEventListener = this.listeners.getMergeEventListeners();
/*  700 */     for (int i = 0; i < mergeEventListener.length; i++) {
/*  701 */       mergeEventListener[i].onMerge(event);
/*      */     }
/*  703 */     return event.getResult();
/*      */   }
/*      */   
/*      */   private void fireMerge(Map copiedAlready, MergeEvent event) {
/*  707 */     errorIfClosed();
/*  708 */     checkTransactionSynchStatus();
/*  709 */     MergeEventListener[] mergeEventListener = this.listeners.getMergeEventListeners();
/*  710 */     for (int i = 0; i < mergeEventListener.length; i++) {
/*  711 */       mergeEventListener[i].onMerge(event, copiedAlready);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Object saveOrUpdateCopy(String entityName, Object object)
/*      */     throws HibernateException
/*      */   {
/*  720 */     return fireSaveOrUpdateCopy(new MergeEvent(entityName, object, this));
/*      */   }
/*      */   
/*      */   public Object saveOrUpdateCopy(Object object) throws HibernateException {
/*  724 */     return saveOrUpdateCopy(null, object);
/*      */   }
/*      */   
/*      */   public Object saveOrUpdateCopy(String entityName, Object object, Serializable id) throws HibernateException
/*      */   {
/*  729 */     return fireSaveOrUpdateCopy(new MergeEvent(entityName, object, id, this));
/*      */   }
/*      */   
/*      */   public Object saveOrUpdateCopy(Object object, Serializable id) throws HibernateException
/*      */   {
/*  734 */     return saveOrUpdateCopy(null, object, id);
/*      */   }
/*      */   
/*      */   public void saveOrUpdateCopy(String entityName, Object object, Map copiedAlready) throws HibernateException
/*      */   {
/*  739 */     fireSaveOrUpdateCopy(copiedAlready, new MergeEvent(entityName, object, this));
/*      */   }
/*      */   
/*      */   private void fireSaveOrUpdateCopy(Map copiedAlready, MergeEvent event) {
/*  743 */     errorIfClosed();
/*  744 */     checkTransactionSynchStatus();
/*  745 */     MergeEventListener[] saveOrUpdateCopyEventListener = this.listeners.getSaveOrUpdateCopyEventListeners();
/*  746 */     for (int i = 0; i < saveOrUpdateCopyEventListener.length; i++) {
/*  747 */       saveOrUpdateCopyEventListener[i].onMerge(event, copiedAlready);
/*      */     }
/*      */   }
/*      */   
/*      */   private Object fireSaveOrUpdateCopy(MergeEvent event) {
/*  752 */     errorIfClosed();
/*  753 */     checkTransactionSynchStatus();
/*  754 */     MergeEventListener[] saveOrUpdateCopyEventListener = this.listeners.getSaveOrUpdateCopyEventListeners();
/*  755 */     for (int i = 0; i < saveOrUpdateCopyEventListener.length; i++) {
/*  756 */       saveOrUpdateCopyEventListener[i].onMerge(event);
/*      */     }
/*  758 */     return event.getResult();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void delete(Object object)
/*      */     throws HibernateException
/*      */   {
/*  768 */     fireDelete(new DeleteEvent(object, this));
/*      */   }
/*      */   
/*      */ 
/*      */   public void delete(String entityName, Object object)
/*      */     throws HibernateException
/*      */   {
/*  775 */     fireDelete(new DeleteEvent(entityName, object, this));
/*      */   }
/*      */   
/*      */ 
/*      */   public void delete(String entityName, Object object, boolean isCascadeDeleteEnabled)
/*      */     throws HibernateException
/*      */   {
/*  782 */     fireDelete(new DeleteEvent(entityName, object, isCascadeDeleteEnabled, this));
/*      */   }
/*      */   
/*      */   private void fireDelete(DeleteEvent event) {
/*  786 */     errorIfClosed();
/*  787 */     checkTransactionSynchStatus();
/*  788 */     DeleteEventListener[] deleteEventListener = this.listeners.getDeleteEventListeners();
/*  789 */     for (int i = 0; i < deleteEventListener.length; i++) {
/*  790 */       deleteEventListener[i].onDelete(event);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void load(Object object, Serializable id)
/*      */     throws HibernateException
/*      */   {
/*  798 */     LoadEvent event = new LoadEvent(id, object, this);
/*  799 */     fireLoad(event, LoadEventListener.RELOAD);
/*      */   }
/*      */   
/*      */   public Object load(Class entityClass, Serializable id) throws HibernateException {
/*  803 */     return load(entityClass.getName(), id);
/*      */   }
/*      */   
/*      */   public Object load(String entityName, Serializable id) throws HibernateException {
/*  807 */     LoadEvent event = new LoadEvent(id, entityName, false, this);
/*  808 */     boolean success = false;
/*      */     try {
/*  810 */       fireLoad(event, LoadEventListener.LOAD);
/*  811 */       ObjectNotFoundException.throwIfNull(event.getResult(), id, entityName);
/*  812 */       success = true;
/*  813 */       return event.getResult();
/*      */     }
/*      */     finally {
/*  816 */       afterOperation(success);
/*      */     }
/*      */   }
/*      */   
/*      */   public Object get(Class entityClass, Serializable id) throws HibernateException {
/*  821 */     return get(entityClass.getName(), id);
/*      */   }
/*      */   
/*      */   public Object get(String entityName, Serializable id) throws HibernateException {
/*  825 */     LoadEvent event = new LoadEvent(id, entityName, false, this);
/*  826 */     boolean success = false;
/*      */     try {
/*  828 */       fireLoad(event, LoadEventListener.GET);
/*  829 */       success = true;
/*  830 */       return event.getResult();
/*      */     }
/*      */     finally {
/*  833 */       afterOperation(success);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object immediateLoad(String entityName, Serializable id)
/*      */     throws HibernateException
/*      */   {
/*  843 */     if (log.isDebugEnabled()) {
/*  844 */       EntityPersister persister = getFactory().getEntityPersister(entityName);
/*  845 */       log.debug("initializing proxy: " + MessageHelper.infoString(persister, id, getFactory()));
/*      */     }
/*      */     
/*  848 */     LoadEvent event = new LoadEvent(id, entityName, true, this);
/*  849 */     fireLoad(event, LoadEventListener.IMMEDIATE_LOAD);
/*  850 */     return event.getResult();
/*      */   }
/*      */   
/*      */   public Object internalLoad(String entityName, Serializable id, boolean eager, boolean nullable) throws HibernateException
/*      */   {
/*  855 */     LoadEventListener.LoadType type = eager ? LoadEventListener.INTERNAL_LOAD_EAGER : nullable ? LoadEventListener.INTERNAL_LOAD_NULLABLE : LoadEventListener.INTERNAL_LOAD_LAZY;
/*      */     
/*      */ 
/*  858 */     LoadEvent event = new LoadEvent(id, entityName, true, this);
/*  859 */     fireLoad(event, type);
/*  860 */     if (!nullable) {
/*  861 */       UnresolvableObjectException.throwIfNull(event.getResult(), id, entityName);
/*      */     }
/*  863 */     return event.getResult();
/*      */   }
/*      */   
/*      */   public Object load(Class entityClass, Serializable id, LockMode lockMode) throws HibernateException {
/*  867 */     return load(entityClass.getName(), id, lockMode);
/*      */   }
/*      */   
/*      */   public Object load(String entityName, Serializable id, LockMode lockMode) throws HibernateException {
/*  871 */     LoadEvent event = new LoadEvent(id, entityName, lockMode, this);
/*  872 */     fireLoad(event, LoadEventListener.LOAD);
/*  873 */     return event.getResult();
/*      */   }
/*      */   
/*      */   public Object get(Class entityClass, Serializable id, LockMode lockMode) throws HibernateException {
/*  877 */     return get(entityClass.getName(), id, lockMode);
/*      */   }
/*      */   
/*      */   public Object get(String entityName, Serializable id, LockMode lockMode) throws HibernateException {
/*  881 */     LoadEvent event = new LoadEvent(id, entityName, lockMode, this);
/*  882 */     fireLoad(event, LoadEventListener.GET);
/*  883 */     return event.getResult();
/*      */   }
/*      */   
/*      */   private void fireLoad(LoadEvent event, LoadEventListener.LoadType loadType) {
/*  887 */     errorIfClosed();
/*  888 */     checkTransactionSynchStatus();
/*  889 */     LoadEventListener[] loadEventListener = this.listeners.getLoadEventListeners();
/*  890 */     for (int i = 0; i < loadEventListener.length; i++) {
/*  891 */       loadEventListener[i].onLoad(event, loadType);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void refresh(Object object)
/*      */     throws HibernateException
/*      */   {
/*  899 */     fireRefresh(new RefreshEvent(object, this));
/*      */   }
/*      */   
/*      */   public void refresh(Object object, LockMode lockMode) throws HibernateException {
/*  903 */     fireRefresh(new RefreshEvent(object, lockMode, this));
/*      */   }
/*      */   
/*      */   public void refresh(Object object, Map refreshedAlready) throws HibernateException {
/*  907 */     fireRefresh(refreshedAlready, new RefreshEvent(object, this));
/*      */   }
/*      */   
/*      */   private void fireRefresh(RefreshEvent refreshEvent) {
/*  911 */     errorIfClosed();
/*  912 */     checkTransactionSynchStatus();
/*  913 */     RefreshEventListener[] refreshEventListener = this.listeners.getRefreshEventListeners();
/*  914 */     for (int i = 0; i < refreshEventListener.length; i++) {
/*  915 */       refreshEventListener[i].onRefresh(refreshEvent);
/*      */     }
/*      */   }
/*      */   
/*      */   private void fireRefresh(Map refreshedAlready, RefreshEvent refreshEvent) {
/*  920 */     errorIfClosed();
/*  921 */     checkTransactionSynchStatus();
/*  922 */     RefreshEventListener[] refreshEventListener = this.listeners.getRefreshEventListeners();
/*  923 */     for (int i = 0; i < refreshEventListener.length; i++) {
/*  924 */       refreshEventListener[i].onRefresh(refreshEvent, refreshedAlready);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void replicate(Object obj, ReplicationMode replicationMode)
/*      */     throws HibernateException
/*      */   {
/*  932 */     fireReplicate(new ReplicateEvent(obj, replicationMode, this));
/*      */   }
/*      */   
/*      */   public void replicate(String entityName, Object obj, ReplicationMode replicationMode) throws HibernateException
/*      */   {
/*  937 */     fireReplicate(new ReplicateEvent(entityName, obj, replicationMode, this));
/*      */   }
/*      */   
/*      */   private void fireReplicate(ReplicateEvent event) {
/*  941 */     errorIfClosed();
/*  942 */     checkTransactionSynchStatus();
/*  943 */     ReplicateEventListener[] replicateEventListener = this.listeners.getReplicateEventListeners();
/*  944 */     for (int i = 0; i < replicateEventListener.length; i++) {
/*  945 */       replicateEventListener[i].onReplicate(event);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void evict(Object object)
/*      */     throws HibernateException
/*      */   {
/*  957 */     fireEvict(new EvictEvent(object, this));
/*      */   }
/*      */   
/*      */   private void fireEvict(EvictEvent evictEvent) {
/*  961 */     errorIfClosed();
/*  962 */     checkTransactionSynchStatus();
/*  963 */     EvictEventListener[] evictEventListener = this.listeners.getEvictEventListeners();
/*  964 */     for (int i = 0; i < evictEventListener.length; i++) {
/*  965 */       evictEventListener[i].onEvict(evictEvent);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected boolean autoFlushIfRequired(Set querySpaces)
/*      */     throws HibernateException
/*      */   {
/*  974 */     errorIfClosed();
/*  975 */     AutoFlushEvent event = new AutoFlushEvent(querySpaces, this);
/*  976 */     AutoFlushEventListener[] autoFlushEventListener = this.listeners.getAutoFlushEventListeners();
/*  977 */     for (int i = 0; i < autoFlushEventListener.length; i++) {
/*  978 */       autoFlushEventListener[i].onAutoFlush(event);
/*      */     }
/*  980 */     return event.isFlushRequired();
/*      */   }
/*      */   
/*      */   public boolean isDirty() throws HibernateException {
/*  984 */     errorIfClosed();
/*  985 */     checkTransactionSynchStatus();
/*  986 */     log.debug("checking session dirtiness");
/*  987 */     if (this.actionQueue.areInsertionsOrDeletionsQueued()) {
/*  988 */       log.debug("session dirty (scheduled updates and insertions)");
/*  989 */       return true;
/*      */     }
/*      */     
/*  992 */     DirtyCheckEvent event = new DirtyCheckEvent(this);
/*  993 */     DirtyCheckEventListener[] dirtyCheckEventListener = this.listeners.getDirtyCheckEventListeners();
/*  994 */     for (int i = 0; i < dirtyCheckEventListener.length; i++) {
/*  995 */       dirtyCheckEventListener[i].onDirtyCheck(event);
/*      */     }
/*  997 */     return event.isDirty();
/*      */   }
/*      */   
/*      */   public void flush() throws HibernateException
/*      */   {
/* 1002 */     errorIfClosed();
/* 1003 */     checkTransactionSynchStatus();
/* 1004 */     if (this.persistenceContext.getCascadeLevel() > 0) {
/* 1005 */       throw new HibernateException("Flush during cascade is dangerous");
/*      */     }
/* 1007 */     FlushEventListener[] flushEventListener = this.listeners.getFlushEventListeners();
/* 1008 */     for (int i = 0; i < flushEventListener.length; i++) {
/* 1009 */       flushEventListener[i].onFlush(new FlushEvent(this));
/*      */     }
/*      */   }
/*      */   
/*      */   public void forceFlush(EntityEntry entityEntry) throws HibernateException {
/* 1014 */     errorIfClosed();
/* 1015 */     if (log.isDebugEnabled()) {
/* 1016 */       log.debug("flushing to force deletion of re-saved object: " + MessageHelper.infoString(entityEntry.getPersister(), entityEntry.getId(), getFactory()));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1022 */     if (this.persistenceContext.getCascadeLevel() > 0) {
/* 1023 */       throw new ObjectDeletedException("deleted object would be re-saved by cascade (remove deleted object from associations)", entityEntry.getId(), entityEntry.getPersister().getEntityName());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1030 */     flush();
/*      */   }
/*      */   
/*      */   public Filter getEnabledFilter(String filterName) {
/* 1034 */     checkTransactionSynchStatus();
/* 1035 */     return (Filter)this.enabledFilters.get(filterName);
/*      */   }
/*      */   
/*      */   public Filter enableFilter(String filterName) {
/* 1039 */     errorIfClosed();
/* 1040 */     checkTransactionSynchStatus();
/* 1041 */     FilterImpl filter = new FilterImpl(this.factory.getFilterDefinition(filterName));
/* 1042 */     this.enabledFilters.put(filterName, filter);
/* 1043 */     return filter;
/*      */   }
/*      */   
/*      */   public void disableFilter(String filterName) {
/* 1047 */     errorIfClosed();
/* 1048 */     checkTransactionSynchStatus();
/* 1049 */     this.enabledFilters.remove(filterName);
/*      */   }
/*      */   
/*      */   public Object getFilterParameterValue(String filterParameterName) {
/* 1053 */     errorIfClosed();
/* 1054 */     checkTransactionSynchStatus();
/* 1055 */     String[] parsed = parseFilterParameterName(filterParameterName);
/* 1056 */     FilterImpl filter = (FilterImpl)this.enabledFilters.get(parsed[0]);
/* 1057 */     if (filter == null) {
/* 1058 */       throw new IllegalArgumentException("Filter [" + parsed[0] + "] currently not enabled");
/*      */     }
/* 1060 */     return filter.getParameter(parsed[1]);
/*      */   }
/*      */   
/*      */   public Type getFilterParameterType(String filterParameterName) {
/* 1064 */     errorIfClosed();
/* 1065 */     checkTransactionSynchStatus();
/* 1066 */     String[] parsed = parseFilterParameterName(filterParameterName);
/* 1067 */     FilterDefinition filterDef = this.factory.getFilterDefinition(parsed[0]);
/* 1068 */     if (filterDef == null) {
/* 1069 */       throw new IllegalArgumentException("Filter [" + parsed[0] + "] not defined");
/*      */     }
/* 1071 */     Type type = filterDef.getParameterType(parsed[1]);
/* 1072 */     if (type == null)
/*      */     {
/* 1074 */       throw new InternalError("Unable to locate type for filter parameter");
/*      */     }
/* 1076 */     return type;
/*      */   }
/*      */   
/*      */   public Map getEnabledFilters() {
/* 1080 */     errorIfClosed();
/* 1081 */     checkTransactionSynchStatus();
/*      */     
/*      */ 
/* 1084 */     Iterator itr = this.enabledFilters.values().iterator();
/* 1085 */     while (itr.hasNext()) {
/* 1086 */       Filter filter = (Filter)itr.next();
/* 1087 */       filter.validate();
/*      */     }
/* 1089 */     return this.enabledFilters;
/*      */   }
/*      */   
/*      */   private String[] parseFilterParameterName(String filterParameterName) {
/* 1093 */     int dot = filterParameterName.indexOf('.');
/* 1094 */     if (dot <= 0) {
/* 1095 */       throw new IllegalArgumentException("Invalid filter-parameter name format");
/*      */     }
/* 1097 */     String filterName = filterParameterName.substring(0, dot);
/* 1098 */     String parameterName = filterParameterName.substring(dot + 1);
/* 1099 */     return new String[] { filterName, parameterName };
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public List find(String query)
/*      */     throws HibernateException
/*      */   {
/* 1107 */     return list(query, new QueryParameters());
/*      */   }
/*      */   
/*      */   public List find(String query, Object value, Type type) throws HibernateException {
/* 1111 */     return list(query, new QueryParameters(type, value));
/*      */   }
/*      */   
/*      */   public List find(String query, Object[] values, Type[] types) throws HibernateException {
/* 1115 */     return list(query, new QueryParameters(types, values));
/*      */   }
/*      */   
/*      */   public List list(String query, QueryParameters queryParameters) throws HibernateException {
/* 1119 */     errorIfClosed();
/* 1120 */     checkTransactionSynchStatus();
/* 1121 */     queryParameters.validateParameters();
/* 1122 */     HQLQueryPlan plan = getHQLQueryPlan(query, false);
/*      */     
/* 1124 */     List results = CollectionHelper.EMPTY_LIST;
/* 1125 */     boolean success = false;
/*      */     
/* 1127 */     this.dontFlushFromFind += 1;
/*      */     try {
/* 1129 */       results = plan.performList(queryParameters, this);
/* 1130 */       success = true;
/*      */     }
/*      */     finally {
/* 1133 */       this.dontFlushFromFind -= 1;
/* 1134 */       afterOperation(success);
/*      */     }
/* 1136 */     return results;
/*      */   }
/*      */   
/*      */   public int executeUpdate(String query, QueryParameters queryParameters) throws HibernateException {
/* 1140 */     errorIfClosed();
/* 1141 */     checkTransactionSynchStatus();
/* 1142 */     queryParameters.validateParameters();
/* 1143 */     HQLQueryPlan plan = getHQLQueryPlan(query, false);
/*      */     
/* 1145 */     boolean success = false;
/* 1146 */     int result = 0;
/*      */     try {
/* 1148 */       result = plan.performExecuteUpdate(queryParameters, this);
/* 1149 */       success = true;
/*      */     }
/*      */     finally {
/* 1152 */       afterOperation(success);
/*      */     }
/* 1154 */     return result;
/*      */   }
/*      */   
/*      */   public Iterator iterate(String query) throws HibernateException {
/* 1158 */     return iterate(query, new QueryParameters());
/*      */   }
/*      */   
/*      */   public Iterator iterate(String query, Object value, Type type) throws HibernateException {
/* 1162 */     return iterate(query, new QueryParameters(type, value));
/*      */   }
/*      */   
/*      */   public Iterator iterate(String query, Object[] values, Type[] types) throws HibernateException {
/* 1166 */     return iterate(query, new QueryParameters(types, values));
/*      */   }
/*      */   
/*      */   public Iterator iterate(String query, QueryParameters queryParameters) throws HibernateException {
/* 1170 */     errorIfClosed();
/* 1171 */     checkTransactionSynchStatus();
/* 1172 */     queryParameters.validateParameters();
/* 1173 */     HQLQueryPlan plan = getHQLQueryPlan(query, true);
/*      */     
/* 1175 */     this.dontFlushFromFind += 1;
/*      */     try {
/* 1177 */       return plan.performIterate(queryParameters, this);
/*      */     }
/*      */     finally {
/* 1180 */       this.dontFlushFromFind -= 1;
/*      */     }
/*      */   }
/*      */   
/*      */   public ScrollableResults scroll(String query, QueryParameters queryParameters) throws HibernateException {
/* 1185 */     errorIfClosed();
/* 1186 */     checkTransactionSynchStatus();
/* 1187 */     HQLQueryPlan plan = getHQLQueryPlan(query, false);
/* 1188 */     autoFlushIfRequired(plan.getQuerySpaces());
/* 1189 */     this.dontFlushFromFind += 1;
/*      */     try {
/* 1191 */       return plan.performScroll(queryParameters, this);
/*      */     }
/*      */     finally {
/* 1194 */       this.dontFlushFromFind -= 1;
/*      */     }
/*      */   }
/*      */   
/*      */   public int delete(String query) throws HibernateException {
/* 1199 */     return delete(query, ArrayHelper.EMPTY_OBJECT_ARRAY, ArrayHelper.EMPTY_TYPE_ARRAY);
/*      */   }
/*      */   
/*      */   public int delete(String query, Object value, Type type) throws HibernateException {
/* 1203 */     return delete(query, new Object[] { value }, new Type[] { type });
/*      */   }
/*      */   
/*      */   public int delete(String query, Object[] values, Type[] types) throws HibernateException {
/* 1207 */     errorIfClosed();
/* 1208 */     checkTransactionSynchStatus();
/* 1209 */     if (query == null) {
/* 1210 */       throw new IllegalArgumentException("attempt to perform delete-by-query with null query");
/*      */     }
/*      */     
/* 1213 */     if (log.isTraceEnabled()) {
/* 1214 */       log.trace("delete: " + query);
/* 1215 */       if (values.length != 0) {
/* 1216 */         log.trace("parameters: " + StringHelper.toString(values));
/*      */       }
/*      */     }
/*      */     
/* 1220 */     List list = find(query, values, types);
/* 1221 */     int deletionCount = list.size();
/* 1222 */     for (int i = 0; i < deletionCount; i++) {
/* 1223 */       delete(list.get(i));
/*      */     }
/*      */     
/* 1226 */     return deletionCount;
/*      */   }
/*      */   
/*      */   public Query createFilter(Object collection, String queryString) {
/* 1230 */     errorIfClosed();
/* 1231 */     checkTransactionSynchStatus();
/* 1232 */     CollectionFilterImpl filter = new CollectionFilterImpl(queryString, collection, this, getFilterQueryPlan(collection, queryString, null, false).getParameterMetadata());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1238 */     filter.setComment(queryString);
/* 1239 */     return filter;
/*      */   }
/*      */   
/*      */   public Query getNamedQuery(String queryName) throws MappingException {
/* 1243 */     errorIfClosed();
/* 1244 */     checkTransactionSynchStatus();
/* 1245 */     return super.getNamedQuery(queryName);
/*      */   }
/*      */   
/*      */   public Object instantiate(String entityName, Serializable id) throws HibernateException {
/* 1249 */     return instantiate(this.factory.getEntityPersister(entityName), id);
/*      */   }
/*      */   
/*      */ 
/*      */   public Object instantiate(EntityPersister persister, Serializable id)
/*      */     throws HibernateException
/*      */   {
/* 1256 */     errorIfClosed();
/* 1257 */     checkTransactionSynchStatus();
/* 1258 */     Object result = this.interceptor.instantiate(persister.getEntityName(), this.entityMode, id);
/* 1259 */     if (result == null) {
/* 1260 */       result = persister.instantiate(id, this.entityMode);
/*      */     }
/* 1262 */     return result;
/*      */   }
/*      */   
/*      */   public EntityMode getEntityMode() {
/* 1266 */     checkTransactionSynchStatus();
/* 1267 */     return this.entityMode;
/*      */   }
/*      */   
/*      */   public void setFlushMode(FlushMode flushMode) {
/* 1271 */     errorIfClosed();
/* 1272 */     checkTransactionSynchStatus();
/* 1273 */     if (log.isTraceEnabled()) {
/* 1274 */       log.trace("setting flush mode to: " + flushMode);
/*      */     }
/* 1276 */     this.flushMode = flushMode;
/*      */   }
/*      */   
/*      */   public FlushMode getFlushMode() {
/* 1280 */     checkTransactionSynchStatus();
/* 1281 */     return this.flushMode;
/*      */   }
/*      */   
/*      */   public CacheMode getCacheMode() {
/* 1285 */     checkTransactionSynchStatus();
/* 1286 */     return this.cacheMode;
/*      */   }
/*      */   
/*      */   public void setCacheMode(CacheMode cacheMode) {
/* 1290 */     errorIfClosed();
/* 1291 */     checkTransactionSynchStatus();
/* 1292 */     if (log.isTraceEnabled()) {
/* 1293 */       log.trace("setting cache mode to: " + cacheMode);
/*      */     }
/* 1295 */     this.cacheMode = cacheMode;
/*      */   }
/*      */   
/*      */   public Transaction getTransaction() throws HibernateException {
/* 1299 */     errorIfClosed();
/* 1300 */     return this.jdbcContext.getTransaction();
/*      */   }
/*      */   
/*      */   public Transaction beginTransaction() throws HibernateException {
/* 1304 */     errorIfClosed();
/* 1305 */     if (!this.isRootSession) {
/* 1306 */       log.warn("Transaction started on non-root session");
/*      */     }
/* 1308 */     Transaction result = getTransaction();
/* 1309 */     result.begin();
/* 1310 */     return result;
/*      */   }
/*      */   
/*      */   public void afterTransactionBegin(Transaction tx) {
/* 1314 */     errorIfClosed();
/* 1315 */     this.interceptor.afterTransactionBegin(tx);
/*      */   }
/*      */   
/*      */   public EntityPersister getEntityPersister(String entityName, Object object) {
/* 1319 */     errorIfClosed();
/* 1320 */     if (entityName == null) {
/* 1321 */       return this.factory.getEntityPersister(guessEntityName(object));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 1330 */       return this.factory.getEntityPersister(entityName).getSubclassEntityPersister(object, getFactory(), this.entityMode);
/*      */     }
/*      */     catch (HibernateException e)
/*      */     {
/*      */       try {
/* 1335 */         return getEntityPersister(null, object);
/*      */       }
/*      */       catch (HibernateException e2) {
/* 1338 */         throw e;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public Serializable getIdentifier(Object object)
/*      */     throws HibernateException
/*      */   {
/* 1346 */     errorIfClosed();
/* 1347 */     checkTransactionSynchStatus();
/* 1348 */     if ((object instanceof HibernateProxy)) {
/* 1349 */       LazyInitializer li = ((HibernateProxy)object).getHibernateLazyInitializer();
/* 1350 */       if (li.getSession() != this) {
/* 1351 */         throw new TransientObjectException("The proxy was not associated with this session");
/*      */       }
/* 1353 */       return li.getIdentifier();
/*      */     }
/*      */     
/* 1356 */     EntityEntry entry = this.persistenceContext.getEntry(object);
/* 1357 */     if (entry == null) {
/* 1358 */       throw new TransientObjectException("The instance was not associated with this session");
/*      */     }
/* 1360 */     return entry.getId();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Serializable getContextEntityIdentifier(Object object)
/*      */   {
/* 1369 */     errorIfClosed();
/* 1370 */     if ((object instanceof HibernateProxy)) {
/* 1371 */       return getProxyIdentifier(object);
/*      */     }
/*      */     
/* 1374 */     EntityEntry entry = this.persistenceContext.getEntry(object);
/* 1375 */     return entry != null ? entry.getId() : null;
/*      */   }
/*      */   
/*      */   private Serializable getProxyIdentifier(Object proxy)
/*      */   {
/* 1380 */     return ((HibernateProxy)proxy).getHibernateLazyInitializer().getIdentifier();
/*      */   }
/*      */   
/*      */   public Collection filter(Object collection, String filter) throws HibernateException {
/* 1384 */     return listFilter(collection, filter, new QueryParameters(new Type[1], new Object[1]));
/*      */   }
/*      */   
/*      */   public Collection filter(Object collection, String filter, Object value, Type type) throws HibernateException {
/* 1388 */     return listFilter(collection, filter, new QueryParameters(new Type[] { null, type }, new Object[] { null, value }));
/*      */   }
/*      */   
/*      */   public Collection filter(Object collection, String filter, Object[] values, Type[] types) throws HibernateException
/*      */   {
/* 1393 */     Object[] vals = new Object[values.length + 1];
/* 1394 */     Type[] typs = new Type[types.length + 1];
/* 1395 */     System.arraycopy(values, 0, vals, 1, values.length);
/* 1396 */     System.arraycopy(types, 0, typs, 1, types.length);
/* 1397 */     return listFilter(collection, filter, new QueryParameters(typs, vals));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private FilterQueryPlan getFilterQueryPlan(Object collection, String filter, QueryParameters parameters, boolean shallow)
/*      */     throws HibernateException
/*      */   {
/* 1405 */     if (collection == null) {
/* 1406 */       throw new NullPointerException("null collection passed to filter");
/*      */     }
/*      */     
/* 1409 */     CollectionEntry entry = this.persistenceContext.getCollectionEntryOrNull(collection);
/* 1410 */     CollectionPersister roleBeforeFlush = entry == null ? null : entry.getLoadedPersister();
/*      */     
/* 1412 */     FilterQueryPlan plan = null;
/* 1413 */     if (roleBeforeFlush == null)
/*      */     {
/*      */ 
/* 1416 */       flush();
/* 1417 */       entry = this.persistenceContext.getCollectionEntryOrNull(collection);
/* 1418 */       CollectionPersister roleAfterFlush = entry == null ? null : entry.getLoadedPersister();
/* 1419 */       if (roleAfterFlush == null) {
/* 1420 */         throw new QueryException("The collection was unreferenced");
/*      */       }
/* 1422 */       plan = this.factory.getQueryPlanCache().getFilterQueryPlan(filter, roleAfterFlush.getRole(), shallow, getEnabledFilters());
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 1427 */       plan = this.factory.getQueryPlanCache().getFilterQueryPlan(filter, roleBeforeFlush.getRole(), shallow, getEnabledFilters());
/* 1428 */       if (autoFlushIfRequired(plan.getQuerySpaces()))
/*      */       {
/*      */ 
/* 1431 */         entry = this.persistenceContext.getCollectionEntryOrNull(collection);
/* 1432 */         CollectionPersister roleAfterFlush = entry == null ? null : entry.getLoadedPersister();
/* 1433 */         if (roleBeforeFlush != roleAfterFlush) {
/* 1434 */           if (roleAfterFlush == null) {
/* 1435 */             throw new QueryException("The collection was dereferenced");
/*      */           }
/* 1437 */           plan = this.factory.getQueryPlanCache().getFilterQueryPlan(filter, roleAfterFlush.getRole(), shallow, getEnabledFilters());
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1442 */     if (parameters != null) {
/* 1443 */       parameters.getPositionalParameterValues()[0] = entry.getLoadedKey();
/* 1444 */       parameters.getPositionalParameterTypes()[0] = entry.getLoadedPersister().getKeyType();
/*      */     }
/*      */     
/* 1447 */     return plan;
/*      */   }
/*      */   
/*      */   public List listFilter(Object collection, String filter, QueryParameters queryParameters) throws HibernateException
/*      */   {
/* 1452 */     errorIfClosed();
/* 1453 */     checkTransactionSynchStatus();
/* 1454 */     FilterQueryPlan plan = getFilterQueryPlan(collection, filter, queryParameters, false);
/* 1455 */     List results = CollectionHelper.EMPTY_LIST;
/*      */     
/* 1457 */     boolean success = false;
/* 1458 */     this.dontFlushFromFind += 1;
/*      */     try {
/* 1460 */       results = plan.performList(queryParameters, this);
/* 1461 */       success = true;
/*      */     }
/*      */     finally {
/* 1464 */       this.dontFlushFromFind -= 1;
/* 1465 */       afterOperation(success);
/*      */     }
/* 1467 */     return results;
/*      */   }
/*      */   
/*      */   public Iterator iterateFilter(Object collection, String filter, QueryParameters queryParameters) throws HibernateException
/*      */   {
/* 1472 */     errorIfClosed();
/* 1473 */     checkTransactionSynchStatus();
/* 1474 */     FilterQueryPlan plan = getFilterQueryPlan(collection, filter, queryParameters, true);
/* 1475 */     return plan.performIterate(queryParameters, this);
/*      */   }
/*      */   
/*      */   public Criteria createCriteria(Class persistentClass, String alias) {
/* 1479 */     errorIfClosed();
/* 1480 */     checkTransactionSynchStatus();
/* 1481 */     return new CriteriaImpl(persistentClass.getName(), alias, this);
/*      */   }
/*      */   
/*      */   public Criteria createCriteria(String entityName, String alias) {
/* 1485 */     errorIfClosed();
/* 1486 */     checkTransactionSynchStatus();
/* 1487 */     return new CriteriaImpl(entityName, alias, this);
/*      */   }
/*      */   
/*      */   public Criteria createCriteria(Class persistentClass) {
/* 1491 */     errorIfClosed();
/* 1492 */     checkTransactionSynchStatus();
/* 1493 */     return new CriteriaImpl(persistentClass.getName(), this);
/*      */   }
/*      */   
/*      */   public Criteria createCriteria(String entityName) {
/* 1497 */     errorIfClosed();
/* 1498 */     checkTransactionSynchStatus();
/* 1499 */     return new CriteriaImpl(entityName, this);
/*      */   }
/*      */   
/*      */   public ScrollableResults scroll(CriteriaImpl criteria, ScrollMode scrollMode) {
/* 1503 */     errorIfClosed();
/* 1504 */     checkTransactionSynchStatus();
/* 1505 */     String entityName = criteria.getEntityOrClassName();
/* 1506 */     CriteriaLoader loader = new CriteriaLoader(getOuterJoinLoadable(entityName), this.factory, criteria, entityName, getEnabledFilters());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1513 */     autoFlushIfRequired(loader.getQuerySpaces());
/* 1514 */     this.dontFlushFromFind += 1;
/*      */     try {
/* 1516 */       return loader.scroll(this, scrollMode);
/*      */     }
/*      */     finally {
/* 1519 */       this.dontFlushFromFind -= 1;
/*      */     }
/*      */   }
/*      */   
/*      */   public List list(CriteriaImpl criteria) throws HibernateException {
/* 1524 */     errorIfClosed();
/* 1525 */     checkTransactionSynchStatus();
/* 1526 */     String[] implementors = this.factory.getImplementors(criteria.getEntityOrClassName());
/* 1527 */     int size = implementors.length;
/*      */     
/* 1529 */     CriteriaLoader[] loaders = new CriteriaLoader[size];
/* 1530 */     Set spaces = new HashSet();
/* 1531 */     for (int i = 0; i < size; i++)
/*      */     {
/* 1533 */       loaders[i] = new CriteriaLoader(getOuterJoinLoadable(implementors[i]), this.factory, criteria, implementors[i], getEnabledFilters());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1541 */       spaces.addAll(loaders[i].getQuerySpaces());
/*      */     }
/*      */     
/*      */ 
/* 1545 */     autoFlushIfRequired(spaces);
/*      */     
/* 1547 */     List results = Collections.EMPTY_LIST;
/* 1548 */     this.dontFlushFromFind += 1;
/* 1549 */     boolean success = false;
/*      */     try {
/* 1551 */       for (int i = 0; i < size; i++) {
/* 1552 */         List currentResults = loaders[i].list(this);
/* 1553 */         currentResults.addAll(results);
/* 1554 */         results = currentResults;
/*      */       }
/* 1556 */       success = true;
/*      */     }
/*      */     finally {
/* 1559 */       this.dontFlushFromFind -= 1;
/* 1560 */       afterOperation(success);
/*      */     }
/*      */     
/* 1563 */     return results;
/*      */   }
/*      */   
/*      */   private OuterJoinLoadable getOuterJoinLoadable(String entityName) throws MappingException {
/* 1567 */     EntityPersister persister = this.factory.getEntityPersister(entityName);
/* 1568 */     if (!(persister instanceof OuterJoinLoadable)) {
/* 1569 */       throw new MappingException("class persister is not OuterJoinLoadable: " + entityName);
/*      */     }
/* 1571 */     return (OuterJoinLoadable)persister;
/*      */   }
/*      */   
/*      */   public boolean contains(Object object) {
/* 1575 */     errorIfClosed();
/* 1576 */     checkTransactionSynchStatus();
/* 1577 */     if ((object instanceof HibernateProxy))
/*      */     {
/*      */ 
/*      */ 
/* 1581 */       LazyInitializer li = ((HibernateProxy)object).getHibernateLazyInitializer();
/* 1582 */       if (li.isUninitialized())
/*      */       {
/*      */ 
/*      */ 
/* 1586 */         return li.getSession() == this;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1593 */       object = li.getImplementation();
/*      */     }
/*      */     
/* 1596 */     return this.persistenceContext.isEntryFor(object);
/*      */   }
/*      */   
/*      */   public Query createQuery(String queryString) {
/* 1600 */     errorIfClosed();
/* 1601 */     checkTransactionSynchStatus();
/* 1602 */     return super.createQuery(queryString);
/*      */   }
/*      */   
/*      */   public SQLQuery createSQLQuery(String sql) {
/* 1606 */     errorIfClosed();
/* 1607 */     checkTransactionSynchStatus();
/* 1608 */     return super.createSQLQuery(sql);
/*      */   }
/*      */   
/*      */   public Query createSQLQuery(String sql, String returnAlias, Class returnClass) {
/* 1612 */     errorIfClosed();
/* 1613 */     checkTransactionSynchStatus();
/* 1614 */     return new SQLQueryImpl(sql, new String[] { returnAlias }, new Class[] { returnClass }, this, this.factory.getQueryPlanCache().getSQLParameterMetadata(sql));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Query createSQLQuery(String sql, String[] returnAliases, Class[] returnClasses)
/*      */   {
/* 1624 */     errorIfClosed();
/* 1625 */     checkTransactionSynchStatus();
/* 1626 */     return new SQLQueryImpl(sql, returnAliases, returnClasses, this, this.factory.getQueryPlanCache().getSQLParameterMetadata(sql));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ScrollableResults scrollCustomQuery(CustomQuery customQuery, QueryParameters queryParameters)
/*      */     throws HibernateException
/*      */   {
/* 1637 */     errorIfClosed();
/* 1638 */     checkTransactionSynchStatus();
/*      */     
/* 1640 */     if (log.isTraceEnabled()) {
/* 1641 */       log.trace("scroll SQL query: " + customQuery.getSQL());
/*      */     }
/*      */     
/* 1644 */     CustomLoader loader = new CustomLoader(customQuery, getFactory());
/*      */     
/* 1646 */     autoFlushIfRequired(loader.getQuerySpaces());
/*      */     
/* 1648 */     this.dontFlushFromFind += 1;
/*      */     try {
/* 1650 */       return loader.scroll(queryParameters, this);
/*      */     }
/*      */     finally {
/* 1653 */       this.dontFlushFromFind -= 1;
/*      */     }
/*      */   }
/*      */   
/*      */   public List listCustomQuery(CustomQuery customQuery, QueryParameters queryParameters)
/*      */     throws HibernateException
/*      */   {
/* 1660 */     errorIfClosed();
/* 1661 */     checkTransactionSynchStatus();
/*      */     
/* 1663 */     if (log.isTraceEnabled()) {
/* 1664 */       log.trace("SQL query: " + customQuery.getSQL());
/*      */     }
/*      */     
/* 1667 */     CustomLoader loader = new CustomLoader(customQuery, getFactory());
/*      */     
/* 1669 */     autoFlushIfRequired(loader.getQuerySpaces());
/*      */     
/* 1671 */     this.dontFlushFromFind += 1;
/* 1672 */     boolean success = false;
/*      */     try {
/* 1674 */       List results = loader.list(this, queryParameters);
/* 1675 */       success = true;
/* 1676 */       return results;
/*      */     }
/*      */     finally {
/* 1679 */       this.dontFlushFromFind -= 1;
/* 1680 */       afterOperation(success);
/*      */     }
/*      */   }
/*      */   
/*      */   public SessionFactory getSessionFactory() {
/* 1685 */     checkTransactionSynchStatus();
/* 1686 */     return this.factory;
/*      */   }
/*      */   
/*      */   public void initializeCollection(PersistentCollection collection, boolean writing) throws HibernateException
/*      */   {
/* 1691 */     errorIfClosed();
/* 1692 */     checkTransactionSynchStatus();
/* 1693 */     InitializeCollectionEventListener[] listener = this.listeners.getInitializeCollectionEventListeners();
/* 1694 */     for (int i = 0; i < listener.length; i++) {
/* 1695 */       listener[i].onInitializeCollection(new InitializeCollectionEvent(collection, this));
/*      */     }
/*      */   }
/*      */   
/*      */   public String bestGuessEntityName(Object object) {
/* 1700 */     if ((object instanceof HibernateProxy)) {
/* 1701 */       object = ((HibernateProxy)object).getHibernateLazyInitializer().getImplementation();
/*      */     }
/* 1703 */     EntityEntry entry = this.persistenceContext.getEntry(object);
/* 1704 */     if (entry == null) {
/* 1705 */       return guessEntityName(object);
/*      */     }
/*      */     
/* 1708 */     return entry.getPersister().getEntityName();
/*      */   }
/*      */   
/*      */   public String getEntityName(Object object)
/*      */   {
/* 1713 */     errorIfClosed();
/* 1714 */     checkTransactionSynchStatus();
/* 1715 */     if ((object instanceof HibernateProxy)) {
/* 1716 */       if (!this.persistenceContext.containsProxy(object)) {
/* 1717 */         throw new TransientObjectException("proxy was not associated with the session");
/*      */       }
/* 1719 */       object = ((HibernateProxy)object).getHibernateLazyInitializer().getImplementation();
/*      */     }
/*      */     
/* 1722 */     EntityEntry entry = this.persistenceContext.getEntry(object);
/* 1723 */     if (entry == null) {
/* 1724 */       throwTransientObjectException(object);
/*      */     }
/* 1726 */     return entry.getPersister().getEntityName();
/*      */   }
/*      */   
/*      */   private void throwTransientObjectException(Object object) throws HibernateException {
/* 1730 */     throw new TransientObjectException("object references an unsaved transient instance - save the transient instance before flushing: " + guessEntityName(object));
/*      */   }
/*      */   
/*      */ 
/*      */   public String guessEntityName(Object object)
/*      */     throws HibernateException
/*      */   {
/* 1737 */     errorIfClosed();
/* 1738 */     String entity = this.interceptor.getEntityName(object);
/* 1739 */     if (entity == null) {
/* 1740 */       if ((object instanceof Map)) {
/* 1741 */         entity = (String)((Map)object).get("$type$");
/* 1742 */         if (entity == null) {
/* 1743 */           throw new HibernateException("could not determine type of dynamic entity");
/*      */         }
/*      */       }
/* 1746 */       else if ((object instanceof Element))
/*      */       {
/* 1748 */         entity = ((Element)object).getName();
/*      */       }
/*      */       else {
/* 1751 */         entity = object.getClass().getName();
/*      */       }
/*      */     }
/* 1754 */     return entity;
/*      */   }
/*      */   
/*      */   public void cancelQuery() throws HibernateException {
/* 1758 */     errorIfClosed();
/* 1759 */     getBatcher().cancelLastQuery();
/*      */   }
/*      */   
/*      */   public Interceptor getInterceptor() {
/* 1763 */     checkTransactionSynchStatus();
/* 1764 */     return this.interceptor;
/*      */   }
/*      */   
/*      */   public int getDontFlushFromFind() {
/* 1768 */     return this.dontFlushFromFind;
/*      */   }
/*      */   
/*      */   public String toString() {
/* 1772 */     StringBuffer buf = new StringBuffer(500).append("SessionImpl(");
/*      */     
/* 1774 */     if (isOpen()) {
/* 1775 */       buf.append(this.persistenceContext).append(";").append(this.actionQueue);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 1780 */       buf.append("<closed>");
/*      */     }
/* 1782 */     return ')';
/*      */   }
/*      */   
/*      */   public EventListeners getListeners() {
/* 1786 */     return this.listeners;
/*      */   }
/*      */   
/*      */   public ActionQueue getActionQueue() {
/* 1790 */     errorIfClosed();
/* 1791 */     checkTransactionSynchStatus();
/* 1792 */     return this.actionQueue;
/*      */   }
/*      */   
/*      */   public PersistenceContext getPersistenceContext() {
/* 1796 */     errorIfClosed();
/* 1797 */     checkTransactionSynchStatus();
/* 1798 */     return this.persistenceContext;
/*      */   }
/*      */   
/*      */   public SessionStatistics getStatistics() {
/* 1802 */     checkTransactionSynchStatus();
/* 1803 */     return new SessionStatisticsImpl(this);
/*      */   }
/*      */   
/*      */   public boolean isEventSource() {
/* 1807 */     checkTransactionSynchStatus();
/* 1808 */     return true;
/*      */   }
/*      */   
/*      */   public void setReadOnly(Object entity, boolean readOnly) {
/* 1812 */     errorIfClosed();
/* 1813 */     checkTransactionSynchStatus();
/* 1814 */     this.persistenceContext.setReadOnly(entity, readOnly);
/*      */   }
/*      */   
/*      */ 
/*      */   public void afterScrollOperation() {}
/*      */   
/*      */   public String getFetchProfile()
/*      */   {
/* 1822 */     checkTransactionSynchStatus();
/* 1823 */     return this.fetchProfile;
/*      */   }
/*      */   
/*      */   public JDBCContext getJDBCContext() {
/* 1827 */     errorIfClosed();
/* 1828 */     checkTransactionSynchStatus();
/* 1829 */     return this.jdbcContext;
/*      */   }
/*      */   
/*      */   public void setFetchProfile(String fetchProfile) {
/* 1833 */     errorIfClosed();
/* 1834 */     checkTransactionSynchStatus();
/* 1835 */     this.fetchProfile = fetchProfile;
/*      */   }
/*      */   
/*      */   private void checkTransactionSynchStatus() {
/* 1839 */     if ((this.jdbcContext != null) && (!isClosed())) {
/* 1840 */       this.jdbcContext.registerSynchronizationIfPossible();
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\impl\SessionImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */