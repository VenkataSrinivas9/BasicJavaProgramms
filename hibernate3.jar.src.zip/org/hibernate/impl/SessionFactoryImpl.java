/*     */ package org.hibernate.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.sql.Connection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import javax.naming.NamingException;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.StringRefAddr;
/*     */ import javax.transaction.TransactionManager;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.ConnectionReleaseMode;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Interceptor;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.hibernate.StatelessSession;
/*     */ import org.hibernate.cache.CacheConcurrencyStrategy;
/*     */ import org.hibernate.cache.CacheFactory;
/*     */ import org.hibernate.cache.CacheKey;
/*     */ import org.hibernate.cache.CacheProvider;
/*     */ import org.hibernate.cache.QueryCache;
/*     */ import org.hibernate.cache.QueryCacheFactory;
/*     */ import org.hibernate.cache.UpdateTimestampsCache;
/*     */ import org.hibernate.cfg.Configuration;
/*     */ import org.hibernate.cfg.Settings;
/*     */ import org.hibernate.classic.Session;
/*     */ import org.hibernate.connection.ConnectionProvider;
/*     */ import org.hibernate.context.CurrentSessionContext;
/*     */ import org.hibernate.context.JTASessionContext;
/*     */ import org.hibernate.context.ThreadLocalSessionContext;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.engine.FilterDefinition;
/*     */ import org.hibernate.engine.Mapping;
/*     */ import org.hibernate.engine.NamedQueryDefinition;
/*     */ import org.hibernate.engine.NamedSQLQueryDefinition;
/*     */ import org.hibernate.engine.ResultSetMappingDefinition;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.query.HQLQueryPlan;
/*     */ import org.hibernate.engine.query.NativeSQLQuerySpecification;
/*     */ import org.hibernate.engine.query.QueryPlanCache;
/*     */ import org.hibernate.engine.query.ReturnMetadata;
/*     */ import org.hibernate.event.EventListeners;
/*     */ import org.hibernate.exception.SQLExceptionConverter;
/*     */ import org.hibernate.id.IdentifierGenerator;
/*     */ import org.hibernate.id.UUIDHexGenerator;
/*     */ import org.hibernate.jdbc.BatcherFactory;
/*     */ import org.hibernate.mapping.KeyValue;
/*     */ import org.hibernate.mapping.PersistentClass;
/*     */ import org.hibernate.mapping.RootClass;
/*     */ import org.hibernate.metadata.ClassMetadata;
/*     */ import org.hibernate.metadata.CollectionMetadata;
/*     */ import org.hibernate.persister.PersisterFactory;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.persister.entity.Queryable;
/*     */ import org.hibernate.pretty.MessageHelper;
/*     */ import org.hibernate.stat.Statistics;
/*     */ import org.hibernate.stat.StatisticsImpl;
/*     */ import org.hibernate.stat.StatisticsImplementor;
/*     */ import org.hibernate.tool.hbm2ddl.SchemaExport;
/*     */ import org.hibernate.tool.hbm2ddl.SchemaUpdate;
/*     */ import org.hibernate.tool.hbm2ddl.SchemaValidator;
/*     */ import org.hibernate.transaction.TransactionFactory;
/*     */ import org.hibernate.transaction.TransactionManagerLookup;
/*     */ import org.hibernate.type.AssociationType;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.CollectionHelper;
/*     */ import org.hibernate.util.ReflectHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SessionFactoryImpl
/*     */   implements SessionFactory, SessionFactoryImplementor
/*     */ {
/*     */   private final String name;
/*     */   private final String uuid;
/*     */   private final transient Map entityPersisters;
/*     */   private final transient Map classMetadata;
/*     */   private final transient Map collectionPersisters;
/*     */   private final transient Map collectionMetadata;
/*     */   private final transient Map collectionRolesByEntityParticipant;
/*     */   private final transient Map identifierGenerators;
/*     */   private final transient Map namedQueries;
/*     */   private final transient Map namedSqlQueries;
/*     */   private final transient Map sqlResultSetMappings;
/*     */   private final transient Map filters;
/*     */   private final transient Map imports;
/*     */   private final transient Interceptor interceptor;
/*     */   private final transient Settings settings;
/*     */   private final transient Properties properties;
/*     */   private transient SchemaExport schemaExport;
/*     */   private final transient TransactionManager transactionManager;
/*     */   private final transient QueryCache queryCache;
/*     */   private final transient UpdateTimestampsCache updateTimestampsCache;
/*     */   private final transient Map queryCaches;
/* 133 */   private final transient Map allCacheRegions = new HashMap();
/* 134 */   private final transient StatisticsImpl statistics = new StatisticsImpl(this);
/*     */   
/*     */   private final transient EventListeners eventListeners;
/*     */   private final transient CurrentSessionContext currentSessionContext;
/* 138 */   private final QueryPlanCache queryPlanCache = new QueryPlanCache(this);
/*     */   
/* 140 */   private transient boolean isClosed = false;
/*     */   
/* 142 */   private static final IdentifierGenerator UUID_GENERATOR = new UUIDHexGenerator();
/*     */   
/* 144 */   private static final Log log = LogFactory.getLog(SessionFactoryImpl.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SessionFactoryImpl(Configuration cfg, Mapping mapping, Settings settings, EventListeners listeners)
/*     */     throws HibernateException
/*     */   {
/* 153 */     log.info("building session factory");
/*     */     
/* 155 */     this.properties = new Properties();
/* 156 */     this.properties.putAll(cfg.getProperties());
/* 157 */     this.interceptor = cfg.getInterceptor();
/* 158 */     this.settings = settings;
/* 159 */     this.eventListeners = listeners;
/* 160 */     this.filters = new HashMap();
/* 161 */     this.filters.putAll(cfg.getFilterDefinitions());
/*     */     
/* 163 */     if (log.isDebugEnabled()) {
/* 164 */       log.debug("Session factory constructed with filter configurations : " + this.filters);
/*     */     }
/*     */     
/* 167 */     if (log.isDebugEnabled()) { log.debug("instantiating session factory with properties: " + this.properties);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 172 */     settings.getCacheProvider().start(this.properties);
/*     */     
/*     */ 
/*     */ 
/* 176 */     this.identifierGenerators = new HashMap();
/* 177 */     Iterator classes = cfg.getClassMappings();
/* 178 */     while (classes.hasNext()) {
/* 179 */       PersistentClass model = (PersistentClass)classes.next();
/* 180 */       if (!model.isInherited()) {
/* 181 */         IdentifierGenerator generator = model.getIdentifier().createIdentifierGenerator(settings.getDialect(), settings.getDefaultCatalogName(), settings.getDefaultSchemaName(), (RootClass)model);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 187 */         this.identifierGenerators.put(model.getEntityName(), generator);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 193 */     Map caches = new HashMap();
/* 194 */     this.entityPersisters = new HashMap();
/* 195 */     Map classMeta = new HashMap();
/* 196 */     classes = cfg.getClassMappings();
/* 197 */     while (classes.hasNext()) {
/* 198 */       PersistentClass model = (PersistentClass)classes.next();
/* 199 */       model.prepareTemporaryTables(mapping, settings.getDialect());
/* 200 */       String cacheRegion = model.getRootClass().getCacheRegionName();
/* 201 */       CacheConcurrencyStrategy cache = (CacheConcurrencyStrategy)caches.get(cacheRegion);
/* 202 */       if (cache == null) {
/* 203 */         cache = CacheFactory.createCache(model.getCacheConcurrencyStrategy(), cacheRegion, model.isMutable(), settings, this.properties);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 210 */         if (cache != null) {
/* 211 */           caches.put(cacheRegion, cache);
/* 212 */           this.allCacheRegions.put(cache.getRegionName(), cache.getCache());
/*     */         }
/*     */       }
/* 215 */       EntityPersister cp = PersisterFactory.createClassPersister(model, cache, this, mapping);
/* 216 */       this.entityPersisters.put(model.getEntityName(), cp);
/* 217 */       classMeta.put(model.getEntityName(), cp.getClassMetadata());
/*     */     }
/* 219 */     this.classMetadata = Collections.unmodifiableMap(classMeta);
/*     */     
/* 221 */     Map tmpEntityToCollectionRoleMap = new HashMap();
/* 222 */     this.collectionPersisters = new HashMap();
/* 223 */     Iterator collections = cfg.getCollectionMappings();
/* 224 */     while (collections.hasNext()) {
/* 225 */       org.hibernate.mapping.Collection model = (org.hibernate.mapping.Collection)collections.next();
/* 226 */       CacheConcurrencyStrategy cache = CacheFactory.createCache(model.getCacheConcurrencyStrategy(), model.getCacheRegionName(), true, settings, this.properties);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 233 */       if (cache != null) this.allCacheRegions.put(cache.getRegionName(), cache.getCache());
/* 234 */       CollectionPersister persister = PersisterFactory.createCollectionPersister(cfg, model, cache, this);
/* 235 */       this.collectionPersisters.put(model.getRole(), persister.getCollectionMetadata());
/* 236 */       Type indexType = persister.getIndexType();
/* 237 */       if ((indexType != null) && (indexType.isAssociationType()) && (!indexType.isAnyType())) {
/* 238 */         String entityName = ((AssociationType)indexType).getAssociatedEntityName(this);
/* 239 */         Set roles = (Set)tmpEntityToCollectionRoleMap.get(entityName);
/* 240 */         if (roles == null) {
/* 241 */           roles = new HashSet();
/* 242 */           tmpEntityToCollectionRoleMap.put(entityName, roles);
/*     */         }
/* 244 */         roles.add(persister.getRole());
/*     */       }
/* 246 */       Type elementType = persister.getElementType();
/* 247 */       if ((elementType.isAssociationType()) && (!elementType.isAnyType())) {
/* 248 */         String entityName = ((AssociationType)elementType).getAssociatedEntityName(this);
/* 249 */         Set roles = (Set)tmpEntityToCollectionRoleMap.get(entityName);
/* 250 */         if (roles == null) {
/* 251 */           roles = new HashSet();
/* 252 */           tmpEntityToCollectionRoleMap.put(entityName, roles);
/*     */         }
/* 254 */         roles.add(persister.getRole());
/*     */       }
/*     */     }
/* 257 */     this.collectionMetadata = Collections.unmodifiableMap(this.collectionPersisters);
/* 258 */     Iterator itr = tmpEntityToCollectionRoleMap.entrySet().iterator();
/* 259 */     while (itr.hasNext()) {
/* 260 */       Map.Entry entry = (Map.Entry)itr.next();
/* 261 */       entry.setValue(Collections.unmodifiableSet((Set)entry.getValue()));
/*     */     }
/* 263 */     this.collectionRolesByEntityParticipant = Collections.unmodifiableMap(tmpEntityToCollectionRoleMap);
/*     */     
/*     */ 
/* 266 */     this.namedQueries = new HashMap(cfg.getNamedQueries());
/* 267 */     this.namedSqlQueries = new HashMap(cfg.getNamedSQLQueries());
/* 268 */     this.sqlResultSetMappings = new HashMap(cfg.getSqlResultSetMappings());
/* 269 */     this.imports = new HashMap(cfg.getImports());
/*     */     
/*     */ 
/* 272 */     Iterator iter = this.entityPersisters.values().iterator();
/* 273 */     while (iter.hasNext()) {
/* 274 */       ((EntityPersister)iter.next()).postInstantiate();
/*     */     }
/* 276 */     iter = this.collectionPersisters.values().iterator();
/* 277 */     while (iter.hasNext()) {
/* 278 */       ((CollectionPersister)iter.next()).postInstantiate();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 283 */     this.name = settings.getSessionFactoryName();
/*     */     try {
/* 285 */       this.uuid = ((String)UUID_GENERATOR.generate(null, null));
/*     */     }
/*     */     catch (Exception e) {
/* 288 */       throw new AssertionFailure("Could not generate UUID");
/*     */     }
/* 290 */     SessionFactoryObjectFactory.addInstance(this.uuid, this.name, this, this.properties);
/*     */     
/* 292 */     log.debug("instantiated session factory");
/*     */     
/* 294 */     if (settings.isAutoCreateSchema()) new SchemaExport(cfg, settings).create(false, true);
/* 295 */     if (settings.isAutoUpdateSchema()) new SchemaUpdate(cfg, settings).execute(false, true);
/* 296 */     if (settings.isAutoValidateSchema()) new SchemaValidator(cfg, settings).validate();
/* 297 */     if (settings.isAutoDropSchema()) { this.schemaExport = new SchemaExport(cfg, settings);
/*     */     }
/* 299 */     if (settings.getTransactionManagerLookup() != null) {
/* 300 */       log.debug("obtaining JTA TransactionManager");
/* 301 */       this.transactionManager = settings.getTransactionManagerLookup().getTransactionManager(this.properties);
/*     */     }
/*     */     else {
/* 304 */       if (settings.getTransactionFactory().isTransactionManagerRequired()) {
/* 305 */         throw new HibernateException("The chosen transaction strategy requires access to the JTA TransactionManager");
/*     */       }
/* 307 */       this.transactionManager = null;
/*     */     }
/*     */     
/* 310 */     this.currentSessionContext = buildCurrentSessionContext();
/*     */     
/* 312 */     if (settings.isQueryCacheEnabled()) {
/* 313 */       this.updateTimestampsCache = new UpdateTimestampsCache(settings, this.properties);
/* 314 */       this.queryCache = settings.getQueryCacheFactory().getQueryCache(null, this.updateTimestampsCache, settings, this.properties);
/*     */       
/* 316 */       this.queryCaches = new HashMap();
/* 317 */       this.allCacheRegions.put(this.updateTimestampsCache.getRegionName(), this.updateTimestampsCache.getCache());
/* 318 */       this.allCacheRegions.put(this.queryCache.getRegionName(), this.queryCache.getCache());
/*     */     }
/*     */     else {
/* 321 */       this.updateTimestampsCache = null;
/* 322 */       this.queryCache = null;
/* 323 */       this.queryCaches = null;
/*     */     }
/*     */     
/*     */ 
/* 327 */     Map errors = checkNamedQueries();
/* 328 */     if (!errors.isEmpty()) {
/* 329 */       Set keys = errors.keySet();
/* 330 */       StringBuffer failingQueries = new StringBuffer("Errors in named queries: ");
/* 331 */       for (Iterator iterator = keys.iterator(); iterator.hasNext();) {
/* 332 */         String queryName = (String)iterator.next();
/* 333 */         HibernateException e = (HibernateException)errors.get(queryName);
/* 334 */         failingQueries.append(queryName);
/* 335 */         if (iterator.hasNext()) failingQueries.append(", ");
/* 336 */         log.error("Error in named query: " + queryName, e);
/*     */       }
/* 338 */       throw new HibernateException(failingQueries.toString());
/*     */     }
/*     */     
/*     */ 
/* 342 */     getStatistics().setStatisticsEnabled(settings.isStatisticsEnabled());
/*     */   }
/*     */   
/*     */   public QueryPlanCache getQueryPlanCache() {
/* 346 */     return this.queryPlanCache;
/*     */   }
/*     */   
/*     */   private Map checkNamedQueries() throws HibernateException {
/* 350 */     Map errors = new HashMap();
/*     */     
/*     */ 
/* 353 */     log.debug("Checking " + this.namedQueries.size() + " named HQL queries");
/* 354 */     Iterator itr = this.namedQueries.entrySet().iterator();
/* 355 */     while (itr.hasNext()) {
/* 356 */       Map.Entry entry = (Map.Entry)itr.next();
/* 357 */       String queryName = (String)entry.getKey();
/* 358 */       NamedQueryDefinition qd = (NamedQueryDefinition)entry.getValue();
/*     */       try
/*     */       {
/* 361 */         log.debug("Checking named query: " + queryName);
/*     */         
/* 363 */         this.queryPlanCache.getHQLQueryPlan(qd.getQueryString(), false, CollectionHelper.EMPTY_MAP);
/*     */       }
/*     */       catch (QueryException e) {
/* 366 */         errors.put(queryName, e);
/*     */       }
/*     */       catch (MappingException e) {
/* 369 */         errors.put(queryName, e);
/*     */       }
/*     */     }
/*     */     
/* 373 */     log.debug("Checking " + this.namedSqlQueries.size() + " named SQL queries");
/* 374 */     itr = this.namedSqlQueries.entrySet().iterator();
/* 375 */     while (itr.hasNext()) {
/* 376 */       Map.Entry entry = (Map.Entry)itr.next();
/* 377 */       String queryName = (String)entry.getKey();
/* 378 */       NamedSQLQueryDefinition qd = (NamedSQLQueryDefinition)entry.getValue();
/*     */       try
/*     */       {
/* 381 */         log.debug("Checking named SQL query: " + queryName);
/*     */         
/*     */ 
/* 384 */         NativeSQLQuerySpecification spec = null;
/* 385 */         if (qd.getResultSetRef() != null) {
/* 386 */           ResultSetMappingDefinition definition = (ResultSetMappingDefinition)this.sqlResultSetMappings.get(qd.getResultSetRef());
/*     */           
/* 388 */           if (definition == null) {
/* 389 */             throw new MappingException("Unable to find resultset-ref definition: " + qd.getResultSetRef());
/*     */           }
/*     */           
/*     */ 
/* 393 */           spec = new NativeSQLQuerySpecification(qd.getQueryString(), definition.getEntityQueryReturns(), definition.getScalarQueryReturns(), qd.getQuerySpaces());
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/* 402 */           spec = new NativeSQLQuerySpecification(qd.getQueryString(), qd.getQueryReturns(), qd.getScalarQueryReturns(), qd.getQuerySpaces());
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 409 */         this.queryPlanCache.getNativeSQLQueryPlan(spec);
/*     */       }
/*     */       catch (QueryException e) {
/* 412 */         errors.put(queryName, e);
/*     */       }
/*     */       catch (MappingException e) {
/* 415 */         errors.put(queryName, e);
/*     */       }
/*     */     }
/*     */     
/* 419 */     return errors;
/*     */   }
/*     */   
/*     */   public StatelessSession openStatelessSession() {
/* 423 */     return new StatelessSessionImpl(null, this);
/*     */   }
/*     */   
/*     */   public StatelessSession openStatelessSession(Connection connection) {
/* 427 */     return new StatelessSessionImpl(connection, this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private SessionImpl openSession(Connection connection, boolean autoClose, long timestamp, Interceptor sessionLocalInterceptor)
/*     */   {
/* 436 */     return new SessionImpl(connection, this, autoClose, timestamp, sessionLocalInterceptor == null ? this.interceptor : sessionLocalInterceptor, this.settings.getDefaultEntityMode(), this.settings.isFlushBeforeCompletionEnabled(), this.settings.isAutoCloseSessionEnabled(), this.settings.getConnectionReleaseMode());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Session openSession(Connection connection, Interceptor sessionLocalInterceptor)
/*     */   {
/* 450 */     return openSession(connection, false, Long.MIN_VALUE, sessionLocalInterceptor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Session openSession(Interceptor sessionLocalInterceptor)
/*     */     throws HibernateException
/*     */   {
/* 459 */     long timestamp = this.settings.getCacheProvider().nextTimestamp();
/* 460 */     return openSession(null, true, timestamp, sessionLocalInterceptor);
/*     */   }
/*     */   
/*     */   public Session openSession(Connection connection) {
/* 464 */     return openSession(connection, this.interceptor);
/*     */   }
/*     */   
/*     */   public Session openSession() throws HibernateException {
/* 468 */     return openSession(this.interceptor);
/*     */   }
/*     */   
/*     */   public Session openTemporarySession() throws HibernateException {
/* 472 */     return new SessionImpl(null, this, true, this.settings.getCacheProvider().nextTimestamp(), this.interceptor, this.settings.getDefaultEntityMode(), false, false, ConnectionReleaseMode.AFTER_STATEMENT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Session openSession(Connection connection, boolean flushBeforeCompletionEnabled, boolean autoCloseSessionEnabled, ConnectionReleaseMode connectionReleaseMode)
/*     */     throws HibernateException
/*     */   {
/* 490 */     return new SessionImpl(connection, this, true, this.settings.getCacheProvider().nextTimestamp(), this.interceptor, this.settings.getDefaultEntityMode(), flushBeforeCompletionEnabled, autoCloseSessionEnabled, connectionReleaseMode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Session getCurrentSession()
/*     */     throws HibernateException
/*     */   {
/* 504 */     if (this.currentSessionContext == null) {
/* 505 */       throw new HibernateException("No CurrentSessionContext configured!");
/*     */     }
/* 507 */     return this.currentSessionContext.currentSession();
/*     */   }
/*     */   
/*     */   public EntityPersister getEntityPersister(String entityName) throws MappingException {
/* 511 */     EntityPersister result = (EntityPersister)this.entityPersisters.get(entityName);
/* 512 */     if (result == null) {
/* 513 */       throw new MappingException("Unknown entity: " + entityName);
/*     */     }
/* 515 */     return result;
/*     */   }
/*     */   
/*     */   public CollectionPersister getCollectionPersister(String role) throws MappingException {
/* 519 */     CollectionPersister result = (CollectionPersister)this.collectionPersisters.get(role);
/* 520 */     if (result == null) {
/* 521 */       throw new MappingException("Unknown collection role: " + role);
/*     */     }
/* 523 */     return result;
/*     */   }
/*     */   
/*     */   public Settings getSettings() {
/* 527 */     return this.settings;
/*     */   }
/*     */   
/*     */   public Dialect getDialect() {
/* 531 */     return this.settings.getDialect();
/*     */   }
/*     */   
/*     */   public Interceptor getInterceptor()
/*     */   {
/* 536 */     return this.interceptor;
/*     */   }
/*     */   
/*     */   public TransactionFactory getTransactionFactory() {
/* 540 */     return this.settings.getTransactionFactory();
/*     */   }
/*     */   
/*     */   public TransactionManager getTransactionManager() {
/* 544 */     return this.transactionManager;
/*     */   }
/*     */   
/*     */   public SQLExceptionConverter getSQLExceptionConverter() {
/* 548 */     return this.settings.getSQLExceptionConverter();
/*     */   }
/*     */   
/*     */   public Set getCollectionRolesByEntityParticipant(String entityName) {
/* 552 */     return (Set)this.collectionRolesByEntityParticipant.get(entityName);
/*     */   }
/*     */   
/*     */   public Reference getReference() throws NamingException
/*     */   {
/* 557 */     log.debug("Returning a Reference to the SessionFactory");
/* 558 */     return new Reference(SessionFactoryImpl.class.getName(), new StringRefAddr("uuid", this.uuid), SessionFactoryObjectFactory.class.getName(), null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object readResolve()
/*     */     throws ObjectStreamException
/*     */   {
/* 567 */     log.trace("Resolving serialized SessionFactory");
/*     */     
/* 569 */     Object result = SessionFactoryObjectFactory.getInstance(this.uuid);
/* 570 */     if (result == null)
/*     */     {
/*     */ 
/* 573 */       result = SessionFactoryObjectFactory.getNamedInstance(this.name);
/* 574 */       if (result == null) {
/* 575 */         throw new InvalidObjectException("Could not find a SessionFactory named: " + this.name);
/*     */       }
/*     */       
/* 578 */       log.debug("resolved SessionFactory by name");
/*     */     }
/*     */     else
/*     */     {
/* 582 */       log.debug("resolved SessionFactory by uid");
/*     */     }
/* 584 */     return result;
/*     */   }
/*     */   
/*     */   public NamedQueryDefinition getNamedQuery(String queryName) {
/* 588 */     return (NamedQueryDefinition)this.namedQueries.get(queryName);
/*     */   }
/*     */   
/*     */   public NamedSQLQueryDefinition getNamedSQLQuery(String queryName) {
/* 592 */     return (NamedSQLQueryDefinition)this.namedSqlQueries.get(queryName);
/*     */   }
/*     */   
/*     */   public ResultSetMappingDefinition getResultSetMapping(String resultSetName) {
/* 596 */     return (ResultSetMappingDefinition)this.sqlResultSetMappings.get(resultSetName);
/*     */   }
/*     */   
/*     */   public Type getIdentifierType(String className) throws MappingException {
/* 600 */     return getEntityPersister(className).getIdentifierType();
/*     */   }
/*     */   
/* 603 */   public String getIdentifierPropertyName(String className) throws MappingException { return getEntityPersister(className).getIdentifierPropertyName(); }
/*     */   
/*     */   private final void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/*     */   {
/* 607 */     log.trace("deserializing");
/* 608 */     in.defaultReadObject();
/* 609 */     log.debug("deserialized: " + this.uuid);
/*     */   }
/*     */   
/* 612 */   private final void writeObject(ObjectOutputStream out) throws IOException { log.debug("serializing: " + this.uuid);
/* 613 */     out.defaultWriteObject();
/* 614 */     log.trace("serialized");
/*     */   }
/*     */   
/*     */   public Type[] getReturnTypes(String queryString) throws HibernateException {
/* 618 */     return this.queryPlanCache.getHQLQueryPlan(queryString, true, CollectionHelper.EMPTY_MAP).getReturnMetadata().getReturnTypes();
/*     */   }
/*     */   
/*     */   public String[] getReturnAliases(String queryString) throws HibernateException {
/* 622 */     return this.queryPlanCache.getHQLQueryPlan(queryString, true, CollectionHelper.EMPTY_MAP).getReturnMetadata().getReturnAliases();
/*     */   }
/*     */   
/*     */   public ClassMetadata getClassMetadata(Class persistentClass) throws HibernateException {
/* 626 */     return getClassMetadata(persistentClass.getName());
/*     */   }
/*     */   
/*     */   public CollectionMetadata getCollectionMetadata(String roleName) throws HibernateException {
/* 630 */     return (CollectionMetadata)this.collectionMetadata.get(roleName);
/*     */   }
/*     */   
/*     */   public ClassMetadata getClassMetadata(String entityName) throws HibernateException {
/* 634 */     return (ClassMetadata)this.classMetadata.get(entityName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getImplementors(String className)
/*     */     throws MappingException
/*     */   {
/*     */     try
/*     */     {
/* 646 */       clazz = ReflectHelper.classForName(className);
/*     */     } catch (ClassNotFoundException cnfe) {
/*     */       Class clazz;
/* 649 */       return new String[] { className };
/*     */     }
/*     */     Class clazz;
/* 652 */     ArrayList results = new ArrayList();
/* 653 */     Iterator iter = this.entityPersisters.values().iterator();
/* 654 */     while (iter.hasNext())
/*     */     {
/* 656 */       EntityPersister testPersister = (EntityPersister)iter.next();
/* 657 */       if ((testPersister instanceof Queryable)) {
/* 658 */         Queryable testQueryable = (Queryable)testPersister;
/* 659 */         String testClassName = testQueryable.getEntityName();
/* 660 */         boolean isMappedClass = className.equals(testClassName);
/* 661 */         if (testQueryable.isExplicitPolymorphism()) {
/* 662 */           if (isMappedClass) { return new String[] { className };
/*     */           }
/*     */         }
/* 665 */         else if (isMappedClass) {
/* 666 */           results.add(testClassName);
/*     */         }
/*     */         else {
/* 669 */           Class mappedClass = testQueryable.getMappedClass(EntityMode.POJO);
/* 670 */           if ((mappedClass != null) && (clazz.isAssignableFrom(mappedClass))) { boolean assignableSuperclass;
/*     */             boolean assignableSuperclass;
/* 672 */             if (testQueryable.isInherited()) {
/* 673 */               Class mappedSuperclass = getEntityPersister(testQueryable.getMappedSuperclass()).getMappedClass(EntityMode.POJO);
/* 674 */               assignableSuperclass = clazz.isAssignableFrom(mappedSuperclass);
/*     */             }
/*     */             else {
/* 677 */               assignableSuperclass = false;
/*     */             }
/* 679 */             if (!assignableSuperclass) { results.add(testClassName);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 685 */     return (String[])results.toArray(new String[results.size()]);
/*     */   }
/*     */   
/*     */   public String getImportedClassName(String className) {
/* 689 */     String result = (String)this.imports.get(className);
/* 690 */     if (result == null) {
/*     */       try {
/* 692 */         ReflectHelper.classForName(className);
/* 693 */         return className;
/*     */       }
/*     */       catch (ClassNotFoundException cnfe) {
/* 696 */         return null;
/*     */       }
/*     */     }
/*     */     
/* 700 */     return result;
/*     */   }
/*     */   
/*     */   public Map getAllClassMetadata() throws HibernateException
/*     */   {
/* 705 */     return this.classMetadata;
/*     */   }
/*     */   
/*     */   public Map getAllCollectionMetadata() throws HibernateException {
/* 709 */     return this.collectionMetadata;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws HibernateException
/*     */   {
/* 728 */     log.info("closing");
/*     */     
/* 730 */     this.isClosed = true;
/*     */     
/* 732 */     Iterator iter = this.entityPersisters.values().iterator();
/* 733 */     while (iter.hasNext()) {
/* 734 */       EntityPersister p = (EntityPersister)iter.next();
/* 735 */       if (p.hasCache()) { p.getCache().destroy();
/*     */       }
/*     */     }
/* 738 */     iter = this.collectionPersisters.values().iterator();
/* 739 */     while (iter.hasNext()) {
/* 740 */       CollectionPersister p = (CollectionPersister)iter.next();
/* 741 */       if (p.hasCache()) { p.getCache().destroy();
/*     */       }
/*     */     }
/* 744 */     if (this.settings.isQueryCacheEnabled()) {
/* 745 */       this.queryCache.destroy();
/*     */       
/* 747 */       iter = this.queryCaches.values().iterator();
/* 748 */       while (iter.hasNext()) {
/* 749 */         QueryCache cache = (QueryCache)iter.next();
/* 750 */         cache.destroy();
/*     */       }
/* 752 */       this.updateTimestampsCache.destroy();
/*     */     }
/*     */     
/* 755 */     this.settings.getCacheProvider().stop();
/*     */     try
/*     */     {
/* 758 */       this.settings.getConnectionProvider().close();
/*     */     }
/*     */     finally {
/* 761 */       SessionFactoryObjectFactory.removeInstance(this.uuid, this.name, this.properties);
/*     */     }
/*     */     
/* 764 */     if (this.settings.isAutoDropSchema()) this.schemaExport.drop(false, true);
/*     */   }
/*     */   
/*     */   public void evictEntity(String entityName, Serializable id) throws HibernateException
/*     */   {
/* 769 */     EntityPersister p = getEntityPersister(entityName);
/* 770 */     if (p.hasCache()) {
/* 771 */       if (log.isDebugEnabled()) {
/* 772 */         log.debug("evicting second-level cache: " + MessageHelper.infoString(p, id, this));
/*     */       }
/* 774 */       CacheKey cacheKey = new CacheKey(id, p.getIdentifierType(), p.getRootEntityName(), EntityMode.POJO, this);
/* 775 */       p.getCache().remove(cacheKey);
/*     */     }
/*     */   }
/*     */   
/*     */   public void evictEntity(String entityName) throws HibernateException {
/* 780 */     EntityPersister p = getEntityPersister(entityName);
/* 781 */     if (p.hasCache()) {
/* 782 */       if (log.isDebugEnabled()) {
/* 783 */         log.debug("evicting second-level cache: " + p.getEntityName());
/*     */       }
/* 785 */       p.getCache().clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public void evict(Class persistentClass, Serializable id) throws HibernateException {
/* 790 */     EntityPersister p = getEntityPersister(persistentClass.getName());
/* 791 */     if (p.hasCache()) {
/* 792 */       if (log.isDebugEnabled()) {
/* 793 */         log.debug("evicting second-level cache: " + MessageHelper.infoString(p, id, this));
/*     */       }
/* 795 */       CacheKey cacheKey = new CacheKey(id, p.getIdentifierType(), p.getRootEntityName(), EntityMode.POJO, this);
/* 796 */       p.getCache().remove(cacheKey);
/*     */     }
/*     */   }
/*     */   
/*     */   public void evict(Class persistentClass) throws HibernateException {
/* 801 */     EntityPersister p = getEntityPersister(persistentClass.getName());
/* 802 */     if (p.hasCache()) {
/* 803 */       if (log.isDebugEnabled()) {
/* 804 */         log.debug("evicting second-level cache: " + p.getEntityName());
/*     */       }
/* 806 */       p.getCache().clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public void evictCollection(String roleName, Serializable id) throws HibernateException {
/* 811 */     CollectionPersister p = getCollectionPersister(roleName);
/* 812 */     if (p.hasCache()) {
/* 813 */       if (log.isDebugEnabled()) {
/* 814 */         log.debug("evicting second-level cache: " + MessageHelper.collectionInfoString(p, id, this));
/*     */       }
/* 816 */       CacheKey cacheKey = new CacheKey(id, p.getKeyType(), p.getRole(), EntityMode.POJO, this);
/* 817 */       p.getCache().remove(cacheKey);
/*     */     }
/*     */   }
/*     */   
/*     */   public void evictCollection(String roleName) throws HibernateException {
/* 822 */     CollectionPersister p = getCollectionPersister(roleName);
/* 823 */     if (p.hasCache()) {
/* 824 */       if (log.isDebugEnabled()) log.debug("evicting second-level cache: " + p.getRole());
/* 825 */       p.getCache().clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public Type getReferencedPropertyType(String className, String propertyName) throws MappingException
/*     */   {
/* 831 */     return getEntityPersister(className).getPropertyType(propertyName);
/*     */   }
/*     */   
/*     */   public ConnectionProvider getConnectionProvider() {
/* 835 */     return this.settings.getConnectionProvider();
/*     */   }
/*     */   
/*     */   public UpdateTimestampsCache getUpdateTimestampsCache() {
/* 839 */     return this.updateTimestampsCache;
/*     */   }
/*     */   
/*     */   public QueryCache getQueryCache() {
/* 843 */     return this.queryCache;
/*     */   }
/*     */   
/*     */   public QueryCache getQueryCache(String cacheRegion) throws HibernateException {
/* 847 */     if (cacheRegion == null) {
/* 848 */       return getQueryCache();
/*     */     }
/*     */     
/* 851 */     if (!this.settings.isQueryCacheEnabled()) {
/* 852 */       return null;
/*     */     }
/*     */     
/* 855 */     synchronized (this.allCacheRegions) {
/* 856 */       QueryCache currentQueryCache = (QueryCache)this.queryCaches.get(cacheRegion);
/* 857 */       if (currentQueryCache == null) {
/* 858 */         currentQueryCache = this.settings.getQueryCacheFactory().getQueryCache(cacheRegion, this.updateTimestampsCache, this.settings, this.properties);
/*     */         
/* 860 */         this.queryCaches.put(cacheRegion, currentQueryCache);
/* 861 */         this.allCacheRegions.put(currentQueryCache.getRegionName(), currentQueryCache.getCache());
/*     */       }
/* 863 */       return currentQueryCache;
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public org.hibernate.cache.Cache getSecondLevelCacheRegion(String regionName)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 9	org/hibernate/impl/SessionFactoryImpl:allCacheRegions	Ljava/util/Map;
/*     */     //   4: dup
/*     */     //   5: astore_2
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 9	org/hibernate/impl/SessionFactoryImpl:allCacheRegions	Ljava/util/Map;
/*     */     //   11: aload_1
/*     */     //   12: invokeinterface 61 2 0
/*     */     //   17: checkcast 302	org/hibernate/cache/Cache
/*     */     //   20: aload_2
/*     */     //   21: monitorexit
/*     */     //   22: areturn
/*     */     //   23: astore_3
/*     */     //   24: aload_2
/*     */     //   25: monitorexit
/*     */     //   26: aload_3
/*     */     //   27: athrow
/*     */     // Line number table:
/*     */     //   Java source line #868	-> byte code offset #0
/*     */     //   Java source line #869	-> byte code offset #7
/*     */     //   Java source line #870	-> byte code offset #23
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	28	0	this	SessionFactoryImpl
/*     */     //   0	28	1	regionName	String
/*     */     //   5	20	2	Ljava/lang/Object;	Object
/*     */     //   23	4	3	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	22	23	finally
/*     */     //   23	26	23	finally
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Map getAllSecondLevelCacheRegions()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 9	org/hibernate/impl/SessionFactoryImpl:allCacheRegions	Ljava/util/Map;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: new 7	java/util/HashMap
/*     */     //   10: dup
/*     */     //   11: aload_0
/*     */     //   12: getfield 9	org/hibernate/impl/SessionFactoryImpl:allCacheRegions	Ljava/util/Map;
/*     */     //   15: invokespecial 100	java/util/HashMap:<init>	(Ljava/util/Map;)V
/*     */     //   18: aload_1
/*     */     //   19: monitorexit
/*     */     //   20: areturn
/*     */     //   21: astore_2
/*     */     //   22: aload_1
/*     */     //   23: monitorexit
/*     */     //   24: aload_2
/*     */     //   25: athrow
/*     */     // Line number table:
/*     */     //   Java source line #874	-> byte code offset #0
/*     */     //   Java source line #875	-> byte code offset #7
/*     */     //   Java source line #876	-> byte code offset #21
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	26	0	this	SessionFactoryImpl
/*     */     //   5	18	1	Ljava/lang/Object;	Object
/*     */     //   21	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	20	21	finally
/*     */     //   21	24	21	finally
/*     */   }
/*     */   
/*     */   public boolean isClosed()
/*     */   {
/* 880 */     return this.isClosed;
/*     */   }
/*     */   
/*     */   public Statistics getStatistics() {
/* 884 */     return this.statistics;
/*     */   }
/*     */   
/*     */   public StatisticsImplementor getStatisticsImplementor() {
/* 888 */     return this.statistics;
/*     */   }
/*     */   
/*     */   public void evictQueries() throws HibernateException {
/* 892 */     if (this.settings.isQueryCacheEnabled()) {
/* 893 */       this.queryCache.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public void evictQueries(String cacheRegion) throws HibernateException {
/* 898 */     if (cacheRegion == null) {
/* 899 */       throw new NullPointerException("use the zero-argument form to evict the default query cache");
/*     */     }
/*     */     
/* 902 */     synchronized (this.allCacheRegions) {
/* 903 */       if (this.settings.isQueryCacheEnabled()) {
/* 904 */         QueryCache currentQueryCache = (QueryCache)this.queryCaches.get(cacheRegion);
/* 905 */         if (currentQueryCache != null) currentQueryCache.clear();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public FilterDefinition getFilterDefinition(String filterName) throws HibernateException
/*     */   {
/* 912 */     FilterDefinition def = (FilterDefinition)this.filters.get(filterName);
/* 913 */     if (def == null) {
/* 914 */       throw new HibernateException("No such filter configured [" + filterName + "]");
/*     */     }
/* 916 */     return def;
/*     */   }
/*     */   
/*     */   public Set getDefinedFilterNames() {
/* 920 */     return this.filters.keySet();
/*     */   }
/*     */   
/*     */   public BatcherFactory getBatcherFactory() {
/* 924 */     return this.settings.getBatcherFactory();
/*     */   }
/*     */   
/*     */   public IdentifierGenerator getIdentifierGenerator(String rootEntityName) {
/* 928 */     return (IdentifierGenerator)this.identifierGenerators.get(rootEntityName);
/*     */   }
/*     */   
/*     */   private CurrentSessionContext buildCurrentSessionContext() {
/* 932 */     String impl = this.properties.getProperty("hibernate.current_session_context_class");
/*     */     
/* 934 */     if ((impl == null) && (this.transactionManager != null)) {
/* 935 */       impl = "jta";
/*     */     }
/*     */     
/* 938 */     if (impl == null) {
/* 939 */       return null;
/*     */     }
/* 941 */     if ("jta".equals(impl)) {
/* 942 */       return new JTASessionContext(this);
/*     */     }
/* 944 */     if ("thread".equals(impl)) {
/* 945 */       return new ThreadLocalSessionContext(this);
/*     */     }
/*     */     try
/*     */     {
/* 949 */       Class implClass = ReflectHelper.classForName(impl);
/* 950 */       return (CurrentSessionContext)implClass.getConstructor(new Class[] { SessionFactoryImplementor.class }).newInstance(new Object[] { this });
/*     */ 
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 955 */       log.error("Unable to construct current session context [" + impl + "]", t); }
/* 956 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public EventListeners getEventListeners()
/*     */   {
/* 963 */     return this.eventListeners;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\impl\SessionFactoryImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */