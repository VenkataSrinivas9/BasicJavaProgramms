/*     */ package org.hibernate.jdbc;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Interceptor;
/*     */ import org.hibernate.ScrollMode;
/*     */ import org.hibernate.TransactionException;
/*     */ import org.hibernate.cfg.Settings;
/*     */ import org.hibernate.connection.ConnectionProvider;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.exception.JDBCExceptionHelper;
/*     */ import org.hibernate.pretty.Formatter;
/*     */ import org.hibernate.stat.Statistics;
/*     */ import org.hibernate.stat.StatisticsImplementor;
/*     */ import org.hibernate.util.GetGeneratedKeysHelper;
/*     */ import org.hibernate.util.JDBCExceptionReporter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractBatcher
/*     */   implements Batcher
/*     */ {
/*     */   private static int globalOpenPreparedStatementCount;
/*     */   private static int globalOpenResultSetCount;
/*     */   private int openPreparedStatementCount;
/*     */   private int openResultSetCount;
/*  39 */   protected static final Log log = LogFactory.getLog(AbstractBatcher.class);
/*  40 */   protected static final Log SQL_LOG = LogFactory.getLog("org.hibernate.SQL");
/*     */   
/*     */   private final ConnectionManager connectionManager;
/*     */   
/*     */   private final SessionFactoryImplementor factory;
/*     */   
/*     */   private PreparedStatement batchUpdate;
/*     */   private String batchUpdateSQL;
/*  48 */   private HashSet statementsToClose = new HashSet();
/*  49 */   private HashSet resultSetsToClose = new HashSet();
/*     */   
/*     */   private PreparedStatement lastQuery;
/*  52 */   private boolean releasing = false;
/*     */   
/*     */   private final Interceptor interceptor;
/*  55 */   private long transactionTimeout = -1L;
/*     */   boolean isTransactionTimeoutSet;
/*     */   
/*     */   public AbstractBatcher(ConnectionManager connectionManager, Interceptor interceptor) {
/*  59 */     this.connectionManager = connectionManager;
/*  60 */     this.interceptor = interceptor;
/*  61 */     this.factory = connectionManager.getFactory();
/*     */   }
/*     */   
/*     */   public void setTransactionTimeout(int seconds) {
/*  65 */     this.isTransactionTimeoutSet = true;
/*  66 */     this.transactionTimeout = (System.currentTimeMillis() / 1000L + seconds);
/*     */   }
/*     */   
/*     */   public void unsetTransactionTimeout() {
/*  70 */     this.isTransactionTimeoutSet = false;
/*     */   }
/*     */   
/*     */   protected PreparedStatement getStatement() {
/*  74 */     return this.batchUpdate;
/*     */   }
/*     */   
/*     */   public CallableStatement prepareCallableStatement(String sql) throws SQLException, HibernateException
/*     */   {
/*  79 */     executeBatch();
/*  80 */     logOpenPreparedStatement();
/*  81 */     return getCallableStatement(this.connectionManager.getConnection(), sql, false);
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql) throws SQLException, HibernateException
/*     */   {
/*  86 */     return prepareStatement(sql, false, null);
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareStatement(String sql, boolean getGeneratedKeys, String[] pkColumnNames) throws SQLException, HibernateException
/*     */   {
/*  91 */     executeBatch();
/*  92 */     logOpenPreparedStatement();
/*  93 */     return getPreparedStatement(this.connectionManager.getConnection(), sql, false, getGeneratedKeys, pkColumnNames, null, false);
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareSelectStatement(String sql) throws SQLException, HibernateException
/*     */   {
/*  98 */     logOpenPreparedStatement();
/*  99 */     return getPreparedStatement(this.connectionManager.getConnection(), sql, false, false, null, null, false);
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareQueryStatement(String sql, boolean scrollable, ScrollMode scrollMode) throws SQLException, HibernateException
/*     */   {
/* 104 */     logOpenPreparedStatement();
/* 105 */     PreparedStatement ps = getPreparedStatement(this.connectionManager.getConnection(), sql, scrollable, scrollMode);
/* 106 */     setStatementFetchSize(ps);
/* 107 */     this.statementsToClose.add(ps);
/* 108 */     this.lastQuery = ps;
/* 109 */     return ps;
/*     */   }
/*     */   
/*     */   public CallableStatement prepareCallableQueryStatement(String sql, boolean scrollable, ScrollMode scrollMode) throws SQLException, HibernateException
/*     */   {
/* 114 */     logOpenPreparedStatement();
/* 115 */     CallableStatement ps = (CallableStatement)getPreparedStatement(this.connectionManager.getConnection(), sql, scrollable, false, null, scrollMode, true);
/*     */     
/*     */ 
/* 118 */     setStatementFetchSize(ps);
/* 119 */     this.statementsToClose.add(ps);
/* 120 */     this.lastQuery = ps;
/* 121 */     return ps;
/*     */   }
/*     */   
/*     */   public void abortBatch(SQLException sqle) {
/*     */     try {
/* 126 */       if (this.batchUpdate != null) closeStatement(this.batchUpdate);
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/* 130 */       JDBCExceptionReporter.logExceptions(e);
/*     */     }
/*     */     finally {
/* 133 */       this.batchUpdate = null;
/* 134 */       this.batchUpdateSQL = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public ResultSet getResultSet(PreparedStatement ps) throws SQLException {
/* 139 */     ResultSet rs = ps.executeQuery();
/* 140 */     this.resultSetsToClose.add(rs);
/* 141 */     logOpenResults();
/* 142 */     return rs;
/*     */   }
/*     */   
/*     */   public ResultSet getResultSet(CallableStatement ps, Dialect dialect) throws SQLException {
/* 146 */     ResultSet rs = dialect.getResultSet(ps);
/* 147 */     this.resultSetsToClose.add(rs);
/* 148 */     logOpenResults();
/* 149 */     return rs;
/*     */   }
/*     */   
/*     */   public void closeQueryStatement(PreparedStatement ps, ResultSet rs) throws SQLException {
/* 153 */     this.statementsToClose.remove(ps);
/* 154 */     if (rs != null) this.resultSetsToClose.remove(rs);
/*     */     try {
/* 156 */       if (rs != null) {
/* 157 */         logCloseResults();
/* 158 */         rs.close();
/*     */       }
/*     */     }
/*     */     finally {
/* 162 */       closeQueryStatement(ps);
/*     */     }
/*     */   }
/*     */   
/*     */   public PreparedStatement prepareBatchStatement(String sql) throws SQLException, HibernateException
/*     */   {
/* 168 */     sql = getSQL(sql);
/*     */     
/* 170 */     if (!sql.equals(this.batchUpdateSQL)) {
/* 171 */       this.batchUpdate = prepareStatement(sql);
/* 172 */       this.batchUpdateSQL = sql;
/*     */     }
/*     */     else {
/* 175 */       log.debug("reusing prepared statement");
/* 176 */       log(sql);
/*     */     }
/* 178 */     return this.batchUpdate;
/*     */   }
/*     */   
/*     */   public CallableStatement prepareBatchCallableStatement(String sql) throws SQLException, HibernateException
/*     */   {
/* 183 */     if (!sql.equals(this.batchUpdateSQL)) {
/* 184 */       this.batchUpdate = prepareCallableStatement(sql);
/* 185 */       this.batchUpdateSQL = sql;
/*     */     }
/* 187 */     return (CallableStatement)this.batchUpdate;
/*     */   }
/*     */   
/*     */   public void executeBatch() throws HibernateException
/*     */   {
/* 192 */     if (this.batchUpdate != null) {
/*     */       try {
/*     */         try {
/* 195 */           doExecuteBatch(this.batchUpdate);
/*     */         }
/*     */         finally {
/* 198 */           closeStatement(this.batchUpdate);
/*     */         }
/*     */       }
/*     */       catch (SQLException sqle) {
/* 202 */         throw JDBCExceptionHelper.convert(this.factory.getSQLExceptionConverter(), sqle, "Could not execute JDBC batch update", this.batchUpdateSQL);
/*     */ 
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/*     */ 
/* 210 */         this.batchUpdate = null;
/* 211 */         this.batchUpdateSQL = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void closeStatement(PreparedStatement ps) throws SQLException {
/* 217 */     logClosePreparedStatement();
/* 218 */     closePreparedStatement(ps);
/*     */   }
/*     */   
/*     */   private void closeQueryStatement(PreparedStatement ps) throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 225 */       if (ps.getMaxRows() != 0) ps.setMaxRows(0);
/* 226 */       if (ps.getQueryTimeout() != 0) ps.setQueryTimeout(0);
/*     */     }
/*     */     catch (Exception e) {
/* 229 */       log.warn("exception clearing maxRows/queryTimeout", e); return;
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 234 */       closeStatement(ps);
/*     */     }
/*     */     
/* 237 */     if (this.lastQuery == ps) { this.lastQuery = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void closeStatements()
/*     */   {
/*     */     try
/*     */     {
/* 247 */       this.releasing = true;
/*     */       try
/*     */       {
/* 250 */         if (this.batchUpdate != null) this.batchUpdate.close();
/*     */       }
/*     */       catch (SQLException sqle)
/*     */       {
/* 254 */         log.warn("Could not close a JDBC prepared statement", sqle);
/*     */       }
/* 256 */       this.batchUpdate = null;
/* 257 */       this.batchUpdateSQL = null;
/*     */       
/* 259 */       Iterator iter = this.resultSetsToClose.iterator();
/* 260 */       while (iter.hasNext()) {
/*     */         try {
/* 262 */           logCloseResults();
/* 263 */           ((ResultSet)iter.next()).close();
/*     */         }
/*     */         catch (SQLException e)
/*     */         {
/* 267 */           log.warn("Could not close a JDBC result set", e);
/*     */         }
/*     */       }
/* 270 */       this.resultSetsToClose.clear();
/*     */       
/* 272 */       iter = this.statementsToClose.iterator();
/* 273 */       while (iter.hasNext()) {
/*     */         try {
/* 275 */           closeQueryStatement((PreparedStatement)iter.next());
/*     */         }
/*     */         catch (SQLException e)
/*     */         {
/* 279 */           log.warn("Could not close a JDBC statement", e);
/*     */         }
/*     */       }
/* 282 */       this.statementsToClose.clear();
/*     */     }
/*     */     finally {
/* 285 */       this.releasing = false;
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract void doExecuteBatch(PreparedStatement paramPreparedStatement) throws SQLException, HibernateException;
/*     */   
/*     */   private String preparedStatementCountsToString() {
/* 292 */     return " (open PreparedStatements: " + this.openPreparedStatementCount + ", globally: " + globalOpenPreparedStatementCount + ")";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String resultSetCountsToString()
/*     */   {
/* 301 */     return " (open ResultSets: " + this.openResultSetCount + ", globally: " + globalOpenResultSetCount + ")";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void logOpenPreparedStatement()
/*     */   {
/* 310 */     if (log.isDebugEnabled()) {
/* 311 */       log.debug("about to open PreparedStatement" + preparedStatementCountsToString());
/* 312 */       this.openPreparedStatementCount += 1;
/* 313 */       globalOpenPreparedStatementCount += 1;
/*     */     }
/*     */   }
/*     */   
/*     */   private void logClosePreparedStatement() {
/* 318 */     if (log.isDebugEnabled()) {
/* 319 */       log.debug("about to close PreparedStatement" + preparedStatementCountsToString());
/* 320 */       this.openPreparedStatementCount -= 1;
/* 321 */       globalOpenPreparedStatementCount -= 1;
/*     */     }
/*     */   }
/*     */   
/*     */   private void logOpenResults() {
/* 326 */     if (log.isDebugEnabled()) {
/* 327 */       log.debug("about to open ResultSet" + resultSetCountsToString());
/* 328 */       this.openResultSetCount += 1;
/* 329 */       globalOpenResultSetCount += 1;
/*     */     }
/*     */   }
/*     */   
/* 333 */   private void logCloseResults() { if (log.isDebugEnabled()) {
/* 334 */       log.debug("about to close ResultSet" + resultSetCountsToString());
/* 335 */       this.openResultSetCount -= 1;
/* 336 */       globalOpenResultSetCount -= 1;
/*     */     }
/*     */   }
/*     */   
/*     */   protected SessionFactoryImplementor getFactory() {
/* 341 */     return this.factory;
/*     */   }
/*     */   
/*     */   private void log(String sql) {
/* 345 */     if (SQL_LOG.isDebugEnabled()) {
/* 346 */       SQL_LOG.debug(format(sql));
/*     */     }
/* 348 */     if (this.factory.getSettings().isShowSqlEnabled()) {
/* 349 */       System.out.println("Hibernate: " + format(sql));
/*     */     }
/*     */   }
/*     */   
/*     */   private String format(String sql) {
/* 354 */     if (this.factory.getSettings().isFormatSqlEnabled()) {
/* 355 */       return new Formatter(sql).format();
/*     */     }
/*     */     
/* 358 */     return sql;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private PreparedStatement getPreparedStatement(Connection conn, String sql, boolean scrollable, ScrollMode scrollMode)
/*     */     throws SQLException
/*     */   {
/* 368 */     return getPreparedStatement(conn, sql, scrollable, false, null, scrollMode, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private CallableStatement getCallableStatement(Connection conn, String sql, boolean scrollable)
/*     */     throws SQLException
/*     */   {
/* 376 */     if ((scrollable) && (!this.factory.getSettings().isScrollableResultSetsEnabled())) {
/* 377 */       throw new AssertionFailure("scrollable result sets are not enabled");
/*     */     }
/*     */     
/* 380 */     sql = getSQL(sql);
/*     */     
/* 382 */     log(sql);
/*     */     
/* 384 */     log.trace("preparing callable statement");
/* 385 */     if (scrollable) {
/* 386 */       return conn.prepareCall(sql, 1004, 1007);
/*     */     }
/*     */     
/* 389 */     return conn.prepareCall(sql);
/*     */   }
/*     */   
/*     */ 
/*     */   private String getSQL(String sql)
/*     */   {
/* 395 */     sql = this.interceptor.onPrepareStatement(sql);
/* 396 */     if ((sql == null) || (sql.length() == 0)) {
/* 397 */       throw new AssertionFailure("Interceptor.onPrepareStatement() returned null or empty string.");
/*     */     }
/* 399 */     return sql;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private PreparedStatement getPreparedStatement(Connection conn, String sql, boolean scrollable, boolean useGetGeneratedKeys, String[] pkColumnNames, ScrollMode scrollMode, boolean callable)
/*     */     throws SQLException
/*     */   {
/* 412 */     if ((scrollable) && (!this.factory.getSettings().isScrollableResultSetsEnabled())) {
/* 413 */       throw new AssertionFailure("scrollable result sets are not enabled");
/*     */     }
/*     */     
/* 416 */     if ((useGetGeneratedKeys) && (!this.factory.getSettings().isGetGeneratedKeysEnabled())) {
/* 417 */       throw new AssertionFailure("getGeneratedKeys() support is not enabled");
/*     */     }
/*     */     
/* 420 */     sql = getSQL(sql);
/*     */     
/* 422 */     log(sql);
/*     */     
/* 424 */     log.trace("preparing statement");
/*     */     PreparedStatement result;
/* 426 */     PreparedStatement result; if (scrollable) { PreparedStatement result;
/* 427 */       if (callable) {
/* 428 */         result = conn.prepareCall(sql, scrollMode.toResultSetType(), 1007);
/*     */       }
/*     */       else
/* 431 */         result = conn.prepareStatement(sql, scrollMode.toResultSetType(), 1007);
/*     */     } else {
/*     */       PreparedStatement result;
/* 434 */       if (useGetGeneratedKeys) {
/* 435 */         result = GetGeneratedKeysHelper.prepareStatement(conn, sql, pkColumnNames);
/*     */       } else {
/*     */         PreparedStatement result;
/* 438 */         if (callable) {
/* 439 */           result = conn.prepareCall(sql);
/*     */         }
/*     */         else {
/* 442 */           result = conn.prepareStatement(sql);
/*     */         }
/*     */       }
/*     */     }
/* 446 */     setTimeout(result);
/*     */     
/* 448 */     if (this.factory.getStatistics().isStatisticsEnabled()) {
/* 449 */       this.factory.getStatisticsImplementor().prepareStatement();
/*     */     }
/*     */     
/* 452 */     return result;
/*     */   }
/*     */   
/*     */   private void setTimeout(PreparedStatement result) throws SQLException
/*     */   {
/* 457 */     if (this.isTransactionTimeoutSet) {
/* 458 */       int timeout = (int)(this.transactionTimeout - System.currentTimeMillis() / 1000L);
/* 459 */       if (timeout <= 0) {
/* 460 */         throw new TransactionException("transaction timeout expired");
/*     */       }
/*     */       
/* 463 */       result.setQueryTimeout(timeout);
/*     */     }
/*     */   }
/*     */   
/*     */   private void closePreparedStatement(PreparedStatement ps) throws SQLException
/*     */   {
/*     */     try {
/* 470 */       log.trace("closing statement");
/* 471 */       ps.close();
/* 472 */       if (this.factory.getStatistics().isStatisticsEnabled()) {
/* 473 */         this.factory.getStatisticsImplementor().closeStatement();
/*     */       }
/*     */     }
/*     */     finally {
/* 477 */       if (!this.releasing)
/*     */       {
/*     */ 
/* 480 */         this.connectionManager.afterStatement();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void setStatementFetchSize(PreparedStatement statement) throws SQLException {
/* 486 */     Integer statementFetchSize = this.factory.getSettings().getJdbcFetchSize();
/* 487 */     if (statementFetchSize != null) {
/* 488 */       statement.setFetchSize(statementFetchSize.intValue());
/*     */     }
/*     */   }
/*     */   
/*     */   public Connection openConnection() throws HibernateException {
/* 493 */     log.debug("opening JDBC connection");
/*     */     try {
/* 495 */       return this.factory.getConnectionProvider().getConnection();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 498 */       throw JDBCExceptionHelper.convert(this.factory.getSQLExceptionConverter(), sqle, "Cannot open connection");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void closeConnection(Connection conn)
/*     */     throws HibernateException
/*     */   {
/* 507 */     if (log.isDebugEnabled()) {
/* 508 */       log.debug("closing JDBC connection" + preparedStatementCountsToString() + resultSetCountsToString());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 516 */       if (!conn.isClosed()) {
/* 517 */         JDBCExceptionReporter.logAndClearWarnings(conn);
/*     */       }
/* 519 */       this.factory.getConnectionProvider().closeConnection(conn);
/*     */     }
/*     */     catch (SQLException sqle) {
/* 522 */       throw JDBCExceptionHelper.convert(this.factory.getSQLExceptionConverter(), sqle, "Cannot close connection");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void cancelLastQuery()
/*     */     throws HibernateException
/*     */   {
/*     */     try
/*     */     {
/* 532 */       if (this.lastQuery != null) this.lastQuery.cancel();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 535 */       throw JDBCExceptionHelper.convert(this.factory.getSQLExceptionConverter(), sqle, "Cannot cancel query");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasOpenResources()
/*     */   {
/* 544 */     return (this.resultSetsToClose.size() > 0) || (this.statementsToClose.size() > 0);
/*     */   }
/*     */   
/*     */   public String openResourceStatsAsString() {
/* 548 */     return preparedStatementCountsToString() + resultSetCountsToString();
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\jdbc\AbstractBatcher.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */