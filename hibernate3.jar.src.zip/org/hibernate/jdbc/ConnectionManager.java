/*     */ package org.hibernate.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.ConnectionReleaseMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Interceptor;
/*     */ import org.hibernate.cfg.Settings;
/*     */ import org.hibernate.connection.ConnectionProvider;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.exception.JDBCExceptionHelper;
/*     */ import org.hibernate.util.JDBCExceptionReporter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionManager
/*     */   implements Serializable
/*     */ {
/*  30 */   private static final Log log = LogFactory.getLog(ConnectionManager.class);
/*     */   
/*     */ 
/*     */ 
/*     */   private transient SessionFactoryImplementor factory;
/*     */   
/*     */ 
/*     */ 
/*     */   private final Callback callback;
/*     */   
/*     */ 
/*     */ 
/*     */   private final ConnectionReleaseMode releaseMode;
/*     */   
/*     */ 
/*     */   private transient Connection connection;
/*     */   
/*     */ 
/*     */   private transient Connection borrowedConnection;
/*     */   
/*     */ 
/*     */   private final boolean wasConnectionSupplied;
/*     */   
/*     */ 
/*     */   private transient Batcher batcher;
/*     */   
/*     */ 
/*     */   private transient Interceptor interceptor;
/*     */   
/*     */ 
/*     */   private boolean isClosed;
/*     */   
/*     */ 
/*     */ 
/*     */   public ConnectionManager(SessionFactoryImplementor factory, Callback callback, ConnectionReleaseMode releaseMode, Connection connection, Interceptor interceptor)
/*     */   {
/*  66 */     this.factory = factory;
/*  67 */     this.callback = callback;
/*     */     
/*  69 */     this.interceptor = interceptor;
/*  70 */     this.batcher = factory.getSettings().getBatcherFactory().createBatcher(this, interceptor);
/*     */     
/*  72 */     this.connection = connection;
/*  73 */     this.wasConnectionSupplied = (connection != null);
/*     */     
/*  75 */     this.releaseMode = (this.wasConnectionSupplied ? ConnectionReleaseMode.ON_CLOSE : releaseMode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SessionFactoryImplementor getFactory()
/*     */   {
/*  84 */     return this.factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Batcher getBatcher()
/*     */   {
/*  93 */     return this.batcher;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSuppliedConnection()
/*     */   {
/* 102 */     return this.wasConnectionSupplied;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws HibernateException
/*     */   {
/* 118 */     if (this.isClosed) {
/* 119 */       throw new HibernateException("connection manager has been closed");
/*     */     }
/* 121 */     if (this.connection == null) {
/* 122 */       openConnection();
/*     */     }
/* 124 */     return this.connection;
/*     */   }
/*     */   
/*     */   public boolean hasBorrowedConnection()
/*     */   {
/* 129 */     return this.borrowedConnection != null;
/*     */   }
/*     */   
/*     */   public Connection borrowConnection() {
/* 133 */     if (this.isClosed) {
/* 134 */       throw new HibernateException("connection manager has been closed");
/*     */     }
/* 136 */     if (isSuppliedConnection()) {
/* 137 */       return this.connection;
/*     */     }
/*     */     
/* 140 */     if (this.borrowedConnection == null) {
/* 141 */       this.borrowedConnection = BorrowedConnectionProxy.generateProxy(this);
/*     */     }
/* 143 */     return this.borrowedConnection;
/*     */   }
/*     */   
/*     */   public void releaseBorrowedConnection()
/*     */   {
/* 148 */     if (this.borrowedConnection != null) {
/* 149 */       this.borrowedConnection = null;
/* 150 */       BorrowedConnectionProxy.renderUnuseable(this.borrowedConnection);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutoCommit()
/*     */     throws SQLException
/*     */   {
/* 163 */     return (this.connection == null) || (this.connection.getAutoCommit());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAggressiveRelease()
/*     */   {
/*     */     boolean inAutoCommitState;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 182 */       inAutoCommitState = (!this.callback.isTransactionInProgress()) && (isAutoCommit());
/*     */     }
/*     */     catch (SQLException e) {
/*     */       boolean inAutoCommitState;
/* 186 */       inAutoCommitState = true;
/*     */     }
/*     */     
/* 189 */     return (this.releaseMode == ConnectionReleaseMode.AFTER_STATEMENT) || ((this.releaseMode == ConnectionReleaseMode.AFTER_TRANSACTION) && (inAutoCommitState));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCurrentlyConnected()
/*     */   {
/* 201 */     return this.connection != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterStatement()
/*     */   {
/* 210 */     if (isAggressiveRelease()) {
/* 211 */       if (this.batcher.hasOpenResources()) {
/* 212 */         log.debug("skipping aggresive-release due to open resources on batcher");
/*     */       }
/* 214 */       else if (this.borrowedConnection != null) {
/* 215 */         log.debug("skipping aggresive-release due to borrowed connection");
/*     */       }
/*     */       else {
/* 218 */         aggressiveRelease();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterTransaction()
/*     */   {
/* 229 */     if (isAfterTransactionRelease()) {
/* 230 */       aggressiveRelease();
/*     */     }
/* 232 */     else if ((isAggressiveRelease()) && (this.batcher.hasOpenResources())) {
/* 233 */       log.info("forcing batcher resource cleanup on transaction completion; forgot to close ScrollableResults/Iterator?");
/* 234 */       this.batcher.closeStatements();
/* 235 */       aggressiveRelease();
/*     */     }
/* 237 */     else if (isOnCloseRelease())
/*     */     {
/* 239 */       log.debug("transaction completed on session with on_close connection release mode; be sure to close the session to release JDBC resources!");
/*     */     }
/* 241 */     this.batcher.unsetTransactionTimeout();
/*     */   }
/*     */   
/*     */   private boolean isAfterTransactionRelease() {
/* 245 */     return this.releaseMode == ConnectionReleaseMode.AFTER_TRANSACTION;
/*     */   }
/*     */   
/*     */   private boolean isOnCloseRelease() {
/* 249 */     return this.releaseMode == ConnectionReleaseMode.ON_CLOSE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Connection close()
/*     */   {
/*     */     try
/*     */     {
/* 261 */       return cleanup();
/*     */     }
/*     */     finally {
/* 264 */       this.isClosed = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Connection manualDisconnect()
/*     */   {
/* 276 */     return cleanup();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void manualReconnect() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void manualReconnect(Connection suppliedConnection)
/*     */   {
/* 295 */     this.connection = suppliedConnection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Connection cleanup()
/*     */     throws HibernateException
/*     */   {
/* 309 */     releaseBorrowedConnection();
/*     */     
/* 311 */     if (this.connection == null) {
/* 312 */       log.trace("connection already null in cleanup : no action");
/* 313 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 317 */       log.trace("performing cleanup");
/*     */       
/* 319 */       this.batcher.closeStatements();
/* 320 */       Connection c = null;
/* 321 */       if (!this.wasConnectionSupplied) {
/* 322 */         closeConnection();
/*     */       }
/*     */       else {
/* 325 */         c = this.connection;
/*     */       }
/* 327 */       this.connection = null;
/* 328 */       return c;
/*     */     }
/*     */     finally {
/* 331 */       this.callback.connectionCleanedUp();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void aggressiveRelease()
/*     */   {
/* 340 */     if (!this.wasConnectionSupplied) {
/* 341 */       log.debug("aggressively releasing JDBC connection");
/* 342 */       if (this.connection != null) {
/* 343 */         closeConnection();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void openConnection()
/*     */     throws HibernateException
/*     */   {
/* 354 */     if (this.connection != null) {
/* 355 */       return;
/*     */     }
/*     */     
/* 358 */     log.debug("opening JDBC connection");
/*     */     try {
/* 360 */       this.connection = this.factory.getConnectionProvider().getConnection();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 363 */       throw JDBCExceptionHelper.convert(this.factory.getSQLExceptionConverter(), sqle, "Cannot open connection");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 370 */     this.callback.connectionOpened();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void closeConnection()
/*     */   {
/* 377 */     if (log.isDebugEnabled()) {
/* 378 */       log.debug("releasing JDBC connection [" + this.batcher.openResourceStatsAsString() + "]");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 385 */       if (!this.connection.isClosed()) {
/* 386 */         JDBCExceptionReporter.logAndClearWarnings(this.connection);
/*     */       }
/* 388 */       this.factory.getConnectionProvider().closeConnection(this.connection);
/* 389 */       this.connection = null;
/*     */     }
/*     */     catch (SQLException sqle) {
/* 392 */       throw JDBCExceptionHelper.convert(this.factory.getSQLExceptionConverter(), sqle, "Cannot release connection");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isReadyForSerialization()
/*     */   {
/* 401 */     return this.connection == null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeObject(ObjectOutputStream oos)
/*     */     throws IOException
/*     */   {
/* 411 */     if (!isReadyForSerialization()) {
/* 412 */       throw new IllegalStateException("Cannot serialize a ConnectionManager while connected");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 417 */     if (this.connection != null) {
/* 418 */       closeConnection();
/*     */     }
/*     */     
/* 421 */     oos.writeObject(this.factory);
/* 422 */     oos.writeObject(this.interceptor);
/* 423 */     oos.defaultWriteObject();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readObject(ObjectInputStream ois)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 434 */     this.factory = ((SessionFactoryImplementor)ois.readObject());
/* 435 */     this.interceptor = ((Interceptor)ois.readObject());
/* 436 */     ois.defaultReadObject();
/*     */     
/* 438 */     this.batcher = this.factory.getSettings().getBatcherFactory().createBatcher(this, this.interceptor);
/*     */   }
/*     */   
/*     */   public static abstract interface Callback
/*     */   {
/*     */     public abstract void connectionOpened();
/*     */     
/*     */     public abstract void connectionCleanedUp();
/*     */     
/*     */     public abstract boolean isTransactionInProgress();
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\jdbc\ConnectionManager.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */