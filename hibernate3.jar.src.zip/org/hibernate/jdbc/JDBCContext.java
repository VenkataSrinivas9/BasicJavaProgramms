/*     */ package org.hibernate.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import javax.transaction.TransactionManager;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.ConnectionReleaseMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Interceptor;
/*     */ import org.hibernate.SessionException;
/*     */ import org.hibernate.TransactionException;
/*     */ import org.hibernate.cfg.Settings;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.exception.JDBCExceptionHelper;
/*     */ import org.hibernate.stat.Statistics;
/*     */ import org.hibernate.stat.StatisticsImplementor;
/*     */ import org.hibernate.transaction.CacheSynchronization;
/*     */ import org.hibernate.transaction.TransactionFactory;
/*     */ import org.hibernate.transaction.TransactionFactory.Context;
/*     */ import org.hibernate.util.JTAHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDBCContext
/*     */   implements Serializable, ConnectionManager.Callback
/*     */ {
/*  45 */   private static final Log log = LogFactory.getLog(JDBCContext.class);
/*     */   
/*     */ 
/*     */   private Context owner;
/*     */   
/*     */ 
/*     */   private ConnectionManager connectionManager;
/*     */   
/*     */ 
/*     */   private transient Connection borrowedConnection;
/*     */   
/*     */ 
/*     */   private transient boolean isTransactionCallbackRegistered;
/*     */   
/*     */ 
/*     */   private transient org.hibernate.Transaction hibernateTransaction;
/*     */   
/*     */ 
/*     */ 
/*     */   public JDBCContext(Context owner, Connection connection, Interceptor interceptor)
/*     */   {
/*  66 */     this.owner = owner;
/*  67 */     this.connectionManager = new ConnectionManager(owner.getFactory(), this, owner.getConnectionReleaseMode(), connection, interceptor);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  75 */     boolean registerSynchronization = (owner.isAutoCloseSessionEnabled()) || (owner.isFlushBeforeCompletionEnabled()) || (owner.getConnectionReleaseMode() == ConnectionReleaseMode.AFTER_TRANSACTION);
/*     */     
/*     */ 
/*  78 */     if (registerSynchronization) {
/*  79 */       registerSynchronizationIfPossible();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void connectionOpened()
/*     */   {
/*  87 */     if (!this.isTransactionCallbackRegistered)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */       registerSynchronizationIfPossible();
/*     */     }
/*     */     
/*  96 */     if (this.owner.getFactory().getStatistics().isStatisticsEnabled()) {
/*  97 */       this.owner.getFactory().getStatisticsImplementor().connect();
/*     */     }
/*     */   }
/*     */   
/*     */   public void connectionCleanedUp() {
/* 102 */     if (!this.isTransactionCallbackRegistered) {
/* 103 */       afterTransactionCompletion(false, null);
/*     */     }
/*     */   }
/*     */   
/*     */   public SessionFactoryImplementor getFactory()
/*     */   {
/* 109 */     return this.owner.getFactory();
/*     */   }
/*     */   
/*     */   public ConnectionManager getConnectionManager() {
/* 113 */     return this.connectionManager;
/*     */   }
/*     */   
/*     */   public Connection borrowConnection() {
/* 117 */     return this.connectionManager.borrowConnection();
/*     */   }
/*     */   
/*     */   public Connection connection() throws HibernateException {
/* 121 */     if (!this.owner.isOpen()) {
/* 122 */       throw new SessionException("Session is closed");
/*     */     }
/*     */     
/* 125 */     return this.connectionManager.getConnection();
/*     */   }
/*     */   
/*     */   public boolean registerCallbackIfNecessary() {
/* 129 */     if (this.isTransactionCallbackRegistered) {
/* 130 */       return false;
/*     */     }
/*     */     
/* 133 */     this.isTransactionCallbackRegistered = true;
/* 134 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean registerSynchronizationIfPossible()
/*     */   {
/* 140 */     if (this.isTransactionCallbackRegistered) return true;
/* 141 */     TransactionManager tm = this.owner.getFactory().getTransactionManager();
/* 142 */     if (tm == null) {
/* 143 */       return false;
/*     */     }
/*     */     try
/*     */     {
/* 147 */       javax.transaction.Transaction tx = tm.getTransaction();
/* 148 */       if (JTAHelper.isTransactionInProgress(tx)) {
/* 149 */         tx.registerSynchronization(new CacheSynchronization(this.owner, this, tx, null));
/* 150 */         this.isTransactionCallbackRegistered = true;
/* 151 */         log.debug("successfully registered Synchronization");
/* 152 */         return true;
/*     */       }
/*     */       
/* 155 */       log.debug("no active transaction, could not register Synchronization");
/* 156 */       return false;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 160 */       throw new TransactionException("could not register synchronization with JTA TransactionManager", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isTransactionInProgress()
/*     */   {
/* 166 */     boolean isHibernateTransactionActive = (this.hibernateTransaction != null) && (this.hibernateTransaction.isActive());
/*     */     
/* 168 */     return (isHibernateTransactionActive) || (JTAHelper.isTransactionInProgress(this.owner.getFactory()));
/*     */   }
/*     */   
/*     */   public org.hibernate.Transaction getTransaction() throws HibernateException {
/* 172 */     if (this.hibernateTransaction == null) {
/* 173 */       this.hibernateTransaction = this.owner.getFactory().getSettings().getTransactionFactory().createTransaction(this, this.owner);
/*     */     }
/*     */     
/*     */ 
/* 177 */     return this.hibernateTransaction;
/*     */   }
/*     */   
/*     */   public void beforeTransactionCompletion(org.hibernate.Transaction tx) {
/* 181 */     log.trace("before transaction completion");
/* 182 */     this.owner.beforeTransactionCompletion(tx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterTransactionBegin(org.hibernate.Transaction tx)
/*     */   {
/* 190 */     log.trace("after transaction begin");
/* 191 */     this.owner.afterTransactionBegin(tx);
/*     */   }
/*     */   
/*     */   public void afterTransactionCompletion(boolean success, org.hibernate.Transaction tx) {
/* 195 */     log.trace("after transaction completion");
/*     */     
/* 197 */     if (getFactory().getStatistics().isStatisticsEnabled()) {
/* 198 */       getFactory().getStatisticsImplementor().endTransaction(success);
/*     */     }
/*     */     
/* 201 */     this.connectionManager.afterTransaction();
/*     */     
/* 203 */     this.isTransactionCallbackRegistered = false;
/* 204 */     this.hibernateTransaction = null;
/* 205 */     this.owner.afterTransactionCompletion(success, tx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterNontransactionalQuery(boolean success)
/*     */   {
/* 213 */     log.trace("after autocommit");
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 219 */       boolean isAutocommit = this.connectionManager.isAutoCommit();
/*     */       
/* 221 */       this.connectionManager.afterTransaction();
/*     */       
/* 223 */       if (isAutocommit) {
/* 224 */         this.owner.afterTransactionCompletion(success, null);
/*     */       }
/*     */     }
/*     */     catch (SQLException sqle) {
/* 228 */       throw JDBCExceptionHelper.convert(this.owner.getFactory().getSQLExceptionConverter(), sqle, "could not inspect JDBC autocommit mode");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeObject(ObjectOutputStream oos)
/*     */     throws IOException
/*     */   {
/* 248 */     oos.defaultWriteObject();
/* 249 */     boolean deserHasCallbackRegistered = (this.isTransactionCallbackRegistered) && (!this.owner.getFactory().getSettings().getTransactionFactory().areCallbacksLocalToHibernateTransactions());
/*     */     
/*     */ 
/* 252 */     oos.writeBoolean(deserHasCallbackRegistered);
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 256 */     ois.defaultReadObject();
/* 257 */     this.isTransactionCallbackRegistered = ois.readBoolean();
/*     */   }
/*     */   
/*     */   public static abstract interface Context
/*     */     extends TransactionFactory.Context
/*     */   {
/*     */     public abstract void afterTransactionBegin(org.hibernate.Transaction paramTransaction);
/*     */     
/*     */     public abstract void beforeTransactionCompletion(org.hibernate.Transaction paramTransaction);
/*     */     
/*     */     public abstract void afterTransactionCompletion(boolean paramBoolean, org.hibernate.Transaction paramTransaction);
/*     */     
/*     */     public abstract ConnectionReleaseMode getConnectionReleaseMode();
/*     */     
/*     */     public abstract boolean isAutoCloseSessionEnabled();
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\jdbc\JDBCContext.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */