package org.hibernate.jdbc;

import org.hibernate.Interceptor;

public abstract interface BatcherFactory
{
  public abstract Batcher createBatcher(ConnectionManager paramConnectionManager, Interceptor paramInterceptor);
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\jdbc\BatcherFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */