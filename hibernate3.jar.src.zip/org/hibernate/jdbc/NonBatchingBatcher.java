/*    */ package org.hibernate.jdbc;
/*    */ 
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.SQLException;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.Interceptor;
/*    */ import org.hibernate.StaleStateException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NonBatchingBatcher
/*    */   extends AbstractBatcher
/*    */ {
/*    */   public NonBatchingBatcher(ConnectionManager connectionManager, Interceptor interceptor)
/*    */   {
/* 19 */     super(connectionManager, interceptor);
/*    */   }
/*    */   
/*    */   public void addToBatch(int expectedRowCount) throws SQLException, HibernateException {
/* 23 */     int rowCount = getStatement().executeUpdate();
/*    */     
/* 25 */     if (expectedRowCount > 0) {
/* 26 */       if (expectedRowCount > rowCount) {
/* 27 */         throw new StaleStateException("Unexpected row count: " + rowCount + " expected: " + expectedRowCount);
/*    */       }
/*    */       
/*    */ 
/*    */ 
/* 32 */       if (expectedRowCount < rowCount) {
/* 33 */         throw new HibernateException("Unexpected row count: " + rowCount + " expected: " + expectedRowCount);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   protected void doExecuteBatch(PreparedStatement ps)
/*    */     throws SQLException, HibernateException
/*    */   {}
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\jdbc\NonBatchingBatcher.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */