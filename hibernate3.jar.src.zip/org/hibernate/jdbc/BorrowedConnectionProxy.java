/*    */ package org.hibernate.jdbc;
/*    */ 
/*    */ import java.lang.reflect.InvocationHandler;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Proxy;
/*    */ import java.sql.Connection;
/*    */ import org.hibernate.HibernateException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BorrowedConnectionProxy
/*    */   implements InvocationHandler
/*    */ {
/*    */   private final ConnectionManager connectionManager;
/* 24 */   private boolean useable = true;
/*    */   
/*    */   public BorrowedConnectionProxy(ConnectionManager connectionManager) {
/* 27 */     this.connectionManager = connectionManager;
/*    */   }
/*    */   
/*    */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 31 */     if ("close".equals(method.getName())) {
/* 32 */       this.connectionManager.releaseBorrowedConnection();
/* 33 */       return null;
/*    */     }
/*    */     
/* 36 */     if (!this.useable) {
/* 37 */       throw new HibernateException("connnection proxy not usable after transaction completion");
/*    */     }
/*    */     try {
/* 40 */       return method.invoke(this.connectionManager.getConnection(), args);
/*    */     }
/*    */     catch (InvocationTargetException e) {
/* 43 */       throw e.getTargetException();
/*    */     }
/*    */   }
/*    */   
/*    */   public static Connection generateProxy(ConnectionManager connectionManager) {
/* 48 */     BorrowedConnectionProxy handler = new BorrowedConnectionProxy(connectionManager);
/* 49 */     return (Connection)Proxy.newProxyInstance(class$java$sql$Connection.getClassLoader(), new Class[] { Connection.class }, handler);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void renderUnuseable(Connection connection)
/*    */   {
/* 57 */     if ((connection != null) && (Proxy.isProxyClass(connection.getClass()))) {
/* 58 */       InvocationHandler handler = Proxy.getInvocationHandler(connection);
/* 59 */       if (BorrowedConnectionProxy.class.isAssignableFrom(handler.getClass())) {
/* 60 */         ((BorrowedConnectionProxy)handler).useable = false;
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\jdbc\BorrowedConnectionProxy.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */