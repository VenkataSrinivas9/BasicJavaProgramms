/*    */ package org.hibernate.jdbc;
/*    */ 
/*    */ import org.hibernate.Interceptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NonBatchingBatcherFactory
/*    */   implements BatcherFactory
/*    */ {
/*    */   public Batcher createBatcher(ConnectionManager connectionManager, Interceptor interceptor)
/*    */   {
/* 16 */     return new NonBatchingBatcher(connectionManager, interceptor);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\jdbc\NonBatchingBatcherFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */