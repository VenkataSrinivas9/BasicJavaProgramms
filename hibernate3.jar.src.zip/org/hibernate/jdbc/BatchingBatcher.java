/*     */ package org.hibernate.jdbc;
/*     */ 
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Interceptor;
/*     */ import org.hibernate.StaleStateException;
/*     */ import org.hibernate.cfg.Settings;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BatchingBatcher
/*     */   extends AbstractBatcher
/*     */ {
/*     */   private int batchSize;
/*     */   private int[] expectedRowCounts;
/*     */   
/*     */   public BatchingBatcher(ConnectionManager connectionManager, Interceptor interceptor)
/*     */   {
/*  22 */     super(connectionManager, interceptor);
/*  23 */     this.expectedRowCounts = new int[getFactory().getSettings().getJdbcBatchSize()];
/*     */   }
/*     */   
/*     */   public void addToBatch(int expectedRowCount) throws SQLException, HibernateException
/*     */   {
/*  28 */     log.trace("Adding to batch");
/*  29 */     PreparedStatement batchUpdate = getStatement();
/*  30 */     batchUpdate.addBatch();
/*  31 */     this.expectedRowCounts[(this.batchSize++)] = expectedRowCount;
/*  32 */     if (this.batchSize == getFactory().getSettings().getJdbcBatchSize())
/*     */     {
/*  34 */       doExecuteBatch(batchUpdate);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doExecuteBatch(PreparedStatement ps)
/*     */     throws SQLException, HibernateException
/*     */   {
/*  50 */     if (this.batchSize == 0) {
/*  51 */       log.debug("no batched statements to execute");
/*     */     }
/*     */     else
/*     */     {
/*  55 */       if (log.isDebugEnabled()) log.debug("Executing batch size: " + this.batchSize);
/*     */       try
/*     */       {
/*  58 */         checkRowCounts(ps.executeBatch());
/*     */       }
/*     */       catch (RuntimeException re) {
/*  61 */         log.error("Exception executing batch: ", re);
/*  62 */         throw re;
/*     */       }
/*     */       finally {
/*  65 */         this.batchSize = 0;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void checkRowCounts(int[] rowCounts)
/*     */   {
/*  74 */     int rowCountLength = rowCounts.length;
/*  75 */     if (rowCountLength != this.batchSize) {
/*  76 */       log.warn("JDBC driver did not return the expected number of row counts");
/*     */     }
/*  78 */     for (int i = 0; i < rowCountLength; i++) {
/*  79 */       checkRowCount(rowCounts[i], this.expectedRowCounts[i], i);
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkRowCount(int rowCount, int expectedRowCount, int i) {
/*  84 */     if (rowCount == -2) {
/*  85 */       if (log.isDebugEnabled()) log.debug("success of batch update unknown: " + i);
/*     */     } else {
/*  87 */       if (rowCount == -3) {
/*  88 */         throw new HibernateException("Batch update failed: " + i);
/*     */       }
/*     */       
/*  91 */       if (expectedRowCount >= 0) {
/*  92 */         if (rowCount < expectedRowCount) {
/*  93 */           throw new StaleStateException("Batch update returned unexpected row count from update: " + i + " actual row count: " + rowCount + " expected: " + expectedRowCount);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*  99 */         if (rowCount > expectedRowCount) {
/* 100 */           throw new HibernateException("Batch update returned unexpected row count from update: " + i + " actual row count: " + rowCount + " expected: " + expectedRowCount);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\jdbc\BatchingBatcher.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */