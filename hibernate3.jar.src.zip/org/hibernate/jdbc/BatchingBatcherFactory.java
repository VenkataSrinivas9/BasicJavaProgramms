/*    */ package org.hibernate.jdbc;
/*    */ 
/*    */ import org.hibernate.Interceptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BatchingBatcherFactory
/*    */   implements BatcherFactory
/*    */ {
/*    */   public Batcher createBatcher(ConnectionManager connectionManager, Interceptor interceptor)
/*    */   {
/* 16 */     return new BatchingBatcher(connectionManager, interceptor);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\jdbc\BatchingBatcherFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */