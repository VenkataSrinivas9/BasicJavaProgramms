package org.hibernate.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.hibernate.HibernateException;
import org.hibernate.ScrollMode;
import org.hibernate.dialect.Dialect;

public abstract interface Batcher
{
  public abstract PreparedStatement prepareQueryStatement(String paramString, boolean paramBoolean, ScrollMode paramScrollMode)
    throws SQLException, HibernateException;
  
  public abstract void closeQueryStatement(PreparedStatement paramPreparedStatement, ResultSet paramResultSet)
    throws SQLException;
  
  public abstract CallableStatement prepareCallableQueryStatement(String paramString, boolean paramBoolean, ScrollMode paramScrollMode)
    throws SQLException, HibernateException;
  
  public abstract PreparedStatement prepareSelectStatement(String paramString)
    throws SQLException, HibernateException;
  
  public abstract PreparedStatement prepareStatement(String paramString, boolean paramBoolean, String[] paramArrayOfString)
    throws SQLException, HibernateException;
  
  public abstract PreparedStatement prepareStatement(String paramString)
    throws SQLException, HibernateException;
  
  public abstract CallableStatement prepareCallableStatement(String paramString)
    throws SQLException, HibernateException;
  
  public abstract void closeStatement(PreparedStatement paramPreparedStatement)
    throws SQLException;
  
  public abstract PreparedStatement prepareBatchStatement(String paramString)
    throws SQLException, HibernateException;
  
  public abstract CallableStatement prepareBatchCallableStatement(String paramString)
    throws SQLException, HibernateException;
  
  public abstract void addToBatch(int paramInt)
    throws SQLException, HibernateException;
  
  public abstract void executeBatch()
    throws HibernateException;
  
  public abstract void closeStatements();
  
  public abstract ResultSet getResultSet(PreparedStatement paramPreparedStatement)
    throws SQLException;
  
  public abstract ResultSet getResultSet(CallableStatement paramCallableStatement, Dialect paramDialect)
    throws SQLException;
  
  public abstract void abortBatch(SQLException paramSQLException);
  
  public abstract void cancelLastQuery()
    throws HibernateException;
  
  public abstract boolean hasOpenResources();
  
  public abstract String openResourceStatsAsString();
  
  public abstract Connection openConnection()
    throws HibernateException;
  
  public abstract void closeConnection(Connection paramConnection)
    throws HibernateException;
  
  public abstract void setTransactionTimeout(int paramInt);
  
  public abstract void unsetTransactionTimeout();
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\jdbc\Batcher.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */