/*    */ package org.hibernate.jdbc;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColumnNameCache
/*    */ {
/*    */   private final Map columnNameToIndexCache;
/*    */   
/*    */   public ColumnNameCache(int columnCount)
/*    */   {
/* 19 */     this.columnNameToIndexCache = new HashMap(columnCount);
/*    */   }
/*    */   
/*    */   public int getIndexForColumnName(String columnName, ResultSetWrapper rs) throws SQLException {
/* 23 */     Integer cached = (Integer)this.columnNameToIndexCache.get(columnName);
/* 24 */     if (cached != null) {
/* 25 */       return cached.intValue();
/*    */     }
/*    */     
/* 28 */     int index = rs.getTarget().findColumn(columnName);
/* 29 */     this.columnNameToIndexCache.put(columnName, new Integer(index));
/* 30 */     return index;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\jdbc\ColumnNameCache.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */