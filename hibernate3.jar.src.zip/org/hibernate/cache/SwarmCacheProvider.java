/*    */ package org.hibernate.cache;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import net.sf.swarmcache.CacheConfiguration;
/*    */ import net.sf.swarmcache.CacheConfigurationManager;
/*    */ import net.sf.swarmcache.CacheFactory;
/*    */ import net.sf.swarmcache.ObjectCache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SwarmCacheProvider
/*    */   implements CacheProvider
/*    */ {
/*    */   private CacheFactory factory;
/*    */   
/*    */   public Cache buildCache(String regionName, Properties properties)
/*    */     throws CacheException
/*    */   {
/* 21 */     ObjectCache cache = this.factory.createCache(regionName);
/* 22 */     if (cache == null) {
/* 23 */       throw new CacheException("SwarmCache did not create a cache: " + regionName);
/*    */     }
/* 25 */     return new SwarmCache(cache, regionName);
/*    */   }
/*    */   
/*    */   public long nextTimestamp() {
/* 29 */     return System.currentTimeMillis() / 100L;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void start(Properties properties)
/*    */     throws CacheException
/*    */   {
/* 39 */     CacheConfiguration config = CacheConfigurationManager.getConfig(properties);
/* 40 */     this.factory = new CacheFactory(config);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void stop()
/*    */   {
/* 48 */     if (this.factory != null) {
/* 49 */       this.factory.shutdown();
/* 50 */       this.factory = null;
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isMinimalPutsEnabledByDefault() {
/* 55 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\SwarmCacheProvider.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */