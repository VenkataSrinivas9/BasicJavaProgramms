/*    */ package org.hibernate.cache;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import org.hibernate.EntityMode;
/*    */ import org.hibernate.engine.FilterDefinition;
/*    */ import org.hibernate.engine.TypedValue;
/*    */ import org.hibernate.impl.FilterImpl;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FilterKey
/*    */   implements Serializable
/*    */ {
/*    */   private String filterName;
/* 23 */   private Map filterParameters = new HashMap();
/*    */   
/*    */   public FilterKey(String name, Map params, Map types, EntityMode entityMode) {
/* 26 */     this.filterName = name;
/* 27 */     Iterator iter = params.entrySet().iterator();
/* 28 */     while (iter.hasNext()) {
/* 29 */       Map.Entry me = (Map.Entry)iter.next();
/* 30 */       Type type = (Type)types.get(me.getKey());
/* 31 */       this.filterParameters.put(me.getKey(), new TypedValue(type, me.getValue(), entityMode));
/*    */     }
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 36 */     int result = 13;
/* 37 */     result = 37 * result + this.filterName.hashCode();
/* 38 */     result = 37 * result + this.filterParameters.hashCode();
/* 39 */     return result;
/*    */   }
/*    */   
/*    */   public boolean equals(Object other) {
/* 43 */     if (!(other instanceof FilterKey)) return false;
/* 44 */     FilterKey that = (FilterKey)other;
/* 45 */     if (!that.filterName.equals(this.filterName)) return false;
/* 46 */     if (!that.filterParameters.equals(this.filterParameters)) return false;
/* 47 */     return true;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 51 */     return "FilterKey[" + this.filterName + this.filterParameters + ']';
/*    */   }
/*    */   
/*    */   public static Set createFilterKeys(Map enabledFilters, EntityMode entityMode) {
/* 55 */     if (enabledFilters.size() == 0) return null;
/* 56 */     Set result = new HashSet();
/* 57 */     Iterator iter = enabledFilters.values().iterator();
/* 58 */     while (iter.hasNext()) {
/* 59 */       FilterImpl filter = (FilterImpl)iter.next();
/* 60 */       FilterKey key = new FilterKey(filter.getName(), filter.getParameters(), filter.getFilterDefinition().getParameterTypes(), entityMode);
/*    */       
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 66 */       result.add(key);
/*    */     }
/* 68 */     return result;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\FilterKey.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */