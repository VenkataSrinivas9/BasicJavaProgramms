/*    */ package org.hibernate.cache;
/*    */ 
/*    */ import org.hibernate.HibernateException;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheException
/*    */   extends HibernateException
/*    */ {
/*    */   public CacheException(String s)
/*    */   {
/* 12 */     super(s);
/*    */   }
/*    */   
/*    */   public CacheException(String s, Exception e) {
/* 16 */     super(s, e);
/*    */   }
/*    */   
/*    */   public CacheException(Exception e) {
/* 20 */     super(e);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\CacheException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */