/*    */ package org.hibernate.cache;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import javax.transaction.TransactionManager;
/*    */ import org.hibernate.transaction.TransactionManagerLookupFactory;
/*    */ import org.jboss.cache.PropertyConfigurator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TreeCacheProvider
/*    */   implements CacheProvider
/*    */ {
/*    */   private org.jboss.cache.TreeCache cache;
/*    */   private TransactionManager transactionManager;
/*    */   
/*    */   public Cache buildCache(String regionName, Properties properties)
/*    */     throws CacheException
/*    */   {
/* 31 */     return new TreeCache(this.cache, regionName, this.transactionManager);
/*    */   }
/*    */   
/*    */   public long nextTimestamp() {
/* 35 */     return System.currentTimeMillis() / 100L;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void start(Properties properties)
/*    */   {
/*    */     try
/*    */     {
/* 47 */       this.cache = new org.jboss.cache.TreeCache();
/* 48 */       PropertyConfigurator config = new PropertyConfigurator();
/* 49 */       config.configure(this.cache, "treecache.xml");
/* 50 */       org.hibernate.transaction.TransactionManagerLookup transactionManagerLookup = TransactionManagerLookupFactory.getTransactionManagerLookup(properties);
/* 51 */       if (transactionManagerLookup != null) {
/* 52 */         this.cache.setTransactionManagerLookup(new TransactionManagerLookupAdaptor(transactionManagerLookup, properties));
/* 53 */         this.transactionManager = transactionManagerLookup.getTransactionManager(properties);
/*    */       }
/* 55 */       this.cache.start();
/*    */     }
/*    */     catch (Exception e) {
/* 58 */       throw new CacheException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   public void stop() {
/* 63 */     if (this.cache != null) {
/* 64 */       this.cache.stop();
/* 65 */       this.cache.destroy();
/* 66 */       this.cache = null;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/* 71 */   public boolean isMinimalPutsEnabledByDefault() { return true; }
/*    */   
/*    */   static final class TransactionManagerLookupAdaptor implements org.jboss.cache.TransactionManagerLookup {
/*    */     private final org.hibernate.transaction.TransactionManagerLookup tml;
/*    */     private final Properties props;
/*    */     
/*    */     TransactionManagerLookupAdaptor(org.hibernate.transaction.TransactionManagerLookup tml, Properties props) {
/* 78 */       this.tml = tml;
/* 79 */       this.props = props;
/*    */     }
/*    */     
/* 82 */     public TransactionManager getTransactionManager() throws Exception { return this.tml.getTransactionManager(this.props); }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\TreeCacheProvider.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */