/*    */ package org.hibernate.cache;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.MappingException;
/*    */ import org.hibernate.cfg.Settings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CacheFactory
/*    */ {
/* 17 */   private static final Log log = LogFactory.getLog(CacheFactory.class);
/*    */   
/*    */ 
/*    */   public static final String READ_ONLY = "read-only";
/*    */   
/*    */ 
/*    */   public static final String READ_WRITE = "read-write";
/*    */   
/*    */ 
/*    */   public static final String NONSTRICT_READ_WRITE = "nonstrict-read-write";
/*    */   
/*    */   public static final String TRANSACTIONAL = "transactional";
/*    */   
/*    */ 
/*    */   public static CacheConcurrencyStrategy createCache(String concurrencyStrategy, String regionName, boolean mutable, Settings settings, Properties properties)
/*    */     throws HibernateException
/*    */   {
/* 34 */     if ((concurrencyStrategy == null) || (!settings.isSecondLevelCacheEnabled())) { return null;
/*    */     }
/* 36 */     String prefix = settings.getCacheRegionPrefix();
/* 37 */     if (prefix != null) { regionName = prefix + '.' + regionName;
/*    */     }
/* 39 */     if (log.isDebugEnabled()) log.debug("instantiating cache region: " + regionName + " usage strategy: " + concurrencyStrategy);
/*    */     CacheConcurrencyStrategy ccs;
/*    */     CacheConcurrencyStrategy ccs;
/* 42 */     if (concurrencyStrategy.equals("read-only")) {
/* 43 */       if (mutable) log.warn("read-only cache configured for mutable class: " + regionName);
/* 44 */       ccs = new ReadOnlyCache();
/*    */     } else { CacheConcurrencyStrategy ccs;
/* 46 */       if (concurrencyStrategy.equals("read-write")) {
/* 47 */         ccs = new ReadWriteCache();
/*    */       } else { CacheConcurrencyStrategy ccs;
/* 49 */         if (concurrencyStrategy.equals("nonstrict-read-write")) {
/* 50 */           ccs = new NonstrictReadWriteCache();
/*    */         }
/* 52 */         else if (concurrencyStrategy.equals("transactional")) {
/* 53 */           ccs = new TransactionalCache();
/*    */         }
/*    */         else {
/* 56 */           throw new MappingException("cache usage attribute should be read-write, read-only, nonstrict-read-write or transactional");
/*    */         }
/*    */       }
/*    */     }
/*    */     try {
/* 61 */       impl = settings.getCacheProvider().buildCache(regionName, properties);
/*    */     } catch (CacheException e) {
/*    */       Cache impl;
/* 64 */       throw new HibernateException("Could not instantiate cache implementation", e); }
/*    */     Cache impl;
/* 66 */     ccs.setCache(impl);
/*    */     
/* 68 */     return ccs;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\CacheFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */