/*     */ package org.hibernate.cache;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransactionalCache
/*     */   implements CacheConcurrencyStrategy
/*     */ {
/*  19 */   private static final Log log = LogFactory.getLog(TransactionalCache.class);
/*     */   private Cache cache;
/*     */   
/*     */   public String getRegionName()
/*     */   {
/*  24 */     return this.cache.getRegionName();
/*     */   }
/*     */   
/*     */   public Object get(Object key, long txTimestamp) throws CacheException {
/*  28 */     if (log.isDebugEnabled()) log.debug("cache lookup: " + key);
/*  29 */     Object result = this.cache.read(key);
/*  30 */     if (log.isDebugEnabled()) {
/*  31 */       log.debug(result == null ? "cache miss" : "cache hit");
/*     */     }
/*  33 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean put(Object key, Object value, long txTimestamp, Object version, Comparator versionComparator, boolean minimalPut)
/*     */     throws CacheException
/*     */   {
/*  45 */     if ((minimalPut) && (this.cache.read(key) != null)) {
/*  46 */       if (log.isDebugEnabled()) log.debug("item already cached: " + key);
/*  47 */       return false;
/*     */     }
/*  49 */     if (log.isDebugEnabled()) log.debug("caching: " + key);
/*  50 */     this.cache.put(key, value);
/*  51 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CacheConcurrencyStrategy.SoftLock lock(Object key, Object version)
/*     */     throws CacheException
/*     */   {
/*  59 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void release(Object key, CacheConcurrencyStrategy.SoftLock clientLock)
/*     */     throws CacheException
/*     */   {}
/*     */   
/*     */   public boolean update(Object key, Object value)
/*     */     throws CacheException
/*     */   {
/*  70 */     if (log.isDebugEnabled()) log.debug("updating: " + key);
/*  71 */     this.cache.update(key, value);
/*  72 */     return true;
/*     */   }
/*     */   
/*     */   public boolean insert(Object key, Object value) throws CacheException {
/*  76 */     if (log.isDebugEnabled()) log.debug("inserting: " + key);
/*  77 */     this.cache.update(key, value);
/*  78 */     return true;
/*     */   }
/*     */   
/*     */   public void evict(Object key) throws CacheException {
/*  82 */     this.cache.remove(key);
/*     */   }
/*     */   
/*     */   public void remove(Object key) throws CacheException {
/*  86 */     if (log.isDebugEnabled()) log.debug("removing: " + key);
/*  87 */     this.cache.remove(key);
/*     */   }
/*     */   
/*     */   public void clear() throws CacheException {
/*  91 */     log.debug("clearing");
/*  92 */     this.cache.clear();
/*     */   }
/*     */   
/*     */   public void destroy() {
/*     */     try {
/*  97 */       this.cache.destroy();
/*     */     }
/*     */     catch (Exception e) {
/* 100 */       log.warn("could not destroy cache", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setCache(Cache cache) {
/* 105 */     this.cache = cache;
/*     */   }
/*     */   
/*     */   public Cache getCache() {
/* 109 */     return this.cache;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean afterInsert(Object key, Object value, Object version)
/*     */     throws CacheException
/*     */   {
/* 117 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean afterUpdate(Object key, Object value, Object version, CacheConcurrencyStrategy.SoftLock clientLock)
/*     */     throws CacheException
/*     */   {
/* 125 */     return false;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 129 */     return this.cache + "(transactional)";
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\TransactionalCache.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */