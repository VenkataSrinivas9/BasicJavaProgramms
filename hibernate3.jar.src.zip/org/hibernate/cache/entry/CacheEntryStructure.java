package org.hibernate.cache.entry;

import org.hibernate.engine.SessionFactoryImplementor;

public abstract interface CacheEntryStructure
{
  public abstract Object structure(Object paramObject);
  
  public abstract Object destructure(Object paramObject, SessionFactoryImplementor paramSessionFactoryImplementor);
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\entry\CacheEntryStructure.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */