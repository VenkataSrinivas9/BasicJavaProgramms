/*    */ package org.hibernate.cache.entry;
/*    */ 
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnstructuredCacheEntry
/*    */   implements CacheEntryStructure
/*    */ {
/*    */   public Object structure(Object item)
/*    */   {
/* 13 */     return item;
/*    */   }
/*    */   
/*    */   public Object destructure(Object map, SessionFactoryImplementor factory) {
/* 17 */     return map;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\entry\UnstructuredCacheEntry.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */