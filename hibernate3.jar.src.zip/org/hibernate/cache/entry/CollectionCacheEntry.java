/*    */ package org.hibernate.cache.entry;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.collection.PersistentCollection;
/*    */ import org.hibernate.persister.collection.CollectionPersister;
/*    */ import org.hibernate.util.ArrayHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CollectionCacheEntry
/*    */   implements Serializable
/*    */ {
/*    */   private final Serializable state;
/*    */   
/*    */   public Serializable[] getState()
/*    */   {
/* 19 */     return (Serializable[])this.state;
/*    */   }
/*    */   
/*    */   public CollectionCacheEntry(PersistentCollection collection, CollectionPersister persister) {
/* 23 */     this.state = collection.disassemble(persister);
/*    */   }
/*    */   
/*    */   CollectionCacheEntry(Serializable state) {
/* 27 */     this.state = state;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void assemble(PersistentCollection collection, CollectionPersister persister, Object owner)
/*    */   {
/* 35 */     collection.initializeFromCache(persister, this.state, owner);
/* 36 */     collection.afterInitialize();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 40 */     return "CollectionCacheEntry" + ArrayHelper.toString(getState());
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\entry\CollectionCacheEntry.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */