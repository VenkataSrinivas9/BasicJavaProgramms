/*    */ package org.hibernate.cache.entry;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StructuredCollectionCacheEntry
/*    */   implements CacheEntryStructure
/*    */ {
/*    */   public Object structure(Object item)
/*    */   {
/* 16 */     CollectionCacheEntry entry = (CollectionCacheEntry)item;
/* 17 */     return Arrays.asList(entry.getState());
/*    */   }
/*    */   
/*    */   public Object destructure(Object item, SessionFactoryImplementor factory) {
/* 21 */     List list = (List)item;
/* 22 */     return new CollectionCacheEntry(list.toArray(new Serializable[list.size()]));
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\entry\StructuredCollectionCacheEntry.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */