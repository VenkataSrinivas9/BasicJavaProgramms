/*     */ package org.hibernate.cache.entry;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Interceptor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.event.EventListeners;
/*     */ import org.hibernate.event.EventSource;
/*     */ import org.hibernate.event.PreLoadEvent;
/*     */ import org.hibernate.event.PreLoadEventListener;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.type.TypeFactory;
/*     */ import org.hibernate.util.ArrayHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CacheEntry
/*     */   implements Serializable
/*     */ {
/*     */   private final Serializable[] disassembledState;
/*     */   private final String subclass;
/*     */   private final boolean lazyPropertiesAreUnfetched;
/*     */   private final Object version;
/*     */   
/*     */   public String getSubclass()
/*     */   {
/*  30 */     return this.subclass;
/*     */   }
/*     */   
/*     */   public boolean areLazyPropertiesUnfetched() {
/*  34 */     return this.lazyPropertiesAreUnfetched;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CacheEntry(Object[] state, EntityPersister persister, boolean unfetched, Object version, SessionImplementor session, Object owner)
/*     */     throws HibernateException
/*     */   {
/*  46 */     this.disassembledState = TypeFactory.disassemble(state, persister.getPropertyTypes(), persister.isLazyPropertiesCacheable() ? null : persister.getPropertyLaziness(), session, owner);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  54 */     this.subclass = persister.getEntityName();
/*  55 */     this.lazyPropertiesAreUnfetched = ((unfetched) || (!persister.isLazyPropertiesCacheable()));
/*  56 */     this.version = version;
/*     */   }
/*     */   
/*     */   public Object getVersion() {
/*  60 */     return this.version;
/*     */   }
/*     */   
/*     */   CacheEntry(Serializable[] state, String subclass, boolean unfetched, Object version) {
/*  64 */     this.disassembledState = state;
/*  65 */     this.subclass = subclass;
/*  66 */     this.lazyPropertiesAreUnfetched = unfetched;
/*  67 */     this.version = version;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object[] assemble(Object instance, Serializable id, EntityPersister persister, Interceptor interceptor, EventSource session)
/*     */     throws HibernateException
/*     */   {
/*  78 */     if (!persister.getEntityName().equals(this.subclass)) {
/*  79 */       throw new AssertionFailure("Tried to assemble a different subclass instance");
/*     */     }
/*     */     
/*  82 */     return assemble(this.disassembledState, instance, id, persister, interceptor, session);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Object[] assemble(Serializable[] values, Object result, Serializable id, EntityPersister persister, Interceptor interceptor, EventSource session)
/*     */     throws HibernateException
/*     */   {
/*  96 */     Object[] assembledProps = TypeFactory.assemble(values, persister.getPropertyTypes(), session, result);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */     PreLoadEvent preLoadEvent = new PreLoadEvent(session).setEntity(result).setState(assembledProps).setId(id).setPersister(persister);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 111 */     PreLoadEventListener[] listeners = session.getListeners().getPreLoadEventListeners();
/* 112 */     for (int i = 0; i < listeners.length; i++) {
/* 113 */       listeners[i].onPreLoad(preLoadEvent);
/*     */     }
/*     */     
/* 116 */     persister.setPropertyValues(result, assembledProps, session.getEntityMode());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 122 */     return assembledProps;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Serializable[] getDisassembledState()
/*     */   {
/* 129 */     return this.disassembledState;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 133 */     return "CacheEntry(" + this.subclass + ')' + ArrayHelper.toString(this.disassembledState);
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\entry\CacheEntry.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */