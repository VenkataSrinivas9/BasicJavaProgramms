/*    */ package org.hibernate.cache.entry;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ 
/*    */ 
/*    */ public class StructuredMapCacheEntry
/*    */   implements CacheEntryStructure
/*    */ {
/*    */   public Object structure(Object item)
/*    */   {
/* 17 */     CollectionCacheEntry entry = (CollectionCacheEntry)item;
/* 18 */     Serializable[] state = entry.getState();
/* 19 */     Map map = new HashMap(state.length);
/* 20 */     for (int i = 0; i < state.length;) {
/* 21 */       map.put(state[(i++)], state[(i++)]);
/*    */     }
/* 23 */     return map;
/*    */   }
/*    */   
/*    */   public Object destructure(Object item, SessionFactoryImplementor factory) {
/* 27 */     Map map = (Map)item;
/* 28 */     Serializable[] state = new Serializable[map.size() * 2];
/* 29 */     int i = 0;
/* 30 */     Iterator iter = map.entrySet().iterator();
/* 31 */     while (iter.hasNext()) {
/* 32 */       Map.Entry me = (Map.Entry)iter.next();
/* 33 */       state[(i++)] = ((Serializable)me.getKey());
/* 34 */       state[(i++)] = ((Serializable)me.getValue());
/*    */     }
/* 36 */     return new CollectionCacheEntry(state);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\entry\StructuredMapCacheEntry.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */