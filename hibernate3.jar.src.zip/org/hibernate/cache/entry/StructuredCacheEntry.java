/*    */ package org.hibernate.cache.entry;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StructuredCacheEntry
/*    */   implements CacheEntryStructure
/*    */ {
/*    */   private EntityPersister persister;
/*    */   
/*    */   public StructuredCacheEntry(EntityPersister persister)
/*    */   {
/* 19 */     this.persister = persister;
/*    */   }
/*    */   
/*    */   public Object destructure(Object item, SessionFactoryImplementor factory) {
/* 23 */     Map map = (Map)item;
/* 24 */     boolean lazyPropertiesUnfetched = ((Boolean)map.get("_lazyPropertiesUnfetched")).booleanValue();
/* 25 */     String subclass = (String)map.get("_subclass");
/* 26 */     Object version = map.get("_version");
/* 27 */     EntityPersister subclassPersister = factory.getEntityPersister(subclass);
/* 28 */     String[] names = subclassPersister.getPropertyNames();
/* 29 */     Serializable[] state = new Serializable[names.length];
/* 30 */     for (int i = 0; i < names.length; i++) {
/* 31 */       state[i] = ((Serializable)map.get(names[i]));
/*    */     }
/* 33 */     return new CacheEntry(state, subclass, lazyPropertiesUnfetched, version);
/*    */   }
/*    */   
/*    */   public Object structure(Object item) {
/* 37 */     CacheEntry entry = (CacheEntry)item;
/* 38 */     String[] names = this.persister.getPropertyNames();
/* 39 */     Map map = new HashMap(names.length + 2);
/* 40 */     map.put("_subclass", entry.getSubclass());
/* 41 */     map.put("_version", entry.getVersion());
/* 42 */     map.put("_lazyPropertiesUnfetched", entry.areLazyPropertiesUnfetched() ? Boolean.TRUE : Boolean.FALSE);
/* 43 */     for (int i = 0; i < names.length; i++) {
/* 44 */       map.put(names[i], entry.getDisassembledState()[i]);
/*    */     }
/* 46 */     return map;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\entry\StructuredCacheEntry.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */