/*     */ package org.hibernate.cache;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.sf.ehcache.CacheManager;
/*     */ import net.sf.ehcache.Element;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EhCache
/*     */   implements Cache
/*     */ {
/*  82 */   private static final Log log = LogFactory.getLog(EhCache.class);
/*     */   
/*     */ 
/*     */ 
/*     */   private net.sf.ehcache.Cache cache;
/*     */   
/*     */ 
/*     */ 
/*     */   public EhCache(net.sf.ehcache.Cache cache)
/*     */   {
/*  92 */     this.cache = cache;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object get(Object key)
/*     */     throws CacheException
/*     */   {
/*     */     try
/*     */     {
/* 103 */       if (log.isDebugEnabled()) {
/* 104 */         log.debug("key: " + key);
/*     */       }
/* 106 */       if (key == null) {
/* 107 */         return null;
/*     */       }
/*     */       
/* 110 */       Element element = this.cache.get((Serializable)key);
/* 111 */       if (element == null) {
/* 112 */         if (log.isDebugEnabled()) {
/* 113 */           log.debug("Element for " + key + " is null");
/*     */         }
/* 115 */         return null;
/*     */       }
/*     */       
/* 118 */       return element.getValue();
/*     */ 
/*     */     }
/*     */     catch (net.sf.ehcache.CacheException e)
/*     */     {
/* 123 */       throw new CacheException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object read(Object key) throws CacheException {
/* 128 */     return get(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void update(Object key, Object value)
/*     */     throws CacheException
/*     */   {
/* 140 */     put(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void put(Object key, Object value)
/*     */     throws CacheException
/*     */   {
/*     */     try
/*     */     {
/* 152 */       Element element = new Element((Serializable)key, (Serializable)value);
/* 153 */       this.cache.put(element);
/*     */     }
/*     */     catch (IllegalArgumentException e) {
/* 156 */       throw new CacheException(e);
/*     */     }
/*     */     catch (IllegalStateException e) {
/* 159 */       throw new CacheException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void remove(Object key)
/*     */     throws CacheException
/*     */   {
/*     */     try
/*     */     {
/* 173 */       this.cache.remove((Serializable)key);
/*     */     }
/*     */     catch (ClassCastException e) {
/* 176 */       throw new CacheException(e);
/*     */     }
/*     */     catch (IllegalStateException e) {
/* 179 */       throw new CacheException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */     throws CacheException
/*     */   {
/*     */     try
/*     */     {
/* 190 */       this.cache.removeAll();
/*     */     }
/*     */     catch (IllegalStateException e) {
/* 193 */       throw new CacheException(e);
/*     */     }
/*     */     catch (IOException e) {
/* 196 */       throw new CacheException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void destroy()
/*     */     throws CacheException
/*     */   {
/*     */     try
/*     */     {
/* 206 */       CacheManager.getInstance().removeCache(this.cache.getName());
/*     */     }
/*     */     catch (IllegalStateException e) {
/* 209 */       throw new CacheException(e);
/*     */     }
/*     */     catch (net.sf.ehcache.CacheException e) {
/* 212 */       throw new CacheException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void lock(Object key)
/*     */     throws CacheException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void unlock(Object key)
/*     */     throws CacheException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long nextTimestamp()
/*     */   {
/* 236 */     return Timestamper.next();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getTimeout()
/*     */   {
/* 244 */     return 245760000;
/*     */   }
/*     */   
/*     */   public String getRegionName() {
/* 248 */     return this.cache.getName();
/*     */   }
/*     */   
/*     */   public long getSizeInMemory() {
/*     */     try {
/* 253 */       return this.cache.calculateInMemorySize();
/*     */     }
/*     */     catch (Throwable t) {}
/* 256 */     return -1L;
/*     */   }
/*     */   
/*     */   public long getElementCountInMemory()
/*     */   {
/*     */     try {
/* 262 */       return this.cache.getSize();
/*     */     }
/*     */     catch (net.sf.ehcache.CacheException ce) {
/* 265 */       throw new CacheException(ce);
/*     */     }
/*     */   }
/*     */   
/*     */   public long getElementCountOnDisk() {
/* 270 */     return this.cache.getDiskStoreSize();
/*     */   }
/*     */   
/*     */   public Map toMap() {
/*     */     try {
/* 275 */       Map result = new HashMap();
/* 276 */       Iterator iter = this.cache.getKeys().iterator();
/* 277 */       while (iter.hasNext()) {
/* 278 */         Object key = iter.next();
/* 279 */         result.put(key, this.cache.get((Serializable)key).getValue());
/*     */       }
/* 281 */       return result;
/*     */     }
/*     */     catch (Exception e) {
/* 284 */       throw new CacheException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() {
/* 289 */     return "EHCache(" + getRegionName() + ')';
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\EhCache.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */