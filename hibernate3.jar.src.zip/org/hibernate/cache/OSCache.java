/*     */ package org.hibernate.cache;
/*     */ 
/*     */ import com.opensymphony.oscache.base.NeedsRefreshException;
/*     */ import com.opensymphony.oscache.general.GeneralCacheAdministrator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OSCache
/*     */   implements Cache
/*     */ {
/*  17 */   private GeneralCacheAdministrator cache = new GeneralCacheAdministrator();
/*     */   private final int refreshPeriod;
/*     */   private final String cron;
/*     */   private final String regionName;
/*     */   
/*     */   private String toString(Object key)
/*     */   {
/*  24 */     return String.valueOf(key) + '.' + this.regionName;
/*     */   }
/*     */   
/*     */   public OSCache(int refreshPeriod, String cron, String region) {
/*  28 */     this.refreshPeriod = refreshPeriod;
/*  29 */     this.cron = cron;
/*  30 */     this.regionName = region;
/*     */   }
/*     */   
/*     */   public void setCacheCapacity(int cacheCapacity) {
/*  34 */     this.cache.setCacheCapacity(cacheCapacity);
/*     */   }
/*     */   
/*     */   public Object get(Object key) throws CacheException {
/*     */     try {
/*  39 */       return this.cache.getFromCache(toString(key), this.refreshPeriod, this.cron);
/*     */     }
/*     */     catch (NeedsRefreshException e) {
/*  42 */       this.cache.cancelUpdate(toString(key)); }
/*  43 */     return null;
/*     */   }
/*     */   
/*     */   public Object read(Object key) throws CacheException
/*     */   {
/*  48 */     return get(key);
/*     */   }
/*     */   
/*     */   public void update(Object key, Object value) throws CacheException {
/*  52 */     put(key, value);
/*     */   }
/*     */   
/*     */   public void put(Object key, Object value) throws CacheException {
/*  56 */     this.cache.putInCache(toString(key), value);
/*     */   }
/*     */   
/*     */   public void remove(Object key) throws CacheException {
/*  60 */     this.cache.flushEntry(toString(key));
/*     */   }
/*     */   
/*     */   public void clear() throws CacheException {
/*  64 */     this.cache.flushAll();
/*     */   }
/*     */   
/*     */   public void destroy() throws CacheException {
/*  68 */     this.cache.destroy();
/*     */   }
/*     */   
/*     */   public void lock(Object key)
/*     */     throws CacheException
/*     */   {}
/*     */   
/*     */   public void unlock(Object key) throws CacheException
/*     */   {}
/*     */   
/*     */   public long nextTimestamp()
/*     */   {
/*  80 */     return Timestamper.next();
/*     */   }
/*     */   
/*     */   public int getTimeout() {
/*  84 */     return 245760000;
/*     */   }
/*     */   
/*     */   public String getRegionName() {
/*  88 */     return this.regionName;
/*     */   }
/*     */   
/*     */   public long getSizeInMemory() {
/*  92 */     return -1L;
/*     */   }
/*     */   
/*     */   public long getElementCountInMemory() {
/*  96 */     return -1L;
/*     */   }
/*     */   
/*     */   public long getElementCountOnDisk() {
/* 100 */     return -1L;
/*     */   }
/*     */   
/*     */   public Map toMap() {
/* 104 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 108 */     return "OSCache(" + this.regionName + ')';
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\OSCache.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */