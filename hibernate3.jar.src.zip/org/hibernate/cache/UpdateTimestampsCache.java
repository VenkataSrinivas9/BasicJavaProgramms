/*     */ package org.hibernate.cache;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Iterator;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.cfg.Settings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UpdateTimestampsCache
/*     */ {
/*  25 */   private static final Log log = LogFactory.getLog(UpdateTimestampsCache.class);
/*     */   
/*     */   private Cache updateTimestamps;
/*     */   
/*     */   private final String regionName;
/*  30 */   public static final String REGION_NAME = UpdateTimestampsCache.class.getName();
/*     */   
/*     */   public void clear() throws CacheException {
/*  33 */     this.updateTimestamps.clear();
/*     */   }
/*     */   
/*     */   public UpdateTimestampsCache(Settings settings, Properties props) throws HibernateException
/*     */   {
/*  38 */     String prefix = settings.getCacheRegionPrefix();
/*     */     
/*  40 */     this.regionName = (prefix + '.' + REGION_NAME);
/*     */     
/*     */ 
/*  43 */     log.info("starting update timestamps cache at region: " + this.regionName);
/*  44 */     this.updateTimestamps = settings.getCacheProvider().buildCache(this.regionName, props);
/*     */   }
/*     */   
/*     */   public synchronized void preinvalidate(Serializable[] spaces) throws CacheException
/*     */   {
/*  49 */     Long ts = new Long(this.updateTimestamps.nextTimestamp() + this.updateTimestamps.getTimeout());
/*  50 */     for (int i = 0; i < spaces.length; i++) {
/*  51 */       if (log.isDebugEnabled()) { log.debug("Pre-invalidating space [" + spaces[i] + "]");
/*     */       }
/*     */       
/*  54 */       this.updateTimestamps.put(spaces[i], ts);
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void invalidate(Serializable[] spaces)
/*     */     throws CacheException
/*     */   {
/*  61 */     Long ts = new Long(this.updateTimestamps.nextTimestamp());
/*     */     
/*  63 */     for (int i = 0; i < spaces.length; i++) {
/*  64 */       if (log.isDebugEnabled()) { log.debug("Invalidating space [" + spaces[i] + "], timestamp: " + ts);
/*     */       }
/*     */       
/*  67 */       this.updateTimestamps.put(spaces[i], ts);
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized boolean isUpToDate(Set spaces, Long timestamp) throws HibernateException {
/*  72 */     Iterator iter = spaces.iterator();
/*  73 */     while (iter.hasNext()) {
/*  74 */       Serializable space = (Serializable)iter.next();
/*  75 */       Long lastUpdate = (Long)this.updateTimestamps.get(space);
/*  76 */       if (lastUpdate != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */         if (log.isDebugEnabled()) {
/*  84 */           log.debug("[" + space + "] last update timestamp: " + lastUpdate + ", result set timestamp: " + timestamp);
/*     */         }
/*  86 */         if (lastUpdate.longValue() >= timestamp.longValue()) return false;
/*     */       }
/*     */     }
/*  89 */     return true;
/*     */   }
/*     */   
/*     */   public void destroy() {
/*     */     try {
/*  94 */       this.updateTimestamps.destroy();
/*     */     }
/*     */     catch (Exception e) {
/*  97 */       log.warn("could not destroy UpdateTimestamps cache", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public Cache getCache() {
/* 102 */     return this.updateTimestamps;
/*     */   }
/*     */   
/*     */   public String getRegionName() {
/* 106 */     return this.regionName;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 110 */     return "UpdateTimestampeCache";
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\UpdateTimestampsCache.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */