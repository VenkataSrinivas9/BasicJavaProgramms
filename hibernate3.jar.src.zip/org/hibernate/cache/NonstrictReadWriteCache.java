/*     */ package org.hibernate.cache;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NonstrictReadWriteCache
/*     */   implements CacheConcurrencyStrategy
/*     */ {
/*     */   private Cache cache;
/*  23 */   private static final Log log = LogFactory.getLog(NonstrictReadWriteCache.class);
/*     */   
/*     */ 
/*     */   public void setCache(Cache cache)
/*     */   {
/*  28 */     this.cache = cache;
/*     */   }
/*     */   
/*     */   public Cache getCache() {
/*  32 */     return this.cache;
/*     */   }
/*     */   
/*     */ 
/*     */   public Object get(Object key, long txTimestamp)
/*     */     throws CacheException
/*     */   {
/*  39 */     if (log.isDebugEnabled()) { log.debug("Cache lookup: " + key);
/*     */     }
/*  41 */     Object result = this.cache.get(key);
/*  42 */     if (result != null) {
/*  43 */       log.debug("Cache hit");
/*     */     }
/*     */     else {
/*  46 */       log.debug("Cache miss");
/*     */     }
/*  48 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean put(Object key, Object value, long txTimestamp, Object version, Comparator versionComparator, boolean minimalPut)
/*     */     throws CacheException
/*     */   {
/*  62 */     if ((minimalPut) && (this.cache.get(key) != null)) {
/*  63 */       if (log.isDebugEnabled()) log.debug("item already cached: " + key);
/*  64 */       return false;
/*     */     }
/*  66 */     if (log.isDebugEnabled()) { log.debug("Caching: " + key);
/*     */     }
/*  68 */     this.cache.put(key, value);
/*  69 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CacheConcurrencyStrategy.SoftLock lock(Object key, Object version)
/*     */     throws CacheException
/*     */   {
/*  78 */     return null;
/*     */   }
/*     */   
/*     */   public void remove(Object key) throws CacheException {
/*  82 */     if (log.isDebugEnabled()) log.debug("Removing: " + key);
/*  83 */     this.cache.remove(key);
/*     */   }
/*     */   
/*     */   public void clear() throws CacheException {
/*  87 */     if (log.isDebugEnabled()) log.debug("Clearing");
/*  88 */     this.cache.clear();
/*     */   }
/*     */   
/*     */   public void destroy() {
/*     */     try {
/*  93 */       this.cache.destroy();
/*     */     }
/*     */     catch (Exception e) {
/*  96 */       log.warn("could not destroy cache", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void evict(Object key)
/*     */     throws CacheException
/*     */   {
/* 104 */     if (log.isDebugEnabled()) { log.debug("Invalidating: " + key);
/*     */     }
/* 106 */     this.cache.remove(key);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean update(Object key, Object value)
/*     */     throws CacheException
/*     */   {
/* 113 */     evict(key);
/* 114 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean insert(Object key, Object value)
/*     */     throws CacheException
/*     */   {
/* 121 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public void release(Object key, CacheConcurrencyStrategy.SoftLock lock)
/*     */     throws CacheException
/*     */   {
/* 128 */     if (log.isDebugEnabled()) { log.debug("Invalidating (again): " + key);
/*     */     }
/* 130 */     this.cache.remove(key);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean afterUpdate(Object key, Object value, Object version, CacheConcurrencyStrategy.SoftLock lock)
/*     */     throws CacheException
/*     */   {
/* 137 */     release(key, lock);
/* 138 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean afterInsert(Object key, Object value, Object version)
/*     */     throws CacheException
/*     */   {
/* 148 */     return false;
/*     */   }
/*     */   
/*     */   public String getRegionName() {
/* 152 */     return this.cache.getRegionName();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 156 */     return this.cache + "(nonstrict-read-write)";
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\NonstrictReadWriteCache.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */