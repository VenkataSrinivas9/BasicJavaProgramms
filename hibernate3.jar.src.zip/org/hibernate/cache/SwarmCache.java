/*     */ package org.hibernate.cache;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ import net.sf.swarmcache.ObjectCache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SwarmCache
/*     */   implements Cache
/*     */ {
/*     */   private final ObjectCache cache;
/*     */   private final String regionName;
/*     */   
/*     */   public SwarmCache(ObjectCache cache, String regionName)
/*     */   {
/*  18 */     this.cache = cache;
/*  19 */     this.regionName = regionName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object get(Object key)
/*     */     throws CacheException
/*     */   {
/*  29 */     if ((key instanceof Serializable)) {
/*  30 */       return this.cache.get((Serializable)key);
/*     */     }
/*     */     
/*  33 */     throw new CacheException("Keys must implement Serializable");
/*     */   }
/*     */   
/*     */   public Object read(Object key) throws CacheException
/*     */   {
/*  38 */     return get(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void update(Object key, Object value)
/*     */     throws CacheException
/*     */   {
/*  48 */     put(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void put(Object key, Object value)
/*     */     throws CacheException
/*     */   {
/*  58 */     if ((key instanceof Serializable)) {
/*  59 */       this.cache.put((Serializable)key, value);
/*     */     }
/*     */     else {
/*  62 */       throw new CacheException("Keys must implement Serializable");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void remove(Object key)
/*     */     throws CacheException
/*     */   {
/*  70 */     if ((key instanceof Serializable)) {
/*  71 */       this.cache.clear((Serializable)key);
/*     */     }
/*     */     else {
/*  74 */       throw new CacheException("Keys must implement Serializable");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void clear()
/*     */     throws CacheException
/*     */   {
/*  82 */     this.cache.clearAll();
/*     */   }
/*     */   
/*     */ 
/*     */   public void destroy()
/*     */     throws CacheException
/*     */   {
/*  89 */     this.cache.clearAll();
/*     */   }
/*     */   
/*     */ 
/*     */   public void lock(Object key)
/*     */     throws CacheException
/*     */   {
/*  96 */     throw new UnsupportedOperationException("SwarmCache does not support locking (use nonstrict-read-write)");
/*     */   }
/*     */   
/*     */ 
/*     */   public void unlock(Object key)
/*     */     throws CacheException
/*     */   {
/* 103 */     throw new UnsupportedOperationException("SwarmCache does not support locking (use nonstrict-read-write)");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public long nextTimestamp()
/*     */   {
/* 110 */     return System.currentTimeMillis() / 100L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getTimeout()
/*     */   {
/* 117 */     return 600;
/*     */   }
/*     */   
/*     */   public String getRegionName() {
/* 121 */     return this.regionName;
/*     */   }
/*     */   
/*     */   public long getSizeInMemory() {
/* 125 */     return -1L;
/*     */   }
/*     */   
/*     */   public long getElementCountInMemory() {
/* 129 */     return -1L;
/*     */   }
/*     */   
/*     */   public long getElementCountOnDisk() {
/* 133 */     return -1L;
/*     */   }
/*     */   
/*     */   public Map toMap() {
/* 137 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 141 */     return "SwarmCache(" + this.regionName + ')';
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\SwarmCache.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */