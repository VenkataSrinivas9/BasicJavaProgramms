/*    */ package org.hibernate.cache;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import javax.transaction.TransactionManager;
/*    */ import org.hibernate.transaction.TransactionManagerLookup;
/*    */ import org.hibernate.transaction.TransactionManagerLookupFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JndiBoundTreeCacheProvider
/*    */   extends AbstractJndiBoundCacheProvider
/*    */ {
/*    */   private TransactionManager transactionManager;
/*    */   
/*    */   public Cache buildCache(String regionName, Properties properties)
/*    */     throws CacheException
/*    */   {
/* 31 */     return new TreeCache(getTreeCacheInstance(), regionName, this.transactionManager);
/*    */   }
/*    */   
/*    */   public void prepare(Properties properties) throws CacheException {
/* 35 */     TransactionManagerLookup transactionManagerLookup = TransactionManagerLookupFactory.getTransactionManagerLookup(properties);
/* 36 */     if (transactionManagerLookup != null) {
/* 37 */       this.transactionManager = transactionManagerLookup.getTransactionManager(properties);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public long nextTimestamp()
/*    */   {
/* 44 */     return System.currentTimeMillis() / 100L;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isMinimalPutsEnabledByDefault()
/*    */   {
/* 57 */     return true;
/*    */   }
/*    */   
/*    */   public org.jboss.cache.TreeCache getTreeCacheInstance() {
/* 61 */     return (org.jboss.cache.TreeCache)super.getCache();
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\JndiBoundTreeCacheProvider.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */