package org.hibernate.cache;

import java.util.Properties;

public abstract interface CacheProvider
{
  public abstract Cache buildCache(String paramString, Properties paramProperties)
    throws CacheException;
  
  public abstract long nextTimestamp();
  
  public abstract void start(Properties paramProperties)
    throws CacheException;
  
  public abstract void stop();
  
  public abstract boolean isMinimalPutsEnabledByDefault();
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\CacheProvider.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */