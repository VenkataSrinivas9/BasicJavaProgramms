/*     */ package org.hibernate.cache;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Comparator;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReadWriteCache
/*     */   implements CacheConcurrencyStrategy
/*     */ {
/*  28 */   private static final Log log = LogFactory.getLog(ReadWriteCache.class);
/*     */   
/*     */   private Cache cache;
/*     */   
/*     */   private int nextLockId;
/*     */   
/*     */   public void setCache(Cache cache)
/*     */   {
/*  36 */     this.cache = cache;
/*     */   }
/*     */   
/*     */   public Cache getCache() {
/*  40 */     return this.cache;
/*     */   }
/*     */   
/*     */   public String getRegionName() {
/*  44 */     return this.cache.getRegionName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int nextLockId()
/*     */   {
/*  53 */     if (this.nextLockId == Integer.MAX_VALUE) this.nextLockId = Integer.MIN_VALUE;
/*  54 */     return this.nextLockId++;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Object get(Object key, long txTimestamp)
/*     */     throws CacheException
/*     */   {
/*  75 */     if (log.isTraceEnabled()) { log.trace("Cache lookup: " + key);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  80 */     Lockable lockable = (Lockable)this.cache.get(key);
/*     */     
/*  82 */     boolean gettable = (lockable != null) && (lockable.isGettable(txTimestamp));
/*     */     
/*  84 */     if (gettable) {
/*  85 */       if (log.isTraceEnabled()) log.trace("Cache hit: " + key);
/*  86 */       return ((Item)lockable).getValue();
/*     */     }
/*     */     
/*  89 */     if (log.isTraceEnabled()) {
/*  90 */       if (lockable == null) {
/*  91 */         log.trace("Cache miss: " + key);
/*     */       }
/*     */       else {
/*  94 */         log.trace("Cached item was locked: " + key);
/*     */       }
/*     */     }
/*  97 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized CacheConcurrencyStrategy.SoftLock lock(Object key, Object version)
/*     */     throws CacheException
/*     */   {
/* 113 */     if (log.isTraceEnabled()) log.trace("Invalidating: " + key);
/*     */     try
/*     */     {
/* 116 */       this.cache.lock(key);
/*     */       
/* 118 */       Lockable lockable = (Lockable)this.cache.get(key);
/* 119 */       long timeout = this.cache.nextTimestamp() + this.cache.getTimeout();
/* 120 */       Lock lock = lockable == null ? new Lock(timeout, nextLockId(), version) : lockable.lock(timeout, nextLockId());
/*     */       
/*     */ 
/* 123 */       this.cache.update(key, lock);
/* 124 */       return lock;
/*     */     }
/*     */     finally {
/* 127 */       this.cache.unlock(key);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean put(Object key, Object value, long txTimestamp, Object version, Comparator versionComparator, boolean minimalPut)
/*     */     throws CacheException
/*     */   {
/* 148 */     if (log.isTraceEnabled()) log.trace("Caching: " + key);
/*     */     try
/*     */     {
/* 151 */       this.cache.lock(key);
/*     */       
/* 153 */       Lockable lockable = (Lockable)this.cache.get(key);
/*     */       
/* 155 */       boolean puttable = (lockable == null) || (lockable.isPuttable(txTimestamp, version, versionComparator));
/*     */       
/*     */       boolean bool1;
/* 158 */       if (puttable) {
/* 159 */         this.cache.put(key, new Item(value, version, this.cache.nextTimestamp()));
/* 160 */         if (log.isTraceEnabled()) log.trace("Cached: " + key);
/* 161 */         return true;
/*     */       }
/*     */       
/* 164 */       if (log.isTraceEnabled()) {
/* 165 */         if (lockable.isLock()) {
/* 166 */           log.trace("Item was locked: " + key);
/*     */         }
/*     */         else {
/* 169 */           log.trace("Item was already cached: " + key);
/*     */         }
/*     */       }
/* 172 */       return false;
/*     */     }
/*     */     finally
/*     */     {
/* 176 */       this.cache.unlock(key);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void decrementLock(Object key, Lock lock)
/*     */     throws CacheException
/*     */   {
/* 185 */     lock.unlock(this.cache.nextTimestamp());
/* 186 */     this.cache.update(key, lock);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void release(Object key, CacheConcurrencyStrategy.SoftLock clientLock)
/*     */     throws CacheException
/*     */   {
/* 195 */     if (log.isTraceEnabled()) log.trace("Releasing: " + key);
/*     */     try
/*     */     {
/* 198 */       this.cache.lock(key);
/*     */       
/* 200 */       Lockable lockable = (Lockable)this.cache.get(key);
/* 201 */       if (isUnlockable(clientLock, lockable)) {
/* 202 */         decrementLock(key, (Lock)lockable);
/*     */       }
/*     */       else {
/* 205 */         handleLockExpiry(key);
/*     */       }
/*     */     }
/*     */     finally {
/* 209 */       this.cache.unlock(key);
/*     */     }
/*     */   }
/*     */   
/*     */   void handleLockExpiry(Object key) throws CacheException {
/* 214 */     log.warn("An item was expired by the cache while it was locked (increase your cache timeout): " + key);
/* 215 */     long ts = this.cache.nextTimestamp() + this.cache.getTimeout();
/*     */     
/* 217 */     Lock lock = new Lock(ts, nextLockId(), null);
/* 218 */     lock.unlock(ts);
/* 219 */     this.cache.update(key, lock);
/*     */   }
/*     */   
/*     */   public void clear() throws CacheException {
/* 223 */     this.cache.clear();
/*     */   }
/*     */   
/*     */   public void remove(Object key) throws CacheException {
/* 227 */     this.cache.remove(key);
/*     */   }
/*     */   
/*     */   public void destroy() {
/*     */     try {
/* 232 */       this.cache.destroy();
/*     */     }
/*     */     catch (Exception e) {
/* 235 */       log.warn("could not destroy cache", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean afterUpdate(Object key, Object value, Object version, CacheConcurrencyStrategy.SoftLock clientLock)
/*     */     throws CacheException
/*     */   {
/* 246 */     if (log.isTraceEnabled()) log.trace("Updating: " + key);
/*     */     try
/*     */     {
/* 249 */       this.cache.lock(key);
/*     */       
/* 251 */       Lockable lockable = (Lockable)this.cache.get(key);
/* 252 */       Lock lock; if (isUnlockable(clientLock, lockable)) {
/* 253 */         lock = (Lock)lockable;
/* 254 */         boolean bool; if (lock.wasLockedConcurrently())
/*     */         {
/*     */ 
/* 257 */           decrementLock(key, lock);
/* 258 */           return false;
/*     */         }
/*     */         
/*     */ 
/* 262 */         this.cache.update(key, new Item(value, version, this.cache.nextTimestamp()));
/* 263 */         if (log.isTraceEnabled()) log.trace("Updated: " + key);
/* 264 */         return true;
/*     */       }
/*     */       
/*     */ 
/* 268 */       handleLockExpiry(key);
/* 269 */       return 0;
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 274 */       this.cache.unlock(key);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean afterInsert(Object key, Object value, Object version)
/*     */     throws CacheException
/*     */   {
/* 285 */     if (log.isTraceEnabled()) log.trace("Inserting: " + key);
/*     */     try {
/* 287 */       this.cache.lock(key);
/*     */       
/* 289 */       Lockable lockable = (Lockable)this.cache.get(key);
/* 290 */       boolean bool; if (lockable == null) {
/* 291 */         this.cache.update(key, new Item(value, version, this.cache.nextTimestamp()));
/* 292 */         if (log.isTraceEnabled()) log.trace("Inserted: " + key);
/* 293 */         return true;
/*     */       }
/*     */       
/* 296 */       return false;
/*     */     }
/*     */     finally
/*     */     {
/* 300 */       this.cache.unlock(key);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void evict(Object key)
/*     */     throws CacheException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean insert(Object key, Object value)
/*     */     throws CacheException
/*     */   {
/* 315 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean update(Object key, Object value)
/*     */     throws CacheException
/*     */   {
/* 322 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isUnlockable(CacheConcurrencyStrategy.SoftLock clientLock, Lockable myLock)
/*     */     throws CacheException
/*     */   {
/* 333 */     return (myLock != null) && (myLock.isLock()) && (clientLock != null) && (((Lock)clientLock).getId() == ((Lock)myLock).getId());
/*     */   }
/*     */   
/*     */ 
/*     */   public static abstract interface Lockable
/*     */   {
/*     */     public abstract ReadWriteCache.Lock lock(long paramLong, int paramInt);
/*     */     
/*     */     public abstract boolean isLock();
/*     */     
/*     */     public abstract boolean isGettable(long paramLong);
/*     */     
/*     */     public abstract boolean isPuttable(long paramLong, Object paramObject, Comparator paramComparator);
/*     */   }
/*     */   
/*     */   public static final class Item
/*     */     implements Serializable, ReadWriteCache.Lockable
/*     */   {
/*     */     private final long freshTimestamp;
/*     */     private final Object value;
/*     */     private final Object version;
/*     */     
/*     */     public Item(Object value, Object version, long currentTimestamp)
/*     */     {
/* 357 */       this.value = value;
/* 358 */       this.version = version;
/* 359 */       this.freshTimestamp = currentTimestamp;
/*     */     }
/*     */     
/*     */ 
/*     */     public long getFreshTimestamp()
/*     */     {
/* 365 */       return this.freshTimestamp;
/*     */     }
/*     */     
/*     */ 
/*     */     public Object getValue()
/*     */     {
/* 371 */       return this.value;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public ReadWriteCache.Lock lock(long timeout, int id)
/*     */     {
/* 378 */       return new ReadWriteCache.Lock(timeout, id, this.version);
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean isLock()
/*     */     {
/* 384 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean isGettable(long txTimestamp)
/*     */     {
/* 391 */       return this.freshTimestamp < txTimestamp;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isPuttable(long txTimestamp, Object newVersion, Comparator comparator)
/*     */     {
/* 401 */       return (this.version != null) && (comparator.compare(this.version, newVersion) < 0);
/*     */     }
/*     */     
/*     */     public String toString() {
/* 405 */       return "Item{version=" + this.version + ",freshTimestamp=" + this.freshTimestamp;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final class Lock
/*     */     implements Serializable, ReadWriteCache.Lockable, CacheConcurrencyStrategy.SoftLock
/*     */   {
/* 416 */     private long unlockTimestamp = -1L;
/* 417 */     private int multiplicity = 1;
/* 418 */     private boolean concurrentLock = false;
/*     */     private long timeout;
/*     */     private final int id;
/*     */     private final Object version;
/*     */     
/*     */     public Lock(long timeout, int id, Object version) {
/* 424 */       this.timeout = timeout;
/* 425 */       this.id = id;
/* 426 */       this.version = version;
/*     */     }
/*     */     
/*     */     public long getUnlockTimestamp() {
/* 430 */       return this.unlockTimestamp;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Lock lock(long timeout, int id)
/*     */     {
/* 437 */       this.concurrentLock = true;
/* 438 */       this.multiplicity += 1;
/* 439 */       this.timeout = timeout;
/* 440 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void unlock(long currentTimestamp)
/*     */     {
/* 448 */       if (--this.multiplicity == 0) {
/* 449 */         this.unlockTimestamp = currentTimestamp;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isPuttable(long txTimestamp, Object newVersion, Comparator comparator)
/*     */     {
/* 458 */       if (this.timeout < txTimestamp) return true;
/* 459 */       if (this.multiplicity > 0) return false;
/* 460 */       return this.unlockTimestamp < txTimestamp;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean wasLockedConcurrently()
/*     */     {
/* 470 */       return this.concurrentLock;
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean isLock()
/*     */     {
/* 476 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean isGettable(long txTimestamp)
/*     */     {
/* 482 */       return false;
/*     */     }
/*     */     
/* 485 */     public int getId() { return this.id; }
/*     */     
/*     */     public String toString() {
/* 488 */       return "Lock{id=" + this.id + ",version=" + this.version + ",multiplicity=" + this.multiplicity + ",unlockTimestamp=" + this.unlockTimestamp;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 497 */     return this.cache + "(read-write)";
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\ReadWriteCache.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */