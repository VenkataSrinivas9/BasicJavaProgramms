/*     */ package org.hibernate.cache;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReadOnlyCache
/*     */   implements CacheConcurrencyStrategy
/*     */ {
/*     */   private Cache cache;
/*  16 */   private static final Log log = LogFactory.getLog(ReadOnlyCache.class);
/*     */   
/*     */ 
/*     */   public void setCache(Cache cache)
/*     */   {
/*  21 */     this.cache = cache;
/*     */   }
/*     */   
/*     */   public Cache getCache() {
/*  25 */     return this.cache;
/*     */   }
/*     */   
/*     */   public String getRegionName() {
/*  29 */     return this.cache.getRegionName();
/*     */   }
/*     */   
/*     */   public synchronized Object get(Object key, long timestamp) throws CacheException {
/*  33 */     Object result = this.cache.get(key);
/*  34 */     if ((result != null) && (log.isDebugEnabled())) log.debug("Cache hit: " + key);
/*  35 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CacheConcurrencyStrategy.SoftLock lock(Object key, Object version)
/*     */   {
/*  42 */     log.error("Application attempted to edit read only item: " + key);
/*  43 */     throw new UnsupportedOperationException("Can't write to a readonly object");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean put(Object key, Object value, long timestamp, Object version, Comparator versionComparator, boolean minimalPut)
/*     */     throws CacheException
/*     */   {
/*  54 */     if ((minimalPut) && (this.cache.get(key) != null)) {
/*  55 */       if (log.isDebugEnabled()) log.debug("item already cached: " + key);
/*  56 */       return false;
/*     */     }
/*  58 */     if (log.isDebugEnabled()) log.debug("Caching: " + key);
/*  59 */     this.cache.put(key, value);
/*  60 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void release(Object key, CacheConcurrencyStrategy.SoftLock lock)
/*     */   {
/*  67 */     log.error("Application attempted to edit read only item: " + key);
/*     */   }
/*     */   
/*     */   public void clear() throws CacheException
/*     */   {
/*  72 */     this.cache.clear();
/*     */   }
/*     */   
/*     */   public void remove(Object key) throws CacheException {
/*  76 */     this.cache.remove(key);
/*     */   }
/*     */   
/*     */   public void destroy() {
/*     */     try {
/*  81 */       this.cache.destroy();
/*     */     }
/*     */     catch (Exception e) {
/*  84 */       log.warn("could not destroy cache", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean afterUpdate(Object key, Object value, Object version, CacheConcurrencyStrategy.SoftLock lock)
/*     */     throws CacheException
/*     */   {
/*  92 */     log.error("Application attempted to edit read only item: " + key);
/*  93 */     throw new UnsupportedOperationException("Can't write to a readonly object");
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean afterInsert(Object key, Object value, Object version)
/*     */     throws CacheException
/*     */   {
/* 100 */     if (log.isDebugEnabled()) log.debug("Caching after insert: " + key);
/* 101 */     this.cache.update(key, value);
/* 102 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void evict(Object key)
/*     */     throws CacheException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean insert(Object key, Object value)
/*     */     throws CacheException
/*     */   {
/* 116 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean update(Object key, Object value)
/*     */     throws CacheException
/*     */   {
/* 123 */     log.error("Application attempted to edit read only item: " + key);
/* 124 */     throw new UnsupportedOperationException("Can't write to a readonly object");
/*     */   }
/*     */   
/*     */   public String toString() {
/* 128 */     return this.cache + "(read-only)";
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\ReadOnlyCache.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */