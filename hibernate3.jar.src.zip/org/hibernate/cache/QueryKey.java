/*     */ package org.hibernate.cache;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.hibernate.EntityMode;
/*     */ import org.hibernate.engine.QueryParameters;
/*     */ import org.hibernate.engine.RowSelection;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.util.EqualsHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueryKey
/*     */   implements Serializable
/*     */ {
/*     */   private final String sqlQueryString;
/*     */   private final Type[] types;
/*     */   private final Object[] values;
/*     */   private final Integer firstRow;
/*     */   private final Integer maxRows;
/*     */   private final Map namedParameters;
/*     */   private final EntityMode entityMode;
/*     */   private final Set filters;
/*     */   private final int hashCode;
/*     */   
/*     */   public QueryKey(String queryString, QueryParameters queryParameters, Set filters, EntityMode entityMode)
/*     */   {
/*  30 */     this.sqlQueryString = queryString;
/*  31 */     this.types = queryParameters.getPositionalParameterTypes();
/*  32 */     this.values = queryParameters.getPositionalParameterValues();
/*  33 */     RowSelection selection = queryParameters.getRowSelection();
/*  34 */     if (selection != null) {
/*  35 */       this.firstRow = selection.getFirstRow();
/*  36 */       this.maxRows = selection.getMaxRows();
/*     */     }
/*     */     else {
/*  39 */       this.firstRow = null;
/*  40 */       this.maxRows = null;
/*     */     }
/*  42 */     this.namedParameters = queryParameters.getNamedParameters();
/*  43 */     this.entityMode = entityMode;
/*  44 */     this.filters = filters;
/*  45 */     this.hashCode = getHashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/*  49 */     QueryKey that = (QueryKey)other;
/*  50 */     if (!this.sqlQueryString.equals(that.sqlQueryString)) return false;
/*  51 */     if ((!EqualsHelper.equals(this.firstRow, that.firstRow)) || (!EqualsHelper.equals(this.maxRows, that.maxRows))) return false;
/*  52 */     if (this.types == null) {
/*  53 */       if (that.types != null) return false;
/*     */     }
/*     */     else {
/*  56 */       if (that.types == null) return false;
/*  57 */       if (this.types.length != that.types.length) return false;
/*  58 */       for (int i = 0; i < this.types.length; i++) {
/*  59 */         if (this.types[i].getReturnedClass() != that.types[i].getReturnedClass()) return false;
/*  60 */         if (!this.types[i].isEqual(this.values[i], that.values[i], this.entityMode)) return false;
/*     */       }
/*     */     }
/*  63 */     if (!EqualsHelper.equals(this.filters, that.filters)) return false;
/*  64 */     if (!EqualsHelper.equals(this.namedParameters, that.namedParameters)) return false;
/*  65 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  69 */     return this.hashCode;
/*     */   }
/*     */   
/*     */   private int getHashCode() {
/*  73 */     int result = 13;
/*  74 */     result = 37 * result + (this.firstRow == null ? 0 : this.firstRow.hashCode());
/*  75 */     result = 37 * result + (this.maxRows == null ? 0 : this.maxRows.hashCode());
/*  76 */     for (int i = 0; i < this.values.length; i++) {
/*  77 */       result = 37 * result + (this.values[i] == null ? 0 : this.types[i].getHashCode(this.values[i], this.entityMode));
/*     */     }
/*  79 */     result = 37 * result + (this.namedParameters == null ? 0 : this.namedParameters.hashCode());
/*  80 */     result = 37 * result + (this.filters == null ? 0 : this.filters.hashCode());
/*  81 */     result = 37 * result + this.sqlQueryString.hashCode();
/*  82 */     return result;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  86 */     StringBuffer buf = new StringBuffer().append("sql: ").append(this.sqlQueryString);
/*     */     
/*     */ 
/*  89 */     if (this.values != null) {
/*  90 */       buf.append("; parameters: ");
/*  91 */       for (int i = 0; i < this.values.length; i++) {
/*  92 */         buf.append(this.values[i]).append(", ");
/*     */       }
/*     */     }
/*     */     
/*  96 */     if (this.namedParameters != null) {
/*  97 */       buf.append("; named parameters: ").append(this.namedParameters);
/*     */     }
/*     */     
/* 100 */     if (this.filters != null) {
/* 101 */       buf.append("; filters: ").append(this.filters);
/*     */     }
/*     */     
/* 104 */     if (this.firstRow != null) buf.append("; first row: ").append(this.firstRow);
/* 105 */     if (this.maxRows != null) buf.append("; max rows: ").append(this.maxRows);
/* 106 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\QueryKey.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */