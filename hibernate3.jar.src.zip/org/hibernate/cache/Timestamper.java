/*    */ package org.hibernate.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Timestamper
/*    */ {
/* 10 */   private static short counter = 0;
/*    */   private static long time;
/*    */   private static final int BIN_DIGITS = 12;
/*    */   public static final short ONE_MS = 4096;
/*    */   
/*    */   public static long next() {
/* 16 */     synchronized (Timestamper.class) {
/* 17 */       long newTime = System.currentTimeMillis() << 12;
/* 18 */       if (time < newTime) {
/* 19 */         time = newTime;
/* 20 */         counter = 0;
/*    */       }
/* 22 */       else if (counter < 4095) {
/* 23 */         counter = (short)(counter + 1);
/*    */       }
/*    */       
/* 26 */       return time + counter;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\Timestamper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */