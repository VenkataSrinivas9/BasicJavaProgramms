/*    */ package org.hibernate.cache;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.cfg.Settings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandardQueryCacheFactory
/*    */   implements QueryCacheFactory
/*    */ {
/*    */   public QueryCache getQueryCache(String regionName, UpdateTimestampsCache updateTimestampsCache, Settings settings, Properties props)
/*    */     throws HibernateException
/*    */   {
/* 21 */     return new StandardQueryCache(settings, props, updateTimestampsCache, regionName);
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\StandardQueryCacheFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */