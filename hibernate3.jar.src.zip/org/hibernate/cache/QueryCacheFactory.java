package org.hibernate.cache;

import java.util.Properties;
import org.hibernate.HibernateException;
import org.hibernate.cfg.Settings;

public abstract interface QueryCacheFactory
{
  public abstract QueryCache getQueryCache(String paramString, UpdateTimestampsCache paramUpdateTimestampsCache, Settings paramSettings, Properties paramProperties)
    throws HibernateException;
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\QueryCacheFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */