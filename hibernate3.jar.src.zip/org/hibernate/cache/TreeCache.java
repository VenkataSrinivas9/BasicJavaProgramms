/*     */ package org.hibernate.cache;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.transaction.SystemException;
/*     */ import javax.transaction.Transaction;
/*     */ import javax.transaction.TransactionManager;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.jboss.cache.Fqn;
/*     */ import org.jboss.cache.lock.TimeoutException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeCache
/*     */   implements Cache
/*     */ {
/*  25 */   private static final Log log = LogFactory.getLog(TreeCache.class);
/*     */   
/*     */   private static final String ITEM = "item";
/*     */   private org.jboss.cache.TreeCache cache;
/*     */   private final String regionName;
/*     */   private final String userRegionName;
/*     */   private final TransactionManager transactionManager;
/*     */   
/*     */   public TreeCache(org.jboss.cache.TreeCache cache, String regionName, TransactionManager transactionManager)
/*     */     throws CacheException
/*     */   {
/*  36 */     this.cache = cache;
/*  37 */     this.userRegionName = regionName;
/*  38 */     this.regionName = regionName.replace('.', '/');
/*  39 */     this.transactionManager = transactionManager;
/*     */   }
/*     */   
/*     */   public Object get(Object key) throws CacheException {
/*  43 */     Transaction tx = suspend();
/*     */     try {
/*  45 */       return read(key);
/*     */     }
/*     */     finally {
/*  48 */       resume(tx);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object read(Object key) throws CacheException {
/*     */     try {
/*  54 */       return this.cache.get(new Fqn(new Object[] { this.regionName, key }), "item");
/*     */     }
/*     */     catch (Exception e) {
/*  57 */       throw new CacheException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void update(Object key, Object value) throws CacheException {
/*     */     try {
/*  63 */       this.cache.put(new Fqn(new Object[] { this.regionName, key }), "item", value);
/*     */     }
/*     */     catch (Exception e) {
/*  66 */       throw new CacheException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void put(Object key, Object value) throws CacheException {
/*  71 */     Transaction tx = suspend();
/*     */     try
/*     */     {
/*  74 */       this.cache.putFailFast(new Fqn(new Object[] { this.regionName, key }), "item", value, 0L);
/*     */     }
/*     */     catch (TimeoutException te)
/*     */     {
/*  78 */       log.debug("ignoring write lock acquisition failure");
/*     */     }
/*     */     catch (Exception e) {
/*  81 */       throw new CacheException(e);
/*     */     }
/*     */     finally {
/*  84 */       resume(tx);
/*     */     }
/*     */   }
/*     */   
/*     */   private void resume(Transaction tx) {
/*     */     try {
/*  90 */       if (tx != null) this.transactionManager.resume(tx);
/*     */     }
/*     */     catch (Exception e) {
/*  93 */       throw new CacheException("Could not resume transaction", e);
/*     */     }
/*     */   }
/*     */   
/*     */   private Transaction suspend() {
/*  98 */     Transaction tx = null;
/*     */     try {
/* 100 */       if (this.transactionManager != null) {
/* 101 */         tx = this.transactionManager.suspend();
/*     */       }
/*     */     }
/*     */     catch (SystemException se) {
/* 105 */       throw new CacheException("Could not suspend transaction", se);
/*     */     }
/* 107 */     return tx;
/*     */   }
/*     */   
/*     */   public void remove(Object key) throws CacheException {
/*     */     try {
/* 112 */       this.cache.remove(new Fqn(new Object[] { this.regionName, key }));
/*     */     }
/*     */     catch (Exception e) {
/* 115 */       throw new CacheException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void clear() throws CacheException {
/*     */     try {
/* 121 */       this.cache.remove(new Fqn(this.regionName));
/*     */     }
/*     */     catch (Exception e) {
/* 124 */       throw new CacheException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void destroy() throws CacheException {
/* 129 */     clear();
/*     */   }
/*     */   
/*     */   public void lock(Object key) throws CacheException {
/* 133 */     throw new UnsupportedOperationException("TreeCache is a fully transactional cache" + this.regionName);
/*     */   }
/*     */   
/*     */   public void unlock(Object key) throws CacheException {
/* 137 */     throw new UnsupportedOperationException("TreeCache is a fully transactional cache: " + this.regionName);
/*     */   }
/*     */   
/*     */   public long nextTimestamp() {
/* 141 */     return System.currentTimeMillis() / 100L;
/*     */   }
/*     */   
/*     */   public int getTimeout() {
/* 145 */     return 600;
/*     */   }
/*     */   
/*     */   public String getRegionName() {
/* 149 */     return this.userRegionName;
/*     */   }
/*     */   
/*     */   public long getSizeInMemory() {
/* 153 */     return -1L;
/*     */   }
/*     */   
/*     */   public long getElementCountInMemory() {
/*     */     try {
/* 158 */       Set children = this.cache.getChildrenNames(new Fqn(this.regionName));
/* 159 */       return children == null ? 0L : children.size();
/*     */     }
/*     */     catch (Exception e) {
/* 162 */       throw new CacheException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public long getElementCountOnDisk() {
/* 167 */     return 0L;
/*     */   }
/*     */   
/*     */   public Map toMap() {
/*     */     try {
/* 172 */       Map result = new HashMap();
/* 173 */       Set childrenNames = this.cache.getChildrenNames(new Fqn(this.regionName));
/* 174 */       if (childrenNames != null) {
/* 175 */         Iterator iter = childrenNames.iterator();
/* 176 */         while (iter.hasNext()) {
/* 177 */           Object key = iter.next();
/* 178 */           result.put(key, this.cache.get(new Fqn(new Object[] { this.regionName, key }), "item"));
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 184 */       return result;
/*     */     }
/*     */     catch (Exception e) {
/* 187 */       throw new CacheException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() {
/* 192 */     return "TreeCache(" + this.userRegionName + ')';
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\TreeCache.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */