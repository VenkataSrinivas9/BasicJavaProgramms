/*     */ package org.hibernate.cache;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import net.sf.ehcache.CacheManager;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EhCacheProvider
/*     */   implements CacheProvider
/*     */ {
/*  76 */   private static final Log log = LogFactory.getLog(EhCacheProvider.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  82 */   private static int referenceCount = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private CacheManager manager;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cache buildCache(String name, Properties properties)
/*     */     throws CacheException
/*     */   {
/*     */     try
/*     */     {
/* 101 */       net.sf.ehcache.Cache cache = this.manager.getCache(name);
/* 102 */       if (cache == null) {
/* 103 */         log.warn("Could not find configuration [" + name + "]; using defaults.");
/* 104 */         this.manager.addCache(name);
/* 105 */         cache = this.manager.getCache(name);
/* 106 */         log.debug("started EHCache region: " + name);
/*     */       }
/* 108 */       return new EhCache(cache);
/*     */     }
/*     */     catch (net.sf.ehcache.CacheException e) {
/* 111 */       throw new CacheException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public long nextTimestamp()
/*     */   {
/* 119 */     return Timestamper.next();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start(Properties properties)
/*     */     throws CacheException
/*     */   {
/*     */     try
/*     */     {
/* 130 */       this.manager = CacheManager.create();
/* 131 */       referenceCount += 1;
/*     */     }
/*     */     catch (net.sf.ehcache.CacheException e) {
/* 134 */       throw new CacheException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */   {
/* 143 */     if (this.manager != null) {
/* 144 */       if (--referenceCount == 0) {
/* 145 */         this.manager.shutdown();
/*     */       }
/* 147 */       this.manager = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isMinimalPutsEnabledByDefault() {
/* 152 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\EhCacheProvider.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */