/*    */ package org.hibernate.cache;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Hashtable;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HashtableCache
/*    */   implements Cache
/*    */ {
/* 15 */   private final Map hashtable = new Hashtable();
/*    */   private final String regionName;
/*    */   
/*    */   public HashtableCache(String regionName) {
/* 19 */     this.regionName = regionName;
/*    */   }
/*    */   
/*    */   public String getRegionName() {
/* 23 */     return this.regionName;
/*    */   }
/*    */   
/*    */   public Object read(Object key) throws CacheException {
/* 27 */     return this.hashtable.get(key);
/*    */   }
/*    */   
/*    */   public Object get(Object key) throws CacheException {
/* 31 */     return this.hashtable.get(key);
/*    */   }
/*    */   
/*    */   public void update(Object key, Object value) throws CacheException {
/* 35 */     put(key, value);
/*    */   }
/*    */   
/*    */   public void put(Object key, Object value) throws CacheException {
/* 39 */     this.hashtable.put(key, value);
/*    */   }
/*    */   
/*    */   public void remove(Object key) throws CacheException {
/* 43 */     this.hashtable.remove(key);
/*    */   }
/*    */   
/*    */   public void clear() throws CacheException {
/* 47 */     this.hashtable.clear();
/*    */   }
/*    */   
/*    */   public void destroy()
/*    */     throws CacheException
/*    */   {}
/*    */   
/*    */   public void lock(Object key)
/*    */     throws CacheException
/*    */   {}
/*    */   
/*    */   public void unlock(Object key) throws CacheException
/*    */   {}
/*    */   
/*    */   public long nextTimestamp()
/*    */   {
/* 63 */     return Timestamper.next();
/*    */   }
/*    */   
/*    */   public int getTimeout() {
/* 67 */     return 245760000;
/*    */   }
/*    */   
/*    */   public long getSizeInMemory() {
/* 71 */     return -1L;
/*    */   }
/*    */   
/*    */   public long getElementCountInMemory() {
/* 75 */     return this.hashtable.size();
/*    */   }
/*    */   
/*    */   public long getElementCountOnDisk() {
/* 79 */     return 0L;
/*    */   }
/*    */   
/*    */   public Map toMap() {
/* 83 */     return Collections.unmodifiableMap(this.hashtable);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 87 */     return "HashtableCache(" + this.regionName + ')';
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\HashtableCache.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */