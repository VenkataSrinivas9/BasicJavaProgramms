/*    */ package org.hibernate.cache;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import javax.naming.Context;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.naming.NamingException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.util.NamingHelper;
/*    */ import org.hibernate.util.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractJndiBoundCacheProvider
/*    */   implements CacheProvider
/*    */ {
/* 24 */   private static final Log log = LogFactory.getLog(AbstractJndiBoundCacheProvider.class);
/*    */   
/*    */ 
/*    */   private Object cache;
/*    */   
/*    */ 
/*    */ 
/*    */   protected void prepare(Properties properties) {}
/*    */   
/*    */ 
/*    */ 
/*    */   protected void release() {}
/*    */   
/*    */ 
/*    */ 
/*    */   public final void start(Properties properties)
/*    */     throws CacheException
/*    */   {
/* 42 */     String jndiNamespace = properties.getProperty("hibernate.cache.jndi");
/* 43 */     if (StringHelper.isEmpty(jndiNamespace)) {
/* 44 */       throw new CacheException("No JNDI namespace specified for cache");
/*    */     }
/* 46 */     this.cache = locateCache(jndiNamespace, NamingHelper.getJndiProperties(properties));
/* 47 */     prepare(properties);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final void stop()
/*    */   {
/* 55 */     release();
/* 56 */     this.cache = null;
/*    */   }
/*    */   
/*    */   private Object locateCache(String jndiNamespace, Properties jndiProperties)
/*    */   {
/* 61 */     Context ctx = null;
/*    */     try {
/* 63 */       ctx = new InitialContext(jndiProperties);
/* 64 */       return ctx.lookup(jndiNamespace);
/*    */     }
/*    */     catch (NamingException ne) {
/* 67 */       String msg = "Unable to retreive Cache from JNDI [" + jndiNamespace + "]";
/* 68 */       log.info(msg, ne);
/* 69 */       throw new CacheException(msg);
/*    */     }
/*    */     finally {
/* 72 */       if (ctx != null) {
/*    */         try {
/* 74 */           ctx.close();
/*    */         }
/*    */         catch (NamingException ne) {
/* 77 */           log.info("Unable to release initial context", ne);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public Object getCache() {
/* 84 */     return this.cache;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\AbstractJndiBoundCacheProvider.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */