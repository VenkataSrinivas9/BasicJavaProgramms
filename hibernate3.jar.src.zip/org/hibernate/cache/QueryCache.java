package org.hibernate.cache;

import java.util.List;
import java.util.Set;
import org.hibernate.HibernateException;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.type.Type;

public abstract interface QueryCache
{
  public abstract void clear()
    throws CacheException;
  
  public abstract boolean put(QueryKey paramQueryKey, Type[] paramArrayOfType, List paramList, boolean paramBoolean, SessionImplementor paramSessionImplementor)
    throws HibernateException;
  
  public abstract List get(QueryKey paramQueryKey, Type[] paramArrayOfType, boolean paramBoolean, Set paramSet, SessionImplementor paramSessionImplementor)
    throws HibernateException;
  
  public abstract void destroy();
  
  public abstract Cache getCache();
  
  public abstract String getRegionName();
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\QueryCache.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */