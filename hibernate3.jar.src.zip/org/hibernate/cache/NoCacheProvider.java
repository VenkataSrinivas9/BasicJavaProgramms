/*    */ package org.hibernate.cache;
/*    */ 
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoCacheProvider
/*    */   implements CacheProvider
/*    */ {
/*    */   public Cache buildCache(String regionName, Properties properties)
/*    */     throws CacheException
/*    */   {
/* 21 */     throw new NoCachingEnabledException();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public long nextTimestamp()
/*    */   {
/* 31 */     return System.currentTimeMillis() / 100L;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void start(Properties properties)
/*    */     throws CacheException
/*    */   {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void stop() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isMinimalPutsEnabledByDefault()
/*    */   {
/* 55 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\NoCacheProvider.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */