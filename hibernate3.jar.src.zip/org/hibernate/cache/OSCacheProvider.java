/*    */ package org.hibernate.cache;
/*    */ 
/*    */ import com.opensymphony.oscache.base.Config;
/*    */ import java.util.Properties;
/*    */ import org.hibernate.util.PropertiesHelper;
/*    */ import org.hibernate.util.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OSCacheProvider
/*    */   implements CacheProvider
/*    */ {
/*    */   public static final String OSCACHE_REFRESH_PERIOD = "refresh.period";
/*    */   public static final String OSCACHE_CRON = "cron";
/*    */   public static final String OSCACHE_CAPACITY = "capacity";
/* 33 */   private static final Properties OSCACHE_PROPERTIES = new Config().getProperties();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Cache buildCache(String region, Properties properties)
/*    */     throws CacheException
/*    */   {
/* 47 */     int refreshPeriod = PropertiesHelper.getInt(StringHelper.qualify(region, "refresh.period"), OSCACHE_PROPERTIES, -1);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 52 */     String cron = OSCACHE_PROPERTIES.getProperty(StringHelper.qualify(region, "cron"));
/*    */     
/*    */ 
/* 55 */     OSCache cache = new OSCache(refreshPeriod, cron, region);
/*    */     
/* 57 */     Integer capacity = PropertiesHelper.getInteger(StringHelper.qualify(region, "capacity"), OSCACHE_PROPERTIES);
/* 58 */     if (capacity != null) { cache.setCacheCapacity(capacity.intValue());
/*    */     }
/* 60 */     return cache;
/*    */   }
/*    */   
/*    */   public long nextTimestamp() {
/* 64 */     return Timestamper.next();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void start(Properties properties)
/*    */     throws CacheException
/*    */   {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void stop() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isMinimalPutsEnabledByDefault()
/*    */   {
/* 84 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\OSCacheProvider.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */