package org.hibernate.cache;

import java.util.Map;

public abstract interface Cache
{
  public abstract Object read(Object paramObject)
    throws CacheException;
  
  public abstract Object get(Object paramObject)
    throws CacheException;
  
  public abstract void put(Object paramObject1, Object paramObject2)
    throws CacheException;
  
  public abstract void update(Object paramObject1, Object paramObject2)
    throws CacheException;
  
  public abstract void remove(Object paramObject)
    throws CacheException;
  
  public abstract void clear()
    throws CacheException;
  
  public abstract void destroy()
    throws CacheException;
  
  public abstract void lock(Object paramObject)
    throws CacheException;
  
  public abstract void unlock(Object paramObject)
    throws CacheException;
  
  public abstract long nextTimestamp();
  
  public abstract int getTimeout();
  
  public abstract String getRegionName();
  
  public abstract long getSizeInMemory();
  
  public abstract long getElementCountInMemory();
  
  public abstract long getElementCountOnDisk();
  
  public abstract Map toMap();
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\Cache.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */