/*     */ package org.hibernate.cache;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.UnresolvableObjectException;
/*     */ import org.hibernate.cfg.Settings;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.type.TypeFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardQueryCache
/*     */   implements QueryCache
/*     */ {
/*  30 */   private static final Log log = LogFactory.getLog(StandardQueryCache.class);
/*     */   private Cache queryCache;
/*     */   private UpdateTimestampsCache updateTimestampsCache;
/*     */   private final String regionName;
/*     */   
/*     */   public void clear() throws CacheException
/*     */   {
/*  37 */     this.queryCache.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StandardQueryCache(Settings settings, Properties props, UpdateTimestampsCache updateTimestampsCache, String regionName)
/*     */     throws HibernateException
/*     */   {
/*  47 */     if (regionName == null) regionName = StandardQueryCache.class.getName();
/*  48 */     String prefix = settings.getCacheRegionPrefix();
/*  49 */     if (prefix != null) { regionName = prefix + '.' + regionName;
/*     */     }
/*  51 */     log.info("starting query cache at region: " + regionName);
/*     */     
/*  53 */     this.queryCache = settings.getCacheProvider().buildCache(regionName, props);
/*  54 */     this.updateTimestampsCache = updateTimestampsCache;
/*  55 */     this.regionName = regionName;
/*     */   }
/*     */   
/*     */   public boolean put(QueryKey key, Type[] returnTypes, List result, boolean isNaturalKeyLookup, SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/*  61 */     if ((isNaturalKeyLookup) && (result.size() == 0)) {
/*  62 */       return false;
/*     */     }
/*     */     
/*     */ 
/*  66 */     if (log.isDebugEnabled()) {
/*  67 */       log.debug("caching query results in region: " + this.regionName);
/*     */     }
/*     */     
/*  70 */     List cacheable = new ArrayList(result.size() + 1);
/*  71 */     cacheable.add(new Long(session.getTimestamp()));
/*  72 */     for (int i = 0; i < result.size(); i++) {
/*  73 */       if (returnTypes.length == 1) {
/*  74 */         cacheable.add(returnTypes[0].disassemble(result.get(i), session, null));
/*     */       }
/*     */       else {
/*  77 */         cacheable.add(TypeFactory.disassemble((Object[])result.get(i), returnTypes, null, session, null));
/*     */       }
/*     */     }
/*     */     
/*  81 */     this.queryCache.put(key, cacheable);
/*     */     
/*  83 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List get(QueryKey key, Type[] returnTypes, boolean isNaturalKeyLookup, Set spaces, SessionImplementor session)
/*     */     throws HibernateException
/*     */   {
/*  92 */     if (log.isDebugEnabled()) {
/*  93 */       log.debug("checking cached query results in region: " + this.regionName);
/*     */     }
/*     */     
/*  96 */     List cacheable = (List)this.queryCache.get(key);
/*  97 */     if (cacheable == null) {
/*  98 */       log.debug("query results were not found in cache");
/*  99 */       return null;
/*     */     }
/*     */     
/* 102 */     Long timestamp = (Long)cacheable.get(0);
/* 103 */     if ((!isNaturalKeyLookup) && (!isUpToDate(spaces, timestamp))) {
/* 104 */       log.debug("cached query results were not up to date");
/* 105 */       return null;
/*     */     }
/*     */     
/* 108 */     log.debug("returning cached query results");
/* 109 */     for (int i = 1; i < cacheable.size(); i++) {
/* 110 */       if (returnTypes.length == 1) {
/* 111 */         returnTypes[0].beforeAssemble((Serializable)cacheable.get(i), session);
/*     */       }
/*     */       else {
/* 114 */         TypeFactory.beforeAssemble((Serializable[])cacheable.get(i), returnTypes, session);
/*     */       }
/*     */     }
/* 117 */     List result = new ArrayList(cacheable.size() - 1);
/* 118 */     for (int i = 1; i < cacheable.size(); i++) {
/*     */       try {
/* 120 */         if (returnTypes.length == 1) {
/* 121 */           result.add(returnTypes[0].assemble((Serializable)cacheable.get(i), session, null));
/*     */         }
/*     */         else {
/* 124 */           result.add(TypeFactory.assemble((Serializable[])cacheable.get(i), returnTypes, session, null));
/*     */         }
/*     */       }
/*     */       catch (UnresolvableObjectException uoe) {
/* 128 */         if (isNaturalKeyLookup)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 133 */           log.debug("could not reassemble cached result set");
/* 134 */           this.queryCache.remove(key);
/* 135 */           return null;
/*     */         }
/*     */         
/* 138 */         throw uoe;
/*     */       }
/*     */     }
/*     */     
/* 142 */     return result;
/*     */   }
/*     */   
/*     */   protected boolean isUpToDate(Set spaces, Long timestamp) {
/* 146 */     if (log.isDebugEnabled()) {
/* 147 */       log.debug("Checking query spaces for up-to-dateness: " + spaces);
/*     */     }
/* 149 */     return this.updateTimestampsCache.isUpToDate(spaces, timestamp);
/*     */   }
/*     */   
/*     */   public void destroy() {
/*     */     try {
/* 154 */       this.queryCache.destroy();
/*     */     }
/*     */     catch (Exception e) {
/* 157 */       log.warn("could not destroy query cache: " + this.regionName, e);
/*     */     }
/*     */   }
/*     */   
/*     */   public Cache getCache() {
/* 162 */     return this.queryCache;
/*     */   }
/*     */   
/*     */   public String getRegionName() {
/* 166 */     return this.regionName;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 170 */     return "StandardQueryCache(" + this.regionName + ')';
/*     */   }
/*     */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\StandardQueryCache.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */