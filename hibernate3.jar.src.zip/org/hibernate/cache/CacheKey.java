/*    */ package org.hibernate.cache;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.EntityMode;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheKey
/*    */   implements Serializable
/*    */ {
/*    */   private final Serializable key;
/*    */   private final Type type;
/*    */   private final String entityOrRoleName;
/*    */   private final EntityMode entityMode;
/*    */   private final int hashCode;
/*    */   
/*    */   public CacheKey(Serializable id, Type type, String entityOrRoleName, EntityMode entityMode, SessionFactoryImplementor factory)
/*    */   {
/* 36 */     this.key = id;
/* 37 */     this.type = type;
/* 38 */     this.entityOrRoleName = entityOrRoleName;
/* 39 */     this.entityMode = entityMode;
/* 40 */     this.hashCode = type.getHashCode(this.key, entityMode, factory);
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 45 */     return this.entityOrRoleName + '#' + this.key.toString();
/*    */   }
/*    */   
/*    */   public boolean equals(Object other) {
/* 49 */     if (!(other instanceof CacheKey)) return false;
/* 50 */     CacheKey that = (CacheKey)other;
/* 51 */     return (this.type.isEqual(this.key, that.key, this.entityMode)) && (this.entityOrRoleName.equals(that.entityOrRoleName));
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 56 */     return this.hashCode;
/*    */   }
/*    */   
/*    */   public Serializable getKey() {
/* 60 */     return this.key;
/*    */   }
/*    */   
/*    */   public String getEntityOrRoleName() {
/* 64 */     return this.entityOrRoleName;
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\CacheKey.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */