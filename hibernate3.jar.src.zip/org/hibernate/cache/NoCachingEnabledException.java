/*    */ package org.hibernate.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoCachingEnabledException
/*    */   extends CacheException
/*    */ {
/*    */   private static final String MSG = "Second-level cache is not enabled for usage [hibernate.cache.use_second_level_cache | hibernate.cache.use_query_cache]";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public NoCachingEnabledException()
/*    */   {
/* 18 */     super("Second-level cache is not enabled for usage [hibernate.cache.use_second_level_cache | hibernate.cache.use_query_cache]");
/*    */   }
/*    */ }


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\NoCachingEnabledException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */