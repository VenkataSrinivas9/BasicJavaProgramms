package org.hibernate.cache;

import java.util.Comparator;

public abstract interface CacheConcurrencyStrategy
{
  public abstract Object get(Object paramObject, long paramLong)
    throws CacheException;
  
  public abstract boolean put(Object paramObject1, Object paramObject2, long paramLong, Object paramObject3, Comparator paramComparator, boolean paramBoolean)
    throws CacheException;
  
  public abstract SoftLock lock(Object paramObject1, Object paramObject2)
    throws CacheException;
  
  public abstract void evict(Object paramObject)
    throws CacheException;
  
  public abstract boolean update(Object paramObject1, Object paramObject2)
    throws CacheException;
  
  public abstract boolean insert(Object paramObject1, Object paramObject2)
    throws CacheException;
  
  public abstract void release(Object paramObject, SoftLock paramSoftLock)
    throws CacheException;
  
  public abstract boolean afterUpdate(Object paramObject1, Object paramObject2, Object paramObject3, SoftLock paramSoftLock)
    throws CacheException;
  
  public abstract boolean afterInsert(Object paramObject1, Object paramObject2, Object paramObject3)
    throws CacheException;
  
  public abstract void remove(Object paramObject)
    throws CacheException;
  
  public abstract void clear()
    throws CacheException;
  
  public abstract void destroy();
  
  public abstract void setCache(Cache paramCache);
  
  public abstract String getRegionName();
  
  public abstract Cache getCache();
  
  public static abstract interface SoftLock {}
}


/* Location:              D:\JavaWorkSpace\BasicJava_Demos\lib\hibernate3.jar!\org\hibernate\cache\CacheConcurrencyStrategy.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */